#Write-Host "start triggers"
param(
    [Parameter(Mandatory=$true)]
    [string]$ADFResourceGroupName,
  
    [Parameter(Mandatory=$true)]
    [string]$DataFactoryName
  
  
  )
$triggerlocation = Import-csv -Path "c:\FrfinTrigger\Adf\Trigger.csv"
$triggerlocation| ForEach-Object { Start-AzDataFactoryV2Trigger -ResourceGroupName $ADFResourceGroupName   -DataFactoryName $DataFactoryName   -Name $_.name -Force}