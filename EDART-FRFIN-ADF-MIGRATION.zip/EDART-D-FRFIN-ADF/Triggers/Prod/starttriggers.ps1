param(
    [Parameter(Mandatory=$true)]
    [string]$ADFResourceGroupName,

    [Parameter(Mandatory=$true)]
    [string]$DataFactoryName
)

# Trigger CSV Path
$csvPath = "c:\FrfinTrigger\Adf\Trigger.csv"

# Import the CSV and get the trigger names
$triggers = Import-Csv -Path $csvPath | Select-Object -ExpandProperty TriggerName

# Exclude Triggers (keep below triggers in stop state)
$excludeTriggers = @(
    "tg_non_prod_CEGID_refresh",
    "tg_non_prod_CRB_refresh",
    "tg_non_prod_CRB_SilverDB_refresh",
    "tg_non_prod_HnB_hermes_refresh",
    "tg_non_prod_HnB_refresh"
)

# Filter out the excluded triggers
$triggersToStart = $triggers | Where-Object { $_ -notin $excludeTriggers }

# Loop through the triggers and start them
foreach ($trigger in $triggersToStart) {
    Write-Output "Starting trigger: $trigger"
    Start-AzDataFactoryV2Trigger -ResourceGroupName $ADFResourceGroupName   -DataFactoryName $DataFactoryName   -Name $_.name -Force
    }

Write-Output "Triggers started successfully."