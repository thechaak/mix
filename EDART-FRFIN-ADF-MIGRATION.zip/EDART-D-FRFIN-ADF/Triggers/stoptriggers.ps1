#Write-Host "stop triggers"
param(
    [Parameter(Mandatory=$true)]
    [string]$ADFResourceGroupName,
  
    [Parameter(Mandatory=$true)]
    [string]$DataFactoryName
  
  
  )
Get-AzDataFactoryV2Trigger -DataFactoryName $DataFactoryName  -ResourceGroupName $ADFResourceGroupName| where {$_.RuntimeState -eq "started"} |select name |Export-Csv -Path "c:\FrfinTrigger\Adf\Trigger.csv" -NoTypeInformation
$Trigger = Get-AzDataFactoryV2Trigger -DataFactoryName $DataFactoryName  -ResourceGroupName $ADFResourceGroupName
$Trigger| ForEach-Object { Stop-AzDataFactoryV2Trigger -ResourceGroupName $ADFResourceGroupName  -DataFactoryName $DataFactoryName -Name $_.name -Force}