param(
    [Parameter(Mandatory=$true)]
    [string]$Resourcegroupname,
  
    [Parameter(Mandatory=$true)]
    [string]$vmname
  
  
  )

$vmstatus = (Get-AzVM -ResourceGroupName $Resourcegroupname -Name $vmname -Status).Statuses

if ($vmstatus[1].code -eq "PowerState/deallocated"){

 Start-AzVM -ResourceGroupName $Resourcegroupname -Name $vmname
'The VM started successfully'
 Start-Sleep -Seconds 300

}

else {

    'The vm is  running'
}