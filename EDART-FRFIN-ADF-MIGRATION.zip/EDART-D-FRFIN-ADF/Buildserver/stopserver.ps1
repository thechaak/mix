param(
    [Parameter(Mandatory=$true)]
    [string]$Resourcegroupname,
  
    [Parameter(Mandatory=$true)]
    [string]$vmname
  
  
  )

$num = Get-Date -UFormat "%d"

$vmstatus = (Get-AzVM -ResourceGroupName $Resourcegroupname -Name $vmname -Status).Statuses

if ($vmstatus[1].code -eq "PowerState/running" -and $num -In 16..18){

 Write-Host "patchtime"

}
   
 

elseif ($vmstatus[1].code -eq "PowerState/running" -and $num -notIn 16..18) {
   Stop-AzVM -ResourceGroupName $Resourcegroupname -Name $vmname -Force
'The VM stopped successfully'
}

else{
 Write-Host "VM is in stopped state"
}