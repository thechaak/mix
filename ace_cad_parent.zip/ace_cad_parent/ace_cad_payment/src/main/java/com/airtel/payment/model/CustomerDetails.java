package com.airtel.payment.model;


import java.sql.Date;

public class CustomerDetails {

	private String accountNumber;
	private String delNumber;
	private float  outStandingBalance;
	private String circle;
	private float  unBilledUsage;
	private String customerCategory;
	private String status;
	
	private String flag;
	
	private String  paymentReceivedDate;
	private int     fxAccountNumber;          
	private String  customerName;            
	private int     invoiceNumber;                      
	private String  paymentMode;        
	private String   paymentAmount;          
	private  String chequeDate;            
	private String  chequeMICRCode;        
	private String  chequeIFSCCode;        
	private String  customerBankAccountNumber; 
	private int     postingStatusfx;        
	private int     postingRetrialAttempts; 
	private String  sourceOfRecord;         
	private String  nameOfSource;          
	private int     fileId;          
	
	private String changeWho; //Username with which program which loads this data
	
	private Date  changeDate;              
	private Date  insertDate;              
	private String  vendorId;             
	private String  userId;                 
	private String  lbxLocationId;         
	private String  lbxSourceId;           
	private String  sessionId;              
	private String  sourceReferenceId;      
	private String  paymentAdvice;          
	
	private String  isPaymentBounced;    
	private String   recordType;   
	
	private int  transactionId;
	private String receiptId;
	private String errorMessage;
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getDelNumber() {
		return delNumber;
	}
	public void setDelNumber(String delNumber) {
		this.delNumber = delNumber;
	}
	public float getOutStandingBalance() {
		return outStandingBalance;
	}
	public void setOutStandingBalance(float outStandingBalance) {
		this.outStandingBalance = outStandingBalance;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public float getUnBilledUsage() {
		return unBilledUsage;
	}
	public void setUnBilledUsage(float unBilledUsage) {
		this.unBilledUsage = unBilledUsage;
	}
	public String getCustomerCategory() {
		return customerCategory;
	}
	public void setCustomerCategory(String customerCategory) {
		this.customerCategory = customerCategory;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public String getPaymentReceivedDate() {
		return paymentReceivedDate;
	}
	public void setPaymentReceivedDate(String paymentReceivedDate) {
		this.paymentReceivedDate = paymentReceivedDate;
	}
	public int getFxAccountNumber() {
		return fxAccountNumber;
	}
	public void setFxAccountNumber(int fxAccountNumber) {
		this.fxAccountNumber = fxAccountNumber;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(int invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(String amount) {
		this.paymentAmount = amount;
	}
	public String getChequeDate() {
		return chequeDate;
	}
	public void setChequeDate(String chequeDate) {
		this.chequeDate = chequeDate;
	}
	public String getChequeMICRCode() {
		return chequeMICRCode;
	}
	public void setChequeMICRCode(String chequeMICRCode) {
		this.chequeMICRCode = chequeMICRCode;
	}
	public String getChequeIFSCCode() {
		return chequeIFSCCode;
	}
	public void setChequeIFSCCode(String chequeIFSCCode) {
		this.chequeIFSCCode = chequeIFSCCode;
	}
	public String getCustomerBankAccountNumber() {
		return customerBankAccountNumber;
	}
	public void setCustomerBankAccountNumber(String customerBankAccountNumber) {
		this.customerBankAccountNumber = customerBankAccountNumber;
	}
	
	public int getPostingStatusfx() {
		return postingStatusfx;
	}
	public void setPostingStatusfx(int postingStatusfx) {
		this.postingStatusfx = postingStatusfx;
	}
	public int getPostingRetrialAttempts() {
		return postingRetrialAttempts;
	}
	public void setPostingRetrialAttempts(int postingRetrialAttempts) {
		this.postingRetrialAttempts = postingRetrialAttempts;
	}
	public String getSourceOfRecord() {
		return sourceOfRecord;
	}
	public void setSourceOfRecord(String sourceOfRecord) {
		this.sourceOfRecord = sourceOfRecord;
	}
	public String getNameOfSource() {
		return nameOfSource;
	}
	public void setNameOfSource(String nameOfSource) {
		this.nameOfSource = nameOfSource;
	}
	public int getFileId() {
		return fileId;
	}
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}
	public String getChangeWho() {
		return changeWho;
	}
	public void setChangeWho(String changeWho) {
		this.changeWho = changeWho;
	}
	public java.util.Date getChangeDate() {
		return changeDate;
	}
	public void setChangeDate(Date sqlDate) {
		this.changeDate = sqlDate;
	}
	public java.util.Date getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Date sqlDate) {
		this.insertDate = sqlDate;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getLbxLocationId() {
		return lbxLocationId;
	}
	public void setLbxLocationId(String lbxLocationId) {
		this.lbxLocationId = lbxLocationId;
	}
	public String getLbxSourceId() {
		return lbxSourceId;
	}
	public void setLbxSourceId(String lbxSourceId) {
		this.lbxSourceId = lbxSourceId;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public String getSourceReferenceId() {
		return sourceReferenceId;
	}
	public void setSourceReferenceId(String sourceReferenceId) {
		this.sourceReferenceId = sourceReferenceId;
	}
	public String getPaymentAdvice() {
		return paymentAdvice;
	}
	public void setPaymentAdvice(String paymentAdvice) {
		this.paymentAdvice = paymentAdvice;
	}
	
	public String getIsPaymentBounced() {
		return isPaymentBounced;
	}
	public void setIsPaymentBounced(String isPaymentBounced) {
		this.isPaymentBounced = isPaymentBounced;
	}
	public String getRecordType() {
		return recordType;
	}
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getReceiptId() {
		return receiptId;
	}
	public void setReceiptId(String receiptId) {
		this.receiptId = receiptId;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
}