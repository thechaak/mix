package com.airtel.payment.service;

import java.util.List;

import com.airtel.payment.model.InvoiceDetails;

public interface InvoiceFetch {

	public List<InvoiceDetails> getOpenInvoices(String account);
}
