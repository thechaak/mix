package com.airtel.payment.util;


import java.io.IOException;
//import java.io.IOException --Testing Clearcase Checkout

import org.springframework.web.multipart.MultipartFile;

public class ACECADUtility {

	public static boolean validateUploadedFile(MultipartFile file) {

		if (!file.getContentType().equals("application/vnd.ms-excel")
				&& (!file
						.getContentType()
						.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))) {

			return false;
		} else {
			return true;

		}

	}

public static boolean validateRecordCount(MultipartFile file)
	{
		
		try {
			if(file.getInputStream()!=null)
			{
			
			return true;
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	}
}
	




