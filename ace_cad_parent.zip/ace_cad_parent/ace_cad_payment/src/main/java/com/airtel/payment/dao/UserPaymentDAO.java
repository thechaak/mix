package com.airtel.payment.dao;

import java.util.HashMap;
import java.util.List;

import com.airtel.payment.model.CustomerDetails;
import com.airtel.payment.model.InvoiceDetails;


public interface UserPaymentDAO {
	CustomerDetails retrieveDetails(String accountNumber,String delNumber);
	 //String checkforDuplication(String accountNumber,String delNumber,int  amount,String sysdate);
	 String checkForDuplication(String accountNumber,String invoiceNumber,int  amount,String paymentReceivedDate,String paymentMode);
	 HashMap aesCheckForDuplication(String accountNumber,String paymentReceivedDate,String paymentMode,List<InvoiceDetails> invoiceFetchImpl);
	

	 List<InvoiceDetails> invoiceDetailsFetch(String accountNumber);
	 		// boolean isCircleFound(String circle, List<String> paymentModeList);
			CustomerDetails paymentposting(CustomerDetails userObj);
			CustomerDetails aesPaymentposting(CustomerDetails userObj,List<InvoiceDetails> invoiceFetchImpl);
	
}
