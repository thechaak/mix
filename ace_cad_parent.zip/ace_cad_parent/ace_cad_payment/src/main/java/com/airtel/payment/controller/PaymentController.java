package com.airtel.payment.controller;


import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.CellReference;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.airtel.payment.dao.UserPaymentDAO;
import com.airtel.payment.model.CustomerDetails;
import com.airtel.payment.model.InvoiceDetails;
import com.airtel.payment.service.InvoiceFetch;
import com.airtel.payment.service.InvoiceFetchImpl;
import com.airtel.payment.util.ACECADUtility;

@Controller
public class PaymentController {

	@Autowired
	UserPaymentDAO userPaymentDAO;
	@Autowired
	CustomerDetails userObj;
	@Autowired
	InvoiceDetails invoiceObj;
	
	@Autowired
	InvoiceFetchImpl invoiceFetchImpl;
	
	@RequestMapping(value = "/SinglePayment")
	public ModelAndView login() {
		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("SinglePayment");
		return modelAndViewObj;
	}
	@RequestMapping(value = "/bulkhome")
	public ModelAndView bulki() {
		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("SinglePayment");
		return modelAndViewObj;
	}

	
	@RequestMapping(value = "/sp")
	public ModelAndView ananymousLogin() {
		ModelAndView modelAndViewObj = new ModelAndView();
		System.out.println("entered anynomous login");
		modelAndViewObj.setViewName("SinglePayment");
		return modelAndViewObj;
	}
	
	/*@RequestMapping(value = "/b")
	public ModelAndView bulkCheck() {
		ModelAndView modelAndViewObj = new ModelAndView();
		System.out.println("entered anynomous login");
		modelAndViewObj.setViewName("TestPayment1");
		return modelAndViewObj;
	}*/
	@RequestMapping(value = "/RetailSinglePayment")
	public ModelAndView singlePaymentRetail() {
		ModelAndView modelAndViewObj = new ModelAndView();
		
		modelAndViewObj.setViewName("RetailSinglePayment");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/AESSinglePayment")
	public ModelAndView singlePaymentAES() {
		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("AESSinglePayment");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/promptPage")
	public ModelAndView promptPage() {
		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("promptPage");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/userCheck", method = RequestMethod.POST)
	public ModelAndView userCheck(ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		
		
		List<String> circleList= new ArrayList<String>();
		circleList.add("AP");
		circleList.add("TN");
		circleList.add("MP");
		circleList.add("DL");
		//circleList.add("telangana");
		ModelAndView modelAndViewObj = new ModelAndView();
		try {
			System.out.println("entered into usercheck out");
			String accountNumber = request.getParameter("accountNumber");
			String delNumber = request.getParameter("delNumber");
			if(accountNumber==null&&delNumber==null){
				
				accountNumber=request.getParameter("actNum");
				delNumber=request.getParameter("delNum");
				//return modelAndViewObj;
			}
			System.out.println("got details ..has to enter " + accountNumber
					+ "," + delNumber);

			userObj = userPaymentDAO.retrieveDetails(accountNumber, delNumber);
			
			if(userObj.getStatus()!=null&& userObj.getStatus().equalsIgnoreCase("1"))
			{
				modelAndViewObj.addObject("CUST_NOT_FOUND",
						"CUSTOMER DETAILS ARE NOT FOUND");
				modelAndViewObj.setViewName("SinglePayment");
				return modelAndViewObj;
			}
		/*	if(userObj.getFlag().equalsIgnoreCase("11")){
				modelAndViewObj.addObject("flagError","Data not found");
			}
			if(userObj.getFlag().equalsIgnoreCase("12")){
				modelAndViewObj.addObject("flagError","Data not found");
			}
			if(userObj.getFlag().equalsIgnoreCase("13")){
				modelAndViewObj.addObject("flagError","Data not found");
			}			*/
			
			List<String> paymentModeList= new ArrayList<String>();
			paymentModeList.add("Cash");
			
			paymentModeList.add("DD");
			paymentModeList.add("Card");
			System.out.println("user circle"+userObj.getCircle());
			
			//boolean isCircleFound = userPaymentDAO.isCircleFound(userObj.getCircle(), circleList);
			
			System.out.println(userObj.getCircle() +","  +circleList.get(1) );
			//System.out.println(isCircleFound);
			if (userObj.getCustomerCategory() != null
					&& userObj.getCustomerCategory().equalsIgnoreCase("RETAIL")) {
				
				modelAndViewObj.addObject("paymentModeList",paymentModeList);
				//modelAndViewObj.setViewName("RetailSinglePayment");
				
				
				System.out.println(" User Object : " + userObj);
				modelAndViewObj.addObject("customerDetails", userObj);
				modelAndViewObj.setViewName("RetailSinglePayment");
			} 
				
			
			
			
			
			
			
			else if (userObj.getCustomerCategory() != null
					&& userObj.getCustomerCategory().equalsIgnoreCase("B2B")) {
				//List<InvoiceDetails> openInvoices=invoiceFetch.getOpenInvoices();
				invoiceFetchImpl.setOpenInvoices(userObj.getAccountNumber());
				/*for(int i=0;i<invoiceFetch.getOpenInvoices().size();i++)
				{
					System.out.println("post getOpenInvoices():"+invoiceFetch.getOpenInvoices().get(i).getInvoiceNumber());
				}
		*/
				modelAndViewObj.addObject("paymentModeList",paymentModeList);
				modelAndViewObj.addObject("customerDetails", userObj);
				modelAndViewObj.addObject("invoiceFetchImpl", invoiceFetchImpl); 
				modelAndViewObj.setViewName("AESSinglePayment");

			} /*else {
				if (userObj.getStatus() != null
						
						&& userObj.getStatus().toUpperCase()
								.contains("1")) {userO
					modelAndViewObj.addObject("CUST_NOT_FOUND",
							"Customer details are not found !!");
					modelAndViewObj.setViewName("SinglePayment");
				}}*/
			
		} catch (Exception exp) {
			System.out.println("Exception occured while processing requerst, exception message is "
							+ exp.getLocalizedMessage());
			exp.printStackTrace();
			modelAndViewObj.setViewName("SinglePayment");
		}

		return modelAndViewObj;
		/*
		 * if (userObj.getAccountNumber() != null &&
		 * userObj.getFlag().equalsIgnoreCase("13")) {
		 * modelAndViewObj.addObject("customerDetails", userObj);
		 * modelAndViewObj.setViewName("flag13");
		 */

		// return modelAndViewObj;

	}

	@RequestMapping(value = "/success", method = RequestMethod.GET)
	public ModelAndView authorized(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("success");
		modelAndViewObj.addObject("message", "Authorized User");
		return modelAndViewObj;

	}

	@RequestMapping(value = "/invalid", method = RequestMethod.GET)
	public ModelAndView unAuthorized(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("invalidUser");
		modelAndViewObj.addObject("message", "Authorized User");
		return modelAndViewObj;

	}
	
	@RequestMapping(value = "/bulkHome", method = RequestMethod.POST)
	public ModelAndView bulkHome(HttpServletRequest request) throws IOException {
		ModelAndView modelAndViewObj=new ModelAndView();
		modelAndViewObj.setViewName("bulk");
		return modelAndViewObj;
	}

	

	@RequestMapping(value = "/invokeAjax", method = RequestMethod.GET)
	public @ResponseBody String processAJAXRequest
			//(@ModelAttribute("CustomerDetails") CustomerDetails userObj){
				//,@RequestParam("delNumber") String delNumber){
				(@RequestParam("amountPaid") String amountPaid) {
				  
		userObj.setPaymentAmount(amountPaid);
		System.out.println(" del Number : "+userObj.getDelNumber());
		System.out.println(" acc Number : "+userObj.getAccountNumber());
		System.out.println(" amount paid :"+userObj.getPaymentAmount());
		String response=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String formattedDate=dateFormat.format(date);
		String paymentMode=userObj.getPaymentMode();
		int payAmount=Integer.parseInt(userObj.getPaymentAmount());
		userObj.setPaymentReceivedDate(formattedDate);
		System.out.println("check_if_paid prdate"+formattedDate);
		System.out.println("userobj date"+userObj.getPaymentReceivedDate());
		String paidStatus = userPaymentDAO.checkForDuplication(userObj.getAccountNumber(), null,payAmount,userObj.getPaymentReceivedDate(),paymentMode);
		System.out.println(userObj.getAccountNumber());
		System.out.println(userObj.getPaymentAmount());
		System.out.println("paid status id .  . " + paidStatus);
		if(paidStatus.equalsIgnoreCase("1"))
		{
			//NPTD -- Not Paid Today
		    response = "NPTD";
		}
		else{
			//PD -- Paid Today
			response = "PD";
		}
		
			//String response = "NOT_PAID_TODAY";
			return response;
	}
	
	@RequestMapping(value = "/aesPaymentPostAjax", method = RequestMethod.GET)
	public @ResponseBody HashMap aesPaymentPostAjax
			//(@ModelAttribute("CustomerDetails") CustomerDetails userObj){
				//,@RequestParam("delNumber") String delNumber){
				(@ModelAttribute("invoicefetchImpl") InvoiceFetchImpl invoiceFetchImpl,
						HttpServletRequest request) {
			
		List<InvoiceDetails> invoiceFetchImpl_=invoiceFetchImpl.getOpenInvoices(); 
		System.out.println("Invoices count in POSTAJAX is:"+invoiceFetchImpl_.size());
		for(int i=0;i<invoiceFetchImpl_.size();i++)
		{
			System.out.println("post getOpenInvoices() for i:"+i+":"+invoiceFetchImpl_.get(i).getInvoiceNumber());
		}
				
		System.out.println(" del Number : "+userObj.getDelNumber());
		System.out.println(" acc Number : "+userObj.getAccountNumber());
		System.out.println(" amount paid :"+userObj.getPaymentAmount());
		String response=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String formattedDate=dateFormat.format(date);
		HashMap paidStatus=null;
		String invoice=null;
		int paymentAmount=0;
		String paymentMode=request.getParameter("modeOfPayment");
		userObj.setPaymentMode(paymentMode);
		userObj.setPaymentReceivedDate(formattedDate);
		System.out.println("check_if_paid prdate"+formattedDate);
		System.out.println("userobj date"+userObj.getPaymentReceivedDate());
/*		for(int i=0;i<invoiceFetchImpl_.size();i++)
		{
		invoice=invoiceFetchImpl_.get(i).getInvoiceNumber();
		//invoice="0";
		paymentAmount=invoiceFetchImpl_.get(i).getAmountPaid();*/
		paidStatus = userPaymentDAO.aesCheckForDuplication(userObj.getAccountNumber(),userObj.getPaymentReceivedDate(),paymentMode,invoiceFetchImpl_);
		System.out.println("Duplication check Status:"+paidStatus);
		/*if(paidStatus.equalsIgnoreCase("2")||paidStatus=="2")
		{	
			response="NPTD";
			return response;
		}
		}*/
		System.out.println(userObj.getAccountNumber());
		System.out.println(userObj.getPaymentAmount());
		System.out.println("paid status id .  . " + paidStatus);
		/*if(paidStatus.equalsIgnoreCase("1"))
		{
			//NPTD -- Not Paid Today
		    response = "NPTD";
		}
		else{
			//PD -- Paid Today
			response = "PD";
		}*/
		
			//String response = "NOT_PAID_TODAY";
			return paidStatus;
	}
	@RequestMapping(value = "/PaymentPosting", method = RequestMethod.POST)
	public ModelAndView PaymentPost(ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {

		ModelAndView modelAndViewObj = new ModelAndView();
		// String accountNumber = request.getParameter("accountNumber");
		System.out.println("agg" + userObj.getAccountNumber());
		// String delNumber = request.getParameter("delNumber");
		System.out.println("entered into payment post");
		//String  amount = request.getParameter("amountPaid");
		System.out.println("amount  below"+userObj.getPaymentAmount());
		String paymentMode=request.getParameter("modeOfPayment");
	//	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		 java.util.Date utilDate = new java.util.Date();
		    java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

		
		userObj.setInvoiceNumber(0);
	
		userObj.setPaymentMode(paymentMode);// to get from request
		
		userObj.setChequeDate(null);
		userObj.setChequeMICRCode(null);
		userObj.setChequeIFSCCode(null);
		userObj.setCustomerBankAccountNumber(null);
	
		userObj.setPostingStatusfx(0);
		userObj.setPostingRetrialAttempts(0);
		userObj.setSourceOfRecord("Single Payment");
		userObj.setNameOfSource(null);
		userObj.setFileId(0);
		userObj.setChangeWho("vendor");// to get from request
		userObj.setChangeDate(sqlDate);// to get from request
		userObj.setInsertDate(sqlDate);// to get from request
		userObj.setVendorId("vndrid");// to get from request
		//userObj.setUserId("uss123");// to get from request
		
		userObj.setLbxLocationId(null);
		userObj.setLbxSourceId(null);
		userObj.setSessionId("session id");// to get from request
		userObj.setSourceReferenceId("kajda");
		userObj.setPaymentAdvice("0");// to get from request
		//userObj.setCustomer_type("cus.type");// to get from request
		userObj.setIsPaymentBounced(null);
		userObj.setRecordType("PAY");

		 System.out.println("got details ..has to enter "+userObj.getAccountNumber()+","+userObj.getDelNumber()+userObj.getPaymentReceivedDate() );
		 CustomerDetails userObj1 = userPaymentDAO.paymentposting(userObj);
		System.out.println("transactionId in controller "+userObj.getTransactionId());
		
		modelAndViewObj.addObject("transactionId",userObj1.getTransactionId());
		modelAndViewObj.addObject("receiptId",userObj1.getReceiptId());
		modelAndViewObj.addObject("customerDetailsObj",userObj1);
		modelAndViewObj.setViewName("paymentPost");
		

	
		return modelAndViewObj;

	}
	@RequestMapping(value = "/AESPaymentPosting", method = RequestMethod.POST)
	public ModelAndView AESPaymentPost(ModelMap model, HttpServletRequest request,HttpServletResponse response,
			@ModelAttribute("invoicefetchImpl") InvoiceFetchImpl invoiceFetchImpl) {

		ModelAndView modelAndViewObj = new ModelAndView();
		List<InvoiceDetails> invoiceFetchImpl_=invoiceFetchImpl.getOpenInvoices();
		
		
		System.out.println("agg" + userObj.getAccountNumber());
		// String delNumber = request.getParameter("delNumber");
		System.out.println("entered into payment post");
		//String  amount = request.getParameter("amountPaid");
		System.out.println("amount  below"+userObj.getPaymentAmount());
		String paymentMode=request.getParameter("modeOfPayment");
	//	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		 java.util.Date utilDate = new java.util.Date();
		    java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

		
		userObj.setInvoiceNumber(0);
	
		userObj.setPaymentMode(paymentMode);// to get from request
		
		userObj.setChequeDate(null);
		userObj.setChequeMICRCode(null);
		userObj.setChequeIFSCCode(null);
		userObj.setCustomerBankAccountNumber(null);
	
		userObj.setPostingStatusfx(0);
		userObj.setPostingRetrialAttempts(0);
		userObj.setSourceOfRecord("Single Payment");
		userObj.setNameOfSource(null);
		userObj.setFileId(0);
		userObj.setChangeWho("vendor");// to get from request
		userObj.setChangeDate(sqlDate);// to get from request
		userObj.setInsertDate(sqlDate);// to get from request
		userObj.setVendorId("vndrid");// to get from request
		//userObj.setUserId("uss123");// to get from request
		
		userObj.setLbxLocationId(null);
		userObj.setLbxSourceId(null);
		userObj.setSessionId("session id");// to get from request
		userObj.setSourceReferenceId("kajda");
		userObj.setPaymentAdvice("0");// to get from request
		//userObj.setCustomer_type("cus.type");// to get from request
		userObj.setIsPaymentBounced(null);
		userObj.setRecordType("PAY");

		 System.out.println("got details ..has to enter "+userObj.getAccountNumber()+","+userObj.getDelNumber()+userObj.getPaymentReceivedDate() );
		 CustomerDetails userObj1 = userPaymentDAO.aesPaymentposting(userObj,invoiceFetchImpl_);
		System.out.println("transactionId in controller "+userObj.getTransactionId());
		
		modelAndViewObj.addObject("transactionId",userObj1.getTransactionId());
		modelAndViewObj.addObject("receiptId",userObj1.getReceiptId());
		modelAndViewObj.addObject("customerDetailsObj",userObj1);
		modelAndViewObj.setViewName("paymentPost");
		

	
		return modelAndViewObj;

	}
	@RequestMapping(value = "/PrintCancel", method = RequestMethod.POST)
	public ModelAndView PrintCancel(ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		System.out.println("abc");
		
		modelAndViewObj.setViewName("SinglePayment");
		return modelAndViewObj;

	}
	@RequestMapping(value = "/getInvoice", method = RequestMethod.POST)
	public ModelAndView getInvoice(ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		//String accountNumber=request.getParameter("accountNumber");
		System.out.println("account number"+userObj.getAccountNumber());
		List<InvoiceDetails> invoiceDetailsList=userPaymentDAO.invoiceDetailsFetch(userObj.getAccountNumber());
		modelAndViewObj.addObject("invoiceDetailsList", invoiceDetailsList);
		modelAndViewObj.addObject("accountNum", userObj.getAccountNumber());
		modelAndViewObj.setViewName("invoice");
		return modelAndViewObj;
		
	}
	}


