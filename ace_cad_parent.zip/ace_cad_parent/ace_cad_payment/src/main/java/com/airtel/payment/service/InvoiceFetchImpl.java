package com.airtel.payment.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.airtel.payment.dao.UserPaymentDAO;
import com.airtel.payment.model.CustomerDetails;
import com.airtel.payment.model.InvoiceDetails;

public class InvoiceFetchImpl {

	
	@Autowired
	UserPaymentDAO userPaymentDAO;

@Autowired
CustomerDetails userObj;

private List<InvoiceDetails> openInvoices;
	public List<InvoiceDetails> getOpenInvoices() {
		//String accountNumber="abc123";
		
		return  openInvoices;
//	return openInvoices;
}
public void setOpenInvoices(String accountNo) {
	List<InvoiceDetails> openInvoices_=userPaymentDAO.invoiceDetailsFetch(accountNo);
	
	for(int i=0;i<openInvoices_.size();i++)
	{
		System.out.println("post getOpenInvoices() for i:"+i+":"+openInvoices_.get(i).getInvoiceNumber());
	}
	this.openInvoices = openInvoices_;
}
	
public void setOpenInvoices(List<InvoiceDetails> openInvoices) {
	
	this.openInvoices = openInvoices;
}
	
	}
