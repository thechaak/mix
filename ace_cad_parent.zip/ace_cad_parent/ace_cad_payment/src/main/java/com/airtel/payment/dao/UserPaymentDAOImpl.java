package com.airtel.payment.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;

import com.airtel.payment.model.CustomerDetails;
import com.airtel.payment.model.InvoiceDetails;

public class UserPaymentDAOImpl implements UserPaymentDAO {

	@Autowired
	@Qualifier("dataSource")
	private DataSource dataSource;
	
	@Autowired
	@Qualifier("jdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	public CustomerDetails retrieveDetails(String accountNumber,String delNumber) {
		CustomerDetails customerObj = new CustomerDetails();

		final String procedureCall = "{call ace_cad_single_payment.ace_cad_fetch_details(?,?,?,?,?,?,?,?,?)}";
		Connection connection = null;
		delNumber="";
		try {

			// Get Connection instance from dataSource
			System.out.println("connection:" + dataSource.getConnection());
			jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			System.out.println("conn");
			System.out.println("input values are:"+accountNumber+":"+delNumber);

			CallableStatement callableStatement = connection
					.prepareCall(procedureCall);

			callableStatement.registerOutParameter(1, Types.VARCHAR);
			callableStatement.registerOutParameter(2, Types.VARCHAR);

			callableStatement.setString(1, accountNumber);
			callableStatement.setString(2, delNumber);
			

			callableStatement.registerOutParameter(3, Types.DECIMAL);
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.registerOutParameter(5, Types.DECIMAL);
			callableStatement.registerOutParameter(6, Types.VARCHAR);
			callableStatement.registerOutParameter(7, Types.VARCHAR);
			callableStatement.registerOutParameter(8, Types.VARCHAR);
			callableStatement.registerOutParameter(9, Types.VARCHAR);

			callableStatement.executeUpdate();
			String CSAccountNumber = callableStatement.getString(1);
			String CSDelNumber = callableStatement.getString(2);
			String nineparameter = callableStatement.getString(9);

			
			customerObj.setDelNumber(CSDelNumber);
			customerObj.setAccountNumber(CSAccountNumber);
			customerObj.setOutStandingBalance(callableStatement.getFloat(3));
			customerObj.setCircle(callableStatement.getString(4));
			customerObj.setUnBilledUsage(callableStatement.getFloat(5));
			customerObj.setCustomerCategory(callableStatement.getString(6));// B2B or B2C
			customerObj.setCustomerCategory("B2B"); // for TESTING
			customerObj.setCustomerName(callableStatement.getString(7));
			customerObj.setStatus(callableStatement.getString(8));
			customerObj.setFlag(callableStatement.getString(9));

			System.out.println(customerObj.getDelNumber() + "," + accountNumber + ","
					+ callableStatement.getInt(3) + ","
					+ callableStatement.getString(4) + "status is... "
					+ customerObj.getStatus() + "," + "flag is... "
					+ callableStatement.getString(9) + "," + "nine is ..." +nineparameter);
			
			System.out.println(" out standing balance -- : "
					+ customerObj.getOutStandingBalance());
			System.out.println(" circle -- : " + customerObj.getCircle());

			System.out.println(" unbilled usage -- : "
					+ customerObj.getUnBilledUsage());
			System.out.println(" customer category -- : "
					+ customerObj.getCustomerCategory());
			System.out.println(" flag : " + customerObj.getFlag());
			System.out.println(" status : " + customerObj.getStatus());
			System.out.println(" bill f name  : " + customerObj.getCustomerName());

			System.out.println(" All details retreived");
		} catch (SQLException e) {
			e.printStackTrace();

		} finally {

			if (connection != null)
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return customerObj;
	}


	public String checkForDuplication(String accountNumber, String invoiceNumber,
			int amount, String paymentReceivedDate, String paymentMode) {

		final String procedureCall = "{call ace_cad_single_payment.ace_cad_check_if_paid(?,?,?,?,?,?,?,?)}";
		Connection connection = null;
		String paid_status = "nll";
		String flag = null;

		try {

			// Get Connection instance from dataSource
			System.out.println("connection:" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			System.out.println("conn");

			System.out
					.println("account:"+accountNumber + ",Invoice: " + invoiceNumber + ",PayAmount " + amount+"PaymentDate:"+paymentReceivedDate
							+"PaymentMode:"+paymentMode);

			CallableStatement callableStatement = connection
					.prepareCall(procedureCall);

			callableStatement.setString(1, accountNumber);
			callableStatement.setString(2, invoiceNumber);
			callableStatement.setString(3, null);
			callableStatement.setInt(4, amount);
			callableStatement.setString(5, paymentReceivedDate);
			callableStatement.setString(6, paymentMode);

			callableStatement.registerOutParameter(7, Types.VARCHAR);
			callableStatement.registerOutParameter(8, Types.VARCHAR);

			callableStatement.executeUpdate();

			paid_status = callableStatement.getString(7);
			flag = callableStatement.getString(8);
			System.out.println("paid status is..."+paid_status);

		} catch (SQLException e) {
			e.printStackTrace();

		} finally {

			if (connection != null)
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return paid_status;
	}
	public HashMap aesCheckForDuplication(String accountNumber, String paymentReceivedDate, String paymentMode,List<InvoiceDetails> invoiceFetchImpl) {

		final String procedureCall = "{call ace_cad_single_payment.ace_cad_check_if_paid(?,?,?,?,?,?,?,?)}";
		Connection connection = null;
		String paid_status = "nll";
		String flag = null;
		String invoiceNumber="";
		int amount=0;
		HashMap paid_status_hashmap=new HashMap();

		try {

			
			//JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			System.out.println("conn");

			

			CallableStatement callableStatement = connection
					.prepareCall(procedureCall);

			callableStatement.setString(1, accountNumber);
			//callableStatement.setString(2, invoiceNumber);
			callableStatement.setString(3, null);
			//callableStatement.setInt(4, amount);
			callableStatement.setString(5, paymentReceivedDate);
			callableStatement.setString(6, paymentMode);

			callableStatement.registerOutParameter(7, Types.VARCHAR);
			callableStatement.registerOutParameter(8, Types.VARCHAR);
			for(int i=0;i<invoiceFetchImpl.size();i++)
			{
			invoiceNumber=invoiceFetchImpl.get(i).getInvoiceNumber();
			
			amount=invoiceFetchImpl.get(i).getAmountPaid();
			
			callableStatement.setString(2, invoiceNumber);
			callableStatement.setInt(4, amount);
			System.out
			.println("account:"+accountNumber + ",Invoice: " + invoiceNumber + ",PayAmount " + amount+"PaymentDate:"+paymentReceivedDate
					+"PaymentMode:"+paymentMode);
			callableStatement.executeUpdate();
			paid_status = callableStatement.getString(7);
			if(paid_status.equalsIgnoreCase("2")&& invoiceNumber!="0")
			{
				paid_status_hashmap.put(invoiceNumber, amount);
				System.out.println("Duplicates observed for invoice and amount:"+invoiceNumber+":"+amount);
			}
			}
			
			flag = callableStatement.getString(8);
			System.out.println("paid status is..."+paid_status);

		} catch (SQLException e) {
			e.printStackTrace();

		} finally {

			if (connection != null)
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return paid_status_hashmap;
	}
	

	public CustomerDetails paymentposting(CustomerDetails custObj) {

		// CustomerDetails customerObj=new CustomerDetails();

		final String procedureCall = "{call ace_cad_single_payment.ace_cad_payment_posting(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
		Connection connection = null;

		try {

			// Get Connection instance from dataSource
			System.out.println("connection:" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			System.out.println("enterd into payment posting");

			CallableStatement callableStatement = connection
					.prepareCall(procedureCall);

			callableStatement.setString(1, custObj.getAccountNumber());
			//callableStatement.setInt(2, custObj.getFxAccountNumber());
			callableStatement.setString(2, custObj.getCustomerName());
			callableStatement.setInt(3, custObj.getInvoiceNumber());
			callableStatement.setString(4, custObj.getDelNumber());
			callableStatement.setString(5, custObj.getPaymentMode());
			callableStatement.setString(6, custObj.getPaymentAmount());
			callableStatement.setString(7, custObj.getChequeDate());
			callableStatement.setString(8, custObj.getChequeMICRCode());
			callableStatement.setString(9, custObj.getChequeIFSCCode());
			callableStatement.setString(10,
					custObj.getCustomerBankAccountNumber());
			callableStatement.setString(11, custObj.getPaymentReceivedDate());
			callableStatement.setInt(12, custObj.getPostingStatusfx());
			callableStatement.setInt(13, custObj.getPostingRetrialAttempts());
			callableStatement.setString(14, custObj.getSourceOfRecord());
			callableStatement.setString(15, custObj.getNameOfSource());
			callableStatement.setInt(16, custObj.getFileId());
			callableStatement.setString(17, custObj.getChangeWho());
			callableStatement.setDate(18, (Date) custObj.getChangeDate());
			callableStatement.setDate(19, (Date) custObj.getInsertDate());
			callableStatement.setString(20, custObj.getVendorId());
			callableStatement.setString(21, custObj.getAccountNumber());
			callableStatement.setString(22, custObj.getCircle());
			callableStatement.setString(23, custObj.getLbxLocationId());
			callableStatement.setString(24, custObj.getLbxSourceId());
			callableStatement.setString(25, custObj.getSessionId());
			callableStatement.setString(26, custObj.getSourceReferenceId());
			callableStatement.setString(27, custObj.getPaymentAdvice());
			callableStatement.setString(28, custObj.getCustomerCategory());
			callableStatement.setString(29, custObj.getIsPaymentBounced());
			callableStatement.setString(30, custObj.getRecordType());

			callableStatement.registerOutParameter(31, Types.INTEGER);
			callableStatement.registerOutParameter(32, Types.INTEGER);
			callableStatement.registerOutParameter(33, Types.VARCHAR);
			callableStatement.registerOutParameter(34, Types.VARCHAR);
			callableStatement.registerOutParameter(35, Types.VARCHAR);
			callableStatement.registerOutParameter(36, Types.VARCHAR);
			callableStatement.executeUpdate();

		

			custObj.setTransactionId(callableStatement.getInt(32));
			System.out.println((callableStatement.getInt(32)));
			custObj.setReceiptId(callableStatement.getString(33));
			custObj.setStatus(callableStatement.getString(34));
			custObj.setErrorMessage(callableStatement.getString(35));
			custObj.setFlag(callableStatement.getString(36));

			System.out.println("connected to db for posting");
			
			System.out.println("fx account number" + custObj.getFxAccountNumber());
			System.out.println("transactionId " + custObj.getTransactionId());
			System.out.println("ReceiptId " + custObj.getReceiptId());
			System.out.println("Status " + custObj.getErrorMessage());
			System.out.println("Error Message " + custObj.getErrorMessage());
			System.out.println("flag " + custObj.getFlag());

			
		
		
			System.out.println(" All details posted");
		} catch (SQLException e) {
			e.printStackTrace();

		} finally {

			if (connection != null)
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return custObj;
	}

	public CustomerDetails aesPaymentposting(CustomerDetails custObj,List<InvoiceDetails> invoiceFetchImpl) {

		// CustomerDetails customerObj=new CustomerDetails();

		final String procedureCall = "{call ace_cad_single_payment.ace_cad_payment_posting(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
		Connection connection = null;

		try {

			// Get Connection instance from dataSource
			System.out.println("connection:" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			System.out.println("enterd into payment posting");

			CallableStatement callableStatement = connection
					.prepareCall(procedureCall);

			callableStatement.setString(1, custObj.getAccountNumber());
			//callableStatement.setInt(2, custObj.getFxAccountNumber());
			callableStatement.setString(2, custObj.getCustomerName());
			//callableStatement.setInt(3, custObj.getInvoiceNumber());
			callableStatement.setString(4, custObj.getDelNumber());
			callableStatement.setString(5, custObj.getPaymentMode());
			//callableStatement.setString(6, custObj.getPaymentAmount());
			callableStatement.setString(7, custObj.getChequeDate());
			callableStatement.setString(8, custObj.getChequeMICRCode());
			callableStatement.setString(9, custObj.getChequeIFSCCode());
			callableStatement.setString(10,
					custObj.getCustomerBankAccountNumber());
			callableStatement.setString(11, custObj.getPaymentReceivedDate());
			callableStatement.setInt(12, custObj.getPostingStatusfx());
			callableStatement.setInt(13, custObj.getPostingRetrialAttempts());
			callableStatement.setString(14, custObj.getSourceOfRecord());
			callableStatement.setString(15, custObj.getNameOfSource());
			callableStatement.setInt(16, custObj.getFileId());
			callableStatement.setString(17, custObj.getChangeWho());
			callableStatement.setDate(18, (Date) custObj.getChangeDate());
			callableStatement.setDate(19, (Date) custObj.getInsertDate());
			callableStatement.setString(20, custObj.getVendorId());
			callableStatement.setString(21, custObj.getAccountNumber());
			callableStatement.setString(22, custObj.getCircle());
			callableStatement.setString(23, custObj.getLbxLocationId());
			callableStatement.setString(24, custObj.getLbxSourceId());
			callableStatement.setString(25, custObj.getSessionId());
			callableStatement.setString(26, custObj.getSourceReferenceId());
			callableStatement.setString(27, custObj.getPaymentAdvice());
			callableStatement.setString(28, custObj.getCustomerCategory());
			callableStatement.setString(29, custObj.getIsPaymentBounced());
			callableStatement.setString(30, custObj.getRecordType());

			callableStatement.registerOutParameter(31, Types.INTEGER);
			callableStatement.registerOutParameter(32, Types.INTEGER);
			callableStatement.registerOutParameter(33, Types.VARCHAR);
			callableStatement.registerOutParameter(34, Types.VARCHAR);
			callableStatement.registerOutParameter(35, Types.VARCHAR);
			callableStatement.registerOutParameter(36, Types.VARCHAR);
			
			for(int i=0;i<invoiceFetchImpl.size();i++)
			{
				System.out.println("Amount paid for invoice-"+invoiceFetchImpl.get(i).getInvoiceNumber()+":Invoice Aount-"+invoiceFetchImpl.get(i).getInvoiceAmount()+":AmountPaid-"+invoiceFetchImpl.get(i).getAmountPaid());
				if(invoiceFetchImpl.get(i).getAmountPaid()>0)
				{
					callableStatement.setString(3, invoiceFetchImpl.get(i).getInvoiceNumber());
					callableStatement.setInt(6, invoiceFetchImpl.get(i).getAmountPaid());
					System.out.println("post getOpenInvoices() for i:"+i+":"+invoiceFetchImpl.get(i).getInvoiceNumber());
					callableStatement.executeUpdate();
				}
			}

		

			custObj.setTransactionId(callableStatement.getInt(32));
			System.out.println((callableStatement.getInt(32)));
			custObj.setReceiptId(callableStatement.getString(33));
			custObj.setStatus(callableStatement.getString(34));
			custObj.setErrorMessage(callableStatement.getString(35));
			custObj.setFlag(callableStatement.getString(36));

			System.out.println("connected to db for posting");
			
			System.out.println("fx account number" + custObj.getFxAccountNumber());
			System.out.println("transactionId " + custObj.getTransactionId());
			System.out.println("ReceiptId " + custObj.getReceiptId());
			System.out.println("Status " + custObj.getErrorMessage());
			System.out.println("Error Message " + custObj.getErrorMessage());
			System.out.println("flag " + custObj.getFlag());

			
		
		
			System.out.println(" All details posted");
		} catch (SQLException e) {
			e.printStackTrace();

		} finally {

			if (connection != null)
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return custObj;
	}

	
	public List<InvoiceDetails> invoiceDetailsFetch(String accountNumber) {
		// TODO Auto-generated method stub
		
		final String procedureCall = "{call ace_cad_single_payment.ace_cad_aes_invoice_fetch(?,?,?)}";
		Connection connection = null;
		int count=0;
		List<InvoiceDetails> invoiceDetailsList=new ArrayList<InvoiceDetails>();
		ResultSet resSetinvoiceDetails = null;
		String invoiceNumber;
		int invoiceAmount;
		String billDate;
		String dueDate;
		
		
		try {

			// Get Connection instance from dataSource
			System.out.println("connection:" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			System.out.println("enterd into invoice fetch");
			CallableStatement callableStatement = connection
					.prepareCall(procedureCall);
			callableStatement.setString(1, accountNumber);
			System.out.println("account number:"+accountNumber);
			callableStatement.registerOutParameter(2, Types.INTEGER);
			callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
			callableStatement.executeUpdate();
			count = callableStatement.getInt(2);
			System.out.println("count......"+count);
			//billableIdsList.add(totalPages);
			resSetinvoiceDetails = (ResultSet) callableStatement.getObject(3);
			
			InvoiceDetails invoiceObj_0_invoice=new InvoiceDetails();
			invoiceObj_0_invoice.setInvoiceNumber("0");
			invoiceObj_0_invoice.setInvoiceAmount(0);
			invoiceObj_0_invoice.setBillDate("0");
			invoiceObj_0_invoice.setDueDate("0");
			invoiceObj_0_invoice.setAmountPaid(0);
			invoiceDetailsList.add(invoiceObj_0_invoice);
	
			if (resSetinvoiceDetails != null) {
				while (resSetinvoiceDetails.next()) {
					InvoiceDetails invoiceObj=new InvoiceDetails();
					invoiceNumber = resSetinvoiceDetails.getString("invoice_no");
					invoiceAmount = resSetinvoiceDetails.getInt("amount");
					billDate=resSetinvoiceDetails.getString("bill_date");
					dueDate=resSetinvoiceDetails.getString("due_date");
					invoiceObj.setAccountNumber(accountNumber);
					invoiceObj.setInvoiceNumber(invoiceNumber);
					invoiceObj.setInvoiceAmount(invoiceAmount);
					invoiceObj.setBillDate(billDate);
					invoiceObj.setDueDate(dueDate);
					invoiceDetailsList.add(invoiceObj);
					System.out.println("Invoice details are:"+invoiceNumber+":"+invoiceAmount+":"+dueDate+":"+dueDate);
				}
				System.out.println("list size"+invoiceDetailsList.size());
			
			}
			
		} catch (SQLException e) {
			e.printStackTrace();

		} finally {

			if (connection != null)
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return invoiceDetailsList;
			}

	/*public boolean isCircleFound(String circle, List<String> circleList) {
		boolean isCircleFound = false;
		
		if (circleList != null) {
			for (int j = 0; j < circleList.size(); j++) {
				if (circleList.get(j) != null
						&& circleList.get(j).toUpperCase()
								.equalsIgnoreCase(circle.toUpperCase())) {
					isCircleFound = true;
				
					break;
					
				}
			}
		}
		return isCircleFound;
	}*/

}
