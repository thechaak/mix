package com.airtel.acecad.util;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class ConnectionUtil{

	private static Logger log = LogManager.getLogger(ConnectionUtil.class);
  public static Connection getConnection() {


	/*try {
		//Class.forName(GenericConfiguration.getDescription("driver_Name"));
		//Class.forName("oracle.jdbc.OracleDriver");
		DriverManager.registerDriver (new oracle.jdbc.OracleDriver());

	} catch (SQLException e) {
		log.info("Class.forName Exception----->",e);

	}
	catch (Exception e) {
		log.info("Class.forName other Exception----->",e);

	}*/

	Connection connection = null;
	String strDbConnection;
	String strDbUser;
	String strDbPwd;

	try {
		strDbConnection= GenericConfiguration.getDescription("db_connection_url");
		log.info("DBURL in OracleJDBC--->>"+strDbConnection);
		strDbUser= GenericConfiguration.getDescription("db_user");
		strDbPwd= GenericConfiguration.getDescription("db_pwd");
		
		connection = DriverManager.getConnection(
				"jdbc:oracle:thin:@"+strDbConnection, strDbUser,
				strDbPwd);
		log.info("connection in OracleJDBC--->>"+connection);	

	} catch (SQLException e) {

		log.info("Connection Failed! Check output console----->",e);
	}
	return connection;
  }

}
