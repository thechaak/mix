package com.airtel.acecad.util;

public interface GlobalConstants {

	String ACECAD_DB_URL = "CADTEST.ACECAD.dbUrl";
	String APSST_DB_URL = "APSST.TESTCAD.dbUrl";
	String APSSIT_DB_URL = "APSSIT.TESTCAD.dbUrl";

	String TRUE_APS = "TRUE";
	String APS_FLAG = "APS";

	// Added by geeta for Tanu

	String STR_CHEQUE = "CHEQUE";
	String STR_NEFT = "NEFT";
	String STR_OTHERS = "OTHERS";
	String PAYMENT = "PAYMENT";
	String STAGING ="STAGING";
	String TABLE_CUST_PAYMENT_DETAILS_APS = "CUST_PAYMENT_DETAILS_APS";
	
	String STR_INT313 = "INT313";
	String STR_INT315 = "INT315";
	
	String TABLE_CUST_PAYMENT_DETAILS_REVERSAL_APS = "REVERSAL";
	String TABLE_CUST_PAYMENT_DETAILS_REV_APS = "REV";

	String INT_219_PASSED="INT_219_PASSED";
	String EMPTY_STRING = "";
	String FX_DOWN_OR_EXCEPTION_IN_INT632 = "FX_DOWN_OR_EXCEPTION_IN_INT632";
	String CURRENCY = "INR";
	String CURRENCY_CODE = "1";
	String RESULT_DB_SUCCESFUL = "UPDATED";
	String RESULT_DB_FAILURE = "NOT UPDATED";
	String BILLABLE = "BILLABLE";
	String MOBILE_NUM_TYPE = "11";

	String LOG_PATH = "/home/ACECAD/ServiceClientLogs";
	String STATUS_CODE = "0000";
	String STATUS_CODE_S = "0000";
	String STATUS_CODE_HTTP = "200";

	// Added by geeta for deposit
	int EMPTY_VALUE = 0;
	int DEPOSIT_STATUS_CODE = 0;
	int DEPOSIT_ERROR_CODE = -1;
	String LOB = "Mobility";
	String DEPOSIT_TYPE = "1";
	String CHEQUE = "P";
	String CASH = "M";
	String DEPOSIT_CONSUMER_NAME = "APS";
	String T = "T";
	String MSISDN = "MSISDN";

	String NRC_CONSUMER_NAME = "APS";
	String OPERATION_TYPE_CREATENRC = "NRCFAILEDPAYMENT";
	String OPERATION_TYPE_DELETENRC = "DELETENRC";
	String SUBLOB = "Postpaid";
	String REFUND_CONSUMER_NAME = "APS";
	String OPERATION_TYPE1 = "RefundCreate";
	String OPERATION_TYPE2 = "DepositRefund";
	// String CURRENCYCODE_INR="INR";
	String INR = "1";

	// added by Ajit all File Identifiers for table_name
	String TRUE = "true";
	String FALSE = "false";
	String APS = "APS";
	String CAD = "CAD";
	String FILE_IDENTIFIER_DPP = "DPP";
	String FILE_IDENTIFIER_RDP = "RDP";
	String FILE_IDENTIFIER_CNR = "CNR";
	String FILE_IDENTIFIER_SNR = "SNR";
	String FILE_IDENTIFIER_DNR = "DNR";
	String FILE_IDENTIFIER_ADJ = "ADJ";
	String FILE_IDENTIFIER_RDJ = "RDJ";
	String FILE_IDENTIFIER_REF = "REF";

	String REVERSAL = "REVERSAL";
	String REV = "REV";
	String FAILED_IN_PAYMENT_HISTORY = "FAILED IN PAYMENT HISTORY";
	String APP = "APP";
	String PAYMENTTRANSFER = "PT";
	String B2B = "B2B";

	String SIEBEL_CALLBACK = "SIEBEL_CALLBACK";
	String AIRTL_CHQ_BOUNCE_NRC_RECORDS = "AIRTL_CHQ_BOUNCE_NRC_RECORDS";
	String OUTST = "OUTST";
	String NRC_APS = "NRC_APS";
	String INTERIM = "INTERIM";

	// Added by geeta for adjustment
	String ADJ_CREATE_CONSUMER_NAME = "APS";
	String ADJ_TYPE_CREATE = "Create";
	String ADJ_TYPE_CANCEL = "Cancel";
	String TRANS_SIGN_CREDIT = "-1";
	String TRANS_SIGN_DEBIT = "1";
	String REV_REV_COSTCENTER = "1";

	String SUCCESS = "SUCCESS";
	String FAILURE = "FAILURE";

	String ACC_EXT_ID_TYPE = "1";

	// For Refund

	String REFUND_TYPE_CHEQUE = "CHEQUE";
	String REFUND_CHEQUE = "1";
	String REFUND_TYPE_CREDIT_CARD = "CREDIT_CARD";
	String REFUND_CREDIT_CARD = "2";
	String REFUND_TYPE_EFT = "EFT";
	//String REFUND_EFT = "3";  changed on 2-AUG-2017(bhupesh asked to chnage)
	String REFUND_EFT = "1";


	int REFUND_INITIAL_STATUS_CODE = 5;

	// For WEB servie intial status for posting to fx
	int INITIAL_STATUS_CODE_POSTFX = 6;
	int INITIAL_STATUS_CODE_CHEUQE = 0;
	int SUCCESS_STATUS_CODE_CHEUQE = 1;

	// FOR int_366_1
	// int INITIAL_STATUS_CODE_SIEBEL=6,-6,-7;
	//String INITIAL_STATUS_CODE_SIEBEL = "(6,-6,-7,-11,-9,-3,-4,10)";
    String INITIAL_STATUS_CODE_SIEBEL = "(6,-6,-7,-11,10)";
	int SUCCESS_STATUS_CODE_SIEBEL = 0;
	//int FAILURE_STATUS_CODE_SIEBEL = -10;
	int FAILURE_STATUS_CODE_SIEBEL = -1;

	// FOR INT_632
	int CUSTACCSUMM_INITIAL_CODE = 5;
	int CUSTACCSUMM_ERROR_CODE = -4;

	//// FOR int_226_F
	String OPRERATION_TYPE_NOTES = "NOTES";
	String BUSSINESS_INTERACTION_IDTYPE_SR = "SR";
	String APS_SYSTEMID = "APS";

	String UPDATE_NOTES_STATUS_CODE = "(5,-5)";
	int VALID_INITIAL_STATUS_CODE = 5;
	int INVALID_INITIAL_STATUS_CODE = -5;
	int VALID_SUCCESS_STATUS_CODE = 20;
	int VALID_FAILURE_STATUS_CODE = -20;
	int INVALID_SUCCESS_STATUS_CODE = -6;
	int INVALID_FAILURE_STATUS_CODE = -11;

	// FOR ECS-DE-REGISTERATION(ADDED BY GEETA)
	int INITIAL_STATUS_CODE = 1;
	String ECS_DE_REGISTERATION = "ECS De-Registration";
	String ECS_CHARGING = "ECS Charging";
	String MT_STATUS_IN_PROGRESS = "In Progress";

	/*
	 * String RESULT_DB_SUCCESFUL="SUCCESS"; String RESULT_DB_FAILURE="FAILURE";
	 */
	String SMS_SENT = "SMS_SENT";
	String SMS_SENDING_FAILED = "SMS_SENDING_FAILED";
	String SMS_SUCCESS = "success";

	String AIRTL_CUST_PAYMENT_DETAILS = "AIRTL_CUST_PAYMENT_DETAILS";

	String CONNECT_TEXT = "connect timed out";
	String READ_TEXT = "Read timed out";

	String SR_DETAILS_APS = "SR_DETAILS_APS";

	String status_code_504 = "504";
	String status_code_502 = "502";
	String status_code_400 = "400";
	String status_code_500 = "500";
	String status_code_409 = "409";

	String AIRTL_EPP_VENDOR_FILES_RECORDS = "AIRTL_EPP_VENDOR_FILES_RECORDS";
	String REFUND_PAYMENT_APS = "REFUND_PAYMENT_APS";

	String CANNOT_CONNECT_WITH_ESB = "CANNOT CONNECT WITH ESB%";
	String CANNOT_CONNECT_WITH_ESB_IN_INT632 = "CANNOT CONNECT WITH ESB IN INT632";
	String CANNOT_GET_RESPONSE_FROM_ESB_IN_INT632 = "CANNOT GET RESPONSE FROM ESB IN INT632";

	String INT_632 = "INT_632";
	String INT_219 = "INT_219";
	
	//added for NDS
	String CONTEXT_PATH = "nds.client";
	String LINE_OF_BUSINESS = "mobility";
	String LOB_MOB="mobility";
	String LOB_TELEMEDIA="dsl";
	String SERVICE_REQUESTER = "AccountMigration";
	String SERVICE_REQUESTER_MSISDN = "SIMigration";
	String ERROR_CODE_SUCCESS = "000";
	String ERROR_MESSAGE_SUCCESS = "SUCCESS";
	String BHARTI_MIGRATION_STATUS = "bharti-migrationStatus";
	String ANCHOR_SERVICE_REQUESTER = "HomesAccount";
	String ANCHOR_CONTEXT_PATH = "anchor.client";
	String BHARTI_ANCHOR = "bharti-anchor";
	String BHARTI_PROSPECT = "bharti-prospect";

	//For ECS 313 new tag operationtype 
    String ECS_UPDATE="ECS_UPDATE";
	
	
}
