package com.airtel.acecad.util;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.concurrent.Callable;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;



public class OptimusClientThread implements Callable<String>{

	private static Logger log = LogManager.getLogger(OptimusClientThread.class);

	private String accountNumber;
	private String multi_Service;
	private String msisdn;

	private String lob;
	private int job_id;

	String CONNECT_TEXT = "connect timed out";
	String READ_TEXT = "Read timed out";

	/**
	 * Constructor
	 * 
	 * @param accountNumber
	 * @param apsFlag
	 * @param multi_Service
	 */
	public OptimusClientThread(String accountNumber, String msisdn, String multi_Service,
			String lob,int job_id) {

		//log.info("START----in AccountDetailsClientThread method constructor counter->>"+counter);

		this.accountNumber = accountNumber;

		this.multi_Service = multi_Service;
		this.msisdn = msisdn;

		this.lob = lob;
		this.job_id=job_id;

		//log.info("END----in AccountDetailsClientThread method constructor ");
	}


	public String call() {
		try {

			//OptimusClient OptimusClient =new OptimusClient();
			OptimusDetailsDto optimusDetails=null;
			//If Lob is null
			if(CommonValidator.isNull(lob)){
				
				lob="Mobility";
				//optimusDetails=OptimusClient.postOptimusToFX(lob, accountNumber,msisdn);

				if(!"Success".equalsIgnoreCase(optimusDetails.getResponseMsg())){

					lob="Telemedia";//FL
				//	optimusDetails=OptimusClient.postOptimusToFX(lob, accountNumber,msisdn);
				}
			}
			else
			{
				if("mob".equalsIgnoreCase(lob)){
					lob="Mobility";
				}
				if("fl".equalsIgnoreCase(lob)){
					lob="Telemedia";
				}
				//optimusDetails=OptimusClient.postOptimusToFX(lob, accountNumber,msisdn);
			}

			updateOptimusResponse(accountNumber, lob, multi_Service,
					optimusDetails.getAnchor(), optimusDetails.getResponseMsg(),optimusDetails.getApsFlag());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}


	public String updateOptimusResponse(String accountId, String lob, String fileIdentifier, String homesId,
			String homesIdDesc,String apsFlag) throws Exception {

		log.info("homesId in updateHomeIdDetails----->>>" + homesId + "AND accountId-->" + accountId + " and"
				+ " fileIdentifier--->>" + fileIdentifier + " and homesIdDesc--->>" + homesIdDesc);


		String result = null;
		String sql = null;
		int resultSet = 0;	
		Connection con = null;
		CallableStatement callableStatement = null;
		String RESULT_DB_SUCCESFUL = "UPDATED";
		String RESULT_DB_FAILURE = "NOT UPDATED";

		if("Success".equalsIgnoreCase(homesIdDesc)){
			homesIdDesc=null;
		}
		sql = "{call AIRTL_OPTIMUS_PAYMENT_PKG.updateOptimusResponseDetails(?,?,?,?,?,?,?)}";

		try {
			con = ConnectionUtil.getConnection();
			log.info("connection formed in updateHomeIdDetails--------->" + con);

		} catch (Exception e) {

			log.info("Connection not established in updateHomeIdDetails ", e);
		}
		if (con != null) {
			log.info("query of updateHomeIdDetails---" + sql);
			try {
				con.setAutoCommit(false);
				callableStatement = con.prepareCall(sql);
				callableStatement.setString(1, accountId);
				callableStatement.setString(2, msisdn);
				callableStatement.setString(3, multi_Service);
				callableStatement.setString(4, homesIdDesc);
				callableStatement.setString(5, apsFlag);

				if("mobility".equalsIgnoreCase(lob)){
					lob="MOB";
				}
				else if("telemedia".equalsIgnoreCase(lob)){
					lob="BTS";
				}
				callableStatement.setString(6, lob);
				if(CommonValidator.isNull(homesId)){
					homesId="NA";
				}
				callableStatement.setString(7, homesId);


				//callableStatement.registerOutParameter(6, Types.VARCHAR);
				resultSet = callableStatement.executeUpdate();
				//result = callableStatement.getString(6);
				try {
					if (resultSet > 0) {
						result = RESULT_DB_SUCCESFUL;
					} else {
						result = RESULT_DB_FAILURE;
					}
				} catch (Exception e) {
					log.info("Query execution updateHomeIdDetails---->", e);
				} finally {
					if (con != null) {
						try {
							con.commit();
							callableStatement.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in updateHomeIdDetails ---", e);
						}
					}

				}
			} catch (Exception e) {

				log.info("Exception in updateHomeIdDetails-->", e);
			}

		}
		log.info("END--in updateHomeIdDetails in ClientDAOImpl result --->" + result);
		return result;

	}
}
