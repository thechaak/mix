package com.airtel.acecad.json.optimusJson;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
    "requestId",
    "uri"
})
public class Params {
	@JsonProperty("requestId")
	private String requestId;
	@JsonProperty("uri")
	private String uri;
	
	@JsonProperty("requestId")
	public String getRequestId() {
		return requestId;
	}
	
	@JsonProperty("requestId")
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	
	@JsonProperty("uri")
	public String getUri() {
		return uri;
	}
	
	@JsonProperty("uri")
	public void setUri(String uri) {
		this.uri = uri;
	}
	
	

}
