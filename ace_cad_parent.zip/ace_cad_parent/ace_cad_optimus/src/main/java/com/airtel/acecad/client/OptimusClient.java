package com.airtel.acecad.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.airtel.acecad.dao.OptimusDAO;
import com.airtel.acecad.daoImpl.OptimusDAOImpl;
import com.airtel.acecad.json.optimusJson.Customer;
import com.airtel.acecad.json.optimusJson.CustomerService;
import com.airtel.acecad.json.optimusJson.OptimusClientResponse;
import com.airtel.acecad.json.optimusJson.OptimusCustomerResponse;
import com.airtel.acecad.json.optimusJson.Service;
import com.airtel.acecad.util.CommonValidator;
import com.airtel.acecad.util.CustomResponseErrorHandler;
import com.airtel.acecad.util.GenericConfiguration;
import com.airtel.acecad.util.GlobalConstants;
import com.airtel.acecad.util.OptimusDetailsDto;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


public class OptimusClient implements GlobalConstants{
	private static Logger logger = LogManager.getLogger("serviceClientUI");
	private static final ObjectMapper mapper = new ObjectMapper();

	public OptimusDetailsDto postOptimusToFX(String lob, String accNo,String delNo,int productTypeStatus){
				logger.info("Start :postOptimusToFX in CustomerAccountSummaryClient"+"lob===>"+lob+"accNo====>"+accNo+"delNo====>"+delNo);

		String status_code = EMPTY_STRING;
		String message = EMPTY_STRING;
		OptimusDetailsDto optimusDto = new OptimusDetailsDto();
		RestTemplate restTemplate = new RestTemplate();
		String clientURL =null;
		String apiFlag ="";

		try {

			if(CommonValidator.isNull(accNo)){
				logger.info("IN IF BLOCK"+"lob===>"+lob+"accNo====>"+accNo+"delNo====>"+delNo);

				apiFlag="msisdn";
				clientURL = "https://qaoptimus.airtel.com/v1/services/";
				String product_code="FLVOICE";
				if(productTypeStatus==0){
					clientURL +="91"+delNo;//+"?lineOfBusiness="+lob;
				}
				else if(productTypeStatus==1){
					clientURL += delNo+"?product_code="+product_code;
				}else if(productTypeStatus==2){
				clientURL +=delNo;//+"?product_code="+product_code;
				}
			}
			else{
				logger.info("IN ELSE BLOCK"+"lob===>"+lob+"accNo====>"+accNo+"delNo====>"+delNo);
				apiFlag="accNo";
				clientURL = "https://qaoptimus.airtel.com/v1/customers/"
						+accNo;//+"?lineOfBusiness="+lob;
			}
             logger.info("clientURL======>"+clientURL); 
			//+ customerMigratedFlag+  GenericConfiguration.getDescription("accountId") + bulkDetails.getAcctEXTID();
			restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
			HttpHeaders headers = new HttpHeaders();
			logger.info("client url in postCustomerAccountSummaryToFX-->>>"+clientURL);
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
			.setConnectTimeout(Integer.parseInt(GenericConfiguration.getDescription("connect_time_out")));
			logger.info("111111111111client url in postCustomerAccountSummaryToFX-->>>"+clientURL);
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
			.setReadTimeout(Integer.parseInt(GenericConfiguration.getDescription("read_time_out")));
			logger.info("222222222222222222222 url in postCustomerAccountSummaryToFX-->>>"+clientURL);
			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
			restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
			restTemplate.setErrorHandler(new CustomResponseErrorHandler());

			logger.info("3333333333333333333333 url in postCustomerAccountSummaryToFX-->>>"+clientURL);
			 headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			 //headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));
			 headers.add("subscribercode", "C93776146879200725AB4747D6833D789BD06821346DA3C28B18674E21D5FB6A");
			 HttpEntity<String> entity = new HttpEntity<>(headers);
			 ResponseEntity<OptimusClientResponse> responsePojo = null;
			 ResponseEntity<OptimusCustomerResponse> customerResponse =null;
/*			 javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
					new javax.net.ssl.HostnameVerifier(){

					    public boolean verify(String hostname,
					            javax.net.ssl.SSLSession sslSession) {
					        return hostname.equals("10.5.74.7");
					    }
					});*/
			 logger.info("4444444444444444444 url in postCustomerAccountSummaryToFX-->>>"+clientURL);
			 if(apiFlag.equalsIgnoreCase("msisdn")){
				 
				 responsePojo = restTemplate.exchange(clientURL, HttpMethod.GET, entity, OptimusClientResponse.class);
				 logger.info("responsePojo--->>" + responsePojo.getBody());
				 logger.info("responsePojo OptimusClient postToFx method--->" + mapper.writeValueAsString(responsePojo));
			 }
			 else{
				 logger.info("in else block=======>>>"+accNo+"clientURL=====>>>"+clientURL+"entity======>>"+entity);
				 customerResponse = restTemplate.exchange(clientURL, HttpMethod.GET, entity, OptimusCustomerResponse.class);
				 logger.info("responsePojo--->>" + customerResponse.getBody());
				 logger.info("responsePojo OptimusClient postToFx method--->" + mapper.writeValueAsString(responsePojo));
			 }




			 if (responsePojo != null) {
				 if (HttpStatus.OK == responsePojo.getStatusCode()) {
					 if(responsePojo.getBody().getStatus_info()!=null)
						 status_code = responsePojo.getBody().getStatus_info().getCode();
					 	 message=responsePojo.getBody().getStatus_info().getMessage();
					 logger.info("when response is success Response of Optimus Service status_Code and Message===> "+status_code +"==>"+ responsePojo.getBody().getStatus_info().getMessage());
				 }

				 else {
					 if(responsePojo.getBody().getStatus_info()!=null)
						 status_code = responsePojo.getBody().getStatus_info().getCode();
					 	 message=responsePojo.getBody().getStatus_info().getMessage();
					 logger.info("when response is failed Response of Optimus Service status_Code and Message===> "+status_code +"==>"+ responsePojo.getBody().getStatus_info().getMessage());
				 }
				 logger.info("BEFORE createResponseJSONForPostOptimusToFX ");
				 
				 
				 optimusDto = createResponseJSONForPostOptimusToFX(responsePojo, status_code,clientURL,accNo,delNo,lob);
			 }
			 else if(customerResponse != null){

				 if (HttpStatus.OK == customerResponse.getStatusCode()) {
					 if(customerResponse.getBody().getStatus_info()!=null)
						 status_code = customerResponse.getBody().getStatus_info().getCode();
					 logger.info("when response is success Response of Optimus Service status_Code and Message===> "+status_code +"==>"+ customerResponse.getBody().getStatus_info().getMessage());
				 }

				 else {
					 if(customerResponse.getBody().getStatus_info()!=null)
						 status_code = customerResponse.getBody().getStatus_info().getCode();
					 logger.info("when response is failed Response of Optimus Service status_Code and Message===> "+status_code +"==>"+ customerResponse.getBody().getStatus_info().getMessage());
				 }

				 optimusDto = createResponseJSONForPostOptimusCustomerToFX(customerResponse, status_code,clientURL,accNo,delNo,lob);
				 logger.info("AFTER createResponseJSONForPostCustAccountSummaryToFX  in postCustAccountSummaryToFX ");
			 }


		} catch (Exception e) {
			logger.info("Got error in the response of FX  pTransactionId postCustomerAccountSummaryToFX-->"
					, e);
			logger.info("Got error in the response 2 of FX  pTransactionId optimus exception-->"
					);
			optimusDto.setErrorMsg(e.getMessage());
			optimusDto.setErrorReasonCode(e.getMessage());
			optimusDto.setErrorCode(e.getMessage());
			optimusDto.setErrorCodeDescription(e.getMessage());
			if (e.getCause()!=null && e.getCause().toString().contains(CONNECT_TEXT)) {
				optimusDto.setErrorMsg(CONNECT_TEXT);
				optimusDto.setErrorReasonCode(CONNECT_TEXT);
				optimusDto.setErrorCode(CONNECT_TEXT);
				optimusDto.setErrorCodeDescription(CONNECT_TEXT);

			}

			if (e.getCause()!=null && e.getCause().toString().contains(READ_TEXT)) {
				optimusDto.setErrorMsg(READ_TEXT);
				optimusDto.setErrorReasonCode(READ_TEXT);
				optimusDto.setErrorCode(READ_TEXT);
				optimusDto.setErrorCodeDescription(READ_TEXT);
				logger.info(
						"Got faulty code from the response READ_TEXT  of FX resultConectRead postCustomerAccountSummaryToFX-----> pTransactionId"
								+ READ_TEXT);

			}
		}

		logger.info("END--->in postOptimusToFX method of CustAccountSummaryClient");


		return optimusDto;
	}

	private OptimusDetailsDto createResponseJSONForPostOptimusToFX(ResponseEntity<OptimusClientResponse> responsePojo,
			String status_code, String clientURL,String accNo,String delNo,String lob) {

		logger.info("Inside createResponseJSONForPostOptimusToFX ====>");
		String statusCode =EMPTY_STRING;
		String message =EMPTY_STRING;
		String requestId =EMPTY_STRING;
		String uri =EMPTY_STRING;
		// String lob= EMPTY_STRING;
		String apsFlag = EMPTY_STRING;
		OptimusDetailsDto optimusDto = new OptimusDetailsDto();
		try {
			if(responsePojo != null){
				logger.info("createResponseJSONForPostOptimusToFX responsePojo is not null line no===>146");
				if(responsePojo.getBody().getStatus_info()!=null){
					if(responsePojo.getBody().getStatus_info().getCode()!=null){
						logger.info("createResponseJSONForPostOptimusToFX Status_info is not null line no===>149");
						statusCode = responsePojo.getBody().getStatus_info().getCode();
						optimusDto.setStatusCode(statusCode);
						logger.info("createResponseJSONForPostOptimusToFX Status_info statusCode===>"+statusCode);
					}
					if(responsePojo.getBody().getStatus_info().getMessage()!=null){
						message = responsePojo.getBody().getStatus_info().getMessage();
						optimusDto.setResponseMsg(message);
						logger.info("createResponseJSONForPostOptimusToFX Status_info statusMessage===>"+message);
					}

				}

				if(responsePojo.getBody().getParams()!=null){
					logger.info("createResponseJSONForPostOptimusToFX Params not null===>163");
					if(responsePojo.getBody().getParams().getRequestId()!=null){
						requestId = responsePojo.getBody().getParams().getRequestId();
						optimusDto.setRequestId(requestId);
						logger.info("createResponseJSONForPostOptimusToFX Params requestId===>"+requestId);
					}

					if(responsePojo.getBody().getParams().getUri()!=null){
						uri =responsePojo.getBody().getParams().getUri();
						optimusDto.setUri(uri);
						logger.info("createResponseJSONForPostOptimusToFX Params uri===>"+uri);
					}
				}

				if(responsePojo.getBody().getServices()!=null){
					ArrayList<Service> serviceList = responsePojo.getBody().getServices();
					for(Service service : serviceList ){
						if(service.getCustAcNo()!=null){
							logger.info("createResponseJSONForPostOptimusToFX Service CustAccNo===>"+service.getCustAcNo());
							optimusDto.setCustAccNo(service.getCustAcNo());
						}
						if(service.getSi()!=null){
							logger.info("createResponseJSONForPostOptimusToFX Service Si===>"+service.getSi());
							optimusDto.setSi(service.getSi());
						}
						if(service.getHomeId()!=null){
							logger.info("createResponseJSONForPostOptimusToFX Service HomeId===>"+service.getHomeId());
							optimusDto.setHomeId(service.getHomeId());
						}
						if(service.getHAnchor()!=null){
							logger.info("createResponseJSONForPostOptimusToFX Service AnchorId===>"+service.getHAnchor());
							optimusDto.setAnchor(service.getHAnchor());
						}
						if(service.getSiLob()!=null){
							logger.info("createResponseJSONForPostOptimusToFX Service Lob===>"+service.getSiLob());
							optimusDto.setSiLob(service.getSiLob());

						}

						if(service.getSiIsBtfly()!=null){
							logger.info("createResponseJSONForPostOptimusToFX Service IsBtfly===>"+service.getSiIsBtfly());
							if(service.getSiIsBtfly().equalsIgnoreCase("0")||service.getSiIsBtfly().equalsIgnoreCase("1")){
								optimusDto.setIsBtfly("Butterfly");
								apsFlag ="APS";
								optimusDto.setApsFlag(apsFlag);
							}
							else if(service.getSiIsBtfly().equalsIgnoreCase("3")){
								optimusDto.setIsBtfly("Hold");
								apsFlag ="Hold";
								optimusDto.setApsFlag(apsFlag);
							}
							else{
								optimusDto.setIsBtfly("Legacy");
								apsFlag ="CAD";
								optimusDto.setApsFlag(apsFlag);
							}
						}
						else{
							optimusDto.setIsBtfly("Legacy");
							apsFlag ="CAD";
							optimusDto.setApsFlag(apsFlag);
						}

					}
				}else{
					optimusDto.setIsBtfly("Legacy");
					apsFlag ="CAD";
					optimusDto.setApsFlag(apsFlag);
				}

				OptimusDAO dao = new OptimusDAOImpl();
				dao.insertOptimusDetails(accNo, delNo, lob, optimusDto);
				dao.insertFxLog(statusCode, accNo, clientURL, mapper.writeValueAsString(responsePojo), lob, apsFlag, "OPTIMUS_INT",null, null, null, null);
			}
		}catch (JsonProcessingException e) {
			logger.error("Exception occuer in createResponseJSONForPostOptimusToFX()===>"+e.getLocalizedMessage());
			e.printStackTrace();
		}

		return optimusDto;
	}


	private OptimusDetailsDto createResponseJSONForPostOptimusCustomerToFX(ResponseEntity<OptimusCustomerResponse> responsePojo,
			String status_code, String clientURL,String accNo,String delNo,String lob) {

		logger.info("Inside createResponseJSONForPostOptimusCustomerToFX ====>");
		String statusCode =EMPTY_STRING;
		String message =EMPTY_STRING;
		String requestId =EMPTY_STRING;
		String uri =EMPTY_STRING;
		// String lob= EMPTY_STRING;
		String apsFlag = EMPTY_STRING;
		OptimusDetailsDto optimusDto = new OptimusDetailsDto();
		try {
			if(responsePojo != null){
				logger.info("createResponseJSONForPostOptimusCustomerToFX responsePojo is not null line no===>146");
				if(responsePojo.getBody().getStatus_info()!=null){
					if(responsePojo.getBody().getStatus_info().getCode()!=null){
						logger.info("createResponseJSONForPostOptimusCustomerToFX Status_info is not null line no===>149");
						statusCode = responsePojo.getBody().getStatus_info().getCode();
						optimusDto.setStatusCode(statusCode);
						logger.info("createResponseJSONForPostOptimusCustomerToFX Status_info statusCode===>"+statusCode);
					}
					if(responsePojo.getBody().getStatus_info().getMessage()!=null){
						message = responsePojo.getBody().getStatus_info().getMessage();
						optimusDto.setResponseMsg(message);
						logger.info("createResponseJSONForPostOptimusCustomerToFX Status_info statusMessage===>"+message);
					}

				}

				if(responsePojo.getBody().getParams()!=null){
					logger.info("createResponseJSONForPostOptimusCustomerToFX Params not null===>163");
					if(responsePojo.getBody().getParams().getRequestId()!=null){
						requestId = responsePojo.getBody().getParams().getRequestId();
						optimusDto.setRequestId(requestId);
						logger.info("createResponseJSONForPostOptimusCustomerToFX Params requestId===>"+requestId);
					}

					if(responsePojo.getBody().getParams().getUri()!=null){
						uri =responsePojo.getBody().getParams().getUri();
						optimusDto.setUri(uri);
						logger.info("createResponseJSONForPostOptimusCustomerToFX Params uri===>"+uri);
					}
				}

				if(responsePojo.getBody().getCustomers()!=null){
					List<Customer> customers = responsePojo.getBody().getCustomers();

					for(Customer customer :customers){
						if(!CommonValidator.isNull(customer.getCust_ac_no())){
							logger.info("createResponseJSONForPostOptimusCustomerToFX Service CustAccNo===>"+customer.getCust_ac_no());
							optimusDto.setCustAccNo(customer.getCust_ac_no());
						}

						if(!CommonValidator.isNull(customer.getFname())){
							logger.info("createResponseJSONForPostOptimusCustomerToFX Service fName===>"+customer.getFname());
							//optimusDto.setCustAccNo(customer.getCustAcNo());
						}
						if(!CommonValidator.isNull(customer.getmName())){
							logger.info("createResponseJSONForPostOptimusCustomerToFX Service mName===>"+customer.getmName());
							//optimusDto.setCustAccNo(customer.getCustAcNo());
						}
						if(!CommonValidator.isNull(customer.getLname())){
							logger.info("createResponseJSONForPostOptimusCustomerToFX Service Lname===>"+customer.getLname());
							//optimusDto.setCustAccNo(customer.getCustAcNo());
						}
						if(!CommonValidator.isNull(customer.getCust_class())){
							logger.info("createResponseJSONForPostOptimusCustomerToFX Service CustClass===>"+customer.getCust_class());
							//optimusDto.setCustAccNo(customer.getCustAcNo());
						}
						if(!CommonValidator.isNull(customer.getProd_type())){
							logger.info("createResponseJSONForPostOptimusCustomerToFX Service ProdType===>"+customer.getProd_type());
							//optimusDto.setCustAccNo(customer.getCustAcNo());
						}

						if(!CommonValidator.isNull(customer.getPref_comm_lang())){
							logger.info("createResponseJSONForPostOptimusCustomerToFX Service PrefCommLang===>"+customer.getPref_comm_lang());
							//optimusDto.setCustAccNo(customer.getCustAcNo());
						}

						if(!CommonValidator.isNull(customer.getAcc_is_btfly())){
							logger.info("createResponseJSONForPostOptimusCustomerToFX Service getAcc_is_btfly===>"+customer.getAcc_is_btfly());
							if(customer.getAcc_is_btfly().equalsIgnoreCase("0")||customer.getAcc_is_btfly().equalsIgnoreCase("1")){
								optimusDto.setIsBtfly("Butterfly");
								apsFlag ="APS";
								optimusDto.setApsFlag(apsFlag);
							}
							else if(customer.getAcc_is_btfly().equalsIgnoreCase("3")){
								optimusDto.setIsBtfly("Hold");
								apsFlag ="Hold";
								optimusDto.setApsFlag(apsFlag);
							}
							else{
								optimusDto.setIsBtfly("Legacy");
								apsFlag ="CAD";
								optimusDto.setApsFlag(apsFlag);
							}
						}
						else{
							optimusDto.setIsBtfly("Legacy");
							apsFlag ="CAD";
							optimusDto.setApsFlag(apsFlag);
						}

						logger.info("createResponseJSONForPostOptimusCustomerToFX Service aqps flag===>"+optimusDto.getApsFlag());

						if(customer.getServices()!=null){
							List<CustomerService> serviceList = customer.getServices();
							for(CustomerService service : serviceList ){

								if(service.getSi()!=null){
									logger.info("createResponseJSONForPostOptimusCustomerToFX Service Si===>"+service.getSi());
									optimusDto.setSi(service.getSi());
								}
								if(service.getImei()!=null){
									logger.info("createResponseJSONForPostOptimusCustomerToFX Service Imei===>"+service.getImei());
									//optimusDto.setHomeId(service.getImei());
								}
								if(service.getSi_sts()!=null){
									logger.info("createResponseJSONForPostOptimusCustomerToFX Service Si_sts===>"+service.getSi_sts());
									//optimusDto.setAnchor(service.getSi_sts());
								}
								if(service.getVasdnd()!=null){
									logger.info("createResponseJSONForPostOptimusCustomerToFX Service Vasdnd===>"+service.getVasdnd());
									//optimusDto.setSiLob(service.getVasdnd());

								}
								if(service.getSi_lob()!=null){
									logger.info("createResponseJSONForPostOptimusCustomerToFX Service Si_Lob===>"+service.getSi_lob());
									optimusDto.setSiLob(service.getSi_lob());

								}
								if(service.getH_anchor()!=null){
									logger.info("createResponseJSONForPostOptimusCustomerToFX Service Anchor Id===>"+service.getH_anchor());
									optimusDto.setAnchor(service.getH_anchor());

								}

								if(service.getHome_id()!=null){
									logger.info("createResponseJSONForPostOptimusCustomerToFX Service HomeId===>"+service.getHome_id());
									optimusDto.setHomeId(service.getHome_id());

								}
								if(service.getSi_is_btfly()!=null){
									logger.info("createResponseJSONForPostOptimusCustomerToFX Service IsBtfly===>"+service.getSi_is_btfly());
								}

									
						if(service.getSi_is_btfly()!=null){
							logger.info("createResponseJSONForPostOptimusCustomerToFX Service IsBtfly===>"+service.getSi_is_btfly());
							if(service.getSi_is_btfly().equalsIgnoreCase("0")
									||service.getSi_is_btfly().equalsIgnoreCase("1")){
								optimusDto.setIsBtfly("Butterfly");
								apsFlag ="APS";
								optimusDto.setApsFlag(apsFlag);
							}
							else if(service.getSi_is_btfly().equalsIgnoreCase("3")){
								optimusDto.setIsBtfly("Hold");
								apsFlag ="Hold";
								optimusDto.setApsFlag(apsFlag);
							}
							else{
								optimusDto.setIsBtfly("Legacy");
								apsFlag ="CAD";
								optimusDto.setApsFlag(apsFlag);
								}
						}
						else{
							optimusDto.setIsBtfly("Legacy");
							apsFlag ="CAD";
							optimusDto.setApsFlag(apsFlag);
						}

							}
						}

					}
					
				}else{
					optimusDto.setIsBtfly("Legacy");
					apsFlag ="CAD";
					optimusDto.setApsFlag(apsFlag);
				}
				logger.info("aps flag aftre call->>"+optimusDto.getApsFlag());
				OptimusDAO dao = new OptimusDAOImpl();
				dao.insertOptimusDetails(accNo, delNo, lob, optimusDto);
				dao.insertFxLog(statusCode, accNo, clientURL, mapper.writeValueAsString(responsePojo), lob, apsFlag, "OPTIMUS_INT_CUST",null, null, null, null);
			}
		}catch (JsonProcessingException e) {
			logger.error("Exception occuer in createResponseJSONForPostOptimusCustomerToFX()===>"+e.getLocalizedMessage());
			e.printStackTrace();
		}

		return optimusDto;
	}


	public static void main(String[] args) {
		new OptimusClient().postOptimusToFX("Mobility", "1083949797",null,0);
	}

}
