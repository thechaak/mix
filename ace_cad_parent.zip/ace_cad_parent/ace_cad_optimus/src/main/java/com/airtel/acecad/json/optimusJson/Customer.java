package com.airtel.acecad.json.optimusJson;

import java.util.ArrayList;
import java.util.List;


public class Customer {
	 private String mName;
	 private List<CustomerService> services;

	    private String cust_class;

	    private String lname;

	    private String pref_comm_lang;

	    private String prod_type;

	    private String cust_ac_no;

	    private String fname;
	    private String acc_is_btfly;

	    
		public String getAcc_is_btfly() {
			return acc_is_btfly;
		}

		public void setAcc_is_btfly(String acc_is_btfly) {
			this.acc_is_btfly = acc_is_btfly;
		}

		public String getmName() {
			return mName;
		}

		public void setmName(String mName) {
			this.mName = mName;
		}

		public List<CustomerService> getServices() {
			return services;
		}

		public void setServices(List<CustomerService> services) {
			this.services = services;
		}

		public String getCust_class() {
			return cust_class;
		}

		public void setCust_class(String cust_class) {
			this.cust_class = cust_class;
		}

		public String getLname() {
			return lname;
		}

		public void setLname(String lname) {
			this.lname = lname;
		}

		public String getPref_comm_lang() {
			return pref_comm_lang;
		}

		public void setPref_comm_lang(String pref_comm_lang) {
			this.pref_comm_lang = pref_comm_lang;
		}

		public String getProd_type() {
			return prod_type;
		}

		public void setProd_type(String prod_type) {
			this.prod_type = prod_type;
		}

		public String getCust_ac_no() {
			return cust_ac_no;
		}

		public void setCust_ac_no(String cust_ac_no) {
			this.cust_ac_no = cust_ac_no;
		}

		public String getFname() {
			return fname;
		}

		public void setFname(String fname) {
			this.fname = fname;
		}

	
}
