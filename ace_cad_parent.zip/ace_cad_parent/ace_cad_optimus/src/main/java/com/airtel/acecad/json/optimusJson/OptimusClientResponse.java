package com.airtel.acecad.json.optimusJson;


import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "status_info",
    "params",
    "services"
})
public class OptimusClientResponse {

	  @JsonProperty("status_info")
	  private StatusInfo status_info;
	  @JsonProperty("params")
	  private Params params;
	  @JsonProperty("services")
	  private ArrayList<Service> services;
	  
	@JsonProperty("status_info")
	public StatusInfo getStatus_info() {
		return status_info;
	}
	  
	@JsonProperty("status_info")
	public void setStatus_info(StatusInfo status_info) {
		this.status_info = status_info;
	}
	  
	@JsonProperty("params")
	public Params getParams() {
		return params;
	}
	  
	@JsonProperty("params")
	public void setParams(Params params) {
		this.params = params;
	}
	  
	@JsonProperty("services")
	public ArrayList<Service> getServices() {
		return services;
	}
	  
	@JsonProperty("services")
	public void setServices(ArrayList<Service> services) {
		this.services = services;
	}
	  
	  
	 
	}

