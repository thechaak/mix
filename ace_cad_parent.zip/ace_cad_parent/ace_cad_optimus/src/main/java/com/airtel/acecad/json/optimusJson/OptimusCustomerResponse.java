package com.airtel.acecad.json.optimusJson;

import java.util.List;

public class OptimusCustomerResponse {

	 private StatusInfo status_info;
	    private Params params;
	    private List<Customer> customers;
		public StatusInfo getStatus_info() {
			return status_info;
		}
		public void setStatus_info(StatusInfo status_info) {
			this.status_info = status_info;
		}
		public Params getParams() {
			return params;
		}
		public void setParams(Params params) {
			this.params = params;
		}
		public List<Customer> getCustomers() {
			return customers;
		}
		public void setCustomers(List<Customer> customers) {
			this.customers = customers;
		}
	    
}
