package com.airtel.acecad.dao;

import com.airtel.acecad.util.OptimusDetailsDto;

public interface OptimusDAO {
	public void updateAPSFlag(String jobId, String level, String optimusThread) ;
	
 	public String insertFxLog(String statusCode,String trxnId,
			String reqJson,String respJson,String lob,String apsFlag,
			String identifier,String array1,String array2,String dataSet1,String dataSet2);
 	public void insertOptimusDetails(String accountNo, 
 			String msisdnVal,String lob,OptimusDetailsDto optimusDetails);

	
}
