package com.airtel.acecad.client;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.airtel.acecad.dao.OptimusDAO;
import com.airtel.acecad.daoImpl.OptimusDAOImpl;
import com.airtel.acecad.util.GenericConfiguration;

public class MainMethodCall {

	private static Logger log = Logger.getLogger(MainMethodCall.class);
	static Properties props = null;
	
		// To Dynamically load the log file from single property file through cron
		static {
			try {
				props = new Properties();
				InputStream inStream = MainMethodCall.class.getResourceAsStream("/log4j.properties");

				(props).load(inStream);
				inStream.close();
			} catch (IOException e) {
			}
			  //System.out.println("homePath===>"+homePath);
			 props.setProperty("log4j.appender.file.File", GenericConfiguration.getDescription("optimusLogFilePath")); 
			 props.setProperty("log4j.appender.file.FilePattern", GenericConfiguration.getDescription("optimusLogFilePathPattern")); 
			  
			//  props.setProperty("log4j.appender.file.File", "D:/Geeta/APS_bulk.log");  
			  System.out.println("Logs Path===>"+props.getProperty("log4j.appender.file.File"));
			   // LogManager.resetConfiguration();
			    PropertyConfigurator.configure(props);
		}
	
	
	public static void main(String[] args) {

		log.info("START----in main method of MainAccountDetailClient");
		String jobId="123426";
		String level="1";
		String fxThread=null;
		String siebelThread="10";
		
		OptimusDAO optimusDAO = new OptimusDAOImpl();
		//clientDAO.updateAPSFlag(jobId,level,fxThread,siebelThread);
		optimusDAO.updateAPSFlag(args[0],args[1],args[2]);//NEEDS TO BE PASSED ARGUMENTS

		log.info("END----in main method of MainAccountDetailClient");
	}
	
}
