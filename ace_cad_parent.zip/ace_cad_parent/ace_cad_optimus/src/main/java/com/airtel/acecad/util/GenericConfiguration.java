package com.airtel.acecad.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class GenericConfiguration {
	private static Logger log = Logger.getLogger(GenericConfiguration.class);
	static Properties propsPath = null;
    //Uncomment below while compiling for GUI service client
	//static String propertyFilePath = System.getenv("GENERIC_PROPERTIES_HOME");
	//Uncomment while compiling for UNIX service client and path should be Environment specific
	//static String propertyFilePath = "/apsst/APS_DIR/Generic_APS_Properties";
	 //static String propertyFilePath = "/apssit/APS_DIR/Generic_APS_Properties";
	//Prod
	//static String propertyFilePath = "/apsprod/APS_DIR/Generic_APS_Properties";
	//--local
	static String propertyFilePath = "Y://apsst//APS_DIR//Generic_APS_Properties";
	//MAT
	//static String propertyFilePath = "/weblogic/APS_DIR/Generic_APS_Properties";
	//PT
	//static String propertyFilePath = "/weblogic/app/APS_DIR/Generic_APS_Properties";

								  
	static File propFile = new File(propertyFilePath + File.separator + "Conf" + File.separator + "generic.properties");

	static {
		try {
			propsPath = new Properties();
			log.info("propertyFilePath============>"+propertyFilePath);
			InputStream inStream = new FileInputStream(propFile);

			(propsPath).load(inStream);
		} catch (IOException e) {
		}
	}

	public static String getDescription(String filePath) {

		return propsPath.getProperty(filePath);
	}

}
