package com.airtel.acecad.json.optimusJson;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
    "si",
    "cust_ac_no",
    "home_id",
    "h_anchor",
    "si_lob",
    "si_is_btfly"
   /* "devices",*/
})
public class Service {

	  @JsonProperty("si")
	  private String si;
	  
	  @JsonProperty("cust_ac_no")
	  private String custAcNo;
	  
	  @JsonProperty("home_id")
	  private String homeId;
	  
	  @JsonProperty("h_anchor")
	  private String hAnchor;
	    
	  @JsonProperty("si_lob")
	  private String siLob;
	  
	  @JsonProperty("si_is_btfly")
	  private String siIsBtfly;
	  
	/*  @JsonProperty("devices")
	  private Devices devices;*/

	@JsonProperty("si")
	public String getSi() {
		return si;
	}

	@JsonProperty("si")
	public void setSi(String si) {
		this.si = si;
	}

	@JsonProperty("cust_ac_no")
	public String getCustAcNo() {
		return custAcNo;
	}

	@JsonProperty("cust_ac_no")
	public void setCustAcNo(String cust_ac_no) {
		this.custAcNo = cust_ac_no;
	}

	@JsonProperty("home_id")
	public String getHomeId() {
		return homeId;
	}

	@JsonProperty("home_id")
	public void setHomeId(String home_id) {
		this.homeId = home_id;
	}

	@JsonProperty("h_anchor")
	public String getHAnchor() {
		return hAnchor;
	}

	@JsonProperty("h_anchor")
	public void setHAnchor(String h_anchor) {
		this.hAnchor = h_anchor;
	}

	@JsonProperty("si_lob")
	public String getSiLob() {
		return siLob;
	}

	@JsonProperty("si_lob")
	public void setSiLob(String si_lob) {
		this.siLob = si_lob;
	}

	@JsonProperty("si_is_btfly")
	public String getSiIsBtfly() {
		return siIsBtfly;
	}

	@JsonProperty("si_is_btfly")
	public void setSiIsBtfly(String si_is_btfly) {
		this.siIsBtfly = si_is_btfly;
	}

	/*@JsonProperty("devices")
	public Devices getDevices() {
		return devices;
	}

	@JsonProperty("devices")
	public void setDevices(Devices devices) {
		this.devices = devices;
	}
	  
	  
*/
	 
}
