package com.airtel.acecad.json.optimusJson;

import java.util.List;

public class CustomerService {

	private String vasdnd;

    private List<String> ndnc;

    private String act_date;

    private String imei;

    private String si_lob;

    //private Devices devices;

    private String si_sts;

    private String si;
	private String si_is_btfly ;
	private String home_id;
	private String h_anchor;
	
	public String getHome_id() {
		return home_id;
	}
	public void setHome_id(String home_id) {
		this.home_id = home_id;
	}
	public String getH_anchor() {
		return h_anchor;
	}
	public void setH_anchor(String h_anchor) {
		this.h_anchor = h_anchor;
	}
	public String getVasdnd() {
		return vasdnd;
	}
	public void setVasdnd(String vasdnd) {
		this.vasdnd = vasdnd;
	}
	public List<String> getNdnc() {
		return ndnc;
	}
	public void setNdnc(List<String> ndnc) {
		this.ndnc = ndnc;
	}
	public String getAct_date() {
		return act_date;
	}
	public void setAct_date(String act_date) {
		this.act_date = act_date;
	}
	public String getImei() {
		return imei;
	}
	public void setImei(String imei) {
		this.imei = imei;
	}
	public String getSi_lob() {
		return si_lob;
	}
	public void setSi_lob(String si_lob) {
		this.si_lob = si_lob;
	}
	
	public String getSi_sts() {
		return si_sts;
	}
	public void setSi_sts(String si_sts) {
		this.si_sts = si_sts;
	}
	public String getSi() {
		return si;
	}
	public void setSi(String si) {
		this.si = si;
	}
	public String getSi_is_btfly() {
		return si_is_btfly;
	}
	public void setSi_is_btfly(String si_is_btfly) {
		this.si_is_btfly = si_is_btfly;
	}
	

}
