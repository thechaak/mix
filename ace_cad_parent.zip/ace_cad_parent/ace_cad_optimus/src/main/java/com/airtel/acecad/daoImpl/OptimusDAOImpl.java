package com.airtel.acecad.daoImpl;


import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.airtel.acecad.dao.OptimusDAO;
import com.airtel.acecad.util.CommonValidator;
import com.airtel.acecad.util.ConnectionUtil;
import com.airtel.acecad.util.GlobalConstants;
import com.airtel.acecad.util.OptimusClientThread;
import com.airtel.acecad.util.OptimusDetailsDto;

import oracle.sql.ARRAY;

public class OptimusDAOImpl implements GlobalConstants,OptimusDAO {

	
	private static Logger log = LogManager.getLogger(OptimusDAOImpl.class);
	
	
	
	/**
	 * This method update the APS Flag for different tables in DB.
	 * 
	 * @throws InterruptedException
	 */
	public void updateAPSFlag(String jobId, String level, String optimusThread) {

		log.info("START----in updateAPSFlag method of OptimusDAOImpl");
		List<List> list = null;
		List<List> newList = null;
		ExecutorService execServ = null;
		
		List<Future<String>> futures = null;
		try {
			//Class.forName(GenericConfiguration.getDescription("driver_Name"));
			//Class.forName("oracle.jdbc.OracleDriver");
			DriverManager.registerDriver (new oracle.jdbc.OracleDriver());

		} catch (SQLException e) {
			log.info("Class.forName Exception----->",e);

		}
		catch (Exception e) {
			log.info("Class.forName other Exception----->",e);

		}
				
		try {
			log.info("i_jobId-->" + jobId + " level->" + level + " optimusThread->" + optimusThread );

			// getting fixed thread pool size from System parameters

			if (!CommonValidator.isNull(optimusThread) && !"0".equals(optimusThread)) {

				
				
				if (!CommonValidator.isNull(optimusThread)) {
					execServ = Executors.newFixedThreadPool(Integer.valueOf(optimusThread));
				}
				log.info("optimusThread-->> " + optimusThread );

				List<OptimusClientThread> list1 = new ArrayList<OptimusClientThread>();

				list = new ArrayList<List>();
				// Calling proc and getting result from query
				// changed to test on PT EN
				Object[] obj = getFXPostingAPSDetails(jobId, level, "OPTIMUS");

				list = (List<List>) obj[0];
				String newJobId = (String) obj[1];
				log.info("JOB_ID IS-->> " + newJobId);
				log.info("list IS-->> " + list);

				if (list != null && list.size() > 0) {
					/// adding here
					for (int i = 0; i < list.size(); i++) {

						String account_number = (String) list.get(i).get(0);
						String msisdn = (String) list.get(i).get(1);
						String multiService = (String) list.get(i).get(2);					
						String lob = (String) list.get(i).get(3);

						// deriveApsFlagAndUpdate(apsFlag, account_number,
						// msisdn,multiService);

						OptimusClientThread accountDetailsClientThread = new OptimusClientThread(
								account_number, msisdn, multiService, lob,
								Integer.valueOf(newJobId));
						list1.add(accountDetailsClientThread);

					}
					futures = execServ.invokeAll(list1);
				}

				execServ.shutdown();
				updateOptimusJobsStatus(Integer.valueOf(jobId), level,"OPTIMUS");

				// New Changes added 1 date 03march2017
				
			}
			
			log.info("END----in deriveApsFlagAndUpdate method of OptimusDAOImpl");

		} catch (InterruptedException e) {

			log.info("error-->> ", e);
		}
		log.info("END----in updateAPSFlag method of ClientDAOImpl");
	}

	
	public void updateOptimusJobsStatus(int jobId, String level, String tableType) {

		log.info("tran no in updateJobStatus----->>>" + jobId + " level->" + level + " tableType->" + tableType);
		Connection con = null;
		CallableStatement callableStatement = null;

		
		String sql = null;

		sql = "{call UPDATE_ANCHOR_HOMES_JOBS(?,?,?)}";

		try {

			try {
				con = ConnectionUtil.getConnection();

			} catch (Exception e) {
				log.info("Connection not established in updateJobStatus", e);
			}
			if (con != null) {

				callableStatement = con.prepareCall(sql);

				callableStatement.setInt(1, jobId);
				callableStatement.setString(2, level);
				callableStatement.setString(3, tableType);

				callableStatement.executeUpdate();

			}
		} catch (Exception e) {
			log.info("Exception in updateJobStatus  ", e);
		} finally {

			if (con != null) {
				try {
					callableStatement.close();
					con.close();
				} catch (Exception e) {
					log.info("Exception in the updateJobStatus", e);
				}
			}

		}

	}
	
	/**
	 * Description -
	 * 
	 * @return List of list data from query
	 */
	public Object[] getFXPostingAPSDetails(String jobId, String level, String procType) {
		log.info("start FX_SR_DETAILS_APS job_id->"+jobId);
		Connection conn = null;
		List<List> list = null;
		Object[] obj = null;
		// int jobId = 0;
		final String procedureCall = "{call FX_SR_DETAILS_APS(?,?,?,?,?,?,?,?,?,?,?,?)}";
		try {
			try {
				conn = ConnectionUtil.getConnection();
			} catch (Exception e) {
				// TODO: handle exception
				log.info("callFXPostingAPS connection formation--" + e);
			}

			if (conn != null) {
				try {

					System.out.println("start calling fx posting");
					CallableStatement callableStatement = conn.prepareCall(procedureCall);
					callableStatement.registerOutParameter(1, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(2, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(3, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(4, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(5, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(6, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(7, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(8, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(9, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.setInt(10, Integer.valueOf(jobId));
					callableStatement.setString(11, level);
					callableStatement.setString(12, procType);

					// callableStatement.executeUpdate();
					callableStatement.executeQuery();

					ARRAY array_accountExternalID = (ARRAY) callableStatement.getArray(1);
					ARRAY array_msisdn = (ARRAY) callableStatement.getArray(2);
					ARRAY array_serviceMultiType = (ARRAY) callableStatement.getArray(3);
					
					ARRAY array_lob = (ARRAY) callableStatement.getArray(4);
					// jobId = callableStatement.getInt(7);
					log.info("JOBID-->> " + jobId);
					// System.out.println("array_accountExternalID-->>
					// "+array_accountExternalID.length());
					// log.info("array_accountExternalID-->>
					// "+array_apsFlag.length());
					list = new ArrayList<List>();
					System.out.println("array_serviceMultiType.length()--> " + array_serviceMultiType.length());
					if (array_serviceMultiType != null && array_serviceMultiType.length() > 0) {
						for (int x = 0; x < array_serviceMultiType.length(); x++) {

							List<String> resList = new ArrayList<String>();
							String[] accountExternalID = (String[]) array_accountExternalID.getArray();

							String[] msisdn = (String[]) array_msisdn.getArray();

							String[] serviceMultiType = (String[]) array_serviceMultiType.getArray();

							String[] valInt619 = (String[]) array_lob.getArray();

							resList.add(accountExternalID[x]);
							resList.add(msisdn[x]);
							resList.add(serviceMultiType[x]);
					
							resList.add(valInt619[x]);
							list.add(resList);

						}
					}

					callableStatement.close();
				} catch (Exception e) {
					// TODO: handle exception
					log.info("callFXPostingAPS----" + e);
				}
			}
			obj = new Object[2];
			obj[0] = list;
			obj[1] = jobId;

			// return list;
		} catch (Exception e) {
			log.info("callFXPostingAPS----" + e);
		} finally {
			try {
				if (conn != null) {
					conn.close();

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				log.info("callFXPostingAPS----" + e);
			}

		}
		log.info("end callFXPostingAPS----->>>");
		return obj;

	}
 	@Override
	public String insertFxLog(String statusCode,String trxnId
			,String reqJson,String respJson,String lob,String apsFlag,
			String identifier,String array1,String array2,String dataSet1,String dataSet2) {
		
	 	log.info("START--in updateCallBackResponse in ClientDAOImpl ");
		int status;
		String result="";
		Connection con = null;
		String query = "INSERT INTO APS_FX_LOG VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps = null;
		Clob requestClob =null;
		Clob responseClob =null;
		Clob arrayClob1 =null;
		Clob arrayClob2 =null;
		try{
			con = ConnectionUtil.getConnection();
			con.setAutoCommit(false);
			
			requestClob = con.createClob();
			responseClob=con.createClob();
			arrayClob1=con.createClob();
			arrayClob2 = con.createClob();
			requestClob.setString(1, reqJson);
			responseClob.setString(1, respJson);
			arrayClob1.setString(1, array1);
			arrayClob2.setString(1, array2);
			ps = con.prepareStatement(query);
			
			ps.setString(1, statusCode);
			ps.setString(2, trxnId);
			ps.setClob(3, requestClob);
			ps.setClob(4, responseClob);
			ps.setString(5, lob);
			ps.setString(6, apsFlag);
			ps.setString(7, identifier);
			ps.setClob(8, arrayClob1);
			ps.setClob(9, arrayClob2);
			ps.setTimestamp(10, new Timestamp(new Date().getTime()));
			ps.setString(11, dataSet1);
			ps.setString(12, dataSet2);
			
			status = ps.executeUpdate();
			if(status>0)
				result= RESULT_DB_SUCCESFUL;
			else
				result=RESULT_DB_FAILURE;

			
			
		}
		catch(Exception e){
			log.info("exception occur while insert data inn APS_FX_LOG Table===>"+e.getMessage());
		}
		finally{
			if(con !=null){
				try {
					con.commit();
					ps.close();
					con.close();
				} catch (SQLException e) {
					log.info("exception occur while insert data inn APS_FX_LOG Table===>"+e.getMessage());
				}
			
			}
		}
		log.info("END--in updateCallBackResponse in ClientDAOImpl ");
		return result;
	}

 	public void insertOptimusDetails(String accountNo, String msisdnVal,String lob,OptimusDetailsDto optimusDetails) {

		log.info(" Start:: Inserting insertOptimusDetails profile aps details");
		Connection con = null;
		PreparedStatement ps=null;
		try {
			con = ConnectionUtil.getConnection();
			
				
				String query = "insert into OPTIMUS_PROFILE_APS(ACCT_EXT_ID,MSISDN,APS_FLAG,"
						+ "LOB,ANCHOR_ID,INTHIT_DATE,ERROR_DESCRIPTION) "
						+ "values(?,?,?,?,?,systimestamp,?)";
				ps = con.prepareStatement(query);

				ps.setString(1, accountNo);
				ps.setString(2, msisdnVal);
				ps.setString(3, optimusDetails.getApsFlag());
				ps.setString(4, lob);
				ps.setString(5, optimusDetails.getAnchor());
				ps.setString(6, optimusDetails.getResponseMsg());
				
				ps.executeQuery();

			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			log.info("Exception", e);
		} finally {
			try {
				if(con!=null){
					con.close();

				}
				if(ps!=null){
					ps.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				log.info("Exception", e);
			}

		}
		log.info(
				" END:: Inserting account profile aps details");

	}
}
