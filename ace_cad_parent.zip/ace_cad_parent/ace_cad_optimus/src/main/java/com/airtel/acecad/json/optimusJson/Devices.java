package com.airtel.acecad.json.optimusJson;


public class Devices {

}
