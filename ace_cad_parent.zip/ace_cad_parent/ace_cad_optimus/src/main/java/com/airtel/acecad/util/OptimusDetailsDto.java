package com.airtel.acecad.util;

import com.airtel.acecad.json.optimusJson.Devices;

public class OptimusDetailsDto {
 private String statusCode;
 private String responseMsg;
 private String requestId;
 private String uri;
 private String si;
 private String custAccNo;
 private String homeId;
 private String anchor;
 private String siLob;
 private String isBtfly;
 private Devices device;
 private String errorMsg;
 private String errorReasonCode;
private String errorCode;
private String errorCodeDescription;

private String apsFlag;

public String getApsFlag() {
	return apsFlag;
}
public void setApsFlag(String apsFlag) {
	this.apsFlag = apsFlag;
}
public String getStatusCode() {
	return statusCode;
}
public void setStatusCode(String statusCode) {
	this.statusCode = statusCode;
}
public String getResponseMsg() {
	return responseMsg;
}
public void setResponseMsg(String responseMsg) {
	this.responseMsg = responseMsg;
}
public String getRequestId() {
	return requestId;
}
public void setRequestId(String requestId) {
	this.requestId = requestId;
}
public String getUri() {
	return uri;
}
public void setUri(String uri) {
	this.uri = uri;
}
public String getSi() {
	return si;
}
public void setSi(String si) {
	this.si = si;
}
public String getCustAccNo() {
	return custAccNo;
}
public void setCustAccNo(String custAccNo) {
	this.custAccNo = custAccNo;
}
public String getHomeId() {
	return homeId;
}
public void setHomeId(String homeId) {
	this.homeId = homeId;
}
public String getAnchor() {
	return anchor;
}
public void setAnchor(String hAnchor) {
	this.anchor = hAnchor;
}
public String getSiLob() {
	return siLob;
}
public void setSiLob(String siLob) {
	this.siLob = siLob;
}
public String getIsBtfly() {
	return isBtfly;
}
public void setIsBtfly(String isBtfly) {
	this.isBtfly = isBtfly;
}
public Devices getDevice() {
	return device;
}
public void setDevice(Devices device) {
	this.device = device;
}


public String getErrorMsg() {
	return errorMsg;
}
public void setErrorMsg(String errorMsg) {
	this.errorMsg = errorMsg;
}
public String getErrorReasonCode() {
	return errorReasonCode;
}
public void setErrorReasonCode(String errorReasonCode) {
	this.errorReasonCode = errorReasonCode;
}
public String getErrorCode() {
	return errorCode;
}
public void setErrorCode(String errorCode) {
	this.errorCode = errorCode;
}
public String getErrorCodeDescription() {
	return errorCodeDescription;
}
public void setErrorCodeDescription(String errorCodeDescription) {
	this.errorCodeDescription = errorCodeDescription;
}
@Override
public String toString() {
	return "OptimusDetailsDto [statusCode=" + statusCode + ", responseMsg=" + responseMsg + ", requestId=" + requestId
			+ ", uri=" + uri + ", si=" + si + ", custAccNo=" + custAccNo + ", homeId=" + homeId + ", hAnchor=" + anchor
			+ ", siLob=" + siLob + ", isBtfly=" + isBtfly + ", device=" + device + "]";
}
	
 
}
