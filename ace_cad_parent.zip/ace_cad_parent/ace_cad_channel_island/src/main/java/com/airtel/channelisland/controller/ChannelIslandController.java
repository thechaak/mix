package com.airtel.channelisland.controller;


import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.airtel.acecad.bulkupload.dao.FileUploadDao;
import com.airtel.acecad.bulkupload.dto.CheckedFile;
import com.airtel.acecad.bulkupload.dto.FileStatusAPS;
import com.airtel.acecad.bulkupload.dto.FileStatusDTO;
import com.airtel.acecad.bulkupload.dto.FileUploadResult;
import com.airtel.acecad.bulkupload.uploadfile.ExcelReader;
import com.airtel.acecad.reports.dao.ReportManagementDAO;



@Controller
public class ChannelIslandController {
	
	@Autowired
	ExcelReader excelReader;
	@Autowired
	FileUploadDao fileUploadDao;
     @Autowired
	ReportManagementDAO reportManagementDAO;
	

	private String downloadpath=System.getenv("ACE_CAD_HOME")+File.separator+"UPLOADED_FILES";
	private String templatesPath=System.getenv("ACE_CAD_HOME")+File.separator+"Templates";
	private String errorFilesPath=System.getenv("ACE_CAD_HOME")+File.separator+"ERRORED_FILES";
	private String uploadRefundFiles = System.getenv("ACE_CAD_HOME")+File.separator+"Refund_Files";
	
	//Added by Ritu
	private static String propertyFilePath = System.getenv("GENERIC_PROPERTIES_HOME");
	static File propFile=new File(propertyFilePath+File.separator+"Conf"+File.separator+"generic.properties");
	
	static Properties propsPath = null;
	static {
		try {
			propsPath = new Properties();
			//InputStream inStream = ExcelReader.class.getResourceAsStream("/generic.properties");
			InputStream inStream=new FileInputStream(propFile);

			(propsPath).load(inStream);
		} catch (IOException e) {
		}
	}
	 private String uploadAPSFiles = propsPath.getProperty("ACE_CAD_BULK_HOME")+File.separator+"CAD";
	 private String uploadCIFiles = System.getenv("ACE_CAD_HOME")+File.separator+"CHANNELPARTNER";
	
	private static Logger log = LogManager.getLogger("channelIslandLog");
	HttpServletRequest request;
	HttpSession session;
	
	@RequestMapping(value = "/ciViewFile")
	public ModelAndView ciViewFile(HttpServletRequest request,HttpServletResponse response) throws IOException {
		List<FileStatusAPS> fileStatusListFinal = new ArrayList<>();
		log.info("START ------>ciViewFile");
		FileStatusDTO fileStatusDTO = new FileStatusDTO();
		int page = 0;
		session = request.getSession(true);
		ModelAndView modelAndViewObj = new ModelAndView();
		List<String> statusList = new ArrayList<>();
		String messsage;
		try{
			messsage = request.getParameter("messsage");
		}catch(Exception e){
			messsage="";
		}
		try{
			page = Integer.parseInt(request.getParameter("pageNum"));
		}
		catch(Exception e){
			page = 1;
		}
		finally{
			try {
				
				fileStatusDTO = fileUploadDao.getFileStatusCI(page);
			try{
				Iterator<FileStatusAPS> iter = fileStatusDTO.getFileStatusList().iterator();
				while(iter.hasNext()){
					FileStatusAPS fileStatusAPS = iter.next();
					String path = getPath(fileStatusAPS.getFileIdentifier(), "input", String.valueOf(fileStatusAPS.getFileId()), fileStatusAPS.getFilePath());
					log.info("path is "+path);
					File f = new File(path);
					if(f.exists() && !f.isDirectory()) { 
					   fileStatusAPS.setIsExist("YES");
					}else{
						fileStatusAPS.setIsExist("NO");
					}
				
					fileStatusListFinal.add(fileStatusAPS);
						
				}
			}catch(Exception e){
				log.error(e);
			}
				try{
					statusList = fileUploadDao.getStatusList();	
				}catch(Exception e){
					log.error(e);
				}
				modelAndViewObj.addObject("statusList",statusList);
				modelAndViewObj.addObject("filtersearch", "true");
				modelAndViewObj.addObject("fileStatusList",fileStatusListFinal);
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("totalRecords",fileStatusDTO.getTotalResults());
				modelAndViewObj.addObject("resultsPerPage",fileStatusDTO.getResultPerPage());
				modelAndViewObj.addObject("totalPages", fileStatusDTO.getTotalPages());
				modelAndViewObj.addObject("messsage", messsage);
				HashMap<String,String> fileTypeList = fileUploadDao.readFileTypeListCP();
				modelAndViewObj.addObject("fileTypeList",fileTypeList);
				modelAndViewObj.setViewName("viewFileCI");
			} catch (Exception e) {
				modelAndViewObj.setViewName("viewFileCI");
				log.error(e);
			}
		}
		return modelAndViewObj;
	}
	public String getPath(String fileIdentifier,String folder,String fileId,String fileName){
		String path = "" ; String parentFolder ="";
/*		if(fileIdentifier.equalsIgnoreCase("DPP")){
			parentFolder ="Deposit";
		}else if(fileIdentifier.equalsIgnoreCase("RDP")){
			parentFolder ="Deposit_Reversal";
		}else if(fileIdentifier.equalsIgnoreCase("CNR")){
			parentFolder ="NRC";
		}else if(fileIdentifier.equalsIgnoreCase("DNR")){
			parentFolder ="NRC_Reversal";
		}else if(fileIdentifier.equalsIgnoreCase("REF")){
			parentFolder ="Refund";
		}else if(fileIdentifier.equalsIgnoreCase("ADJ")){
			parentFolder ="Adj";
		}else if(fileIdentifier.equalsIgnoreCase("RDJ")){
			parentFolder ="Adj_Reversal";
		}else if(fileIdentifier.equalsIgnoreCase("SNR")){
			parentFolder ="NRC";
		}*/
		
		
		path = uploadCIFiles + File.separator;
		
	
			//fileName = fileName;//fileId+"_"+
		
		String filepath = path+File.separator+fileName;
		return filepath;
	}
	
	
	@RequestMapping(value = "/templateDownloadCIInHelp", method = RequestMethod.GET)
	public ModelAndView templateDownloadCIInHelp(HttpServletRequest request,HttpServletResponse response) throws IOException {

		log.info("START ChannelIslandController------>templateDownloadCI");
		ModelAndView modelAndViewObj = new ModelAndView();
		String filepath=null;
		String fileToDownload=null;
		String type=request.getParameter("type");
		FileInputStream in=null;
	if(type!=null &&type.equalsIgnoreCase("error"))
	{
		fileToDownload =request.getParameter("fileName");
		filepath =errorFilesPath+File.separator;
	}
	else if(type!=null && type.equalsIgnoreCase("templates"))
	{
		fileToDownload =request.getParameter("fileName");
	    filepath =templatesPath+File.separator;
	}  
	else
	{
		fileToDownload =request.getParameter("fileName");
		filepath=downloadpath+File.separator;
	}
	  				
		 String fileName = filepath+fileToDownload;
	   
	   		log.info("File Name is "+fileName);

	        ServletOutputStream out = response.getOutputStream();
	        try
	        {
	         in = new FileInputStream(fileName);
	         modelAndViewObj.addObject("messsage", "");
	        }
	        catch(Exception e)
	        {
	        	log.error(e);
	        	modelAndViewObj.addObject("messsage", "File not found with particular name");
	    		modelAndViewObj.setViewName("helpbulkUpload");
	    		return modelAndViewObj;
	        }
	      response.setContentType("APPLICATION/OCTET-STREAM");
	      response.addHeader("content-disposition",
	                "attachment; filename=" + fileToDownload);
	  

	        int octet;
	        while((octet = in.read()) != -1)
	            out.write(octet);

	        in.close();
	        out.flush();
	        out.close();
	        response.flushBuffer();
	        modelAndViewObj.setViewName("BulkUploadCI");
	        log.info("START ChannelIslandController------>templateDownloadCI");
		return modelAndViewObj;
		
	}
	
	@RequestMapping(value = "/searchFileCI", method = RequestMethod.GET)
	public ModelAndView searchFileCI(HttpServletRequest request,HttpServletResponse response)throws Exception{
		log.info("Reaching search file");
		List<FileStatusAPS> fileStatusListFinal = new ArrayList<>();
		int page = 0;
		String fileId= null, fileName=null,fromDate = null,endDate = null,status=null,viewName=null,fileIdentifier=null,olmid=null;
		List<String> statusList = new ArrayList<>();
		ModelAndView modelAndViewObj = new ModelAndView();
		FileStatusDTO fileStatusDTO = new FileStatusDTO();
		try{
			 page = Integer.parseInt(request.getParameter("pageNum"));
			 fileId = request.getParameter("fileIdSearch");
			 fileName = request.getParameter("fileNameSearch");
			 status = request.getParameter("fileStatusSearch");
			 if(status == null){
				 status = "";
			 }
			 viewName = request.getParameter("viewName");
			 fromDate = request.getParameter("fromDate");
			 endDate = request.getParameter("endDate");
			 olmid = request.getParameter("OLMIdSearch");
			 if(olmid == null){
				 olmid ="";
			 }
			 fileIdentifier = request.getParameter("fileIdentifierSearch");
			 if(fileIdentifier ==  null){
				 fileIdentifier = "";
			 }
			 
		}
		catch(Exception e){
			page = 1;
			 fileId = request.getParameter("fileIdSearch");
			 fileName = request.getParameter("fileNameSearch");
			 viewName = request.getParameter("viewName");
			 status = request.getParameter("fileStatusSearch");
			 if(status == null){
				 status = "";
			 }
			 fromDate = request.getParameter("fromDate");
			 endDate = request.getParameter("endDate");
			 olmid = request.getParameter("OLMIdSearch");
			 if(olmid == null){
				 olmid ="";
			 }
			 fileIdentifier = request.getParameter("fileIdentifierSearch");
			 if(fileIdentifier ==  null){
				 fileIdentifier = "";
			 }
		}
		
		finally{
			fromDate = (fromDate == null) ? "" : fromDate;
			endDate = (endDate == null) ? "" : endDate;
			log.info("File id is "+fileId +"fileName is "+fileName + " status is "+status+" viename is "+viewName);
			log.info("from date is "+fromDate +" and end date is "+endDate);
			fileStatusDTO = fileUploadDao.searchFileCi(fileId.trim(), fileName.toUpperCase().trim(), fromDate, endDate, status, page,viewName,fileIdentifier.trim(),olmid.toUpperCase().trim());
			Iterator<FileStatusAPS> iter = fileStatusDTO.getFileStatusList().iterator();
			while(iter.hasNext()){
				FileStatusAPS fileStatusAPS = iter.next();
				String path = getPath(fileStatusAPS.getFileIdentifier(), "done", String.valueOf(fileStatusAPS.getFileId()), fileStatusAPS.getFilePath());
				log.info("path is "+path);
				File f = new File(path);
				if(f.exists() && !f.isDirectory()) { 
				   fileStatusAPS.setIsExist("YES");
				}else{
					fileStatusAPS.setIsExist("NO");
				}
				path = getPath(fileStatusAPS.getFileIdentifier(), "ctrl", String.valueOf(fileStatusAPS.getFileId()), fileStatusAPS.getFilePath());
				f= new File(path);
				if(f.exists() && !f.isDirectory()) { 
					   fileStatusAPS.setIsExistCtrl("YES");
					}else{
						fileStatusAPS.setIsExistCtrl("NO");
					}
				path = getPath(fileStatusAPS.getFileIdentifier(), "error", String.valueOf(fileStatusAPS.getFileId()), fileStatusAPS.getFilePath());
				f= new File(path);
				if(f.exists() && !f.isDirectory()) { 
					   fileStatusAPS.setIsExistError("YES");
					}else{
						fileStatusAPS.setIsExistError("NO");
					}
				path = getPath(fileStatusAPS.getFileIdentifier(), "FX1.2", String.valueOf(fileStatusAPS.getFileId()), fileStatusAPS.getFilePath());
				f= new File(path);
				log.info("Path of FX 1.2 is "+path);
				if(f.exists() && !f.isDirectory()) { 
					   fileStatusAPS.setIsExistFX("YES");
					}else{
						fileStatusAPS.setIsExistFX("NO");
					}
				
				fileStatusListFinal.add(fileStatusAPS);
			}
			statusList = fileUploadDao.getStatusList();
			HashMap<String,String> fileTypeList = fileUploadDao.readFileTypeListCP();
			modelAndViewObj.addObject("searchedFileIdentifier", fileIdentifier);
			modelAndViewObj.addObject("searchedOlmid", olmid);
			modelAndViewObj.addObject("fileTypeList",fileTypeList);
			modelAndViewObj.addObject("statusList",statusList);
			modelAndViewObj.addObject("filtersearch", "false");
			modelAndViewObj.addObject("searchedFileId", fileId);
			modelAndViewObj.addObject("searchedFileName", fileName);
			modelAndViewObj.addObject("reason", fileStatusDTO.getReasons());
			log.info("lenght of reason list is"+fileStatusDTO.getReasons().size());
			log.info("status is"+status);
			modelAndViewObj.addObject("searchedstatus", status);
			modelAndViewObj.addObject("searchedFromDate", fromDate);
			modelAndViewObj.addObject("searchedEndDate", endDate);
			modelAndViewObj.addObject("fileStatusList",fileStatusListFinal);
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.addObject("totalRecords",fileStatusDTO.getTotalResults());
			modelAndViewObj.addObject("resultsPerPage",fileStatusDTO.getResultPerPage());
			modelAndViewObj.addObject("totalPages", fileStatusDTO.getTotalPages());
			modelAndViewObj.addObject("searchedFileIdentifier", fileIdentifier);
			modelAndViewObj.addObject("checkedFile", new CheckedFile());
		
		}
		
		
		modelAndViewObj.setViewName(viewName);
		return modelAndViewObj;
	}
	
	
	@RequestMapping(value = "/uploadCIBulkFile", method = RequestMethod.POST)
	public ModelAndView uploadCIBulkFile(@RequestParam("file") MultipartFile file,HttpServletRequest request) throws Exception{
		log.info("START ---->uploadCIBulkFile");
		MultipartFile multipartFile = file;
		ModelAndView modelAndViewObj = new ModelAndView("redirect:/ciViewFile");
		InputStream inputStream = null;
		String fileName="",fileIdentifier = "";;
		String user = session.getAttribute("userid").toString();
		if(multipartFile!=null){
			fileName = multipartFile.getOriginalFilename();
			System.out.println("file name->"+fileName);
			fileIdentifier = fileName.substring(3, 6);
			log.info("File Name is "+fileName +" and file Identifier is "+fileIdentifier);
		        try {
		        	byte[] bytes = file.getBytes();
		        	inputStream = new ByteArrayInputStream(bytes);
		        }catch (IOException e) {
		            log.error(e);
		        }
		}
		log.info("fileName from UI"+fileName);
		String path = getPath(fileIdentifier,"input","0",fileName);
		log.info("fileName to go in filestatus aps "+path);
		System.out.println("fileIdentifier->>> "+fileIdentifier);
		
		FileUploadResult fileUpload = excelReader.readFromExcelfile(path,fileIdentifier, "UI", user, "",inputStream,"Bulk",null,null);
		if(fileUpload.getStatus() == 1 && !"RRC".equalsIgnoreCase(fileIdentifier)){
			String filepath = getPath(fileIdentifier,"done",fileUpload.getFileId(),fileName);
			log.info("file path is "+filepath);
			file.transferTo(new File(filepath));
		}
		else{
			String filepath = uploadRefundFiles + File.separator+fileName;
			log.info("file path is "+filepath);
			file.transferTo(new File(filepath));
		}
		modelAndViewObj.addObject("messsage",fileUpload.getStatusDescription());
		/*modelAndViewObj.setViewName("viewFileAPS");*/
		/*return new ModelAndView("redirect:/apsViewFile?messsage="+fileUpload.getStatusDescription());*/
		return modelAndViewObj;
	}
	
	@RequestMapping(value = "/downloadCIFileByFileId" , method = RequestMethod.GET)
	public ModelAndView downloadCIFileByFileId(HttpServletRequest request,HttpServletResponse response) throws IOException{
		log.info("START ------------------->downloadCIFileByFileId");
		ModelAndView modelAndViewObj = new ModelAndView();
		session = request.getSession(true);
		String fileId = request.getParameter("fileId");
		String fileIdentifier = request.getParameter("fileIdentifier");
		String folder = request.getParameter("type");
		String fileName = request.getParameter("fileName");
		String viewName = request.getParameter("viewName");
		log.info("View Name is "+viewName);
		modelAndViewObj.setViewName(viewName);
				/* log.info("End of failure records download "); */
		String filePath = getPath(fileIdentifier, folder, fileId, fileName);
		ServletOutputStream out = response.getOutputStream();
		FileInputStream in;
		fileName = filePath.substring(filePath.lastIndexOf("\\")+1,filePath.length());
		log.info(fileName);
		fileName =   fileName.substring(fileName.lastIndexOf("/")+1,fileName.length());;
		log.info("File Name of downloaded file is after removing / "+fileName);
	        try
	        {
	         in = new FileInputStream(filePath);
	         File file = new File(filePath);
	         modelAndViewObj.addObject("messsage", "");
	         response.setContentType("APPLICATION/OCTET-STREAM");
	         log.info(file.getAbsolutePath()+" and ");
	        /* response.setContentLength(Integer.parseInt(String.valueOf(file.length())));*/
	        /* response.addHeader("Content-Length", String.valueOf(file.length()));*/
		     response.addHeader("content-disposition",
		                "attachment; filename="+fileName);
		     log.info("file name in downloadFileByFileId "+fileName);
		     
		       	int octet;
		        while((octet = in.read()) != -1)
		            out.write(octet);

		        in.close();
		        out.flush();
		        out.close();
		        response.flushBuffer();
	        }
	        catch(Exception e)
	        {
	        	log.error(e);
	        	modelAndViewObj.addObject("messsage", "File not found with particular name");
	    		return modelAndViewObj;
	        }
	   log.info("File Name in downloadFileByFileId in last "+fileName);
		return null;
	}
	
	
	
	@RequestMapping(value = "/ciBulkApprove", method = RequestMethod.GET)
	public ModelAndView apsBulkApprove(HttpServletRequest request,HttpServletResponse response) throws IOException {
		log.info("START ------>ciBulkApprove");
		List<FileStatusAPS> fileStatusListFinal = new ArrayList<>();
		List<String> statusList = new ArrayList<>();
		FileStatusDTO fileStatusDTO = new FileStatusDTO();
		int page = 0;
		session = request.getSession(true);
		ModelAndView modelAndViewObj = new ModelAndView();
		try{
			page = Integer.parseInt(request.getParameter("pageNum"));
		}
		catch(Exception e){
			page = 1;
		}
		finally{
			try {
				HashMap<String,String> fileTypeList = fileUploadDao.readFileTypeListCP();
				fileStatusDTO = fileUploadDao.getFileStatusCiForApprove(page);
				Iterator<FileStatusAPS> iter = fileStatusDTO.getFileStatusList().iterator();
				while(iter.hasNext()){
					FileStatusAPS fileStatusAPS = iter.next();
					String path = getPath(fileStatusAPS.getFileIdentifier(), "done", String.valueOf(fileStatusAPS.getFileId()), fileStatusAPS.getFilePath());
					log.info("path is "+path);
					File f = new File(path);
					if(f.exists() && !f.isDirectory()) { 
					   fileStatusAPS.setIsExist("YES");
					}else{
						fileStatusAPS.setIsExist("NO");
					}
					
					
					fileStatusListFinal.add(fileStatusAPS);
						
				}
				statusList = fileUploadDao.getStatusList();
				modelAndViewObj.addObject("statusList",statusList);
				modelAndViewObj.addObject("filtersearch", "true");
				modelAndViewObj.addObject("fileStatusList",fileStatusListFinal);
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("reason", fileStatusDTO.getReasons());
				log.info("lenght of reason list is"+fileStatusDTO.getReasons().size());
				modelAndViewObj.addObject("totalRecords",fileStatusDTO.getTotalResults());
				modelAndViewObj.addObject("resultsPerPage",fileStatusDTO.getResultPerPage());
				modelAndViewObj.addObject("totalPages", fileStatusDTO.getTotalPages());
				modelAndViewObj.addObject("checkedFile", new CheckedFile());
				modelAndViewObj.addObject("fileTypeList", fileTypeList);
				modelAndViewObj.setViewName("approveFileCI");
			} catch (Exception e) {
				log.error(e);
			}
		}
		return modelAndViewObj;
	}
	
	@RequestMapping(value = "/approveFileCi", method = RequestMethod.GET)
	public ModelAndView approveFile(@RequestParam String action, @ModelAttribute("checkedSR") CheckedFile checkedFile,
			HttpServletRequest request) {
		int page = 1;
		log.info("In approve method " + action);
		action = request.getParameter("action");
		FileStatusDTO fileStatusDTO = new FileStatusDTO();
	
		log.info("In approve method " + action);
		
		String roleId = session.getAttribute("user_role_id").toString();
		String userId = session.getAttribute("userid").toString();
		
		log.info("and Sr Number list size is " + checkedFile.getCheckedFileList());
		log.info(" and Remark List size is " + checkedFile.getCheckedRemarkList());
		log.info(" and reason list size is " + checkedFile.getCheckedReasonList());
		List<FileStatusAPS> fileStatusListFinal = new ArrayList<>();
		ModelAndView modelAndViewObj = new ModelAndView();
		String message = "";
		try {
			String status = "";
			
			status = fileUploadDao.approveFileCP(checkedFile.getCheckedFileList(), checkedFile.getCheckedReasonList(), checkedFile.getCheckedRemarkList(), userId, action);
			log.info("Status from Procedure is "+status);
			if (status.equalsIgnoreCase("Success") && action.equals("A")) {
				message = "File Approved.";

			} else if (status.equalsIgnoreCase("Success") && action.equals("R")) {
				message = "File Rejected.";
			}
			if (!status.equalsIgnoreCase("Success")) {
				message =  status;
			}
			log.info("Inside approve button click method");
			fileStatusDTO = fileUploadDao.getFileStatusCiForApprove(page);
			Iterator<FileStatusAPS> iter = fileStatusDTO.getFileStatusList().iterator();
			
			while(iter.hasNext()){
				FileStatusAPS fileStatusAPS = iter.next();
				String path = getPath(fileStatusAPS.getFileIdentifier(), "done", String.valueOf(fileStatusAPS.getFileId()), fileStatusAPS.getFilePath());
				log.info("path is "+path);
				File f = new File(path);
				if(f.exists() && !f.isDirectory()) { 
				   fileStatusAPS.setIsExist("YES");
				}else{
					fileStatusAPS.setIsExist("NO");
				}
				
				
				fileStatusListFinal .add(fileStatusAPS);
					
			}
			HashMap< String, String> fileTypeList = fileUploadDao.readFileTypeListCP();
			List<String> statusList = fileUploadDao.getStatusList();
			modelAndViewObj.addObject("statusList",statusList);
			modelAndViewObj.addObject("filtersearch", "true");
			modelAndViewObj.addObject("fileStatusList",fileStatusListFinal);
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.addObject("reason", fileStatusDTO.getReasons());
			log.info("length of reason list is"+fileStatusDTO.getReasons().size());
			modelAndViewObj.addObject("totalRecords",fileStatusDTO.getTotalResults());
			modelAndViewObj.addObject("resultsPerPage",fileStatusDTO.getResultPerPage());
			modelAndViewObj.addObject("totalPages", fileStatusDTO.getTotalPages());
			modelAndViewObj.addObject("checkedFile", new CheckedFile());
			modelAndViewObj.addObject("fileTypeList", fileTypeList);
			modelAndViewObj.setViewName("approveFileCI");
			modelAndViewObj.addObject("currentPage", page);
			
			modelAndViewObj.addObject("message", "No service request in queue for approval");
			modelAndViewObj.addObject("approveRejectMessage", message);
		
		} catch (Exception e) {
			log.error(e);
		}
		return modelAndViewObj;
	}
	
	
	@RequestMapping(value = "/templateDownloadCI", method = RequestMethod.GET)
	public ModelAndView templateDownloadAPS(HttpServletRequest request,HttpServletResponse response) throws IOException {

		log.info("START ------>templateDownloadCI");
		ModelAndView modelAndViewObj = new ModelAndView();
		String filepath=null;
		String fileToDownload=null;
		String type=request.getParameter("type");
		FileInputStream in=null;
	if(type!=null &&type.equalsIgnoreCase("error"))
	{
		fileToDownload =request.getParameter("fileName");
		filepath =errorFilesPath+File.separator;
	}
	else if(type!=null && type.equalsIgnoreCase("templates"))
	{
		fileToDownload =request.getParameter("fileName");
	    filepath =templatesPath+File.separator;
	}  
	else
	{
		fileToDownload =request.getParameter("fileName");
		filepath=downloadpath+File.separator;
	}
	  				
		 String fileName = filepath+fileToDownload;
	   
	   		log.info("File Name is "+fileName);

	        ServletOutputStream out = response.getOutputStream();
	        try
	        {
	         in = new FileInputStream(fileName);
	         modelAndViewObj.addObject("messsage", "");
	        }
	        catch(Exception e)
	        {
	        	log.error(e);
	        	modelAndViewObj.addObject("messsage", "File not found with particular name");
	    		modelAndViewObj.setViewName("BulkUploadCI");
	    		return modelAndViewObj;
	        }
	      response.setContentType("APPLICATION/OCTET-STREAM");
	      response.addHeader("content-disposition",
	                "attachment; filename=" + fileToDownload);
	  

	        int octet;
	        while((octet = in.read()) != -1)
	            out.write(octet);

	        in.close();
	        out.flush();
	        out.close();
	        response.flushBuffer();
	        modelAndViewObj.setViewName("BulkUploadCI");
	        log.info("END ------>templateDownloadCI");
		return modelAndViewObj;
		
	}

}
