package com.acecad.reports.model;

import java.sql.Date;

public class PayTransferFileLevelDetails {

	private String parentUserId;
	private String childUserId;
	private String fileORreqId;
	private String uploadedByOLMId;
	private String uploadedByName;
	private String uploadedTime;
	private String fileName;
	private String statusMsg;	
	private int totRecCount;
	private int inProgressRecords;
	private String inProgressvalue;
	private String totVal;  
	private String status;
	private int successCountFx;
	private String successValFx;
	public int getInProgressRecords() {
		return inProgressRecords;
	}
	public void setInProgressRecords(int inProgressRecords) {
		this.inProgressRecords = inProgressRecords;
	}
	public String getInProgressvalue() {
		return inProgressvalue;
	}
	public void setInProgressvalue(String inProgressvalue) {
		this.inProgressvalue = inProgressvalue;
	}
	private int failedRecCountFx;
	private String failedRecValFx;
	private int Role;
	private String mode;
	private String vendorId;
	private String fromDate;
	private String toDate;
	
	
	public String getStatusMsg() {
		return statusMsg;
	}
	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public void setUploadedTime(String uploadedTime) {
		this.uploadedTime = uploadedTime;
	}
	public String getChildUserId() {
		return childUserId;
	}
	public void setChildUserId(String childUserId) {
		this.childUserId = childUserId;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getParentUserId() {
		return parentUserId;
	}
	public void setParentUserId(String parentUserId) {
		this.parentUserId = parentUserId;
	}
	public int getRole() {
		return Role;
	}
	public void setRole(int role) {
		Role = role;
	}
	public String getFileORreqId() {
		return fileORreqId;
	}
	public void setFileORreqId(String fileORreqId) {
		this.fileORreqId = fileORreqId;
	}

	public String getUploadedByOLMId() {
		return uploadedByOLMId;
	}
	public void setUploadedByOLMId(String uploadedByOLMId) {
		this.uploadedByOLMId = uploadedByOLMId;
	}
	public String getUploadedByName() {
		return uploadedByName;
	}
	public void setUploadedByName(String uploadedByName) {
		this.uploadedByName = uploadedByName;
	}
	
	public String getUploadedTime() {
		return uploadedTime;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public int getTotRecCount() {
		return totRecCount;
	}
	public void setTotRecCount(int totRecCount) {
		this.totRecCount = totRecCount;
	}
	public String getTotVal() {
		return totVal;
	}
	public void setTotVal(String totVal) {
		this.totVal = totVal;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getSuccessCountFx() {
		return successCountFx;
	}
	public void setSuccessCountFx(int successCountFx) {
		this.successCountFx = successCountFx;
	}
	public String getSuccessValFx() {
		return successValFx;
	}
	public void setSuccessValFx(String successValFx) {
		this.successValFx = successValFx;
	}
	public int getFailedRecCountFx() {
		return failedRecCountFx;
	}
	public void setFailedRecCountFx(int failedRecCountFx) {
		this.failedRecCountFx = failedRecCountFx;
	}
	public String getFailedRecValFx() {
		return failedRecValFx;
	}
	public void setFailedRecValFx(String failedRecValFx) {
		this.failedRecValFx = failedRecValFx;
	}
	
}
