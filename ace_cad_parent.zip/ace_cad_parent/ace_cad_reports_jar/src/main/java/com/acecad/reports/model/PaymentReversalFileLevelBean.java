package com.acecad.reports.model;

import java.sql.Date;

public class PaymentReversalFileLevelBean {
	private String fileId;
	private String reversalType;
	private String uploadedByOlmId;
	private String uploadedByName;
	private String fileName;
    private String status;
    private int totalRecords;
    private int successRecordCount;
    private int failureRecordCount;
    private int inProgressRecords;
    public int getInProgressRecords() {
		return inProgressRecords;
	}
	public void setInProgressRecords(int inProgressRecords) {
		this.inProgressRecords = inProgressRecords;
	}
	public String getInProgressValue() {
		return inProgressValue;
	}
	public void setInProgressValue(String inProgressValue) {
		this.inProgressValue = inProgressValue;
	}
	private String inProgressValue;
    private String uploadTime;
    private String totalValue;
    public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getReversalType() {
		return reversalType;
	}
	public void setReversalType(String reversalType) {
		this.reversalType = reversalType;
	}
	public String getUploadedByOlmId() {
		return uploadedByOlmId;
	}
	public void setUploadedByOlmId(String uploadedByOlmId) {
		this.uploadedByOlmId = uploadedByOlmId;
	}
	public String getUploadedByName() {
		return uploadedByName;
	}
	public void setUploadedByName(String uploadedByName) {
		this.uploadedByName = uploadedByName;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getTotalRecords() {
		return totalRecords;
	}
	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}
	public int getSuccessRecordCount() {
		return successRecordCount;
	}
	public void setSuccessRecordCount(int successRecordCount) {
		this.successRecordCount = successRecordCount;
	}
	public int getFailureRecordCount() {
		return failureRecordCount;
	}
	public void setFailureRecordCount(int failureRecordCount) {
		this.failureRecordCount = failureRecordCount;
	}
	public String getUploadTime() {
		return uploadTime;
	}
	public void setUploadTime(String uploadTime) {
		this.uploadTime = uploadTime;
	}
	public String getTotalValue() {
		return totalValue;
	}
	public void setTotalValue(String totalValue) {
		this.totalValue = totalValue;
	}
	public String getSuccessRecordValue() {
		return successRecordValue;
	}
	public void setSuccessRecordValue(String successRecordValue) {
		this.successRecordValue = successRecordValue;
	}
	public String getFailureRecordValue() {
		return failureRecordValue;
	}
	public void setFailureRecordValue(String failureRecordValue) {
		this.failureRecordValue = failureRecordValue;
	}
	public String getChildUserId() {
		return childUserId;
	}
	public void setChildUserId(String childUserId) {
		this.childUserId = childUserId;
	}
	public String getParentUserId() {
		return parentUserId;
	}
	public void setParentUserId(String parentUserId) {
		this.parentUserId = parentUserId;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	private String successRecordValue;
    private String failureRecordValue;
    private String childUserId;
    private String parentUserId;
    private String vendorId;
    private String fromDate;
    public String getStatusMsg() {
		return statusMsg;
	}
	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}
	public int getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	private String toDate;
    private String statusMsg;
    private int totalPages;
    
}



