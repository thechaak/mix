package com.acecad.reports.model;

import java.sql.Date;

public class PayPostingChequeDetails {
	 
	private String parentUser;
	private String toDate;
	private String fromDate;
	private String fileId;
	private String chqNo;
	private String bankName;
	private String vendorId;
	private String vendorName;
	private String userOLMId;
	private String fileName;
	private String dateOnChq;
	private int noOfAccPosted;
	private int noOfInvPosted;
	private String chqVal;
	private String valPostedFX;
	public String getBankAccNo() {
		return bankAccNo;
	}
	public void setBankAccNo(String bankAccNo) {
		this.bankAccNo = bankAccNo;
	}
	private String valPendingLIU;
	private String chqUploadDt;
	private String chqUploadTym;
	private String bankAccNo;
	public String getChqUploadTym() {
		return chqUploadTym;
	}
	public void setChqUploadTym(String chqUploadTym) {
		this.chqUploadTym = chqUploadTym;
	}
	private String postingDate;
	private String postingTime;
	private int diffChqvsUpload;
	private int diffUploadvsPosted;
	private int role;
	private String statusMsg;
	
	
	
	public String getValPostedFX() {
		return valPostedFX;
	}
	public void setValPostedFX(String valPostedFX) {
		this.valPostedFX = valPostedFX;
	}
	public String getValPendingLIU() {
		return valPendingLIU;
	}
	public void setValPendingLIU(String valPendingLIU) {
		this.valPendingLIU = valPendingLIU;
	}
	public String getDateOnChq() {
		return dateOnChq;
	}
	public void setDateOnChq(String dateOnChq) {
		this.dateOnChq = dateOnChq;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	
	
	public String getParentUser() {
		return parentUser;
	}
	public void setParentUser(String parentUser) {
		this.parentUser = parentUser;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getChqNo() {
		return chqNo;
	}
	public void setChqNo(String chqNo) {
		this.chqNo = chqNo;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getUserOLMId() {
		return userOLMId;
	}
	public void setUserOLMId(String userOLMId) {
		this.userOLMId = userOLMId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	
	public int getNoOfAccPosted() {
		return noOfAccPosted;
	}
	public void setNoOfAccPosted(int noOfAccPosted) {
		this.noOfAccPosted = noOfAccPosted;
	}
	public int getNoOfInvPosted() {
		return noOfInvPosted;
	}
	public void setNoOfInvPosted(int noOfInvPosted) {
		this.noOfInvPosted = noOfInvPosted;
	}
	public String getChqVal() {
		return chqVal;
	}
	public void setChqVal(String chqVal) {
		this.chqVal = chqVal;
	}
	
	public String getPostingDate() {
		return postingDate;
	}
	public String getChqUploadDt() {
		return chqUploadDt;
	}
	public void setChqUploadDt(String chqUploadDt) {
		this.chqUploadDt = chqUploadDt;
	}
	
	public void setPostingDate(String postingDate) {
		this.postingDate = postingDate;
	}
	
	public String getPostingTime() {
		return postingTime;
	}
	public void setPostingTime(String postingTime) {
		this.postingTime = postingTime;
	}
	public int getDiffChqvsUpload() {
		return diffChqvsUpload;
	}
	public void setDiffChqvsUpload(int diffChqvsUpload) {
		this.diffChqvsUpload = diffChqvsUpload;
	}
	public int getDiffUploadvsPosted() {
		return diffUploadvsPosted;
	}
	public void setDiffUploadvsPosted(int diffUploadvsPosted) {
		this.diffUploadvsPosted = diffUploadvsPosted;
	}
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}
	public String getStatusMsg() {
		return statusMsg;
	}
	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}
	
	
	
	
	
	
	
	
	
	
}
