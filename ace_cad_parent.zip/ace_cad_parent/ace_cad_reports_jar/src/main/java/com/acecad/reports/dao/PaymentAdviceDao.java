package com.acecad.reports.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;


//import com.acecad.reports.model.LIURecordDetails;
import com.acecad.reports.model.PaymentAdviceBean;
import com.acecad.reports.model.ProcessedAdviceFileDetails;

public interface PaymentAdviceDao {

	   public List<String> adviceProcessListDropdown(String role,String userId); 
	   
	//   public List<String> adviceRMProcessList(int roleType); 
	   
		public HashMap<Integer, List<PaymentAdviceBean>> adviceSearchTransLevel(int pageNumber,PaymentAdviceBean adviceTransBeanObj,String userRole,String userId) throws SQLException;

		public HashMap<Integer, List<PaymentAdviceBean>> adviceSearchEFTLevel(int pageNumber,PaymentAdviceBean adviceEFTBeanObj,String userRole,String userId) throws SQLException;
		
		public HashMap<Integer, List<PaymentAdviceBean>> adviceSearchRequestLevel(int pageNumber,PaymentAdviceBean adviceRequestBeanObj,String userRole,String userId) throws SQLException;
	
		public  String getDateTime();
		
	   	public int getRoleType(String userId);
		
 	public PaymentAdviceBean downloadedTransFile(PaymentAdviceBean adviceDownloadTransObj,/*String downloadedFilesPath,*/String extension,String pageNumber,String userRole,String userId) throws SQLException;

 	public PaymentAdviceBean downloadedEFTLevelFile(PaymentAdviceBean adviceEFTBeanObj,/*String downloadedFilesPath,*/String extension,String pageNumber,String userRole,String userId) throws SQLException;

 	public PaymentAdviceBean downloadedRequestLevelFile(PaymentAdviceBean adviceDownloadRequestObj,/*String downloadedFilesPath,*/String extension,String pageNumber,String userRole,String userId) throws SQLException;

 	public ProcessedAdviceFileDetails downloadProcessedFile(String userId,String requestId,String paymentMode,String extension) throws SQLException;

	public HashMap<Integer, List<PaymentAdviceBean>> waiverSearchRequestLevel(int pageNumber,
			PaymentAdviceBean adviceRequestBeanObj1, String role, String userId) throws SQLException;

	
}
