package com.acecad.reports.daoImpl;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.acecad.reports.dao.ReportsDao;
import com.acecad.reports.model.ActivityLogDetails;
import com.acecad.reports.model.PayPostingChequeDetails;
import com.acecad.reports.model.PayPostingTransLevelDetails;
import com.acecad.reports.model.PayPostingVendorDetails;
import com.acecad.reports.model.PayRevChequeBounceDetailsDownload;
import com.acecad.reports.model.PayRevChqBounceRecordsDetails;
import com.acecad.reports.model.PayRevDirectTransRecordsDownload;
import com.acecad.reports.model.PayTransferFileLevelDetails;
import com.acecad.reports.model.PaymentDirectReversalBean;
import com.acecad.reports.model.PaymentPostingFilelevelDetails;
import com.acecad.reports.model.PaymentPostingModewiseBean;
import com.acecad.reports.model.PaymentPostingTransLevelDetailsDownload;
import com.acecad.reports.model.PaymentReversalFileLevelBean;
import com.acecad.reports.model.PaymentTransferTransLevelBean;
import com.acecad.reports.model.UserManagementUserLevel;
import com.acecad.reports.model.VendorUserReportBean;




public class ReportsDaoImpl implements ReportsDao {
	
	private static Logger reportslogger =LogManager.getLogger("reportsLogger");
	
	private DataSource dataSource;
	Connection conn = null;
	ResultSet resultset = null;

	public ReportsDaoImpl(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public int getRole(String parentUserId) {
		int Role = 0;
		CallableStatement callableStatement=null;
		try {

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			reportslogger.info("In DaoImpl to Get Role");

			String functionCall = "{? = call GETUSERROLE(?)}";

			 callableStatement = conn
					.prepareCall(functionCall);

			callableStatement.registerOutParameter(1, Types.INTEGER);
			callableStatement.setString(2, parentUserId);
			callableStatement.execute();

			Role = callableStatement.getInt(1);
			//reportslogger.info("@dao role is" + Role);

		} catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return -1;
		} finally {
			
     	   if(callableStatement!=null){
     	   try {
     		  callableStatement.close();
			} catch (Exception e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);			}
     	   }
			
    	   if(conn!=null){
         	   try {
    				conn.close();
    			} catch (Exception e) {
    				StringWriter errors= new StringWriter();
    				e.printStackTrace(new PrintWriter(errors));
    				reportslogger.error(errors);    			}
         	   }
		}
		return Role;
	}

	public String getOrignalFileName(String ticketId) {
		
	PreparedStatement preparedStatement=null;
	String fileName=null;
		try {

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			reportslogger.info("In DaoImpl to Get Role");

			String functionCall = "select  ORIGINAL_FILE_NAME from advice_request_status_aps where i_request_id="+ticketId;
			reportslogger.info("Report dao impl Statement>>>"+functionCall);
			
			preparedStatement=conn.prepareStatement(functionCall);

			ResultSet rs=preparedStatement.executeQuery();
			if(rs!=null){
				while (rs.next()) {
				 fileName=rs.getString(1);
				}	
			}
			//reportslogger.info("@dao role is" + Role);

		} catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			
		} finally {
			
     	   if(preparedStatement!=null){
     	   try {
     		  preparedStatement.close();
			} catch (Exception e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);			}
     	   }
			
    	   if(conn!=null){
         	   try {
    				conn.close();
    			} catch (Exception e) {
    				StringWriter errors= new StringWriter();
    				e.printStackTrace(new PrintWriter(errors));
    				reportslogger.error(errors);    			}
         	   }
		}
		return fileName;
	}
	
	public List<String> returnModeList() {

		List<String> modeList = new ArrayList<String>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		try {
			reportslogger.info("In DaoImpl To Get Mode List");
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("entered PayPostingFilelevelDaoImpl");

			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.PAYMENT_MODE_LIST(?,?,?)}";

			 callableStatement = conn
					.prepareCall(procedureCall);
			callableStatement.registerOutParameter(1, Types.VARCHAR);
			callableStatement.registerOutParameter(2, Types.VARCHAR);
			callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
			callableStatement.executeUpdate();
			//reportslogger.info("callable statements executed");

			resultset = (ResultSet) callableStatement.getObject(3);
			while (resultset.next()) {
				modeList.add(resultset.getString("PAYMENT_MODE"));
			}

		} catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
			} 
		finally {
			
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);		    			}
		         
		         	   }
		}
		return modeList;
	}

	/** PAYMENT POSTING FILE LEVEL **/

	public HashMap<Integer, List<PaymentPostingFilelevelDetails>> getPayPostingFilelevelDetails(
			PaymentPostingFilelevelDetails payPostingFilelevelDetailsObj,
			int page) {

		HashMap<Integer, List<PaymentPostingFilelevelDetails>> finalDetailsMap = new HashMap<Integer, List<PaymentPostingFilelevelDetails>>();
		List<PaymentPostingFilelevelDetails> detailsList = new ArrayList<PaymentPostingFilelevelDetails>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		//reportslogger.info("page number in dao" + page);
		reportslogger.info(" Payment Posting File level Details Method in DaoImpl");

		try {
			
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			/*reportslogger.info("connection established");
			reportslogger.info("in dao child userid"
					+ payPostingFilelevelDetailsObj.getChildUserId());
			reportslogger.info("mode in dao"
					+ payPostingFilelevelDetailsObj.getMode());*/

			// call proc
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_USER_FILE_STATUS_DETAILS(?,?,?,?,?,?,?,?,?,?,?,?)}";

			 callableStatement = conn
					.prepareCall(procedureCall);

			/* callableStatement.setInt(1, page); */
			callableStatement.setString(1,
					payPostingFilelevelDetailsObj.getParentUserId());
			callableStatement.setString(2,
					payPostingFilelevelDetailsObj.getChildUserId());
			callableStatement.setString(3,
					payPostingFilelevelDetailsObj.getFileId());
			
			callableStatement.setString(4,
					payPostingFilelevelDetailsObj.getFileName());
			callableStatement.setString(5,
					payPostingFilelevelDetailsObj.getMode());
			callableStatement.setString(6,
					payPostingFilelevelDetailsObj.getVendorId());
			callableStatement.setString(7,
					payPostingFilelevelDetailsObj.getToDate());
			callableStatement.setString(8,
					payPostingFilelevelDetailsObj.getFromDate());
			callableStatement.setInt(9, page);
			callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(11, Types.INTEGER);
			callableStatement.registerOutParameter(12, Types.VARCHAR);
			//reportslogger.info("before execute update");
			callableStatement.executeUpdate();
			//reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(11);

			String statusMsg = callableStatement.getString(12);// msg

			resultset = (ResultSet) callableStatement.getObject(10);

			payPostingFilelevelDetailsObj.setStatusMsg(statusMsg);

			// reportslogger.info("result set size"+resultset.getFetchSize());
			reportslogger.info("Error Msg at DaoImpl"+ payPostingFilelevelDetailsObj.getStatusMsg());
			/* reportslogger.info("totalpages:" + totalPages); */
			if (resultset == null) {
				reportslogger.info("Resultset is null in DaoImpl");

			} else {

				while (resultset != null && resultset.next()) {
				//	//reportslogger.info("inside while!");
					PaymentPostingFilelevelDetails PayPostingFilelevelDetailsObject = new PaymentPostingFilelevelDetails();

					PayPostingFilelevelDetailsObject.setChildUserId(resultset
							.getString("USER_ID"));
					PayPostingFilelevelDetailsObject.setVendorId(resultset
							.getString("VENDOR_ID"));
					PayPostingFilelevelDetailsObject.setVendorName(resultset
							.getString("VENDOR_NAME"));

					/*
					 * PayPostingFilelevelDetailsObject.setMode(resultset.getString
					 * (3));
					 */
					PayPostingFilelevelDetailsObject.setFileName(resultset
							.getString("ORIGINAL_FILE_NAME"));

					String date = resultset.getString("FILE_UPLOAD_DATE");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date date1 = dateString.parse(date);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateString1.format(date1);

					PayPostingFilelevelDetailsObject.setUploadedDate(finalDate);
					/*reportslogger.info("dao impl date"
							+ resultset.getString("FILE_UPLOAD_DATE"));*/
					PayPostingFilelevelDetailsObject.setApprovedBy(resultset.getString("APPROVED_BY"));
					/*reportslogger.info("approved by"+PayPostingFilelevelDetailsObject.getApprovedBy());*/
					if(resultset.getString("APPROVED_DATE")==null||resultset.getString("APPROVED_DATE").equalsIgnoreCase(""))
					{
						PayPostingFilelevelDetailsObject.setApprovedDate(resultset.getString("APPROVED_DATE"));
					}
					else
					{
					String approvedDate = resultset.getString("APPROVED_DATE");
					Date date2 = dateString.parse(approvedDate);
					String finalDate1 = dateString1.format(date2);
					PayPostingFilelevelDetailsObject.setApprovedDate(finalDate1);
					}
					PayPostingFilelevelDetailsObject.setFileId(resultset
							.getString("FILE_ID"));
					PayPostingFilelevelDetailsObject.setUserCircle(resultset
							.getString("CIRCLE"));
					PayPostingFilelevelDetailsObject.setMode(resultset
							.getString("PAYMENT_MODE"));
					PayPostingFilelevelDetailsObject
							.setRecordsPostedToFx(resultset
									.getInt("RECORDS_POSTED_FX"));
					PayPostingFilelevelDetailsObject
							.setValuePostedToFx(resultset
									.getString("VALUE_POSTED_FX"));
					PayPostingFilelevelDetailsObject
							.setRecordsPendingAtLiu(resultset
									.getInt("PENDING_LIU"));
					PayPostingFilelevelDetailsObject
							.setValuePendingAtLiu(resultset
									.getString("VALUE_PENDING_LIU"));
					PayPostingFilelevelDetailsObject
					.setValueDeletedAtLiu(resultset
							.getString("VALUE_DELETED_AT_LIU"));
					PayPostingFilelevelDetailsObject.setLiuDeleted(resultset.getInt("LIU_DELETED"));
					
					PayPostingFilelevelDetailsObject.setTotalValue(resultset
							.getString("TOTAL_VALUE"));
					//reportslogger.info("amount" + resultset.getString("TOTAL_VALUE"));
					PayPostingFilelevelDetailsObject.setTotalRecords(resultset
							.getInt("TOTAL_RECORDS"));
					PayPostingFilelevelDetailsObject.setInProgressRecords(resultset
							.getInt("INPROGRESS_RECORDS"));
					PayPostingFilelevelDetailsObject.setInProgressValue(resultset
							.getString("INPROGRESS_RECORDS_VALUE"));
					PayPostingFilelevelDetailsObject.setRejectedRecords(resultset
							.getInt("REJECTED_RECORDS"));
					PayPostingFilelevelDetailsObject.setRejectedValue(resultset
							.getString("REJECTED_VALUE"));

					PayPostingFilelevelDetailsObject.setStatus(resultset
							.getString("FILE_ACCEPTANCE_STATUS"));
					/*PayPostingFilelevelDetailsObject.setStatus(resultset
							.getString("FILE_ACCEPTANCE_STATUS1"));*/

					detailsList.add(PayPostingFilelevelDetailsObject);
				/*	reportslogger.info("records posted to fx"
							+ resultset.getInt("RECORDS_POSTED_FX"));
					reportslogger.info("value posted to fx"
							+ resultset.getDouble("VALUE_POSTED_FX"));
					//reportslogger.info("records pending at liu"
							//+ resultset.getInt("RECORDS_PENDING_LIU"));
					reportslogger.info("value pending at liu"
							+ resultset.getDouble("VALUE_PENDING_LIU"));*/

				}
			}
			reportslogger.info("Payment Posting File level Details list size in DaoImpl:" + detailsList.size());
            finalDetailsMap.put(totalPages, detailsList);
		} 
		 catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     }
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
			
		}
		return finalDetailsMap;

	}

	public List<PaymentPostingTransLevelDetailsDownload> getPayPostingPendingLiuRecords(
			String fileID) {
		List<PaymentPostingTransLevelDetailsDownload> PayPostingTransLevelDetailsList = new ArrayList<PaymentPostingTransLevelDetailsDownload>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		try {
			reportslogger.info("Payment Posting File level Pending LIU Records Download in DaoImpl");
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("entered transRecords download file");
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.PAY_POSTING_DETAILS_DOWNLOAD(?,?,?)}";

			callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1, fileID);
			//reportslogger.info("file id in liu dao" + fileID);

			callableStatement.registerOutParameter(2, OracleTypes.CURSOR);

			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.executeUpdate();

			//reportslogger.info("callable statements executed");

			resultset = (ResultSet) callableStatement.getObject(2);

			String statusMessage = callableStatement.getString(3);

			reportslogger.info("Error Msg at DaoImpl:" + statusMessage);
			if (resultset == null) {
				reportslogger.info("Resultset is null in daoImpl");

			} else {

				while (resultset != null && resultset.next()) {
				//	//reportslogger.info("inside while!");
					PaymentPostingTransLevelDetailsDownload PayPostingTransLevelDetailsObj = new PaymentPostingTransLevelDetailsDownload();
					PayPostingTransLevelDetailsObj.setRefNo(resultset
							.getString("REF_NUMBER"));
					PayPostingTransLevelDetailsObj.setVendorId(resultset
							.getString("VENDOR_ID"));
					PayPostingTransLevelDetailsObj.setVendorName(resultset
							.getString("VENDOR_NAME"));
					PayPostingTransLevelDetailsObj.setUserOlmId(resultset
							.getString("USER_ID"));
					PayPostingTransLevelDetailsObj.setFileId(resultset
							.getString("FILE_ID"));
					PayPostingTransLevelDetailsObj.setFileName(resultset
							.getString("FILE_NAME"));
					PayPostingTransLevelDetailsObj.setFileSource(resultset
							.getString("FILE_SOURCE"));
					if(resultset.getString("MODE").equalsIgnoreCase("OTHERS"))
						PayPostingTransLevelDetailsObj.setMode("MISCELLANEOUS");
					else
					PayPostingTransLevelDetailsObj.setMode(resultset
							.getString("MODE"));
					String date = resultset.getString("UPLOAD_DATE");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date date1 = dateString.parse(date);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateString1.format(date1);
					PayPostingTransLevelDetailsObj
							.setUplodedDateTime(finalDate);
					PayPostingTransLevelDetailsObj.setAccountNumber(resultset
							.getString("ACCOUNT_NUMBER"));
					PayPostingTransLevelDetailsObj.setInvoice(resultset
							.getString("INVOICE_NUMBER"));
					PayPostingTransLevelDetailsObj.setAmount(resultset
							.getString("AMOUNT"));

					PayPostingTransLevelDetailsObj
							.setReasonForLiuFailure(resultset
									.getString("REASON_FOR_LIU"));
					PayPostingTransLevelDetailsObj
					.setBankAccNo(resultset
							.getString("BANK_ACCOUNT_NUMBER"));
					if(resultset.getString("LOB")==null||resultset.getString("LOB").equalsIgnoreCase(""))
					{
						PayPostingTransLevelDetailsObj.setLob("");
					}
					else
					{
					if(resultset.getString("LOB").equalsIgnoreCase("BTS"))
					{
						PayPostingTransLevelDetailsObj.setLob("FL");
					}
					else
						PayPostingTransLevelDetailsObj.setLob(resultset.getString("LOB"));
					}
					
					PayPostingTransLevelDetailsObj
					.setApprovedBy(resultset
							.getString("APPROVED_BY"));
					if(resultset.getString("APPROVED_DATE")==null||resultset.getString("APPROVED_DATE").equalsIgnoreCase(""))
					{
						PayPostingTransLevelDetailsObj.setApprovedDate(resultset.getString("APPROVED_DATE"));
					}
					else
					{
					String approvedDate = resultset.getString("APPROVED_DATE");
					Date date2 = dateString.parse(approvedDate);
					String finalDate1 = dateString1.format(date2);
					PayPostingTransLevelDetailsObj.setApprovedDate(finalDate1);
					}
					
					/*reportslogger.info("uploaded date time"
							+ PayPostingTransLevelDetailsObj
									.getUplodedDateTime());*/

					PayPostingTransLevelDetailsList
							.add(PayPostingTransLevelDetailsObj);

				}
			}
			reportslogger.info("Payment Posting File level Pending LIU Records list size in DaoImpl:"
					+ PayPostingTransLevelDetailsList.size());

		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     } 
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
			
		}
		return PayPostingTransLevelDetailsList;
	}

	public List<PaymentPostingTransLevelDetailsDownload> getPayPostingRecordsPostedToFx(
			String fileID) {
		List<PaymentPostingTransLevelDetailsDownload> PayPostingTransLevelDetailsList = new ArrayList<PaymentPostingTransLevelDetailsDownload>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		try {
			reportslogger.info("Payment Posting File level FX Records Download in DaoImpl");
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("entered transRecords download file");
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.PAY_POS_FX_DETAILS_DOWNLOAD(?,?,?)}";

			callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1, fileID);
			//reportslogger.info("file id in liu dao" + fileID);

			callableStatement.registerOutParameter(2, OracleTypes.CURSOR);

			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.executeUpdate();

			//reportslogger.info("callable statements executed");

			resultset = (ResultSet) callableStatement.getObject(2);

			String statusMessage = callableStatement.getString(3);

			reportslogger.info("Error Msg at DaoImpl" + statusMessage);
			if (resultset == null) {
				reportslogger.info("Resultset is null in DaoImpl");

			} else {

				while (resultset != null && resultset.next()) {

					PaymentPostingTransLevelDetailsDownload PayPostingTransLevelDetailsObj = new PaymentPostingTransLevelDetailsDownload();
					PayPostingTransLevelDetailsObj.setRefNo(resultset
							.getString("REF_NUMBER"));
					PayPostingTransLevelDetailsObj.setVendorId(resultset
							.getString("VENDOR_ID"));
					PayPostingTransLevelDetailsObj.setVendorName(resultset
							.getString("VENDOR_NAME"));
					PayPostingTransLevelDetailsObj.setUserOlmId(resultset
							.getString("USER_ID"));
					PayPostingTransLevelDetailsObj.setFileId(resultset
							.getString("FILE_ID"));
					PayPostingTransLevelDetailsObj.setFileName(resultset
							.getString("FILE_NAME"));
					PayPostingTransLevelDetailsObj.setFileSource(resultset
							.getString("FILE_SOURCE"));
					if(resultset.getString("MODE").equalsIgnoreCase("OTHERS"))
						PayPostingTransLevelDetailsObj.setMode("MISCELLANEOUS");
					else
					PayPostingTransLevelDetailsObj.setMode(resultset
							.getString("MODE"));
					String stringUpload = resultset.getString("UPLOAD_DATE");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date dateUpload = dateString.parse(stringUpload);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateString1.format(dateUpload);
					PayPostingTransLevelDetailsObj
							.setUplodedDateTime(finalDate);
					PayPostingTransLevelDetailsObj.setAccountNumber(resultset
							.getString("ACCOUNT_NUMBER"));
					PayPostingTransLevelDetailsObj.setInvoice(resultset
							.getString("INVOICE_NUMBER"));
					PayPostingTransLevelDetailsObj.setAmount(resultset
							.getString("AMOUNT"));
					if(resultset.getString("FX_POSTING_TIME")!=null){
					String date = resultset.getString("FX_POSTING_TIME");
					
					Date date1 = dateString.parse(date);
					
					String finalDate1 = dateString1.format(date1);
					PayPostingTransLevelDetailsObj.setFxPostingTime(finalDate1);
					}
					else
						PayPostingTransLevelDetailsObj.setFxPostingTime("");
					PayPostingTransLevelDetailsObj.setTrackingid(resultset
							.getString("TRACKING_ID"));
					PayPostingTransLevelDetailsObj.setTrackingServ(resultset
							.getString("TRACKING_ID_SERV"));
					PayPostingTransLevelDetailsObj
					.setBankAccNo(resultset
							.getString("BANK_ACCOUNT_NUMBER"));
					if(resultset.getString("LOB")==null||resultset.getString("LOB").equalsIgnoreCase(""))
					{
						PayPostingTransLevelDetailsObj.setLob("");
					}
					else
					{
					if(resultset.getString("LOB").equalsIgnoreCase("BTS"))
					{
						PayPostingTransLevelDetailsObj.setLob("FL");
					}
					else
						PayPostingTransLevelDetailsObj.setLob(resultset.getString("LOB"));
					}
					
					PayPostingTransLevelDetailsObj
					.setApprovedBy(resultset
							.getString("APPROVED_BY"));
					if(resultset.getString("APPROVED_DATE")==null||resultset.getString("APPROVED_DATE").equalsIgnoreCase(""))
					{
						PayPostingTransLevelDetailsObj.setApprovedDate(resultset.getString("APPROVED_DATE"));
					}
					else
					{
					String approvedDate = resultset.getString("APPROVED_DATE");
					Date date2 = dateString.parse(approvedDate);
					String finalDate1 = dateString1.format(date2);
					PayPostingTransLevelDetailsObj.setApprovedDate(finalDate1);
					}

				/*	reportslogger.info("uploaded date time"
							+ PayPostingTransLevelDetailsObj
									.getUplodedDateTime());*/

					PayPostingTransLevelDetailsList
							.add(PayPostingTransLevelDetailsObj);

				}
			}
			reportslogger.info("Payment Posting File level Fx Records list size in DaoImpl:"+ PayPostingTransLevelDetailsList.size());

		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     } 
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return PayPostingTransLevelDetailsList;
	}

	public List<PaymentPostingFilelevelDetails> getPayPostingExcelDetails(
			PaymentPostingFilelevelDetails payPostingFilelevelDetailsObj,
			String pageNo) {
		List<PaymentPostingFilelevelDetails> excelDetailsList = new ArrayList<PaymentPostingFilelevelDetails>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		//reportslogger.info("page number in dao" + pageNo);

		try {
			reportslogger.info("Payment Posting File level Excel Download method in DaoImpl");
			//reportslogger.info("connection" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("connection established");
			/*reportslogger.info("in dao child userid"
					+ payPostingFilelevelDetailsObj.getChildUserId());
			reportslogger.info("mode in dao"
					+ payPostingFilelevelDetailsObj.getMode());*/

			// call proc
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_USER_FILE_STATUS_DETAILS(?,?,?,?,?,?,?,?,?,?,?,?)}";

			 callableStatement = conn
					.prepareCall(procedureCall);

			// callableStatement.setInt(1, pageNo);
			callableStatement.setString(1,
					payPostingFilelevelDetailsObj.getParentUserId());
			callableStatement.setString(2,
					payPostingFilelevelDetailsObj.getChildUserId());
			callableStatement.setString(3,
					payPostingFilelevelDetailsObj.getFileId());
			callableStatement.setString(4,
					payPostingFilelevelDetailsObj.getFileName());
			callableStatement.setString(5,
					payPostingFilelevelDetailsObj.getMode());
			callableStatement.setString(6,
					payPostingFilelevelDetailsObj.getVendorId());

			callableStatement.setString(7,
					payPostingFilelevelDetailsObj.getToDate());
			callableStatement.setString(8,
					payPostingFilelevelDetailsObj.getFromDate());
			callableStatement.setString(9, pageNo);
			callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(11, Types.INTEGER);
			callableStatement.registerOutParameter(12, Types.VARCHAR);
			//reportslogger.info("before execute update");
			callableStatement.executeUpdate();
			//reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(11);

			String statusMsg = callableStatement.getString(12);// msg

			resultset = (ResultSet) callableStatement.getObject(10);

			payPostingFilelevelDetailsObj.setStatusMsg(statusMsg);

			// reportslogger.info("result set size"+resultset.getFetchSize());
			reportslogger.info("Error Msg at DaoImpl"+ payPostingFilelevelDetailsObj.getStatusMsg());
			//reportslogger.info("totalpages:" + totalPages);*/
			if (resultset == null) {
				reportslogger.info("Resultset is null in DaoImpl");

			} else {

				while (resultset != null && resultset.next()) {
					////reportslogger.info("inside while!");
					PaymentPostingFilelevelDetails PayPostingFilelevelDetailsObject = new PaymentPostingFilelevelDetails();

					PayPostingFilelevelDetailsObject.setChildUserId(resultset
							.getString("USER_ID"));
					PayPostingFilelevelDetailsObject.setVendorId(resultset
							.getString("VENDOR_ID"));
					PayPostingFilelevelDetailsObject.setVendorName(resultset
							.getString("VENDOR_NAME"));

					/*
					 * PayPostingFilelevelDetailsObject.setMode(resultset.getString
					 * (3));
					 */
					PayPostingFilelevelDetailsObject.setFileName(resultset
							.getString("ORIGINAL_FILE_NAME"));

					String date = resultset.getString("FILE_UPLOAD_DATE");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date date1 = dateString.parse(date);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateString1.format(date1);

					PayPostingFilelevelDetailsObject.setUploadedDate(finalDate);
//					reportslogger.info("dao impl date"
//							+ resultset.getString("FILE_UPLOAD_DATE"));
					PayPostingFilelevelDetailsObject.setApprovedBy(resultset.getString("APPROVED_BY"));
					
					if(resultset.getString("APPROVED_DATE")==null||resultset.getString("APPROVED_DATE").equalsIgnoreCase(""))
					{
						PayPostingFilelevelDetailsObject.setApprovedDate(resultset.getString("APPROVED_DATE"));
					}
					else
					{
					String approvedDate = resultset.getString("APPROVED_DATE");
					Date date2 = dateString.parse(approvedDate);
					String finalDate1 = dateString1.format(date2);
					PayPostingFilelevelDetailsObject.setApprovedDate(finalDate1);
					}
					
					
				//	PayPostingFilelevelDetailsObject.setApprovedDate(resultset.getString("APPROVED_DATE"));
					PayPostingFilelevelDetailsObject.setFileId(resultset
							.getString("FILE_ID"));
					PayPostingFilelevelDetailsObject.setUserCircle(resultset
							.getString("CIRCLE"));
					if(resultset.getString("PAYMENT_MODE").equalsIgnoreCase("OTHERS"))
						PayPostingFilelevelDetailsObject.setMode("MISCELLANEOUS");
					else
						PayPostingFilelevelDetailsObject.setMode(resultset
							.getString("PAYMENT_MODE"));
					
					PayPostingFilelevelDetailsObject
							.setRecordsPostedToFx(resultset
									.getInt("RECORDS_POSTED_FX"));
					PayPostingFilelevelDetailsObject
							.setValuePostedToFx(resultset
									.getString("VALUE_POSTED_FX"));
					PayPostingFilelevelDetailsObject
							.setRecordsPendingAtLiu(resultset
									.getInt("PENDING_LIU"));
					PayPostingFilelevelDetailsObject
							.setValuePendingAtLiu(resultset
									.getString("VALUE_PENDING_LIU"));
					PayPostingFilelevelDetailsObject
					.setValueDeletedAtLiu(resultset
							.getString("VALUE_DELETED_AT_LIU"));
					PayPostingFilelevelDetailsObject
					.setLiuDeleted(resultset
							.getInt("LIU_DELETED"));
					
					PayPostingFilelevelDetailsObject.setTotalValue(resultset
							.getString("TOTAL_VALUE"));
					//reportslogger.info("amount" + resultset.getString(14));
					PayPostingFilelevelDetailsObject.setTotalRecords(resultset
							.getInt("TOTAL_RECORDS"));
					PayPostingFilelevelDetailsObject.setInProgressRecords(resultset
							.getInt("INPROGRESS_RECORDS"));
					PayPostingFilelevelDetailsObject.setInProgressValue(resultset
							.getString("INPROGRESS_RECORDS_VALUE"));
					PayPostingFilelevelDetailsObject.setRejectedRecords(resultset
							.getInt("REJECTED_RECORDS"));
					PayPostingFilelevelDetailsObject.setRejectedValue(resultset
							.getString("REJECTED_VALUE"));

					PayPostingFilelevelDetailsObject.setStatus(resultset
							.getString("FILE_ACCEPTANCE_STATUS"));

					
				/*	reportslogger.info("records posted to fx"
							+ resultset.getInt("RECORDS_POSTED_FX"));
					reportslogger.info("value posted to fx"
							+ resultset.getDouble("VALUE_POSTED_FX"));
					//reportslogger.info("records pending at liu"
							//+ resultset.getInt("RECORDS_PENDING_LIU"));
					reportslogger.info("value pending at liu"
							+ resultset.getDouble("VALUE_PENDING_LIU"));*/

					excelDetailsList.add(PayPostingFilelevelDetailsObject);

				}
			}
			reportslogger.info("Payment Posting File level Excel Records list size in DaoImpl:" + excelDetailsList.size());

		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     } 
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return excelDetailsList;
	}

	/************** PAYMENT POSTING MODEWISE ******************************/

	public HashMap<Integer, List<PaymentPostingModewiseBean>> getPayPosModewiseSumDetails(
			PaymentPostingModewiseBean PayPosModewiseSumBeanObj, int page) {

		HashMap<Integer, List<PaymentPostingModewiseBean>> finalDetailsMap = new HashMap<Integer, List<PaymentPostingModewiseBean>>();
		List<PaymentPostingModewiseBean> detailsList = new ArrayList<PaymentPostingModewiseBean>();

		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		//reportslogger.info("page number in dao" + page);
		try {
			reportslogger.info("Payment Posting Mode Level Method in DaoImpl");
			//reportslogger.info("connection" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			/*reportslogger.info("connection established");

			reportslogger.info("mode in dao"
					+ PayPosModewiseSumBeanObj.getMode());*/

			// call proc
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_USER_FILE_MODE_DETAILS (?,?,?,?,?,?,?,?)}";

			 callableStatement = conn
					.prepareCall(procedureCall);

			/* callableStatement.setInt(1, page); */
			callableStatement.setString(1,
					PayPosModewiseSumBeanObj.getParentUserId());
			callableStatement.setString(2, PayPosModewiseSumBeanObj.getMode());
			callableStatement
					.setString(3, PayPosModewiseSumBeanObj.getToDate());
			callableStatement.setString(4,
					PayPosModewiseSumBeanObj.getFromDate());
			callableStatement.setInt(5, page);
			callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(7, Types.INTEGER);
			callableStatement.registerOutParameter(8, Types.VARCHAR);
			//reportslogger.info("before execute update");
			callableStatement.executeUpdate();
			//reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(7);

			String statusMsg = callableStatement.getString(8);// msg

			resultset = (ResultSet) callableStatement.getObject(6);

			PayPosModewiseSumBeanObj.setStatusMsg(statusMsg);

			// reportslogger.info("result set size"+resultset.getFetchSize());
			reportslogger.info("Error Msg at DaoImpl"+ PayPosModewiseSumBeanObj.getStatusMsg());
			/* reportslogger.info("totalpages:" + totalPages); */
			if (resultset == null) {
				reportslogger.info("Resultset is null in DaoImpl");

			} else {
				while (resultset != null && resultset.next()) {
					////reportslogger.info("inside while!");
					PaymentPostingModewiseBean PayPosModewiseSumBeanObject = new PaymentPostingModewiseBean();

					PayPosModewiseSumBeanObject.setMode(resultset.getString(2));
					PayPosModewiseSumBeanObject.setTotalRecords(resultset
							.getInt("TOTAL_RECORDS"));
					PayPosModewiseSumBeanObject.setInProgressRecords(resultset
							.getInt("IN_PROGRESS"));
					PayPosModewiseSumBeanObject.setInProgressValue(resultset
							.getString("IN_PROGRESS_VALUE"));
					PayPosModewiseSumBeanObject.setRejectedRecords(resultset
							.getInt("REJECTED_RECORDS"));
					PayPosModewiseSumBeanObject.setRejectedValue(resultset
							.getString("REJECTED_RECORDS_VALUE"));
					PayPosModewiseSumBeanObject.setTotalValue(resultset
							.getString("TOTAL_VALUE"));
					PayPosModewiseSumBeanObject.setRecordsPostedToFx(resultset
							.getInt("RECORDS_POSTED_FX"));
					PayPosModewiseSumBeanObject.setValuePostedToFx(resultset
							.getString("VALUE_POSTED_FX"));
					PayPosModewiseSumBeanObject
							.setRecordsPendingAtLiu(resultset
									.getInt("RECORDS_PENDING_LIU"));
					PayPosModewiseSumBeanObject.setValuePendingAtLiu(resultset
							.getString("VALUE_PENDING_LIU"));
					PayPosModewiseSumBeanObject
					.setRecDeletedAtLiu(resultset
							.getInt("RECORDS_DELETED_AT_LIU"));
					PayPosModewiseSumBeanObject
					.setValueDeletedAtLiu(resultset
							.getString("VALUE_DELETED_AT_LIU"));

					PayPosModewiseSumBeanObject
							.setStatusMsg(PayPosModewiseSumBeanObject
									.getStatusMsg());

					detailsList.add(PayPosModewiseSumBeanObject);
				}
			}
			reportslogger.info("Payment Posting Mode level Records list size in daoImpl:" + detailsList.size());

			finalDetailsMap.put(totalPages, detailsList);
		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     } 
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}

		return finalDetailsMap;

	}

	public List<PaymentPostingModewiseBean> getPayPosModewiseSumexcelDetails(
			PaymentPostingModewiseBean payPosModewiseSumBeanObj, int pageNo) {
		List<PaymentPostingModewiseBean> excelDetailsList = new ArrayList<PaymentPostingModewiseBean>();

		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		// reportslogger.info("page number in dao"+page);
		try {
			reportslogger.info("Payment Posting Mode Level Excel Download in DaoImpl");
			//reportslogger.info("connection" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			/*reportslogger.info("connection established");

			reportslogger.info("mode in dao"
					+ payPosModewiseSumBeanObj.getMode());*/

			// call proc
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_USER_FILE_MODE_DETAILS (?,?,?,?,?,?,?,?)}";

			callableStatement = conn
					.prepareCall(procedureCall);

			/* callableStatement.setInt(1, page); */
			callableStatement.setString(1,
					payPosModewiseSumBeanObj.getParentUserId());
			callableStatement.setString(2, payPosModewiseSumBeanObj.getMode());
			callableStatement
					.setString(3, payPosModewiseSumBeanObj.getToDate());
			callableStatement.setString(4,
					payPosModewiseSumBeanObj.getFromDate());
			callableStatement.setInt(5, pageNo);
			callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(7, Types.INTEGER);
			callableStatement.registerOutParameter(8, Types.VARCHAR);
			//reportslogger.info("before execute update");
			callableStatement.executeUpdate();
			//reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(7);

			String statusMsg = callableStatement.getString(8);// msg

			resultset = (ResultSet) callableStatement.getObject(6);

			payPosModewiseSumBeanObj.setStatusMsg(statusMsg);

			// reportslogger.info("result set size"+resultset.getFetchSize());
			reportslogger.info("Error Msg at DaoImpl" + payPosModewiseSumBeanObj.getStatusMsg());
			/* reportslogger.info("totalpages:" + totalPages); */
			if (resultset == null) {
				reportslogger.info("Resultset is null in DaoImpl");

			} else {
				while (resultset != null && resultset.next()) {
					////reportslogger.info("inside while!");
					PaymentPostingModewiseBean PayPosModewiseSumBeanObject = new PaymentPostingModewiseBean();

					if(resultset.getString("PAYMENT_MODE").equalsIgnoreCase("OTHERS"))
						PayPosModewiseSumBeanObject.setMode("MISCELLANEOUS");
					else
						PayPosModewiseSumBeanObject.setMode(resultset
							.getString("PAYMENT_MODE"));
					PayPosModewiseSumBeanObject.setTotalRecords(resultset
							.getInt("TOTAL_RECORDS"));
					PayPosModewiseSumBeanObject.setInProgressRecords(resultset
							.getInt("IN_PROGRESS"));
					PayPosModewiseSumBeanObject.setInProgressValue(resultset
							.getString("IN_PROGRESS_VALUE"));
					PayPosModewiseSumBeanObject.setRejectedRecords(resultset
							.getInt("REJECTED_RECORDS"));
					PayPosModewiseSumBeanObject.setRejectedValue(resultset
							.getString("REJECTED_RECORDS_VALUE"));
					PayPosModewiseSumBeanObject.setTotalValue(resultset
							.getString("TOTAL_VALUE"));
					PayPosModewiseSumBeanObject.setRecordsPostedToFx(resultset
							.getInt("RECORDS_POSTED_FX"));
					PayPosModewiseSumBeanObject.setValuePostedToFx(resultset
							.getString("VALUE_POSTED_FX"));
					PayPosModewiseSumBeanObject
							.setRecordsPendingAtLiu(resultset
									.getInt("RECORDS_PENDING_LIU"));
					PayPosModewiseSumBeanObject.setValuePendingAtLiu(resultset
							.getString("VALUE_PENDING_LIU"));
					PayPosModewiseSumBeanObject
					.setRecDeletedAtLiu(resultset
							.getInt("RECORDS_DELETED_AT_LIU"));
					PayPosModewiseSumBeanObject
					.setValueDeletedAtLiu(resultset
							.getString("VALUE_DELETED_AT_LIU"));
					PayPosModewiseSumBeanObject
							.setStatusMsg(PayPosModewiseSumBeanObject
									.getStatusMsg());

					excelDetailsList.add(PayPosModewiseSumBeanObject);
				}
			}
			reportslogger.info("Payment Posting Excel Records list size in DaoImpl:" + excelDetailsList.size());

		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     }
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}

		return excelDetailsList;

	}

	/***************************** PAYMENT REVERSAL FILE LEVEL ***********************************/

	public List<String> reversalTypeList() {

		List<String> reversalTypeList = new ArrayList<String>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		try {
reportslogger.info("Payment Reversal Type List in DaoImpl");
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("entered PayReversalFilelevelDaoImpl");

			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.PAYMENT_REVERSALTYPE_LIST(?,?,?)}";

			 callableStatement = conn
					.prepareCall(procedureCall);
			callableStatement.registerOutParameter(1, Types.VARCHAR);
			callableStatement.registerOutParameter(2, Types.VARCHAR);
			callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
			callableStatement.executeUpdate();
		//	reportslogger.info("callable statements executed");

			resultset = (ResultSet) callableStatement.getObject(3);
			while (resultset.next()) {
				reversalTypeList.add(resultset.getString("REVERSAL_TYPE"));
			}

		} catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return reversalTypeList;
	}

	public HashMap<Integer, List<PaymentReversalFileLevelBean>> getPayReversalFilelevelDetails(
			PaymentReversalFileLevelBean payReversalFileLevelBeanObj, int page) {
		HashMap<Integer, List<PaymentReversalFileLevelBean>> finalDetailsMap = new HashMap<Integer, List<PaymentReversalFileLevelBean>>();
		List<PaymentReversalFileLevelBean> detailsList = new ArrayList<PaymentReversalFileLevelBean>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		//reportslogger.info("page number in dao" + page);

		try {
			reportslogger.info("Payment Reversal File level Details Method in DaoImpl");
			//reportslogger.info("connection" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			/*reportslogger.info("connection established");
			reportslogger.info("in dao child userid"
					+ payReversalFileLevelBeanObj.getChildUserId());*/

			// call proc
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_PAYMENT_REV_FILE_DETAILS(?,?,?,?,?,?,?,?,?,?,?,?)}";

			callableStatement = conn
					.prepareCall(procedureCall);

			/* callableStatement.setInt(1, page); */
			callableStatement.setString(1,
					payReversalFileLevelBeanObj.getParentUserId());
			callableStatement.setString(2,
					payReversalFileLevelBeanObj.getChildUserId());
			callableStatement.setString(3,
					payReversalFileLevelBeanObj.getFileId());
			callableStatement.setString(4,
					payReversalFileLevelBeanObj.getFileName());
			callableStatement.setString(5,
					payReversalFileLevelBeanObj.getReversalType());
			callableStatement.setString(6,
					payReversalFileLevelBeanObj.getVendorId());
			callableStatement.setString(7,
					payReversalFileLevelBeanObj.getToDate());
			callableStatement.setString(8,
					payReversalFileLevelBeanObj.getFromDate());
			callableStatement.setInt(9, page);
			callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(11, Types.INTEGER);
			callableStatement.registerOutParameter(12, Types.VARCHAR);
			//reportslogger.info("before execute update");
			callableStatement.executeUpdate();
			//reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(11);

			String statusMsg = callableStatement.getString(12);// msg

			resultset = (ResultSet) callableStatement.getObject(10);

			payReversalFileLevelBeanObj.setStatusMsg(statusMsg);

			// reportslogger.info("result set size"+resultset.getFetchSize());
			reportslogger.info("Error Msg at DaoImpl"+ payReversalFileLevelBeanObj.getStatusMsg());
			/* reportslogger.info("totalpages:" + totalPages); */
			if (resultset == null) {
				reportslogger.info("Resultset is null in Dao Impl");

			} else {

				while (resultset != null && resultset.next()) {
					////reportslogger.info("inside while!");
					PaymentReversalFileLevelBean PayReversalFileLevelBeanObject = new PaymentReversalFileLevelBean();
					PayReversalFileLevelBeanObject.setChildUserId(resultset
							.getString("USER_ID"));
					PayReversalFileLevelBeanObject.setFileId(resultset
							.getString("FILE_ID"));
					PayReversalFileLevelBeanObject.setReversalType(resultset
							.getString("FILE_TYPE"));
					PayReversalFileLevelBeanObject.setUploadedByOlmId(resultset
							.getString("USER_ID"));
					PayReversalFileLevelBeanObject.setUploadedByName(resultset
							.getString("USER_NAME"));
					String date = resultset.getString("UPLOAD_DATE");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date date1 = dateString.parse(date);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateString1.format(date1);

					PayReversalFileLevelBeanObject.setUploadTime(finalDate);
					PayReversalFileLevelBeanObject.setFileName(resultset
							.getString("FILE_NAME"));
					PayReversalFileLevelBeanObject.setTotalRecords(resultset
							.getInt("TOTAL_RECORDS"));
					PayReversalFileLevelBeanObject.setTotalValue(resultset
							.getString("TOTAL_AMOUNT"));
					PayReversalFileLevelBeanObject.setStatus(resultset
							.getString("STATUS"));
					PayReversalFileLevelBeanObject
							.setSuccessRecordCount(resultset
									.getInt("SUCCESS_REC_COUNT"));
					PayReversalFileLevelBeanObject
							.setSuccessRecordValue(resultset
									.getString("SUCCESS_REC_VALUE"));
					PayReversalFileLevelBeanObject
							.setFailureRecordCount(resultset
									.getInt("FAILURE_REC_COUNT"));
					PayReversalFileLevelBeanObject
							.setFailureRecordValue(resultset
									.getString("FAILURE_REC_VALUE"));
					PayReversalFileLevelBeanObject
					.setVendorId(resultset
							.getString("VENDOR_ID"));
					PayReversalFileLevelBeanObject.setInProgressRecords(resultset
							.getInt("INPROGRESS_RECORDS"));
					PayReversalFileLevelBeanObject.setInProgressValue(resultset
							.getString("INPROGRESS_RECORDS_VALUE"));

					detailsList.add(PayReversalFileLevelBeanObject);
				}
			}
			reportslogger.info("Payment Reversal file level details list size in DaoImpl :" + detailsList.size());

			finalDetailsMap.put(totalPages, detailsList);
		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     } 
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return finalDetailsMap;
	}

	public List<PayRevDirectTransRecordsDownload> getDirectRevTransLevelRecords(
			String fileID) {
		List<PayRevDirectTransRecordsDownload> PayDirectRevTransLevelDetailsList = new ArrayList<PayRevDirectTransRecordsDownload>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		try {
			reportslogger.info(" Payment Reversal File level Direct Reversal Records Download" );
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("entered transRecords download file");
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_PAY_DIRECT_REV_DOWNLOAD(?,?,?)}";

			callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1, fileID);
			//reportslogger.info("file id in liu dao" + fileID);

			callableStatement.registerOutParameter(2, OracleTypes.CURSOR);

			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.executeUpdate();

			//reportslogger.info("callable statements executed");

			resultset = (ResultSet) callableStatement.getObject(2);

			String statusMessage = callableStatement.getString(3);

			reportslogger.info("Error Msg at DaoImpl:" + statusMessage);
			if (resultset == null) {
				reportslogger.info("Resultset is null in daoImpl");

			} else {

				while (resultset != null && resultset.next()) {
					//reportslogger.info("inside while!");
					PayRevDirectTransRecordsDownload PayDirectRevTransRecordsObj = new PayRevDirectTransRecordsDownload();
					PayDirectRevTransRecordsObj.setAccountNumber(resultset
							.getString("ACCT_EXT_ID"));

					PayDirectRevTransRecordsObj.setTrackingId(resultset
							.getString("TRACKING_ID"));

					PayDirectRevTransRecordsObj.setTrackingIdServ(resultset
							.getString("TRACKING_ID_SERV"));
					PayDirectRevTransRecordsObj.setUploadedByOlmId(resultset
							.getString("VENDOR_USERID"));
					PayDirectRevTransRecordsObj.setUploadedByName(resultset
							.getString("USER_NAME"));
					PayDirectRevTransRecordsObj.setFileId(resultset
							.getString("FILE_ID"));
					PayDirectRevTransRecordsObj.setFileName(resultset
							.getString("ORIGINAL_FILE_NAME"));
					String date = resultset.getString("FILE_UPLOAD_DATE");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date date1 = dateString.parse(date);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateString1.format(date1);
					PayDirectRevTransRecordsObj.setUploadDateTime(finalDate);
					/*if (resultset.getString("PAYMENT_POSTED_DATE") != null) {
						String StringPosted = resultset
								.getString("PAYMENT_POSTED_DATE");

						Date datePosted = dateString.parse(StringPosted);

						String finalDate1 = dateString1.format(datePosted);
						PayDirectRevTransRecordsObj.setFxUpdateTime(finalDate1);
					} else
						PayDirectRevTransRecordsObj.setFxUpdateTime("");*/
					PayDirectRevTransRecordsObj.setStatus(resultset
							.getString("STATUS"));
					PayDirectRevTransRecordsObj.setReasonForFailue(resultset
							.getString("REASON_FOR_FAILURE"));
					// reportslogger.info("uploaded date time"+PayDirectRevTransRecordsObj.getUplodedDateTime());

					PayDirectRevTransLevelDetailsList
							.add(PayDirectRevTransRecordsObj);

				}
			}
			reportslogger.info("Payment Reversal File level Direct Reversal Records list size in DaoImpl:"
					+ PayDirectRevTransLevelDetailsList.size());

		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     } 
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return PayDirectRevTransLevelDetailsList;
	}

	public List<PayRevChequeBounceDetailsDownload> getChequeBounceTransLevelRecords(
			String fileID) {
		List<PayRevChequeBounceDetailsDownload> PayChequeBounceTransLevelDetailsList = new ArrayList<PayRevChequeBounceDetailsDownload>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		try {
			reportslogger.info("Payment Reversal File level Cheque Bounce Details Download in DaoImpl");
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			reportslogger.info("entered transRecords download file");
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_PAY_REV_CHQ_BNC_DOWNLOAD(?,?,?)}";

			 callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1, fileID);
			//reportslogger.info("file id in liu dao" + fileID);

			callableStatement.registerOutParameter(2, OracleTypes.CURSOR);

			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.executeUpdate();

			//reportslogger.info("callable statements executed");

			resultset = (ResultSet) callableStatement.getObject(2);

			String statusMessage = callableStatement.getString(3);

			reportslogger.info("Error Msg at DaoImpl:" + statusMessage);
			if (resultset == null) {
				reportslogger.info("Resultset is null in DaoImpl");

			} else {

				while (resultset != null && resultset.next()) {
					PayRevChequeBounceDetailsDownload PymntRevChqBounceRecordsDetailsObject = new PayRevChequeBounceDetailsDownload();
					PymntRevChqBounceRecordsDetailsObject
					.setUploadedUser(resultset
							.getString("VENDOR_USERID"));
					PymntRevChqBounceRecordsDetailsObject
					.setFileId(resultset
							.getString("FILE_ID"));
					PymntRevChqBounceRecordsDetailsObject
					.setVendorId(resultset
							.getString("VENDOR_ID"));
					
			PymntRevChqBounceRecordsDetailsObject
					.setVendorName(resultset.getString("VENDOR_NAME"));
			int lob_mo = resultset.getInt("LOB_MO");
			int lob_fl = resultset.getInt("LOB_FL");
			int lob_istm = resultset.getInt("LOB_ISTM");
			int lob_aes=resultset.getInt("LOB_AES");
			
			
			if(((lob_mo + lob_fl) > 1) || ((lob_istm + lob_mo) > 1) || ((lob_aes + lob_mo) > 1) || ((lob_fl + lob_istm) > 1)|| ((lob_aes + lob_fl) > 1) || ((lob_istm + lob_aes) > 1) )
					{
				if(lob_mo>1&&lob_fl<1&&lob_istm<1&&lob_aes<1){
					PymntRevChqBounceRecordsDetailsObject.setLob("MOB");
				}else if(lob_mo<1&&lob_fl>1&&lob_istm<1&&lob_aes<1)
					PymntRevChqBounceRecordsDetailsObject.setLob("FL");
				else if(lob_mo<1&&lob_fl<1&&lob_istm>1&&lob_aes<1)
					PymntRevChqBounceRecordsDetailsObject.setLob("ISTM");
				else if(lob_mo<1&&lob_fl<1&&lob_istm<1&&lob_aes>1)
					PymntRevChqBounceRecordsDetailsObject.setLob("AES");
				else
					PymntRevChqBounceRecordsDetailsObject.setLob("Multiple");
			
			}else if(lob_mo==1)
				PymntRevChqBounceRecordsDetailsObject.setLob("MOB");
			else if(lob_fl==1)
				PymntRevChqBounceRecordsDetailsObject.setLob("FL");
			else if(lob_istm==1)
				PymntRevChqBounceRecordsDetailsObject.setLob("ISTM");
			else if(lob_aes==1)
				PymntRevChqBounceRecordsDetailsObject.setLob("AES");
			
			PymntRevChqBounceRecordsDetailsObject.setFileName(resultset
					.getString("REVERSAL_FILE_NAME"));
			PymntRevChqBounceRecordsDetailsObject.setRefNo(resultset
					.getString("REF_NUMBER"));
			PymntRevChqBounceRecordsDetailsObject.setBankName(resultset
					.getString("BANK_NAME"));

			String date = resultset.getString("CHEQUE_DATE");
			SimpleDateFormat dateStringChqDate = new SimpleDateFormat(
					"yyyy-MM-dd");
			SimpleDateFormat dateStringChqDate1 = new SimpleDateFormat(
					"dd/MM/yyyy");
			
			SimpleDateFormat dateString = new SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss");
			Date date1 = dateStringChqDate.parse(date);
			SimpleDateFormat dateString1 = new SimpleDateFormat(
					"dd/MM/yyyy HH:mm:ss");
			String finalDate = dateStringChqDate1.format(date1);

			PymntRevChqBounceRecordsDetailsObject
					.setDateonChq(finalDate);

			/*PymntRevChqBounceRecordsDetailsObject
					.setNoOfAccPostedFx(resultset
							.getInt("ACCT_EXT_IDS"));
			PymntRevChqBounceRecordsDetailsObject
					.setNoOfInvPostedFx(resultset.getInt("INVOICE_NOS"));*/
			PymntRevChqBounceRecordsDetailsObject
					.setTotChqVal(resultset.getString("PAYMENT_AMOUNT"));

			if (resultset.getString("INITIAL_FILE_UPLOAD_DATE") != null)
					 {
				String initialUplddate = resultset
						.getString("INITIAL_FILE_UPLOAD_DATE");
				
				Date initialUplddate1 = dateString
						.parse(initialUplddate);
				
				String finalDate1 = dateString1
						.format(initialUplddate1);

				PymntRevChqBounceRecordsDetailsObject
						.setInitialUploadedDate(finalDate1);
			} else
				PymntRevChqBounceRecordsDetailsObject
						.setInitialUploadedDate("");

			if (resultset.getString("INITIAL_POSTED_DATE") != null)
					 {
				String initialPstddate = resultset
						.getString("INITIAL_POSTED_DATE");
				Date initialPstddate1 = dateString
						.parse(initialPstddate);
				String finalDate2 = dateString1
						.format(initialPstddate1);

				PymntRevChqBounceRecordsDetailsObject
						.setInitialPostedDate(finalDate2);
			} else
				PymntRevChqBounceRecordsDetailsObject
						.setInitialPostedDate("");

			if (resultset.getString("BOUNCED_DATE") != null) {

				String bounceddate = resultset
						.getString("BOUNCED_DATE");
				Date bounceddate1 = dateStringChqDate.parse(bounceddate);
				String finalDate3 = dateStringChqDate1.format(bounceddate1);

				PymntRevChqBounceRecordsDetailsObject
						.setBouncedDate(finalDate3);
			} else
				PymntRevChqBounceRecordsDetailsObject
						.setBouncedDate("");

			if (resultset.getString("BOUNCED_MIS_DATE") != null) {
				
				
				String bouncedMisddate = resultset
						.getString("BOUNCED_MIS_DATE");
				Date bouncedMisddate1 = dateString
						.parse(bouncedMisddate);
				String finalDate2 = dateString1
						.format(bouncedMisddate1);

				PymntRevChqBounceRecordsDetailsObject
						.setBounceMisDate(finalDate2);

				
						
			} else
				PymntRevChqBounceRecordsDetailsObject
						.setBounceMisDate("");

			/*if (resultset.getString("REVERSAL_DATE") != null)
				 {

				String revDate = resultset.getString("REVERSAL_DATE");
				Date revDate1 = dateString.parse(revDate);
				String finalDate5 = dateString1.format(revDate1);
				
				PymntRevChqBounceRecordsDetailsObject
						.setRevPostingFxDate(finalDate5);
			} else
				PymntRevChqBounceRecordsDetailsObject
						.setRevPostingFxDate("");*/

			PymntRevChqBounceRecordsDetailsObject
					.setDiffInitalVsBouncedDate(resultset
							.getInt("DIFF_INIT_FILE_DATE_BOUNC_DATE"));
			PymntRevChqBounceRecordsDetailsObject
					.setDiffBouncedVsBouncdMisDate(resultset
							.getInt("DIFF_BOUNC_DATE_BOUNC_MIS_DATE"));
			/*PymntRevChqBounceRecordsDetailsObject
					.setDiffBouncedVspostingRevDate(resultset
							.getInt("DIFF_BOUNC_DATE_REV_DATE"));
			PymntRevChqBounceRecordsDetailsObject
					.setDiffBounceMisDateVspostingRevDate(resultset
							.getInt("DIFF_BOUNC_MIS_DATE_REV_DATE"));*/
			PymntRevChqBounceRecordsDetailsObject.setStatus(resultset
					.getString("CHQ_STATUS"));
			PymntRevChqBounceRecordsDetailsObject.setReasonForFailure(resultset.getString("CHQ_BNC_ERR_REASON_CODE"));
			PymntRevChqBounceRecordsDetailsObject.setBankAccNo(resultset.getString("BANK_VIRTUAL_ACCOUNT_NO"));
			
					PayChequeBounceTransLevelDetailsList
							.add(PymntRevChqBounceRecordsDetailsObject);

				}
			}
			reportslogger.info("Payment Reversal File level Cheque Bounce Records list size in DaoImpl:"
					+ PayChequeBounceTransLevelDetailsList.size());

		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     } 
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return PayChequeBounceTransLevelDetailsList;
	}

	public List<PaymentReversalFileLevelBean> getPayReversalFilelevelExcelDetails(
			PaymentReversalFileLevelBean payReversalFileLevelBeanObj,
			String pageNo) {
		List<PaymentReversalFileLevelBean> excelDetailsList = new ArrayList<PaymentReversalFileLevelBean>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		//reportslogger.info("page number in dao" + pageNo);

		try {
			reportslogger.info("Payment Reversal File level Excel Download in daoImpl");
			//reportslogger.info("connection" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			/*reportslogger.info("connection established");
			reportslogger.info("in dao child userid"
					+ payReversalFileLevelBeanObj.getChildUserId());*/

			// call proc
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_PAYMENT_REV_FILE_DETAILS(?,?,?,?,?,?,?,?,?,?,?,?)}";

			callableStatement = conn
					.prepareCall(procedureCall);

			/* callableStatement.setInt(1, page); */
			callableStatement.setString(1,
					payReversalFileLevelBeanObj.getParentUserId());
			callableStatement.setString(2,
					payReversalFileLevelBeanObj.getChildUserId());
			callableStatement.setString(3,
					payReversalFileLevelBeanObj.getFileId());
			callableStatement.setString(4,
					payReversalFileLevelBeanObj.getFileName());
			callableStatement.setString(5,
					payReversalFileLevelBeanObj.getReversalType());
			callableStatement.setString(6,
					payReversalFileLevelBeanObj.getVendorId());
			callableStatement.setString(7,
					payReversalFileLevelBeanObj.getToDate());
			callableStatement.setString(8,
					payReversalFileLevelBeanObj.getFromDate());
			callableStatement.setString(9, pageNo);
			callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(11, Types.INTEGER);
			callableStatement.registerOutParameter(12, Types.VARCHAR);
			//reportslogger.info("before execute update");
			callableStatement.executeUpdate();
			//reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(11);

			String statusMsg = callableStatement.getString(12);// msg

			resultset = (ResultSet) callableStatement.getObject(10);

			payReversalFileLevelBeanObj.setStatusMsg(statusMsg);

			// reportslogger.info("result set size"+resultset.getFetchSize());
			reportslogger.info("Error Msg at DaoImpl"
					+ payReversalFileLevelBeanObj.getStatusMsg());
			/* reportslogger.info("totalpages:" + totalPages); */
			if (resultset == null) {
				reportslogger.info("Resultset is null in DaoImpl");

			} else {

				while (resultset != null && resultset.next()) {
					//reportslogger.info("inside while!");
					PaymentReversalFileLevelBean PayReversalFileLevelBeanObject = new PaymentReversalFileLevelBean();
					PayReversalFileLevelBeanObject.setChildUserId(resultset
							.getString("USER_ID"));
					PayReversalFileLevelBeanObject.setFileId(resultset
							.getString("FILE_ID"));
					PayReversalFileLevelBeanObject.setReversalType(resultset
							.getString("FILE_TYPE"));

					PayReversalFileLevelBeanObject.setUploadedByOlmId(resultset
							.getString("USER_ID"));
					PayReversalFileLevelBeanObject.setUploadedByName(resultset
							.getString("USER_NAME"));
					PayReversalFileLevelBeanObject.setUploadTime(resultset
							.getString("UPLOAD_DATE"));
					PayReversalFileLevelBeanObject.setFileName(resultset
							.getString("FILE_NAME"));
					PayReversalFileLevelBeanObject.setTotalRecords(resultset
							.getInt("TOTAL_RECORDS"));
					PayReversalFileLevelBeanObject.setTotalValue(resultset
							.getString("TOTAL_AMOUNT"));
					PayReversalFileLevelBeanObject.setStatus(resultset
							.getString("STATUS"));
					PayReversalFileLevelBeanObject
							.setSuccessRecordCount(resultset
									.getInt("SUCCESS_REC_COUNT"));
					PayReversalFileLevelBeanObject
							.setSuccessRecordValue(resultset
									.getString("SUCCESS_REC_VALUE"));
					PayReversalFileLevelBeanObject
							.setFailureRecordCount(resultset
									.getInt("FAILURE_REC_COUNT"));
					PayReversalFileLevelBeanObject
							.setFailureRecordValue(resultset
									.getString("FAILURE_REC_VALUE"));
					PayReversalFileLevelBeanObject
					.setVendorId(resultset
							.getString("VENDOR_ID"));
					PayReversalFileLevelBeanObject.setInProgressRecords(resultset
							.getInt("INPROGRESS_RECORDS"));
					PayReversalFileLevelBeanObject.setInProgressValue(resultset
							.getString("INPROGRESS_RECORDS_VALUE"));

					excelDetailsList.add(PayReversalFileLevelBeanObject);
				}
			}
			reportslogger.info("Payment Reversal File level Excel Records list size in DaoImpl:" + excelDetailsList.size());

		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     }
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return excelDetailsList;
	}

	/* <*****methods in payment posting transaction level****> */

	public HashMap<Integer, List<PayPostingTransLevelDetails>> getPaymntPostingTranslevelMap(
			PayPostingTransLevelDetails PymntPostingTransLevelDetailsObj,
			int page) {

		HashMap<Integer, List<PayPostingTransLevelDetails>> ReportsMap = new HashMap<Integer, List<PayPostingTransLevelDetails>>();
		List<PayPostingTransLevelDetails> DetailsList = new ArrayList<PayPostingTransLevelDetails>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;

		//reportslogger.info("page number in dao:" + page);

		try {
			reportslogger.info("Payment Posting Trans Level Method  In DaoImpl");
			//reportslogger.info("connection:" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("connection established");

			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_USER_FILE_RECORD_DETAILS(?,?,?,?,?,?,?,?,?,?,?,?,?)}";

			callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1,
					PymntPostingTransLevelDetailsObj.getParentUserId());
			callableStatement.setString(2,
					PymntPostingTransLevelDetailsObj.getChildUserId());
			callableStatement.setString(3,
					PymntPostingTransLevelDetailsObj.getFileId());
			callableStatement.setString(4,
					PymntPostingTransLevelDetailsObj.getFileName());
			callableStatement.setString(5,
					PymntPostingTransLevelDetailsObj.getRefNo());
			callableStatement.setString(6,
					PymntPostingTransLevelDetailsObj.getMode());
			callableStatement.setString(7,
					PymntPostingTransLevelDetailsObj.getVendorId());
			callableStatement.setString(8,
					PymntPostingTransLevelDetailsObj.getToDate());
			callableStatement.setString(9,
					PymntPostingTransLevelDetailsObj.getFromDate());
			callableStatement.setInt(10, page);
			callableStatement.registerOutParameter(11, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(12, Types.INTEGER);
			callableStatement.registerOutParameter(13, Types.VARCHAR);
			callableStatement.executeUpdate();

			//reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(12);

			//reportslogger.info("totalpages got from proc:" + totalPages);

			resultset = (ResultSet) callableStatement.getObject(11);

			PymntPostingTransLevelDetailsObj.setStatusMsg(callableStatement
					.getString(13));

			reportslogger.info("Error Msg at DaoImpl"
					+ PymntPostingTransLevelDetailsObj.getStatusMsg());

			if (resultset == null) {
				reportslogger.info("Resultset is null in DaoImpl");

			} else {

				while (resultset != null && resultset.next()) {
					//reportslogger.info("inside while!");
					PayPostingTransLevelDetails PymntPostingTransLevelDetailsObject = new PayPostingTransLevelDetails();

					PymntPostingTransLevelDetailsObject.setRefNo(resultset
							.getString("REF_NUMBER"));
					PymntPostingTransLevelDetailsObject.setVendorId(resultset
							.getString("VENDOR_ID"));
					/*
					 * reportslogger.info("vendor id"+
					 * PymntPostingTransLevelDetailsObject.getVendorId());
					 */
					PymntPostingTransLevelDetailsObject.setVendorName(resultset
							.getString("VENDOR_NAME"));
					PymntPostingTransLevelDetailsObject
							.setChildUserId(resultset.getString("USER_ID"));
					PymntPostingTransLevelDetailsObject.setFileId(resultset
							.getString("FILE_ID"));
					PymntPostingTransLevelDetailsObject.setFileName(resultset
							.getString("ORIGINAL_FILE_NAME"));
					PymntPostingTransLevelDetailsObject.setFileSource(resultset
							.getString("FILE_SOURCE"));
				
					PymntPostingTransLevelDetailsObject.setMode(resultset
							.getString("PAYMENT_MODE"));
					String date = resultset.getString("FILE_UPLOAD_DATE");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date date1 = dateString.parse(date);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateString1.format(date1);
					PymntPostingTransLevelDetailsObject
							.setUploadTime(finalDate);
					PymntPostingTransLevelDetailsObject.setApprovedBy(resultset
							.getString("APPROVED_BY"));
					
					
					if(resultset.getString("APPROVED_DATE")==null||resultset.getString("APPROVED_DATE").equalsIgnoreCase(""))
					{
						PymntPostingTransLevelDetailsObject.setApprovedDate(resultset.getString("APPROVED_DATE"));
					}
					else
					{
						String approvedDate = resultset.getString("APPROVED_DATE");
						Date date2 = dateString.parse(approvedDate);
						String approvedFinalDate = dateString1.format(date2);
						PymntPostingTransLevelDetailsObject.setApprovedDate(approvedFinalDate);
					}
					
					
				//	PymntPostingTransLevelDetailsObject.setApprovedDate(resultset.getString("APPROVED_DATE"));
					PymntPostingTransLevelDetailsObject.setAccountNo(resultset
							.getString("ACCT_EXT_ID"));
					PymntPostingTransLevelDetailsObject.setInvoice(resultset
							.getString("INVOICE_NO"));
					PymntPostingTransLevelDetailsObject.setTotalVal(resultset
							.getString("PAYMENT_AMOUNT"));
					PymntPostingTransLevelDetailsObject.setStatus(resultset
							.getString("STATUS"));
					/*
					 * if(resultset.getString("PAYMENT_POSTED_DATE")==null){
					 * }else{String
					 * date[]=resultset.getString("PAYMENT_POSTED_DATE"
					 * ).split(" ");
					 * PymntPostingTransLevelDetailsObject.setFXpostingTime
					 * (date[0]);}
					 */

					if (resultset.getString("PAYMENT_POSTED_DATE") != null) {
						String StringPosted = resultset
								.getString("PAYMENT_POSTED_DATE");
						Date datePosted = dateString.parse(StringPosted);
						String finalDate1 = dateString1.format(datePosted);
						PymntPostingTransLevelDetailsObject
								.setFXpostingTime(finalDate1);
					} else
						PymntPostingTransLevelDetailsObject
								.setFXpostingTime(resultset
										.getString("PAYMENT_POSTED_DATE"));
					PymntPostingTransLevelDetailsObject.setTrackingId(resultset
							.getString("TRACKING_ID"));
					PymntPostingTransLevelDetailsObject
							.setTrackingIdServ(resultset
									.getString("TRACKING_ID_SERV"));
					PymntPostingTransLevelDetailsObject
							.setReasonForLiuorFailure(resultset
									.getString("LIU_REASON"));
					PymntPostingTransLevelDetailsObject.setBankAccNo(resultset.getString("BANK_ACCOUNT_NUMBER"));
					if(resultset.getString("LOB")==null||resultset.getString("LOB").equalsIgnoreCase(""))
					{
						PymntPostingTransLevelDetailsObject.setLob("");
					}
					else
					{
					if(resultset.getString("LOB").equalsIgnoreCase("BTS"))
					{
						PymntPostingTransLevelDetailsObject.setLob("FL");
					}
					else
					PymntPostingTransLevelDetailsObject.setLob(resultset.getString("LOB"));
					}

					DetailsList.add(PymntPostingTransLevelDetailsObject);
				}
			}
			reportslogger.info("Payment Posting Trans level Records list size in DaoImpl:" + DetailsList.size());

			ReportsMap.put(totalPages, DetailsList);
		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     } 
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return ReportsMap;

	}

	public List<PayPostingTransLevelDetails> getPayPostTransactionExcelList(
			PayPostingTransLevelDetails PymntPostingTransLevelDetailsObj,
			String pageNum) {

		List<PayPostingTransLevelDetails> PayPostTransactionExcelList = new ArrayList<PayPostingTransLevelDetails>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;

		//reportslogger.info("page number in dao:" + pageNum);

		try {
			reportslogger.info("Payment Posting Trans Level Excel Download in DaoImpl");
			//reportslogger.info("connection:" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			/*reportslogger.info("connection established");*/

			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_USER_FILE_RECORD_DETAILS(?,?,?,?,?,?,?,?,?,?,?,?,?)}";

			callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1,
					PymntPostingTransLevelDetailsObj.getParentUserId());
			callableStatement.setString(2,
					PymntPostingTransLevelDetailsObj.getChildUserId());
			callableStatement.setString(3,
					PymntPostingTransLevelDetailsObj.getFileId());
			callableStatement.setString(4,
					PymntPostingTransLevelDetailsObj.getFileName());
			callableStatement.setString(5,
					PymntPostingTransLevelDetailsObj.getRefNo());
			callableStatement.setString(6,
					PymntPostingTransLevelDetailsObj.getMode());
			callableStatement.setString(7,
					PymntPostingTransLevelDetailsObj.getVendorId());
			callableStatement.setString(8,
					PymntPostingTransLevelDetailsObj.getToDate());
			callableStatement.setString(9,
					PymntPostingTransLevelDetailsObj.getFromDate());
			callableStatement.setString(10, pageNum);
			callableStatement.registerOutParameter(11, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(12, Types.INTEGER);
			callableStatement.registerOutParameter(13, Types.VARCHAR);
			callableStatement.executeUpdate();

			//reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(12);

			//reportslogger.info("totalpages got from proc:" + totalPages);

			resultset = (ResultSet) callableStatement.getObject(11);

			PymntPostingTransLevelDetailsObj.setStatusMsg(callableStatement
					.getString(13));

			reportslogger.info("Error Msg at DaoImpl:"
					+ PymntPostingTransLevelDetailsObj.getStatusMsg());

			if (resultset == null) {
				reportslogger.info("Resultset is null in daoImpl");

			} else {

				while (resultset != null && resultset.next()) {
					//reportslogger.info("inside while!");
					PayPostingTransLevelDetails PymntPostingTransLevelDetailsObject = new PayPostingTransLevelDetails();

					PymntPostingTransLevelDetailsObject.setRefNo(resultset
							.getString("REF_NUMBER"));
					PymntPostingTransLevelDetailsObject.setVendorId(resultset
							.getString("VENDOR_ID"));
					/*
					 * reportslogger.info("vendor id"+
					 * PymntPostingTransLevelDetailsObject.getVendorId());
					 */
					PymntPostingTransLevelDetailsObject.setVendorName(resultset
							.getString("VENDOR_NAME"));
					PymntPostingTransLevelDetailsObject
							.setChildUserId(resultset.getString("USER_ID"));
					PymntPostingTransLevelDetailsObject.setFileId(resultset
							.getString("FILE_ID"));
					PymntPostingTransLevelDetailsObject.setFileName(resultset
							.getString("ORIGINAL_FILE_NAME"));
					PymntPostingTransLevelDetailsObject.setFileSource(resultset
							.getString("FILE_SOURCE"));
					if(resultset.getString("PAYMENT_MODE").equalsIgnoreCase("OTHERS"))
						PymntPostingTransLevelDetailsObject.setMode("MISCELLANEOUS");
					else
					PymntPostingTransLevelDetailsObject.setMode(resultset
							.getString("PAYMENT_MODE"));
					String date = resultset.getString("FILE_UPLOAD_DATE");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date date1 = dateString.parse(date);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateString1.format(date1);
					PymntPostingTransLevelDetailsObject
							.setUploadTime(finalDate);
					PymntPostingTransLevelDetailsObject.setApprovedBy(resultset
							.getString("APPROVED_BY"));
					
					if(resultset.getString("APPROVED_DATE")==null||resultset.getString("APPROVED_DATE").equalsIgnoreCase(""))
					{
						PymntPostingTransLevelDetailsObject.setApprovedDate(resultset.getString("APPROVED_DATE"));
					}
					else
					{
						String approvedDate = resultset.getString("APPROVED_DATE");
						Date date2 = dateString.parse(approvedDate);
						String approvedFinalDate = dateString1.format(date2);
						PymntPostingTransLevelDetailsObject.setApprovedDate(approvedFinalDate);
					}
					
					//PymntPostingTransLevelDetailsObject.setApprovedDate(resultset.getString("APPROVED_DATE"));
					PymntPostingTransLevelDetailsObject.setAccountNo(resultset
							.getString("ACCT_EXT_ID"));
					PymntPostingTransLevelDetailsObject.setInvoice(resultset
							.getString("INVOICE_NO"));
					PymntPostingTransLevelDetailsObject.setTotalVal(resultset
							.getString("PAYMENT_AMOUNT"));
					PymntPostingTransLevelDetailsObject.setStatus(resultset
							.getString("STATUS"));
					/*
					 * if(resultset.getString("PAYMENT_POSTED_DATE")==null){
					 * }else{String
					 * date[]=resultset.getString("PAYMENT_POSTED_DATE"
					 * ).split(" ");
					 * PymntPostingTransLevelDetailsObject.setFXpostingTime
					 * (date[0]);}
					 */

					if (resultset.getString("PAYMENT_POSTED_DATE") != null) {
						String StringPosted = resultset
								.getString("PAYMENT_POSTED_DATE");
						Date datePosted = dateString.parse(StringPosted);
						String finalDate1 = dateString1.format(datePosted);
						PymntPostingTransLevelDetailsObject
								.setFXpostingTime(finalDate1);
					} else
						PymntPostingTransLevelDetailsObject
								.setFXpostingTime(resultset
										.getString("PAYMENT_POSTED_DATE"));
					PymntPostingTransLevelDetailsObject.setTrackingId(resultset
							.getString("TRACKING_ID"));
					PymntPostingTransLevelDetailsObject
							.setTrackingIdServ(resultset
									.getString("TRACKING_ID_SERV"));
					PymntPostingTransLevelDetailsObject
							.setReasonForLiuorFailure(resultset
									.getString("LIU_REASON"));
					PymntPostingTransLevelDetailsObject.setBankAccNo(resultset.getString("BANK_ACCOUNT_NUMBER"));
					if(resultset.getString("LOB")==null||resultset.getString("LOB").equalsIgnoreCase(""))
					{
						PymntPostingTransLevelDetailsObject.setLob("");
					}
					else
					{
					if(resultset.getString("LOB").equalsIgnoreCase("BTS"))
					{
						PymntPostingTransLevelDetailsObject.setLob("FL");
					}
					else
					PymntPostingTransLevelDetailsObject.setLob(resultset.getString("LOB"));
					}

					PayPostTransactionExcelList
							.add(PymntPostingTransLevelDetailsObject);
				}
			}
			reportslogger.info("Payment Posting Trans Level Excel Records list size in daoImpl:"
					+ PayPostTransactionExcelList.size());

		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     }
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return PayPostTransactionExcelList;

	}

	/* end<*****methods in payment posting transaction level****> */

	/* <****methods in vendor summary****> */

	public HashMap<Integer, List<PayPostingVendorDetails>> getVendorSummaryMap(
			PayPostingVendorDetails VendorDetailsObj, int page) {

		HashMap<Integer, List<PayPostingVendorDetails>> ReportsMap = new HashMap<Integer, List<PayPostingVendorDetails>>();
		List<PayPostingVendorDetails> DetailsList = new ArrayList<PayPostingVendorDetails>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;

		try {
			reportslogger.info("Payment Posting Vendor Level Method in DaoImpl");
			//reportslogger.info("connection" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("connection established");

			// call proc
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_USER_FILE_VENDOR_DETAILS(?,?,?,?,?,?,?,?)}";

			 callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1, VendorDetailsObj.getParentUserId());
			callableStatement.setString(2, VendorDetailsObj.getVendorId());
			callableStatement.setString(3, VendorDetailsObj.getToDate());
			callableStatement.setString(4, VendorDetailsObj.getFromDate());
			callableStatement.setInt(5, page);
			callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(7, Types.INTEGER);
			callableStatement.registerOutParameter(8, Types.VARCHAR);

			callableStatement.executeUpdate();

			//reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(7);
			//reportslogger.info("totalpages:" + totalPages);

			resultset = (ResultSet) callableStatement.getObject(6);

			VendorDetailsObj.setStatusMsg(callableStatement.getString(8));

		reportslogger.info("Error Msg at DaoImpl"
					+ VendorDetailsObj.getStatusMsg());

			if (resultset == null) {
				reportslogger.info("Resultset is null in daoImpl");

			} else {

				while (resultset != null && resultset.next()) {
					//reportslogger.info("inside while!");
					PayPostingVendorDetails vendorDetailsObject = new PayPostingVendorDetails();

					vendorDetailsObject.setVendorId(resultset
							.getString("VENDOR_ID"));
					vendorDetailsObject.setVendorName(resultset
							.getString("VENDOR_NAME"));
					vendorDetailsObject.setTotalRec(resultset
							.getInt("TOTAL_RECORDS"));
					vendorDetailsObject.setInProgressRecords(resultset
							.getInt("IN_PROGRESS"));
					vendorDetailsObject.setInProgressValue(resultset
							.getString("IN_PROGRESS_VALUE"));
					vendorDetailsObject.setRejectedRecords(resultset
							.getInt("REJECTED_RECORDS"));
					vendorDetailsObject.setRejectedValue(resultset
							.getString("REJECTED_RECORDS_VALUE"));
					vendorDetailsObject.setTotalVal(resultset
							.getString("TOTAL_VALUE"));
					vendorDetailsObject.setRecPostedFX(resultset
							.getInt("RECORDS_POSTED_FX"));
					vendorDetailsObject.setValuePostedFX(resultset
							.getString("VALUE_POSTED_FX"));
					vendorDetailsObject.setRecPendingAtLIU(resultset
							.getInt("RECORDS_PENDING_LIU"));
					vendorDetailsObject.setAmountPendingAtLIU(resultset
							.getString("VALUE_PENDING_LIU"));
					vendorDetailsObject.setRecDeletedAtLiu(resultset
							.getInt("RECORDS_DELETED_AT_LIU"));
					vendorDetailsObject
					.setValueDeletedAtLiu(resultset
							.getString("VALUE_DELETED_AT_LIU"));
					DetailsList.add(vendorDetailsObject);
				}
			}
			reportslogger.info(" Payment posting Vendor Level Records list size in daoImpl:" + DetailsList.size());

			ReportsMap.put(totalPages, DetailsList);
		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     }
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return ReportsMap;

	}

	public List<PayPostingVendorDetails> getVendorSummaryExcelList(
			PayPostingVendorDetails VendorDetailsObj, String pageNum) {
		List<PayPostingVendorDetails> ExcelDetailsList = new ArrayList<PayPostingVendorDetails>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		
		try {
			reportslogger.info("Payment Posting Vendor Level Excel Download in DaoImpl");
			//reportslogger.info("connection" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("connection established");

			// call proc
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_USER_FILE_VENDOR_DETAILS(?,?,?,?,?,?,?,?)}";

			callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1, VendorDetailsObj.getParentUserId());
			callableStatement.setString(2, VendorDetailsObj.getVendorId());
			callableStatement.setString(3, VendorDetailsObj.getToDate());
			callableStatement.setString(4, VendorDetailsObj.getFromDate());
			callableStatement.setString(5, pageNum);
			callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(7, Types.INTEGER);
			callableStatement.registerOutParameter(8, Types.VARCHAR);

			callableStatement.executeUpdate();

			//reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(7);
			//reportslogger.info("totalpages:" + totalPages);

			resultset = (ResultSet) callableStatement.getObject(6);

			VendorDetailsObj.setStatusMsg(callableStatement.getString(8));

			reportslogger.info("Error Msg at DaoImpl:"+ VendorDetailsObj.getStatusMsg());

			if (resultset == null) {
				reportslogger.info("Resultset is null in daoImpl");

			} else {

				while (resultset != null && resultset.next()) {
					//reportslogger.info("inside while!");
					PayPostingVendorDetails vendorDetailsObject = new PayPostingVendorDetails();
					vendorDetailsObject.setVendorId(resultset
							.getString("VENDOR_ID"));
					vendorDetailsObject.setVendorName(resultset
							.getString("VENDOR_NAME"));
					vendorDetailsObject.setTotalRec(resultset
							.getInt("TOTAL_RECORDS"));
					vendorDetailsObject.setInProgressRecords(resultset
							.getInt("IN_PROGRESS"));
					vendorDetailsObject.setInProgressValue(resultset
							.getString("IN_PROGRESS_VALUE"));
					vendorDetailsObject.setRejectedRecords(resultset
							.getInt("REJECTED_RECORDS"));
					vendorDetailsObject.setRejectedValue(resultset
							.getString("REJECTED_RECORDS_VALUE"));
					vendorDetailsObject.setTotalVal(resultset
							.getString("TOTAL_VALUE"));
					vendorDetailsObject.setRecPostedFX(resultset
							.getInt("RECORDS_POSTED_FX"));
					vendorDetailsObject.setValuePostedFX(resultset
							.getString("VALUE_POSTED_FX"));
					vendorDetailsObject.setRecPendingAtLIU(resultset
							.getInt("RECORDS_PENDING_LIU"));
					vendorDetailsObject.setAmountPendingAtLIU(resultset
							.getString("VALUE_PENDING_LIU"));
					vendorDetailsObject.setRecDeletedAtLiu(resultset
							.getInt("RECORDS_DELETED_AT_LIU"));
					vendorDetailsObject
					.setValueDeletedAtLiu(resultset
							.getString("VALUE_DELETED_AT_LIU"));

					ExcelDetailsList.add(vendorDetailsObject);
				}
			}
			reportslogger.info("Payment Posting Vendor Level Excel Records list size in DaoImpl:" + ExcelDetailsList.size());

		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     }
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return ExcelDetailsList;

	}

	/* end<****methods in vendor summary****> */

	/* <****methods in payment posting cheque level****> */

	public HashMap<Integer, List<PayPostingChequeDetails>> getPaymntPostingChequeMapAps(
			PayPostingChequeDetails PyPostChequeDetailsObj, int page) {

		HashMap<Integer, List<PayPostingChequeDetails>> ReportsMap = new HashMap<Integer, List<PayPostingChequeDetails>>();
		List<PayPostingChequeDetails> DetailsList = new ArrayList<PayPostingChequeDetails>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;

		//reportslogger.info("page number in dao:" + page);

		try {
			reportslogger.info("Payment Posting Cheque Level Method in DaoImpl");
			//reportslogger.info("connection:" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("connection established");

			final String procedureCall = "{call AIRTL_PAYMENT_REPORTS_PKG.PAYMENT_POSTING_CHEQUE_LEVEL(?,?,?,?,?,?,?,?,?,?,?,?)}";

			 callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1,
					PyPostChequeDetailsObj.getParentUser());
			callableStatement.setString(2,
					PyPostChequeDetailsObj.getUserOLMId());
			callableStatement.setString(3, PyPostChequeDetailsObj.getFileId());
			callableStatement
					.setString(4, PyPostChequeDetailsObj.getFileName());
			callableStatement.setString(5, PyPostChequeDetailsObj.getChqNo());
			callableStatement
					.setString(6, PyPostChequeDetailsObj.getVendorId());
			callableStatement.setString(7, PyPostChequeDetailsObj.getToDate());
			callableStatement
					.setString(8, PyPostChequeDetailsObj.getFromDate());

			callableStatement.setInt(9, page);
			callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(11, Types.INTEGER);
			callableStatement.registerOutParameter(12, Types.VARCHAR);
			callableStatement.executeUpdate();

			//reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(11);

			//reportslogger.info("totalpages got from proc:" + totalPages);

			resultset = (ResultSet) callableStatement.getObject(10);

			PyPostChequeDetailsObj
					.setStatusMsg(callableStatement.getString(12));

		reportslogger.info("Error Msg at DaoImpl:"
					+ PyPostChequeDetailsObj.getStatusMsg());

			if (resultset == null) {
				reportslogger.info("Resultset is null in daoImpl");

			} else {

				while (resultset != null && resultset.next()) {
					//reportslogger.info("inside while!");

					PayPostingChequeDetails PyPostChequeDetailsObject = new PayPostingChequeDetails();

					PyPostChequeDetailsObject.setChqNo(resultset
							.getString("CHEQUE_NO"));
					PyPostChequeDetailsObject.setBankName(resultset
							.getString("BANK_NAME"));
					PyPostChequeDetailsObject.setVendorName(resultset
							.getString("VENDOR_NAME"));
					PyPostChequeDetailsObject.setUserOLMId(resultset
							.getString("USER_OLM_ID"));
					PyPostChequeDetailsObject.setFileName(resultset
							.getString("FILE_NAME"));

					String StringChqDate = resultset
							.getString("CHEQUE_DATE");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date ChqParseddate = dateString.parse(StringChqDate);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalChqDate = dateString1.format(ChqParseddate);
					String dateChq[] = finalChqDate.split(" ");
					PyPostChequeDetailsObject.setDateOnChq(dateChq[0]);

					PyPostChequeDetailsObject.setNoOfAccPosted(resultset
							.getInt("NO_ACC_EXT_ID_POSTED"));
					PyPostChequeDetailsObject.setNoOfInvPosted(resultset
							.getInt("NO_INVOICE_POSTED"));
					PyPostChequeDetailsObject.setChqVal(resultset
							.getString("PAYMENT_AMOUNT_TOTAL"));
					PyPostChequeDetailsObject.setValPendingLIU(resultset
							.getString("PAYMENT_AMOUNT_LIU"));
					PyPostChequeDetailsObject.setValPostedFX(resultset
							.getString("PAYMENT_AMOUNT_POSTED"));

					String StringUploadDate = resultset
							.getString("FILE_UPLOAD_DATE");
					// SimpleDateFormat dateString = new SimpleDateFormat(
					// "yyyy-MM-dd HH:mm:ss");
					Date uploadParseddate = dateString.parse(StringUploadDate);
					// SimpleDateFormat dateString1 = new SimpleDateFormat(
					// "dd/MM/yyyy HH:mm:ss");
					String finalUploadDate = dateString1
							.format(uploadParseddate);

					if (finalUploadDate == null || finalUploadDate == "") {
						PyPostChequeDetailsObject.setChqUploadDt("");
						PyPostChequeDetailsObject.setChqUploadTym("");
					} else {
						String uploadDateAndTime[] = finalUploadDate.split(" ");
						PyPostChequeDetailsObject
								.setChqUploadDt(uploadDateAndTime[0]);
						PyPostChequeDetailsObject
								.setChqUploadTym(uploadDateAndTime[1]);

					}

					if (resultset.getString("PAYMENT_POSTED_DATE") != null) {
						String StringPostedDate = resultset
								.getString("PAYMENT_POSTED_DATE");
						Date PostedParseddate = dateString
								.parse(StringPostedDate);
						String finalPostedDate = dateString1
								.format(PostedParseddate);
						if ((finalPostedDate == null)
								|| (finalPostedDate == "")
								|| (finalPostedDate.equalsIgnoreCase("null"))) {
							PyPostChequeDetailsObject.setPostingDate("");
							PyPostChequeDetailsObject.setPostingTime("");
						} else {
							String PostingDate[] = finalPostedDate.split(" ");
							PyPostChequeDetailsObject
									.setPostingDate(PostingDate[0]);
							PyPostChequeDetailsObject
									.setPostingTime(PostingDate[1]);
						}
					} else
						PyPostChequeDetailsObject.setPostingDate(resultset
								.getString("PAYMENT_POSTED_DATE"));

					PyPostChequeDetailsObject.setDiffChqvsUpload(resultset
							.getInt("DIFF_CHEQUE_UPLOAD_DATE"));
					PyPostChequeDetailsObject.setDiffUploadvsPosted(resultset
							.getInt("DIFF_UPLOAD_POSTED_DATE"));
					PyPostChequeDetailsObject.setFileId(resultset
							.getString("FILE_ID"));
					PyPostChequeDetailsObject.setVendorId(resultset
							.getString("VENDOR_ID"));
					PyPostChequeDetailsObject.setBankAccNo(resultset
							.getString("BANK_VIRTUAL_ACCOUNT_NO"));

					DetailsList.add(PyPostChequeDetailsObject);
				}
			}
			reportslogger.info("Payment Posting Cheque Level Records list size in daoImpl:" + DetailsList.size());

			ReportsMap.put(totalPages, DetailsList);
		}
		 catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     }
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return ReportsMap;
	}

	
	
	/*********************************************new archival proc*************************************************************/
	
	public HashMap<Integer, List<PayPostingChequeDetails>> getPaymntPostingChequeMapApsArchive(
			PayPostingChequeDetails PyPostChequeDetailsObj, int page) {

		HashMap<Integer, List<PayPostingChequeDetails>> ReportsMap = new HashMap<Integer, List<PayPostingChequeDetails>>();
		List<PayPostingChequeDetails> DetailsList = new ArrayList<PayPostingChequeDetails>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;

		//reportslogger.info("page number in dao:" + page);

		try {
			reportslogger.info("Payment Posting Cheque Level Method in DaoImpl");
			//reportslogger.info("connection:" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("connection established");

			final String procedureCall = "{call AIRTL_PAYMENT_REPORTS_PKG.PAYMENT_POSTING_CHEQUE_LEVEL(?,?,?,?,?,?,?,?,?,?,?,?)}";

			 callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1,
					PyPostChequeDetailsObj.getParentUser());
			callableStatement.setString(2,
					PyPostChequeDetailsObj.getUserOLMId());
			callableStatement.setString(3, PyPostChequeDetailsObj.getFileId());
			callableStatement
					.setString(4, PyPostChequeDetailsObj.getFileName());
			callableStatement.setString(5, PyPostChequeDetailsObj.getChqNo());
			callableStatement
					.setString(6, PyPostChequeDetailsObj.getVendorId());
			callableStatement.setString(7, PyPostChequeDetailsObj.getToDate());
			callableStatement
					.setString(8, PyPostChequeDetailsObj.getFromDate());

			callableStatement.setInt(9, page);
			callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(11, Types.INTEGER);
			callableStatement.registerOutParameter(12, Types.VARCHAR);
			callableStatement.executeUpdate();

			//reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(11);

			//reportslogger.info("totalpages got from proc:" + totalPages);

			resultset = (ResultSet) callableStatement.getObject(10);

			PyPostChequeDetailsObj
					.setStatusMsg(callableStatement.getString(12));

		reportslogger.info("Error Msg at DaoImpl:"
					+ PyPostChequeDetailsObj.getStatusMsg());

			if (resultset == null) {
				reportslogger.info("Resultset is null in daoImpl");

			} else {

				while (resultset != null && resultset.next()) {
					//reportslogger.info("inside while!");

					PayPostingChequeDetails PyPostChequeDetailsObject = new PayPostingChequeDetails();

					PyPostChequeDetailsObject.setChqNo(resultset
							.getString("CHEQUE_NO"));
					PyPostChequeDetailsObject.setBankName(resultset
							.getString("BANK_NAME"));
					PyPostChequeDetailsObject.setVendorName(resultset
							.getString("VENDOR_NAME"));
					PyPostChequeDetailsObject.setUserOLMId(resultset
							.getString("USER_OLM_ID"));
					PyPostChequeDetailsObject.setFileName(resultset
							.getString("FILE_NAME"));

					String StringChqDate = resultset
							.getString("CHEQUE_DATE");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date ChqParseddate = dateString.parse(StringChqDate);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalChqDate = dateString1.format(ChqParseddate);
					String dateChq[] = finalChqDate.split(" ");
					PyPostChequeDetailsObject.setDateOnChq(dateChq[0]);

					PyPostChequeDetailsObject.setNoOfAccPosted(resultset
							.getInt("NO_ACC_EXT_ID_POSTED"));
					PyPostChequeDetailsObject.setNoOfInvPosted(resultset
							.getInt("NO_INVOICE_POSTED"));
					PyPostChequeDetailsObject.setChqVal(resultset
							.getString("PAYMENT_AMOUNT_TOTAL"));
					PyPostChequeDetailsObject.setValPendingLIU(resultset
							.getString("PAYMENT_AMOUNT_LIU"));
					PyPostChequeDetailsObject.setValPostedFX(resultset
							.getString("PAYMENT_AMOUNT_POSTED"));

					String StringUploadDate = resultset
							.getString("FILE_UPLOAD_DATE");
					// SimpleDateFormat dateString = new SimpleDateFormat(
					// "yyyy-MM-dd HH:mm:ss");
					Date uploadParseddate = dateString.parse(StringUploadDate);
					// SimpleDateFormat dateString1 = new SimpleDateFormat(
					// "dd/MM/yyyy HH:mm:ss");
					String finalUploadDate = dateString1
							.format(uploadParseddate);

					if (finalUploadDate == null || finalUploadDate == "") {
						PyPostChequeDetailsObject.setChqUploadDt("");
						PyPostChequeDetailsObject.setChqUploadTym("");
					} else {
						String uploadDateAndTime[] = finalUploadDate.split(" ");
						PyPostChequeDetailsObject
								.setChqUploadDt(uploadDateAndTime[0]);
						PyPostChequeDetailsObject
								.setChqUploadTym(uploadDateAndTime[1]);

					}

					if (resultset.getString("PAYMENT_POSTED_DATE") != null) {
						String StringPostedDate = resultset
								.getString("PAYMENT_POSTED_DATE");
						Date PostedParseddate = dateString
								.parse(StringPostedDate);
						String finalPostedDate = dateString1
								.format(PostedParseddate);
						if ((finalPostedDate == null)
								|| (finalPostedDate == "")
								|| (finalPostedDate.equalsIgnoreCase("null"))) {
							PyPostChequeDetailsObject.setPostingDate("");
							PyPostChequeDetailsObject.setPostingTime("");
						} else {
							String PostingDate[] = finalPostedDate.split(" ");
							PyPostChequeDetailsObject
									.setPostingDate(PostingDate[0]);
							PyPostChequeDetailsObject
									.setPostingTime(PostingDate[1]);
						}
					} else
						PyPostChequeDetailsObject.setPostingDate(resultset
								.getString("PAYMENT_POSTED_DATE"));

					PyPostChequeDetailsObject.setDiffChqvsUpload(resultset
							.getInt("DIFF_CHEQUE_UPLOAD_DATE"));
					PyPostChequeDetailsObject.setDiffUploadvsPosted(resultset
							.getInt("DIFF_UPLOAD_POSTED_DATE"));
					PyPostChequeDetailsObject.setFileId(resultset
							.getString("FILE_ID"));
					PyPostChequeDetailsObject.setVendorId(resultset
							.getString("VENDOR_ID"));
					PyPostChequeDetailsObject.setBankAccNo(resultset
							.getString("BANK_VIRTUAL_ACCOUNT_NO"));

					DetailsList.add(PyPostChequeDetailsObject);
				}
			}
			reportslogger.info("Payment Posting Cheque Level Records list size in daoImpl:" + DetailsList.size());

			ReportsMap.put(totalPages, DetailsList);
		}
		 catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     }
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return ReportsMap;
	}

	
	
	
	public List<PayPostingChequeDetails> getPyPostChequeDetailsListAps(
			PayPostingChequeDetails PyPostChequeDetailsObj, String pageNum) {

		List<PayPostingChequeDetails> PyPostChequeDetailsList = new ArrayList<PayPostingChequeDetails>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;

		//reportslogger.info("page number in dao:" + pageNum);

		try {
			reportslogger.info("Payment Posting Cheque Level Excel Download in DaoImpl");
			//reportslogger.info("connection:" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("connection established");

			final String procedureCall = "{call AIRTL_PAYMENT_REPORTS_PKG.PAYMENT_POSTING_CHEQUE_LEVEL(?,?,?,?,?,?,?,?,?,?,?,?)}";

			 callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1,
					PyPostChequeDetailsObj.getParentUser());
			callableStatement.setString(2,
					PyPostChequeDetailsObj.getUserOLMId());
			callableStatement.setString(3, PyPostChequeDetailsObj.getFileId());
			callableStatement
					.setString(4, PyPostChequeDetailsObj.getFileName());
			callableStatement.setString(5, PyPostChequeDetailsObj.getChqNo());
			callableStatement
					.setString(6, PyPostChequeDetailsObj.getVendorId());
			callableStatement.setString(7, PyPostChequeDetailsObj.getToDate());
			callableStatement
					.setString(8, PyPostChequeDetailsObj.getFromDate());

			callableStatement.setString(9, pageNum);
			callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(11, Types.INTEGER);
			callableStatement.registerOutParameter(12, Types.VARCHAR);
			callableStatement.executeUpdate();

			//reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(11);

			//reportslogger.info("totalpages got from proc:" + totalPages);

			resultset = (ResultSet) callableStatement.getObject(10);

			PyPostChequeDetailsObj
					.setStatusMsg(callableStatement.getString(12));

		reportslogger.info("Error Msg at DaoImpl:"+ PyPostChequeDetailsObj.getStatusMsg());

			if (resultset == null) {
				reportslogger.info("Resultset is null in daoImpl");

			} else {

				while (resultset != null && resultset.next()) {
					//reportslogger.info("inside while!");

					PayPostingChequeDetails PyPostChequeDetailsObject = new PayPostingChequeDetails();

					PyPostChequeDetailsObject.setChqNo(resultset
							.getString("CHEQUE_NO"));
					PyPostChequeDetailsObject.setBankName(resultset
							.getString("BANK_NAME"));
					PyPostChequeDetailsObject.setVendorName(resultset
							.getString("VENDOR_NAME"));
					PyPostChequeDetailsObject.setUserOLMId(resultset
							.getString("USER_OLM_ID"));
					PyPostChequeDetailsObject.setFileName(resultset
							.getString("FILE_NAME"));

					String StringChqDate = resultset
							.getString("FILE_UPLOAD_DATE");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date ChqParseddate = dateString.parse(StringChqDate);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalChqDate = dateString1.format(ChqParseddate);
					String dateChq[] = finalChqDate.split(" ");
					PyPostChequeDetailsObject.setDateOnChq(dateChq[0]);

					PyPostChequeDetailsObject.setNoOfAccPosted(resultset
							.getInt("NO_ACC_EXT_ID_POSTED"));
					PyPostChequeDetailsObject.setNoOfInvPosted(resultset
							.getInt("NO_INVOICE_POSTED"));
					PyPostChequeDetailsObject.setChqVal(resultset
							.getString("PAYMENT_AMOUNT_TOTAL"));
					PyPostChequeDetailsObject.setValPendingLIU(resultset
							.getString("PAYMENT_AMOUNT_LIU"));
					PyPostChequeDetailsObject.setValPostedFX(resultset
							.getString("PAYMENT_AMOUNT_POSTED"));

					String StringUploadDate = resultset
							.getString("FILE_UPLOAD_DATE");
					// SimpleDateFormat dateString = new SimpleDateFormat(
					// "yyyy-MM-dd HH:mm:ss");
					Date uploadParseddate = dateString.parse(StringUploadDate);
					// SimpleDateFormat dateString1 = new SimpleDateFormat(
					// "dd/MM/yyyy HH:mm:ss");
					String finalUploadDate = dateString1
							.format(uploadParseddate);

					if (finalUploadDate == null || finalUploadDate == "") {
						PyPostChequeDetailsObject.setChqUploadDt("");
						PyPostChequeDetailsObject.setChqUploadTym("");
					} else {
						String uploadDateAndTime[] = finalUploadDate.split(" ");
						PyPostChequeDetailsObject
								.setChqUploadDt(uploadDateAndTime[0]);
						PyPostChequeDetailsObject
								.setChqUploadTym(uploadDateAndTime[1]);

					}

					if (resultset.getString("PAYMENT_POSTED_DATE") != null) {
						String StringPostedDate = resultset
								.getString("PAYMENT_POSTED_DATE");
						Date PostedParseddate = dateString
								.parse(StringPostedDate);
						String finalPostedDate = dateString1
								.format(PostedParseddate);
						if ((finalPostedDate == null)
								|| (finalPostedDate == "")
								|| (finalPostedDate.equalsIgnoreCase("null"))) {
							PyPostChequeDetailsObject.setPostingDate("");
							PyPostChequeDetailsObject.setPostingTime("");
						} else {
							String PostingDate[] = finalPostedDate.split(" ");
							PyPostChequeDetailsObject
									.setPostingDate(PostingDate[0]);
							PyPostChequeDetailsObject
									.setPostingTime(PostingDate[1]);
						}
					} else
						PyPostChequeDetailsObject.setPostingDate(resultset
								.getString("PAYMENT_POSTED_DATE"));

					PyPostChequeDetailsObject.setDiffChqvsUpload(resultset
							.getInt("DIFF_CHEQUE_UPLOAD_DATE"));
					PyPostChequeDetailsObject.setDiffUploadvsPosted(resultset
							.getInt("DIFF_UPLOAD_POSTED_DATE"));
					PyPostChequeDetailsObject.setFileId(resultset
							.getString("FILE_ID"));
					PyPostChequeDetailsObject.setVendorId(resultset
							.getString("VENDOR_ID"));
					PyPostChequeDetailsObject.setBankAccNo(resultset
							.getString("BANK_VIRTUAL_ACCOUNT_NO"));

					PyPostChequeDetailsList.add(PyPostChequeDetailsObject);
				}
			}
			reportslogger.info("Payment Posting Cheque Level excel Records list size in daoImpl:" + PyPostChequeDetailsList.size());

		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     } 
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return PyPostChequeDetailsList;
	}

	/* end <****methods in payment posting cheque level****> */

	/******************** PAYMENT DIRECT REVERSAL ***********************************/

	public HashMap<Integer, List<PaymentDirectReversalBean>> getPayDirectReversalDetails(
			PaymentDirectReversalBean PayDirectReversalBeanObj, int page) {
		HashMap<Integer, List<PaymentDirectReversalBean>> payDirectReversalMap = new HashMap<Integer, List<PaymentDirectReversalBean>>();
		List<PaymentDirectReversalBean> payDirectReversalList = new ArrayList<PaymentDirectReversalBean>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
	//	reportslogger.info("page number in dao" + page);

		try {
			reportslogger.info("Payment Direct Reversal method in DaoImpl");
			//reportslogger.info("connection" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
//			reportslogger.info("connection established");
//			reportslogger.info("in dao child userid"
//					+ PayDirectReversalBeanObj.getChildUserId());

			// call proc
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_PAY_DIRECT_REV_DETAILS(?,?,?,?,?,?,?,?,?,?,?,?)}";

			callableStatement = conn
					.prepareCall(procedureCall);

			/* callableStatement.setInt(1, page); */
			callableStatement.setString(1,
					PayDirectReversalBeanObj.getParentUserId());
			callableStatement.setString(2,
					PayDirectReversalBeanObj.getChildUserId());
			callableStatement
					.setString(3, PayDirectReversalBeanObj.getFileId());
			callableStatement.setString(4,
					PayDirectReversalBeanObj.getFileName());
			callableStatement.setString(5,
					PayDirectReversalBeanObj.getTrackingId());
			callableStatement.setString(6,
					PayDirectReversalBeanObj.getVendorId());
			callableStatement
					.setString(7, PayDirectReversalBeanObj.getToDate());
			callableStatement.setString(8,
					PayDirectReversalBeanObj.getFromDate());
			callableStatement.setInt(9, page);
			callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(11, Types.INTEGER);
			callableStatement.registerOutParameter(12, Types.VARCHAR);
			//reportslogger.info("before execute update");
			callableStatement.executeUpdate();
			//reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(11);

			String statusMsg = callableStatement.getString(12);// msg

			resultset = (ResultSet) callableStatement.getObject(10);

			PayDirectReversalBeanObj.setStatusMsg(statusMsg);

			// reportslogger.info("result set size"+resultset.getFetchSize());
			reportslogger.info("Error Msg at DaoImpl"+ PayDirectReversalBeanObj.getStatusMsg());
				
			/* reportslogger.info("totalpages:" + totalPages); */

			if (resultset == null) {
				reportslogger.info("Resultset is null in daoImpl");

			} else {
				while (resultset != null && resultset.next()) {
					//reportslogger.info("inside while!");
					PaymentDirectReversalBean payDirectReversalBeanObject = new PaymentDirectReversalBean();

					payDirectReversalBeanObject.setAccountNumber(resultset
							.getString("ACCT_EXT_ID"));

					payDirectReversalBeanObject.setTrackingId(resultset
							.getString("TRACKING_ID"));

					payDirectReversalBeanObject.setTrackingIdServ(resultset
							.getString("TRACKING_ID_SERV"));
					payDirectReversalBeanObject.setUploadedByOlmId(resultset
							.getString("VENDOR_USERID"));
					payDirectReversalBeanObject.setUploadedByName(resultset
							.getString("USER_NAME"));
					payDirectReversalBeanObject.setFileId(resultset
							.getString("FILE_ID"));
					payDirectReversalBeanObject.setFileName(resultset
							.getString("ORIGINAL_FILE_NAME"));
					String date = resultset.getString("FILE_UPLOAD_DATE");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date date1 = dateString.parse(date);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateString1.format(date1);
					payDirectReversalBeanObject.setUploadDateTime(finalDate);
					if (resultset.getString("PAYMENT_POSTED_DATE") != null) {
						String StringPosted = resultset
								.getString("PAYMENT_POSTED_DATE");

						Date datePosted = dateString.parse(StringPosted);

						String finalDate1 = dateString1.format(datePosted);
						payDirectReversalBeanObject.setFxUpdateTime(finalDate1);
					} else
						payDirectReversalBeanObject.setFxUpdateTime("");
					payDirectReversalBeanObject.setStatus(resultset
							.getString("STATUS"));
					payDirectReversalBeanObject.setReasonForFailue(resultset
							.getString("REASON_FOR_FAILURE"));
					payDirectReversalList.add(payDirectReversalBeanObject);
				}
			}
			reportslogger.info("Payment Direct Reversal Records list size:" + payDirectReversalList.size());

			payDirectReversalMap.put(totalPages, payDirectReversalList);
		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     } 
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return payDirectReversalMap;

	}

	public List<PaymentDirectReversalBean> getPayDirectRevExcelDetails(
			PaymentDirectReversalBean payDirectReversalBeanObj, String pageNo) {
		List<PaymentDirectReversalBean> payDirectReversalList = new ArrayList<PaymentDirectReversalBean>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		//reportslogger.info("page number in dao" + pageNo);

		try {
		reportslogger.info("Payment Direct Reversal excel Download in DaoImpl ");
			//reportslogger.info("connection" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("connection established");
			// reportslogger.info("in dao child userid"+PayDirectReversalBeanObj.getChildUserId());

			// call proc
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_PAY_DIRECT_REV_DETAILS(?,?,?,?,?,?,?,?,?,?,?,?)}";

			 callableStatement = conn
					.prepareCall(procedureCall);

			/* callableStatement.setInt(1, page); */
			callableStatement.setString(1,
					payDirectReversalBeanObj.getParentUserId());
			callableStatement.setString(2,
					payDirectReversalBeanObj.getChildUserId());
			callableStatement
					.setString(3, payDirectReversalBeanObj.getFileId());
			callableStatement.setString(4,
					payDirectReversalBeanObj.getFileName());
			callableStatement.setString(5,
					payDirectReversalBeanObj.getTrackingId());
			callableStatement.setString(6,
					payDirectReversalBeanObj.getVendorId());
			callableStatement
					.setString(7, payDirectReversalBeanObj.getToDate());
			callableStatement.setString(8,
					payDirectReversalBeanObj.getFromDate());
			callableStatement.setString(9, pageNo);
			callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(11, Types.INTEGER);
			callableStatement.registerOutParameter(12, Types.VARCHAR);
			//reportslogger.info("before execute update");
			callableStatement.executeUpdate();
			//reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(11);

			String statusMsg = callableStatement.getString(12);// msg

			resultset = (ResultSet) callableStatement.getObject(10);

			payDirectReversalBeanObj.setStatusMsg(statusMsg);

			 reportslogger.info("Error Msg at DaoImpl"+statusMsg);
			
			/* reportslogger.info("totalpages:" + totalPages); */

			if (resultset == null) {
				reportslogger.info("Resultset is null in daoImpl");

			} else {
				while (resultset != null && resultset.next()) {
					//reportslogger.info("inside while!");
					PaymentDirectReversalBean payDirectReversalBeanObject = new PaymentDirectReversalBean();

					payDirectReversalBeanObject.setAccountNumber(resultset
							.getString("ACCT_EXT_ID"));

					payDirectReversalBeanObject.setTrackingId(resultset
							.getString("TRACKING_ID"));

					payDirectReversalBeanObject.setTrackingIdServ(resultset
							.getString("TRACKING_ID_SERV"));
					payDirectReversalBeanObject.setUploadedByOlmId(resultset
							.getString("VENDOR_USERID"));
					payDirectReversalBeanObject.setUploadedByName(resultset
							.getString("USER_NAME"));
					payDirectReversalBeanObject.setFileId(resultset
							.getString("FILE_ID"));
					payDirectReversalBeanObject.setFileName(resultset
							.getString("ORIGINAL_FILE_NAME"));
					String date = resultset.getString("FILE_UPLOAD_DATE");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date date1 = dateString.parse(date);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateString1.format(date1);
					payDirectReversalBeanObject.setUploadDateTime(finalDate);
					if (resultset.getString("PAYMENT_POSTED_DATE") != null) {
						String StringPosted = resultset
								.getString("PAYMENT_POSTED_DATE");

						Date datePosted = dateString.parse(StringPosted);

						String finalDate1 = dateString1.format(datePosted);
						payDirectReversalBeanObject.setFxUpdateTime(finalDate1);
					} else
						payDirectReversalBeanObject.setFxUpdateTime("");
					payDirectReversalBeanObject.setStatus(resultset
							.getString("STATUS"));
					payDirectReversalBeanObject.setReasonForFailue(resultset
							.getString("REASON_FOR_FAILURE"));
					payDirectReversalList.add(payDirectReversalBeanObject);
				}
			}
			reportslogger.info("payment Direct Reversal Excel Records list size in daoImpl:" + payDirectReversalList.size());

		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     } 
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return payDirectReversalList;
	}

	/* <****methods in cheque Bounce****> */
	public HashMap<Integer, List<PayRevChqBounceRecordsDetails>> getPymntRevChqBounceRecords(
			PayRevChqBounceRecordsDetails PymntRevChqBounceRecordsDetailsObj,
			int page) {
		HashMap<Integer, List<PayRevChqBounceRecordsDetails>> ReportsMap = new HashMap<Integer, List<PayRevChqBounceRecordsDetails>>();
		List<PayRevChqBounceRecordsDetails> DetailsList = new ArrayList<PayRevChqBounceRecordsDetails>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;

		try {
			reportslogger.info("Payment Reversal Cheque Bounce Details method in DaoImpl");
			//reportslogger.info("connection" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("connection established");

			// call proc
			final String procedureCall = "{call AIRTL_PAYMENT_REPORTS_PKG.GET_PAY_REV_CHQBOUNCE_DETAILS(?,?,?,?,?,?,?,?,?,?,?,?)}";

		callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1,
					PymntRevChqBounceRecordsDetailsObj.getParentUserId());
			callableStatement.setString(2,
					PymntRevChqBounceRecordsDetailsObj.getChildUserId());
			callableStatement.setString(3,
					PymntRevChqBounceRecordsDetailsObj.getFileId());
			callableStatement.setString(4,
					PymntRevChqBounceRecordsDetailsObj.getFileName());
			callableStatement.setString(5,
					PymntRevChqBounceRecordsDetailsObj.getRefNo());
			callableStatement.setString(6,
					PymntRevChqBounceRecordsDetailsObj.getVendorId());
			callableStatement.setString(7,
					PymntRevChqBounceRecordsDetailsObj.getToDate());
			callableStatement.setString(8,
					PymntRevChqBounceRecordsDetailsObj.getFromDate());
			callableStatement.setInt(9, page);
			callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(11, Types.INTEGER);
			callableStatement.registerOutParameter(12, Types.VARCHAR);

			callableStatement.executeUpdate();

		//	reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(11);
		//	reportslogger.info("totalpages:" + totalPages);

			resultset = (ResultSet) callableStatement.getObject(10);

			PymntRevChqBounceRecordsDetailsObj.setStatusMsg(callableStatement
					.getString(12));

			reportslogger.info("Error Msg at DaoImpl:"
					+ PymntRevChqBounceRecordsDetailsObj.getStatusMsg());

			if (resultset == null) {
				reportslogger.info("Resultset is null in daoImpl");

			} else {

				while (resultset != null && resultset.next()) {
					//reportslogger.info("inside while!");
					PayRevChqBounceRecordsDetails PymntRevChqBounceRecordsDetailsObject = new PayRevChqBounceRecordsDetails();
					PymntRevChqBounceRecordsDetailsObject
							.setUploadedUser(resultset
									.getString("VENDOR_USERID"));
					PymntRevChqBounceRecordsDetailsObject
							.setVendorName(resultset.getString("VENDOR_NAME"));
					int lob_mo = resultset.getInt("LOB_MO");
					int lob_fl = resultset.getInt("LOB_FL");
					int lob_istm = resultset.getInt("LOB_ISTM");
					int lob_aes=resultset.getInt("LOB_AES");
					
					
					if(((lob_mo + lob_fl) > 1) || ((lob_istm + lob_mo) > 1) || ((lob_aes + lob_mo) > 1) || ((lob_fl + lob_istm) > 1)|| ((lob_aes + lob_fl) > 1) || ((lob_istm + lob_aes) > 1) )
							{
						if(lob_mo>1&&lob_fl<1&&lob_istm<1&&lob_aes<1){
							PymntRevChqBounceRecordsDetailsObject.setLob("MOB");
						}else if(lob_mo<1&&lob_fl>1&&lob_istm<1&&lob_aes<1)
							PymntRevChqBounceRecordsDetailsObject.setLob("FL");
						else if(lob_mo<1&&lob_fl<1&&lob_istm>1&&lob_aes<1)
							PymntRevChqBounceRecordsDetailsObject.setLob("ISTM");
						else if(lob_mo<1&&lob_fl<1&&lob_istm<1&&lob_aes>1)
							PymntRevChqBounceRecordsDetailsObject.setLob("AES");
						else
							PymntRevChqBounceRecordsDetailsObject.setLob("Multiple");
					
					}else if(lob_mo==1)
						PymntRevChqBounceRecordsDetailsObject.setLob("MOB");
					else if(lob_fl==1)
						PymntRevChqBounceRecordsDetailsObject.setLob("FL");
					else if(lob_istm==1)
						PymntRevChqBounceRecordsDetailsObject.setLob("ISTM");
					else if(lob_aes==1)
						PymntRevChqBounceRecordsDetailsObject.setLob("AES");
					
					/* if ((lob_mo>1)||(lob_mo == 1))
							PymntRevChqBounceRecordsDetailsObject.setLob("MOB");
						else if ((lob_fl>1)||(lob_fl == 1))
							PymntRevChqBounceRecordsDetailsObject.setLob("FL");
						else if ((lob_istm>1)||(lob_istm == 1))
							PymntRevChqBounceRecordsDetailsObject.setLob("ISTM");
						else if ((lob_mo + lob_fl > 1) || (lob_fl + lob_istm) > 1
								|| (lob_istm + lob_mo) > 1)
							PymntRevChqBounceRecordsDetailsObject
									.setLob("multiple");*/
					PymntRevChqBounceRecordsDetailsObject.setFileName(resultset
							.getString("REVERSAL_FILE_NAME"));
					PymntRevChqBounceRecordsDetailsObject.setRefNo(resultset
							.getString("REF_NUMBER"));
					PymntRevChqBounceRecordsDetailsObject.setBankName(resultset
							.getString("BANK_NAME"));

					String date = resultset.getString("CHEQUE_DATE");
					SimpleDateFormat dateStringChqDate = new SimpleDateFormat(
							"yyyy-MM-dd");
					SimpleDateFormat dateStringChqDate1 = new SimpleDateFormat(
							"dd/MM/yyyy");
					
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date date1 = dateStringChqDate.parse(date);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateStringChqDate1.format(date1);

					PymntRevChqBounceRecordsDetailsObject
							.setDateonChq(finalDate);

					PymntRevChqBounceRecordsDetailsObject
							.setNoOfAccPostedFx(resultset
									.getInt("ACCT_EXT_IDS"));
					PymntRevChqBounceRecordsDetailsObject
							.setNoOfInvPostedFx(resultset.getInt("INVOICE_NOS"));
					PymntRevChqBounceRecordsDetailsObject
							.setTotChqVal(resultset.getString("PAYMENT_AMOUNT"));

					if (resultset.getString("INITIAL_FILE_UPLOAD_DATE") != null)
							 {
						String initialUplddate = resultset
								.getString("INITIAL_FILE_UPLOAD_DATE");
						
						Date initialUplddate1 = dateString
								.parse(initialUplddate);
						
						String finalDate1 = dateString1
								.format(initialUplddate1);

						PymntRevChqBounceRecordsDetailsObject
								.setInitialUploadedDate(finalDate1);
					} else
						PymntRevChqBounceRecordsDetailsObject
								.setInitialUploadedDate("");

					if (resultset.getString("INITIAL_POSTED_DATE") != null)
							 {
						String initialPstddate = resultset
								.getString("INITIAL_POSTED_DATE");
						Date initialPstddate1 = dateString
								.parse(initialPstddate);
						String finalDate2 = dateString1
								.format(initialPstddate1);

						PymntRevChqBounceRecordsDetailsObject
								.setInitialPostedDate(finalDate2);
					} else
						PymntRevChqBounceRecordsDetailsObject
								.setInitialPostedDate("");

					if (resultset.getString("BOUNCED_DATE") != null) {

						String bounceddate = resultset
								.getString("BOUNCED_DATE");
						Date bounceddate1 = dateStringChqDate.parse(bounceddate);
						String finalDate3 = dateStringChqDate1.format(bounceddate1);

						PymntRevChqBounceRecordsDetailsObject
								.setBouncedDate(finalDate3);
					} else
						PymntRevChqBounceRecordsDetailsObject
								.setBouncedDate("");

					
					
					
					if (resultset.getString("BOUNCED_MIS_DATE") != null) {

						String bouncedmisdate = resultset
								.getString("BOUNCED_MIS_DATE");
						Date bouncedmisdate1 = dateString.parse(bouncedmisdate);
						String finalDate4 = dateString1.format(bouncedmisdate1);

						PymntRevChqBounceRecordsDetailsObject
								.setBounceMisDate(finalDate4);
					} else
						PymntRevChqBounceRecordsDetailsObject
								.setBounceMisDate("");

					if (resultset.getString("REVERSAL_DATE") != null)
						 {

						String revDate = resultset.getString("REVERSAL_DATE");
						Date revDate1 = dateString.parse(revDate);
						String finalDate5 = dateString1.format(revDate1);
						
						PymntRevChqBounceRecordsDetailsObject
								.setRevPostingFxDate(finalDate5);
					} else
						PymntRevChqBounceRecordsDetailsObject
								.setRevPostingFxDate("");

					PymntRevChqBounceRecordsDetailsObject
							.setDiffInitalVsBouncedDate(resultset
									.getInt("DIFF_INIT_FILE_DATE_BOUNC_DATE"));
					PymntRevChqBounceRecordsDetailsObject
							.setDiffBouncedVsBouncdMisDate(resultset
									.getInt("DIFF_BOUNC_DATE_BOUNC_MIS_DATE"));
					PymntRevChqBounceRecordsDetailsObject
							.setDiffBouncedVspostingRevDate(resultset
									.getInt("DIFF_BOUNC_DATE_REV_DATE"));
					PymntRevChqBounceRecordsDetailsObject
							.setDiffBounceMisDateVspostingRevDate(resultset
									.getInt("DIFF_BOUNC_MIS_DATE_REV_DATE"));
					PymntRevChqBounceRecordsDetailsObject.setStatus(resultset
							.getString("CHQ_STATUS"));
					PymntRevChqBounceRecordsDetailsObject.setReasonForFailure(resultset.getString("CHQ_BNC_ERR_REASON_CODE"));
					PymntRevChqBounceRecordsDetailsObject.setFileId(resultset.getString("FILE_ID"));
					PymntRevChqBounceRecordsDetailsObject.setVendorId(resultset.getString("VENDOR_ID"));
					PymntRevChqBounceRecordsDetailsObject.setBankAccNo(resultset.getString("BANK_VIRTUAL_ACCOUNT_NO"));
					DetailsList.add(PymntRevChqBounceRecordsDetailsObject);
				}
			}
			reportslogger.info("Payment Reversal Cheque Bounce Records list size in DaoImpl:" + DetailsList.size());

			ReportsMap.put(totalPages, DetailsList);
		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     }
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return ReportsMap;

	}

	public List<PayRevChqBounceRecordsDetails> getPymntRevChqBounceList(
			PayRevChqBounceRecordsDetails PymntRevChqBounceRecordsDetailsObj,
			String pageNum) {

		List<PayRevChqBounceRecordsDetails> PymntRevChqBounceList = new ArrayList<PayRevChqBounceRecordsDetails>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;

		try {
			reportslogger.info("Payment Reversal Cheque bounce Excel Download in DaoImpl");
			//reportslogger.info("connection" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("connection established");

			// call proc
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_PAY_REV_CHQBOUNCE_DETAILS(?,?,?,?,?,?,?,?,?,?,?,?)}";

			callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1,
					PymntRevChqBounceRecordsDetailsObj.getParentUserId());
			callableStatement.setString(2,
					PymntRevChqBounceRecordsDetailsObj.getChildUserId());
			callableStatement.setString(3,
					PymntRevChqBounceRecordsDetailsObj.getFileId());
			callableStatement.setString(4,
					PymntRevChqBounceRecordsDetailsObj.getFileName());
			callableStatement.setString(5,
					PymntRevChqBounceRecordsDetailsObj.getRefNo());
			callableStatement.setString(6,
					PymntRevChqBounceRecordsDetailsObj.getVendorId());
			callableStatement.setString(7,
					PymntRevChqBounceRecordsDetailsObj.getToDate());
			callableStatement.setString(8,
					PymntRevChqBounceRecordsDetailsObj.getFromDate());
			callableStatement.setString(9, pageNum);
			callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(11, Types.INTEGER);
			callableStatement.registerOutParameter(12, Types.VARCHAR);

			callableStatement.executeUpdate();

			//reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(11);
			//reportslogger.info("totalpages:" + totalPages);

			resultset = (ResultSet) callableStatement.getObject(10);

			PymntRevChqBounceRecordsDetailsObj.setStatusMsg(callableStatement
					.getString(12));

			reportslogger.info("Error Msg at DaoImpl:"
					+ PymntRevChqBounceRecordsDetailsObj.getStatusMsg());

			if (resultset == null) {
				reportslogger.info("Resultset is null in daoImpl");

			} else {

				while (resultset != null && resultset.next()) {
					//reportslogger.info("inside while!");
					PayRevChqBounceRecordsDetails PymntRevChqBounceRecordsDetailsObject = new PayRevChqBounceRecordsDetails();
					PymntRevChqBounceRecordsDetailsObject
					.setUploadedUser(resultset
							.getString("VENDOR_USERID"));
			PymntRevChqBounceRecordsDetailsObject
					.setVendorName(resultset.getString("VENDOR_NAME"));
			int lob_mo = resultset.getInt("LOB_MO");
			int lob_fl = resultset.getInt("LOB_FL");
			int lob_istm = resultset.getInt("LOB_ISTM");
			int lob_aes=resultset.getInt("LOB_AES");
			
			
			if(((lob_mo + lob_fl) > 1) || ((lob_istm + lob_mo) > 1) || ((lob_aes + lob_mo) > 1) || ((lob_fl + lob_istm) > 1)|| ((lob_aes + lob_fl) > 1) || ((lob_istm + lob_aes) > 1) )
					{
				if(lob_mo>1&&lob_fl<1&&lob_istm<1&&lob_aes<1){
					PymntRevChqBounceRecordsDetailsObject.setLob("MOB");
				}else if(lob_mo<1&&lob_fl>1&&lob_istm<1&&lob_aes<1)
					PymntRevChqBounceRecordsDetailsObject.setLob("FL");
				else if(lob_mo<1&&lob_fl<1&&lob_istm>1&&lob_aes<1)
					PymntRevChqBounceRecordsDetailsObject.setLob("ISTM");
				else if(lob_mo<1&&lob_fl<1&&lob_istm<1&&lob_aes>1)
					PymntRevChqBounceRecordsDetailsObject.setLob("AES");
				else
					PymntRevChqBounceRecordsDetailsObject.setLob("Multiple");
			
			}else if(lob_mo==1)
				PymntRevChqBounceRecordsDetailsObject.setLob("MOB");
			else if(lob_fl==1)
				PymntRevChqBounceRecordsDetailsObject.setLob("FL");
			else if(lob_istm==1)
				PymntRevChqBounceRecordsDetailsObject.setLob("ISTM");
			else if(lob_aes==1)
				PymntRevChqBounceRecordsDetailsObject.setLob("AES");
			
			
			
			
			PymntRevChqBounceRecordsDetailsObject.setFileName(resultset
					.getString("REVERSAL_FILE_NAME"));
			PymntRevChqBounceRecordsDetailsObject.setRefNo(resultset
					.getString("REF_NUMBER"));
			PymntRevChqBounceRecordsDetailsObject.setBankName(resultset
					.getString("BANK_NAME"));

			String date = resultset.getString("CHEQUE_DATE");
			SimpleDateFormat dateStringChqDate = new SimpleDateFormat(
					"yyyy-MM-dd");
			SimpleDateFormat dateStringChqDate1 = new SimpleDateFormat(
					"dd/MM/yyyy");
			
			SimpleDateFormat dateString = new SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss");
			Date date1 = dateStringChqDate.parse(date);
			SimpleDateFormat dateString1 = new SimpleDateFormat(
					"dd/MM/yyyy HH:mm:ss");
			String finalDate = dateStringChqDate1.format(date1);

			PymntRevChqBounceRecordsDetailsObject
					.setDateonChq(finalDate);

			PymntRevChqBounceRecordsDetailsObject
					.setNoOfAccPostedFx(resultset
							.getInt("ACCT_EXT_IDS"));
			PymntRevChqBounceRecordsDetailsObject
					.setNoOfInvPostedFx(resultset.getInt("INVOICE_NOS"));
			PymntRevChqBounceRecordsDetailsObject
					.setTotChqVal(resultset.getString("PAYMENT_AMOUNT"));

			if (resultset.getString("INITIAL_FILE_UPLOAD_DATE") != null)
					 {
				String initialUplddate = resultset
						.getString("INITIAL_FILE_UPLOAD_DATE");
				
				Date initialUplddate1 = dateString
						.parse(initialUplddate);
				
				String finalDate1 = dateString1
						.format(initialUplddate1);

				PymntRevChqBounceRecordsDetailsObject
						.setInitialUploadedDate(finalDate1);
			} else
				PymntRevChqBounceRecordsDetailsObject
						.setInitialUploadedDate("");

			if (resultset.getString("INITIAL_POSTED_DATE") != null)
					 {
				String initialPstddate = resultset
						.getString("INITIAL_POSTED_DATE");
				Date initialPstddate1 = dateString
						.parse(initialPstddate);
				String finalDate2 = dateString1
						.format(initialPstddate1);

				PymntRevChqBounceRecordsDetailsObject
						.setInitialPostedDate(finalDate2);
			} else
				PymntRevChqBounceRecordsDetailsObject
						.setInitialPostedDate("");

			if (resultset.getString("BOUNCED_DATE") != null) {

				String bounceddate = resultset
						.getString("BOUNCED_DATE");
				Date bounceddate1 = dateStringChqDate.parse(bounceddate);
				String finalDate3 = dateStringChqDate1.format(bounceddate1);

				PymntRevChqBounceRecordsDetailsObject
						.setBouncedDate(finalDate3);
			} else
				PymntRevChqBounceRecordsDetailsObject
						.setBouncedDate("");

			if (resultset.getString("BOUNCED_MIS_DATE") != null) {

				String bouncedmisdate = resultset
						.getString("BOUNCED_MIS_DATE");
				Date bouncedmisdate1 = dateString.parse(bouncedmisdate);
				String finalDate4 = dateString1.format(bouncedmisdate1);

				PymntRevChqBounceRecordsDetailsObject
						.setBounceMisDate(finalDate4);
			} else
				PymntRevChqBounceRecordsDetailsObject
						.setBounceMisDate("");

			if (resultset.getString("REVERSAL_DATE") != null)
				 {

				String revDate = resultset.getString("REVERSAL_DATE");
				Date revDate1 = dateString.parse(revDate);
				String finalDate5 = dateString1.format(revDate1);
				
				PymntRevChqBounceRecordsDetailsObject
						.setRevPostingFxDate(finalDate5);
			} else
				PymntRevChqBounceRecordsDetailsObject
						.setRevPostingFxDate("");

			PymntRevChqBounceRecordsDetailsObject
					.setDiffInitalVsBouncedDate(resultset
							.getInt("DIFF_INIT_FILE_DATE_BOUNC_DATE"));
			PymntRevChqBounceRecordsDetailsObject
					.setDiffBouncedVsBouncdMisDate(resultset
							.getInt("DIFF_BOUNC_DATE_BOUNC_MIS_DATE"));
			PymntRevChqBounceRecordsDetailsObject
					.setDiffBouncedVspostingRevDate(resultset
							.getInt("DIFF_BOUNC_DATE_REV_DATE"));
			PymntRevChqBounceRecordsDetailsObject
					.setDiffBounceMisDateVspostingRevDate(resultset
							.getInt("DIFF_BOUNC_MIS_DATE_REV_DATE"));
			PymntRevChqBounceRecordsDetailsObject.setStatus(resultset
					.getString("CHQ_STATUS"));
			PymntRevChqBounceRecordsDetailsObject.setReasonForFailure(resultset.getString("CHQ_BNC_ERR_REASON_CODE"));
			PymntRevChqBounceRecordsDetailsObject.setFileId(resultset.getString("FILE_ID"));
			PymntRevChqBounceRecordsDetailsObject.setVendorId(resultset.getString("VENDOR_ID"));
			PymntRevChqBounceRecordsDetailsObject.setBankAccNo(resultset.getString("BANK_VIRTUAL_ACCOUNT_NO"));
					PymntRevChqBounceList
							.add(PymntRevChqBounceRecordsDetailsObject);
				}
			}
			reportslogger.info("Payment Reversal Cheque Bounce Excel Records list size in daoImpl:" + PymntRevChqBounceList.size());

		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     } 
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return PymntRevChqBounceList;

	}

	/* <end****methods in chqBounce****> */
	/********************* PAYMENT TRANSFER TRANS LEVEL ****************************/

	public HashMap<Integer, List<PaymentTransferTransLevelBean>> getPaymentTransferTransLevelDetails(
			PaymentTransferTransLevelBean payTransferTransLevelBeanObj, int page) {
		HashMap<Integer, List<PaymentTransferTransLevelBean>> payTransferTransLevelMap = new HashMap<Integer, List<PaymentTransferTransLevelBean>>();
		List<PaymentTransferTransLevelBean> payTransferTransLevelList = new ArrayList<PaymentTransferTransLevelBean>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		//reportslogger.info("page number in dao" + page);

		try {
         	reportslogger.info("Payment Transfer Trans level method  in daoImpl");
//			reportslogger.info("connection" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("connection established");
			//reportslogger.info("in dao child userid"
				//	+ payTransferTransLevelBeanObj.getChildUserId());

			// call proc
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_PT_TRANSACTION_DETAILS(?,?,?,?,?,?,?,?,?,?,?,?)}";

			 callableStatement = conn
					.prepareCall(procedureCall);

			/* callableStatement.setInt(1, page); */
			callableStatement.setString(1,
					payTransferTransLevelBeanObj.getParentUserId());
			callableStatement.setString(2,
					payTransferTransLevelBeanObj.getChildUserId());
			callableStatement.setString(3,
					payTransferTransLevelBeanObj.getFileId());
			callableStatement.setString(4,
					payTransferTransLevelBeanObj.getFileName());
			callableStatement.setString(5,
					payTransferTransLevelBeanObj.getVendorId());
			callableStatement.setString(6,
					payTransferTransLevelBeanObj.getSourceTrackingId());
			callableStatement.setString(7,
					payTransferTransLevelBeanObj.getToDate());
			callableStatement.setString(8,
					payTransferTransLevelBeanObj.getFromDate());
			callableStatement.setInt(9, page);
			callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(11, Types.INTEGER);
			callableStatement.registerOutParameter(12, Types.VARCHAR);
			//reportslogger.info("before execute update");
			callableStatement.executeUpdate();
			//reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(11);

			String statusMsg = callableStatement.getString(12);// msg

			resultset = (ResultSet) callableStatement.getObject(10);

			payTransferTransLevelBeanObj.setStatusMsg(statusMsg);
			// reportslogger.info("result set size"+resultset.getFetchSize());
			reportslogger.info("Error Msg at DaoImpl"
					+ payTransferTransLevelBeanObj.getStatusMsg());
			/* reportslogger.info("totalpages:" + totalPages); */
			if (resultset == null) {
				reportslogger.info("Resultset is null in DaoImpl");

			} else {

				while (resultset != null && resultset.next()) {
					//reportslogger.info("inside while!");
					PaymentTransferTransLevelBean payTransferTransLevelBeanObject = new PaymentTransferTransLevelBean();
					payTransferTransLevelBeanObject.setTransId(resultset
							.getString("REF_NUMBER"));
					payTransferTransLevelBeanObject
							.setSourceTrackingId(resultset
									.getString("TRACKING_ID"));
					payTransferTransLevelBeanObject
							.setSourceTrackingIdServ(resultset
									.getString("TRACKING_ID_SERV"));
					payTransferTransLevelBeanObject.setType(resultset
							.getString("TRANSFER_TYPE"));
					payTransferTransLevelBeanObject.setPaymentMode(resultset
							.getString("PAYMENT_MODE"));
					
					int lob_mo = resultset.getInt("LOB_MO");
					int lob_fl = resultset.getInt("LOB_FL");
					int lob_istm = resultset.getInt("LOB_ISTM");
					int lob_aes=resultset.getInt("LOB_AES");

					
					if(lob_mo>=1)
						payTransferTransLevelBeanObject.setLob("MOB");
					else if(lob_fl>=1)
						payTransferTransLevelBeanObject.setLob("FL");
					else if(lob_istm>=1)
						payTransferTransLevelBeanObject.setLob("ISTM");
					else if(lob_aes>=1)
						payTransferTransLevelBeanObject.setLob("AES");
					
					payTransferTransLevelBeanObject.setAccountNo(resultset
							.getString("ACCT_EXT_ID"));
					if((resultset.getString("INVOICE_NO"))==null||(resultset.getString("INVOICE_NO")).equalsIgnoreCase("null")||(resultset.getString("INVOICE_NO")).equalsIgnoreCase(""))
					{
						payTransferTransLevelBeanObject.setInvoiceNo("");
					}
					else
					payTransferTransLevelBeanObject.setInvoiceNo(resultset
							.getString("INVOICE_NO"));
					payTransferTransLevelBeanObject.setAmount(resultset
							.getString("PAYMENT_AMOUNT"));
					payTransferTransLevelBeanObject
							.setUploadedByOlmId(resultset
									.getString("VENDOR_USERID"));
					payTransferTransLevelBeanObject.setUploadedByName(resultset
							.getString("USER_NAME"));
					
					
					
					String date = resultset.getString("FILE_UPLOAD_DATE");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date date1 = dateString.parse(date);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateString1.format(date1);
					
					payTransferTransLevelBeanObject.setUploadTime(finalDate);
						
					payTransferTransLevelBeanObject.setFileId(resultset
							.getString("FILE_ID"));
					payTransferTransLevelBeanObject.setFileName(resultset
							.getString("ORIGINAL_FILE_NAME"));
					payTransferTransLevelBeanObject.setStatus(resultset
							.getString("STATUS"));
							
					if(resultset.getString("PAYMENT_POSTED_DATE")!=null)
									{
					String Posteddate = resultset.getString("PAYMENT_POSTED_DATE");
					//reportslogger.info("posted date"+Posteddate);
					Date Posteddate1 = dateString.parse(Posteddate);
					
					String finalPostedDate = dateString1.format(Posteddate1);
					
					
					payTransferTransLevelBeanObject.setFxUpdatedDate(finalPostedDate);
					}
					else payTransferTransLevelBeanObject.setFxUpdatedDate(resultset.getString("PAYMENT_POSTED_DATE"));
					
					payTransferTransLevelBeanObject
							.setReasonForFailure(resultset
									.getString("REASON_FOR_FAILURE"));
					payTransferTransLevelBeanObject.setDesTrackingId(resultset.getString("DES_TRACKING_ID"));
					payTransferTransLevelBeanObject.setDesTrackingIdServ(resultset.getString("DES_TRACKING_ID_SERV"));

					payTransferTransLevelList
							.add(payTransferTransLevelBeanObject);
				}
			}
			reportslogger.info("Payment Transfer Trans level Records list size in DaoImpl:" + payTransferTransLevelList.size());

			payTransferTransLevelMap.put(totalPages, payTransferTransLevelList);
		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     } 
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return payTransferTransLevelMap;

	}

	public List<PaymentTransferTransLevelBean> getPaymentTransferTransExcelDetails(
			PaymentTransferTransLevelBean payTransferTransLevelBeanObj,
			String pageNo) {
		List<PaymentTransferTransLevelBean> payTransferTransLevelExcelList = new ArrayList<PaymentTransferTransLevelBean>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
	//	reportslogger.info("page number in dao" + pageNo);

		try {
			reportslogger.info("Payment Transfer Trans Level Excel Download in DaoImpl");
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			/*reportslogger.info("connection established");
			reportslogger.info("in dao child userid"
					+ payTransferTransLevelBeanObj.getChildUserId());*/

			// call proc
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_PT_TRANSACTION_DETAILS(?,?,?,?,?,?,?,?,?,?,?,?)}";

			 callableStatement = conn
					.prepareCall(procedureCall);

			/* callableStatement.setInt(1, page); */
			callableStatement.setString(1,
					payTransferTransLevelBeanObj.getParentUserId());
			callableStatement.setString(2,
					payTransferTransLevelBeanObj.getChildUserId());
			callableStatement.setString(3,
					payTransferTransLevelBeanObj.getFileId());
			callableStatement.setString(4,
					payTransferTransLevelBeanObj.getFileName());
			callableStatement.setString(5,
					payTransferTransLevelBeanObj.getVendorId());
			callableStatement.setString(6,
					payTransferTransLevelBeanObj.getSourceTrackingId());
			callableStatement.setString(7,
					payTransferTransLevelBeanObj.getToDate());
			callableStatement.setString(8,
					payTransferTransLevelBeanObj.getFromDate());
			callableStatement.setString(9, pageNo);
			callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(11, Types.INTEGER);
			callableStatement.registerOutParameter(12, Types.VARCHAR);
			//reportslogger.info("before execute update");
			callableStatement.executeUpdate();
			//reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(11);

			String statusMsg = callableStatement.getString(12);// msg

			resultset = (ResultSet) callableStatement.getObject(10);

			payTransferTransLevelBeanObj.setStatusMsg(statusMsg);

			// reportslogger.info("result set size"+resultset.getFetchSize());
			reportslogger.info("Error Msg at DaoImpl"+ payTransferTransLevelBeanObj.getStatusMsg());
			/* reportslogger.info("totalpages:" + totalPages); */
			if (resultset == null) {
				reportslogger.info("Resultset is null in daoImpl");

			} else {

				while (resultset != null && resultset.next()) {
					//reportslogger.info("inside while!");
					PaymentTransferTransLevelBean payTransferTransLevelBeanObject = new PaymentTransferTransLevelBean();
					payTransferTransLevelBeanObject.setTransId(resultset
							.getString("REF_NUMBER"));
					payTransferTransLevelBeanObject
							.setSourceTrackingId(resultset
									.getString("TRACKING_ID"));
					payTransferTransLevelBeanObject
							.setSourceTrackingIdServ(resultset
									.getString("TRACKING_ID_SERV"));
					payTransferTransLevelBeanObject.setType(resultset
							.getString("TRANSFER_TYPE"));
					
					
					payTransferTransLevelBeanObject.setPaymentMode(resultset
							.getString("PAYMENT_MODE"));
					int lob_mo = resultset.getInt("LOB_MO");
					int lob_fl = resultset.getInt("LOB_FL");
					int lob_istm = resultset.getInt("LOB_ISTM");
					int lob_aes=resultset.getInt("LOB_AES");

					
					if(lob_mo>=1)
						payTransferTransLevelBeanObject.setLob("MOB");
					else if(lob_fl>=1)
						payTransferTransLevelBeanObject.setLob("FL");
					else if(lob_istm>=1)
						payTransferTransLevelBeanObject.setLob("ISTM");
					else if(lob_aes>=1)
						payTransferTransLevelBeanObject.setLob("AES");
					
					payTransferTransLevelBeanObject.setAccountNo(resultset
							.getString("ACCT_EXT_ID"));
					if((resultset.getString("INVOICE_NO"))==null||(resultset.getString("INVOICE_NO")).equalsIgnoreCase("null")||(resultset.getString("INVOICE_NO")).equalsIgnoreCase(""))
					{
						payTransferTransLevelBeanObject.setInvoiceNo("");
					}
					else
					payTransferTransLevelBeanObject.setInvoiceNo(resultset
							.getString("INVOICE_NO"));
					payTransferTransLevelBeanObject.setAmount(resultset
							.getString("PAYMENT_AMOUNT"));
					payTransferTransLevelBeanObject
							.setUploadedByOlmId(resultset
									.getString("VENDOR_USERID"));
					payTransferTransLevelBeanObject.setUploadedByName(resultset
							.getString("USER_NAME"));
					
					
					
					String date = resultset.getString("FILE_UPLOAD_DATE");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date date1 = dateString.parse(date);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateString1.format(date1);
					
					payTransferTransLevelBeanObject.setUploadTime(finalDate);
						
					payTransferTransLevelBeanObject.setFileId(resultset
							.getString("FILE_ID"));
					payTransferTransLevelBeanObject.setFileName(resultset
							.getString("ORIGINAL_FILE_NAME"));
					payTransferTransLevelBeanObject.setStatus(resultset
							.getString("STATUS"));
							
					if(resultset.getString("PAYMENT_POSTED_DATE")!=null)
									{
					String Posteddate = resultset.getString("PAYMENT_POSTED_DATE");
					//reportslogger.info("posted date"+Posteddate);
					Date Posteddate1 = dateString.parse(Posteddate);
					
					String finalPostedDate = dateString1.format(Posteddate1);
					
					
					payTransferTransLevelBeanObject.setFxUpdatedDate(finalPostedDate);
					}
					else payTransferTransLevelBeanObject.setFxUpdatedDate(resultset.getString("PAYMENT_POSTED_DATE"));
					
					payTransferTransLevelBeanObject
							.setReasonForFailure(resultset
									.getString("REASON_FOR_FAILURE"));
					payTransferTransLevelBeanObject.setDesTrackingId(resultset.getString("DES_TRACKING_ID"));
					payTransferTransLevelBeanObject.setDesTrackingIdServ(resultset.getString("DES_TRACKING_ID_SERV"));

					payTransferTransLevelExcelList
							.add(payTransferTransLevelBeanObject);
				}
			}
			reportslogger.info("Payment Transfer Trans Level Excel Records list size in DaoImpl:"+ payTransferTransLevelExcelList.size());

		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     } 
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
							reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return payTransferTransLevelExcelList;

	}

	/**************************** PAYMENT TRANSFER FILE LEVEL ***********************************************/

	public HashMap<Integer, List<PayTransferFileLevelDetails>> getPymntTransFileSummaryMap(
			PayTransferFileLevelDetails pymntTransFileLevelDetailsObj, int page) {

		HashMap<Integer, List<PayTransferFileLevelDetails>> ReportsMap = new HashMap<Integer, List<PayTransferFileLevelDetails>>();
		List<PayTransferFileLevelDetails> DetailsList = new ArrayList<PayTransferFileLevelDetails>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;

		try {
			reportslogger.info("Payment Transfer File level method in DaoImpl");
			//reportslogger.info("connection" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("connection established");

			// call proc
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_PAYMENT_TRANS_FILE_DETAILS(?,?,?,?,?,?,?,?,?,?,?)}";

			callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1,
					pymntTransFileLevelDetailsObj.getParentUserId());
			callableStatement.setString(2,
					pymntTransFileLevelDetailsObj.getChildUserId());
			callableStatement.setString(3,
					pymntTransFileLevelDetailsObj.getFileORreqId());
			callableStatement.setString(4,
					pymntTransFileLevelDetailsObj.getFileName());
			callableStatement.setString(5,
					pymntTransFileLevelDetailsObj.getVendorId());
			callableStatement.setString(6,
					pymntTransFileLevelDetailsObj.getToDate());
			callableStatement.setString(7,
					pymntTransFileLevelDetailsObj.getFromDate());

			callableStatement.setInt(8, page);
			callableStatement.registerOutParameter(9, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(10, Types.INTEGER);
			callableStatement.registerOutParameter(11, Types.VARCHAR);

			callableStatement.executeUpdate();

			//reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(10);
			//reportslogger.info("totalpages:" + totalPages);

			resultset = (ResultSet) callableStatement.getObject(9);

			pymntTransFileLevelDetailsObj.setStatusMsg(callableStatement
					.getString(11));

			reportslogger.info("Error Msg at DaoImpl:"
					+ pymntTransFileLevelDetailsObj.getStatusMsg());

			if (resultset == null) {
				reportslogger.info("Resultset is null in DaoImpl");

			} else {

				while (resultset != null && resultset.next()) {
					//reportslogger.info("inside while!");
					PayTransferFileLevelDetails pymntTransFileLevelDetailsObject = new PayTransferFileLevelDetails();

					pymntTransFileLevelDetailsObject.setFileORreqId(resultset
							.getString("FILE_ID"));

					pymntTransFileLevelDetailsObject
							.setUploadedByOLMId(resultset.getString("USER_ID"));
					pymntTransFileLevelDetailsObject
							.setUploadedByName(resultset.getString("USER_NAME"));
					// pymntTransFileLevelDetailsObject.setUploadedTime(resultset.getString("UPLOAD_DATE"));

					String stringUpload = resultset.getString("UPLOAD_DATE");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date dateUpload = dateString.parse(stringUpload);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateString1.format(dateUpload);
					pymntTransFileLevelDetailsObject.setUploadedTime(finalDate);

					pymntTransFileLevelDetailsObject.setFileName(resultset
							.getString("FILE_NAME"));
					pymntTransFileLevelDetailsObject.setTotRecCount(resultset
							.getInt("TOTAL_RECORDS"));
					pymntTransFileLevelDetailsObject.setTotVal(resultset
							.getString("TOTAL_AMOUNT"));
					pymntTransFileLevelDetailsObject.setStatus(resultset
							.getString("STATUS"));
					pymntTransFileLevelDetailsObject
							.setSuccessCountFx(resultset
									.getInt("SUCCESS_REC_COUNT"));
					pymntTransFileLevelDetailsObject.setSuccessValFx(resultset
							.getString("SUCCESS_REC_VALUE"));
					pymntTransFileLevelDetailsObject
							.setFailedRecCountFx(resultset
									.getInt("FAILURE_REC_COUNT"));
					pymntTransFileLevelDetailsObject
							.setFailedRecValFx(resultset
									.getString("FAILURE_REC_VALUE"));
					pymntTransFileLevelDetailsObject.setInProgressRecords(resultset
							.getInt("INPROGRESS_RECORDS"));
					pymntTransFileLevelDetailsObject.setInProgressvalue(resultset
							.getString("INPROGRESS_RECORDS_VALUE"));

					DetailsList.add(pymntTransFileLevelDetailsObject);
				}
			}
			reportslogger.info("Payment Transfer File level Records list size in daoImpl :" + DetailsList.size());

			ReportsMap.put(totalPages, DetailsList);
		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     }
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
							reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return ReportsMap;

	}


	
	public List<PaymentTransferTransLevelBean> getPymntTransferErrorRecords(String FileId) {


		List<PaymentTransferTransLevelBean> PymntTransferErrorRecordsList = new ArrayList<PaymentTransferTransLevelBean>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;

		try {
			reportslogger.info("Payment Transfer File level Failure Records Downlaod");
			//reportslogger.info("connection" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("connection established");
			

			// call proc
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_PT_TRANS_DETAILS_DOWNLOAD(?,?,?)}";

			 callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1,FileId);
			callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			
			//reportslogger.info("before execute update");
			callableStatement.executeUpdate();
			//reportslogger.info("callable statements executed");

			
			String statusMsg = callableStatement.getString(3);// msg

			resultset = (ResultSet) callableStatement.getObject(2);
			reportslogger.info("Error Msg at DaoImpl:" + statusMsg); 
			if (resultset == null) {
				reportslogger.info("Resultset is null in DaoImpl");

			} else {

				while (resultset != null && resultset.next()) {
					//reportslogger.info("inside while!");
					
					PaymentTransferTransLevelBean payTransferTransLevelBeanObject = new PaymentTransferTransLevelBean();
					payTransferTransLevelBeanObject.setTransId(resultset
							.getString("REF_NUMBER"));
					payTransferTransLevelBeanObject
							.setSourceTrackingId(resultset
									.getString("TRACKING_ID"));
					payTransferTransLevelBeanObject
							.setSourceTrackingIdServ(resultset
									.getString("TRACKING_ID_SERV"));
					payTransferTransLevelBeanObject.setType(resultset
							.getString("TRANSFER_TYPE"));
					payTransferTransLevelBeanObject.setPaymentMode(resultset
							.getString("PAYMENT_MODE"));
					
					
					int lob_mo = resultset.getInt("LOB_MO");
					int lob_fl = resultset.getInt("LOB_FL");
					int lob_istm = resultset.getInt("LOB_ISTM");
					int lob_aes=resultset.getInt("LOB_AES");

					
					if(lob_mo>=1)
						payTransferTransLevelBeanObject.setLob("MOB");
					else if(lob_fl>=1)
						payTransferTransLevelBeanObject.setLob("FL");
					else if(lob_istm>=1)
						payTransferTransLevelBeanObject.setLob("ISTM");
					else if(lob_aes>=1)
						payTransferTransLevelBeanObject.setLob("AES");
					
					payTransferTransLevelBeanObject.setAccountNo(resultset
							.getString("ACCT_EXT_ID"));
					payTransferTransLevelBeanObject.setInvoiceNo(resultset
							.getString("INVOICE_NO"));
					payTransferTransLevelBeanObject.setAmount(resultset
							.getString("PAYMENT_AMOUNT"));
					payTransferTransLevelBeanObject
							.setUploadedByOlmId(resultset
									.getString("VENDOR_USERID"));
					payTransferTransLevelBeanObject.setUploadedByName(resultset
							.getString("USER_NAME"));
					
					
					
					String date = resultset.getString("FILE_UPLOAD_DATE");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date date1 = dateString.parse(date);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateString1.format(date1);
					
					payTransferTransLevelBeanObject.setUploadTime(finalDate);
						
					payTransferTransLevelBeanObject.setFileId(resultset
							.getString("FILE_ID"));
					payTransferTransLevelBeanObject.setFileName(resultset
							.getString("ORIGINAL_FILE_NAME"));
					payTransferTransLevelBeanObject.setStatus(resultset
							.getString("STATUS"));
							
					/*if(resultset.getString("PAYMENT_POSTED_DATE")!=null)
									{
					String Posteddate = resultset.getString("PAYMENT_POSTED_DATE");
					reportslogger.info("posted date"+Posteddate);
					Date Posteddate1 = dateString.parse(Posteddate);
					
					String finalPostedDate = dateString1.format(Posteddate1);
					
					
					payTransferTransLevelBeanObject.setFxUpdatedDate(finalPostedDate);
					}
					else payTransferTransLevelBeanObject.setFxUpdatedDate(resultset.getString("PAYMENT_POSTED_DATE"));*/
					
					payTransferTransLevelBeanObject
							.setReasonForFailure(resultset
									.getString("REASON_FOR_FAILURE"));

					PymntTransferErrorRecordsList
							.add(payTransferTransLevelBeanObject);
				}
			}
			reportslogger.info("Payment Transfer File level Failure Records list size in DaoImpl:" + PymntTransferErrorRecordsList.size());

			
		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     }
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
							reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return PymntTransferErrorRecordsList;

	}

					
	public List<PayTransferFileLevelDetails> getpymntTransFileLevelDetailsExcelList(
			PayTransferFileLevelDetails pymntTransFileLevelDetailsObj,
			String pageNum) {

		List<PayTransferFileLevelDetails> DetailsList = new ArrayList<PayTransferFileLevelDetails>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		try {
			reportslogger.info("Payment Transfer File level Excel Download in DaoImpl");
			//reportslogger.info("connection" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("connection established");

			// call proc
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_PAYMENT_TRANS_FILE_DETAILS(?,?,?,?,?,?,?,?,?,?,?)}";

		 callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1,
					pymntTransFileLevelDetailsObj.getParentUserId());
			callableStatement.setString(2,
					pymntTransFileLevelDetailsObj.getChildUserId());
			callableStatement.setString(3,
					pymntTransFileLevelDetailsObj.getFileORreqId());
			callableStatement.setString(4,
					pymntTransFileLevelDetailsObj.getFileName());
			callableStatement.setString(5,
					pymntTransFileLevelDetailsObj.getVendorId());
			callableStatement.setString(6,
					pymntTransFileLevelDetailsObj.getToDate());
			callableStatement.setString(7,
					pymntTransFileLevelDetailsObj.getFromDate());

			callableStatement.setString(8, pageNum);
			callableStatement.registerOutParameter(9, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(10, Types.INTEGER);
			callableStatement.registerOutParameter(11, Types.VARCHAR);

			callableStatement.executeUpdate();

			//reportslogger.info("callable statements executed");

			int totalPages = callableStatement.getInt(10);
			//reportslogger.info("totalpages:" + totalPages);

			resultset = (ResultSet) callableStatement.getObject(9);

			pymntTransFileLevelDetailsObj.setStatusMsg(callableStatement
					.getString(11));

			reportslogger.info("Error Msg at DaoImpl:"
					+ pymntTransFileLevelDetailsObj.getStatusMsg());

			if (resultset == null) {
				reportslogger.info("Resultset is null in DaoImpl");

			} else {

				while (resultset != null && resultset.next()) {
					//reportslogger.info("inside while!");
					PayTransferFileLevelDetails pymntTransFileLevelDetailsObject = new PayTransferFileLevelDetails();

					pymntTransFileLevelDetailsObject.setFileORreqId(resultset
							.getString("FILE_ID"));
					pymntTransFileLevelDetailsObject
							.setUploadedByOLMId(resultset.getString("USER_ID"));
					pymntTransFileLevelDetailsObject
							.setUploadedByName(resultset.getString("USER_NAME"));
					// pymntTransFileLevelDetailsObject.setUploadedTime(resultset.getDate("UPLOAD_DATE"));

					String stringUpload = resultset.getString("UPLOAD_DATE");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date dateUpload = dateString.parse(stringUpload);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateString1.format(dateUpload);
					pymntTransFileLevelDetailsObject.setUploadedTime(finalDate);

					pymntTransFileLevelDetailsObject.setFileName(resultset
							.getString("FILE_NAME"));
					pymntTransFileLevelDetailsObject.setTotRecCount(resultset
							.getInt("TOTAL_RECORDS"));
					pymntTransFileLevelDetailsObject.setTotVal(resultset
							.getString("TOTAL_AMOUNT"));
					pymntTransFileLevelDetailsObject.setStatus(resultset
							.getString("STATUS"));
					pymntTransFileLevelDetailsObject
							.setSuccessCountFx(resultset
									.getInt("SUCCESS_REC_COUNT"));
					pymntTransFileLevelDetailsObject.setSuccessValFx(resultset
							.getString("SUCCESS_REC_VALUE"));
					pymntTransFileLevelDetailsObject
							.setFailedRecCountFx(resultset
									.getInt("FAILURE_REC_COUNT"));
					pymntTransFileLevelDetailsObject
							.setFailedRecValFx(resultset
									.getString("FAILURE_REC_VALUE"));
					pymntTransFileLevelDetailsObject.setInProgressRecords(resultset
							.getInt("INPROGRESS_RECORDS"));
					pymntTransFileLevelDetailsObject.setInProgressvalue(resultset
							.getString("INPROGRESS_RECORDS_VALUE"));

					DetailsList.add(pymntTransFileLevelDetailsObject);
				}
			}
			reportslogger.info("Payment Transfer File level Excel Records list size in DaoImpl:" + DetailsList.size());

		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     } 
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
							reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return DetailsList;
	}
	/**************************** PAYMENT TRANSFER FILE LEVEL ends***********************************************/
	
	/*****************************************Activity Log************************************************************/
	
	public HashMap<Integer, List<ActivityLogDetails>> getActivityLogMap(
			ActivityLogDetails viewActivityLogDetailsObj, int page) 
			{
		HashMap<Integer, List<ActivityLogDetails>> ReportsMap = new HashMap<Integer, List<ActivityLogDetails>>();
		List<ActivityLogDetails> DetailsList = new ArrayList<ActivityLogDetails>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		
		//reportslogger.info("page number in dao:"+page);
	
		try {
			reportslogger.info("Activity Log Method in DaoImpl");
			//reportslogger.info("connection:" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			

			
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_USER_ACTIVITY_LOG_DETAILS(?,?,?,?,?,?,?,?)}";

			callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1,viewActivityLogDetailsObj.getParentUserId());
			callableStatement.setString(2, viewActivityLogDetailsObj.getChildUserId());
			callableStatement.setString(3, viewActivityLogDetailsObj.getToDate());
			callableStatement.setString(4, viewActivityLogDetailsObj.getFromDate());
			callableStatement.setInt(5,page);
			callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(7,Types.INTEGER);
			callableStatement.registerOutParameter(8, Types.VARCHAR);
			
			
			callableStatement.executeUpdate();
			
		//	reportslogger.info("callable statements executed");
			
			int totalPages = callableStatement.getInt(7);
			
		//	reportslogger.info("totalpages got from proc:" + totalPages);
			
			resultset=(ResultSet) callableStatement.getObject(6);
	
			viewActivityLogDetailsObj.setErrorMsg(callableStatement.getString(8));

            reportslogger.info("Error Msg at DaoImpl:"+viewActivityLogDetailsObj.getErrorMsg());
			
if(resultset==null)
{
	reportslogger.info("Resultset is null in DaoImpl");
	
}
else
{

			while (resultset!=null &&resultset.next()) {
					//reportslogger.info("inside while!");
					ActivityLogDetails viewActivityLogDetailsObject= new ActivityLogDetails();
				
					viewActivityLogDetailsObject.setChildUserId(resultset.getString("USER_ID"));
					viewActivityLogDetailsObject.setUserRole(resultset.getString("ROLE_DESC"));
					viewActivityLogDetailsObject.setActivity(resultset.getString("ACTIVITY_DESC"));
					
					String date = resultset.getString("ACTIVITY_START_TIME");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date date1 = dateString.parse(date);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateString1.format(date1);		
					viewActivityLogDetailsObject.setActivityStartTime(finalDate);
				viewActivityLogDetailsObject.setStatus(resultset.getString("REMARKS"));	
				viewActivityLogDetailsObject.setRemarks(resultset.getString("STATUS"));
					viewActivityLogDetailsObject.setFileName(resultset.getString("FILENAME"));
					viewActivityLogDetailsObject.setRecCount(resultset.getString("REC_COUNT"));
					viewActivityLogDetailsObject.setValueOftheFile(resultset.getString("TOT_AMOUNT"));	

				DetailsList.add(viewActivityLogDetailsObject);
			}
}
			reportslogger.info("Activity Log Records list size in DaoImpl:" + DetailsList.size());

			ReportsMap.put(totalPages, DetailsList);
		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     } 
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		}
		finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
							reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return ReportsMap;

	}

	public List<ActivityLogDetails> getActivityLogExcelList(ActivityLogDetails viewActivityLogDetailsObj, String pageNum)
	{
		List<ActivityLogDetails> ActivityLogList = new ArrayList<ActivityLogDetails>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		
	//	reportslogger.info("page number in dao:"+pageNum);
	
		try {
			reportslogger.info("Activity log Excel Download");
			//reportslogger.info("connection:" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("connection established");

			
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_USER_ACTIVITY_LOG_DETAILS(?,?,?,?,?,?,?,?)}";

			callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1,viewActivityLogDetailsObj.getParentUserId());
			callableStatement.setString(2, viewActivityLogDetailsObj.getChildUserId());
			callableStatement.setString(3, viewActivityLogDetailsObj.getToDate());
			callableStatement.setString(4, viewActivityLogDetailsObj.getFromDate());
			callableStatement.setString(5,pageNum);
			callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(7,Types.INTEGER);
			callableStatement.registerOutParameter(8, Types.VARCHAR);
			
			
			callableStatement.executeUpdate();
			
			//reportslogger.info("callable statements executed");
			
			int totalPages = callableStatement.getInt(7);
			
			//reportslogger.info("totalpages got from proc:" + totalPages);
			
			resultset=(ResultSet) callableStatement.getObject(6);
	
			viewActivityLogDetailsObj.setErrorMsg(callableStatement.getString(8));

            reportslogger.info("Error Msg at DaoImpl:"+viewActivityLogDetailsObj.getErrorMsg());
			
if(resultset==null)
{
	reportslogger.info("Resultset is null in DaoImpl");
	
}
else
{


			while (resultset!=null &&resultset.next()) {
					//reportslogger.info("inside while!");
					ActivityLogDetails viewActivityLogDetailsObject= new ActivityLogDetails();
			
					viewActivityLogDetailsObject.setChildUserId(resultset.getString("USER_ID"));
					viewActivityLogDetailsObject.setUserRole(resultset.getString("ROLE_DESC"));
					viewActivityLogDetailsObject.setActivity(resultset.getString("ACTIVITY_DESC"));
					String date = resultset.getString("ACTIVITY_START_TIME");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date date1 = dateString.parse(date);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateString1.format(date1);		
					viewActivityLogDetailsObject.setActivityStartTime(finalDate);
				viewActivityLogDetailsObject.setStatus(resultset.getString("REMARKS"));	
				viewActivityLogDetailsObject.setRemarks(resultset.getString("STATUS"));	
					viewActivityLogDetailsObject.setFileName(resultset.getString("FILENAME"));
					viewActivityLogDetailsObject.setRecCount(resultset.getString("REC_COUNT"));
					viewActivityLogDetailsObject.setValueOftheFile(resultset.getString("TOT_AMOUNT"));	
			

				ActivityLogList.add(viewActivityLogDetailsObject);
			}
}
			reportslogger.info("Activity Log Excel Records list size:" + ActivityLogList.size());

			
		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     } 
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		}
		finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    			}
		         
		         	   }
		}
		return ActivityLogList;
	}

	/*************************************User Management Vendor Report********************************************/

	public HashMap<Integer, List<VendorUserReportBean>> getVendorReportMap(
			VendorUserReportBean VendorUserReportBeanObj, int page) {
		HashMap<Integer, List<VendorUserReportBean>> ReportsMap = new HashMap<Integer, List<VendorUserReportBean>>();
		List<VendorUserReportBean> DetailsList = new ArrayList<VendorUserReportBean>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		
		//reportslogger.info("page number in dao:"+page);
	
		try {
			reportslogger.info("User Management-Vendor Level Method in DaoImpl");
			//reportslogger.info("connection:" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("connection established");

			
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_USER_MGMT_VENDOR_DETAILS(?,?,?,?,?,?,?,?)}";

			 callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1,VendorUserReportBeanObj.getParentUserId());
			callableStatement.setString(2, VendorUserReportBeanObj.getVendorId());
			callableStatement.setString(3, VendorUserReportBeanObj.getVendorName());
			callableStatement.setString(4, VendorUserReportBeanObj.getStatus());
			callableStatement.setInt(5,page);
			callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(7,Types.INTEGER);
			callableStatement.registerOutParameter(8, Types.VARCHAR);
			
			
			callableStatement.executeUpdate();
			
			//reportslogger.info("callable statements executed");
			
			int totalPages = callableStatement.getInt(7);
			
			//reportslogger.info("totalpages got from proc:" + totalPages);
			
			resultset=(ResultSet) callableStatement.getObject(6);
	
			
			VendorUserReportBeanObj.setErrorMsg(callableStatement.getString(8));

            reportslogger.info("Error Msg at DaoImpl:"+VendorUserReportBeanObj.getErrorMsg());
			
if(resultset==null)
{
	reportslogger.info("Resultset is null in DaoImpl");
	
}
else
{

			while (resultset!=null &&resultset.next()) {
					//reportslogger.info("inside while!");
					VendorUserReportBean VendorUserReportBeanObject= new VendorUserReportBean();
					VendorUserReportBeanObject.setVendorId(resultset.getString("VENDOR_ID"));
					VendorUserReportBeanObject.setVendorName(resultset.getString("VENDOR_NAME"));
					VendorUserReportBeanObject.setVendorSpocName(resultset.getString("VENDOR_SPOC"));
					VendorUserReportBeanObject.setVendorSpocEmail(resultset.getString("VENDOR_EMAIL"));
					VendorUserReportBeanObject.setVendorSpocContactNumber(resultset.getString("CONTACT_NUM"));
					VendorUserReportBeanObject.setVendorAddressline1(resultset.getString("ADDRESS_LINE1"));
					VendorUserReportBeanObject.setVendorAddressLine2(resultset.getString("ADDRESS_LINE2"));
					VendorUserReportBeanObject.setVendorCity(resultset.getString("CITY"));
					VendorUserReportBeanObject.setVendorState(resultset.getString("STATE"));
					VendorUserReportBeanObject.setPin(resultset.getString("PINCODE"));
					VendorUserReportBeanObject.setLobs(resultset.getString("LOB"));
					VendorUserReportBeanObject.setPaymentModes(resultset.getString("PAYMENT_MODE"));
					
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					if(resultset.getString("ACTIVE_DATE")!=null){
					String activeDate = resultset.getString("ACTIVE_DATE");
					
					Date date1 = dateString.parse(activeDate);
					
					String finalDate = dateString1.format(date1);		
					VendorUserReportBeanObject.setActiveDate(finalDate);}
					else
						VendorUserReportBeanObject.setActiveDate(resultset.getString("ACTIVE_DATE"));
						
					if(resultset.getString("INACTIVE_DATE")!=null){
					String inactiveDate = resultset.getString("INACTIVE_DATE");
					Date date2 = dateString.parse(inactiveDate);
					String finalDate2 = dateString1.format(date2);	
					VendorUserReportBeanObject.setInActiveDate(finalDate2);}
					else 
						VendorUserReportBeanObject.setInActiveDate(resultset.getString("INACTIVE_DATE"));
					VendorUserReportBeanObject.setStatus(resultset.getString("STATUS"));
					
					
				DetailsList.add(VendorUserReportBeanObject);
			}
}
			reportslogger.info("User Management Vendor Level Records list size in DaoImpl:" + DetailsList.size());

			ReportsMap.put(totalPages, DetailsList);
		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     }
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		}
		finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
							reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return ReportsMap;

		
	}

	public List<VendorUserReportBean> getVendorsExcelList(
			VendorUserReportBean VendorUserReportBeanObj, String pageNum) 
			{
		
		List<VendorUserReportBean> DetailsList = new ArrayList<VendorUserReportBean>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		
		//reportslogger.info("page number in dao:"+pageNum);
	
		try {
			reportslogger.info("User Management-Vendor Level Excel Download in DaoImpl");
			//reportslogger.info("connection:" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("connection established");

			
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_USER_MGMT_VENDOR_DETAILS(?,?,?,?,?,?,?,?)}";

			callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1,VendorUserReportBeanObj.getParentUserId());
			callableStatement.setString(2, VendorUserReportBeanObj.getVendorId());
			callableStatement.setString(3, VendorUserReportBeanObj.getVendorName());
			callableStatement.setString(4, VendorUserReportBeanObj.getStatus());
			callableStatement.setString(5,pageNum);
			callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(7,Types.INTEGER);
			callableStatement.registerOutParameter(8, Types.VARCHAR);
			
			
			callableStatement.executeUpdate();
			
			//reportslogger.info("callable statements executed");
			
			int totalPages = callableStatement.getInt(7);
			
			//reportslogger.info("totalpages got from proc:" + totalPages);
			
			resultset=(ResultSet) callableStatement.getObject(6);
	
			
			VendorUserReportBeanObj.setErrorMsg(callableStatement.getString(8));

           reportslogger.info("Error Msg at DaoImpl:"+VendorUserReportBeanObj.getErrorMsg());
			
if(resultset==null)
{
	reportslogger.info("Resultset is null in DaoImpl");
	
}
else
{

			while (resultset!=null &&resultset.next()) {
					//reportslogger.info("inside while!");
					VendorUserReportBean VendorUserReportBeanObject= new VendorUserReportBean();
					VendorUserReportBeanObject.setVendorId(resultset.getString("VENDOR_ID"));
					VendorUserReportBeanObject.setVendorName(resultset.getString("VENDOR_NAME"));
					VendorUserReportBeanObject.setVendorSpocName(resultset.getString("VENDOR_SPOC"));
					VendorUserReportBeanObject.setVendorSpocEmail(resultset.getString("VENDOR_EMAIL"));
					VendorUserReportBeanObject.setVendorSpocContactNumber(resultset.getString("CONTACT_NUM"));
					VendorUserReportBeanObject.setVendorAddressline1(resultset.getString("ADDRESS_LINE1"));
					VendorUserReportBeanObject.setVendorAddressLine2(resultset.getString("ADDRESS_LINE2"));
					VendorUserReportBeanObject.setVendorCity(resultset.getString("CITY"));
					VendorUserReportBeanObject.setVendorState(resultset.getString("STATE"));
					VendorUserReportBeanObject.setPin(resultset.getString("PINCODE"));
					VendorUserReportBeanObject.setLobs(resultset.getString("LOB"));
					VendorUserReportBeanObject.setPaymentModes(resultset.getString("PAYMENT_MODE"));
					
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					if(resultset.getString("ACTIVE_DATE")!=null){
					String activeDate = resultset.getString("ACTIVE_DATE");
					
					Date date1 = dateString.parse(activeDate);
					
					String finalDate = dateString1.format(date1);		
					VendorUserReportBeanObject.setActiveDate(finalDate);}
					else
						VendorUserReportBeanObject.setActiveDate(resultset.getString("ACTIVE_DATE"));
						
					if(resultset.getString("INACTIVE_DATE")!=null){
					String inactiveDate = resultset.getString("INACTIVE_DATE");
					Date date2 = dateString.parse(inactiveDate);
					String finalDate2 = dateString1.format(date2);	
					VendorUserReportBeanObject.setInActiveDate(finalDate2);}
					else 
						VendorUserReportBeanObject.setInActiveDate(resultset.getString("INACTIVE_DATE"));
					
					VendorUserReportBeanObject.setStatus(resultset.getString("STATUS"));
					
					
				DetailsList.add(VendorUserReportBeanObject);
			}
}
			reportslogger.info("User Management Vendor level Excel Records list size in DaoImpl:" + DetailsList.size());

			
		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     }
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		}
		finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
							reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return DetailsList;

	
	} 
	/*************************************User Management Vendor Report Ends********************************************/
	
	/**********************************user management -user level reports**********************************************************/
	
	public List<String> returnStatusList() {

		List<String> statusList = new ArrayList<String>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		try {
reportslogger.info("User Management Status list method in DaoImpl");
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			//reportslogger.info("entered daoimpl to return status!");

			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_USERMANAGEMENT_STATUS_LIST(?,?,?)}";

			 callableStatement = conn.prepareCall(procedureCall);
			callableStatement.registerOutParameter(1, Types.VARCHAR);
			callableStatement.registerOutParameter(2, Types.VARCHAR);
			callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
			callableStatement.executeUpdate();
			//reportslogger.info("callable statements executed");

			resultset = (ResultSet) callableStatement.getObject(3);
			while (resultset.next()) {
				statusList.add(resultset.getString("STATUS_LIST"));
			}

		} catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
							reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return statusList;
	}


	public List<String> returnRoleDescList() {
		
		List<String> roleDescList = new ArrayList<String>();
		ResultSet resultset = null;
		CallableStatement callableStatement=null;
		try {
reportslogger.info("User management Role Description List in daoImpl");
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
		//	reportslogger.info("entered daoimpl to return ROLE DESC!");

			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_ROLE_DESC_LIST(?,?,?)}";

			 callableStatement = conn.prepareCall(procedureCall);
			callableStatement.registerOutParameter(1, Types.VARCHAR);
			callableStatement.registerOutParameter(2, Types.VARCHAR);
			callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
			callableStatement.executeUpdate();
			//reportslogger.info("callable statements executed");

			resultset = (ResultSet) callableStatement.getObject(3);
			while (resultset.next()) {
				roleDescList.add(resultset.getString("ROLE_DESC"));
			}

		} catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		} finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
							reportslogger.error(errors);
		    			}
		         
		         	   }
		}
		return roleDescList;
	}


	

public HashMap<Integer, List<UserManagementUserLevel>> getUserMgmtUserLevelMap(
		UserManagementUserLevel UserManagementUserLevelObj,
		int page) {
	

	HashMap<Integer, List<UserManagementUserLevel>> ReportsMap = new HashMap<Integer, List<UserManagementUserLevel>>();
	List<UserManagementUserLevel> DetailsList = new ArrayList<UserManagementUserLevel>();
	ResultSet resultset = null;
	CallableStatement callableStatement=null;
	
	//reportslogger.info("page number in dao:"+page);

	try {
		reportslogger.info("User Management-User Level method  In DoaImpl");
		//reportslogger.info("connection:" + dataSource.getConnection());*/
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		conn = jdbcTemplate.getDataSource().getConnection();
		//reportslogger.info("connection established");

		
		final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_USER_MGMT_USER_DETAILS(?,?,?,?,?,?,?,?,?)}";

		 callableStatement = conn
				.prepareCall(procedureCall);

		callableStatement.setString(1,UserManagementUserLevelObj.getParentUserId());
		callableStatement.setString(2, UserManagementUserLevelObj.getChildOlmId());
		callableStatement.setString(3, UserManagementUserLevelObj.getChildUserName());
		callableStatement.setString(4, UserManagementUserLevelObj.getRoleDesc());
		callableStatement.setString(5, UserManagementUserLevelObj.getStatus());
		callableStatement.setInt(6,page);
		callableStatement.registerOutParameter(7, OracleTypes.CURSOR);
		callableStatement.registerOutParameter(8,Types.INTEGER);
		callableStatement.registerOutParameter(9, Types.VARCHAR);
		
		
		callableStatement.executeUpdate();
		
		//reportslogger.info("callable statements executed");
		
		int totalPages = callableStatement.getInt(8);
		
		//reportslogger.info("totalpages got from proc:" + totalPages);
		
		resultset=(ResultSet) callableStatement.getObject(7);

		
		UserManagementUserLevelObj.setStatusMsg(callableStatement.getString(9));

       reportslogger.info("Error Msg at DaoImpl:"+UserManagementUserLevelObj.getStatusMsg());
		
if(resultset==null)
{
reportslogger.info("Resultset is null in daoImpl");

}
else
{

		while (resultset!=null &&resultset.next()) {
				//reportslogger.info("inside while!");
				UserManagementUserLevel UserManagementUserLevelObject= new UserManagementUserLevel();
				
				UserManagementUserLevelObject.setChildOlmId(resultset.getString("USERID"));
				UserManagementUserLevelObject.setChildUserName(resultset.getString("USER_NAME"));
				UserManagementUserLevelObject.setRoleDesc(resultset.getString("USER_ROLE"));
				UserManagementUserLevelObject.setVendorId(resultset.getString("VENDOR_ID"));
				UserManagementUserLevelObject.setEmailId(resultset.getString("EMAILID"));
				UserManagementUserLevelObject.setCircle(resultset.getString("CIRCLE"));
				UserManagementUserLevelObject.setApplicableProcess(resultset.getString("TRANSFER_TYPE"));		
				UserManagementUserLevelObject.setStatus(resultset.getString("STATUS"));
				
				
				SimpleDateFormat dateString = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss");
				SimpleDateFormat dateString1 = new SimpleDateFormat(
						"dd/MM/yyyy HH:mm:ss");
				if(resultset.getString("ACTIVE_DATE")!=null){
				String activeDate = resultset.getString("ACTIVE_DATE");
				
				Date date1 = dateString.parse(activeDate);
				
				String finalDate = dateString1.format(date1);		
				UserManagementUserLevelObject.setActiveDate(finalDate);}
				else
				UserManagementUserLevelObject.setActiveDate(resultset.getString("ACTIVE_DATE"));
				
				if(resultset.getString("INACTIVE_DATE")!=null){
				String inactiveDate = resultset.getString("INACTIVE_DATE");
				Date date2 = dateString.parse(inactiveDate);
				String finalDate2 = dateString1.format(date2);	
				UserManagementUserLevelObject.setInactiveDate(finalDate2);}
				else 
					UserManagementUserLevelObject.setInactiveDate(resultset.getString("INACTIVE_DATE"));
		
			DetailsList.add(UserManagementUserLevelObject);
		}
}
		reportslogger.info("User Mangement User Level Records list size in daoImpl:" + DetailsList.size());

		ReportsMap.put(totalPages, DetailsList);
	} catch (SQLException e) 
    {
		  StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
	return null;
    } 
	catch (Exception e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		reportslogger.error(errors);
		return null;
	}
	finally {
		if(resultset!=null){
	     	   try {
	     		  resultset.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
				}
	     	   }
		
		if(callableStatement!=null){
	     	   try {
	     		  callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
				}
	     	   }
				
	    	   if(conn!=null){
	         	   try {
	    				conn.close();
	    			} catch (Exception e) {
	    				StringWriter errors= new StringWriter();
	    				e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
	    			}
	         
	         	   }
	}
	return ReportsMap;

}




public List<UserManagementUserLevel> getUserMgmtUserLevelExcelList(UserManagementUserLevel UserManagementUserLevelObj,
		String pageNum) {
	
	List<UserManagementUserLevel> UserMgmtUserLevelExcelList = new ArrayList<UserManagementUserLevel>();
	ResultSet resultset = null;
	CallableStatement callableStatement=null;
	
	//reportslogger.info("page number in dao:"+pageNum);

	try {
		reportslogger.info("User Management-User Level excel Downlaod in DaoImpl");
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		conn = jdbcTemplate.getDataSource().getConnection();
		//reportslogger.info("connection established");

		
		final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_USER_MGMT_USER_DETAILS(?,?,?,?,?,?,?,?,?)}";

		callableStatement = conn
				.prepareCall(procedureCall);

		callableStatement.setString(1,UserManagementUserLevelObj.getParentUserId());
		callableStatement.setString(2, UserManagementUserLevelObj.getChildOlmId());
		callableStatement.setString(3, UserManagementUserLevelObj.getChildUserName());
		callableStatement.setString(4, UserManagementUserLevelObj.getRoleDesc());
		callableStatement.setString(5, UserManagementUserLevelObj.getStatus());
		callableStatement.setString(6,pageNum);
		callableStatement.registerOutParameter(7, OracleTypes.CURSOR);
		callableStatement.registerOutParameter(8,Types.INTEGER);
		callableStatement.registerOutParameter(9, Types.VARCHAR);
		
		
		callableStatement.executeUpdate();
		
		//reportslogger.info("callable statements executed");
		
		int totalPages = callableStatement.getInt(8);
		
		//reportslogger.info("totalpages got from proc:" + totalPages);
		
		resultset=(ResultSet) callableStatement.getObject(7);

		
		UserManagementUserLevelObj.setStatusMsg(callableStatement.getString(9));

        reportslogger.info("Error Msg at DaoImpl:"+UserManagementUserLevelObj.getStatusMsg());
		
if(resultset==null)
{
reportslogger.info("Resultset is null in DaoImpl");

}
else
{

		while (resultset!=null &&resultset.next()) {
				//reportslogger.info("inside while!");
				UserManagementUserLevel UserManagementUserLevelObject= new UserManagementUserLevel();
				
				UserManagementUserLevelObject.setChildOlmId(resultset.getString("USERID"));
				UserManagementUserLevelObject.setChildUserName(resultset.getString("USER_NAME"));
				UserManagementUserLevelObject.setRoleDesc(resultset.getString("USER_ROLE"));
				UserManagementUserLevelObject.setVendorId(resultset.getString("VENDOR_ID"));
				UserManagementUserLevelObject.setEmailId(resultset.getString("EMAILID"));
				UserManagementUserLevelObject.setCircle(resultset.getString("CIRCLE"));
				UserManagementUserLevelObject.setApplicableProcess(resultset.getString("TRANSFER_TYPE"));		
				UserManagementUserLevelObject.setStatus(resultset.getString("STATUS"));
				
				SimpleDateFormat dateString = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss");
				SimpleDateFormat dateString1 = new SimpleDateFormat(
						"dd/MM/yyyy HH:mm:ss");
				if(resultset.getString("ACTIVE_DATE")!=null){
				String activeDate = resultset.getString("ACTIVE_DATE");
				
				Date date1 = dateString.parse(activeDate);
				
				String finalDate = dateString1.format(date1);		
				UserManagementUserLevelObject.setActiveDate(finalDate);}
				else
				UserManagementUserLevelObject.setActiveDate(resultset.getString("ACTIVE_DATE"));
				
				if(resultset.getString("INACTIVE_DATE")!=null){
				String inactiveDate = resultset.getString("INACTIVE_DATE");
				Date date2 = dateString.parse(inactiveDate);
				String finalDate2 = dateString1.format(date2);	
				UserManagementUserLevelObject.setInactiveDate(finalDate2);}
				else 
					UserManagementUserLevelObject.setInactiveDate(resultset.getString("INACTIVE_DATE"));
				
		
				UserMgmtUserLevelExcelList.add(UserManagementUserLevelObject);
		}
}
		reportslogger.info("User Management-User Level Excel Records list size in DaoImpl:" + UserMgmtUserLevelExcelList.size());

		
	} catch (SQLException e) 
    {
		  StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
	return null;
    }
	catch (Exception e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		reportslogger.error(errors);
		return null;
	}
	finally {
		if(resultset!=null){
	     	   try {
	     		  resultset.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
				}
	     	   }
		
		if(callableStatement!=null){
	     	   try {
	     		  callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
				}
	     	   }
				
	    	   if(conn!=null){
	         	   try {
	    				conn.close();
	    			} catch (Exception e) {
	    				StringWriter errors= new StringWriter();
	    				e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
	    			}
	         
	         	   }
	}
	return UserMgmtUserLevelExcelList;
}
	/**********************************user management -user level report ends**********************************************************/




/***********************************************************************aps new reports*******************************************************************/
public HashMap<Integer, List<PayPostingChequeDetails>> getPaymntPostingChequeMap(
		PayPostingChequeDetails PyPostChequeDetailsObj, int page) {

	HashMap<Integer, List<PayPostingChequeDetails>> ReportsMap = new HashMap<Integer, List<PayPostingChequeDetails>>();
	List<PayPostingChequeDetails> DetailsList = new ArrayList<PayPostingChequeDetails>();
	ResultSet resultset = null;
	CallableStatement callableStatement=null;

	//reportslogger.info("page number in dao:" + page);

	try {
		reportslogger.info("Payment Posting Cheque Level Method in DaoImpl");
		//reportslogger.info("connection:" + dataSource.getConnection());*/
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		conn = jdbcTemplate.getDataSource().getConnection();
		//reportslogger.info("connection established");

		final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_USER_CHEQUE_RECORD_DETAILS(?,?,?,?,?,?,?,?,?,?,?,?)}";

		 callableStatement = conn
				.prepareCall(procedureCall);

		callableStatement.setString(1,
				PyPostChequeDetailsObj.getParentUser());
		callableStatement.setString(2,
				PyPostChequeDetailsObj.getUserOLMId());
		callableStatement.setString(3, PyPostChequeDetailsObj.getFileId());
		callableStatement
				.setString(4, PyPostChequeDetailsObj.getFileName());
		callableStatement.setString(5, PyPostChequeDetailsObj.getChqNo());
		callableStatement
				.setString(6, PyPostChequeDetailsObj.getVendorId());
		callableStatement.setString(7, PyPostChequeDetailsObj.getToDate());
		callableStatement
				.setString(8, PyPostChequeDetailsObj.getFromDate());

		callableStatement.setInt(9, page);
		callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
		callableStatement.registerOutParameter(11, Types.INTEGER);
		callableStatement.registerOutParameter(12, Types.VARCHAR);
		callableStatement.executeUpdate();

		//reportslogger.info("callable statements executed");

		int totalPages = callableStatement.getInt(11);

		//reportslogger.info("totalpages got from proc:" + totalPages);

		resultset = (ResultSet) callableStatement.getObject(10);

		PyPostChequeDetailsObj
				.setStatusMsg(callableStatement.getString(12));

	reportslogger.info("Error Msg at DaoImpl:"
				+ PyPostChequeDetailsObj.getStatusMsg());

		if (resultset == null) {
			reportslogger.info("Resultset is null in daoImpl");

		} else {

			while (resultset != null && resultset.next()) {
				//reportslogger.info("inside while!");

				PayPostingChequeDetails PyPostChequeDetailsObject = new PayPostingChequeDetails();

				PyPostChequeDetailsObject.setChqNo(resultset
						.getString("CHEQUE_NO"));
				PyPostChequeDetailsObject.setBankName(resultset
						.getString("BANK_NAME"));
				PyPostChequeDetailsObject.setVendorName(resultset
						.getString("VENDOR_NAME"));
				PyPostChequeDetailsObject.setUserOLMId(resultset
						.getString("USER_OLM_ID"));
				PyPostChequeDetailsObject.setFileName(resultset
						.getString("FILE_NAME"));

				String StringChqDate = resultset
						.getString("CHEQUE_DATE");
				SimpleDateFormat dateString = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss");
				Date ChqParseddate = dateString.parse(StringChqDate);
				SimpleDateFormat dateString1 = new SimpleDateFormat(
						"dd/MM/yyyy HH:mm:ss");
				String finalChqDate = dateString1.format(ChqParseddate);
				String dateChq[] = finalChqDate.split(" ");
				PyPostChequeDetailsObject.setDateOnChq(dateChq[0]);

				PyPostChequeDetailsObject.setNoOfAccPosted(resultset
						.getInt("NO_ACC_EXT_ID_POSTED"));
				PyPostChequeDetailsObject.setNoOfInvPosted(resultset
						.getInt("NO_INVOICE_POSTED"));
				PyPostChequeDetailsObject.setChqVal(resultset
						.getString("PAYMENT_AMOUNT_TOTAL"));
				PyPostChequeDetailsObject.setValPendingLIU(resultset
						.getString("PAYMENT_AMOUNT_LIU"));
				PyPostChequeDetailsObject.setValPostedFX(resultset
						.getString("PAYMENT_AMOUNT_POSTED"));

				String StringUploadDate = resultset
						.getString("FILE_UPLOAD_DATE");
				// SimpleDateFormat dateString = new SimpleDateFormat(
				// "yyyy-MM-dd HH:mm:ss");
				Date uploadParseddate = dateString.parse(StringUploadDate);
				// SimpleDateFormat dateString1 = new SimpleDateFormat(
				// "dd/MM/yyyy HH:mm:ss");
				String finalUploadDate = dateString1
						.format(uploadParseddate);

				if (finalUploadDate == null || finalUploadDate == "") {
					PyPostChequeDetailsObject.setChqUploadDt("");
					PyPostChequeDetailsObject.setChqUploadTym("");
				} else {
					String uploadDateAndTime[] = finalUploadDate.split(" ");
					PyPostChequeDetailsObject
							.setChqUploadDt(uploadDateAndTime[0]);
					PyPostChequeDetailsObject
							.setChqUploadTym(uploadDateAndTime[1]);

				}

				if (resultset.getString("PAYMENT_POSTED_DATE") != null) {
					String StringPostedDate = resultset
							.getString("PAYMENT_POSTED_DATE");
					Date PostedParseddate = dateString
							.parse(StringPostedDate);
					String finalPostedDate = dateString1
							.format(PostedParseddate);
					if ((finalPostedDate == null)
							|| (finalPostedDate == "")
							|| (finalPostedDate.equalsIgnoreCase("null"))) {
						PyPostChequeDetailsObject.setPostingDate("");
						PyPostChequeDetailsObject.setPostingTime("");
					} else {
						String PostingDate[] = finalPostedDate.split(" ");
						PyPostChequeDetailsObject
								.setPostingDate(PostingDate[0]);
						PyPostChequeDetailsObject
								.setPostingTime(PostingDate[1]);
					}
				} else
					PyPostChequeDetailsObject.setPostingDate(resultset
							.getString("PAYMENT_POSTED_DATE"));

				PyPostChequeDetailsObject.setDiffChqvsUpload(resultset
						.getInt("DIFF_CHEQUE_UPLOAD_DATE"));
				PyPostChequeDetailsObject.setDiffUploadvsPosted(resultset
						.getInt("DIFF_UPLOAD_POSTED_DATE"));
				PyPostChequeDetailsObject.setFileId(resultset
						.getString("FILE_ID"));
				PyPostChequeDetailsObject.setVendorId(resultset
						.getString("VENDOR_ID"));
				PyPostChequeDetailsObject.setBankAccNo(resultset
						.getString("BANK_VIRTUAL_ACCOUNT_NO"));

				DetailsList.add(PyPostChequeDetailsObject);
			}
		}
		reportslogger.info("Payment Posting Cheque Level Records list size in daoImpl:" + DetailsList.size());

		ReportsMap.put(totalPages, DetailsList);
	}
	 catch (SQLException e) 
     {
		  StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
	return null;
     }
	catch (Exception e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		reportslogger.error(errors);
		return null;
	} finally {
		if(resultset!=null){
	     	   try {
	     		  resultset.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
				}
	     	   }
		
		if(callableStatement!=null){
	     	   try {
	     		  callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
				}
	     	   }
				
	    	   if(conn!=null){
	         	   try {
	    				conn.close();
	    			} catch (Exception e) {
	    				StringWriter errors= new StringWriter();
	    				e.printStackTrace(new PrintWriter(errors));
	    				reportslogger.error(errors);
	    			}
	         
	         	   }
	}
	return ReportsMap;
}

public List<PayPostingChequeDetails> getPyPostChequeDetailsList(
		PayPostingChequeDetails PyPostChequeDetailsObj, String pageNum) {

	List<PayPostingChequeDetails> PyPostChequeDetailsList = new ArrayList<PayPostingChequeDetails>();
	ResultSet resultset = null;
	CallableStatement callableStatement=null;

	//reportslogger.info("page number in dao:" + pageNum);

	try {
		reportslogger.info("Payment Posting Cheque Level Excel Download in DaoImpl");
		//reportslogger.info("connection:" + dataSource.getConnection());*/
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		conn = jdbcTemplate.getDataSource().getConnection();
		//reportslogger.info("connection established");

		final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_USER_CHEQUE_RECORD_DETAILS(?,?,?,?,?,?,?,?,?,?,?,?)}";

		 callableStatement = conn
				.prepareCall(procedureCall);

		callableStatement.setString(1,
				PyPostChequeDetailsObj.getParentUser());
		callableStatement.setString(2,
				PyPostChequeDetailsObj.getUserOLMId());
		callableStatement.setString(3, PyPostChequeDetailsObj.getFileId());
		callableStatement
				.setString(4, PyPostChequeDetailsObj.getFileName());
		callableStatement.setString(5, PyPostChequeDetailsObj.getChqNo());
		callableStatement
				.setString(6, PyPostChequeDetailsObj.getVendorId());
		callableStatement.setString(7, PyPostChequeDetailsObj.getToDate());
		callableStatement
				.setString(8, PyPostChequeDetailsObj.getFromDate());

		callableStatement.setString(9, pageNum);
		callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
		callableStatement.registerOutParameter(11, Types.INTEGER);
		callableStatement.registerOutParameter(12, Types.VARCHAR);
		callableStatement.executeUpdate();

		//reportslogger.info("callable statements executed");

		int totalPages = callableStatement.getInt(11);

		//reportslogger.info("totalpages got from proc:" + totalPages);

		resultset = (ResultSet) callableStatement.getObject(10);

		PyPostChequeDetailsObj
				.setStatusMsg(callableStatement.getString(12));

	reportslogger.info("Error Msg at DaoImpl:"+ PyPostChequeDetailsObj.getStatusMsg());

		if (resultset == null) {
			reportslogger.info("Resultset is null in daoImpl");

		} else {

			while (resultset != null && resultset.next()) {
				//reportslogger.info("inside while!");

				PayPostingChequeDetails PyPostChequeDetailsObject = new PayPostingChequeDetails();

				PyPostChequeDetailsObject.setChqNo(resultset
						.getString("CHEQUE_NO"));
				PyPostChequeDetailsObject.setBankName(resultset
						.getString("BANK_NAME"));
				PyPostChequeDetailsObject.setVendorName(resultset
						.getString("VENDOR_NAME"));
				PyPostChequeDetailsObject.setUserOLMId(resultset
						.getString("USER_OLM_ID"));
				PyPostChequeDetailsObject.setFileName(resultset
						.getString("FILE_NAME"));

				String StringChqDate = resultset
						.getString("FILE_UPLOAD_DATE");
				SimpleDateFormat dateString = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss");
				Date ChqParseddate = dateString.parse(StringChqDate);
				SimpleDateFormat dateString1 = new SimpleDateFormat(
						"dd/MM/yyyy HH:mm:ss");
				String finalChqDate = dateString1.format(ChqParseddate);
				String dateChq[] = finalChqDate.split(" ");
				PyPostChequeDetailsObject.setDateOnChq(dateChq[0]);

				PyPostChequeDetailsObject.setNoOfAccPosted(resultset
						.getInt("NO_ACC_EXT_ID_POSTED"));
				PyPostChequeDetailsObject.setNoOfInvPosted(resultset
						.getInt("NO_INVOICE_POSTED"));
				PyPostChequeDetailsObject.setChqVal(resultset
						.getString("PAYMENT_AMOUNT_TOTAL"));
				PyPostChequeDetailsObject.setValPendingLIU(resultset
						.getString("PAYMENT_AMOUNT_LIU"));
				PyPostChequeDetailsObject.setValPostedFX(resultset
						.getString("PAYMENT_AMOUNT_POSTED"));

				String StringUploadDate = resultset
						.getString("FILE_UPLOAD_DATE");
				// SimpleDateFormat dateString = new SimpleDateFormat(
				// "yyyy-MM-dd HH:mm:ss");
				Date uploadParseddate = dateString.parse(StringUploadDate);
				// SimpleDateFormat dateString1 = new SimpleDateFormat(
				// "dd/MM/yyyy HH:mm:ss");
				String finalUploadDate = dateString1
						.format(uploadParseddate);

				if (finalUploadDate == null || finalUploadDate == "") {
					PyPostChequeDetailsObject.setChqUploadDt("");
					PyPostChequeDetailsObject.setChqUploadTym("");
				} else {
					String uploadDateAndTime[] = finalUploadDate.split(" ");
					PyPostChequeDetailsObject
							.setChqUploadDt(uploadDateAndTime[0]);
					PyPostChequeDetailsObject
							.setChqUploadTym(uploadDateAndTime[1]);

				}

				if (resultset.getString("PAYMENT_POSTED_DATE") != null) {
					String StringPostedDate = resultset
							.getString("PAYMENT_POSTED_DATE");
					Date PostedParseddate = dateString
							.parse(StringPostedDate);
					String finalPostedDate = dateString1
							.format(PostedParseddate);
					if ((finalPostedDate == null)
							|| (finalPostedDate == "")
							|| (finalPostedDate.equalsIgnoreCase("null"))) {
						PyPostChequeDetailsObject.setPostingDate("");
						PyPostChequeDetailsObject.setPostingTime("");
					} else {
						String PostingDate[] = finalPostedDate.split(" ");
						PyPostChequeDetailsObject
								.setPostingDate(PostingDate[0]);
						PyPostChequeDetailsObject
								.setPostingTime(PostingDate[1]);
					}
				} else
					PyPostChequeDetailsObject.setPostingDate(resultset
							.getString("PAYMENT_POSTED_DATE"));

				PyPostChequeDetailsObject.setDiffChqvsUpload(resultset
						.getInt("DIFF_CHEQUE_UPLOAD_DATE"));
				PyPostChequeDetailsObject.setDiffUploadvsPosted(resultset
						.getInt("DIFF_UPLOAD_POSTED_DATE"));
				PyPostChequeDetailsObject.setFileId(resultset
						.getString("FILE_ID"));
				PyPostChequeDetailsObject.setVendorId(resultset
						.getString("VENDOR_ID"));
				PyPostChequeDetailsObject.setBankAccNo(resultset
						.getString("BANK_VIRTUAL_ACCOUNT_NO"));

				PyPostChequeDetailsList.add(PyPostChequeDetailsObject);
			}
		}
		reportslogger.info("Payment Posting Cheque Level excel Records list size in daoImpl:" + PyPostChequeDetailsList.size());

	} catch (SQLException e) 
     {
		  StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
	return null;
     } 
	catch (Exception e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		reportslogger.error(errors);
		return null;
	} finally {
		if(resultset!=null){
	     	   try {
	     		  resultset.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
				}
	     	   }
		
		if(callableStatement!=null){
	     	   try {
	     		  callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
				}
	     	   }
				
	    	   if(conn!=null){
	         	   try {
	    				conn.close();
	    			} catch (Exception e) {
	    				StringWriter errors= new StringWriter();
	    				e.printStackTrace(new PrintWriter(errors));
	    				reportslogger.error(errors);
	    			}
	         
	         	   }
	}
	return PyPostChequeDetailsList;
}


public HashMap<Integer, List<PayPostingTransLevelDetails>> getPaymntPostingTranslevelMapAps(
		PayPostingTransLevelDetails PymntPostingTransLevelDetailsObj,
		int page) {

	HashMap<Integer, List<PayPostingTransLevelDetails>> ReportsMap = new HashMap<Integer, List<PayPostingTransLevelDetails>>();
	List<PayPostingTransLevelDetails> DetailsList = new ArrayList<PayPostingTransLevelDetails>();
	ResultSet resultset = null;
	CallableStatement callableStatement=null;

	//reportslogger.info("page number in dao:" + page);

	try {
		reportslogger.info("Payment Posting Trans Level Method  In DaoImpl");
		//reportslogger.info("connection:" + dataSource.getConnection());*/
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		conn = jdbcTemplate.getDataSource().getConnection();
		//reportslogger.info("connection established");

		final String procedureCall = "{call AIRTL_PAYMENT_REPORTS_PKG.PAYMENT_POSTING_TRANSACTIONS(?,?,?,?,?,?,?,?,?,?,?,?,?)}";

		callableStatement = conn
				.prepareCall(procedureCall);

		callableStatement.setString(1,
				PymntPostingTransLevelDetailsObj.getParentUserId());
		callableStatement.setString(2,
				PymntPostingTransLevelDetailsObj.getChildUserId());
		callableStatement.setString(3,
				PymntPostingTransLevelDetailsObj.getFileId());
		callableStatement.setString(4,
				PymntPostingTransLevelDetailsObj.getFileName());
		callableStatement.setString(5,
				PymntPostingTransLevelDetailsObj.getRefNo());
		callableStatement.setString(6,
				PymntPostingTransLevelDetailsObj.getMode());
		callableStatement.setString(7,
				PymntPostingTransLevelDetailsObj.getVendorId());
		callableStatement.setString(8,
				PymntPostingTransLevelDetailsObj.getToDate());
		callableStatement.setString(9,
				PymntPostingTransLevelDetailsObj.getFromDate());
		callableStatement.setInt(10, page);
		callableStatement.registerOutParameter(11, OracleTypes.CURSOR);
		callableStatement.registerOutParameter(12, Types.INTEGER);
		callableStatement.registerOutParameter(13, Types.VARCHAR);
		callableStatement.executeUpdate();

		//reportslogger.info("callable statements executed");

		int totalPages = callableStatement.getInt(12);

		//reportslogger.info("totalpages got from proc:" + totalPages);

		resultset = (ResultSet) callableStatement.getObject(11);

		PymntPostingTransLevelDetailsObj.setStatusMsg(callableStatement
				.getString(13));

		reportslogger.info("Error Msg at DaoImpl"
				+ PymntPostingTransLevelDetailsObj.getStatusMsg());

		if (resultset == null) {
			reportslogger.info("Resultset is null in DaoImpl");

		} else {

			while (resultset != null && resultset.next()) {
				//reportslogger.info("inside while!");
				PayPostingTransLevelDetails PymntPostingTransLevelDetailsObject = new PayPostingTransLevelDetails();

				PymntPostingTransLevelDetailsObject.setRefNo(resultset
						.getString("REF_NUMBER"));
				PymntPostingTransLevelDetailsObject.setVendorId(resultset
						.getString("VENDOR_ID"));
				/*
				 * reportslogger.info("vendor id"+
				 * PymntPostingTransLevelDetailsObject.getVendorId());
				 */
				PymntPostingTransLevelDetailsObject.setVendorName(resultset
						.getString("VENDOR_NAME"));
				PymntPostingTransLevelDetailsObject
						.setChildUserId(resultset.getString("USER_ID"));
				PymntPostingTransLevelDetailsObject.setFileId(resultset
						.getString("FILE_ID"));
				PymntPostingTransLevelDetailsObject.setFileName(resultset
						.getString("ORIGINAL_FILE_NAME"));
				PymntPostingTransLevelDetailsObject.setFileSource(resultset
						.getString("FILE_SOURCE"));
			
				PymntPostingTransLevelDetailsObject.setMode(resultset
						.getString("PAYMENT_MODE"));
				String date = resultset.getString("FILE_UPLOAD_DATE");
				SimpleDateFormat dateString = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss");
				Date date1 = dateString.parse(date);
				SimpleDateFormat dateString1 = new SimpleDateFormat(
						"dd/MM/yyyy HH:mm:ss");
				String finalDate = dateString1.format(date1);
				PymntPostingTransLevelDetailsObject
						.setUploadTime(finalDate);
				PymntPostingTransLevelDetailsObject.setApprovedBy(resultset
						.getString("APPROVED_BY"));				
				if(resultset.getString("APPROVED_DATE")==null||resultset.getString("APPROVED_DATE").equalsIgnoreCase(""))
				{
					PymntPostingTransLevelDetailsObject.setApprovedDate(resultset.getString("APPROVED_DATE"));
				}
				else
				{
					String approvedDate = resultset.getString("APPROVED_DATE");
					Date date2 = dateString.parse(approvedDate);
					String approvedFinalDate = dateString1.format(date2);
					PymntPostingTransLevelDetailsObject.setApprovedDate(approvedFinalDate);
				}
				
				
			//	PymntPostingTransLevelDetailsObject.setApprovedDate(resultset.getString("APPROVED_DATE"));
				PymntPostingTransLevelDetailsObject.setAccountNo(resultset
						.getString("ACCT_EXT_ID"));
				PymntPostingTransLevelDetailsObject.setInvoice(resultset
						.getString("INVOICE_NO"));
				PymntPostingTransLevelDetailsObject.setTotalVal(resultset
						.getString("PAYMENT_AMOUNT"));
				PymntPostingTransLevelDetailsObject.setStatus(resultset
						.getString("STATUS"));
				reportslogger.info("hey the status is--------->>>>>>>>>>>>>>>>>>>"+resultset
						.getString("STATUS"));
				/*
				 * if(resultset.getString("PAYMENT_POSTED_DATE")==null){
				 * }else{String
				 * date[]=resultset.getString("PAYMENT_POSTED_DATE"
				 * ).split(" ");
				 * PymntPostingTransLevelDetailsObject.setFXpostingTime
				 * (date[0]);}
				 */

				if (resultset.getString("PAYMENT_POSTED_DATE") != null) {
					String StringPosted = resultset
							.getString("PAYMENT_POSTED_DATE");
					Date datePosted = dateString.parse(StringPosted);
					String finalDate1 = dateString1.format(datePosted);
					PymntPostingTransLevelDetailsObject
							.setFXpostingTime(finalDate1);
				} else
					PymntPostingTransLevelDetailsObject
							.setFXpostingTime(resultset
									.getString("PAYMENT_POSTED_DATE"));
				PymntPostingTransLevelDetailsObject.setTrackingId(resultset
						.getString("TRACKING_ID"));
				PymntPostingTransLevelDetailsObject
						.setTrackingIdServ(resultset
								.getString("TRACKING_ID_SERV"));
				PymntPostingTransLevelDetailsObject
						.setReasonForLiuorFailure(resultset
								.getString("LIU_REASON"));
				PymntPostingTransLevelDetailsObject.setBankAccNo(resultset.getString("BANK_ACCOUNT_NUMBER"));
				PymntPostingTransLevelDetailsObject.setSiNumber(resultset.getString("DEL_NO"));
				if(resultset.getString("LOB")==null||resultset.getString("LOB").equalsIgnoreCase(""))
				{
					PymntPostingTransLevelDetailsObject.setLob("");
				}
				else
				{
				if(resultset.getString("LOB").equalsIgnoreCase("BTS"))
				{
					PymntPostingTransLevelDetailsObject.setLob("FL");
				}
				else
				PymntPostingTransLevelDetailsObject.setLob(resultset.getString("LOB"));
				}

				DetailsList.add(PymntPostingTransLevelDetailsObject);
			}
		}
		reportslogger.info("Payment Posting Trans level Records list size in DaoImpl:" + DetailsList.size());

		ReportsMap.put(totalPages, DetailsList);
	} catch (SQLException e) 
     {
		  StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
	return null;
     } 
	catch (Exception e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		reportslogger.error(errors);
		return null;
	} finally {
		if(resultset!=null){
	     	   try {
	     		  resultset.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
				}
	     	   }
		
		if(callableStatement!=null){
	     	   try {
	     		  callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
				}
	     	   }
				
	    	   if(conn!=null){
	         	   try {
	    				conn.close();
	    			} catch (Exception e) {
	    				StringWriter errors= new StringWriter();
	    				e.printStackTrace(new PrintWriter(errors));
	    				reportslogger.error(errors);
	    			}
	         
	         	   }
	}
	return ReportsMap;

}

public List<PayPostingTransLevelDetails> getPayPostTransactionExcelListAps(
		PayPostingTransLevelDetails PymntPostingTransLevelDetailsObj,
		String pageNum) {

	List<PayPostingTransLevelDetails> PayPostTransactionExcelList = new ArrayList<PayPostingTransLevelDetails>();
	ResultSet resultset = null;
	CallableStatement callableStatement=null;

	//reportslogger.info("page number in dao:" + pageNum);

	try {
		reportslogger.info("Payment Posting Trans Level Excel Download in DaoImpl");
		//reportslogger.info("connection:" + dataSource.getConnection());*/
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		conn = jdbcTemplate.getDataSource().getConnection();
		/*reportslogger.info("connection established");*/

		final String procedureCall = "{call AIRTL_PAYMENT_REPORTS_PKG.PAYMENT_POSTING_TRANSACTIONS(?,?,?,?,?,?,?,?,?,?,?,?,?)}";

		callableStatement = conn
				.prepareCall(procedureCall);

		callableStatement.setString(1,
				PymntPostingTransLevelDetailsObj.getParentUserId());
		callableStatement.setString(2,
				PymntPostingTransLevelDetailsObj.getChildUserId());
		callableStatement.setString(3,
				PymntPostingTransLevelDetailsObj.getFileId());
		callableStatement.setString(4,
				PymntPostingTransLevelDetailsObj.getFileName());
		callableStatement.setString(5,
				PymntPostingTransLevelDetailsObj.getRefNo());
		callableStatement.setString(6,
				PymntPostingTransLevelDetailsObj.getMode());
		callableStatement.setString(7,
				PymntPostingTransLevelDetailsObj.getVendorId());
		callableStatement.setString(8,
				PymntPostingTransLevelDetailsObj.getToDate());
		callableStatement.setString(9,
				PymntPostingTransLevelDetailsObj.getFromDate());
		callableStatement.setString(10, pageNum);
		callableStatement.registerOutParameter(11, OracleTypes.CURSOR);
		callableStatement.registerOutParameter(12, Types.INTEGER);
		callableStatement.registerOutParameter(13, Types.VARCHAR);
		callableStatement.executeUpdate();

		//reportslogger.info("callable statements executed");

		int totalPages = callableStatement.getInt(12);

		//reportslogger.info("totalpages got from proc:" + totalPages);

		resultset = (ResultSet) callableStatement.getObject(11);

		PymntPostingTransLevelDetailsObj.setStatusMsg(callableStatement
				.getString(13));

		reportslogger.info("Error Msg at DaoImpl:"
				+ PymntPostingTransLevelDetailsObj.getStatusMsg());

		if (resultset == null) {
			reportslogger.info("Resultset is null in daoImpl");

		} else {

			while (resultset != null && resultset.next()) {
				//reportslogger.info("inside while!");
				PayPostingTransLevelDetails PymntPostingTransLevelDetailsObject = new PayPostingTransLevelDetails();

				PymntPostingTransLevelDetailsObject.setRefNo(resultset
						.getString("REF_NUMBER"));
				PymntPostingTransLevelDetailsObject.setVendorId(resultset
						.getString("VENDOR_ID"));
				/*
				 * reportslogger.info("vendor id"+
				 * PymntPostingTransLevelDetailsObject.getVendorId());
				 */
				PymntPostingTransLevelDetailsObject.setVendorName(resultset
						.getString("VENDOR_NAME"));
				PymntPostingTransLevelDetailsObject
						.setChildUserId(resultset.getString("USER_ID"));
				PymntPostingTransLevelDetailsObject.setFileId(resultset
						.getString("FILE_ID"));
				PymntPostingTransLevelDetailsObject.setFileName(resultset
						.getString("ORIGINAL_FILE_NAME"));
				PymntPostingTransLevelDetailsObject.setFileSource(resultset
						.getString("FILE_SOURCE"));
				if(resultset.getString("PAYMENT_MODE").equalsIgnoreCase("OTHERS"))
					PymntPostingTransLevelDetailsObject.setMode("MISCELLANEOUS");
				else
				PymntPostingTransLevelDetailsObject.setMode(resultset
						.getString("PAYMENT_MODE"));
				String date = resultset.getString("FILE_UPLOAD_DATE");
				SimpleDateFormat dateString = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss");
				Date date1 = dateString.parse(date);
				SimpleDateFormat dateString1 = new SimpleDateFormat(
						"dd/MM/yyyy HH:mm:ss");
				String finalDate = dateString1.format(date1);
				PymntPostingTransLevelDetailsObject
						.setUploadTime(finalDate);
				PymntPostingTransLevelDetailsObject.setApprovedBy(resultset
						.getString("APPROVED_BY"));
				
				if(resultset.getString("APPROVED_DATE")==null||resultset.getString("APPROVED_DATE").equalsIgnoreCase(""))
				{
					PymntPostingTransLevelDetailsObject.setApprovedDate(resultset.getString("APPROVED_DATE"));
				}
				else
				{
					String approvedDate = resultset.getString("APPROVED_DATE");
					Date date2 = dateString.parse(approvedDate);
					String approvedFinalDate = dateString1.format(date2);
					PymntPostingTransLevelDetailsObject.setApprovedDate(approvedFinalDate);
				}
				
				//PymntPostingTransLevelDetailsObject.setApprovedDate(resultset.getString("APPROVED_DATE"));
				PymntPostingTransLevelDetailsObject.setAccountNo(resultset
						.getString("ACCT_EXT_ID"));
				PymntPostingTransLevelDetailsObject.setInvoice(resultset
						.getString("INVOICE_NO"));
				PymntPostingTransLevelDetailsObject.setTotalVal(resultset
						.getString("PAYMENT_AMOUNT"));
				PymntPostingTransLevelDetailsObject.setStatus(resultset
						.getString("STATUS"));
				/*
				 * if(resultset.getString("PAYMENT_POSTED_DATE")==null){
				 * }else{String
				 * date[]=resultset.getString("PAYMENT_POSTED_DATE"
				 * ).split(" ");
				 * PymntPostingTransLevelDetailsObject.setFXpostingTime
				 * (date[0]);}
				 */

				if (resultset.getString("PAYMENT_POSTED_DATE") != null) {
					String StringPosted = resultset
							.getString("PAYMENT_POSTED_DATE");
					Date datePosted = dateString.parse(StringPosted);
					String finalDate1 = dateString1.format(datePosted);
					PymntPostingTransLevelDetailsObject
							.setFXpostingTime(finalDate1);
				} else
					PymntPostingTransLevelDetailsObject
							.setFXpostingTime(resultset
									.getString("PAYMENT_POSTED_DATE"));
				PymntPostingTransLevelDetailsObject.setTrackingId(resultset
						.getString("TRACKING_ID"));
				PymntPostingTransLevelDetailsObject
						.setTrackingIdServ(resultset
								.getString("TRACKING_ID_SERV"));
				PymntPostingTransLevelDetailsObject
						.setReasonForLiuorFailure(resultset
								.getString("LIU_REASON"));
				PymntPostingTransLevelDetailsObject.setBankAccNo(resultset.getString("BANK_ACCOUNT_NUMBER"));
				PymntPostingTransLevelDetailsObject.setSiNumber(resultset.getString("DEL_NO"));
				if(resultset.getString("LOB")==null||resultset.getString("LOB").equalsIgnoreCase(""))
				{
					PymntPostingTransLevelDetailsObject.setLob("");
				}
				else
				{
				if(resultset.getString("LOB").equalsIgnoreCase("BTS"))
				{
					PymntPostingTransLevelDetailsObject.setLob("FL");
				}
				else
				PymntPostingTransLevelDetailsObject.setLob(resultset.getString("LOB"));
				}

				PayPostTransactionExcelList
						.add(PymntPostingTransLevelDetailsObject);
			}
		}
		reportslogger.info("Payment Posting Trans Level Excel Records list size in daoImpl:"
				+ PayPostTransactionExcelList.size());

	} catch (SQLException e) 
     {
		  StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
	return null;
     }
	catch (Exception e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		reportslogger.error(errors);
		return null;
	} finally {
		if(resultset!=null){
	     	   try {
	     		  resultset.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
				}
	     	   }
		
		if(callableStatement!=null){
	     	   try {
	     		  callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
				}
	     	   }
				
	    	   if(conn!=null){
	         	   try {
	    				conn.close();
	    			} catch (Exception e) {
	    				StringWriter errors= new StringWriter();
	    				e.printStackTrace(new PrintWriter(errors));
	    				reportslogger.error(errors);
	    			}
	         
	         	   }
	}
	return PayPostTransactionExcelList;

}


/***********************************************************Aps Reversal Reports************************************************************************/



public HashMap<Integer, List<PaymentDirectReversalBean>> getPayDirectReversalDetailsAps(
		PaymentDirectReversalBean PayDirectReversalBeanObj, int page) {
	HashMap<Integer, List<PaymentDirectReversalBean>> payDirectReversalMap = new HashMap<Integer, List<PaymentDirectReversalBean>>();
	List<PaymentDirectReversalBean> payDirectReversalList = new ArrayList<PaymentDirectReversalBean>();
	ResultSet resultset = null;
	CallableStatement callableStatement=null;
//	reportslogger.info("page number in dao" + page);

	try {
		reportslogger.info("Payment Direct Reversal method in DaoImpl");
		//reportslogger.info("connection" + dataSource.getConnection());*/
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		conn = jdbcTemplate.getDataSource().getConnection();
//		reportslogger.info("connection established");
//		reportslogger.info("in dao child userid"
//				+ PayDirectReversalBeanObj.getChildUserId());

		// call proc
		final String procedureCall = "{call AIRTL_PAYMENT_REPORTS_PKG.PAYMENT_REVERSAL_TRASACTIONS(?,?,?,?,?,?,?,?,?,?,?,?)}";

		callableStatement = conn
				.prepareCall(procedureCall);

		/* callableStatement.setInt(1, page); */
		callableStatement.setString(1,
				PayDirectReversalBeanObj.getParentUserId());
		callableStatement.setString(2,
				PayDirectReversalBeanObj.getChildUserId());
		callableStatement
				.setString(3, PayDirectReversalBeanObj.getFileId());
		callableStatement.setString(4,
				PayDirectReversalBeanObj.getFileName());
		callableStatement.setString(5,
				PayDirectReversalBeanObj.getTrackingId());
		callableStatement.setString(6,
				PayDirectReversalBeanObj.getVendorId());
		callableStatement
				.setString(7, PayDirectReversalBeanObj.getToDate());
		callableStatement.setString(8,
				PayDirectReversalBeanObj.getFromDate());
		callableStatement.setInt(9, page);
		callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
		callableStatement.registerOutParameter(11, Types.INTEGER);
		callableStatement.registerOutParameter(12, Types.VARCHAR);
		//reportslogger.info("before execute update");
		callableStatement.executeUpdate();
		//reportslogger.info("callable statements executed");

		int totalPages = callableStatement.getInt(11);

		String statusMsg = callableStatement.getString(12);// msg

		resultset = (ResultSet) callableStatement.getObject(10);

		PayDirectReversalBeanObj.setStatusMsg(statusMsg);

		// reportslogger.info("result set size"+resultset.getFetchSize());
		reportslogger.info("Error Msg at DaoImpl"+ PayDirectReversalBeanObj.getStatusMsg());
			
		/* reportslogger.info("totalpages:" + totalPages); */

		if (resultset == null) {
			reportslogger.info("Resultset is null in daoImpl");

		} else {
			while (resultset != null && resultset.next()) {
				//reportslogger.info("inside while!");
				PaymentDirectReversalBean payDirectReversalBeanObject = new PaymentDirectReversalBean();

				payDirectReversalBeanObject.setAccountNumber(resultset
						.getString("ACCT_EXT_ID"));

				payDirectReversalBeanObject.setTrackingId(resultset
						.getString("TRACKING_ID"));

				payDirectReversalBeanObject.setTrackingIdServ(resultset
						.getString("TRACKING_ID_SERV"));
				payDirectReversalBeanObject.setUploadedByOlmId(resultset
						.getString("VENDOR_USERID"));
				payDirectReversalBeanObject.setUploadedByName(resultset
						.getString("USER_NAME"));
				payDirectReversalBeanObject.setFileId(resultset
						.getString("FILE_ID"));
				payDirectReversalBeanObject.setFileName(resultset
						.getString("ORIGINAL_FILE_NAME"));
				String date = resultset.getString("FILE_UPLOAD_DATE");
				SimpleDateFormat dateString = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss");
				Date date1 = dateString.parse(date);
				SimpleDateFormat dateString1 = new SimpleDateFormat(
						"dd/MM/yyyy HH:mm:ss");
				String finalDate = dateString1.format(date1);
				payDirectReversalBeanObject.setUploadDateTime(finalDate);
				if (resultset.getString("PAYMENT_POSTED_DATE") != null) {
					String StringPosted = resultset
							.getString("PAYMENT_POSTED_DATE");

					Date datePosted = dateString.parse(StringPosted);

					String finalDate1 = dateString1.format(datePosted);
					payDirectReversalBeanObject.setFxUpdateTime(finalDate1);
				} else
					payDirectReversalBeanObject.setFxUpdateTime("");
				payDirectReversalBeanObject.setStatus(resultset
						.getString("STATUS"));
				payDirectReversalBeanObject.setReasonForFailue(resultset
						.getString("REASON_FOR_FAILURE"));
				payDirectReversalList.add(payDirectReversalBeanObject);
			}
		}
		reportslogger.info("Payment Direct Reversal Records list size:" + payDirectReversalList.size());

		payDirectReversalMap.put(totalPages, payDirectReversalList);
	} catch (SQLException e) 
     {
		  StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
	return null;
     } 
	catch (Exception e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		reportslogger.error(errors);
		return null;
	} finally {
		if(resultset!=null){
	     	   try {
	     		  resultset.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
				}
	     	   }
		
		if(callableStatement!=null){
	     	   try {
	     		  callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
				}
	     	   }
				
	    	   if(conn!=null){
	         	   try {
	    				conn.close();
	    			} catch (Exception e) {
	    				StringWriter errors= new StringWriter();
	    				e.printStackTrace(new PrintWriter(errors));
	    				reportslogger.error(errors);
	    			}
	         
	         	   }
	}
	return payDirectReversalMap;

}

public List<PaymentDirectReversalBean> getPayDirectRevExcelDetailsAps(
		PaymentDirectReversalBean payDirectReversalBeanObj, String pageNo) {
	List<PaymentDirectReversalBean> payDirectReversalList = new ArrayList<PaymentDirectReversalBean>();
	ResultSet resultset = null;
	CallableStatement callableStatement=null;
	//reportslogger.info("page number in dao" + pageNo);

	try {
	reportslogger.info("Payment Direct Reversal excel Download in DaoImpl ");
		//reportslogger.info("connection" + dataSource.getConnection());*/
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		conn = jdbcTemplate.getDataSource().getConnection();
		//reportslogger.info("connection established");
		// reportslogger.info("in dao child userid"+PayDirectReversalBeanObj.getChildUserId());

		// call proc
		final String procedureCall = "{call AIRTL_PAYMENT_REPORTS_PKG.PAYMENT_REVERSAL_TRASACTIONS(?,?,?,?,?,?,?,?,?,?,?,?)}";

		 callableStatement = conn
				.prepareCall(procedureCall);

		/* callableStatement.setInt(1, page); */
		callableStatement.setString(1,
				payDirectReversalBeanObj.getParentUserId());
		callableStatement.setString(2,
				payDirectReversalBeanObj.getChildUserId());
		callableStatement
				.setString(3, payDirectReversalBeanObj.getFileId());
		callableStatement.setString(4,
				payDirectReversalBeanObj.getFileName());
		callableStatement.setString(5,
				payDirectReversalBeanObj.getTrackingId());
		callableStatement.setString(6,
				payDirectReversalBeanObj.getVendorId());
		callableStatement
				.setString(7, payDirectReversalBeanObj.getToDate());
		callableStatement.setString(8,
				payDirectReversalBeanObj.getFromDate());
		callableStatement.setString(9, pageNo);
		callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
		callableStatement.registerOutParameter(11, Types.INTEGER);
		callableStatement.registerOutParameter(12, Types.VARCHAR);
		//reportslogger.info("before execute update");
		callableStatement.executeUpdate();
		//reportslogger.info("callable statements executed");

		int totalPages = callableStatement.getInt(11);

		String statusMsg = callableStatement.getString(12);// msg

		resultset = (ResultSet) callableStatement.getObject(10);

		payDirectReversalBeanObj.setStatusMsg(statusMsg);

		 reportslogger.info("Error Msg at DaoImpl"+statusMsg);
		
		/* reportslogger.info("totalpages:" + totalPages); */

		if (resultset == null) {
			reportslogger.info("Resultset is null in daoImpl");

		} else {
			while (resultset != null && resultset.next()) {
				//reportslogger.info("inside while!");
				PaymentDirectReversalBean payDirectReversalBeanObject = new PaymentDirectReversalBean();

				payDirectReversalBeanObject.setAccountNumber(resultset
						.getString("ACCT_EXT_ID"));

				payDirectReversalBeanObject.setTrackingId(resultset
						.getString("TRACKING_ID"));

				payDirectReversalBeanObject.setTrackingIdServ(resultset
						.getString("TRACKING_ID_SERV"));
				payDirectReversalBeanObject.setUploadedByOlmId(resultset
						.getString("VENDOR_USERID"));
				payDirectReversalBeanObject.setUploadedByName(resultset
						.getString("USER_NAME"));
				payDirectReversalBeanObject.setFileId(resultset
						.getString("FILE_ID"));
				payDirectReversalBeanObject.setFileName(resultset
						.getString("ORIGINAL_FILE_NAME"));
				String date = resultset.getString("FILE_UPLOAD_DATE");
				SimpleDateFormat dateString = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss");
				Date date1 = dateString.parse(date);
				SimpleDateFormat dateString1 = new SimpleDateFormat(
						"dd/MM/yyyy HH:mm:ss");
				String finalDate = dateString1.format(date1);
				payDirectReversalBeanObject.setUploadDateTime(finalDate);
				if (resultset.getString("PAYMENT_POSTED_DATE") != null) {
					String StringPosted = resultset
							.getString("PAYMENT_POSTED_DATE");

					Date datePosted = dateString.parse(StringPosted);

					String finalDate1 = dateString1.format(datePosted);
					payDirectReversalBeanObject.setFxUpdateTime(finalDate1);
				} else
					payDirectReversalBeanObject.setFxUpdateTime("");
				payDirectReversalBeanObject.setStatus(resultset
						.getString("STATUS"));
				payDirectReversalBeanObject.setReasonForFailue(resultset
						.getString("REASON_FOR_FAILURE"));
				payDirectReversalList.add(payDirectReversalBeanObject);
			}
		}
		reportslogger.info("payment Direct Reversal Excel Records list size in daoImpl:" + payDirectReversalList.size());

	} catch (SQLException e) 
     {
		  StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
	return null;
     } 
	catch (Exception e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		reportslogger.error(errors);
		return null;
	} finally {
		if(resultset!=null){
	     	   try {
	     		  resultset.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
				}
	     	   }
		
		if(callableStatement!=null){
	     	   try {
	     		  callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
				}
	     	   }
				
	    	   if(conn!=null){
	         	   try {
	    				conn.close();
	    			} catch (Exception e) {
	    				StringWriter errors= new StringWriter();
	    				e.printStackTrace(new PrintWriter(errors));
	    				reportslogger.error(errors);
	    			}
	         
	         	   }
	}
	return payDirectReversalList;
}






}
