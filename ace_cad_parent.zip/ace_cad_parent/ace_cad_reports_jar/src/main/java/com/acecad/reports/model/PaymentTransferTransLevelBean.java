package com.acecad.reports.model;

public class PaymentTransferTransLevelBean {
	private String transId;
	private String type;
	private String paymentMode;
	private String lob;
	private String accountNo;
	private String invoiceNo;
	private String uploadedByOlmId;
	private String uploadedByName;
	private String fileName;
	private String fileId;
	private String desTrackingId;
	public String getDesTrackingId() {
		return desTrackingId;
	}
	public void setDesTrackingId(String desTrackingId) {
		this.desTrackingId = desTrackingId;
	}
	public String getDesTrackingIdServ() {
		return desTrackingIdServ;
	}
	public void setDesTrackingIdServ(String desTrackingIdServ) {
		this.desTrackingIdServ = desTrackingIdServ;
	}
	private String desTrackingIdServ;
	public String getTransId() {
		return transId;
	}
	public void setTransId(String transId) {
		this.transId = transId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public String getUploadedByOlmId() {
		return uploadedByOlmId;
	}
	public void setUploadedByOlmId(String uploadedByOlmId) {
		this.uploadedByOlmId = uploadedByOlmId;
	}
	public String getUploadedByName() {
		return uploadedByName;
	}
	public void setUploadedByName(String uploadedByName) {
		this.uploadedByName = uploadedByName;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getReasonForFailure() {
		return reasonForFailure;
	}
	public void setReasonForFailure(String reasonForFailure) {
		this.reasonForFailure = reasonForFailure;
	}
	public String getParentUserId() {
		return parentUserId;
	}
	public void setParentUserId(String parentUserId) {
		this.parentUserId = parentUserId;
	}
	public String getChildUserId() {
		return childUserId;
	}
	public void setChildUserId(String childUserId) {
		this.childUserId = childUserId;
	}
	public String getSourceTrackingId() {
		return sourceTrackingId;
	}
	public void setSourceTrackingId(String sourceTrackingId) {
		this.sourceTrackingId = sourceTrackingId;
	}
	public String getSourceTrackingIdServ() {
		return sourceTrackingIdServ;
	}
	public void setSourceTrackingIdServ(String sourceTrackingIdServ) {
		this.sourceTrackingIdServ = sourceTrackingIdServ;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getUploadTime() {
		return uploadTime;
	}
	public void setUploadTime(String uploadTime) {
		this.uploadTime = uploadTime;
	}
	public String getFxUpdatedDate() {
		return fxUpdatedDate;
	}
	public void setFxUpdatedDate(String fxUpdatedDate) {
		this.fxUpdatedDate = fxUpdatedDate;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getStatusMsg() {
		return statusMsg;
	}
	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}
	private String status;
	private String vendorId;
	private String reasonForFailure;
	private String parentUserId;
	private String childUserId;
	private String sourceTrackingId;
	private String sourceTrackingIdServ;
	private String amount; 
	private String uploadTime;
	private String fxUpdatedDate;
	private String fromDate;
	private String toDate;
	private String statusMsg;
	
	

}
