package com.acecad.reports.model;

public class VendorUserReportBean {
	private String vendorName;
	private String vendorId;
	private String vendorSpocName;
	private String vendorSpocEmail;
	private String paymentModes;
    private String vendorSpocContactNumber;
	private String activeDate;
	private String inActiveDate;
    private String vendorAddressline1;
	private String vendorAddressLine2;
	private String status;
	private String vendorCity;
	private String vendorState;
	private String pin;
	private String lobs;
	private String parentUserId;
	private String childUserId;
	private int role;
	private String errorMsg;
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getParentUserId() {
		return parentUserId;
	}
	public void setParentUserId(String parentUserId) {
		this.parentUserId = parentUserId;
	}
	public String getChildUserId() {
		return childUserId;
	}
	public void setChildUserId(String childUserId) {
		this.childUserId = childUserId;
	}
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getVendorSpocName() {
		return vendorSpocName;
	}
	public void setVendorSpocName(String vendorSpocName) {
		this.vendorSpocName = vendorSpocName;
	}
	public String getVendorSpocEmail() {
		return vendorSpocEmail;
	}
	public void setVendorSpocEmail(String vendorSpocEmail) {
		this.vendorSpocEmail = vendorSpocEmail;
	}
	public String getPaymentModes() {
		return paymentModes;
	}
	public void setPaymentModes(String paymentModes) {
		this.paymentModes = paymentModes;
	}
	public String getVendorSpocContactNumber() {
		return vendorSpocContactNumber;
	}
	public void setVendorSpocContactNumber(String vendorSpocContactNumber) {
		this.vendorSpocContactNumber = vendorSpocContactNumber;
	}
	public String getActiveDate() {
		return activeDate;
	}
	public void setActiveDate(String activeDate) {
		this.activeDate = activeDate;
	}
	public String getInActiveDate() {
		return inActiveDate;
	}
	public void setInActiveDate(String inActiveDate) {
		this.inActiveDate = inActiveDate;
	}
	public String getVendorAddressline1() {
		return vendorAddressline1;
	}
	public void setVendorAddressline1(String vendorAddressline1) {
		this.vendorAddressline1 = vendorAddressline1;
	}
	public String getVendorAddressLine2() {
		return vendorAddressLine2;
	}
	public void setVendorAddressLine2(String vendorAddressLine2) {
		this.vendorAddressLine2 = vendorAddressLine2;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getVendorCity() {
		return vendorCity;
	}
	public void setVendorCity(String vendorCity) {
		this.vendorCity = vendorCity;
	}
	public String getVendorState() {
		return vendorState;
	}
	public void setVendorState(String vendorState) {
		this.vendorState = vendorState;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getLobs() {
		return lobs;
	}
	public void setLobs(String lobs) {
		this.lobs = lobs;
	}



}
