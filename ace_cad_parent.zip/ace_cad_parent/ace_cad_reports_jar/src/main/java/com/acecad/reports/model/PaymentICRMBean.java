package com.acecad.reports.model;

import java.sql.Date;

public class PaymentICRMBean {
	
	private String srNumber;
	private String sourceAcctNum;
	private String destAccNum;
	private String billDate;
	private String amount;
	private String reasonForTransfer;
	private String transId_ChequeNum;
	private String trackingId;
	private String trackingIdServ;
	private String paymentMode;
	private String chequeDate_bankName;
	private String fromDate;
	private String toDate;
	private String aps_Status;
	private String Sr_Status;
	private String errorMsg;
	private String approvedBy;
	public String getPostingTrackingId() {
		return postingTrackingId;
	}
	public void setPostingTrackingId(String postingTrackingId) {
		this.postingTrackingId = postingTrackingId;
	}
	public String getPostingTrackingIdServ() {
		return postingTrackingIdServ;
	}
	public void setPostingTrackingIdServ(String postingTrackingIdServ) {
		this.postingTrackingIdServ = postingTrackingIdServ;
	}
	private String approvedDate;
	private String remarks;
	private String rejectionReason;
	private String srCreatedDate;
	private String postingTrackingId;
	private String postingTrackingIdServ;
	private String recordType;
	private String fxPostingTime;

	
	
	
	
	
	public String getRecordType() {
		return recordType;
	}
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
	public String getFxPostingTime() {
		return fxPostingTime;
	}
	public void setFxPostingTime(String fxPostingTime) {
		this.fxPostingTime = fxPostingTime;
	}
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getSourceAcctNum() {
		return sourceAcctNum;
	}
	public void setSourceAcctNum(String sourceAcctNum) {
		this.sourceAcctNum = sourceAcctNum;
	}
	public String getDestAccNum() {
		return destAccNum;
	}
	public void setDestAccNum(String destAccNum) {
		this.destAccNum = destAccNum;
	}
	public String getBillDate() {
		return billDate;
	}
	public void setBillDate(String billDate) {
		this.billDate = billDate;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getReasonForTransfer() {
		return reasonForTransfer;
	}
	public void setReasonForTransfer(String reasonForTransfer) {
		this.reasonForTransfer = reasonForTransfer;
	}
	public String getTransId_ChequeNum() {
		return transId_ChequeNum;
	}
	public void setTransId_ChequeNum(String transId_ChequeNum) {
		this.transId_ChequeNum = transId_ChequeNum;
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	public String getTrackingIdServ() {
		return trackingIdServ;
	}
	public void setTrackingIdServ(String trackingIdServ) {
		this.trackingIdServ = trackingIdServ;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getChequeDate_bankName() {
		return chequeDate_bankName;
	}
	public void setChequeDate_bankName(String chequeDate_bankName) {
		this.chequeDate_bankName = chequeDate_bankName;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getSr_Status() {
		return Sr_Status;
	}
	public void setSr_Status(String sr_Status) {
		Sr_Status = sr_Status;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getApprovedBy() {
		return approvedBy;
	}
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}
	public String getApprovedDate() {
		return approvedDate;
	}
	public void setApprovedDate(String approvedDate) {
		this.approvedDate = approvedDate;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getAps_Status() {
		return aps_Status;
	}
	public void setAps_Status(String aps_Status) {
		this.aps_Status = aps_Status;
	}
	public String getRejectionReason() {
		return rejectionReason;
	}
	public void setRejectionReason(String rejectionReason) {
		this.rejectionReason = rejectionReason;
	}
	public String getSrCreatedDate() {
		return srCreatedDate;
	}
	public void setSrCreatedDate(String srCreatedDate) {
		this.srCreatedDate = srCreatedDate;
	}
	
	
	

}
