package com.acecad.reports.model;

import java.util.Date;

public class PayPostingTransLevelDetails {

	private String parentUserId;
	private String childUserId;
	private String vendorId;
	private String vendorName;
	private String userCircle;
	private String fileId;
	private String fileName;
	private String mode;
	private String uploadTime;
	private int totalRec;
	private String totalVal;
	private String status;
	private int recPostedFX;
	private String valuePostedFX;
	private int recPendingAtLIU;
	private String amountPendingAtLIU;
	private String fromDate;
	private String statusMsg;
	private int pagenum;
	private int totPages;
	private String fileSource;
	private String accountNo;
	private String invoice;
	private String FXpostingTime;
	private String trackingId;
	private String trackingIdServ;
	private String reasonForLiuorFailure;
	private String refNo;
	private int role;
	private String bankAccNo;
	private String approvedBy;
	private String lob;
	private String siNumber;
	
	public String getSiNumber() {
		return siNumber;
	}
	public void setSiNumber(String siNumber) {
		this.siNumber = siNumber;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getApprovedBy() {
		return approvedBy;
	}
	public String getBankAccNo() {
		return bankAccNo;
	}
	public void setBankAccNo(String bankAccNo) {
		this.bankAccNo = bankAccNo;
	}
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}
	public String getApprovedDate() {
		return approvedDate;
	}
	public void setApprovedDate(String approvedDate) {
		this.approvedDate = approvedDate;
	}
	private String approvedDate;
	
	
	
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public String getFileSource() {
		return fileSource;
	}
	public void setFileSource(String fileSource) {
		this.fileSource = fileSource;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getInvoice() {
		return invoice;
	}
	public void setInvoice(String invoice) {
		this.invoice = invoice;
	}
	
	public String getFXpostingTime() {
		return FXpostingTime;
	}
	public void setFXpostingTime(String fXpostingTime) {
		FXpostingTime = fXpostingTime;
	}
	
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	public String getTrackingIdServ() {
		return trackingIdServ;
	}
	public void setTrackingIdServ(String trackingIdServ) {
		this.trackingIdServ = trackingIdServ;
	}
	public String getReasonForLiuorFailure() {
		return reasonForLiuorFailure;
	}
	public void setReasonForLiuorFailure(String reasonForLiuorFailure) {
		this.reasonForLiuorFailure = reasonForLiuorFailure;
	}
	public String getParentUserId() {
		return parentUserId;
	}
	public void setParentUserId(String parentUserId) {
		this.parentUserId = parentUserId;
	}
	public String getChildUserId() {
		return childUserId;
	}
	public void setChildUserId(String childUserId) {
		this.childUserId = childUserId;
	}
	
	public int getTotPages() {
		return totPages;
	}
	public void setTotPages(int totPages) {
		this.totPages = totPages;
	}
	public int getPagenum() {
		return pagenum;
	}
	public void setPagenum(int pagenum) {
		this.pagenum = pagenum;
	}
	
	
	public String getStatusMsg() {
		return statusMsg;
	}
	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	private String toDate;
	
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getUserCircle() {
		return userCircle;
	}
	public void setUserCircle(String userCircle) {
		this.userCircle = userCircle;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	
	
	
	public String getUploadTime() {
		return uploadTime;
	}
	public void setUploadTime(String uploadTime) {
		this.uploadTime = uploadTime;
	}
	public int getTotalRec() {
		return totalRec;
	}
	public void setTotalRec(int totalRec) {
		this.totalRec = totalRec;
	}
	public String getTotalVal() {
		return totalVal;
	}
	public void setTotalVal(String totalVal) {
		this.totalVal = totalVal;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getRecPostedFX() {
		return recPostedFX;
	}
	public void setRecPostedFX(int recPostedFX) {
		this.recPostedFX = recPostedFX;
	}
	public String getValuePostedFX() {
		return valuePostedFX;
	}
	public void setValuePostedFX(String valuePostedFX) {
		this.valuePostedFX = valuePostedFX;
	}
	public int getRecPendingAtLIU() {
		return recPendingAtLIU;
	}
	public void setRecPendingAtLIU(int recPendingAtLIU) {
		this.recPendingAtLIU = recPendingAtLIU;
	}
	public String getAmountPendingAtLIU() {
		return amountPendingAtLIU;
	}
	public void setAmountPendingAtLIU(String amountPendingAtLIU) {
		this.amountPendingAtLIU = amountPendingAtLIU;
	}
		
}
