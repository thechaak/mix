package com.acecad.reports.dao;

import java.util.HashMap;
import java.util.List;

import com.acecad.reports.model.ActivityLogDetails;
import com.acecad.reports.model.PayPostingChequeDetails;
import com.acecad.reports.model.PayPostingTransLevelDetails;
import com.acecad.reports.model.PayPostingVendorDetails;
import com.acecad.reports.model.PayRevChequeBounceDetailsDownload;
import com.acecad.reports.model.PayRevChqBounceRecordsDetails;
import com.acecad.reports.model.PayRevDirectTransRecordsDownload;
import com.acecad.reports.model.PayTransferFileLevelDetails;
import com.acecad.reports.model.PaymentDirectReversalBean;
import com.acecad.reports.model.PaymentPostingFilelevelDetails;
import com.acecad.reports.model.PaymentPostingModewiseBean;
import com.acecad.reports.model.PaymentPostingTransLevelDetailsDownload;
import com.acecad.reports.model.PaymentReversalFileLevelBean;
import com.acecad.reports.model.PaymentTransferTransLevelBean;
import com.acecad.reports.model.UserManagementUserLevel;
import com.acecad.reports.model.VendorUserReportBean;



public interface ReportsDao {
	int getRole(String UserId);
	
	List<String> returnModeList();
	/** PAYMENT POSTING FILE LEVEL  **/
	
	HashMap<Integer, List<PaymentPostingFilelevelDetails>> getPayPostingFilelevelDetails(PaymentPostingFilelevelDetails payPostingFilelevelDetailsObj,int page);

	

	List<PaymentPostingTransLevelDetailsDownload> getPayPostingPendingLiuRecords(String fileID);
	List<PaymentPostingTransLevelDetailsDownload> getPayPostingRecordsPostedToFx(String fileID);

	List<PaymentPostingFilelevelDetails> getPayPostingExcelDetails(
			PaymentPostingFilelevelDetails payPostingFilelevelDetailsObj, String pageNo);
	/** PAYMENT POSTING MODEWISE **/
	HashMap<Integer, List<PaymentPostingModewiseBean>> getPayPosModewiseSumDetails(PaymentPostingModewiseBean payPostingFilelevelDetailsObj,int page);

	List<PaymentPostingModewiseBean> getPayPosModewiseSumexcelDetails(
			PaymentPostingModewiseBean payPosModewiseSumBeanObj, int pageNo);
	
	/** PAYMENT REVERSAL FILE LEVEL **/
	HashMap<Integer, List<PaymentReversalFileLevelBean>> getPayReversalFilelevelDetails(
			PaymentReversalFileLevelBean payReversalFileLevelBeanObj, int page);

	List<String> reversalTypeList();

	List<PayRevDirectTransRecordsDownload> getDirectRevTransLevelRecords(String fileID);

	List<PayRevChequeBounceDetailsDownload> getChequeBounceTransLevelRecords(
			String fileID);

	List<PaymentReversalFileLevelBean> getPayReversalFilelevelExcelDetails(
			PaymentReversalFileLevelBean payReversalFileLevelBeanObj, String pageNo);
	
	/* ****methods in payposting trans level**** */

	HashMap<Integer, List<PayPostingTransLevelDetails>> getPaymntPostingTranslevelMap(
			PayPostingTransLevelDetails PymntPostingTransLevelDetailsObj,
			int page);

	List<PayPostingTransLevelDetails> getPayPostTransactionExcelList(
			PayPostingTransLevelDetails PymntPostingTransLevelDetailsObj,
			String pageNum);

	/* end ****methods in payposting trans level**** */

	/* ****methods in vendor summary**** */

	HashMap<Integer, List<PayPostingVendorDetails>> getVendorSummaryMap(
			PayPostingVendorDetails vendorDetailsObj, int page);

	List<PayPostingVendorDetails> getVendorSummaryExcelList(
			PayPostingVendorDetails VendorDetailsObj, String pageNum);

	/* end ****methods in vendor summary**** */

	/* **** methods in payment posting cheque level *****/

	HashMap<Integer, List<PayPostingChequeDetails>> getPaymntPostingChequeMap(
			PayPostingChequeDetails pyPostChequeDetailsObj, int page);

	List<PayPostingChequeDetails> getPyPostChequeDetailsList(
			PayPostingChequeDetails PyPostChequeDetailsObj, String pageNum);
	/* end****methods in payment posting cheque level**** */
 
	/*** PAYMENT DIRECT REVERSAL ***/
	
	HashMap<Integer, List<PaymentDirectReversalBean>> getPayDirectReversalDetails(
			PaymentDirectReversalBean payDirectReversalBeanObj, int page);

	List<PaymentDirectReversalBean> getPayDirectRevExcelDetails(
			PaymentDirectReversalBean payDirectReversalBeanObj, String pageNo);
	
	/*<****methods in chq bounce****>*/
	HashMap<Integer, List<PayRevChqBounceRecordsDetails>> getPymntRevChqBounceRecords(PayRevChqBounceRecordsDetails PymntRevChqBounceRecordsDetailsObj,int page);

	List<PayRevChqBounceRecordsDetails> getPymntRevChqBounceList(PayRevChqBounceRecordsDetails PymntRevChqBounceRecordsDetailsObj,String pageNum);
	
	/*end****methods in chq bounce****>*/
	
	
	/******************** PAYMENT TRANSFER TRANS LEVEL ****************************/
	HashMap<Integer, List<PaymentTransferTransLevelBean>> getPaymentTransferTransLevelDetails(
			PaymentTransferTransLevelBean payTransferTransLevelBeanObj, int page);

	List<PaymentTransferTransLevelBean> getPaymentTransferTransExcelDetails(
			PaymentTransferTransLevelBean payTransferTransLevelBeanObj,
			String pageNo);
	
	
	
	/***********************************PAYMENT TRANSFER FILE LEVEL************************************/
	
	/****to download error records***/
	List<PaymentTransferTransLevelBean>getPymntTransferErrorRecords(String FileId);
	
	/****to download error records end***/

	HashMap<Integer, List<PayTransferFileLevelDetails>> getPymntTransFileSummaryMap(
			PayTransferFileLevelDetails pymntTransFileLevelDetailsObj, int page);
	
	List<PayTransferFileLevelDetails> getpymntTransFileLevelDetailsExcelList(PayTransferFileLevelDetails pymntTransFileLevelDetailsObj,String pageNum);



/*****************************************Activity Log************************************************************/


HashMap<Integer,List<ActivityLogDetails>> getActivityLogMap(ActivityLogDetails viewActivityLogDetailsObj,int page);
List<ActivityLogDetails> getActivityLogExcelList(ActivityLogDetails viewActivityLogDetailsObj,String pageNum);

/*****************************************Activity Log************************************************************/

/*****************************************User Management Vendor Report************************************************************/
HashMap<Integer,List<VendorUserReportBean>> getVendorReportMap(VendorUserReportBean VendorUserReportBeanObj,int page);
List<VendorUserReportBean> getVendorsExcelList(VendorUserReportBean VendorUserReportBeanObj,String pageNum);

/*****************************************User Management  vendor Report ends************************************************************/


/**********************************user management -user level reports**********************************************************/
List<String> returnStatusList();

List<String> returnRoleDescList();

HashMap<Integer, List<UserManagementUserLevel>> getUserMgmtUserLevelMap(UserManagementUserLevel UserManagementUserLevelObj,int page);

List<UserManagementUserLevel> getUserMgmtUserLevelExcelList(UserManagementUserLevel UserManagementUserLevelObj,String pageNum);

/**********************************user management -user level report ends**********************************************************/

	/*************************************aps reports**************************************************/


public HashMap<Integer, List<PayPostingChequeDetails>> getPaymntPostingChequeMapAps(
		PayPostingChequeDetails PyPostChequeDetailsObj, int page);

public List<PayPostingChequeDetails> getPyPostChequeDetailsListAps(PayPostingChequeDetails PyPostChequeDetailsObj, String pageNum);



public HashMap<Integer, List<PayPostingTransLevelDetails>> getPaymntPostingTranslevelMapAps(
		PayPostingTransLevelDetails PymntPostingTransLevelDetailsObj,
		int page);

List<PayPostingTransLevelDetails> getPayPostTransactionExcelListAps(
		PayPostingTransLevelDetails PymntPostingTransLevelDetailsObj,
		String pageNum);


HashMap<Integer, List<PaymentDirectReversalBean>> getPayDirectReversalDetailsAps(
		PaymentDirectReversalBean payDirectReversalBeanObj, int page);

List<PaymentDirectReversalBean> getPayDirectRevExcelDetailsAps(
		PaymentDirectReversalBean payDirectReversalBeanObj, String pageNo);

public String getOrignalFileName(String ticketId);


}

