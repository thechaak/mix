package com.acecad.reports.daoImpl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.acecad.reports.dao.PaymentAdviceDao;
//import com.acecad.liu.model.LIURecordDetails;
import com.acecad.reports.model.PaymentAdviceBean;
import com.acecad.reports.model.ProcessedAdviceFileDetails;


public class PaymentAdviceDaoImpl implements PaymentAdviceDao {
 
	//private static Logger reportslogger =LogManager.getLogger("paymentAdviceLogger");
	
	private static Logger reportslogger =LogManager.getLogger("reportsLogger");

	
	@Autowired
	private PlatformTransactionManager transactionManager;
	
	public void setTransactionManager(
		      PlatformTransactionManager transactionManager) {
		      this.transactionManager = transactionManager;
		   }
	
	public PaymentAdviceDaoImpl(DataSource dataSource) {
		this.dataSource = dataSource;
		setTransactionManager(transactionManager);
	}

	private DataSource dataSource;
	Connection conn = null;
	ResultSet resultsetshowdetails = null;

	public PaymentAdviceDaoImpl() {

	}
	
	
	public  String getDateTime() {
		Date today = (Date) Calendar.getInstance().getTime();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		return formatter.format(today);
	} 
	
	
	
	public int getRoleType(String userId)
	{
		int roleType=0;
		try 
		{
			reportslogger.info("Entered getRoleType method in PaymentAdviceDaoImpl");

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			String functionCall = "{? = call GETUSERROLE(?)}";

			CallableStatement callableStatement = conn
					.prepareCall(functionCall);

			callableStatement.registerOutParameter(1, Types.INTEGER);
			callableStatement.setString(2, userId);
			callableStatement.execute();

			roleType = callableStatement.getInt(1);
			
				
				if (roleType == 0) 
		        {
					reportslogger.info("DB returning NULL values at getRoleType method in PaymentAdviceDaoImpl");
				}
				
				else
				{
			     	roleType=callableStatement.getInt(1);
				    reportslogger.info("Role of the logged in user at getRoleType method in PaymentAdviceDaoImpl:"+roleType);
				}
		}catch (Exception e) {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
				}
		finally{
			try {
				conn.close();
			} catch (SQLException e) {
				  StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);	
				}
		}
		
		reportslogger.info("executed getRoleType method in PaymentAdviceDaoImpl");	

		return roleType; 
	}

	
	
   public List<String> adviceProcessListDropdown(String role,String userId) 
	{		
		List<String> adviceProcessList=new ArrayList<String>();
		
		try 
		{
			reportslogger.info("Entered adviceProcessListDropdown method in PaymentAdviceDaoImpl");

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();

			final String procedureCall = "{call ACE_CAD_BULK_PAYMENT.ACE_CAD_ADVICE_PROCESS_LIST(?,?,?,?,?)}";

			CallableStatement callableStatement = conn.prepareCall(procedureCall);
			
			callableStatement.setString(1, role);
			callableStatement.setString(2, userId);
			callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(4, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(5, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
		
		      String errorMsg=callableStatement.getString(4);
		      reportslogger.info("Error Message at adviceProcessListDropdown method in PaymentAdviceDaoImpl:"+errorMsg);
			  
			
			ResultSet adviceProcessResultSet=(ResultSet) callableStatement.getObject(3);
			
			if (adviceProcessResultSet == null) 
	        {
				reportslogger.info("DB returning NULL values at adviceProcessListDropdown method in PaymentAdviceDaoImpl");
			}
			else
			{
		    while(adviceProcessResultSet.next())
		     {
		    	adviceProcessList.add(adviceProcessResultSet.getString(1));
		    //	reportslogger.info("adviceProcessList @ IMPL:"+adviceProcessResultSet.getString(1));
		     }
		    
			  reportslogger.info("Size of adviceProcessList at adviceProcessListDropdown method in PaymentAdviceDaoImpl:"+ adviceProcessList.size());

			}
	}catch (Exception e) {
		  StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
		}
	finally{
		try {
			conn.close();
		} catch (SQLException e) {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
				}
	}
		
		reportslogger.info("executed adviceProcessListDropdown method in PaymentAdviceDaoImpl");	

		return adviceProcessList ;
}
   
   
   
   
   
  /* public List<String> adviceRMProcessList(int roleType) 
  	{		
  		List<String> adviceRMList=new ArrayList<String>();
  		
  		try 
  		{
  			reportslogger.info("ENTERED adviceRMProcessList @ DaoIMPL");

  			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
  			conn = jdbcTemplate.getDataSource().getConnection();

  			final String procedureCall = "{call (?,?,?,?)}";

  			CallableStatement callableStatement = conn.prepareCall(procedureCall);
  			
  			callableStatement.setInt(1, roleType);
  			callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
  			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
  			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
  			callableStatement.executeUpdate();
  		
  		      String errorMsg=callableStatement.getString(3);
  		      reportslogger.info("ERROR MESSAGE adviceRMProcessList:"+errorMsg);
  			  
  			
  			ResultSet adviceProcessResultSet=(ResultSet) callableStatement.getObject(2);
  			
  			if (adviceProcessResultSet == null) 
  	        {
  				reportslogger.info("DB IS RETURNING NULL VALUES");
  			}
  			else
  			{
  		    while(adviceProcessResultSet.next())
  		     {
  		    	
  		    	adviceRMList.add(adviceProcessResultSet.getString(1));
  			    reportslogger.info("adviceProcessList @ IMPL:"+adviceRMList);
  		     }
  			}
  	}catch (Exception e) {
  		e.printStackTrace();
  	}
  	finally{
  		try {
  			conn.close();
  		} catch (SQLException e) {
  			e.printStackTrace();
  		}
  	}
  		return adviceRMList ;
  }
   */
   
   
   
   public HashMap<Integer, List<PaymentAdviceBean>> adviceSearchTransLevel(int pageNumber,PaymentAdviceBean adviceTransBeanObj,String userRole,String userId) throws SQLException	
   {
		ResultSet resultsetdetails = null;
		HashMap<Integer, List<PaymentAdviceBean>> adviceHashMap=new HashMap<Integer, List<PaymentAdviceBean>>();
		CallableStatement callableStatement = null;
		List<PaymentAdviceBean> adviceBeanListObj = new ArrayList<PaymentAdviceBean>();
		try {

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			
			reportslogger.info("Entered adviceSearchTransLevel method in PaymentAdviceDaoImpl");

			final String procedureCall = "{call ACE_CAD_ADVICE_TRANS_SEARCH(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";

			callableStatement = conn.prepareCall(procedureCall);

			callableStatement.setString(1, adviceTransBeanObj.getToDate());
			callableStatement.setString(2, adviceTransBeanObj.getFromDate());
			callableStatement.setString(3, adviceTransBeanObj.getTicketId());
			callableStatement.setString(4, adviceTransBeanObj.getUtrNum());	
			callableStatement.setString(5, adviceTransBeanObj.getCustBankAcctNum());
			callableStatement.setString(6, adviceTransBeanObj.getUploadedBy());
			callableStatement.setString(7, adviceTransBeanObj.getProcess());
			callableStatement.setString(8, userId);
			callableStatement.setString(9, userRole);
			callableStatement.setInt(10, pageNumber);			

			callableStatement.registerOutParameter(11, Types.INTEGER);
			callableStatement.registerOutParameter(12, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(13,OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(14,OracleTypes.VARCHAR);
			

			callableStatement.executeUpdate();
           int totalPages=callableStatement.getInt(11);
           String errorMsg=callableStatement.getString(13);
           
           reportslogger.info("Error Message at adviceSearchTransLevel method in PaymentAdviceDaoImpl:"+errorMsg );
           adviceTransBeanObj.setErrorMsg(errorMsg);
           
			resultsetdetails = (ResultSet) callableStatement.getObject(12);

			if (resultsetdetails == null) 
	        {
				reportslogger.info("DB returning NULL values at adviceSearchTransLevel method in PaymentAdviceDaoImpl");
				//return null;

			}
			
			else
			{
				while (resultsetdetails.next()) 
				 {
					PaymentAdviceBean paymentAdviceBeanObj1 = new PaymentAdviceBean();

					paymentAdviceBeanObj1.setPaymentMode(resultsetdetails.getString("PAYMENT_MODE"));
					paymentAdviceBeanObj1.setTicketId(resultsetdetails.getString("I_REQUEST_ID"));
					if(resultsetdetails.getString("DT_UPLOADED_DATE")!=null)
					{
					paymentAdviceBeanObj1.setFileUploadDate(resultsetdetails.getString("DT_UPLOADED_DATE"));
					}
					
					else
						paymentAdviceBeanObj1.setFileUploadDate("");
					
					paymentAdviceBeanObj1.setUploadedBy(resultsetdetails.getString("VC_UPLOADED_USER_ID"));
					paymentAdviceBeanObj1.setUploadedByName(resultsetdetails.getString("VC_UPLOADED_USER_NAME"));
					paymentAdviceBeanObj1.setSourceLob(resultsetdetails.getString("SOURCE_LOB"));
					paymentAdviceBeanObj1.setSourceCircle(resultsetdetails.getString("SOURCE_CIRCLE_NAME"));
					
					if(resultsetdetails.getString("VC_DESTINATION_LOB")!=null)
					{
						paymentAdviceBeanObj1.setDestinationLob(resultsetdetails.getString("VC_DESTINATION_LOB"));
					}else
					{
					paymentAdviceBeanObj1.setDestinationLob("");
					}
					paymentAdviceBeanObj1.setDestinationCircle(resultsetdetails.getString("DESTINATION_CIRCLE_NAME"));
					paymentAdviceBeanObj1.setUtrNum(resultsetdetails.getString("UTR_CHQ_NUMBER"));
					paymentAdviceBeanObj1.setIncTransRefNumber(resultsetdetails.getString("INCOMING_TRANSACTION_REF_NO"));
					
					paymentAdviceBeanObj1.setTransDate(resultsetdetails.getString("TRANS_DATE"));
					paymentAdviceBeanObj1.setReceiptAmount(resultsetdetails.getString("RECEIPT_AMOUNT"));
					paymentAdviceBeanObj1.setPaymentExchangeRate(resultsetdetails.getString("PAYMENT_EXCHANGE_RATE"));
					paymentAdviceBeanObj1.setPaymentCurrency(resultsetdetails.getString("PAYMENT_CURRENCY"));
					//adding 2-more here on 19June-19 by AJIT
					paymentAdviceBeanObj1.setDummyCurrency(resultsetdetails.getString("DUMMY_CURRENCY"));
					paymentAdviceBeanObj1.setFundCurrency(resultsetdetails.getString("FUND_CURRENCY"));
					
					paymentAdviceBeanObj1.setLegalEntity(resultsetdetails.getString("LEGAL_ENTITY"));
					paymentAdviceBeanObj1.setCustBankAcctNum(resultsetdetails.getString("BANK_VIRTUAL_ACCOUNT_NO"));
					paymentAdviceBeanObj1.setReceiverName(resultsetdetails.getString("RECEIVER_NAME"));
					paymentAdviceBeanObj1.setRemitterName(resultsetdetails.getString("REMITTER_NAME"));
					paymentAdviceBeanObj1.setRefNum(resultsetdetails.getString("REF_NO"));
					paymentAdviceBeanObj1.setPaymentDetails1(resultsetdetails.getString("PAYMENT_DETAILS_1"));
					paymentAdviceBeanObj1.setPaymentDetails2(resultsetdetails.getString("PAYMENT_DETAILS_2"));
					paymentAdviceBeanObj1.setTargetFxAcctNum(resultsetdetails.getString("TARGET_FX_ACCOUNT_NO"));
					paymentAdviceBeanObj1.setCustName(resultsetdetails.getString("CUSTOMER_NAME"));
					paymentAdviceBeanObj1.setInvoiceNumber(resultsetdetails.getString("INVOICE_NO"));
					paymentAdviceBeanObj1.setInvoiceAllocationAmt(resultsetdetails.getString("INVOICE_ALLOCATION_AMOUNT"));
					paymentAdviceBeanObj1.setChequeDate(resultsetdetails.getString("CHEQUE_DATE"));
					paymentAdviceBeanObj1.setBankName(resultsetdetails.getString("BANK_NAME"));
					
					//
					paymentAdviceBeanObj1.setRecordType(resultsetdetails.getString("RECORD_TYPE"));
					paymentAdviceBeanObj1.setAccountType(resultsetdetails.getString("ACCOUNT_TYPE"));
					
					//
					
					
					if(resultsetdetails.getString("INPUT_REMARKS")!=null)
					{
					  paymentAdviceBeanObj1.setRemarks(resultsetdetails.getString("INPUT_REMARKS"));
					}
					else
					{
						paymentAdviceBeanObj1.setRemarks("");
					}
					if(resultsetdetails.getString("ORIG_TRACKING_ID")!=null)
					{
					paymentAdviceBeanObj1.setSourceTrackingId(resultsetdetails.getString("ORIG_TRACKING_ID"));
					}
					else
						paymentAdviceBeanObj1.setSourceTrackingId("");
					
					paymentAdviceBeanObj1.setTargetLob(resultsetdetails.getString("TARGET_LOB"));
					
					
					paymentAdviceBeanObj1.setFileName(resultsetdetails.getString("VC_UPLOADED_ORIGINAL_FILE_NAME"));
					paymentAdviceBeanObj1.setProcess(resultsetdetails.getString("VC_PROCESS_TYPE"));

					if(resultsetdetails.getString("VC_APPROVED_USER_ID")!=null)
					{
				      	paymentAdviceBeanObj1.setApprovedBy(resultsetdetails.getString("VC_APPROVED_USER_ID"));
					}
					else
					{
				      	paymentAdviceBeanObj1.setApprovedBy("");
					}
					

					if(resultsetdetails.getString("VC_APPROVED_USER_NAME")!=null)
					{
					   paymentAdviceBeanObj1.setApprovedByName(resultsetdetails.getString("VC_APPROVED_USER_NAME"));
					}
					else
					{
						paymentAdviceBeanObj1.setApprovedByName("");
					}
					if(resultsetdetails.getString("DT_APPROVAL_DATE")!=null)
					{
					paymentAdviceBeanObj1.setApprovalTime(resultsetdetails.getString("DT_APPROVAL_DATE"));
					}
					
					else
						paymentAdviceBeanObj1.setApprovalTime("");
					
					
					paymentAdviceBeanObj1.setFinalExchangeRate(resultsetdetails.getString("NEW_EXCHANGE_RATE"));
					
					paymentAdviceBeanObj1.setStatusDescription(resultsetdetails.getString("STATUS_DESC"));
					

					if(resultsetdetails.getString("TRACKING_ID")!=null)
					{
					paymentAdviceBeanObj1.setDestinationTrackingId(resultsetdetails.getString("TRACKING_ID"));
					}
					else
						paymentAdviceBeanObj1.setDestinationTrackingId("");

						
						
					if(resultsetdetails.getString("TRACKING_ID_SERV")!=null)
					{
						paymentAdviceBeanObj1.setDestinationTrackingIdServ(resultsetdetails.getString("TRACKING_ID_SERV"));
					}
					else
						paymentAdviceBeanObj1.setDestinationTrackingIdServ("");
					if(resultsetdetails.getString("PAYMENT_POSTED_DATE")!=null)
					{
						paymentAdviceBeanObj1.setFxUpdateTime(resultsetdetails.getString("PAYMENT_POSTED_DATE"));				
					}
					else
						paymentAdviceBeanObj1.setFxUpdateTime("");
					
					paymentAdviceBeanObj1.setErrorReasonCode(resultsetdetails.getString("ERROR_REASON_CODE"));
				//	paymentAdviceBeanObj1.setStatus(resultsetdetails.getString("I_STATUS"));
					
					if(resultsetdetails.getString("POSTING_STATUS_FX")!=null)
					{
					 paymentAdviceBeanObj1.setFxPostingStatus(resultsetdetails.getString("POSTING_STATUS_FX"));
					}
					else
						 paymentAdviceBeanObj1.setFxPostingStatus("");
					paymentAdviceBeanObj1.setFxPostingErrorDescription(resultsetdetails.getString("FX_POSTING_ERROR_DESCRIPTION"));

					paymentAdviceBeanObj1.setRoleName(resultsetdetails.getString("ROLE_DESCRIPTION"));
					//paymentAdviceBeanObj1.setFinalExchangeRate(resultsetdetails.getString("NEW_EXCHANGE_RATE"));
					paymentAdviceBeanObj1.setCadRecievedTime(resultsetdetails.getString("CAD_FILE_RECEIVED_TIME"));

					paymentAdviceBeanObj1.setDerivedB2bB2c(resultsetdetails.getString("DERIVED_B2B_B2C"));
					paymentAdviceBeanObj1.setAdviceExemption(resultsetdetails.getString("PAYMENT_ADVICE_EXCEMPTION"));
					paymentAdviceBeanObj1.setRecordId(resultsetdetails.getString("RECORD_ID"));
					
					//paymentAdviceBeanObj1.setTargetFxAcctNum(resultsetdetails.getString("ACCT_EXT_ID"));
					//paymentAdviceBeanObj1.setPaymentExchangeRate(resultsetdetails.getString("OLD_EXCHANGE_RATE"));
					
					////////adding end
					
								
					adviceBeanListObj.add(paymentAdviceBeanObj1);
                }

			}
			
			adviceHashMap.put(totalPages,adviceBeanListObj);
			reportslogger.info("Size of adviceHashMap at adviceSearchTransLevel method in PaymentAdviceDaoImpl:"+ adviceHashMap.size());
			
		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     }
	catch(Exception e)
	{
		  StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		return null;
	}
	           finally{
	        	   
	        	   if(resultsetdetails!=null){
		 	     	   try {
		 	     		 resultsetdetails.close();
		 				} catch (Exception e) {
		 					  StringWriter errors= new StringWriter();
		 						e.printStackTrace(new PrintWriter(errors));
		 						reportslogger.error(errors);
		 				}
		 	     	   }
		 		
		 		if(callableStatement!=null){
		 	     	   try {
		 	     		  callableStatement.close();
		 				} catch (Exception e) {
		 					  StringWriter errors= new StringWriter();
		 						e.printStackTrace(new PrintWriter(errors));
		 						reportslogger.error(errors);
		 				}
		 	     	   }
	        	   
	        	   if(conn!=null){
	        	   try {
					conn.close();
				} catch (Exception e) {
					  StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
				}
	        	   }
	        	   
	        	   
	           }
		
		reportslogger.info("executed adviceSearchTransLevel method in PaymentAdviceDaoImpl");	
     return adviceHashMap;
      
	}
   
   
   
   
   
	public HashMap<Integer, List<PaymentAdviceBean>> adviceSearchEFTLevel(int pageNumber,PaymentAdviceBean adviceEFTBeanObj,String userRole,String userId) throws SQLException
	{
		
		ResultSet resultsetdetails = null;
		HashMap<Integer, List<PaymentAdviceBean>> adviceHashMap=new HashMap<Integer, List<PaymentAdviceBean>>();
		CallableStatement callableStatement=null;
		List<PaymentAdviceBean> adviceBeanListObj = new ArrayList<PaymentAdviceBean>();
		try {

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			
			reportslogger.info("Entered adviceSearchEFTLevel method in PaymentAdviceDaoImpl");

			final String procedureCall = "{call ACE_CAD_ADVICE_EFT_SEARCH(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";

			callableStatement = conn.prepareCall(procedureCall);

			callableStatement.setString(1, adviceEFTBeanObj.getToDate());
			callableStatement.setString(2, adviceEFTBeanObj.getFromDate());
			callableStatement.setString(3, adviceEFTBeanObj.getTicketId());
			callableStatement.setString(4, adviceEFTBeanObj.getUtrNum());	
			callableStatement.setString(5, adviceEFTBeanObj.getCustBankAcctNum());
			callableStatement.setString(6, adviceEFTBeanObj.getUploadedBy());
			callableStatement.setString(7, adviceEFTBeanObj.getProcess());
			callableStatement.setString(8, userId);
			callableStatement.setString(9, userRole);
			callableStatement.setInt(10, pageNumber);			

			callableStatement.registerOutParameter(11, Types.INTEGER);
			callableStatement.registerOutParameter(12, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(13,OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(14,OracleTypes.VARCHAR);
			

			callableStatement.executeUpdate();
           int totalPages=callableStatement.getInt(11);
           String errorMsg=callableStatement.getString(13);
           
           reportslogger.info("Error Message at adviceSearchEFTLevel method in PaymentAdviceDaoImpl:"+errorMsg);
           adviceEFTBeanObj.setErrorMsg(errorMsg);
           reportslogger.info("error at adviceSearchEFTLevel method in PaymentAdviceDaoImpl:"+adviceEFTBeanObj.getErrorMsg());
           
			resultsetdetails = (ResultSet) callableStatement.getObject(12);
			if (resultsetdetails == null) 
	        {
				reportslogger.info("DB returning NULL values at adviceSearchEFTLevel method in PaymentAdviceDaoImpl");
			}
			
			else
			{      
				
				while (resultsetdetails.next()) 
				 {
					PaymentAdviceBean paymentAdviceBeanObj1 = new PaymentAdviceBean();

					paymentAdviceBeanObj1.setUtrNum(resultsetdetails.getString("UTR_CHQ_NUMBER"));
					paymentAdviceBeanObj1.setLob(resultsetdetails.getString("LOB"));
					paymentAdviceBeanObj1.setTicketId(resultsetdetails.getString("I_REQUEST_ID"));
					paymentAdviceBeanObj1.setCustBankAcctNum(resultsetdetails.getString("BANK_VIRTUAL_ACCOUNT_NO"));
					
					if(resultsetdetails.getString("AIRTL_BANK_ACCOUNT_NO")!=null)
						paymentAdviceBeanObj1.setAirtelBankAcctNum(resultsetdetails.getString("AIRTL_BANK_ACCOUNT_NO"));
					else
						paymentAdviceBeanObj1.setAirtelBankAcctNum("-");
					
					
					if(resultsetdetails.getString("PAYMENT_FILE_UPLOAD_DATE")!=null)
					{
						
						String date = resultsetdetails.getString("PAYMENT_FILE_UPLOAD_DATE");
						SimpleDateFormat dateString = new SimpleDateFormat(
								"yyyy-MM-dd HH:mm:ss");
						Date date1 = dateString.parse(date);
						SimpleDateFormat dateString1 = new SimpleDateFormat(
								"dd/MM/yyyy");
						String finalDate = dateString1.format(date1);
						paymentAdviceBeanObj1.setFileUploadDate(finalDate);
					}
					else
					      paymentAdviceBeanObj1.setFileUploadDate("-");
					
					if(resultsetdetails.getString("VENDOR_NAME")!=null)
						
					   paymentAdviceBeanObj1.setVendorName(resultsetdetails.getString("VENDOR_NAME"));
					else
						   paymentAdviceBeanObj1.setVendorName("");
					
					paymentAdviceBeanObj1.setUploadedBy(resultsetdetails.getString("VENDOR_USERID"));
					paymentAdviceBeanObj1.setFileName(resultsetdetails.getString("ORIGINAL_FILE_NAME"));
					paymentAdviceBeanObj1.setPaymentMode(resultsetdetails.getString("PAYMENT_MODE"));	
					
					
					if(resultsetdetails.getString("BANK_CREDIT_RECORD_DATE")!=null)
					{
						
						String date = resultsetdetails.getString("BANK_CREDIT_RECORD_DATE");
						SimpleDateFormat dateString = new SimpleDateFormat(
								"yyyy-MM-dd HH:mm:ss");
						Date date1 = dateString.parse(date);
						SimpleDateFormat dateString1 = new SimpleDateFormat(
								"dd/MM/yyyy");
						String finalDate = dateString1.format(date1);
						paymentAdviceBeanObj1.setBankCreditRcrdDate(finalDate);
					}
						else
							paymentAdviceBeanObj1.setBankCreditRcrdDate("");
					
					//paymentAdviceBeanObj1.setBankCreditRcrdDate(resultsetdetails.getString("BANK_CREDIT_RECORD_DATE"));
					
					if(resultsetdetails.getString("REQUEST_RAISED_DATE")!=null)
					{
						
						String date = resultsetdetails.getString("REQUEST_RAISED_DATE");
						SimpleDateFormat dateString = new SimpleDateFormat(
								"yyyy-MM-dd HH:mm:ss");
						Date date1 = dateString.parse(date);
						SimpleDateFormat dateString1 = new SimpleDateFormat(
								"dd/MM/yyyy");
						String finalDate = dateString1.format(date1);
						paymentAdviceBeanObj1.setRequestRaisedDate(finalDate);
					}
					else
					   paymentAdviceBeanObj1.setRequestRaisedDate("");
					
					paymentAdviceBeanObj1.setRequestStatus(resultsetdetails.getString("FILE_LEVEL_STATUS"));
					paymentAdviceBeanObj1.setUtrLevelStatus(resultsetdetails.getString("UTR_LEVEL_STATUS"));
					paymentAdviceBeanObj1.setNumOfAcctsPosted(resultsetdetails.getLong("NO_OF_ACCT_POSTED"));
					paymentAdviceBeanObj1.setNumOfInvoicesPosted(resultsetdetails.getLong("NO_OF_INV_POSTED"));
					paymentAdviceBeanObj1.setValueOfEftPayment(resultsetdetails.getString("PAYMENT_AMOUNT"));
					paymentAdviceBeanObj1.setRequestRaisedTime(resultsetdetails.getString("REQUEST_RAISED_TIME"));
					
					if(resultsetdetails.getString("POSTING_DATE")!=null)
					{
						String date = resultsetdetails.getString("POSTING_DATE");
						SimpleDateFormat dateString = new SimpleDateFormat(
								"yyyy-MM-dd HH:mm:ss");
						Date date1 = dateString.parse(date);
						SimpleDateFormat dateString1 = new SimpleDateFormat(
								"dd/MM/yyyy");
						String finalDate = dateString1.format(date1);
						
						paymentAdviceBeanObj1.setPostingDate(finalDate);
					
					}
					else
						paymentAdviceBeanObj1.setPostingDate("");
				
					if(resultsetdetails.getString("POSTING_TIME")!=null)
   					   paymentAdviceBeanObj1.setPostingTime(resultsetdetails.getString("POSTING_TIME"));
					else
						paymentAdviceBeanObj1.setPostingTime("");

					if(resultsetdetails.getString("DIFF_CREDIT_REQUEST_DATES")!=null)
					   paymentAdviceBeanObj1.setCreditDateVsRequestDate(resultsetdetails.getString("DIFF_CREDIT_REQUEST_DATES"));
					else
						 paymentAdviceBeanObj1.setCreditDateVsRequestDate("");
					
					if(resultsetdetails.getString("DIFF_REQUEST_POSTED_DATES")!=null)
					   paymentAdviceBeanObj1.setRequestDateVsPostedDate(resultsetdetails.getString("DIFF_REQUEST_POSTED_DATES"));
					else
						paymentAdviceBeanObj1.setRequestDateVsPostedDate("");
					
					if(resultsetdetails.getString("DIFF_CREDIT_POSTED_DATES")!=null)
   					    paymentAdviceBeanObj1.setCreditDateVsPostedDate(resultsetdetails.getString("DIFF_CREDIT_POSTED_DATES"));
					else
						paymentAdviceBeanObj1.setCreditDateVsPostedDate("");
					
					paymentAdviceBeanObj1.setProcess(resultsetdetails.getString("PROCESS_TYPE"));
		
					adviceBeanListObj.add(paymentAdviceBeanObj1);
                }
			}
			adviceHashMap.put(totalPages,adviceBeanListObj);
			
			reportslogger.info("Size of adviceHashMap at adviceSearchEFTLevel method in PaymentAdviceDaoImpl:"+ adviceHashMap.size());
			
		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     }
	catch(Exception e)
	{
		  StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		return null;
	}
	           finally{
	        	   
	        	   if(resultsetdetails!=null){
		 	     	   try {
		 	     		 resultsetdetails.close();
		 				} catch (Exception e) {
		 					  StringWriter errors= new StringWriter();
		 						e.printStackTrace(new PrintWriter(errors));
		 						reportslogger.error(errors);
		 				}
		 	     	   }
		 		
		 		if(callableStatement!=null){
		 	     	   try {
		 	     		  callableStatement.close();
		 				} catch (Exception e) {
		 					  StringWriter errors= new StringWriter();
		 						e.printStackTrace(new PrintWriter(errors));
		 						reportslogger.error(errors);
		 				}
		 	     	   }
	        	   
	        	   if(conn!=null){
	        	   try {
					conn.close();
				} catch (Exception e) {
					  StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
				}
	        	   }
	           }
		reportslogger.info("executed adviceSearchEFTLevel method in PaymentAdviceDaoImpl");	
     return adviceHashMap;
      
	}

	
	   
		public HashMap<Integer, List<PaymentAdviceBean>> adviceSearchRequestLevel(int pageNumber,PaymentAdviceBean adviceRequestBeanObj,String userRole,String userId) throws SQLException
		{
			
			ResultSet resultsetdetails = null;
			HashMap<Integer, List<PaymentAdviceBean>> adviceHashMap=new HashMap<Integer, List<PaymentAdviceBean>>();
			CallableStatement callableStatement=null;
			List<PaymentAdviceBean> adviceBeanListObj = new ArrayList<PaymentAdviceBean>();
			try {

				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				conn = jdbcTemplate.getDataSource().getConnection();
				
				reportslogger.info("Entered adviceSearchRequestLevel method in PaymentAdviceDaoImpl");

				final String procedureCall = "{call ACE_CAD_ADVICE_REQUEST_SEARCH(?,?,?,?,?,?,?,?,?,?,?)}";

				callableStatement = conn.prepareCall(procedureCall);

				callableStatement.setString(1, adviceRequestBeanObj.getToDate());
				callableStatement.setString(2, adviceRequestBeanObj.getFromDate());
				callableStatement.setString(3, adviceRequestBeanObj.getTicketId());
				callableStatement.setString(4, adviceRequestBeanObj.getUploadedBy());
				callableStatement.setString(5, userId);
				callableStatement.setString(6, userRole);
				callableStatement.setInt(7, pageNumber);			

				callableStatement.registerOutParameter(8, Types.INTEGER);
				callableStatement.registerOutParameter(9, OracleTypes.CURSOR);
				callableStatement.registerOutParameter(10,OracleTypes.VARCHAR);
				callableStatement.registerOutParameter(11,OracleTypes.VARCHAR);
				

				callableStatement.executeUpdate();
	           int totalPages=callableStatement.getInt(8);
	           String errorMsg=callableStatement.getString(10);
	           
	           reportslogger.info("Error Message at adviceSearchRequestLevel method in PaymentAdviceDaoImpl:"+errorMsg);
	           adviceRequestBeanObj.setErrorMsg(errorMsg);
	           reportslogger.info("Error Message at adviceSearchRequestLevel method in PaymentAdviceDaoImpl:"+adviceRequestBeanObj.getErrorMsg());
	           
				resultsetdetails = (ResultSet) callableStatement.getObject(9);
				if (resultsetdetails == null) 
		        {
					reportslogger.info("DB returning NULL values at adviceSearchRequestLevel method in PaymentAdviceDaoImpl");
				}
				
				else
				{
					while (resultsetdetails.next()) 
					 {
						PaymentAdviceBean paymentAdviceBeanObj1 = new PaymentAdviceBean();
						
						paymentAdviceBeanObj1.setUploadedByName(resultsetdetails.getString("VC_UPLOADED_USER_NAME"));
						paymentAdviceBeanObj1.setFileName(resultsetdetails.getString("VC_UPLOADED_ORIGINAL_FILE_NAME"));
						paymentAdviceBeanObj1.setUploadTime(resultsetdetails.getString("DT_UPLOADED_DATE"));
						paymentAdviceBeanObj1.setTicketId(resultsetdetails.getString("I_REQUEST_ID"));
						paymentAdviceBeanObj1.setStatus(resultsetdetails.getString("STATUS_DESCRIPTION"));
						paymentAdviceBeanObj1.setComments(resultsetdetails.getString("REQUEST_COMMENTS"));
						paymentAdviceBeanObj1.setAllowDownload(resultsetdetails.getString("ALLOW_DOWNLOAD"));
						paymentAdviceBeanObj1.setRejectionRemarks(resultsetdetails.getString("VC_REJECTED_REASON"));
						paymentAdviceBeanObj1.setRejectedReason(resultsetdetails.getString("VC_REJECTED_REASON_DROP_DOWN"));
						paymentAdviceBeanObj1.setPaymentMode(resultsetdetails.getString("VC_PAYMENT_MODE"));

			
						adviceBeanListObj.add(paymentAdviceBeanObj1);
	                }
				}
				adviceHashMap.put(totalPages,adviceBeanListObj);
				
				reportslogger.info("Size of adviceHashMap at adviceSearchRequestLevel method in PaymentAdviceDaoImpl:"+ adviceHashMap.size());
				
			} catch (SQLException e) 
		     {
				  StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
			return null;
		     }
		catch(Exception e)
		{
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
			return null;
		}
		           finally{
		        	   
		        	   if(resultsetdetails!=null){
			 	     	   try {
			 	     		 resultsetdetails.close();
			 				} catch (Exception e) {
			 					  StringWriter errors= new StringWriter();
			 						e.printStackTrace(new PrintWriter(errors));
			 						reportslogger.error(errors);
			 				}
			 	     	   }
			 		
			 		if(callableStatement!=null){
			 	     	   try {
			 	     		  callableStatement.close();
			 				} catch (Exception e) {
			 					  StringWriter errors= new StringWriter();
			 						e.printStackTrace(new PrintWriter(errors));
			 						reportslogger.error(errors);
			 				}
			 	     	   }
		        	   
		        	   if(conn!=null){
		        	   try {
						conn.close();
					} catch (Exception e) {
						  StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							reportslogger.error(errors);
					}
		        	   }
		           }
			reportslogger.info("executed adviceSearchRequestLevel method in PaymentAdviceDaoImpl");	
	     return adviceHashMap;
	      
		}
	
		public HashMap<Integer, List<PaymentAdviceBean>> waiverSearchRequestLevel(int pageNumber,PaymentAdviceBean adviceRequestBeanObj,String userRole,String userId) throws SQLException
		{
			
			ResultSet resultsetdetails = null;
			HashMap<Integer, List<PaymentAdviceBean>> adviceHashMap=new HashMap<Integer, List<PaymentAdviceBean>>();
			CallableStatement callableStatement=null;
			List<PaymentAdviceBean> adviceBeanListObj = new ArrayList<PaymentAdviceBean>();
			try {

				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				conn = jdbcTemplate.getDataSource().getConnection();
				
				reportslogger.info("Entered waiverSearchRequestLevel method in PaymentAdviceDaoImpl");

				final String procedureCall = "{call WAIVER_REQUEST_TRACK_SEARCH(?,?,?,?,?,?,?,?,?,?,?)}";

				callableStatement = conn.prepareCall(procedureCall);

				callableStatement.setString(1, adviceRequestBeanObj.getToDate());
				callableStatement.setString(2, adviceRequestBeanObj.getFromDate());
				callableStatement.setString(3, adviceRequestBeanObj.getTicketId());
				callableStatement.setString(4, adviceRequestBeanObj.getUploadedBy());
				callableStatement.setString(5, userId);
				callableStatement.setString(6, userRole);
				callableStatement.setInt(7, pageNumber);			

				callableStatement.registerOutParameter(8, Types.INTEGER);
				callableStatement.registerOutParameter(9, OracleTypes.CURSOR);
				callableStatement.registerOutParameter(10,OracleTypes.VARCHAR);
				callableStatement.registerOutParameter(11,OracleTypes.VARCHAR);
				

				callableStatement.executeUpdate();
	           int totalPages=callableStatement.getInt(8);
	           String errorMsg=callableStatement.getString(10);
	           
	           reportslogger.info("Error Message at waiverSearchRequestLevel method in PaymentAdviceDaoImpl:"+errorMsg);
	           adviceRequestBeanObj.setErrorMsg(errorMsg);
	           reportslogger.info("Error Message at waiverSearchRequestLevel method in PaymentAdviceDaoImpl:"+adviceRequestBeanObj.getErrorMsg());
	           
				resultsetdetails = (ResultSet) callableStatement.getObject(9);
				if (resultsetdetails == null) 
		        {
					reportslogger.info("DB returning NULL values at waiverSearchRequestLevel method in PaymentAdviceDaoImpl");
				}
				
				else
				{
					while (resultsetdetails.next()) 
					 {
						PaymentAdviceBean paymentAdviceBeanObj1 = new PaymentAdviceBean();
						
						paymentAdviceBeanObj1.setUploadedByName(resultsetdetails.getString("VC_UPLOADED_USER_NAME"));
						paymentAdviceBeanObj1.setFileName(resultsetdetails.getString("VC_UPLOADED_ORIGINAL_FILE_NAME"));
						paymentAdviceBeanObj1.setUploadTime(resultsetdetails.getString("DT_UPLOADED_DATE"));
						paymentAdviceBeanObj1.setTicketId(resultsetdetails.getString("I_REQUEST_ID"));
						paymentAdviceBeanObj1.setStatus(resultsetdetails.getString("STATUS_DESCRIPTION"));
						paymentAdviceBeanObj1.setComments(resultsetdetails.getString("REQUEST_COMMENTS"));
						paymentAdviceBeanObj1.setAllowDownload(resultsetdetails.getString("ALLOW_DOWNLOAD"));
						paymentAdviceBeanObj1.setRejectionRemarks(resultsetdetails.getString("VC_REJECTED_REASON"));
						paymentAdviceBeanObj1.setRejectedReason(resultsetdetails.getString("VC_REJECTED_REASON_DROP_DOWN"));
						paymentAdviceBeanObj1.setPaymentMode(resultsetdetails.getString("VC_PAYMENT_MODE"));

			
						adviceBeanListObj.add(paymentAdviceBeanObj1);
	                }
				}
				adviceHashMap.put(totalPages,adviceBeanListObj);
				
				reportslogger.info("Size of adviceHashMap at waiverSearchRequestLevel method in PaymentAdviceDaoImpl:"+ adviceHashMap.size());
				
			} catch (SQLException e) 
		     {
				  StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
			return null;
		     }
		catch(Exception e)
		{
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
			return null;
		}
		           finally{
		        	   
		        	   if(resultsetdetails!=null){
			 	     	   try {
			 	     		 resultsetdetails.close();
			 				} catch (Exception e) {
			 					  StringWriter errors= new StringWriter();
			 						e.printStackTrace(new PrintWriter(errors));
			 						reportslogger.error(errors);
			 				}
			 	     	   }
			 		
			 		if(callableStatement!=null){
			 	     	   try {
			 	     		  callableStatement.close();
			 				} catch (Exception e) {
			 					  StringWriter errors= new StringWriter();
			 						e.printStackTrace(new PrintWriter(errors));
			 						reportslogger.error(errors);
			 				}
			 	     	   }
		        	   
		        	   if(conn!=null){
		        	   try {
						conn.close();
					} catch (Exception e) {
						  StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							reportslogger.error(errors);
					}
		        	   }
		           }
			reportslogger.info("executed waiverSearchRequestLevel method in PaymentAdviceDaoImpl");	
	     return adviceHashMap;
	      
		}
   
   public PaymentAdviceBean downloadedTransFile(PaymentAdviceBean adviceDownloadTransObj,String extension,String pageNumber,String userRole,String userId) throws SQLException
	{
		
		ResultSet resultsetdetails = null;
		CallableStatement callableStatement=null;
		int i=1;
		
		try {

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			
			reportslogger.info("Entered downloadedTransFile method in PaymentAdviceDaoImpl");

			final String procedureCall = "{call ACE_CAD_ADVICE_TRANS_SEARCH(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";

			callableStatement = conn.prepareCall(procedureCall);

			callableStatement.setString(1, adviceDownloadTransObj.getToDate());
			callableStatement.setString(2, adviceDownloadTransObj.getFromDate());
			callableStatement.setString(3, adviceDownloadTransObj.getTicketId());
			callableStatement.setString(4, adviceDownloadTransObj.getUtrNum());	
			callableStatement.setString(5, adviceDownloadTransObj.getCustBankAcctNum());
			callableStatement.setString(6, adviceDownloadTransObj.getUploadedBy());
			callableStatement.setString(7, adviceDownloadTransObj.getProcess());
			callableStatement.setString(8, userId);
			callableStatement.setString(9, userRole);
			callableStatement.setString(10, pageNumber);			

			callableStatement.registerOutParameter(11, Types.INTEGER);
			callableStatement.registerOutParameter(12, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(13,OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(14,OracleTypes.VARCHAR);
			

			callableStatement.executeUpdate();
           int totalPages=callableStatement.getInt(11);
           String errorMsg=callableStatement.getString(13);
           
           reportslogger.info("Error Message at downloadedTransFile method in PaymentAdviceDaoImpl:"+errorMsg );
           adviceDownloadTransObj.setErrorMsg(errorMsg);
           
           reportslogger.info("Error Message at downloadedTransFile method in PaymentAdviceDaoImpl:"+errorMsg );
           reportslogger.info("Total No. of pages at downloadedTransFile method in PaymentAdviceDaoImpl:"+totalPages);
           
           adviceDownloadTransObj.setErrorMsg(errorMsg);
           
			resultsetdetails = (ResultSet) callableStatement.getObject(12);

			if (resultsetdetails == null) 
	        {
				reportslogger.info("DB returning NULL values at downloadedTransFile method in PaymentAdviceDaoImpl");
			}
			
			FileOutputStream downloadFile = null;
			
			try 
			{
				downloadFile = new FileOutputStream(new File("APS_PAY_ADVICE_TRANSACTION_LEVEL_"+getDateTime()+"."+extension));
			
			 
			
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet worksheet = workbook.createSheet("PAYMENT ADVICE TRANSACTION LEVEL REPORTS");
			XSSFRow row=null;
			row = worksheet.createRow(0);
			//XSSFCellStyle cellStyle = workbook.createCellStyle();

			XSSFCellStyle my_style = workbook.createCellStyle();
			 XSSFFont my_font=workbook.createFont();
			 my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
			 my_style.setFont(my_font);
			 
			 XSSFCellStyle rightAligned = workbook.createCellStyle();
			 rightAligned.setAlignment(XSSFCellStyle.ALIGN_RIGHT);

			Cell cellA1 = row.createCell((short) 0);
			cellA1.setCellValue("PAYMENT MODE");
			cellA1.setCellStyle(my_style);
			
			Cell cellB1 = row.createCell((short) 1);
			cellB1.setCellValue("TICKET/REQUEST ID");
			cellB1.setCellStyle(my_style);
			
			Cell cellC1 = row.createCell((short) 2);
			cellC1.setCellValue("UPLOAD DATE");
			cellC1.setCellStyle(my_style);
			
			/*Cell cellCC1 = row.createCell((short) 3);
			cellCC1.setCellValue("SOURCE TRACKING ID SERV");
			cellCC1.setCellStyle(my_style);
*/
			Cell cellCC1 = row.createCell((short) 3);
			cellCC1.setCellValue("UPLOADED BY(OLM ID)");
			cellCC1.setCellStyle(my_style);
			
			Cell cellD1 = row.createCell((short) 4);
			cellD1.setCellValue("UPLOADED BY(NAME)");
			cellD1.setCellStyle(my_style);
			
			Cell cellE1 = row.createCell((short) 5);
			cellE1.setCellValue("SOURCE LOB");
			cellE1.setCellStyle(my_style);
			
	        Cell cellF1 = row.createCell((short) 6);
			cellF1.setCellValue("SOURCE CIRCLE NAME");
			cellF1.setCellStyle(my_style);
			
			Cell cellG1 = row.createCell((short) 7);
			cellG1.setCellValue("TARGET LOB");
			cellG1.setCellStyle(my_style);
			//cellStyle = workbook.createCellStyle();
			
			Cell cellH1 = row.createCell((short) 8);
			cellH1.setCellValue("DESTINATION CIRCLE NAME");
			cellH1.setCellStyle(my_style);
			
			Cell cellI1 = row.createCell((short) 9);
			cellI1.setCellValue("UTR/CHEQUE NUMBER");
			cellI1.setCellStyle(my_style);
			
			Cell cellJ1 = row.createCell((short) 10);
			cellJ1.setCellValue("INCOMING TRANSACTION REF NO.");
			cellJ1.setCellStyle(my_style);
					
			Cell cellK1 = row.createCell((short) 11);
			cellK1.setCellValue("TRANS DATE");
			cellK1.setCellStyle(my_style);
			
			Cell cellL1 = row.createCell((short) 12);
			cellL1.setCellValue("RECEIPT AMOUNT");
			cellL1.setCellStyle(my_style);
			
			Cell cellM1 = row.createCell((short) 13);
			cellM1.setCellValue("PAYMENT EXCHANGE RATE");
			cellM1.setCellStyle(my_style);

			Cell cellN1 = row.createCell((short) 14);
			cellN1.setCellValue("FUND RECEIVED CURRENCY");
			cellN1.setCellStyle(my_style);
			
			//added on 19June by ajit
			
			Cell cellNx1 = row.createCell((short) 15);
			cellNx1.setCellValue("DUMMY ACCOUNT CURRENCY");
			cellNx1.setCellStyle(my_style);
			
			
			Cell cellNy1 = row.createCell((short) 16);
			cellNy1.setCellValue("POSTING CURRENCY");
			cellNy1.setCellStyle(my_style);
			
			
			
			
			Cell cellNN1 = row.createCell((short) 17);
			cellNN1.setCellValue("LEGAL ENTITY");
			cellNN1.setCellStyle(my_style);
			
			Cell cellP1 = row.createCell((short) 18);
			cellP1.setCellValue("CUSTOMER BANK ACCOUNT NO.");
			cellP1.setCellStyle(my_style);

			Cell cellQ1 = row.createCell((short) 19);
			cellQ1.setCellValue("RECEIVER NAME");
			cellQ1.setCellStyle(my_style);
			
			Cell cellR1 = row.createCell((short) 20);
			cellR1.setCellValue("REMITTER NAME");
			cellR1.setCellStyle(my_style);

			Cell cellS1 = row.createCell((short) 21);
			cellS1.setCellValue("REF NO.");
			cellS1.setCellStyle(my_style);

			Cell cellT1 = row.createCell((short) 22);	           
			cellT1.setCellValue("PAYMENT DETAILS 1");
			cellT1.setCellStyle(my_style);
			
			Cell cellU1 = row.createCell((short) 23);	           
			cellU1.setCellValue("PAYMENT DETAILS 2");
			cellU1.setCellStyle(my_style);
			
			Cell cellUU1 = row.createCell((short) 24);
			cellUU1.setCellValue("TARGET FX ACCOUNT NO.");
			cellUU1.setCellStyle(my_style);
			
			Cell cellVX1 = row.createCell((short) 25);
			cellVX1.setCellValue("RECORD TYPE");
			cellVX1.setCellStyle(my_style);
			
			Cell cellVVX1 = row.createCell((short) 26);
			cellVVX1.setCellValue("ACCOUNT TYPE");
			cellVVX1.setCellStyle(my_style);
			
			Cell cellV1 = row.createCell((short) 27);
			cellV1.setCellValue("CUSTOMER NAME");
			cellV1.setCellStyle(my_style);
			
			Cell cellVV1 = row.createCell((short) 28);
			cellVV1.setCellValue("INVOICE NUMBER");
			cellVV1.setCellStyle(my_style);
			
			Cell cellW1 = row.createCell((short) 29);
			cellW1.setCellValue("INVOICE ALLOCATION AMT");
			cellW1.setCellStyle(my_style);
			
			Cell cellX1 = row.createCell((short) 30);
			cellX1.setCellStyle(my_style);
			cellX1.setCellValue("CHEQUE DATE");
		
			Cell cellY1 = row.createCell((short) 31);
			cellY1.setCellStyle(my_style);
			cellY1.setCellValue("BANK NAME");
			
			Cell cellZ1 = row.createCell((short) 32);
			cellZ1.setCellStyle(my_style);
			cellZ1.setCellValue("REMARKS");
			
			///
			Cell cellHa1 = row.createCell((short) 33);
			cellHa1.setCellValue("SOURCE TRACKING ID");
			cellHa1.setCellStyle(my_style);
			
			Cell cellIa1 = row.createCell((short) 34);
			cellIa1.setCellValue("TARGET LOB");
			cellIa1.setCellStyle(my_style);
			
			Cell cellJa1 = row.createCell((short) 35);
			cellJa1.setCellValue("FILE NAME");
			cellJa1.setCellStyle(my_style);
					
			Cell cellKa1 = row.createCell((short) 36);
			cellKa1.setCellValue("PROCESS TYPE");
			cellKa1.setCellStyle(my_style);
			
			Cell cellLa1 = row.createCell((short) 37);
			cellLa1.setCellValue("APPROVED BY(OLM ID)");
			cellLa1.setCellStyle(my_style);
			
			Cell cellMa1 = row.createCell((short) 38);
			cellMa1.setCellValue("APPROVED BY(NAME)");
			cellMa1.setCellStyle(my_style);

			Cell cellNa1 = row.createCell((short) 39);
			cellNa1.setCellValue("APPROVED DATE");
			cellNa1.setCellStyle(my_style);
			
			Cell cellNNa1 = row.createCell((short) 40);
			cellNNa1.setCellValue("FINAL EXCHANGE RATE");
			cellNNa1.setCellStyle(my_style);
			
			Cell cellPa1 = row.createCell((short) 41);
			cellPa1.setCellValue("STATUS");
			cellPa1.setCellStyle(my_style);

			Cell cellQa1 = row.createCell((short) 42);
			cellQa1.setCellValue("DESTINATION TRACKING ID");
			cellQa1.setCellStyle(my_style);
			
			Cell cellRa1 = row.createCell((short) 43);
			cellRa1.setCellValue("DESTINATION TRACKING ID SERV");
			cellRa1.setCellStyle(my_style);

			Cell cellSa1 = row.createCell((short) 44);
			cellSa1.setCellValue("FX UPDATE DATE");
			cellSa1.setCellStyle(my_style);

			Cell cellTa1 = row.createCell((short) 45);	           
			cellTa1.setCellValue("REASON FOR FAILURE");
			cellTa1.setCellStyle(my_style);
			
			Cell cellUa1 = row.createCell((short) 46);	           
			cellUa1.setCellValue("FX POSTING STATUS");
			cellUa1.setCellStyle(my_style);
			
			Cell cellUUa1 = row.createCell((short) 47);
			cellUUa1.setCellValue("FX POSTING DESCRIPTION");
			cellUUa1.setCellStyle(my_style);
			
			Cell cellVa1 = row.createCell((short) 48);
			cellVa1.setCellValue("ROLE NAME");
			cellVa1.setCellStyle(my_style);
			
			Cell cellVVa1 = row.createCell((short) 49);
			cellVVa1.setCellValue("CAD FILE RECEIVED TIME");
			cellVVa1.setCellStyle(my_style);
			
			Cell cellWa1 = row.createCell((short) 50);
			cellWa1.setCellValue("DERIVED B2B B2C");
			cellWa1.setCellStyle(my_style);
			
			Cell cellXa1 = row.createCell((short) 51);
			cellXa1.setCellStyle(my_style);
			cellXa1.setCellValue("PAYMENT ADVICE EXCEMPTION");
			
			Cell cellYa1 = row.createCell((short) 52);
			cellYa1.setCellStyle(my_style);
			cellYa1.setCellValue("RECORD ID");
			
		
		
			
			
if(resultsetdetails!=null){
				while (resultsetdetails.next()) {
					//System.out.println("invoice number is " +resultsetdetails.getString("invoice_no"));
					//error_code = resultsetdetails.getString("error_reason_code");
				
				//	fileObj.setErrorReasonCode(error_code);
					PaymentAdviceBean adviceTransDownloadObj=new PaymentAdviceBean();
					
					/*adviceTransDownloadObj.setUtrNum(resultsetdetails.getString("UTR_CHQ_NUMBER"));
					
					if(resultsetdetails.getString("ORIG_TRACKING_ID")!=null)
					       adviceTransDownloadObj.setSourceTrackingId(resultsetdetails.getString("ORIG_TRACKING_ID"));
					else 
						 adviceTransDownloadObj.setSourceTrackingId("");
					
					//	adviceTransDownloadObj.setSourceTrackingIdServ(resultsetdetails.getString("ORIG_TRACKING_ID_SERV"));
					
					if(resultsetdetails.getString("TRACKING_ID")!=null)
					       adviceTransDownloadObj.setDestinationTrackingId(resultsetdetails.getString("TRACKING_ID"));
					else
						adviceTransDownloadObj.setDestinationTrackingId("");
					
					if(resultsetdetails.getString("TRACKING_ID_SERV")!=null)
					       adviceTransDownloadObj.setDestinationTrackingIdServ(resultsetdetails.getString("TRACKING_ID_SERV"));
					else
						adviceTransDownloadObj.setDestinationTrackingIdServ("");
					
					adviceTransDownloadObj.setCustBankAcctNum(resultsetdetails.getString("BANK_VIRTUAL_ACCOUNT_NO"));
					adviceTransDownloadObj.setTargetFxAcctNum(resultsetdetails.getString("ACCT_EXT_ID"));
					adviceTransDownloadObj.setInvoiceNumber(resultsetdetails.getString("INVOICE_NO"));
					adviceTransDownloadObj.setInvoiceAllocationAmt(resultsetdetails.getString("PAYMENT_AMOUNT"));
					adviceTransDownloadObj.setPaymentExchangeRate(resultsetdetails.getString("OLD_EXCHANGE_RATE"));
					adviceTransDownloadObj.setTdsAmount_Invoicewise(resultsetdetails.getString("TDS_AMOUNT"));
					
					if(resultsetdetails.getString("TAN_NUMBER")!=null)
					      adviceTransDownloadObj.setTanNo(resultsetdetails.getString("TAN_NUMBER"));
					else
						adviceTransDownloadObj.setTanNo("");
					if(resultsetdetails.getString("INPUT_REMARKS")!=null)
					      adviceTransDownloadObj.setRemarks(resultsetdetails.getString("INPUT_REMARKS"));					
					else
						adviceTransDownloadObj.setRemarks("");
					adviceTransDownloadObj.setUploadedBy(resultsetdetails.getString("VC_UPLOADED_USER_ID"));
					adviceTransDownloadObj.setUploadedByName(resultsetdetails.getString("VC_UPLOADED_USER_NAME"));
					adviceTransDownloadObj.setUploadTime(resultsetdetails.getString("DT_UPLOADED_DATE"));
					adviceTransDownloadObj.setFileName(resultsetdetails.getString("VC_UPLOADED_ORIGINAL_FILE_NAME"));
					adviceTransDownloadObj.setTicketId(resultsetdetails.getString("I_REQUEST_ID"));
					adviceTransDownloadObj.setApprovedBy(resultsetdetails.getString("VC_APPROVED_USER_ID"));
					adviceTransDownloadObj.setApprovedByName(resultsetdetails.getString("VC_APPROVED_USER_NAME"));
					
					if(resultsetdetails.getString("VC_DESTINATION_LOB")!=null)
					     adviceTransDownloadObj.setDestinationLob(resultsetdetails.getString("VC_DESTINATION_LOB"));
					else
						adviceTransDownloadObj.setDestinationLob("");
					
					if(resultsetdetails.getString("DT_APPROVAL_DATE")!=null)
					     adviceTransDownloadObj.setApprovalTime(resultsetdetails.getString("DT_APPROVAL_DATE"));
					else 
						adviceTransDownloadObj.setApprovalTime("");
					
					adviceTransDownloadObj.setFinalExchangeRate(resultsetdetails.getString("NEW_EXCHANGE_RATE"));
					adviceTransDownloadObj.setStatus(resultsetdetails.getString("STATUS_DESC"));
					
					if(resultsetdetails.getString("PAYMENT_POSTED_DATE")!=null)
					{
						
						String date = resultsetdetails.getString("PAYMENT_POSTED_DATE");
						SimpleDateFormat dateString = new SimpleDateFormat(
								"yyyy-MM-dd");
						Date date1;
						try {
							date1 = dateString.parse(date);
							SimpleDateFormat dateString1 = new SimpleDateFormat(
									"dd/MM/yyyy");
							String finalDate = dateString1.format(date1);
							adviceTransDownloadObj.setFxUpdateTime(finalDate);
						}
						catch (ParseException e) {
							StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							reportslogger.error(errors);
						}
						adviceTransDownloadObj.setFxUpdateTime(resultsetdetails.getString("PAYMENT_POSTED_DATE"));
						
					}
					else
						adviceTransDownloadObj.setFxUpdateTime("");
					adviceTransDownloadObj.setReasonForFailure(resultsetdetails.getString("ERROR_REASON_CODE"));
					adviceTransDownloadObj.setFxPostingStatus(resultsetdetails.getString("POSTING_STATUS_FX"));
					adviceTransDownloadObj.setFxPostingErrorDescription(resultsetdetails.getString("FX_POSTING_ERROR_DESCRIPTION"));
					adviceTransDownloadObj.setRoleName(resultsetdetails.getString("ROLE_NAME"));
					adviceTransDownloadObj.setProcess(resultsetdetails.getString("VC_PROCESS_TYPE"));

			*/
					
					
					adviceTransDownloadObj.setPaymentMode(resultsetdetails.getString("PAYMENT_MODE"));
					adviceTransDownloadObj.setTicketId(resultsetdetails.getString("I_REQUEST_ID"));
					if(resultsetdetails.getString("DT_UPLOADED_DATE")!=null)
					{
						adviceTransDownloadObj.setFileUploadDate(resultsetdetails.getString("DT_UPLOADED_DATE"));
					}
					
					else
						adviceTransDownloadObj.setFileUploadDate("");
					
					adviceTransDownloadObj.setUploadedBy(resultsetdetails.getString("VC_UPLOADED_USER_ID"));
					adviceTransDownloadObj.setUploadedByName(resultsetdetails.getString("VC_UPLOADED_USER_NAME"));
					adviceTransDownloadObj.setSourceLob(resultsetdetails.getString("SOURCE_LOB"));
					adviceTransDownloadObj.setSourceCircle(resultsetdetails.getString("SOURCE_CIRCLE_NAME"));
					
					if(resultsetdetails.getString("VC_DESTINATION_LOB")!=null)
					{
						adviceTransDownloadObj.setDestinationLob(resultsetdetails.getString("VC_DESTINATION_LOB"));
					}else
					{
						adviceTransDownloadObj.setDestinationLob("");
					}
					adviceTransDownloadObj.setDestinationCircle(resultsetdetails.getString("DESTINATION_CIRCLE_NAME"));
					adviceTransDownloadObj.setUtrNum(resultsetdetails.getString("UTR_CHQ_NUMBER"));
					adviceTransDownloadObj.setIncTransRefNumber(resultsetdetails.getString("INCOMING_TRANSACTION_REF_NO"));
					
					adviceTransDownloadObj.setTransDate(resultsetdetails.getString("TRANS_DATE"));
					adviceTransDownloadObj.setReceiptAmount(resultsetdetails.getString("RECEIPT_AMOUNT"));
					adviceTransDownloadObj.setPaymentExchangeRate(resultsetdetails.getString("PAYMENT_EXCHANGE_RATE"));
					adviceTransDownloadObj.setPaymentCurrency(resultsetdetails.getString("PAYMENT_CURRENCY"));
					
					//adding 2-more here on 19June-19 by AJIT
					adviceTransDownloadObj.setDummyCurrency(resultsetdetails.getString("DUMMY_CURRENCY"));
					adviceTransDownloadObj.setFundCurrency(resultsetdetails.getString("FUND_CURRENCY"));
					
					
					adviceTransDownloadObj.setLegalEntity(resultsetdetails.getString("LEGAL_ENTITY"));
					adviceTransDownloadObj.setCustBankAcctNum(resultsetdetails.getString("BANK_VIRTUAL_ACCOUNT_NO"));
					adviceTransDownloadObj.setReceiverName(resultsetdetails.getString("RECEIVER_NAME"));
					adviceTransDownloadObj.setRemitterName(resultsetdetails.getString("REMITTER_NAME"));
					adviceTransDownloadObj.setRefNum(resultsetdetails.getString("REF_NO"));
					adviceTransDownloadObj.setPaymentDetails1(resultsetdetails.getString("PAYMENT_DETAILS_1"));
					adviceTransDownloadObj.setPaymentDetails2(resultsetdetails.getString("PAYMENT_DETAILS_2"));
					adviceTransDownloadObj.setTargetFxAcctNum(resultsetdetails.getString("TARGET_FX_ACCOUNT_NO"));
					adviceTransDownloadObj.setCustName(resultsetdetails.getString("CUSTOMER_NAME"));
					adviceTransDownloadObj.setInvoiceNumber(resultsetdetails.getString("INVOICE_NO"));
					adviceTransDownloadObj.setInvoiceAllocationAmt(resultsetdetails.getString("INVOICE_ALLOCATION_AMOUNT"));
					adviceTransDownloadObj.setChequeDate(resultsetdetails.getString("CHEQUE_DATE"));
					adviceTransDownloadObj.setBankName(resultsetdetails.getString("BANK_NAME"));
					if(resultsetdetails.getString("INPUT_REMARKS")!=null)
					{
						adviceTransDownloadObj.setRemarks(resultsetdetails.getString("INPUT_REMARKS"));
					}
					else
					{
						adviceTransDownloadObj.setRemarks("");
					}
					if(resultsetdetails.getString("ORIG_TRACKING_ID")!=null)
					{
						adviceTransDownloadObj.setSourceTrackingId(resultsetdetails.getString("ORIG_TRACKING_ID"));
					}
					else
						adviceTransDownloadObj.setSourceTrackingId("");
					
					adviceTransDownloadObj.setTargetLob(resultsetdetails.getString("TARGET_LOB"));
					
					
					adviceTransDownloadObj.setFileName(resultsetdetails.getString("VC_UPLOADED_ORIGINAL_FILE_NAME"));
					adviceTransDownloadObj.setProcess(resultsetdetails.getString("VC_PROCESS_TYPE"));

					if(resultsetdetails.getString("VC_APPROVED_USER_ID")!=null)
					{
						adviceTransDownloadObj.setApprovedBy(resultsetdetails.getString("VC_APPROVED_USER_ID"));
					}
					else
					{
						adviceTransDownloadObj.setApprovedBy("");
					}
					

					if(resultsetdetails.getString("VC_APPROVED_USER_NAME")!=null)
					{
						adviceTransDownloadObj.setApprovedByName(resultsetdetails.getString("VC_APPROVED_USER_NAME"));
					}
					else
					{
						adviceTransDownloadObj.setApprovedByName("");
					}
					if(resultsetdetails.getString("DT_APPROVAL_DATE")!=null)
					{
						adviceTransDownloadObj.setApprovalTime(resultsetdetails.getString("DT_APPROVAL_DATE"));
					}
					
					else
						adviceTransDownloadObj.setApprovalTime("");
					
					
					adviceTransDownloadObj.setFinalExchangeRate(resultsetdetails.getString("NEW_EXCHANGE_RATE"));
					
					adviceTransDownloadObj.setStatusDescription(resultsetdetails.getString("STATUS_DESC"));
					

					if(resultsetdetails.getString("TRACKING_ID")!=null)
					{
						adviceTransDownloadObj.setDestinationTrackingId(resultsetdetails.getString("TRACKING_ID"));
					}
					else
						adviceTransDownloadObj.setDestinationTrackingId("");

						
						
					if(resultsetdetails.getString("TRACKING_ID_SERV")!=null)
					{
						adviceTransDownloadObj.setDestinationTrackingIdServ(resultsetdetails.getString("TRACKING_ID_SERV"));
					}
					else
						adviceTransDownloadObj.setDestinationTrackingIdServ("");
					if(resultsetdetails.getString("PAYMENT_POSTED_DATE")!=null)
					{
						adviceTransDownloadObj.setFxUpdateTime(resultsetdetails.getString("PAYMENT_POSTED_DATE"));				
					}
					else
						adviceTransDownloadObj.setFxUpdateTime("");
					
					adviceTransDownloadObj.setErrorReasonCode(resultsetdetails.getString("ERROR_REASON_CODE"));
				//	paymentAdviceBeanObj1.setStatus(resultsetdetails.getString("I_STATUS"));
					
					if(resultsetdetails.getString("POSTING_STATUS_FX")!=null)
					{
						adviceTransDownloadObj.setFxPostingStatus(resultsetdetails.getString("POSTING_STATUS_FX"));
					}
					else
						adviceTransDownloadObj.setFxPostingStatus("");
					adviceTransDownloadObj.setFxPostingErrorDescription(resultsetdetails.getString("FX_POSTING_ERROR_DESCRIPTION"));

					adviceTransDownloadObj.setRoleName(resultsetdetails.getString("ROLE_DESCRIPTION"));
					//paymentAdviceBeanObj1.setFinalExchangeRate(resultsetdetails.getString("NEW_EXCHANGE_RATE"));
					adviceTransDownloadObj.setCadRecievedTime(resultsetdetails.getString("CAD_FILE_RECEIVED_TIME"));

					adviceTransDownloadObj.setDerivedB2bB2c(resultsetdetails.getString("DERIVED_B2B_B2C"));
					adviceTransDownloadObj.setAdviceExemption(resultsetdetails.getString("PAYMENT_ADVICE_EXCEMPTION"));
					//
					adviceTransDownloadObj.setRecordType(resultsetdetails.getString("RECORD_TYPE"));
					adviceTransDownloadObj.setAccountType(resultsetdetails.getString("ACCOUNT_TYPE"));
					adviceTransDownloadObj.setRecordId(resultsetdetails.getString("RECORD_ID"));
					
					//
					//paymentAdviceBeanObj1.setTargetFxAcctNum(resultsetdetails.getString("ACCT_EXT_ID"));
					//paymentAdviceBeanObj1.setPaymentExchangeRate(resultsetdetails.getString("OLD_EXCHANGE_RATE"));
						 row = worksheet.createRow(i);
						 
						 

						
						XSSFCell cellA2 = row.createCell((short) 0);
						cellA2.setCellValue(adviceTransDownloadObj.getPaymentMode());
						
						XSSFCell cellB2 = row.createCell((short) 1);
						cellB2.setCellValue(adviceTransDownloadObj.getTicketId());
						cellB2.setCellStyle(rightAligned);
						
						XSSFCell cellC2 = row.createCell((short) 2);
						cellC2.setCellValue(adviceTransDownloadObj.getFileUploadDate());
						cellC2.setCellStyle(rightAligned);
						
					/*	XSSFCell cellCC2 = row.createCell((short) 3);
						cellCC2.setCellValue(adviceTransDownloadObj.getSourceTrackingIdServ());
						cellCC2.setCellStyle(rightAligned);*/
						
						XSSFCell cellCC2 = row.createCell((short) 3);
						cellCC2.setCellValue(adviceTransDownloadObj.getUploadedBy());
						
						
						XSSFCell cellD2 = row.createCell((short) 4);
						cellD2.setCellValue(adviceTransDownloadObj.getUploadedByName());
						
						
						XSSFCell cellE2 = row.createCell((short) 5);
						cellE2.setCellValue(adviceTransDownloadObj.getSourceLob());
						
						XSSFCell cellF2 = row.createCell((short) 6);
						cellF2.setCellValue(adviceTransDownloadObj.getSourceCircle());
						

						XSSFCell cellG2 = row.createCell((short) 7);
						cellG2.setCellValue(adviceTransDownloadObj.getDestinationLob());
						

						XSSFCell cellH2 = row.createCell((short) 8);
						cellH2.setCellValue(adviceTransDownloadObj.getDestinationCircle());
						
						
						XSSFCell cellI2 = row.createCell((short) 9);
						cellI2.setCellValue(adviceTransDownloadObj.getUtrNum());
						
						
						XSSFCell cellJ2 = row.createCell((short) 10);
						cellJ2.setCellValue(adviceTransDownloadObj.getIncTransRefNumber());
						
						
						XSSFCell cellK2 = row.createCell((short) 11);
						cellK2.setCellValue(adviceTransDownloadObj.getTransDate());
						cellK2.setCellStyle(rightAligned);
						
						XSSFCell cellL2 = row.createCell((short) 12);
						cellL2.setCellValue(adviceTransDownloadObj.getReceiptAmount());
						cellL2.setCellStyle(rightAligned);
						
						XSSFCell cellM2 = row.createCell((short) 13);
						cellM2.setCellValue(adviceTransDownloadObj.getPaymentExchangeRate());
						cellM2.setCellStyle(rightAligned);

						XSSFCell cellN2 = row.createCell((short) 14);
						cellN2.setCellValue(adviceTransDownloadObj.getFundCurrency());
						
						XSSFCell cellNx2 = row.createCell((short) 15);
						cellNx2.setCellValue(adviceTransDownloadObj.getDummyCurrency());
						
						XSSFCell cellNy2 = row.createCell((short) 16);
						cellNy2.setCellValue(adviceTransDownloadObj.getPaymentCurrency());
					
						
						XSSFCell cellNN2 = row.createCell((short) 17);
						cellNN2.setCellValue(adviceTransDownloadObj.getLegalEntity());
						 
						XSSFCell cellP2 = row.createCell((short) 18);
						cellP2.setCellValue(adviceTransDownloadObj.getCustBankAcctNum());
						
						XSSFCell cellQ2 = row.createCell((short) 19);
			            cellQ2.setCellValue(adviceTransDownloadObj.getReceiverName());
					
						XSSFCell cellR2 = row.createCell((short) 20);
			             cellR2.setCellValue(adviceTransDownloadObj.getRemitterName());
						
					    XSSFCell cellS2 = row.createCell((short) 21);
						cellS2.setCellValue(adviceTransDownloadObj.getRefNum());

						XSSFCell cellT2 = row.createCell((short) 22);
						cellT2.setCellValue(adviceTransDownloadObj.getPaymentDetails1());					
						
						XSSFCell cellU2 = row.createCell((short) 23);
						cellU2.setCellValue(adviceTransDownloadObj.getPaymentDetails2());
						
						XSSFCell cellUU2 = row.createCell((short) 24);
						cellUU2.setCellValue(adviceTransDownloadObj.getTargetFxAcctNum());
					//	cellUU2.setCellStyle(rightAligned);
						
						
						/////
						XSSFCell cellVX2 = row.createCell((short) 25);
						cellVX2.setCellValue(adviceTransDownloadObj.getRecordType());//getRecordType
						

						XSSFCell cellVY2 = row.createCell((short) 26);
						cellVY2.setCellValue(adviceTransDownloadObj.getAccountType());
						
						/////

						XSSFCell cellV2 = row.createCell((short) 27);
						cellV2.setCellValue(adviceTransDownloadObj.getCustName());
						

						XSSFCell cellVv2 = row.createCell((short) 28);
						cellVv2.setCellValue(adviceTransDownloadObj.getInvoiceNumber());
						cellVv2.setCellStyle(rightAligned);
						
						XSSFCell cellW2 = row.createCell((short) 29);
						cellW2.setCellValue(adviceTransDownloadObj.getInvoiceAllocationAmt());
						cellW2.setCellStyle(rightAligned);
						
						XSSFCell cellX2 = row.createCell((short) 30);
						cellX2.setCellValue(adviceTransDownloadObj.getChequeDate());
						cellX2.setCellStyle(rightAligned);
						
						XSSFCell cellY2 = row.createCell((short) 31);
						cellY2.setCellValue(adviceTransDownloadObj.getBankName());
						
						XSSFCell cellZ2 = row.createCell((short) 32);
						cellZ2.setCellValue(adviceTransDownloadObj.getRemarks());
						
												
						XSSFCell cellaa2 = row.createCell((short) 33);
						cellaa2.setCellValue(adviceTransDownloadObj.getSourceTrackingId());
						cellaa2.setCellStyle(rightAligned);
						
						XSSFCell cellIa2 = row.createCell((short) 34);
						cellIa2.setCellValue(adviceTransDownloadObj.getTargetLob());
						
						
						XSSFCell cellJa2 = row.createCell((short) 35);
						cellJa2.setCellValue(adviceTransDownloadObj.getFileName());
						
						XSSFCell cellKa2 = row.createCell((short) 36);
						cellKa2.setCellValue(adviceTransDownloadObj.getProcess());
						
						XSSFCell cellLa2 = row.createCell((short) 37);
						cellLa2.setCellValue(adviceTransDownloadObj.getApprovedBy());
						
						XSSFCell cellMa2 = row.createCell((short) 38);
						cellMa2.setCellValue(adviceTransDownloadObj.getApprovedByName());

						XSSFCell cellNa2 = row.createCell((short) 39);
						cellNa2.setCellValue(adviceTransDownloadObj.getFileUploadDate());
						cellNa2.setCellStyle(rightAligned);
						
						XSSFCell cellNNa2 = row.createCell((short) 40);
						cellNNa2.setCellValue(adviceTransDownloadObj.getFinalExchangeRate());
						cellNNa2.setCellStyle(rightAligned);
						 
						XSSFCell cellPa2 = row.createCell((short) 41);
						cellPa2.setCellValue(adviceTransDownloadObj.getStatusDescription());
						
						XSSFCell cellQa2 = row.createCell((short) 42);
			            cellQa2.setCellValue(adviceTransDownloadObj.getDestinationTrackingId());
			            cellQa2.setCellStyle(rightAligned);
					
						XSSFCell cellRa2 = row.createCell((short) 43);
			             cellRa2.setCellValue(adviceTransDownloadObj.getDestinationTrackingIdServ());
			             cellRa2.setCellStyle(rightAligned);
						
					    XSSFCell cellSa2 = row.createCell((short) 44);
						cellSa2.setCellValue(adviceTransDownloadObj.getFxUpdateTime());
						cellSa2.setCellStyle(rightAligned);

						XSSFCell cellTa2 = row.createCell((short) 45);
						cellTa2.setCellValue(adviceTransDownloadObj.getErrorReasonCode());
						
						
						XSSFCell cellUa2 = row.createCell((short) 46);
						cellUa2.setCellValue(adviceTransDownloadObj.getFxPostingStatus());
						
						XSSFCell cellUUa2 = row.createCell((short) 47);
						cellUUa2.setCellValue(adviceTransDownloadObj.getFxPostingErrorDescription());
					

						XSSFCell cellVa2 = row.createCell((short) 48);
						cellVa2.setCellValue(adviceTransDownloadObj.getRoleName());
						

						XSSFCell cellVva2 = row.createCell((short) 49);
						cellVva2.setCellValue(adviceTransDownloadObj.getCadRecievedTime());
						cellVva2.setCellStyle(rightAligned);
						
						XSSFCell cellWa2 = row.createCell((short) 50);
						cellWa2.setCellValue(adviceTransDownloadObj.getDerivedB2bB2c());
						
						XSSFCell cellXa2 = row.createCell((short) 51);
						cellXa2.setCellValue(adviceTransDownloadObj.getAdviceExemption());
					
						XSSFCell cellYa2 = row.createCell((short) 52);
						cellYa2.setCellValue(adviceTransDownloadObj.getRecordId());
						cellYa2.setCellStyle(rightAligned);
									
					i++;
					
					} 

				for(int j=0;j<29;j++)
				{
					worksheet.autoSizeColumn(j);
					
				}
				    try {
						workbook.write(downloadFile);
						  downloadFile.flush();
						    downloadFile.close();
					} catch (IOException e) {
						  StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							reportslogger.error(errors);
							return null;

					}
               }//if				  
         
			}//try
			
			catch (FileNotFoundException e) {
				  StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
					return null;

			}
			catch (Exception e) {
				  StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
					return null;

			}
		}
	
			    finally{
			    	
			    	  if(resultsetdetails!=null){
			 	     	   try {
			 	     		 resultsetdetails.close();
			 				} catch (Exception e) {
			 					  StringWriter errors= new StringWriter();
			 						e.printStackTrace(new PrintWriter(errors));
			 						reportslogger.error(errors);
			 				}
			 	     	   }
			 		
			 		if(callableStatement!=null){
			 	     	   try {
			 	     		  callableStatement.close();
			 				} catch (Exception e) {
			 					  StringWriter errors= new StringWriter();
			 						e.printStackTrace(new PrintWriter(errors));
			 						reportslogger.error(errors);
			 				}
			 	     	   }
			    	
		        	 if(conn!=null)
		        	 {
		        	       try {
						conn.close();
					           } 
		        	       catch (Exception e) {
		        	    	   StringWriter errors= new StringWriter();
		        	   		e.printStackTrace(new PrintWriter(errors));
		        	   		reportslogger.error(errors);
					        }
		        	   }
		           }
				
		reportslogger.info("executed downloadedTransFile method in PaymentAdviceDaoImpl");	
	
		return adviceDownloadTransObj;   
	}
   
   
	public PaymentAdviceBean downloadedEFTLevelFile(PaymentAdviceBean adviceEFTBeanObj,/*String downloadedFilesPath,*/String extension,String pageNumber,String userRole,String userId) throws SQLException
	{

		ResultSet resultsetdetails = null;
		CallableStatement callableStatement=null;
		int i=1;
		
		try {

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			reportslogger.info("Entered downloadedEFTLevelFile method in PaymentAdviceDaoImpl");

			final String procedureCall = "{call ACE_CAD_ADVICE_EFT_SEARCH(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
			
			callableStatement = conn.prepareCall(procedureCall);

			callableStatement.setString(1, adviceEFTBeanObj.getToDate());
			callableStatement.setString(2, adviceEFTBeanObj.getFromDate());
			callableStatement.setString(3, adviceEFTBeanObj.getTicketId());
			callableStatement.setString(4, adviceEFTBeanObj.getUtrNum());	
			callableStatement.setString(5, adviceEFTBeanObj.getCustBankAcctNum());
			callableStatement.setString(6, adviceEFTBeanObj.getUploadedBy());
			callableStatement.setString(7, adviceEFTBeanObj.getProcess());
			callableStatement.setString(8, userId);
			callableStatement.setString(9, userRole);
			callableStatement.setString(10, pageNumber);			

			callableStatement.registerOutParameter(11, Types.INTEGER);
			callableStatement.registerOutParameter(12, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(13,OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(14,OracleTypes.VARCHAR);
			

			callableStatement.executeUpdate();
           int totalPages=callableStatement.getInt(11);
           String errorMsg=callableStatement.getString(13);
           
           reportslogger.info("Error Message at downloadedTransFile method in PaymentAdviceDaoImpl:"+errorMsg );
           adviceEFTBeanObj.setErrorMsg(errorMsg);
           
			resultsetdetails = (ResultSet) callableStatement.getObject(12);

			if (resultsetdetails == null) 
	        {
				reportslogger.info("DB returning NULL values at downloadedEFTLevelFile method in PaymentAdviceDaoImpl");
			}
			
			FileOutputStream downloadFile = null;
			
			try 
			{
				downloadFile = new FileOutputStream(new File("APS_PAY_ADVICE_EFT_LEVEL_"+getDateTime()+"."+extension));
			
			
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet worksheet = workbook.createSheet("PAYMENT ADVICE EFT LEVEL REPORTS");
			XSSFRow row=null;
			row = worksheet.createRow(0);
		//	XSSFCellStyle cellStyle = workbook.createCellStyle();

			XSSFCellStyle my_style = workbook.createCellStyle();
			 XSSFFont my_font=workbook.createFont();
			 my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
			 my_style.setFont(my_font);
			 
			 XSSFCellStyle rightAligned = workbook.createCellStyle();
			 rightAligned.setAlignment(XSSFCellStyle.ALIGN_RIGHT);

			 
			Cell cellA1 = row.createCell((short) 0);
			cellA1.setCellValue("LOB");
			cellA1.setCellStyle(my_style);

			
			Cell cellB1 = row.createCell((short) 1);
			cellB1.setCellValue("REFERENCE/UTR NO.");
			cellB1.setCellStyle(my_style);
			
			Cell cellC1 = row.createCell((short) 2);
			cellC1.setCellValue("CUSTOMER BANK ACCOUNT NO.");
			cellC1.setCellStyle(my_style);
			
		/*	Cell cellD1 = row.createCell((short) 3);
			cellD1.setCellValue("AIRTEL BANK ACCOUNT NUMBER");*/
			
			Cell cellD1 = row.createCell((short) 3);
			cellD1.setCellValue("FILE UPLOAD DATE");
			cellD1.setCellStyle(my_style);
			
/*	        Cell cellF1 = row.createCell((short) 5);
			cellF1.setCellValue("VENDOR NAME");*/
			
			Cell cellE1 = row.createCell((short) 4);
			cellE1.setCellValue("USER OLM ID");
			cellE1.setCellStyle(my_style);
			//cellStyle = workbook.createCellStyle();
			
			
			Cell cellG1 = row.createCell((short) 5);
			cellG1.setCellValue("PAYMENT MODE");
			cellG1.setCellStyle(my_style);
			
	/*		Cell cellJ1 = row.createCell((short) 9);
			cellJ1.setCellValue("PAYMENT DATE");*/
					
			Cell cellH1 = row.createCell((short) 6);
			cellH1.setCellValue("BANK CREDIT RECEIVED DATE");
			cellH1.setCellStyle(my_style);
			
			Cell cellHH1 = row.createCell((short) 7);
			cellHH1.setCellValue("PAYMENT REQUEST ID");
			cellHH1.setCellStyle(my_style);
			
			Cell cellHH2 = row.createCell((short) 8);
			cellHH2.setCellValue("FILE NAME");
			cellHH2.setCellStyle(my_style);
				
			Cell cellI1 = row.createCell((short) 9);
			cellI1.setCellValue("REQUEST RAISED DATE");
			cellI1.setCellStyle(my_style);
			
			Cell cellJ1 = row.createCell((short) 10);
			cellJ1.setCellValue("REQUEST RAISED TIME");
			cellJ1.setCellStyle(my_style);
			
			Cell cellL1 = row.createCell((short) 11);
			cellL1.setCellValue("PROCESS TYPE");
			cellL1.setCellStyle(my_style);
			
			Cell cellM1 = row.createCell((short) 12);
			cellM1.setCellValue("REQUEST STATUS");
			cellM1.setCellStyle(my_style);
			
			Cell cellN1 = row.createCell((short) 13);
			cellN1.setCellValue("UTR LEVEL STATUS");
			cellN1.setCellStyle(my_style);
					
			Cell cellO1 = row.createCell((short) 14);
			cellO1.setCellValue("NO.OF ACCOUNTS POSTED");
			cellO1.setCellStyle(my_style);
			
			Cell cellP1 = row.createCell((short) 15);
			cellP1.setCellValue("NO.OF INVOICES POSTED");
			cellP1.setCellStyle(my_style);
			
			Cell cellQ1 = row.createCell((short) 16);
			cellQ1.setCellValue("VALUE OF EFT PAYMENT");
			cellQ1.setCellStyle(my_style);

			Cell cellR1 = row.createCell((short) 17);	           
			cellR1.setCellValue("POSTING DATE");
			cellR1.setCellStyle(my_style);
			
			Cell cellS1 = row.createCell((short) 18);	           
			cellS1.setCellValue("POSTING TIME");
			cellS1.setCellStyle(my_style);
			
			Cell cellT1 = row.createCell((short) 19);
			cellT1.setCellValue("CREDIT DT vs REQUEST DATE");
			cellT1.setCellStyle(my_style);
			
			Cell cellU1 = row.createCell((short) 20);
			cellU1.setCellValue("REQUEST DATE vs POSTED DATE");
			cellU1.setCellStyle(my_style);
		
			Cell cellV1 = row.createCell((short) 21);
			cellV1.setCellValue("CREDIT DATE vs POSTED DATE");
			cellV1.setCellStyle(my_style);
			
		
			
			
if(resultsetdetails!=null){
				while (resultsetdetails.next()) {
					//System.out.println("invoice number is " +resultsetdetails.getString("invoice_no"));
					//error_code = resultsetdetails.getString("error_reason_code");
				
				//	fileObj.setErrorReasonCode(error_code);
					PaymentAdviceBean adviceDownloadEFTBeanObj=new PaymentAdviceBean();
					
					adviceDownloadEFTBeanObj.setUtrNum(resultsetdetails.getString("UTR_CHQ_NUMBER"));
					adviceDownloadEFTBeanObj.setLob(resultsetdetails.getString("LOB"));
					adviceDownloadEFTBeanObj.setTicketId(resultsetdetails.getString("I_REQUEST_ID"));
					adviceDownloadEFTBeanObj.setCustBankAcctNum(resultsetdetails.getString("BANK_VIRTUAL_ACCOUNT_NO"));
					adviceDownloadEFTBeanObj.setAirtelBankAcctNum(resultsetdetails.getString("AIRTL_BANK_ACCOUNT_NO"));
					
					if(resultsetdetails.getString("PAYMENT_FILE_UPLOAD_DATE")!=null)
					{
						
						String date = resultsetdetails.getString("PAYMENT_FILE_UPLOAD_DATE");
						SimpleDateFormat dateString = new SimpleDateFormat(
								"yyyy-MM-dd HH:mm:ss");
						Date date1;
						try {
							date1 = dateString.parse(date);
							SimpleDateFormat dateString1 = new SimpleDateFormat(
									"dd/MM/yyyy");
							String finalDate = dateString1.format(date1);
							adviceDownloadEFTBeanObj.setFileUploadDate(finalDate);
						}
						catch (ParseException e) {
							  StringWriter errors= new StringWriter();
								e.printStackTrace(new PrintWriter(errors));
								reportslogger.error(errors);
						}
						
					}
					
					else
					    adviceDownloadEFTBeanObj.setFileUploadDate("");
					
					adviceDownloadEFTBeanObj.setVendorName(resultsetdetails.getString("VENDOR_NAME"));
					adviceDownloadEFTBeanObj.setUploadedBy(resultsetdetails.getString("VENDOR_USERID"));
					adviceDownloadEFTBeanObj.setFileName(resultsetdetails.getString("ORIGINAL_FILE_NAME"));
					adviceDownloadEFTBeanObj.setPaymentMode(resultsetdetails.getString("PAYMENT_MODE"));
					//adviceDownloadEFTBeanObj.setPaymentDate(resultsetdetails.getDate(""));
					
					if(resultsetdetails.getString("BANK_CREDIT_RECORD_DATE")!=null)
					{
						
						String date = resultsetdetails.getString("BANK_CREDIT_RECORD_DATE");
						SimpleDateFormat dateString = new SimpleDateFormat(
								"yyyy-MM-dd HH:mm:ss");
						Date date1;
						try {
							date1 = dateString.parse(date);
							SimpleDateFormat dateString1 = new SimpleDateFormat(
									"dd/MM/yyyy");
							String finalDate = dateString1.format(date1);
							  adviceDownloadEFTBeanObj.setBankCreditRcrdDate(finalDate);
						   }
						catch (ParseException e) {
							  StringWriter errors= new StringWriter();
								e.printStackTrace(new PrintWriter(errors));
								reportslogger.error(errors);
						}
					}
					else
						adviceDownloadEFTBeanObj.setBankCreditRcrdDate("");
					
					
					if(resultsetdetails.getString("REQUEST_RAISED_DATE")!=null)
					{
						
						String date = resultsetdetails.getString("REQUEST_RAISED_DATE");
						SimpleDateFormat dateString = new SimpleDateFormat(
								"yyyy-MM-dd HH:mm:ss");
						Date date1;
						try {
							date1 = dateString.parse(date);
							SimpleDateFormat dateString1 = new SimpleDateFormat(
									"dd/MM/yyyy");
							String finalDate = dateString1.format(date1);
							adviceDownloadEFTBeanObj.setRequestRaisedDate(finalDate);
						}
						catch (ParseException e) {
							  StringWriter errors= new StringWriter();
								e.printStackTrace(new PrintWriter(errors));
								reportslogger.error(errors);
						}
					
					}
					else
					   adviceDownloadEFTBeanObj.setRequestRaisedDate("");
					
					
					adviceDownloadEFTBeanObj.setRequestStatus(resultsetdetails.getString("FILE_LEVEL_STATUS"));
					adviceDownloadEFTBeanObj.setUtrLevelStatus(resultsetdetails.getString("UTR_LEVEL_STATUS"));
					adviceDownloadEFTBeanObj.setNumOfAcctsPosted(resultsetdetails.getLong("NO_OF_ACCT_POSTED"));
					adviceDownloadEFTBeanObj.setNumOfInvoicesPosted(resultsetdetails.getLong("NO_OF_INV_POSTED"));
					adviceDownloadEFTBeanObj.setValueOfEftPayment(resultsetdetails.getString("PAYMENT_AMOUNT"));
					adviceDownloadEFTBeanObj.setRequestRaisedTime(resultsetdetails.getString("REQUEST_RAISED_TIME"));
					
					if(resultsetdetails.getString("POSTING_DATE")!=null)
					{
						
						String date = resultsetdetails.getString("POSTING_DATE");
						SimpleDateFormat dateString = new SimpleDateFormat(
								"yyyy-MM-dd HH:mm:ss");
						Date date1;
						try {
							date1 = dateString.parse(date);
							SimpleDateFormat dateString1 = new SimpleDateFormat(
									"dd/MM/yyyy");
							String finalDate = dateString1.format(date1);
							  adviceDownloadEFTBeanObj.setPostingDate(finalDate);
						   }
						catch (ParseException e) {
							  StringWriter errors= new StringWriter();
								e.printStackTrace(new PrintWriter(errors));
								reportslogger.error(errors);
						}
					}
					   else
						 adviceDownloadEFTBeanObj.setPostingDate("");
					
					adviceDownloadEFTBeanObj.setPostingTime(resultsetdetails.getString("POSTING_TIME"));
					
					if(resultsetdetails.getString("DIFF_CREDIT_REQUEST_DATES")!=null)
      					   adviceDownloadEFTBeanObj.setCreditDateVsRequestDate(resultsetdetails.getString("DIFF_CREDIT_REQUEST_DATES"));
					else
						   adviceDownloadEFTBeanObj.setCreditDateVsRequestDate("");
					
					if(resultsetdetails.getString("DIFF_REQUEST_POSTED_DATES")!=null)
						   adviceDownloadEFTBeanObj.setRequestDateVsPostedDate(resultsetdetails.getString("DIFF_REQUEST_POSTED_DATES"));
					else 
						adviceDownloadEFTBeanObj.setRequestDateVsPostedDate("");
					
					if(resultsetdetails.getString("DIFF_CREDIT_POSTED_DATES")!=null)
					       adviceDownloadEFTBeanObj.setCreditDateVsPostedDate(resultsetdetails.getString("DIFF_CREDIT_POSTED_DATES"));
					else
						adviceDownloadEFTBeanObj.setCreditDateVsPostedDate("");
					
					    adviceDownloadEFTBeanObj.setProcess(resultsetdetails.getString("PROCESS_TYPE"));
			
						 row = worksheet.createRow(i);
						 
						 
						XSSFCell cellA2 = row.createCell((short) 0);
						cellA2.setCellValue(adviceDownloadEFTBeanObj.getLob());
						
						XSSFCell cellB2 = row.createCell((short) 1);
						cellB2.setCellValue(adviceDownloadEFTBeanObj.getUtrNum());
						
						XSSFCell cellC2 = row.createCell((short) 2);
						cellC2.setCellValue(adviceDownloadEFTBeanObj.getCustBankAcctNum());
						
					/*	XSSFCell cellD2 = row.createCell((short) 3);
						cellD2.setCellValue(adviceDownloadEFTBeanObj.getAirtelBankAcctNum());*/
						
						if(adviceDownloadEFTBeanObj.getFileUploadDate()==null)
						{
							XSSFCell cellD2 = row.createCell((short) 3);
							cellD2.setCellValue("-");
						}
						
						else
						{
						XSSFCell cellD2 = row.createCell((short) 3);
						cellD2.setCellValue(adviceDownloadEFTBeanObj.getFileUploadDate());
						}
						
					/*	XSSFCell cellF2 = row.createCell((short) 5);
						cellF2.setCellValue(adviceDownloadEFTBeanObj.getVendorName());*/

						XSSFCell cellE2 = row.createCell((short) 4);
						cellE2.setCellValue(adviceDownloadEFTBeanObj.getUploadedBy());
			
						
						XSSFCell cellG2 = row.createCell((short) 5);
						cellG2.setCellValue(adviceDownloadEFTBeanObj.getPaymentMode());
						
						
						if(adviceDownloadEFTBeanObj.getBankCreditRcrdDate()==null)
						{
						XSSFCell cellH2 = row.createCell((short) 6);
						cellH2.setCellValue("-");
						}
						
						else
						{
							XSSFCell cellH2 = row.createCell((short) 6);
							cellH2.setCellValue(adviceDownloadEFTBeanObj.getBankCreditRcrdDate());
						}
						
						XSSFCell cellHH3 = row.createCell((short) 7);
						cellHH3.setCellValue(adviceDownloadEFTBeanObj.getTicketId());
						cellHH3.setCellStyle(rightAligned);
						
						XSSFCell cellHH4 = row.createCell((short) 8);
						cellHH4.setCellValue(adviceDownloadEFTBeanObj.getFileName());
						
						XSSFCell cellI2 = row.createCell((short) 9);
						cellI2.setCellValue(adviceDownloadEFTBeanObj.getRequestRaisedDate());
						
						XSSFCell cellJ2 = row.createCell((short) 10);
			            cellJ2.setCellValue(adviceDownloadEFTBeanObj.getRequestRaisedTime());
			             
						
						
						
						XSSFCell cellL2 = row.createCell((short) 11);
						cellL2.setCellValue(adviceDownloadEFTBeanObj.getProcess());
						
						
						XSSFCell cellM2 = row.createCell((short) 12);
						cellM2.setCellValue(adviceDownloadEFTBeanObj.getRequestStatus());
						
						XSSFCell cellN2 = row.createCell((short) 13);
						cellN2.setCellValue(adviceDownloadEFTBeanObj.getUtrLevelStatus());
						
						
						XSSFCell cellO2 = row.createCell((short) 14);
						cellO2.setCellValue(adviceDownloadEFTBeanObj.getNumOfAcctsPosted());

						XSSFCell cellP2 = row.createCell((short) 15);
						cellP2.setCellValue(adviceDownloadEFTBeanObj.getNumOfInvoicesPosted());

						XSSFCell cellQ2 = row.createCell((short) 16);
			            cellQ2.setCellValue(adviceDownloadEFTBeanObj.getValueOfEftPayment());
			            cellQ2.setCellStyle(rightAligned);
						
			             if(adviceDownloadEFTBeanObj.getPostingDate()==null)
			             {
			            	 XSSFCell cellR2 = row.createCell((short) 17);
								cellR2.setCellValue("-");
			             }
			             else
			             {
					    XSSFCell cellR2 = row.createCell((short) 17);
						cellR2.setCellValue(adviceDownloadEFTBeanObj.getPostingDate());
			             }
						XSSFCell cellS2 = row.createCell((short) 18);
						cellS2.setCellValue(adviceDownloadEFTBeanObj.getPostingTime());
						
						XSSFCell cellT2 = row.createCell((short) 19);
						cellT2.setCellValue(adviceDownloadEFTBeanObj.getCreditDateVsRequestDate());
						cellT2.setCellStyle(rightAligned);
						
						XSSFCell cellU2 = row.createCell((short) 20);
						cellU2.setCellValue(adviceDownloadEFTBeanObj.getRequestDateVsPostedDate());
						cellU2.setCellStyle(rightAligned);
						
						XSSFCell cellV2 = row.createCell((short) 21);
						cellV2.setCellValue(adviceDownloadEFTBeanObj.getCreditDateVsPostedDate());
						cellV2.setCellStyle(rightAligned);
						
						i++;
					
					} 
				
				for(int j=0;j<22;j++)
				{
					worksheet.autoSizeColumn(j);
					
				}

				    try {
						workbook.write(downloadFile);
						  downloadFile.flush();
						    downloadFile.close();
					} catch (IOException e) {
						  StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							reportslogger.error(errors);
							return null;

							}
                       }//if				  
                  }//try
			
			catch (FileNotFoundException e) {
				  StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
					return null;

			}
			catch (Exception e) {
				  StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
					return null;
			}			    
		}
	
			    finally{
			    	
			    	if(resultsetdetails!=null){
			 	     	   try {
			 	     		 resultsetdetails.close();
			 				} catch (Exception e) {
			 					  StringWriter errors= new StringWriter();
			 						e.printStackTrace(new PrintWriter(errors));
			 						reportslogger.error(errors);
			 				}
			 	     	   }
			 		
			 		if(callableStatement!=null){
			 	     	   try {
			 	     		  callableStatement.close();
			 				} catch (Exception e) {
			 					  StringWriter errors= new StringWriter();
			 						e.printStackTrace(new PrintWriter(errors));
			 						reportslogger.error(errors);
			 				}
			 	     	   }
			    	
		        	 if(conn!=null)
		        	 {
		        	       try {
						conn.close();
					           } 
		        	       catch (Exception e) {
		        	    	   StringWriter errors= new StringWriter();
		        	   		e.printStackTrace(new PrintWriter(errors));
		        	   		reportslogger.error(errors);
		        	   		}
		        	   }
		           }
		
		reportslogger.info("executed downloadedEFTLevelFile method in PaymentAdviceDaoImpl");	
	
		return adviceEFTBeanObj; 
	}


	public PaymentAdviceBean downloadedRequestLevelFile(PaymentAdviceBean adviceDownloadRequestObj,String extension,String pageNumber,String userRole,String userId) throws SQLException
	{
		
		ResultSet resultsetdetails = null;
		CallableStatement callableStatement=null;
		int i=1;
		
		try {

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			reportslogger.info("Entered downloadedRequestLevelFile method in PaymentAdviceDaoImpl");
			
			final String procedureCall = "{call ACE_CAD_ADVICE_REQUEST_SEARCH(?,?,?,?,?,?,?,?,?,?,?)}";

			callableStatement = conn.prepareCall(procedureCall);

			callableStatement.setString(1, adviceDownloadRequestObj.getToDate());
			callableStatement.setString(2, adviceDownloadRequestObj.getFromDate());
			callableStatement.setString(3, adviceDownloadRequestObj.getTicketId());
			callableStatement.setString(4, adviceDownloadRequestObj.getUploadedBy());
			callableStatement.setString(5, userId);
			callableStatement.setString(6, userRole);
			callableStatement.setString(7, pageNumber);			

			callableStatement.registerOutParameter(8, Types.INTEGER);
			callableStatement.registerOutParameter(9, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(10,OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(11,OracleTypes.VARCHAR);
			

			callableStatement.executeUpdate();
           int totalPages=callableStatement.getInt(8);
           String errorMsg=callableStatement.getString(10);
           
           reportslogger.info("Error Message at downloadedTransFile method in PaymentAdviceDaoImpl:"+errorMsg);
           adviceDownloadRequestObj.setErrorMsg(errorMsg);
           reportslogger.info("error"+adviceDownloadRequestObj.getErrorMsg());
      
           reportslogger.info("Error Message at downloadedTransFile method in PaymentAdviceDaoImpl:"+errorMsg );
           reportslogger.info("Total No. of pages at downloadedTransFile method in PaymentAdviceDaoImpl:"+totalPages);
           
           adviceDownloadRequestObj.setErrorMsg(errorMsg);
           
			resultsetdetails = (ResultSet) callableStatement.getObject(9);

			if (resultsetdetails == null) 
	        {
				reportslogger.info("DB returning NULL values at downloadedEFTLevelFile method in PaymentAdviceDaoImpl");
			}
			
			FileOutputStream downloadFile = null;
			
			try 
			{
				downloadFile = new FileOutputStream(new File("APS_PAY_ADVICE_REQUEST_LEVEL_"+getDateTime()+"."+extension));
		
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet worksheet = workbook.createSheet("PAYMENT ADVICE REQUEST LEVEL REPORTS");
			XSSFRow row=null;
			row = worksheet.createRow(0);
//			XSSFCellStyle cellStyle = workbook.createCellStyle();
			
			XSSFCellStyle my_style = workbook.createCellStyle();
			 XSSFFont my_font=workbook.createFont();
			 my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
			 my_style.setFont(my_font);
			 
			 XSSFCellStyle rightAligned = workbook.createCellStyle();
			 rightAligned.setAlignment(XSSFCellStyle.ALIGN_RIGHT);
			
			
			Cell cellA1 = row.createCell((short) 0);
			cellA1.setCellValue("REQUEST/TICKET ID");
			cellA1.setCellStyle(my_style);
			
			Cell cellB1 = row.createCell((short) 1);
			cellB1.setCellValue("UPLOADED BY(NAME)");
			cellB1.setCellStyle(my_style);
			
			Cell cellC1 = row.createCell((short) 2);
			cellC1.setCellValue("UPLOADED DATE");
			cellC1.setCellStyle(my_style);
			
			Cell cellD1 = row.createCell((short) 3);
			cellD1.setCellValue("FILE NAME");
			cellD1.setCellStyle(my_style);
			
			Cell cellE1 = row.createCell((short) 4);
			cellE1.setCellValue("STATUS");
			cellE1.setCellStyle(my_style);
			
			Cell cellF1 = row.createCell((short) 5);
			cellF1.setCellValue("COMMENTS");
			cellF1.setCellStyle(my_style);
			
			Cell cellG1 = row.createCell((short) 6);
			cellG1.setCellValue("REJECTION REASON");
			cellG1.setCellStyle(my_style);
			
			Cell cellH1 = row.createCell((short) 7);
			cellH1.setCellValue("REJECTION REMARKS");
			cellH1.setCellStyle(my_style);
			
if(resultsetdetails!=null){
				while (resultsetdetails.next()) {
					//System.out.println("invoice number is " +resultsetdetails.getString("invoice_no"));
					//error_code = resultsetdetails.getString("error_reason_code");
				
				//	fileObj.setErrorReasonCode(error_code);
					PaymentAdviceBean adviceDownloadObj=new PaymentAdviceBean();
					
					adviceDownloadObj.setTicketId(resultsetdetails.getString("I_REQUEST_ID"));
					adviceDownloadObj.setUploadedByName(resultsetdetails.getString("VC_UPLOADED_USER_NAME"));
					adviceDownloadObj.setUploadTime(resultsetdetails.getString("DT_UPLOADED_DATE"));
					adviceDownloadObj.setFileName(resultsetdetails.getString("VC_UPLOADED_ORIGINAL_FILE_NAME"));
					adviceDownloadObj.setStatus(resultsetdetails.getString("STATUS_DESCRIPTION"));
					adviceDownloadObj.setComments(resultsetdetails.getString("REQUEST_COMMENTS"));
					adviceDownloadObj.setRejectionRemarks(resultsetdetails.getString("VC_REJECTED_REASON"));
					adviceDownloadObj.setRejectedReason(resultsetdetails.getString("VC_REJECTED_REASON_DROP_DOWN"));

			
						 row = worksheet.createRow(i);
						 
						 

						XSSFCell cellA2 = row.createCell((short) 0);
						cellA2.setCellValue(adviceDownloadObj.getTicketId());
						cellA2.setCellStyle(rightAligned);
						 
						XSSFCell cellB2 = row.createCell((short) 1);
						cellB2.setCellValue(adviceDownloadObj.getUploadedByName());
						
						XSSFCell cellC2 = row.createCell((short) 2);
						cellC2.setCellValue(adviceDownloadObj.getUploadTime());
						
						XSSFCell cellD2 = row.createCell((short) 3);
						cellD2.setCellValue(adviceDownloadObj.getFileName());
						
						XSSFCell cellE2 = row.createCell((short) 4);
						cellE2.setCellValue(adviceDownloadObj.getStatus());
						
						XSSFCell cellF2 = row.createCell((short) 5);
						cellF2.setCellValue(adviceDownloadObj.getComments());
						
						XSSFCell cellG2 = row.createCell((short) 6);
						cellG2.setCellValue(adviceDownloadObj.getRejectedReason());
						
						XSSFCell cellH2 = row.createCell((short) 7);
						cellH2.setCellValue(adviceDownloadObj.getRejectionRemarks());
					

						i++;
					
					} 

				for(int j=0;j<8;j++)
				{
					worksheet.autoSizeColumn(j);
					
				}
				    try {
						workbook.write(downloadFile);
						  downloadFile.flush();
						    downloadFile.close();
					} catch (IOException e) {
						  StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							reportslogger.error(errors);
							return null;

							}
                   }//if				  
				    
            }//try
			
		catch (FileNotFoundException e) {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
				return null;

		}
		catch (Exception e) {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
				return null;
		}
			}
	
			    finally{
			    	
			    	if(resultsetdetails!=null){
			 	     	   try {
			 	     		 resultsetdetails.close();
			 				} catch (Exception e) {
			 					  StringWriter errors= new StringWriter();
			 						e.printStackTrace(new PrintWriter(errors));
			 						reportslogger.error(errors);
			 				}
			 	     	   }
			 		
			 		if(callableStatement!=null){
			 	     	   try {
			 	     		  callableStatement.close();
			 				} catch (Exception e) {
			 					  StringWriter errors= new StringWriter();
			 						e.printStackTrace(new PrintWriter(errors));
			 						reportslogger.error(errors);
			 				}
			 	     	   }
		        	 if(conn!=null)
		        	 {
		        	       try {
						conn.close();
					           } 
		        	       catch (Exception e) {
		        	    	   StringWriter errors= new StringWriter();
		        	   		e.printStackTrace(new PrintWriter(errors));
		        	   		reportslogger.error(errors);
		        	   		}
		        	   }
		           }
				
		reportslogger.info("executed downloadedRequestLevelFile method in PaymentAdviceDaoImpl");	
		
		return adviceDownloadRequestObj;   
	}
	

	public ProcessedAdviceFileDetails downloadProcessedFile(String userId,String requestId,String paymentMode,String extension) throws SQLException
	{

	ResultSet resultsetdetails = null;
	Connection connection=null;
	CallableStatement callableStatement=null;
	int i=1;
	ProcessedAdviceFileDetails paymentAdvicedownloadObj=new ProcessedAdviceFileDetails();	

	try {
	   
	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
	connection = jdbcTemplate.getDataSource().getConnection();
	final String procedureCall = "{call GET_PAYMENT_ADVICE_REQ_DETAILS(?,?,?,?,?)}";

	 callableStatement = connection.prepareCall(procedureCall);


	 reportslogger.info("details entered into callable statement of downloadProcessedFile @paymentAdviceImpl ");
	 reportslogger.info("REQUEST ID AND PAYMENT MODE ARE" +"REQUEST ID" +requestId +"PAYMENT MODE" +paymentMode);
	callableStatement.setString(1, userId);
	callableStatement.setInt(2, Integer.parseInt(requestId));
	callableStatement.setString(3, paymentMode);
	callableStatement.registerOutParameter(4, OracleTypes.CURSOR);
	callableStatement.registerOutParameter(5,OracleTypes.VARCHAR);

	callableStatement.executeUpdate();

	String errorMsg=callableStatement.getString(5);

	reportslogger.info("errorMsg @ downloadProcessedFile"+errorMsg );
	paymentAdvicedownloadObj.setDownloadStatus(errorMsg);


	resultsetdetails = (ResultSet) callableStatement.getObject(4);

	if (resultsetdetails == null) 
	{
		reportslogger.info("DB RETURNING NULL VALUES");
	}

	FileOutputStream downloadFile = null;
	try 
	{
		downloadFile = new FileOutputStream(new File("APS_PAYMENT_ADVICE_PROCESSED_FILE_"+requestId+"_"+getDateTime()+"."+extension));

		//downloadFile = new FileOutputStream(new File(paymentAdviceHomePath+ File.separator+"UploadedFiles"+File.separator+"Payment_Advice_"+requestId+"."+extension));
		//downloadFile = new FileOutputStream(new File("C:/Users/1004362/Desktop/A/test1.xls"));
	

	XSSFWorkbook workbook = new XSSFWorkbook();
	XSSFSheet worksheet = workbook.createSheet("Payment Advice");
	XSSFRow row=null;
	row = worksheet.createRow(0);
	XSSFCellStyle cellStyle = workbook.createCellStyle();

	Cell cellA1 = row.createCell((short) 0);
	cellA1.setCellValue("Payment Mode");

	Cell cellB1 = row.createCell((short) 1);
	cellB1.setCellValue("Ticket No");

	Cell cellC1 = row.createCell((short) 2);
	cellC1.setCellValue("Ticket Date"); 

	Cell cellD1 = row.createCell((short) 3);
	cellD1.setCellValue("Request Raised by (OLM ID)");

	Cell cellAF1 = row.createCell((short) 4);
	cellAF1.setCellValue("Request Raised by (Name)");
	//cellStyle = workbook.createCellStyle();

	Cell cellE1 = row.createCell((short) 5);
	cellE1.setCellValue("Source LOB");

	Cell cellF1 = row.createCell((short) 6);
	cellF1.setCellValue("Source Circle Name");

	Cell cellG1 = row.createCell((short) 7);
	cellG1.setCellValue("Destination LOB");
			
	Cell cellH1 = row.createCell((short) 8);
	cellH1.setCellValue("Destination Circle Name");

	Cell cellI1 = row.createCell((short) 9);
	cellI1.setCellValue("UTR No / Cheque no");

	Cell cellJ1 = row.createCell((short) 10);
	cellJ1.setCellValue("Incoming Transaction Ref No/Source FX Account No");

	Cell cellK1 = row.createCell((short) 11);
	cellK1.setCellValue("Value date/Trans Date");

	Cell cellL1 = row.createCell((short) 12);
	cellL1.setCellValue("Actual Amount Received (Actual currency)/Receipt Amount");

	Cell cellM1 = row.createCell((short) 13);	           
	cellM1.setCellValue("Payment Exchange Rate");

	Cell cellN1 = row.createCell((short) 14);
	cellN1.setCellValue("Payment Currency");

	Cell cellO1 = row.createCell((short) 15);
	cellO1.setCellValue("Amount in INR/Receipt Amount");

	Cell cellP1 = row.createCell((short) 16);
	cellP1.setCellValue("Legal Entity of Receiving Airtel Bank Account no");

	Cell cellQ1 = row.createCell((short) 17);
	cellQ1.setCellValue("Receiving account received from RBI 2/Bank Account Number");

	Cell cellR1 = row.createCell((short) 18);
	cellR1.setCellValue("Receiving Name/Source FX Account Name");

	Cell cellS1 = row.createCell((short) 19);
	cellS1.setCellValue("Remitter Name");

	Cell cellT1 = row.createCell((short) 20);
	cellT1.setCellValue("Ref No/Deposit Circle");

	Cell cellU1 = row.createCell((short) 21);
	cellU1.setCellValue("Payment Details 1/Annotation");

	Cell cellV1 = row.createCell((short) 22);
	cellV1.setCellValue("Payment Details 2 /Bank Branch Name");

	Cell cellW1 = row.createCell((short) 23);
	cellW1.setCellValue("Target FX Account Number");

	Cell cellX1 = row.createCell((short) 24);
	cellX1.setCellValue("Company / Customer name in FX");

	Cell cellY1 = row.createCell((short) 25);
	cellY1.setCellValue("Invoice Number");

	Cell cellZ1 = row.createCell((short) 26);
	cellZ1.setCellValue("Invoice Allocation Amount");

	Cell cellAA1 = row.createCell((short) 27);
	cellAA1.setCellValue("TDS Amount (Invoice wise)");

	Cell cellAB1 = row.createCell((short) 28);
	cellAB1.setCellValue("TAN No");

	Cell cellAC1 = row.createCell((short) 29);
	cellAC1.setCellValue("Cheque Date");

	Cell cellAD1 = row.createCell((short) 30);
	cellAD1.setCellValue("Bank Name");

	Cell cellAE1 = row.createCell((short) 31);
	cellAE1.setCellValue("Remarks");
					
	if(resultsetdetails!=null){
		while (resultsetdetails.next()) {
			
			ProcessedAdviceFileDetails paDownloadObj=new ProcessedAdviceFileDetails();
			
			paDownloadObj.setPaymentMode(resultsetdetails.getString("PAYMENT_MODE"));
			paDownloadObj.setRequestID(Long.parseLong(resultsetdetails.getString("TICKET_NO")));
			paDownloadObj.setUploadedDate(resultsetdetails.getString("TICKET_DATE"));
			paDownloadObj.setUploadedName(resultsetdetails.getString("REQUEST_RAISED_BY"));
			paDownloadObj.setDestinationLOB(resultsetdetails.getString("DESTINATION_LOB"));
		if(resultsetdetails.getString("DESTINATION_LOB")!=null && resultsetdetails.getString("DESTINATION_LOB").equalsIgnoreCase("BTS")){
				paDownloadObj.setDestinationLOB("FL");
			}
			paDownloadObj.setSourceLOB(resultsetdetails.getString("SOURCE_LOB"));
			
			if(resultsetdetails.getString("SOURCE_LOB")!=null && resultsetdetails.getString("SOURCE_LOB").equalsIgnoreCase("BTS")){
				paDownloadObj.setSourceLOB("FL");
			}
			if(resultsetdetails.getString("SOURCE_LOB")==null){
				paDownloadObj.setSourceLOB("-");
			}
			paDownloadObj.setSourceCircle(resultsetdetails.getString("SOURCE_CIRCLE"));
			paDownloadObj.setDestinationCircle(resultsetdetails.getString("DESTINATION_CIRCLE"));
			paDownloadObj.setUtrNumber(resultsetdetails.getString("CHQ_NUMBER"));
			paDownloadObj.setPaymentReceivedDate(resultsetdetails.getDate("TRANS_DATE"));					
			paDownloadObj.setPaymentAmount(resultsetdetails.getDouble("RECEIPT_AMOUNT"));
			paDownloadObj.setNewExchangeRate(resultsetdetails.getDouble("PAYMENT_EXCHANGE_RATE"));
			paDownloadObj.setPaymentCurrency(resultsetdetails.getString("PAYMENT_CURRENCY"));
			paDownloadObj.setAmountInINR(resultsetdetails.getDouble("RECEIPT_AMOUNT_1"));
			paDownloadObj.setLegalEntity(resultsetdetails.getString("LEGAL_ENTITY"));
			paDownloadObj.setBankAccountNumber(resultsetdetails.getString("BANK_ACCOUNT_NO"));
			paDownloadObj.setRemitterName(resultsetdetails.getString("REMITTER_NAME"));
			paDownloadObj.setTargetFxAccountNumber(resultsetdetails.getString("TARGET_FX_ACCOUNT_NO"));
			paDownloadObj.setCustomerName(resultsetdetails.getString("CUSTOMER_NAME"));
			paDownloadObj.setInvoiceNumber(resultsetdetails.getString("INVOICE_NO"));
			paDownloadObj.setInvoiceAllocationAmount(resultsetdetails.getString("INVOICE_ALLOCATION_AMOUNT"));
			paDownloadObj.setTdsAmount(resultsetdetails.getDouble("TDS_AMOUNT"));
			paDownloadObj.setTanNumber(resultsetdetails.getString("TAN_NUMBER"));
			paDownloadObj.setChequeDate(resultsetdetails.getDate("CHEQUE_DATE"));
			paDownloadObj.setBankName(resultsetdetails.getString("BANK_NAME"));
			paDownloadObj.setRemarks(resultsetdetails.getString("REMARKS"));
			paDownloadObj.setUploadedOLMId(resultsetdetails.getString("VC_UPLOADED_USER_ID"));

			
			if(paymentMode.equalsIgnoreCase("CHEQUE")){
				paDownloadObj.setIncomingTransactionRefNumber(resultsetdetails.getString("SOURCE_FX_ACCOUNT_NO"));
				paDownloadObj.setReceiverName(resultsetdetails.getString("SOURCE_FX_ACCOUNT_NAME"));
				paDownloadObj.setRefNo(resultsetdetails.getString("DEPOSIT_CIRCLE"));
				paDownloadObj.setPaymentDetails1(resultsetdetails.getString("ANNOTATION"));
				paDownloadObj.setPaymentDetails2(resultsetdetails.getString("BANK_BRANCH_NAME"));
			}
			else if(paymentMode.equalsIgnoreCase("NEFT")){
				paDownloadObj.setIncomingTransactionRefNumber(resultsetdetails.getString("INCOMING_TRANSACTION_REF_NO"));
				paDownloadObj.setReceiverName(resultsetdetails.getString("RECEIVER_NAME"));
				paDownloadObj.setRefNo(resultsetdetails.getString("REF_NO"));
				paDownloadObj.setPaymentDetails1(resultsetdetails.getString("PAYMENT_DETAILS_1"));
				paDownloadObj.setPaymentDetails2(resultsetdetails.getString("PAYMENT_DETAILS_2"));
			}

			
			reportslogger.info("VC_UPLOADED_USER_ID" +resultsetdetails.getString("VC_UPLOADED_USER_ID"));
			row = worksheet.createRow(i);
				 
				 
				XSSFCell cellA2 = row.createCell((short) 0);
				cellA2.setCellValue(paDownloadObj.getPaymentMode());
				
				XSSFCell cellB2 = row.createCell((short) 1);
				cellB2.setCellValue(paDownloadObj.getRequestID());
				//worksheet.autoSizeColumn(1);

				
				XSSFCell cellC2 = row.createCell((short) 2);
				//cellC2.setCellValue(paDownloadObj.getUploadedDate());
				
				CreationHelper createHelper = workbook.getCreationHelper();
				cellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
				cellC2.setCellValue(paDownloadObj.getUploadedDate());
				cellC2.setCellStyle(cellStyle);
				//worksheet.autoSizeColumn(2);
				
				XSSFCell cellD2 = row.createCell((short) 3);
				cellD2.setCellValue(paDownloadObj.getUploadedOLMId());
				
				XSSFCell cellAF2 = row.createCell((short) 4);
				cellAF2.setCellValue(paDownloadObj.getUploadedName());
				
				XSSFCell cellE2 = row.createCell((short) 5);
				cellE2.setCellValue(paDownloadObj.getSourceLOB());
				
				XSSFCell cellF2 = row.createCell((short) 6);
				cellF2.setCellValue(paDownloadObj.getSourceCircle());

				XSSFCell cellG2 = row.createCell((short) 7);
				cellG2.setCellValue(paDownloadObj.getDestinationLOB());

				XSSFCell cellH2 = row.createCell((short) 8);
				cellH2.setCellValue(paDownloadObj.getDestinationCircle());
				
				XSSFCell cellI2 = row.createCell((short) 9);
				cellI2.setCellValue(paDownloadObj.getUtrNumber());
				
				XSSFCell cellJ2 = row.createCell((short) 10);
				cellJ2.setCellValue(paDownloadObj.getIncomingTransactionRefNumber());
				
				XSSFCell cellK2 = row.createCell((short) 11);
				//cellK2.setCellValue(paDownloadObj.getPaymentReceivedDate());
				
				CreationHelper createHelper10 = workbook.getCreationHelper();
				cellStyle.setDataFormat(createHelper10.createDataFormat().getFormat("MM/dd/yyyy"));
				cellK2.setCellValue(paDownloadObj.getPaymentReceivedDate());
				cellK2.setCellStyle(cellStyle);
				//worksheet.autoSizeColumn(10);

				XSSFCell cellL2 = row.createCell((short) 12);
				cellL2.setCellValue(paDownloadObj.getPaymentAmount());
							
				XSSFCell cellM2 = row.createCell((short) 13);
	             cellM2.setCellValue(paDownloadObj.getNewExchangeRate());
				
			    XSSFCell cellN2 = row.createCell((short) 14);
				cellN2.setCellValue(paDownloadObj.getPaymentCurrency());

				XSSFCell cellO2 = row.createCell((short) 15);
				cellO2.setCellValue(paDownloadObj.getAmountInINR());
													
				XSSFCell cellP2 = row.createCell((short) 16);
				cellP2.setCellValue(paDownloadObj.getLegalEntity());

				Cell cellQ2 = row.createCell((short) 17);
				cellQ2.setCellValue(paDownloadObj.getBankAccountNumber());
				
				Cell cellR2 = row.createCell((short) 18);
				cellR2.setCellValue(paDownloadObj.getReceiverName());
				
				Cell cellS2 = row.createCell((short) 19);
				cellS2.setCellValue(paDownloadObj.getRemitterName());
				
				Cell cellT2 = row.createCell((short) 20);
				cellT2.setCellValue(paDownloadObj.getRefNo());
				
				Cell cellU2 = row.createCell((short) 21);
				cellU2.setCellValue(paDownloadObj.getPaymentDetails1());
				
				Cell cellV2 = row.createCell((short) 22);
				cellV2.setCellValue(paDownloadObj.getPaymentDetails2());
				
				Cell cellW2 = row.createCell((short) 23);
				cellW2.setCellValue(paDownloadObj.getTargetFxAccountNumber());
				
				Cell cellX2 = row.createCell((short) 24);
				cellX2.setCellValue(paDownloadObj.getCustomerName());
				
				Cell cellY2 = row.createCell((short) 25);
				cellY2.setCellValue(paDownloadObj.getInvoiceNumber());
				
				Cell cellZ2 = row.createCell((short) 26);
				cellZ2.setCellValue(paDownloadObj.getInvoiceAllocationAmount());
				
				Cell cellAA2 = row.createCell((short) 27);
				cellAA2.setCellValue(paDownloadObj.getTdsAmount());
				
				Cell cellAB2 = row.createCell((short) 28);
				cellAB2.setCellValue(paDownloadObj.getTanNumber());
				
				Cell cellAC2 = row.createCell((short) 29);
				//cellAC2.setCellValue(paDownloadObj.getChequeDate());
				
				CreationHelper createHelper29 = workbook.getCreationHelper();
				cellStyle.setDataFormat(createHelper29.createDataFormat().getFormat("MM/dd/yyyy"));
			if(paDownloadObj.getChequeDate()!=null){
				cellAC2.setCellValue(paDownloadObj.getChequeDate());
			}
			else{
				cellAC2.setCellValue("NA");
			}
				cellAC2.setCellStyle(cellStyle);
				//worksheet.autoSizeColumn(28);
				
				Cell cellAD2 = row.createCell((short) 30);
				cellAD2.setCellValue(paDownloadObj.getBankName());
				
				Cell cellAE2 = row.createCell((short) 31);
				cellAE2.setCellValue(paDownloadObj.getRemarks());
				//logger.info("i value" +i);
				i++;
				//logger.info("i++ value" +i);

			
			}
		
		
	       	for(int j=0;j<30;j++){
	     		worksheet.autoSizeColumn(j);
		             }  
	       	
	        try {
				workbook.write(downloadFile);
				    downloadFile.flush();
				    downloadFile.close();
			} catch (IOException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
				return null;
			}	
		
	     }		  
		    
	}//try
	catch (FileNotFoundException e) {
		  StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;

	}
	catch (Exception e) {
		  StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
			return null;
	}
 }

	    finally{
			
			if(callableStatement!=null){
			try {
				callableStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
			}
		}
			
			if(resultsetdetails!=null){
				try {
					resultsetdetails.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
				}
			}
			
			if(connection!=null){
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
				}
			}
			
			
	}
		

	return paymentAdvicedownloadObj;


	}	
   
   
}
