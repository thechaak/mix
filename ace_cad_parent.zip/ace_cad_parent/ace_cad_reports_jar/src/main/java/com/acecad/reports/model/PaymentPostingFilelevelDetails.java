package com.acecad.reports.model;
import java.sql.Date;

public class PaymentPostingFilelevelDetails {
	public String fromDate;
	public String toDate;
	private int inProgressRecords;
	private String inProgressValue;
	private int rejectedRecords;
	private String RejectedValue;
	public String getValueDeletedAtLiu() {
		return valueDeletedAtLiu;
	}

	public String getInProgressValue() {
		return inProgressValue;
	}

	public void setInProgressValue(String inProgressValue) {
		this.inProgressValue = inProgressValue;
	}

	public int getRejectedRecords() {
		return rejectedRecords;
	}

	public void setRejectedRecords(int rejectedRecords) {
		this.rejectedRecords = rejectedRecords;
	}

	public String getRejectedValue() {
		return RejectedValue;
	}

	public void setRejectedValue(String rejectedValue) {
		RejectedValue = rejectedValue;
	}

	public void setValueDeletedAtLiu(String valueDeletedAtLiu) {
		this.valueDeletedAtLiu = valueDeletedAtLiu;
	}
	private String valueDeletedAtLiu;
	public int getInProgressRecords() {
		return inProgressRecords;
	}

	public void setInProgressRecords(int inProgressRecords) {
		this.inProgressRecords = inProgressRecords;
	}
	private String approvedBy;
	private String approvedDate;
	private int liuDeleted;
	private String liuPending;
	public String getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	public String getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(String approvedDate) {
		this.approvedDate = approvedDate;
	}

	public int getLiuDeleted() {
		return liuDeleted;
	}

	public void setLiuDeleted(int liuDeleted) {
		this.liuDeleted = liuDeleted;
	}

	public String getLiuPending() {
		return liuPending;
	}

	public void setLiuPending(String liuPending) {
		this.liuPending = liuPending;
	}
	public String uploadedDate;
	public String getUploadedDate() {
		return uploadedDate;
	}

	public void setUploadedDate(String uploadedDate) {
		this.uploadedDate = uploadedDate;
	}
	public String statusMsg;
	public String getFromDate() {
		return fromDate;
	}
	
	public String getStatusMsg() {
		return statusMsg;
	}

	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String parentUserId;
	public String childUserId;
	public String vendorId;
	public String vendorName;
	public String userCircle;
	public String fileName;
	public String mode;
	public String status;
	public String fileId;
	public int totalRecords;
	public String totalValue;
	public String valuePostedToFx;
	public String valuePendingAtLiu;
	public int recordsPostedToFx;
	public int recordsPendingAtLiu;
	
	
	
	public String getParentUserId() {
		return parentUserId;
	}

	public void setParentUserId(String parentUserId) {
		this.parentUserId = parentUserId;
	}

	public String getChildUserId() {
		return childUserId;
	}

	public void setChildUserId(String childUserId) {
		this.childUserId = childUserId;
	}

	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getUserCircle() {
		return userCircle;
	}
	public void setUserCircle(String userCircle) {
		this.userCircle = userCircle;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public int getTotalRecords() {
		return totalRecords;
	}
	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}
	public String getTotalValue() {
		return totalValue;
	}
	public void setTotalValue(String totalValue) {
		this.totalValue = totalValue;
	}
	public String getValuePostedToFx() {
		return valuePostedToFx;
	}
	public void setValuePostedToFx(String valuePostedToFx) {
		this.valuePostedToFx = valuePostedToFx;
	}
	public String getValuePendingAtLiu() {
		return valuePendingAtLiu;
	}
	public void setValuePendingAtLiu(String valuePendingAtLiu) {
		this.valuePendingAtLiu = valuePendingAtLiu;
	}
	public int getRecordsPostedToFx() {
		return recordsPostedToFx;
	}
	public void setRecordsPostedToFx(int recordsPostedToFx) {
		this.recordsPostedToFx = recordsPostedToFx;
	}
	public int getRecordsPendingAtLiu() {
		return recordsPendingAtLiu;
	}
	public void setRecordsPendingAtLiu(int recordsPendingAtLiu) {
		this.recordsPendingAtLiu = recordsPendingAtLiu;
	}
	
}
