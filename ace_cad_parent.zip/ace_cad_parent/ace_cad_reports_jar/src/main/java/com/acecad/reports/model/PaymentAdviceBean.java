package com.acecad.reports.model;

import java.sql.Date;

public class PaymentAdviceBean {
	
	
	private String lob;
	private String utrNum;
	private String airtelBankAcctNum;
	private String vendorName;
	private String userOlmId;
	private String fileName;
	private String paymentMode;
	private long requestId;
	private String requestStatus;
	private long numOfAcctsPosted;
	private long numOfInvoicesPosted;
	private String valueOfEftPayment;
	private String requestRaisedTime;
	private String postingDate;
	private String fileUploadDate;
	private String requestRaisedDate;
	private String bankCreditRcrdDate;
	private String postingTime;
	private String creditDateVsRequestDate;
	private String requestDateVsPostedDate;
	private String creditDateVsPostedDate;
    
	private String sourceTrackingId;
	private String targetFxAcctNum;
	private String invoiceNumber;
	private String invoiceAllocationAmt;
	private String paymentExchangeRate;
	private String tdsAmount_Invoicewise;
	private String tanNo;
	private String remarks;
	private String uploadedBy;
	private String uploadedByName;
	private String uploadTime;
	private String ticketId;
	private String approvedBy;
	private String approvedByName;
	private String approvalTime;
	private String status;
	private String fxUpdateTime;
	private String reasonForFailure;
	private String fromDate;
	private String toDate;
	private String tktNo;
	private String process;
	private String custBankAcctNum;
	private String errorMsg;
	private String errorCode;
	private String finalExchangeRate;
	private String paymentDate;
	private String paymentRequestId;
	private String fxPostingStatus;
	private String fxPostingErrorDescription;
	private String roleName;
	private String utrLevelStatus;
	private String comments;
	private String sourceTrackingIdServ;
	private String rejectionRemarks;
	private String rejectedReason;
	private String destinationTrackingId;
	private String destinationTrackingIdServ;
	private String destinationLob;
	private String allowDownload;
	//NEW ADDED
	private String sourceCircle;
	private String sourceLob;
	private String destinationCircle;
	private String incTransRefNumber;
	private String transDate;
	private String receiptAmount;
	private String paymentCurrency;
	private String legalEntity;
	
	private String receiverName;
	private String remitterName;
	private String refNum;
	private String paymentDetails1;
	private String paymentDetails2;
	
	private String custName;
	private String chequeDate;
	private String bankName;
	private String targetLob;
	private String statusDescription;
	
	private String errorReasonCode;
	
	
	private String cadRecievedTime;
	private String derivedB2bB2c;
	
	private String adviceExemption;
	//END
	private String accountType;
	private String RecordType;
	private String recordId;
	
	private String dummyCurrency;
	private String fundCurrency;
	
	

	public String getDummyCurrency() {
		return dummyCurrency;
	}


	public void setDummyCurrency(String dummyCurrency) {
		this.dummyCurrency = dummyCurrency;
	}


	public String getFundCurrency() {
		return fundCurrency;
	}


	public void setFundCurrency(String fundCurrency) {
		this.fundCurrency = fundCurrency;
	}


	public String getRecordId() {
		return recordId;
	}


	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}


	public String getAccountType() {
		return accountType;
	}


	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}


	public String getRecordType() {
		return RecordType;
	}


	public void setRecordType(String recordType) {
		RecordType = recordType;
	}


	public String getTransDate() {
		return transDate;
	}
	
	
	public String getCadRecievedTime() {
		return cadRecievedTime;
	}


	public void setCadRecievedTime(String cadRecievedTime) {
		this.cadRecievedTime = cadRecievedTime;
	}


	public String getDerivedB2bB2c() {
		return derivedB2bB2c;
	}


	public void setDerivedB2bB2c(String derivedB2bB2c) {
		this.derivedB2bB2c = derivedB2bB2c;
	}


	public String getAdviceExemption() {
		return adviceExemption;
	}


	public void setAdviceExemption(String adviceExemption) {
		this.adviceExemption = adviceExemption;
	}


	public String getErrorReasonCode() {
		return errorReasonCode;
	}

	public void setErrorReasonCode(String errorReasonCode) {
		this.errorReasonCode = errorReasonCode;
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

	public String getTargetLob() {
		return targetLob;
	}

	public void setTargetLob(String targetLob) {
		this.targetLob = targetLob;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getChequeDate() {
		return chequeDate;
	}

	public void setChequeDate(String chequeDate) {
		this.chequeDate = chequeDate;
	}

	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getPaymentDetails1() {
		return paymentDetails1;
	}
	public void setPaymentDetails1(String paymentDetails1) {
		this.paymentDetails1 = paymentDetails1;
	}
	public String getPaymentDetails2() {
		return paymentDetails2;
	}
	public void setPaymentDetails2(String paymentDetails2) {
		this.paymentDetails2 = paymentDetails2;
	}
	public String getRefNum() {
		return refNum;
	}
	public void setRefNum(String refNum) {
		this.refNum = refNum;
	}
	public String getReceiverName() {
		return receiverName;
	}
	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}
	public String getRemitterName() {
		return remitterName;
	}
	public void setRemitterName(String remitterName) {
		this.remitterName = remitterName;
	}
	public String getLegalEntity() {
		return legalEntity;
	}
	public void setLegalEntity(String legalEntity) {
		this.legalEntity = legalEntity;
	}
	public String getPaymentCurrency() {
		return paymentCurrency;
	}
	public void setPaymentCurrency(String paymentCurrency) {
		this.paymentCurrency = paymentCurrency;
	}
	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}
	public String getReceiptAmount() {
		return receiptAmount;
	}
	public void setReceiptAmount(String receiptAmount) {
		this.receiptAmount = receiptAmount;
	}
	public String getDestinationCircle() {
		return destinationCircle;
	}
	public String getIncTransRefNumber() {
		return incTransRefNumber;
	}
	public void setIncTransRefNumber(String incTransRefNumber) {
		this.incTransRefNumber = incTransRefNumber;
	}
	public void setDestinationCircle(String destinationCircle) {
		this.destinationCircle = destinationCircle;
	}
	public String getDestinationTrackingId() {
		return destinationTrackingId;
	}
	public String getSourceCircle() {
		return sourceCircle;
	}
	public void setSourceCircle(String sourceCircle) {
		this.sourceCircle = sourceCircle;
	}
	public String getSourceLob() {
		return sourceLob;
	}
	public void setSourceLob(String sourceLob) {
		this.sourceLob = sourceLob;
	}
	public void setDestinationTrackingId(String destinationTrackingId) {
		this.destinationTrackingId = destinationTrackingId;
	}
	public String getDestinationTrackingIdServ() {
		return destinationTrackingIdServ;
	}
	public void setDestinationTrackingIdServ(String destinationTrackingIdServ) {
		this.destinationTrackingIdServ = destinationTrackingIdServ;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getUtrNum() {
		return utrNum;
	}
	public void setUtrNum(String utrNum) {
		this.utrNum = utrNum;
	}
	public String getAirtelBankAcctNum() {
		return airtelBankAcctNum;
	}
	public void setAirtelBankAcctNum(String airtelBankAcctNum) {
		this.airtelBankAcctNum = airtelBankAcctNum;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getUserOlmId() {
		return userOlmId;
	}
	public void setUserOlmId(String userOlmId) {
		this.userOlmId = userOlmId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	public long getNumOfAcctsPosted() {
		return numOfAcctsPosted;
	}
	public void setNumOfAcctsPosted(long numOfAcctsPosted) {
		this.numOfAcctsPosted = numOfAcctsPosted;
	}
	public long getNumOfInvoicesPosted() {
		return numOfInvoicesPosted;
	}
	public void setNumOfInvoicesPosted(long numOfInvoicesPosted) {
		this.numOfInvoicesPosted = numOfInvoicesPosted;
	}
	public String getValueOfEftPayment() {
		return valueOfEftPayment;
	}
	public void setValueOfEftPayment(String valueOfEftPayment) {
		this.valueOfEftPayment = valueOfEftPayment;
	}
	public String getRequestRaisedTime() {
		return requestRaisedTime;
	}
	public void setRequestRaisedTime(String requestRaisedTime) {
		this.requestRaisedTime = requestRaisedTime;
	}
	public String getPostingDate() {
		return postingDate;
	}
	public void setPostingDate(String postingDate) {
		this.postingDate = postingDate;
	}
	public String getFileUploadDate() {
		return fileUploadDate;
	}
	public void setFileUploadDate(String fileUploadDate) {
		this.fileUploadDate = fileUploadDate;
	}
	public String getRequestRaisedDate() {
		return requestRaisedDate;
	}
	public void setRequestRaisedDate(String requestRaisedDate) {
		this.requestRaisedDate = requestRaisedDate;
	}
	public String getBankCreditRcrdDate() {
		return bankCreditRcrdDate;
	}
	public void setBankCreditRcrdDate(String bankCreditRcrdDate) {
		this.bankCreditRcrdDate = bankCreditRcrdDate;
	}
	public String getPostingTime() {
		return postingTime;
	}
	public void setPostingTime(String postingTime) {
		this.postingTime = postingTime;
	}
	public String getCreditDateVsRequestDate() {
		return creditDateVsRequestDate;
	}
	public void setCreditDateVsRequestDate(String creditDateVsRequestDate) {
		this.creditDateVsRequestDate = creditDateVsRequestDate;
	}
	public String getRequestDateVsPostedDate() {
		return requestDateVsPostedDate;
	}
	public void setRequestDateVsPostedDate(String requestDateVsPostedDate) {
		this.requestDateVsPostedDate = requestDateVsPostedDate;
	}
	public String getCreditDateVsPostedDate() {
		return creditDateVsPostedDate;
	}
	public void setCreditDateVsPostedDate(String creditDateVsPostedDate) {
		this.creditDateVsPostedDate = creditDateVsPostedDate;
	}

	
	public String getTargetFxAcctNum() {
		return targetFxAcctNum;
	}
	public void setTargetFxAcctNum(String targetFxAcctNum) {
		this.targetFxAcctNum = targetFxAcctNum;
	}
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public String getInvoiceAllocationAmt() {
		return invoiceAllocationAmt;
	}
	public void setInvoiceAllocationAmt(String invoiceAllocationAmt) {
		this.invoiceAllocationAmt = invoiceAllocationAmt;
	}
	public String getPaymentExchangeRate() {
		return paymentExchangeRate;
	}
	public void setPaymentExchangeRate(String paymentExchangeRate) {
		this.paymentExchangeRate = paymentExchangeRate;
	}
	public String getTdsAmount_Invoicewise() {
		return tdsAmount_Invoicewise;
	}
	public void setTdsAmount_Invoicewise(String tdsAmount_Invoicewise) {
		this.tdsAmount_Invoicewise = tdsAmount_Invoicewise;
	}
	public String getTanNo() {
		return tanNo;
	}
	public void setTanNo(String tanNo) {
		this.tanNo = tanNo;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getUploadedBy() {
		return uploadedBy;
	}
	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}
	public String getUploadedByName() {
		return uploadedByName;
	}
	public void setUploadedByName(String uploadedByName) {
		this.uploadedByName = uploadedByName;
	}
	public String getUploadTime() {
		return uploadTime;
	}
	public void setUploadTime(String uploadTime) {
		this.uploadTime = uploadTime;
	}
	public String getTicketId() {
		return ticketId;
	}
	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;
	}
	public String getApprovedBy() {
		return approvedBy;
	}
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}
	public String getApprovedByName() {
		return approvedByName;
	}
	public void setApprovedByName(String approvedByName) {
		this.approvedByName = approvedByName;
	}
	public String getApprovalTime() {
		return approvalTime;
	}
	public void setApprovalTime(String approvalTime) {
		this.approvalTime = approvalTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getFxUpdateTime() {
		return fxUpdateTime;
	}
	public void setFxUpdateTime(String fxUpdateTime) {
		this.fxUpdateTime = fxUpdateTime;
	}
	public String getReasonForFailure() {
		return reasonForFailure;
	}
	public void setReasonForFailure(String reasonForFailure) {
		this.reasonForFailure = reasonForFailure;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getTktNo() {
		return tktNo;
	}
	public void setTktNo(String tktNo) {
		this.tktNo = tktNo;
	}
	public String getProcess() {
		return process;
	}
	public void setProcess(String process) {
		this.process = process;
	}
	public String getCustBankAcctNum() {
		return custBankAcctNum;
	}
	public void setCustBankAcctNum(String custBankAcctNum) {
		this.custBankAcctNum = custBankAcctNum;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getFinalExchangeRate() {
		return finalExchangeRate;
	}
	public void setFinalExchangeRate(String finalExchangeRate) {
		this.finalExchangeRate = finalExchangeRate;
	}
	public String getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}
	public String getPaymentRequestId() {
		return paymentRequestId;
	}
	public void setPaymentRequestId(String paymentRequestId) {
		this.paymentRequestId = paymentRequestId;
	}
	public String getFxPostingStatus() {
		return fxPostingStatus;
	}
	public void setFxPostingStatus(String fxPostingStatus) {
		this.fxPostingStatus = fxPostingStatus;
	}
	public String getFxPostingErrorDescription() {
		return fxPostingErrorDescription;
	}
	public void setFxPostingErrorDescription(String fxPostingErrorDescription) {
		this.fxPostingErrorDescription = fxPostingErrorDescription;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getUtrLevelStatus() {
		return utrLevelStatus;
	}
	public void setUtrLevelStatus(String utrLevelStatus) {
		this.utrLevelStatus = utrLevelStatus;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	public String getRejectedReason() {
		return rejectedReason;
	}
	public void setRejectedReason(String rejectedReason) {
		this.rejectedReason = rejectedReason;
	}
	public String getRejectionRemarks() {
		return rejectionRemarks;
	}
	public void setRejectionRemarks(String rejectionRemarks) {
		this.rejectionRemarks = rejectionRemarks;
	}
	public String getSourceTrackingIdServ() {
		return sourceTrackingIdServ;
	}
	public void setSourceTrackingIdServ(String sourceTrackingIdServ) {
		this.sourceTrackingIdServ = sourceTrackingIdServ;
	}
	public String getSourceTrackingId() {
		return sourceTrackingId;
	}
	public void setSourceTrackingId(String sourceTrackingId) {
		this.sourceTrackingId = sourceTrackingId;
	}
	public String getDestinationLob() {
		return destinationLob;
	}
	public void setDestinationLob(String destinationLob) {
		this.destinationLob = destinationLob;
	}

	public String getAllowDownload() {
		return allowDownload;
	}
	public void setAllowDownload(String allowDownload) {
		this.allowDownload = allowDownload;
	}
	
	}
