package com.acecad.reports.model;

public class PayRevChequeBounceDetailsDownload {
	private String refNo;
	private String status;
	private String bankAccNo;
	public String getStatus() {
		return status;
	}
	public String getBankAccNo() {
		return bankAccNo;
	}
	public void setBankAccNo(String bankAccNo) {
		this.bankAccNo = bankAccNo;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	private String reasonForFailure;
	public String getReasonForFailure() {
		return reasonForFailure;
	}
	public void setReasonForFailure(String reasonForFailure) {
		this.reasonForFailure = reasonForFailure;
	}
	private String uploadedUser;
	private String fileId;
	private String fileName;
	private String vendorId;
	private String toDate;
	private String fromDate;
	private String vendorName;
	private String lob;
	private String bankName;
	private String dateonChq;
	private int noOfAccPostedFx;
	private int noOfInvPostedFx;
	public int getNoOfInvPostedFx() {
		return noOfInvPostedFx;
	}
	public void setNoOfInvPostedFx(int noOfInvPostedFx) {
		this.noOfInvPostedFx = noOfInvPostedFx;
	}
	private String totChqVal;
	private String initialUploadedDate;
	public String getUploadedUser() {
		return uploadedUser;
	}
	public void setUploadedUser(String uploadedUser) {
		this.uploadedUser = uploadedUser;
	}
	public String getInitialUploadedDate() {
		return initialUploadedDate;
	}
	public String getBouncedDate() {
		return bouncedDate;
	}
	public String getBounceMisDate() {
		return bounceMisDate;
	}
	private String initialPostedDate;
	private String bouncedDate;
	private String bounceMisDate;
	private String RevPostingFxDate;
	private int diffInitalVsBouncedDate;
	private int diffBouncedVsBouncdMisDate;
	private int diffBouncedVspostingRevDate;
	private int diffBounceMisDateVspostingRevDate;
	private int Role;
	private String statusMsg;



	public String getInitialPostedDate() {
		return initialPostedDate;
	}
	public void setInitialPostedDate(String initialPostedDate) {
		this.initialPostedDate = initialPostedDate;
	}
	public String getRevPostingFxDate() {
		return RevPostingFxDate;
	}
	public void setRevPostingFxDate(String revPostingFxDate) {
		RevPostingFxDate = revPostingFxDate;
	}
	public void setInitialUploadedDate(String initialUploadedDate) {
		this.initialUploadedDate = initialUploadedDate;
	}
	public void setBouncedDate(String bouncedDate) {
		this.bouncedDate = bouncedDate;
	}
	public void setBounceMisDate(String bounceMisDate) {
		this.bounceMisDate = bounceMisDate;
	}
	public String getStatusMsg() {
		return statusMsg;
	}
	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}
	
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getDateonChq() {
		return dateonChq;
	}
	public void setDateonChq(String dateonChq) {
		this.dateonChq = dateonChq;
	}
	public int getNoOfAccPostedFx() {
		return noOfAccPostedFx;
	}
	public void setNoOfAccPostedFx(int noOfAccPostedFx) {
		this.noOfAccPostedFx = noOfAccPostedFx;
	}

	public String getTotChqVal() {
		return totChqVal;
	}
	public void setTotChqVal(String totChqVal) {
		this.totChqVal = totChqVal;
	}


	public int getDiffInitalVsBouncedDate() {
		return diffInitalVsBouncedDate;
	}
	public void setDiffInitalVsBouncedDate(int diffInitalVsBouncedDate) {
		this.diffInitalVsBouncedDate = diffInitalVsBouncedDate;
	}
	public int getDiffBouncedVsBouncdMisDate() {
		return diffBouncedVsBouncdMisDate;
	}
	public void setDiffBouncedVsBouncdMisDate(int diffBouncedVsBouncsMisDate) {
		this.diffBouncedVsBouncdMisDate = diffBouncedVsBouncsMisDate;
	}
	public int getDiffBouncedVspostingRevDate() {
		return diffBouncedVspostingRevDate;
	}
	public void setDiffBouncedVspostingRevDate(int diffBouncedVspostingRevDate) {
		this.diffBouncedVspostingRevDate = diffBouncedVspostingRevDate;
	}
	public int getDiffBounceMisDateVspostingRevDate() {
		return diffBounceMisDateVspostingRevDate;
	}
	public void setDiffBounceMisDateVspostingRevDate(
			int diffBounceMisDateVspostingRevDate) {
		this.diffBounceMisDateVspostingRevDate = diffBounceMisDateVspostingRevDate;
	}
	public int getRole() {
		return Role;
	}
	public void setRole(int role) {
		Role = role;
	}

}