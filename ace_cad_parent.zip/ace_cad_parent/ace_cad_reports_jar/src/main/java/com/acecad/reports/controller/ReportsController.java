package com.acecad.reports.controller;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.acecad.reports.dao.PaymentAdviceDao;
import com.acecad.reports.dao.PaymentICRMDao;
import com.acecad.reports.dao.ReportsDao;
import com.acecad.reports.model.ActivityLogDetails;
import com.acecad.reports.model.PayPostingChequeDetails;
import com.acecad.reports.model.PayPostingTransLevelDetails;
import com.acecad.reports.model.PayPostingVendorDetails;
import com.acecad.reports.model.PayRevChequeBounceDetailsDownload;
import com.acecad.reports.model.PayRevChqBounceRecordsDetails;
import com.acecad.reports.model.PayRevDirectTransRecordsDownload;
import com.acecad.reports.model.PayTransferFileLevelDetails;
import com.acecad.reports.model.PaymentAdviceBean;
import com.acecad.reports.model.PaymentDirectReversalBean;
import com.acecad.reports.model.PaymentICRMBean;
import com.acecad.reports.model.PaymentPostingFilelevelDetails;
import com.acecad.reports.model.PaymentPostingModewiseBean;
import com.acecad.reports.model.PaymentPostingTransLevelDetailsDownload;
import com.acecad.reports.model.PaymentReversalFileLevelBean;
import com.acecad.reports.model.PaymentTransferTransLevelBean;
import com.acecad.reports.model.ProcessedAdviceFileDetails;
import com.acecad.reports.model.UserManagementUserLevel;
import com.acecad.reports.model.VendorUserReportBean;



@Controller
public class ReportsController {
	private static Logger reportslogger = LogManager
			.getLogger("reportsLogger");
	String extension="xlsx";
	@Autowired
	ReportsDao ReportsDaoObj;

	@Autowired
	PaymentAdviceDao paymentAdviceDaoObj;

	@Autowired
	PaymentICRMDao paymentIcrmDaoObj;

	HttpSession session;
	//PaymentICRMBean paymentIcrmBeanObj=new PaymentICRMBean();
	//VendorUserReportBean VendorUserReportBeanObj=new VendorUserReportBean();
	//UserManagementUserLevel UserManagementUserLevelObj=new UserManagementUserLevel();
	//PaymentTransferTransLevelBean PayTransferTransLevelBeanObj=new PaymentTransferTransLevelBean();
	//ActivityLogDetails ActivityLogDetailsObj=new ActivityLogDetails();
	//PayTransferFileLevelDetails pymntTransFileLevelDetailsObj=new PayTransferFileLevelDetails();
	//PaymentPostingFilelevelDetails payPostingFilelevelDetailsObj = new PaymentPostingFilelevelDetails();
	//PaymentPostingModewiseBean PayPostingModewiseSumBeanObj = new PaymentPostingModewiseBean();
	//PaymentReversalFileLevelBean PayReversalFileLevelBeanObj = new PaymentReversalFileLevelBean();
	//PayPostingTransLevelDetails PayPostingTransLevelDetailsObj = new PayPostingTransLevelDetails();
	//PayPostingVendorDetails PayPostingVendorDetailsObj = new PayPostingVendorDetails();
	//PayPostingChequeDetails PyPostChequeDetailsObj = new PayPostingChequeDetails();
	//PayRevChqBounceRecordsDetails PayRevChqBounceRecordsDetailsObj = new PayRevChqBounceRecordsDetails();
	//PaymentDirectReversalBean PayDirectReversalBeanObj = new PaymentDirectReversalBean();
	//	int Role;
	private String suspenseFile=System.getenv("ACE_CAD_HOME")
			+File.separator+"UPLOADED_FILES"+File.separator+"SuspenseAllocation";

	private String paymentTransferFile=System.getenv("ACE_CAD_HOME")
			+File.separator+"UPLOADED_FILES"+File.separator+"PaymentTransfer";
    
	private String aesChequeWorkflowFile=System.getenv("ACE_CAD_HOME")
			+File.separator+"UPLOADED_FILES"+File.separator+"AESChequeAllocation";
	private String TDS_File=System.getenv("ACE_CAD_HOME");//tds file path
	
	private String uploadWavierFiles = System.getenv("ACE_CAD_HOME")+File.separator+"Wavier_Files"+File.separator+"Input files";
	private String uploadSupportFiles = System.getenv("ACE_CAD_HOME")+File.separator+"Wavier_Files"+File.separator+"Support Files";
	
	@Value("${PAYMENT_ADVICE_HOME}")
	private String paymentAdviceRequestDownloadPath;
	/** PAYMENT POSTING FILE LEVEL **/

	/*@RequestMapping(value = "/paymentPostingFileLevel")
	public ModelAndView paymentPostingFilelevelHome() {
		reportslogger.info("In payment Posting file level controller");
		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("PayPostingFileLevelLogin");
		return modelAndViewObj;
	}
	 */


	@RequestMapping(value = "/payPostingFilelevelRole", method = RequestMethod.GET)
	public ModelAndView paymentPostingFileLevelRole(HttpServletRequest request,HttpServletResponse response) 
	{
		//PaymentPostingFilelevelDetails payPostingFilelevelDetailsObj1 = new PaymentPostingFilelevelDetails();

		session=request.getSession(false);
		ModelAndView modelAndViewObj = new ModelAndView();

		PaymentPostingFilelevelDetails payPostingFilelevelDetailsObj = new PaymentPostingFilelevelDetails();

		reportslogger.info("In payment Posting file level controller");
		//reportslogger.info("in controller to get role.");
		//String parentUserId = request.getParameter("parentUserId");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in payPostingFilelevelRole mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);

		//	Role = ReportsDaoObj.getRole(parentUserId);
		reportslogger.info("User Role: " + Role);

		/*if(Role==-1)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues");
			modelAndViewObj.setViewName("PayPostingFileLevelSearch");
			return modelAndViewObj;
		}
		 */

		if (Role == 1 || Role == 2 || Role == 3 || Role == 4 || Role == 7) {

			payPostingFilelevelDetailsObj.setParentUserId(parentUserId);
			payPostingFilelevelDetailsObj.setChildUserId(null);
			payPostingFilelevelDetailsObj.setVendorId(null);
			payPostingFilelevelDetailsObj.setFileId(null);
			payPostingFilelevelDetailsObj.setFileName(null);
			payPostingFilelevelDetailsObj.setToDate(null);
			payPostingFilelevelDetailsObj.setFromDate(null);
			payPostingFilelevelDetailsObj.setMode(null);
			List<String> modeList = ReportsDaoObj.returnModeList();
			if(modeList==null)
			{
				modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("role", Role);
				modelAndViewObj.setViewName("PayPostingFileLevelSearch");
				return modelAndViewObj;
			}
			reportslogger.info("Modes List size in Controller: "+modeList.size());
			modelAndViewObj.addObject("modeList", modeList);

			HashMap<Integer, List<PaymentPostingFilelevelDetails>> completeDetailsMap = new HashMap<Integer, List<PaymentPostingFilelevelDetails>>();
			int page = 1;
			String statusMsg = null;

			completeDetailsMap = ReportsDaoObj.getPayPostingFilelevelDetails(
					payPostingFilelevelDetailsObj, page);


			if(completeDetailsMap==null)
			{
				modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("role", Role);
				modelAndViewObj.setViewName("PayPostingFileLevelSearch");
				return modelAndViewObj;
			}

			//	session.setAttribute("PaymentPostingFileLevelFilter", payPostingFilelevelDetailsObj1);

			reportslogger.info(" Details Map Size in Controller: "+completeDetailsMap.size() );



			if(payPostingFilelevelDetailsObj.getStatusMsg()!=null)
			{

				if(payPostingFilelevelDetailsObj.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
				{
					statusMsg="";
				}

				else
				{
					statusMsg=payPostingFilelevelDetailsObj.getStatusMsg();
				}

			}
			else
				statusMsg="Connectivity Issues..Retry..";

			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.addObject("statusMsg", statusMsg);
			modelAndViewObj.addObject("detailsMap", completeDetailsMap);
			modelAndViewObj.addObject("payPostingFilelevelDetailsObjJsp",payPostingFilelevelDetailsObj);
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.setViewName("PayPostingFileLevelSearch");
			return modelAndViewObj;
		}

		else
			reportslogger.info("you do not have privilage to view this page!");

		modelAndViewObj.addObject("statusMsg",
				"You do not have privilige to View Reports !!");
		modelAndViewObj.setViewName("PayPostingFileLevelSearch");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/payPostingFilelevelSelectTracking")
	public ModelAndView paymentPostingFileLevelDetails(HttpServletRequest request, HttpServletResponse response)
	{
		//PaymentPostingFilelevelDetails payPostingFilelevelDetailsObj = (PaymentPostingFilelevelDetails)session.getAttribute("PaymentPostingFileLevelFilter");

		//PaymentPostingFilelevelDetails payPostingFilelevelDetailsObj = new PaymentPostingFilelevelDetails();

		/*String myObjectId = request.getParameter("PaymentPostingFileLevelFilter");


		reportslogger.info("object is:"+request.getSession().getAttribute(myObjectId));
		PaymentPostingFilelevelDetails payPostingFilelevelDetailsObj = (PaymentPostingFilelevelDetails)request.getSession().getAttribute(myObjectId);*/

		PaymentPostingFilelevelDetails payPostingFilelevelDetailsObjSearch = new PaymentPostingFilelevelDetails();

		session=request.getSession(false);
		reportslogger.info("In Payment Posting File level Search");
		ModelAndView modelAndViewObj = new ModelAndView();
		//String childUserId=session.getAttribute("userid").toString();
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		payPostingFilelevelDetailsObjSearch.setParentUserId(parentUserId);

		//reportslogger.info("    payPostingFilelevelDetailsObj.getParentUserId()"+		payPostingFilelevelDetailsObj.getParentUserId());
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in payPostingFilelevelSelectTracking mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		String filedId = request.getParameter("fileid");
		String fromDate = request.getParameter("startDate");

		String toDate = request.getParameter("endDate");
		//reportslogger.info("toDate is" + toDate);
		String fileName = request.getParameter("fileName");
		String mode = request.getParameter("mode");
		String vendorID = request.getParameter("vendorid");
		String childUserId = request.getParameter("childUserid");
		reportslogger.info("File ID: "+filedId);
		reportslogger.info("From Date: "+fromDate);
		reportslogger.info("To Date: "+toDate);
		reportslogger.info("File Name: "+fileName);
		reportslogger.info("Mode: "+mode);
		reportslogger.info("Vendor ID: "+vendorID);
		reportslogger.info("User ID: "+childUserId);
		//reportslogger.info("User ID: "+childUserId);


		if (fromDate != "") {

			payPostingFilelevelDetailsObjSearch.setFromDate(fromDate);
		} else
			payPostingFilelevelDetailsObjSearch.setFromDate(null);

		//reportslogger.info("fromdate:"+ payPostingFilelevelDetailsObj.getFromDate());

		if (toDate != "") {
			payPostingFilelevelDetailsObjSearch.setToDate(toDate);
		} else {
			payPostingFilelevelDetailsObjSearch.setToDate(null);
		}

		//reportslogger.info("todate:"+ payPostingFilelevelDetailsObj.getToDate());


		//reportslogger.info("file id " + filedId);

		if (filedId == null || filedId.equals("")) {
			//reportslogger.info("enterded if set to 0");
			payPostingFilelevelDetailsObjSearch.setFileId(null);

		} else {
			//reportslogger.info("enterded else");
			payPostingFilelevelDetailsObjSearch.setFileId(filedId.trim());
			//reportslogger.info("file id is"+payPostingFilelevelDetailsObj.getFileId());
		}
		//reportslogger.info("file id"+ payPostingFilelevelDetailsObj.getFileId());


		if (fileName == null || fileName.equals("")) {

			payPostingFilelevelDetailsObjSearch.setFileName(null);

		} else {
			//reportslogger.info("enterded else");
			payPostingFilelevelDetailsObjSearch.setFileName(fileName.trim());
		}

		//reportslogger.info("mode in controller" + mode);

		if (mode != null && mode.equalsIgnoreCase("ALL")) {
			payPostingFilelevelDetailsObjSearch.setMode("");
		} else {
			payPostingFilelevelDetailsObjSearch.setMode(mode);
		}
		//reportslogger.info("vendor id " + vendorID);

		if (vendorID == null || vendorID.equals("")) {

			payPostingFilelevelDetailsObjSearch.setVendorId(null);

		} else {
			//reportslogger.info("enterded else");

			payPostingFilelevelDetailsObjSearch.setVendorId(vendorID.trim());
		}

		//reportslogger.info("vendor id"+ payPostingFilelevelDetailsObj.getVendorId());
		if (childUserId == null || childUserId.equals("")) {

			payPostingFilelevelDetailsObjSearch.setChildUserId(null);

		} else {
			//reportslogger.info("enterded else");

			payPostingFilelevelDetailsObjSearch.setChildUserId(childUserId.trim());
		}

		//reportslogger.info("child user id"+ payPostingFilelevelDetailsObj.getChildUserId());
		HashMap<Integer, List<PaymentPostingFilelevelDetails>> detailsMap = new HashMap<Integer, List<PaymentPostingFilelevelDetails>>();
		int page = 1;
		String statusMsg = null;
		List<String> modeList = ReportsDaoObj.returnModeList();

		/*if(Role==-1)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.setViewName("PayPostingFileLevelSearch");
			return modelAndViewObj;
		}*/

		if(modeList==null)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PayPostingFileLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Modes List size in Controller: "+modeList.size());
		modelAndViewObj.addObject("modeList", modeList);


		//session.setAttribute("PaymentPostingFileLevelFilter", payPostingFilelevelDetailsObj);

		detailsMap = ReportsDaoObj.getPayPostingFilelevelDetails(payPostingFilelevelDetailsObjSearch, page);

		if(detailsMap==null)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PayPostingFileLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info(" Details Map Size based on Search Criteria in Controller: "+detailsMap.size() );



		//reportslogger.info("method called in controler");

		//reportslogger.info("in controller"+ payPostingFilelevelDetailsObj.getStatusMsg());
		if(payPostingFilelevelDetailsObjSearch.getStatusMsg()!=null)
		{

			if(payPostingFilelevelDetailsObjSearch.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				statusMsg="";
			}

			else
			{
				statusMsg=payPostingFilelevelDetailsObjSearch.getStatusMsg();
			}

		}
		else
			statusMsg="Connectivity Issues..Retry..";

		modelAndViewObj.addObject("role", Role);
		modelAndViewObj.addObject("statusMsg", statusMsg);
		modelAndViewObj.addObject("detailsMap", detailsMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("payPostingFilelevelDetailsObjJsp",payPostingFilelevelDetailsObjSearch);
		modelAndViewObj.setViewName("PayPostingFileLevelSearch");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/payPostingFilelevelViewPagination")
	public ModelAndView paymentPostingFilelevelPagination(HttpServletRequest request, HttpServletResponse response) 

	{
		//PaymentPostingFilelevelDetails payPostingFilelevelDetailsObj=(PaymentPostingFilelevelDetails)session.getAttribute("PaymentPostingFileLevelFilter");
		PaymentPostingFilelevelDetails payPostingFilelevelDetailsObjPag=new PaymentPostingFilelevelDetails();

		/*String myObjectId = request.getParameter("PaymentPostingFileLevelFilter");
		PaymentPostingFilelevelDetails payPostingFilelevelDetailsObj = (PaymentPostingFilelevelDetails)request.getSession().getAttribute(myObjectId);*/

		session=request.getSession(false);

		reportslogger.info("In Payment Posting File level Pagination");

		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		payPostingFilelevelDetailsObjPag.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in payPostingFilelevelViewPagination mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);
		String filedId = request.getParameter("fileid");
		String fromDate = request.getParameter("startDate");

		String toDate = request.getParameter("endDate");
		//reportslogger.info("toDate is" + toDate);
		String fileName = request.getParameter("fileName");
		String mode = request.getParameter("mode");
		String vendorID = request.getParameter("vendorid");
		String childUserId = request.getParameter("childUserid");
		reportslogger.info("File ID: "+filedId);
		reportslogger.info("From Date: "+fromDate);
		reportslogger.info("To Date: "+toDate);
		reportslogger.info("File Name: "+fileName);
		reportslogger.info("Mode: "+mode);
		reportslogger.info("Vendor ID: "+vendorID);
		reportslogger.info("User ID: "+childUserId);


		if (fromDate != "") {

			payPostingFilelevelDetailsObjPag.setFromDate(fromDate);
		} else
			payPostingFilelevelDetailsObjPag.setFromDate(null);

		//reportslogger.info("fromdate:"+ payPostingFilelevelDetailsObj.getFromDate());

		if (toDate != "") {
			payPostingFilelevelDetailsObjPag.setToDate(toDate);
		} else {
			payPostingFilelevelDetailsObjPag.setToDate(null);
		}

		//reportslogger.info("todate:"+ payPostingFilelevelDetailsObj.getToDate());


		//reportslogger.info("file id " + filedId);

		if (filedId == null || filedId.equals("")) {
			//reportslogger.info("enterded if set to 0");
			payPostingFilelevelDetailsObjPag.setFileId(null);

		} else {
			//reportslogger.info("enterded else");
			payPostingFilelevelDetailsObjPag.setFileId(filedId.trim());
			//reportslogger.info("file id is"+payPostingFilelevelDetailsObj.getFileId());
		}
		//reportslogger.info("file id"+ payPostingFilelevelDetailsObj.getFileId());


		if (fileName == null || fileName.equals("")) {

			payPostingFilelevelDetailsObjPag.setFileName(null);

		} else {
			//reportslogger.info("enterded else");
			payPostingFilelevelDetailsObjPag.setFileName(fileName.trim());
		}

		//reportslogger.info("mode in controller" + mode);

		if (mode != null && mode.equalsIgnoreCase("ALL")) {
			payPostingFilelevelDetailsObjPag.setMode("");
		} else {
			payPostingFilelevelDetailsObjPag.setMode(mode);
		}
		//reportslogger.info("vendor id " + vendorID);

		if (vendorID == null || vendorID.equals("")) {

			payPostingFilelevelDetailsObjPag.setVendorId(null);

		} else {
			//reportslogger.info("enterded else");

			payPostingFilelevelDetailsObjPag.setVendorId(vendorID.trim());
		}

		//reportslogger.info("vendor id"+ payPostingFilelevelDetailsObj.getVendorId());
		if (childUserId == null || childUserId.equals("")) {

			payPostingFilelevelDetailsObjPag.setChildUserId(null);

		} else {
			//reportslogger.info("enterded else");

			payPostingFilelevelDetailsObjPag.setChildUserId(childUserId.trim());
		}


		HashMap<Integer, List<PaymentPostingFilelevelDetails>> detailsMap = new HashMap<Integer, List<PaymentPostingFilelevelDetails>>();
		int page = Integer.parseInt(request.getParameter("pageNum"));

		reportslogger.info("Page Number: "+page);
		String statusMsg = null;
		ModelAndView modelAndViewObj = new ModelAndView();

		List<String> modeList = ReportsDaoObj.returnModeList();
		if(modeList==null)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PayPostingFileLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Modes List size in Controller: "+modeList.size());
		modelAndViewObj.addObject("modeList", modeList);

		//session.setAttribute("PaymentPostingFileLevelFilter", payPostingFilelevelDetailsObj);


		detailsMap = ReportsDaoObj.getPayPostingFilelevelDetails(payPostingFilelevelDetailsObjPag, page);

		if(detailsMap==null){

			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PayPostingFileLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info(" Details Map Size based on Page No. in Controller: "+detailsMap.size() );


		//reportslogger.info("method called in controler");

		//reportslogger.info("in controller"+ payPostingFilelevelDetailsObj.getStatusMsg());

		if(payPostingFilelevelDetailsObjPag.getStatusMsg()!=null)
		{

			if(payPostingFilelevelDetailsObjPag.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				statusMsg="";
			}

			else
			{
				statusMsg=payPostingFilelevelDetailsObjPag.getStatusMsg();
			}

		}
		else
			statusMsg="Connectivity Issues..Retry..";


		modelAndViewObj.addObject("role", Role);
		modelAndViewObj.addObject("statusMsg", statusMsg);
		modelAndViewObj.addObject("detailsMap", detailsMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("payPostingFilelevelDetailsObjJsp",payPostingFilelevelDetailsObjPag);
		modelAndViewObj.setViewName("PayPostingFileLevelSearch");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/payPostingExcelFileDownload", method = RequestMethod.POST)
	public ModelAndView paymentPostingexcelFileDownload(HttpServletRequest request, HttpServletResponse response)throws IOException 

	{
		//PaymentPostingFilelevelDetails payPostingFilelevelDetailsObj=(PaymentPostingFilelevelDetails)session.getAttribute("PaymentPostingFileLevelFilter");
		//reportslogger.info("enterd /payPostingExcelFileDownload");
		PaymentPostingFilelevelDetails payPostingFilelevelDetailsObjExp=new PaymentPostingFilelevelDetails();
		reportslogger.info(" In Payment Posting Excel File Download" );

		/*String myObjectId = request.getParameter("PaymentPostingFileLevelFilter");
		PaymentPostingFilelevelDetails payPostingFilelevelDetailsObj = (PaymentPostingFilelevelDetails)request.getSession().getAttribute(myObjectId);*/


		session=request.getSession(false);

		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		payPostingFilelevelDetailsObjExp.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);

		String filedId = request.getParameter("fileid");
		String fromDate = request.getParameter("startDate");

		String toDate = request.getParameter("endDate");
		//reportslogger.info("toDate is" + toDate);
		String fileName1 = request.getParameter("fileName");
		String mode = request.getParameter("mode");
		String vendorID = request.getParameter("vendorid");
		String childUserId = request.getParameter("childUserid");
		reportslogger.info("File ID: "+filedId);
		reportslogger.info("From Date: "+fromDate);
		reportslogger.info("To Date: "+toDate);
		reportslogger.info("File Name: "+fileName1);
		reportslogger.info("Mode: "+mode);
		reportslogger.info("Vendor ID: "+vendorID);
		reportslogger.info("User ID: "+childUserId);
		reportslogger.info("User ID in expoert to excel: "+childUserId);



		if (fromDate != "") {

			payPostingFilelevelDetailsObjExp.setFromDate(fromDate);
		} else
			payPostingFilelevelDetailsObjExp.setFromDate(null);

		//reportslogger.info("fromdate:"+ payPostingFilelevelDetailsObj.getFromDate());

		if (toDate != "") {
			payPostingFilelevelDetailsObjExp.setToDate(toDate);
		} else {
			payPostingFilelevelDetailsObjExp.setToDate(null);
		}

		//reportslogger.info("todate:"+ payPostingFilelevelDetailsObj.getToDate());


		//reportslogger.info("file id " + filedId);

		if (filedId == null || filedId.equals("")) {
			//reportslogger.info("enterded if set to 0");
			payPostingFilelevelDetailsObjExp.setFileId(null);

		} else {
			//reportslogger.info("enterded else");
			payPostingFilelevelDetailsObjExp.setFileId(filedId.trim());
			//reportslogger.info("file id is"+payPostingFilelevelDetailsObj.getFileId());
		}
		//reportslogger.info("file id"+ payPostingFilelevelDetailsObj.getFileId());


		if (fileName1 == null || fileName1.equals("")) {

			payPostingFilelevelDetailsObjExp.setFileName(null);

		} else {
			//reportslogger.info("enterded else");
			payPostingFilelevelDetailsObjExp.setFileName(fileName1.trim());
		}

		//reportslogger.info("mode in controller" + mode);

		if (mode != null && mode.equalsIgnoreCase("ALL")) {
			payPostingFilelevelDetailsObjExp.setMode("");
		} else {
			payPostingFilelevelDetailsObjExp.setMode(mode);
		}
		//reportslogger.info("vendor id " + vendorID);

		if (vendorID == null || vendorID.equals("")) {

			payPostingFilelevelDetailsObjExp.setVendorId(null);

		} else {
			//reportslogger.info("enterded else");

			payPostingFilelevelDetailsObjExp.setVendorId(vendorID.trim());
		}

		//reportslogger.info("vendor id"+ payPostingFilelevelDetailsObj.getVendorId());
		if (childUserId == null || childUserId.equals("")) {

			payPostingFilelevelDetailsObjExp.setChildUserId(null);

		} else {
			//reportslogger.info("enterded else");

			payPostingFilelevelDetailsObjExp.setChildUserId(childUserId.trim());
		}



		ModelAndView modelAndViewObj = new ModelAndView();
		List<PaymentPostingFilelevelDetails> PayPostingexcellDetailsList = new ArrayList<PaymentPostingFilelevelDetails>();
		String pageNo = null;
		int rowNumber = 1;
		List<String> modeList = ReportsDaoObj.returnModeList();
		if(modeList==null)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PayPostingFileLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Modes List size in Controller: "+modeList.size());
		modelAndViewObj.addObject("modeList", modeList);




		PayPostingexcellDetailsList = ReportsDaoObj.getPayPostingExcelDetails(payPostingFilelevelDetailsObjExp, pageNo);

		if(PayPostingexcellDetailsList==null)
		{	modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
		modelAndViewObj.addObject("role", Role);
		modelAndViewObj.setViewName("PayPostingFileLevelSearch");
		return modelAndViewObj;
		}


		reportslogger.info("Excel Details List Size in Controller: "+PayPostingexcellDetailsList.size());
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("Payment_Posting_File_Level");
		XSSFCell cell = null;
		XSSFRow row;
		XSSFCellStyle my_style = wb.createCellStyle();
		XSSFFont my_font=wb.createFont();
		my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		my_style.setFont(my_font);
		XSSFCellStyle rightAligned = wb.createCellStyle();
		rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);


		row = sheet.createRow(0);
		cell = row.createCell(0);
		cell.setCellValue("Uploaded By(OLM ID)");
		cell.setCellStyle(my_style);
		cell = row.createCell(1);
		cell.setCellValue("Vendor ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(2);
		cell.setCellValue("Vendor Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(3);
		cell.setCellValue("User Circle");
		cell.setCellStyle(my_style);
		cell = row.createCell(4);
		cell.setCellValue("File ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(5);
		cell.setCellValue("File Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(6);
		cell.setCellValue("Mode");
		cell.setCellStyle(my_style);
		cell = row.createCell(7);
		cell.setCellValue("Uploaded Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(8);
		cell.setCellValue("Approved/Rejected By(OLM ID)");
		cell.setCellStyle(my_style);
		cell = row.createCell(9);
		cell.setCellValue("Approved/Rejected Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(10);
		cell.setCellValue("Total Records");
		cell.setCellStyle(my_style);
		cell = row.createCell(11);
		cell.setCellValue("Total Value");
		cell.setCellStyle(my_style);
		cell = row.createCell(12);
		cell.setCellValue("In Progress Records");
		cell.setCellStyle(my_style);
		cell = row.createCell(13);
		cell.setCellValue("In Progress Value");
		cell.setCellStyle(my_style);
		cell = row.createCell(14);
		cell.setCellValue("Status");
		cell.setCellStyle(my_style);
		cell = row.createCell(15);
		cell.setCellValue("Records Pushed To FX");
		cell.setCellStyle(my_style);
		cell = row.createCell(16);
		cell.setCellValue("Value Pushed To FX");
		cell.setCellStyle(my_style);
		cell = row.createCell(17);
		cell.setCellValue("Records Pending At LIU");
		cell.setCellStyle(my_style);
		cell = row.createCell(18);
		cell.setCellValue("Value Pending At LIU");
		cell.setCellStyle(my_style);
		cell = row.createCell(19);
		cell.setCellValue("Records Deleted At LIU");
		cell.setCellStyle(my_style);
		cell = row.createCell(20);
		cell.setCellValue("Value Deleted At LIU");
		cell.setCellStyle(my_style);
		cell = row.createCell(21);
		cell.setCellValue("Rejected Records");
		cell.setCellStyle(my_style);
		cell = row.createCell(22);
		cell.setCellValue("Rejected Records Value");
		cell.setCellStyle(my_style);




		for (int i = 0; i < PayPostingexcellDetailsList.size(); i++) {

			PaymentPostingFilelevelDetails PayPostingFilelevelDetailsObj = PayPostingexcellDetailsList
					.get(i);

			row = sheet.createRow(rowNumber);
			cell = row.createCell(0);
			cell.setCellValue(PayPostingFilelevelDetailsObj.getChildUserId());
			//sheet.autoSizeColumn(0);
			cell = row.createCell(1);
			if (PayPostingFilelevelDetailsObj.getVendorId() == null
					|| PayPostingFilelevelDetailsObj.getVendorId()
					.equalsIgnoreCase("NA"))
				cell.setCellValue("");
			else
				cell.setCellValue(PayPostingFilelevelDetailsObj.getVendorId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(1);
			cell = row.createCell(2);
			if (PayPostingFilelevelDetailsObj.getVendorName() == null
					|| PayPostingFilelevelDetailsObj.getVendorName()
					.equalsIgnoreCase("NA"))
				cell.setCellValue("");
			else
				cell.setCellValue(PayPostingFilelevelDetailsObj.getVendorName());
			//sheet.autoSizeColumn(2);
			cell = row.createCell(3);
			cell.setCellValue(PayPostingFilelevelDetailsObj.getUserCircle());
			//sheet.autoSizeColumn(3);
			cell = row.createCell(4);
			cell.setCellValue(PayPostingFilelevelDetailsObj.getFileId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(4);
			cell = row.createCell(5);
			cell.setCellValue(PayPostingFilelevelDetailsObj.getFileName());
			//sheet.autoSizeColumn(5);

			cell = row.createCell(6);
			cell.setCellValue(PayPostingFilelevelDetailsObj.getMode());
			//sheet.autoSizeColumn(6);
			cell = row.createCell(7);
			CellStyle cellStyle = wb.createCellStyle();
			CreationHelper createHelper = wb.getCreationHelper();

			cellStyle.setDataFormat(createHelper.createDataFormat().getFormat(
					"dd/mm/yyyy"));
			if (PayPostingFilelevelDetailsObj.getUploadedDate() != null) {
				cell.setCellValue(PayPostingFilelevelDetailsObj
						.getUploadedDate());
				cell.setCellStyle(cellStyle);
			} else
				cell.setCellValue("");

			//sheet.autoSizeColumn(7);
			cell = row.createCell(8);
			cell.setCellValue(PayPostingFilelevelDetailsObj.getApprovedBy());
			//sheet.autoSizeColumn(8);
			cell = row.createCell(9);
			cell.setCellValue(PayPostingFilelevelDetailsObj.getApprovedDate());
			//sheet.autoSizeColumn(9);

			cell = row.createCell(10);
			cell.setCellValue(PayPostingFilelevelDetailsObj.getTotalRecords());
			//sheet.autoSizeColumn(10);
			cell = row.createCell(11);
			cell.setCellValue(PayPostingFilelevelDetailsObj.getTotalValue());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(11);
			cell = row.createCell(12);
			cell.setCellValue(PayPostingFilelevelDetailsObj.getInProgressRecords());
			cell = row.createCell(13);
			cell.setCellValue(PayPostingFilelevelDetailsObj.getInProgressValue());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(12);
			cell = row.createCell(14);
			cell.setCellValue(PayPostingFilelevelDetailsObj.getStatus());
			//sheet.autoSizeColumn(13);
			cell = row.createCell(15);

			cell.setCellValue(PayPostingFilelevelDetailsObj
					.getRecordsPostedToFx());
			//sheet.autoSizeColumn(14);
			cell = row.createCell(16);
			cell.setCellValue(PayPostingFilelevelDetailsObj
					.getValuePostedToFx());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(15);
			cell = row.createCell(17);
			cell.setCellValue(PayPostingFilelevelDetailsObj
					.getRecordsPendingAtLiu());
			//sheet.autoSizeColumn(16);
			cell = row.createCell(18);

			cell.setCellValue(PayPostingFilelevelDetailsObj
					.getValuePendingAtLiu());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(17);
			cell = row.createCell(19);
			cell.setCellValue(PayPostingFilelevelDetailsObj
					.getLiuDeleted());
			//sheet.autoSizeColumn(18);

			cell = row.createCell(20);
			cell.setCellValue(PayPostingFilelevelDetailsObj
					.getValueDeletedAtLiu());
			cell.setCellStyle(rightAligned);
			cell = row.createCell(21);
			cell.setCellValue(PayPostingFilelevelDetailsObj
					.getRejectedRecords());
			cell = row.createCell(22);
			cell.setCellValue(PayPostingFilelevelDetailsObj
					.getRejectedValue());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(18);

			rowNumber = rowNumber + 1;

		}
		for (int i = 0; i <= 22; i++) {
			sheet.autoSizeColumn(i);
		}

		// write it as an excel attachment
		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);

		}
		byte[] outArray = outByteStream.toByteArray();
		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
				.format(new Date());
		String fileName = "APS_Payment_Posting_File_Level_" + date + ".xlsx";

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}

		reportslogger.info("End of Payment Posting Excel records download ");
		// modelAndViewObj.setViewName("viewTracking");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/payPostingLiuRecordsFileDownload", method = RequestMethod.POST)
	public ModelAndView paymentPostingLiuRecordsFileDownload(HttpServletRequest request, HttpServletResponse response)throws IOException
	{
		session=request.getSession(false);
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);

		reportslogger.info("In payment Posting, Pending LIU Records Download");
		List<PaymentPostingTransLevelDetailsDownload> PayPostingTransLevelDetailsList = new ArrayList<PaymentPostingTransLevelDetailsDownload>();
		ModelAndView modelAndViewObj = new ModelAndView();
		String fileID = request.getParameter("fileID");
		reportslogger.info("File ID in Payment Posting Pending LIU Records download: " + fileID);
		int rowNumber = 1;
		List<String> modeList = ReportsDaoObj.returnModeList();
		if(modeList==null)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PayPostingFileLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Modes List size in Controller: "+modeList.size());
		modelAndViewObj.addObject("modeList", modeList);

		//reportslogger.info("file ID" + fileID);

		PayPostingTransLevelDetailsList = ReportsDaoObj.getPayPostingPendingLiuRecords(fileID);

		if(PayPostingTransLevelDetailsList==null)
		{			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
		modelAndViewObj.addObject("role", Role);
		modelAndViewObj.setViewName("PayPostingFileLevelSearch");
		return modelAndViewObj;
		}

		reportslogger.info("Excel Details list size in Controller: "+PayPostingTransLevelDetailsList.size());
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("Records_Pending_At_LIU");
		XSSFCell cell = null;
		XSSFRow row;
		XSSFCellStyle my_style = wb.createCellStyle();
		XSSFFont my_font=wb.createFont();
		my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		my_style.setFont(my_font);
		XSSFCellStyle rightAligned = wb.createCellStyle();
		rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);

		row = sheet.createRow(0);
		cell = row.createCell(0);
		cell.setCellValue("Reference No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(1);
		cell.setCellValue("Bank Account No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(2);
		cell.setCellValue("Vendor ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(3);
		cell.setCellValue("Vendor Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(4);
		cell.setCellValue("Uploaded By(OLM ID)");
		cell.setCellStyle(my_style);
		cell = row.createCell(5);
		cell.setCellValue("File ID");

		cell.setCellStyle(my_style);
		cell = row.createCell(6);
		cell.setCellValue("File Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(7);
		cell.setCellValue("File Source");
		cell.setCellStyle(my_style);
		cell = row.createCell(8);
		cell.setCellValue("Mode");
		cell.setCellStyle(my_style);
		cell = row.createCell(9);
		cell.setCellValue("Uploaded Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(10);
		cell.setCellValue("Approved/Rejected By(OLM ID)");
		cell.setCellStyle(my_style);
		cell = row.createCell(11);
		cell.setCellValue("Approved/Rejected Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(12);
		cell.setCellValue("LOB");
		cell.setCellStyle(my_style);
		cell = row.createCell(13);
		cell.setCellValue("Account No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(14);
		cell.setCellValue("Invoice");
		cell.setCellStyle(my_style);
		cell = row.createCell(15);
		cell.setCellValue("Amount");
		cell.setCellStyle(my_style);
		cell = row.createCell(16);
		cell.setCellValue("Reason For Failure/LIU");
		cell.setCellStyle(my_style);

		for (int i = 0; i < PayPostingTransLevelDetailsList.size(); i++) {

			PaymentPostingTransLevelDetailsDownload PayPostingTransLevelDetailsObj = PayPostingTransLevelDetailsList
					.get(i);
			//reportslogger.info("in controller uplodeddate"+ PayPostingTransLevelDetailsObj.getUplodedDateTime());
			row = sheet.createRow(rowNumber);
			cell = row.createCell(0);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getRefNo());
			cell = row.createCell(1);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getBankAccNo());
			//sheet.autoSizeColumn(0);
			cell = row.createCell(2);
			if (PayPostingTransLevelDetailsObj.getVendorId() == null
					|| PayPostingTransLevelDetailsObj.getVendorId()
					.equalsIgnoreCase("NA"))
				cell.setCellValue("");
			else
				cell.setCellValue(PayPostingTransLevelDetailsObj.getVendorId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(1);
			cell = row.createCell(3);
			if (PayPostingTransLevelDetailsObj.getVendorName() == null
					|| PayPostingTransLevelDetailsObj.getVendorName()
					.equalsIgnoreCase("NA"))
				cell.setCellValue("");
			else
				cell.setCellValue(PayPostingTransLevelDetailsObj
						.getVendorName());
			//sheet.autoSizeColumn(2);
			cell = row.createCell(4);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getUserOlmId());
			//sheet.autoSizeColumn(3);
			cell = row.createCell(5);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getFileId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(4);
			cell = row.createCell(6);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getFileName());
			//sheet.autoSizeColumn(5);
			cell = row.createCell(7);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getFileSource());
			//sheet.autoSizeColumn(6);
			cell = row.createCell(8);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getMode());
			//sheet.autoSizeColumn(7);
			cell = row.createCell(9);
			CellStyle cellStyle = wb.createCellStyle();
			CreationHelper createHelper = wb.getCreationHelper();

			cellStyle.setDataFormat(createHelper.createDataFormat().getFormat(
					"dd/mm/yyyy"));
			if (PayPostingTransLevelDetailsObj.getUplodedDateTime() != null) {
				cell.setCellValue(PayPostingTransLevelDetailsObj
						.getUplodedDateTime());
				cell.setCellStyle(cellStyle);
			} else
				cell.setCellValue("");

			//sheet.autoSizeColumn(8);
			cell = row.createCell(10);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getApprovedBy());
			cell = row.createCell(11);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getApprovedDate());
			cell = row.createCell(12);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getLob());

			cell = row.createCell(13);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getAccountNumber());
			//sheet.autoSizeColumn(9);
			cell = row.createCell(14);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getInvoice());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(10);
			cell = row.createCell(15);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getAmount());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(11);
			cell = row.createCell(16);

			cell.setCellValue(PayPostingTransLevelDetailsObj
					.getReasonForLiuFailure());
			//sheet.autoSizeColumn(12);

			rowNumber = rowNumber + 1;

		}
		for (int i = 0; i <=16; i++) {
			sheet.autoSizeColumn(i);
		}
		// write it as an excel attachment
		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		byte[] outArray = outByteStream.toByteArray();
		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
				.format(new Date());

		String fileName = "APS_"+fileID + "_Records_Pending_At_LIU_"+date+".xlsx";

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}

		reportslogger.info("End of Pending LIU records download ");
		// modelAndViewObj.setViewName("viewTracking");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/payPostingFxRecordsFileDownload", method = RequestMethod.POST)
	public ModelAndView paymentPostingFxRecordsDownload(HttpServletRequest request, HttpServletResponse response)throws IOException 
	{
		session=request.getSession(false);

		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);

		reportslogger.info("In payment Posting, FX Records Download");
		List<PaymentPostingTransLevelDetailsDownload> PayPostingTransLevelDetailsList = new ArrayList<PaymentPostingTransLevelDetailsDownload>();
		ModelAndView modelAndViewObj = new ModelAndView();
		String fileID = request.getParameter("fileID");
		reportslogger.info("File ID in Payment Posting FX Records download: " + fileID);
		int rowNumber = 1;
		List<String> modeList = ReportsDaoObj.returnModeList();
		if(modeList==null)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PayPostingFileLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Modes List size in Controller: "+modeList.size());
		modelAndViewObj.addObject("modeList", modeList);

		//reportslogger.info("file ID" + fileID);

		PayPostingTransLevelDetailsList = ReportsDaoObj.getPayPostingRecordsPostedToFx(fileID);

		if(PayPostingTransLevelDetailsList==null)
		{			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
		modelAndViewObj.addObject("role", Role);
		modelAndViewObj.setViewName("PayPostingFileLevelSearch");
		return modelAndViewObj;
		}
		reportslogger.info("Excel Details List Size in controller: "+PayPostingTransLevelDetailsList.size());
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("Records_Pushed_To_FX");
		XSSFCell cell = null;
		XSSFRow row;
		XSSFCellStyle my_style = wb.createCellStyle();
		XSSFFont my_font=wb.createFont();
		my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		my_style.setFont(my_font);
		XSSFCellStyle rightAligned = wb.createCellStyle();
		rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);



		row = sheet.createRow(0);
		cell = row.createCell(0);
		cell.setCellValue("Reference No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(1);
		cell.setCellValue("Bank Account No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(2);
		cell.setCellValue("Vendor ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(3);
		cell.setCellValue("Vendor Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(4);
		cell.setCellValue("Uploaded By(OLM ID)");
		cell.setCellStyle(my_style);
		cell = row.createCell(5);
		cell.setCellValue("File ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(6);
		cell.setCellValue("File Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(7);
		cell.setCellValue("File Source");
		cell.setCellStyle(my_style);
		cell = row.createCell(8);
		cell.setCellValue("Mode");
		cell.setCellStyle(my_style);
		cell = row.createCell(9);
		cell.setCellValue("Uploaded Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(10);
		cell.setCellValue("Approved/Rejected By(OLM ID)");
		cell.setCellStyle(my_style);
		cell = row.createCell(11);
		cell.setCellValue("Approved/Rejected Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(12);
		cell.setCellValue("LOB");
		cell.setCellStyle(my_style);
		cell = row.createCell(13);
		cell.setCellValue("Account No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(14);
		cell.setCellValue("Invoice");
		cell.setCellStyle(my_style);
		cell = row.createCell(15);
		cell.setCellValue("Amount");
		cell.setCellStyle(my_style);
		cell = row.createCell(16);
		cell.setCellValue("FX Posting Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(17);
		cell.setCellValue("Tracking ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(18);
		cell.setCellValue("Tracking ID Serv");
		cell.setCellStyle(my_style);

		for (int i = 0; i < PayPostingTransLevelDetailsList.size(); i++) {

			PaymentPostingTransLevelDetailsDownload PayPostingTransLevelDetailsObj = PayPostingTransLevelDetailsList
					.get(i);
			//reportslogger.info("in controller uplodeddate"+ PayPostingTransLevelDetailsObj.getUplodedDateTime());
			row = sheet.createRow(rowNumber);
			cell = row.createCell(0);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getRefNo());
			cell = row.createCell(1);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getBankAccNo());
			//sheet.autoSizeColumn(0);
			cell = row.createCell(2);

			if (PayPostingTransLevelDetailsObj.getVendorId() == null
					|| PayPostingTransLevelDetailsObj.getVendorId()
					.equalsIgnoreCase("NA"))
				cell.setCellValue("");
			else
				cell.setCellValue(PayPostingTransLevelDetailsObj.getVendorId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(1);
			cell = row.createCell(3);
			if (PayPostingTransLevelDetailsObj.getVendorName() == null
					|| PayPostingTransLevelDetailsObj.getVendorName()
					.equalsIgnoreCase("NA"))
				cell.setCellValue("");
			else
				cell.setCellValue(PayPostingTransLevelDetailsObj
						.getVendorName());
			//sheet.autoSizeColumn(2);
			cell = row.createCell(4);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getUserOlmId());
			//sheet.autoSizeColumn(3);
			cell = row.createCell(5);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getFileId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(4);
			cell = row.createCell(6);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getFileName());
			//sheet.autoSizeColumn(5);
			cell = row.createCell(7);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getFileSource());
			//sheet.autoSizeColumn(6);
			cell = row.createCell(8);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getMode());
			//sheet.autoSizeColumn(7);
			cell = row.createCell(9);
			CellStyle cellStyle = wb.createCellStyle();
			CreationHelper createHelper = wb.getCreationHelper();

			cellStyle.setDataFormat(createHelper.createDataFormat().getFormat(
					"dd/mm/yyyy"));
			if (PayPostingTransLevelDetailsObj.getUplodedDateTime() != null) {
				cell.setCellValue(PayPostingTransLevelDetailsObj
						.getUplodedDateTime());
				cell.setCellStyle(cellStyle);
			} else
				cell.setCellValue("");

			//sheet.autoSizeColumn(8);
			cell = row.createCell(10);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getApprovedBy());
			cell = row.createCell(11);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getApprovedDate());
			cell = row.createCell(12);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getLob());
			cell = row.createCell(13);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getAccountNumber());
			//sheet.autoSizeColumn(9);
			cell = row.createCell(14);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getInvoice());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(10);
			cell = row.createCell(15);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getAmount());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(11);
			cell = row.createCell(16);
			if (PayPostingTransLevelDetailsObj.getFxPostingTime() != null) {
				cell.setCellValue(PayPostingTransLevelDetailsObj
						.getFxPostingTime());
				cell.setCellStyle(cellStyle);
			} else
				cell.setCellValue("");
			//sheet.autoSizeColumn(12);
			cell = row.createCell(17);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getTrackingid());
			//sheet.autoSizeColumn(13);
			cell = row.createCell(18);
			cell.setCellValue(PayPostingTransLevelDetailsObj.getTrackingServ());
			//sheet.autoSizeColumn(14);

			rowNumber = rowNumber + 1;

		}
		for (int i = 0; i <= 18; i++) {
			sheet.autoSizeColumn(i);
		}
		// write it as an excel attachment
		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		byte[] outArray = outByteStream.toByteArray();
		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
				.format(new Date());

		String fileName = "APS_"+fileID + "_Records_Pushed_To_FX_"+date+".xlsx";

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}

		reportslogger.info("End of FX records download ");
		// modelAndViewObj.setViewName("viewTracking");
		return modelAndViewObj;
	}

	/** PAYMENT POSTING MODEWISE SUMMARY **/

	/*	@RequestMapping(value = "/paymentPostingModewise")
	public ModelAndView ModewiseHome() {
		reportslogger.info(" In Payment Posting Mode level Report Controller ");
		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("PaymentPostingModewiseLogin");
		return modelAndViewObj;


	}*/

	@RequestMapping(value = "/paymentPostingModewiseRole", method = RequestMethod.GET)
	public ModelAndView paymentPostingModewiseRole(HttpServletRequest request,HttpServletResponse response) 
	{
		PaymentPostingModewiseBean PayPostingModewiseSumBeanObj = new PaymentPostingModewiseBean();

		ModelAndView modelAndViewObj = new ModelAndView();
		session=request.getSession(false);
		reportslogger.info(" In Payment Posting Mode level Report Controller ");

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		// PayPostingFilelevelDetails payPostingFilelevelDetailsObj=new
		// PayPostingFilelevelDetails();
		//reportslogger.info("in controller to get role.");

		// get role by calling fn.
		//String parentUserId = request.getParameter("parentUserId");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		//Role = ReportsDaoObj.getRole(parentUserId);
		/*if(Role==-1)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.setViewName("PaymentPostingModewiseSearch");
			return modelAndViewObj;
		}*/

		reportslogger.info("User Role: " + Role);

		if (Role == 1 || Role == 2 || Role == 3 || Role == 4 || Role == 7) {

			PayPostingModewiseSumBeanObj.setParentUserId(parentUserId);

			PayPostingModewiseSumBeanObj.setToDate(null);
			PayPostingModewiseSumBeanObj.setFromDate(null);
			PayPostingModewiseSumBeanObj.setMode(null);
			List<String> modeList = ReportsDaoObj.returnModeList();
			if(modeList==null)
			{
				modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("role", Role);
				modelAndViewObj.setViewName("PaymentPostingModewiseSearch");
				return modelAndViewObj;
			}
			reportslogger.info("Modes List size in Controller: "+modeList.size());
			modelAndViewObj.addObject("modeList", modeList);

			HashMap<Integer, List<PaymentPostingModewiseBean>> completeDetailsMap = new HashMap<Integer, List<PaymentPostingModewiseBean>>();
			int page = 1;
			String statusMsg = null;

			completeDetailsMap = ReportsDaoObj.getPayPosModewiseSumDetails(PayPostingModewiseSumBeanObj, page);


			if(completeDetailsMap==null){
				modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("role", Role);
				modelAndViewObj.setViewName("PaymentPostingModewiseSearch");
				return modelAndViewObj;
			}

			reportslogger.info("Details Map Size in Controller: "+completeDetailsMap.size());
			if(PayPostingModewiseSumBeanObj.getStatusMsg()!=null)
			{

				if(PayPostingModewiseSumBeanObj.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
				{
					statusMsg="";
				}

				else
				{
					statusMsg=PayPostingModewiseSumBeanObj.getStatusMsg();
				}

			}
			else
				statusMsg="Connectivity Issues..Retry..";


			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.addObject("statusMsg", statusMsg);

			modelAndViewObj.addObject("detailsMap", completeDetailsMap);
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.setViewName("PaymentPostingModewiseSearch");
			return modelAndViewObj;
		}

		else {
			reportslogger.info("you do not have privilage to view this page!");

			modelAndViewObj.addObject("error",
					"You do not have privilige to View Reports !!");
			modelAndViewObj.setViewName("PaymentPostingModewiseSearch");
			return modelAndViewObj;
		}
	}

	@RequestMapping(value = "/PaymentPostingModewiseSearch")
	public ModelAndView paymentPostingModewiseDetails(HttpServletRequest request, HttpServletResponse response)
	{
		PaymentPostingModewiseBean PayPostingModewiseSumBeanSearchObj = new PaymentPostingModewiseBean();

		session=request.getSession(false);
		reportslogger.info("In Payment Posting Mode level Search");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);

		ModelAndView modelAndViewObj = new ModelAndView();
		/*if(Role==-1)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.setViewName("PaymentPostingModewiseSearch");
			return modelAndViewObj;
		}*/

		PayPostingModewiseSumBeanSearchObj.setParentUserId(parentUserId);

		String fromDate = request.getParameter("startDate");

		String toDate = request.getParameter("endDate");
		String mode = request.getParameter("mode");

		reportslogger.info("From Date: " + fromDate);
		reportslogger.info("To Date: " + toDate);
		reportslogger.info("mode: " + mode);

		if (fromDate != "") {

			PayPostingModewiseSumBeanSearchObj.setFromDate(fromDate);
		} else
			PayPostingModewiseSumBeanSearchObj.setFromDate(null);



		if (toDate != "") {
			PayPostingModewiseSumBeanSearchObj.setToDate(toDate);
		} else {
			PayPostingModewiseSumBeanSearchObj.setToDate(null);
		}



		if (mode != null && mode.equalsIgnoreCase("ALL")) {
			PayPostingModewiseSumBeanSearchObj.setMode("");
		} else {
			PayPostingModewiseSumBeanSearchObj.setMode(mode);
		}

		HashMap<Integer, List<PaymentPostingModewiseBean>> detailsMap = new HashMap<Integer, List<PaymentPostingModewiseBean>>();
		int page = 1;
		String statusMsg = null;
		List<String> modeList = ReportsDaoObj.returnModeList();
		if(modeList==null)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PaymentPostingModewiseSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Modes List size in Controller: "+modeList.size());
		modelAndViewObj.addObject("modeList", modeList);

		//session.setAttribute("PayPostingModewiseSumBeanObj", PayPostingModewiseSumBeanObj);

		detailsMap = ReportsDaoObj.getPayPosModewiseSumDetails(PayPostingModewiseSumBeanSearchObj, page);

		if(detailsMap==null){
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PaymentPostingModewiseSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Details Map Size based on Search Criteria in Controller: "+detailsMap.size());
		if(PayPostingModewiseSumBeanSearchObj.getStatusMsg()!=null)
		{

			if(PayPostingModewiseSumBeanSearchObj.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				statusMsg="";
			}

			else
			{
				statusMsg=PayPostingModewiseSumBeanSearchObj.getStatusMsg();
			}

		}
		else
			statusMsg="Connectivity Issues..Retry..";


		modelAndViewObj.addObject("role", Role);
		modelAndViewObj.addObject("statusMsg", statusMsg);
		modelAndViewObj.addObject("detailsMap", detailsMap);
		modelAndViewObj.addObject("PayPostingModewiseSumBeanObjJsp", PayPostingModewiseSumBeanSearchObj);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.setViewName("PaymentPostingModewiseSearch");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/PaymentPostingModewiseExcelFileDownload", method = RequestMethod.POST)
	public ModelAndView payPostingModewiseExcelFileDownload(HttpServletRequest request, HttpServletResponse response)throws IOException
	{
		session=request.getSession(false);
		//	PaymentPostingModewiseBean PayPostingModewiseSumBeanObj3=(PaymentPostingModewiseBean)session.getAttribute("PayPostingModewiseSumBeanObj");
		PaymentPostingModewiseBean PayPostingModewiseSumBeanExcel=new PaymentPostingModewiseBean();
		reportslogger.info("In Payment Posting Mode level Excel Records Download");
		//PaymentPostingModewiseBean.getFromDate();
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		PayPostingModewiseSumBeanExcel.setParentUserId(parentUserId);
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);

		ModelAndView modelAndViewObj = new ModelAndView();



		String fromDate = request.getParameter("startDate");

		String toDate = request.getParameter("endDate");
		String mode = request.getParameter("mode");

		reportslogger.info("From Date: " + fromDate);
		reportslogger.info("To Date: " + toDate);
		reportslogger.info("mode: " + mode);

		if (fromDate != "") {

			PayPostingModewiseSumBeanExcel.setFromDate(fromDate);
		} else
			PayPostingModewiseSumBeanExcel.setFromDate(null);



		if (toDate != "") {
			PayPostingModewiseSumBeanExcel.setToDate(toDate);
		} else {
			PayPostingModewiseSumBeanExcel.setToDate(null);
		}



		if (mode != null && mode.equalsIgnoreCase("ALL")) {
			PayPostingModewiseSumBeanExcel.setMode("");
		} else {
			PayPostingModewiseSumBeanExcel.setMode(mode);
		}
		List<PaymentPostingModewiseBean> PayPostingModewiseDetailsList = new ArrayList<PaymentPostingModewiseBean>();
		int pageNo = 1;
		int rowNumber = 1;
		List<String> modeList = ReportsDaoObj.returnModeList();
		if(modeList==null)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PaymentPostingModewiseSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Modes List size in Controller: "+modeList.size());
		modelAndViewObj.addObject("modeList", modeList);

		PayPostingModewiseDetailsList = ReportsDaoObj.getPayPosModewiseSumexcelDetails(PayPostingModewiseSumBeanExcel,pageNo);
		if(PayPostingModewiseDetailsList==null){
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PaymentPostingModewiseSearch");
			return modelAndViewObj;
		}

		reportslogger.info("Excel Records List Size in Controller: "+ PayPostingModewiseDetailsList.size());
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("Payment_Posting_Mode_Level");
		XSSFCell cell = null;
		XSSFRow row;
		XSSFCellStyle my_style = wb.createCellStyle();
		XSSFFont my_font=wb.createFont();
		my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		my_style.setFont(my_font);
		XSSFCellStyle rightAligned = wb.createCellStyle();
		rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);


		row = sheet.createRow(0);
		cell = row.createCell(0);
		cell.setCellValue("Mode");
		cell.setCellStyle(my_style);
		cell = row.createCell(1);
		cell.setCellValue("Total Records");
		cell.setCellStyle(my_style);
		cell = row.createCell(2);
		cell.setCellValue("Total Value");
		cell.setCellStyle(my_style);
		cell = row.createCell(3);
		cell.setCellValue("In Progress Records");
		cell.setCellStyle(my_style);
		cell = row.createCell(4);
		cell.setCellValue("In Progress Value");
		cell.setCellStyle(my_style);
		cell = row.createCell(5);
		cell.setCellValue("Rejected Records");
		cell.setCellStyle(my_style);
		cell = row.createCell(6);
		cell.setCellValue("Rejected Records Value");
		cell.setCellStyle(my_style);
		cell = row.createCell(7);
		cell.setCellValue("Records Pushed To FX ");
		cell.setCellStyle(my_style);
		cell = row.createCell(8);
		cell.setCellValue("Value Pushed To FX");
		cell.setCellStyle(my_style);
		cell = row.createCell(9);
		cell.setCellValue("Records Pending At LIU");
		cell.setCellStyle(my_style);
		cell = row.createCell(10);
		cell.setCellValue("Value Pending At LIU");
		cell.setCellStyle(my_style);
		cell = row.createCell(11);
		cell.setCellValue("Records Deleted At LIU");
		cell.setCellStyle(my_style);
		cell = row.createCell(12);
		cell.setCellValue("Value Deleted At LIU");
		cell.setCellStyle(my_style);

		for (int i = 0; i < PayPostingModewiseDetailsList.size(); i++) {

			PaymentPostingModewiseBean PayPosModewiseSumBeanObj = PayPostingModewiseDetailsList
					.get(i);
			// reportslogger.info("in controller uplodeddate"+PayPostingFilelevelDetailsObj.getUplodedDateTime());
			row = sheet.createRow(rowNumber);
			cell = row.createCell(0);
			cell.setCellValue(PayPosModewiseSumBeanObj.getMode());
			//sheet.autoSizeColumn(0);

			cell = row.createCell(1);
			cell.setCellValue(PayPosModewiseSumBeanObj.getTotalRecords());

			//sheet.autoSizeColumn(1);
			cell = row.createCell(2);
			cell.setCellValue(PayPosModewiseSumBeanObj.getTotalValue());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(2);
			cell = row.createCell(3);
			cell.setCellValue(PayPosModewiseSumBeanObj.getInProgressRecords());
			//sheet.autoSizeColumn(3);
			cell = row.createCell(4);
			cell.setCellValue(PayPosModewiseSumBeanObj.getInProgressValue());
			cell.setCellStyle(rightAligned);
			cell = row.createCell(5);
			cell.setCellValue(PayPosModewiseSumBeanObj.getRejectedRecords());
			cell = row.createCell(6);
			cell.setCellValue(PayPosModewiseSumBeanObj.getRejectedValue());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(4);
			cell = row.createCell(7);
			cell.setCellValue(PayPosModewiseSumBeanObj.getRecordsPostedToFx());
			//sheet.autoSizeColumn(5);

			cell = row.createCell(8);
			cell.setCellValue(PayPosModewiseSumBeanObj.getValuePostedToFx());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(6);

			cell = row.createCell(9);
			cell.setCellValue(PayPosModewiseSumBeanObj.getRecordsPendingAtLiu());
			//sheet.autoSizeColumn(7);

			cell = row.createCell(10);

			cell.setCellValue(PayPosModewiseSumBeanObj.getValuePendingAtLiu());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(8);
			cell = row.createCell(11);
			cell.setCellValue(PayPosModewiseSumBeanObj.getRecDeletedAtLiu());
			//sheet.autoSizeColumn(9);

			cell = row.createCell(12);
			cell.setCellValue(PayPosModewiseSumBeanObj.getValueDeletedAtLiu());
			cell.setCellStyle(rightAligned);

			rowNumber = rowNumber + 1;
		}
		for (int i = 0; i <= 12; i++) {
			sheet.autoSizeColumn(i);
		}
		// write it as an excel attachment
		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		byte[] outArray = outByteStream.toByteArray();
		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
				.format(new Date());
		String fileName = "APS_Payment_Posting_Mode_Level_" + date + " .xlsx";

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}

		reportslogger.info("End of Payment Posting Mode level records download ");
		// modelAndViewObj.setViewName("viewTracking");
		return modelAndViewObj;
	}

	/************************* PAYMENT POSTING TRANSACTION LEVEL REPORT *******************************/

	/*@RequestMapping(value = "/payPostingTransLevel")
	public ModelAndView pymntPostingTransLevel() {
		reportslogger.info("In Payment Posting Transaction Level Controller");
		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("PaymentPostingTransLevelLogin");
		return modelAndViewObj;
	}*/

	@RequestMapping(value = "/getRolePayPostingTransLevel", method = RequestMethod.GET)
	public ModelAndView getParentRole(HttpServletRequest request,
			HttpServletResponse response) {
		session=request.getSession(false);
		PayPostingTransLevelDetails PayPostingTransLevelDetailsObj = new PayPostingTransLevelDetails();

		reportslogger.info("In Payment Posting Transaction Level Controller");

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		ModelAndView modelAndViewObj = new ModelAndView();
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		/* Role = ReportsDaoObj.getRole(parentUserId);
		 if(Role==-1)
			{
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("PaymentPostingTransLevelSearch");
				return modelAndViewObj;
			}*/

		reportslogger.info("User Role: " + Role);

		if ((Role == 1) || (Role == 2) || (Role == 3) || (Role == 4)
				|| (Role == 7)) {

			PayPostingTransLevelDetailsObj.setParentUserId(parentUserId);
			PayPostingTransLevelDetailsObj.setChildUserId(null);
			PayPostingTransLevelDetailsObj.setVendorId(null);
			PayPostingTransLevelDetailsObj.setToDate(null);
			PayPostingTransLevelDetailsObj.setFromDate(null);
			PayPostingTransLevelDetailsObj.setFileId(null);
			PayPostingTransLevelDetailsObj.setFileName(null);
			PayPostingTransLevelDetailsObj.setMode(null);
			PayPostingTransLevelDetailsObj.setRefNo(null);
			/*PayPostingTransLevelDetailsObj.setRole(Role);*/

			// call method from dao and get records based on parentuserId only.
			int page = 1;
			String errMsg = null;
			List<String> modeList = ReportsDaoObj.returnModeList();
			if(modeList==null)
			{
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("UserRole", Role);
				modelAndViewObj.setViewName("PaymentPostingTransLevelSearch");
				return modelAndViewObj;
			}
			reportslogger.info("Modes List size in Controller: "+modeList.size());
			modelAndViewObj.addObject("modeList", modeList);

			HashMap<Integer, List<PayPostingTransLevelDetails>> ReportsMap = new HashMap<Integer, List<PayPostingTransLevelDetails>>();
			ReportsMap = ReportsDaoObj.getPaymntPostingTranslevelMap(
					PayPostingTransLevelDetailsObj, page);

			if(ReportsMap==null)
			{
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("UserRole", Role);
				modelAndViewObj.setViewName("PaymentPostingTransLevelSearch");
				return modelAndViewObj;
			}


			reportslogger.info("Details map  size in Controller: "+ReportsMap.size());


			if(PayPostingTransLevelDetailsObj.getStatusMsg()!=null)
			{

				if(PayPostingTransLevelDetailsObj.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
				{
					errMsg="";
				}

				else
				{
					errMsg=PayPostingTransLevelDetailsObj.getStatusMsg();
				}

			}
			else
				errMsg="Connectivity Issues..Retry..";




			modelAndViewObj.addObject("ReportsMap", ReportsMap);



			modelAndViewObj.addObject("errMsg", errMsg);

			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.addObject("currentPage", page);

			modelAndViewObj.setViewName("PaymentPostingTransLevelSearch");
		}

		else {
			modelAndViewObj.addObject("error",
					"You do not have privilige to check the reports !!");
			modelAndViewObj.setViewName("PaymentPostingTransLevelSearch");
			return modelAndViewObj;
		}

		return modelAndViewObj;
	}

	@RequestMapping(value = "/getRecordsOnSearchPayPostingTransLevel")
	public ModelAndView getRecordsOnSearch(HttpServletRequest request,
			HttpServletResponse response) {
		session=request.getSession(false);
		PayPostingTransLevelDetails PayPostingTransLevelDetailsObjSearch = new PayPostingTransLevelDetails();
		reportslogger.info("In Payment Posting Transaction level Search");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		PayPostingTransLevelDetailsObjSearch.setParentUserId(parentUserId);
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		ModelAndView modelAndViewObj = new ModelAndView();
		/* if(Role==-1)
			{
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("PaymentPostingTransLevelSearch");
				return modelAndViewObj;
			}*/
		//reportslogger.info("parent before:"+ PayPostingTransLevelDetailsObj.getParentUserId());
		/*int Role = ReportsDaoObj.getRole(PayPostingTransLevelDetailsObj
				.getParentUserId());*/

		//reportslogger.info("parent:"+ PayPostingTransLevelDetailsObj.getParentUserId());

		String fromDate = request.getParameter("startDate");
		String toDate = request.getParameter("endDate");
		String mode = request.getParameter("mode");
		String refNo = request.getParameter("refNo");
		String userOLMId = request.getParameter("userId");
		String fileId = request.getParameter("fileId");
		String fileName = request.getParameter("fileName");
		String vendorId = request.getParameter("vendorId");
		reportslogger.info("To date : " +toDate );
		reportslogger.info("From date : " +fromDate);
		reportslogger.info("User ID : "+userOLMId );
		reportslogger.info("Vendor ID :"+ vendorId);
		reportslogger.info("Reference No. : " + refNo);
		reportslogger.info("mode:  " + mode);
		reportslogger.info("File Id: "+fileId );
		reportslogger.info("File name:" +fileName);

		if (fromDate != "") {
			PayPostingTransLevelDetailsObjSearch.setFromDate(fromDate);
		} else

			PayPostingTransLevelDetailsObjSearch.setFromDate(null);

		if (toDate != "") {
			PayPostingTransLevelDetailsObjSearch.setToDate(toDate);
		} else

			PayPostingTransLevelDetailsObjSearch.setToDate(null);

		if (mode != null && mode.equalsIgnoreCase("ALL")) {
			PayPostingTransLevelDetailsObjSearch.setMode("");
		} else {
			PayPostingTransLevelDetailsObjSearch.setMode(mode);
		}

		if (vendorId == null || vendorId.equals("")) {
			PayPostingTransLevelDetailsObjSearch.setVendorId(null);
		} else
			PayPostingTransLevelDetailsObjSearch.setVendorId(vendorId.trim());

		if (refNo == null || refNo.equals("")) {
			PayPostingTransLevelDetailsObjSearch.setRefNo(null);
		} else
			PayPostingTransLevelDetailsObjSearch.setRefNo(refNo.trim());

		if (fileId == null || fileId.equals("")) {
			PayPostingTransLevelDetailsObjSearch.setFileId(null);

		} else
			PayPostingTransLevelDetailsObjSearch.setFileId(fileId.trim());

		if (fileName == null || fileName.equals("")) {
			PayPostingTransLevelDetailsObjSearch.setFileName(null);
		} else
			PayPostingTransLevelDetailsObjSearch.setFileName(fileName.trim());
		if (userOLMId == null || userOLMId.equals("")) {
			PayPostingTransLevelDetailsObjSearch.setChildUserId(null);
		} else
			PayPostingTransLevelDetailsObjSearch.setChildUserId(userOLMId.trim());

		/*reportslogger.info("todate:"
				+ PayPostingTransLevelDetailsObj.getToDate());
		reportslogger.info("from date:"
				+ PayPostingTransLevelDetailsObj.getFromDate());
		reportslogger.info("user id:"
				+ PayPostingTransLevelDetailsObj.getChildUserId());
		reportslogger.info("vendor id:"
				+ PayPostingTransLevelDetailsObj.getVendorId());
		reportslogger.info("ref no:"
				+ PayPostingTransLevelDetailsObj.getRefNo());
		reportslogger.info("mode:" + PayPostingTransLevelDetailsObj.getMode());
		reportslogger.info("file id:"
				+ PayPostingTransLevelDetailsObj.getFileId());
		reportslogger.info("file name:"
				+ PayPostingTransLevelDetailsObj.getFileName());*/

		HashMap<Integer, List<PayPostingTransLevelDetails>> ReportsMap = new HashMap<Integer, List<PayPostingTransLevelDetails>>();
		int page = 1;
		String errMsg = null;
		List<String> modeList = ReportsDaoObj.returnModeList();
		if(modeList==null)
		{
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentPostingTransLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Modes List size in Controller: "+modeList.size());
		modelAndViewObj.addObject("modeList", modeList);

		ReportsMap = ReportsDaoObj.getPaymntPostingTranslevelMap(
				PayPostingTransLevelDetailsObjSearch, page);

		if(ReportsMap==null)
		{	modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
		modelAndViewObj.addObject("UserRole", Role);
		modelAndViewObj.setViewName("PaymentPostingTransLevelSearch");
		return modelAndViewObj;
		}
		reportslogger.info("Details Map Size based on Search Criteria in Controller: "+ReportsMap.size());


		/*reportslogger.info("method called in controller");

		reportslogger.info("status msg in controller:"
				+ PayPostingTransLevelDetailsObj.getStatusMsg());*/
		if(PayPostingTransLevelDetailsObjSearch.getStatusMsg()!=null)
		{

			if(PayPostingTransLevelDetailsObjSearch.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				errMsg="";
			}

			else
			{
				errMsg=PayPostingTransLevelDetailsObjSearch.getStatusMsg();
			}

		}
		else
			errMsg="Connectivity Issues..Retry..";



		modelAndViewObj.addObject("modeList", modeList);
		modelAndViewObj.addObject("errMsg", errMsg);
		modelAndViewObj.addObject("ReportsMap", ReportsMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("UserRole", Role);
		modelAndViewObj.addObject("PayPostingTransLevelDetailsObjJsp", PayPostingTransLevelDetailsObjSearch);
		modelAndViewObj.setViewName("PaymentPostingTransLevelSearch");

		//	reportslogger.info("end of search controller");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/viewRecordswithPaginationPayPostingTransLevel")
	public ModelAndView viewRecordswithPagination(HttpServletRequest request,
			HttpServletResponse response) {
		session=request.getSession(false);
		PayPostingTransLevelDetails PayPostingTransLevelDetailsObjPag = new PayPostingTransLevelDetails();
		reportslogger.info("In Payment Posting Transaction Level Pagination");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		PayPostingTransLevelDetailsObjPag.setParentUserId(parentUserId);
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);




		String fromDate = request.getParameter("startDate");
		String toDate = request.getParameter("endDate");
		String mode = request.getParameter("mode");
		String refNo = request.getParameter("refNo");
		String userOLMId = request.getParameter("userId");
		String fileId = request.getParameter("fileId");
		String fileName = request.getParameter("fileName");
		String vendorId = request.getParameter("vendorId");
		reportslogger.info("To date : " +toDate );
		reportslogger.info("From date : " +fromDate);
		reportslogger.info("User ID : "+userOLMId );
		reportslogger.info("Vendor ID :"+ vendorId);
		reportslogger.info("Reference No. : " + refNo);
		reportslogger.info("mode:  " + mode);
		reportslogger.info("File Id: "+fileId );
		reportslogger.info("File name:" +fileName);

		if (fromDate != "") {
			PayPostingTransLevelDetailsObjPag.setFromDate(fromDate);
		} else

			PayPostingTransLevelDetailsObjPag.setFromDate(null);

		if (toDate != "") {
			PayPostingTransLevelDetailsObjPag.setToDate(toDate);
		} else

			PayPostingTransLevelDetailsObjPag.setToDate(null);

		if (mode != null && mode.equalsIgnoreCase("ALL")) {
			PayPostingTransLevelDetailsObjPag.setMode("");
		} else {
			PayPostingTransLevelDetailsObjPag.setMode(mode);
		}

		if (vendorId == null || vendorId.equals("")) {
			PayPostingTransLevelDetailsObjPag.setVendorId(null);
		} else
			PayPostingTransLevelDetailsObjPag.setVendorId(vendorId.trim());

		if (refNo == null || refNo.equals("")) {
			PayPostingTransLevelDetailsObjPag.setRefNo(null);
		} else
			PayPostingTransLevelDetailsObjPag.setRefNo(refNo.trim());

		if (fileId == null || fileId.equals("")) {
			PayPostingTransLevelDetailsObjPag.setFileId(null);

		} else
			PayPostingTransLevelDetailsObjPag.setFileId(fileId.trim());

		if (fileName == null || fileName.equals("")) {
			PayPostingTransLevelDetailsObjPag.setFileName(null);
		} else
			PayPostingTransLevelDetailsObjPag.setFileName(fileName.trim());
		if (userOLMId == null || userOLMId.equals("")) {
			PayPostingTransLevelDetailsObjPag.setChildUserId(null);
		} else
			PayPostingTransLevelDetailsObjPag.setChildUserId(userOLMId.trim());
		/*int Role = ReportsDaoObj.getRole(PayPostingTransLevelDetailsObj
				.getParentUserId());*/
		HashMap<Integer, List<PayPostingTransLevelDetails>> ReportsMap = new HashMap<Integer, List<PayPostingTransLevelDetails>>();
		int page = Integer.parseInt(request.getParameter("pageNum"));
		reportslogger.info("Page No. " +page);
		ModelAndView modelAndViewObj = new ModelAndView();
		String errMsg = null;
		List<String> modeList = ReportsDaoObj.returnModeList();
		if(modeList==null)
		{
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentPostingTransLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Modes List size in Controller: "+modeList.size());
		modelAndViewObj.addObject("modeList", modeList);

		ReportsMap = ReportsDaoObj.getPaymntPostingTranslevelMap(
				PayPostingTransLevelDetailsObjPag, page);

		if(ReportsMap==null)
		{
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentPostingTransLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Deatils Map size based on Page No. in controller: "+ReportsMap.size());

		/*	reportslogger.info("pagtn called in controller");

		reportslogger.info("status msg in controller"
				+ PayPostingTransLevelDetailsObj.getStatusMsg());*/
		if(PayPostingTransLevelDetailsObjPag.getStatusMsg()!=null)
		{

			if(PayPostingTransLevelDetailsObjPag.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				errMsg="";
			}

			else
			{
				errMsg=PayPostingTransLevelDetailsObjPag.getStatusMsg();
			}

		}
		else
			errMsg="Connectivity Issues..Retry..";


		modelAndViewObj.addObject("modeList", modeList);
		modelAndViewObj.addObject("errMsg", errMsg);
		modelAndViewObj.addObject("ReportsMap", ReportsMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("UserRole", Role);
		modelAndViewObj.addObject("PayPostingTransLevelDetailsObjJsp", PayPostingTransLevelDetailsObjPag);
		modelAndViewObj.setViewName("PaymentPostingTransLevelSearch");
		//	reportslogger.info("end of pagination");
		return modelAndViewObj;
	}

	/* <-------------export to excel-----------------> */

	@RequestMapping(value = "/viewPayPostingTransLevelExcel", method = RequestMethod.POST)
	public ModelAndView PayPostTansToExcel(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		session=request.getSession(false);
		PayPostingTransLevelDetails PayPostingTransLevelDetailsObjExcel = new PayPostingTransLevelDetails();

		reportslogger.info(" In Payment Posting Transaction level Excel Download ");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		PayPostingTransLevelDetailsObjExcel.setParentUserId(parentUserId);
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);
		String fromDate = request.getParameter("startDate");
		String toDate = request.getParameter("endDate");
		String mode = request.getParameter("mode");
		String refNo = request.getParameter("refNo");
		String userOLMId = request.getParameter("userId");
		String fileId = request.getParameter("fileId");
		String fileName = request.getParameter("fileName");
		String vendorId = request.getParameter("vendorId");
		reportslogger.info("To date : " +toDate );
		reportslogger.info("From date : " +fromDate);
		reportslogger.info("User ID : "+userOLMId );
		reportslogger.info("Vendor ID :"+ vendorId);
		reportslogger.info("Reference No. : " + refNo);
		reportslogger.info("mode:  " + mode);
		reportslogger.info("File Id: "+fileId );
		reportslogger.info("File name:" +fileName);

		if (fromDate != "") {
			PayPostingTransLevelDetailsObjExcel.setFromDate(fromDate);
		} else

			PayPostingTransLevelDetailsObjExcel.setFromDate(null);

		if (toDate != "") {
			PayPostingTransLevelDetailsObjExcel.setToDate(toDate);
		} else

			PayPostingTransLevelDetailsObjExcel.setToDate(null);

		if (mode != null && mode.equalsIgnoreCase("ALL")) {
			PayPostingTransLevelDetailsObjExcel.setMode("");
		} else {
			PayPostingTransLevelDetailsObjExcel.setMode(mode);
		}

		if (vendorId == null || vendorId.equals("")) {
			PayPostingTransLevelDetailsObjExcel.setVendorId(null);
		} else
			PayPostingTransLevelDetailsObjExcel.setVendorId(vendorId.trim());

		if (refNo == null || refNo.equals("")) {
			PayPostingTransLevelDetailsObjExcel.setRefNo(null);
		} else
			PayPostingTransLevelDetailsObjExcel.setRefNo(refNo.trim());

		if (fileId == null || fileId.equals("")) {
			PayPostingTransLevelDetailsObjExcel.setFileId(null);

		} else
			PayPostingTransLevelDetailsObjExcel.setFileId(fileId.trim());

		if (fileName == null || fileName.equals("")) {
			PayPostingTransLevelDetailsObjExcel.setFileName(null);
		} else
			PayPostingTransLevelDetailsObjExcel.setFileName(fileName.trim());
		if (userOLMId == null || userOLMId.equals("")) {
			PayPostingTransLevelDetailsObjExcel.setChildUserId(null);
		} else
			PayPostingTransLevelDetailsObjExcel.setChildUserId(userOLMId.trim());
		int Role=Integer.parseInt(sessionRole_string);


		String pageNum = null;

		List<PayPostingTransLevelDetails> PayPostExportToExcelList = new ArrayList<PayPostingTransLevelDetails>();
		List<String> modeList = ReportsDaoObj.returnModeList();
		if(modeList==null)
		{
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentPostingTransLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Modes List size in Controller: "+modeList.size());
		modelAndViewObj.addObject("modeList", modeList);

		PayPostExportToExcelList = ReportsDaoObj
				.getPayPostTransactionExcelList(PayPostingTransLevelDetailsObjExcel,
						pageNum);
		if(PayPostExportToExcelList==null)
		{
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentPostingTransLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info(" Excel records list size in Controller: "+PayPostExportToExcelList.size());
		int rowNumber = 1;
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("Payment_Posting_Trans_Level");
		XSSFCell cell = null;
		XSSFRow row;
		XSSFCellStyle my_style = wb.createCellStyle();
		XSSFFont my_font=wb.createFont();
		my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		my_style.setFont(my_font);
		XSSFCellStyle rightAligned = wb.createCellStyle();
		rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);

		row = sheet.createRow(0);
		cell = row.createCell(0);
		cell.setCellValue("Reference No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(1);
		cell.setCellValue("Bank Account No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(2);
		cell.setCellValue("Vendor ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(3);
		cell.setCellValue("Vendor Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(4);
		cell.setCellValue("Uploaded By(OLM ID)");
		cell.setCellStyle(my_style);
		cell = row.createCell(5);
		cell.setCellValue("File ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(6);
		cell.setCellValue("File Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(7);
		cell.setCellValue("File Source");
		cell.setCellStyle(my_style);
		cell = row.createCell(8);
		cell.setCellValue("Mode");
		cell.setCellStyle(my_style);
		cell = row.createCell(9);
		cell.setCellValue("Uploaded Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(10);
		cell.setCellValue("Approved/Rejected By(OLM ID)");
		cell.setCellStyle(my_style);
		cell = row.createCell(11);
		cell.setCellValue("Approved/Rejected Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(12);
		cell.setCellValue("LOB");
		cell.setCellStyle(my_style);

		cell = row.createCell(13);
		cell.setCellValue("Account No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(14);
		cell.setCellValue("Invoice");
		cell.setCellStyle(my_style);
		cell = row.createCell(15);
		cell.setCellValue("Amount");
		cell.setCellStyle(my_style);
		cell = row.createCell(16);
		cell.setCellValue("Status");
		cell.setCellStyle(my_style);
		cell = row.createCell(17);
		cell.setCellValue("FX Posting Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(18);
		cell.setCellValue("Tracking ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(19);
		cell.setCellValue("Tracking ID Serv");
		cell.setCellStyle(my_style);
		cell = row.createCell(20);
		cell.setCellValue("Reason For Failure/LIU ");
		cell.setCellStyle(my_style);

		for (int i = 0; i < PayPostExportToExcelList.size(); i++) {
			// reportslogger.info("i value"+i);
			PayPostingTransLevelDetails PayPostingTransLevelDetailsObject = PayPostExportToExcelList
					.get(i);

			row = sheet.createRow(rowNumber);
			cell = row.createCell(0);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getRefNo());
			cell = row.createCell(1);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getBankAccNo());
			//sheet.autoSizeColumn(0);

			cell = row.createCell(2);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getVendorId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(1);
			cell = row.createCell(3);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getVendorName());
			//sheet.autoSizeColumn(2);

			cell = row.createCell(4);
			cell.setCellValue(PayPostingTransLevelDetailsObject
					.getChildUserId());
			//sheet.autoSizeColumn(3);
			cell = row.createCell(5);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getFileId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(4);

			cell = row.createCell(6);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getFileName());
			//sheet.autoSizeColumn(5);
			cell = row.createCell(7);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getFileSource());
			//sheet.autoSizeColumn(6);

			cell = row.createCell(8);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getMode());
			//sheet.autoSizeColumn(7);
			cell = row.createCell(9);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getUploadTime());
			//sheet.autoSizeColumn(8);
			cell = row.createCell(10);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getApprovedBy());
			//sheet.autoSizeColumn(9);
			cell = row.createCell(11);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getApprovedDate());
			cell = row.createCell(12);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getLob());
			//sheet.autoSizeColumn(10);

			cell = row.createCell(13);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getAccountNo());
			//sheet.autoSizeColumn(11);
			cell = row.createCell(14);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getInvoice());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(12);

			cell = row.createCell(15);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getTotalVal());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(13);
			cell = row.createCell(16);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getStatus());
			//sheet.autoSizeColumn(14);
			cell = row.createCell(17);
			cell.setCellValue(PayPostingTransLevelDetailsObject
					.getFXpostingTime());
			//sheet.autoSizeColumn(15);

			cell = row.createCell(18);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getTrackingId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(16);
			cell = row.createCell(19);
			cell.setCellValue(PayPostingTransLevelDetailsObject
					.getTrackingIdServ());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(17);
			cell = row.createCell(20);
			cell.setCellValue(PayPostingTransLevelDetailsObject
					.getReasonForLiuorFailure());
			//sheet.autoSizeColumn(18);
			rowNumber++;
			//reportslogger.info("row number in getPayPostTransactionExcelList" +rowNumber);
		}
		for (int i = 0; i <= 20; i++) {

			sheet.autoSizeColumn(i);
		}

		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		byte[] outArray = outByteStream.toByteArray();
		//reportslogger.info("out arrray" +outArray);
		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
				.format(new Date());

		String fileName1 = "APS_Payment_Posting_Transaction_Level_"+ date + ".xlsx";
		reportslogger.info("filename is" + fileName1);

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName1);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();

			outStream.close();
			outByteStream.close();

		} catch (IOException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}

		reportslogger.info("End of payment Posting Transaction Excel records download "); 

		return modelAndViewObj;

	}

	/************************* PAYMENT POSTING TRANSACTION LEVEL REPORT ENDS*******************************/

	/***************************************** PAYMENT POSTING VENDOR SUMMARY **************************/

	/*@RequestMapping(value = "/payPostingVendorsummary")
	public ModelAndView payPostingVendorsummary() {
		reportslogger.info("In Payment Posting Vendor Level Controller");
		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("PaymentPostingVendorLogin");
		return modelAndViewObj;
	}*/

	@RequestMapping(value = "/getPayPostingVendorRole", method = RequestMethod.GET)
	public ModelAndView getRole(HttpServletRequest request,
			HttpServletResponse response) {
		// session=request.getSession(false);
		session=request.getSession(false);
		reportslogger.info("In Payment Posting Vendor Level Controller");

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		ModelAndView modelAndViewObj = new ModelAndView();
		PayPostingVendorDetails PayPostingVendorDetailsObj = new PayPostingVendorDetails();

		//String parentUserId = request.getParameter("UserId");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User Id: "+parentUserId);
		/* Role = ReportsDaoObj.getRole(parentUserId);
		 if(Role==-1)
			{
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("PaymentPostingVendorSearch");
				return modelAndViewObj;
			}
		 */
		reportslogger.info("User Role: " + Role);

		if ((Role == 1) || (Role == 2) || (Role == 3) || (Role == 4)
				|| (Role == 7)) {

			PayPostingVendorDetailsObj.setParentUserId(parentUserId);
			/*PayPostingVendorDetailsObj.setRole(Role);*/
			PayPostingVendorDetailsObj.setToDate(null);
			PayPostingVendorDetailsObj.setFromDate(null);
			PayPostingVendorDetailsObj.setVendorId(null);
			// call method from dao and get records based on parentuserId only.
			int page = 1;
			String errMsg = null;

			HashMap<Integer, List<PayPostingVendorDetails>> ReportsMap = new HashMap<Integer, List<PayPostingVendorDetails>>();

			// set statusmsg in daoimpl
			//			reportslogger.info("error msg:"
			//					+ PayPostingVendorDetailsObj.getStatusMsg());

			ReportsMap = ReportsDaoObj.getVendorSummaryMap(
					PayPostingVendorDetailsObj, page);

			if(ReportsMap==null){
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("UserRole", Role);
				modelAndViewObj.setViewName("PaymentPostingVendorSearch");
				return modelAndViewObj;
			}
			reportslogger.info("Details Map size in Controller: "+ReportsMap.size());

			if(PayPostingVendorDetailsObj.getStatusMsg()!=null)
			{

				if(PayPostingVendorDetailsObj.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
				{
					errMsg="";
				}

				else
				{
					errMsg=PayPostingVendorDetailsObj.getStatusMsg();
				}

			}
			else
				errMsg="Connectivity Issues..Retry..";

			modelAndViewObj.addObject("ReportsMap", ReportsMap);
			modelAndViewObj.addObject("errMsg", errMsg);
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.setViewName("PaymentPostingVendorSearch");
		}

		else {
			modelAndViewObj.addObject("error",
					"You do not have privilige to check the reports !!");
			modelAndViewObj.setViewName("PaymentPostingVendorSearch");
			return modelAndViewObj;
		}

		return modelAndViewObj;
	}

	@RequestMapping(value = "/getFilteredPayPostingVendorSummary")
	public ModelAndView getFilteredPayPostingVendorSummary(
			HttpServletRequest request, HttpServletResponse response) {
		// session=request.getSession(false);
		session=request.getSession(false);

		reportslogger.info("In payment Posting Vendor Level Search");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		PayPostingVendorDetails PayPostingVendorDetailsObjSearch = new PayPostingVendorDetails();

		PayPostingVendorDetailsObjSearch.setParentUserId(parentUserId);
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		ModelAndView modelAndViewObj = new ModelAndView();
		/*int Role = ReportsDaoObj.getRole(PayPostingVendorDetailsObj
				.getParentUserId());*/
		/*if(Role==-1)
			{
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("PaymentPostingVendorSearch");
				return modelAndViewObj;
			}*/
		int page = 1;
		String errMsg = null;
		String vendorId = request.getParameter("vendorId");
		String toDate = request.getParameter("endDate");

		String fromDate = request.getParameter("startDate");
		reportslogger.info("Vendor ID: " + vendorId);
		reportslogger.info(" To date: " + toDate);
		reportslogger.info("From Date: " + fromDate);
		if ((vendorId != "" && vendorId != null)) {

			PayPostingVendorDetailsObjSearch.setVendorId(vendorId.trim());

		} else
			PayPostingVendorDetailsObjSearch.setVendorId(null);

		if ((toDate != "")) {
			PayPostingVendorDetailsObjSearch.setToDate(toDate);
		} else
			PayPostingVendorDetailsObjSearch.setToDate(null);

		if ((fromDate != "")) {
			PayPostingVendorDetailsObjSearch.setFromDate(fromDate);

		} else
			PayPostingVendorDetailsObjSearch.setFromDate(null);

		/*reportslogger.info("todate:" + PayPostingVendorDetailsObj.getToDate());
		reportslogger.info("fromdate:"
				+ PayPostingVendorDetailsObj.getFromDate());
		reportslogger.info("vendor id:"
				+ PayPostingVendorDetailsObj.getVendorId());*/

		HashMap<Integer, List<PayPostingVendorDetails>> ReportsMapwithFilter = new HashMap<Integer, List<PayPostingVendorDetails>>();

		// set statusmsg in daoimpl

		ReportsMapwithFilter = ReportsDaoObj.getVendorSummaryMap(
				PayPostingVendorDetailsObjSearch, page);

		if(ReportsMapwithFilter==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentPostingVendorSearch");
			return modelAndViewObj;
		}

		reportslogger.info("Deatils map size based on search criteria in Controller: " + ReportsMapwithFilter.size());

		if(PayPostingVendorDetailsObjSearch.getStatusMsg()!=null)
		{

			if(PayPostingVendorDetailsObjSearch.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				errMsg="";
			}

			else
			{
				errMsg=PayPostingVendorDetailsObjSearch.getStatusMsg();
			}

		}
		else
			errMsg="Connectivity Issues..Retry..";


		modelAndViewObj.addObject("ReportsMap", ReportsMapwithFilter);
		modelAndViewObj.addObject("PayPostingVendorDetailsObjJsp",PayPostingVendorDetailsObjSearch);
		modelAndViewObj.addObject("UserRole", Role);
		modelAndViewObj.addObject("errMsg", errMsg);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.setViewName("PaymentPostingVendorSearch");

		return modelAndViewObj;
	}

	@RequestMapping(value = "/getPayPostingVendorSummaryWithPagination")
	public ModelAndView getFilteredVendorSummaryWithPagination(
			HttpServletRequest request, HttpServletResponse response) {
		session=request.getSession(false);
		reportslogger.info("In Payment Posting Vendor level pagination ");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		PayPostingVendorDetails PayPostingVendorDetailsObjPag = new PayPostingVendorDetails();

		PayPostingVendorDetailsObjPag.setParentUserId(parentUserId);
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		ModelAndView modelAndViewObj = new ModelAndView();
		String errMsg = null;

		String vendorId = request.getParameter("vendorId");
		String toDate = request.getParameter("endDate");

		String fromDate = request.getParameter("startDate");
		reportslogger.info("Vendor ID: " + vendorId);
		reportslogger.info(" To date: " + toDate);
		reportslogger.info("From Date: " + fromDate);
		if ((vendorId != "" && vendorId != null)) {

			PayPostingVendorDetailsObjPag.setVendorId(vendorId.trim());

		} else
			PayPostingVendorDetailsObjPag.setVendorId(null);

		if ((toDate != "")) {
			PayPostingVendorDetailsObjPag.setToDate(toDate);
		} else
			PayPostingVendorDetailsObjPag.setToDate(null);

		if ((fromDate != "")) {
			PayPostingVendorDetailsObjPag.setFromDate(fromDate);

		} else
			PayPostingVendorDetailsObjPag.setFromDate(null);


		int page = Integer.parseInt(request.getParameter("pageNum"));
		reportslogger.info("Page No. "+page);

		HashMap<Integer, List<PayPostingVendorDetails>> ReportsMapwithFilterwithPagination = new HashMap<Integer, List<PayPostingVendorDetails>>();

		ReportsMapwithFilterwithPagination = ReportsDaoObj.getVendorSummaryMap(
				PayPostingVendorDetailsObjPag, page);

		if(ReportsMapwithFilterwithPagination==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentPostingVendorSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Details map List based on page No. in Controller: "+ ReportsMapwithFilterwithPagination.size());

		if(PayPostingVendorDetailsObjPag.getStatusMsg()!=null)
		{

			if(PayPostingVendorDetailsObjPag.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				errMsg="";
			}

			else
			{
				errMsg=PayPostingVendorDetailsObjPag.getStatusMsg();
			}

		}
		else
			errMsg="Connectivity Issues..Retry..";


		modelAndViewObj.addObject("ReportsMap",
				ReportsMapwithFilterwithPagination);
		modelAndViewObj.addObject("UserRole", Role);
		modelAndViewObj.addObject("errMsg", errMsg);
		modelAndViewObj.addObject("PayPostingVendorDetailsObjJsp",PayPostingVendorDetailsObjPag);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.setViewName("PaymentPostingVendorSearch");

		return modelAndViewObj;
	}

	@RequestMapping(value = "/PayPostingVendorSummaryToExcel", method = RequestMethod.POST)
	public ModelAndView PayPostingVendorSummaryToExcel(HttpServletRequest request, HttpServletResponse response) 
	{
		ModelAndView modelAndViewObj = new ModelAndView();
		session=request.getSession(false);
		PayPostingVendorDetails PayPostingVendorDetailsObjExcel = new PayPostingVendorDetails();

		reportslogger.info("Payment Posting Vendor Level Excel Records download");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		PayPostingVendorDetailsObjExcel.setParentUserId(parentUserId);
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		String vendorId = request.getParameter("vendorId");
		String toDate = request.getParameter("endDate");

		String fromDate = request.getParameter("startDate");
		reportslogger.info("Vendor ID: " + vendorId);
		reportslogger.info(" To date: " + toDate);
		reportslogger.info("From Date: " + fromDate);
		if ((vendorId != "" && vendorId != null)) {

			PayPostingVendorDetailsObjExcel.setVendorId(vendorId.trim());

		} else
			PayPostingVendorDetailsObjExcel.setVendorId(null);

		if ((toDate != "")) {
			PayPostingVendorDetailsObjExcel.setToDate(toDate);
		} else
			PayPostingVendorDetailsObjExcel.setToDate(null);

		if ((fromDate != "")) {
			PayPostingVendorDetailsObjExcel.setFromDate(fromDate);

		} else
			PayPostingVendorDetailsObjExcel.setFromDate(null);

		int Role=Integer.parseInt(sessionRole_string);


		String pageNum = "";

		List<PayPostingVendorDetails> PayPostExportToExcelList = new ArrayList<PayPostingVendorDetails>();

		PayPostExportToExcelList = ReportsDaoObj.getVendorSummaryExcelList(
				PayPostingVendorDetailsObjExcel, pageNum);

		if(PayPostExportToExcelList==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentPostingVendorSearch");
			return modelAndViewObj;
		}
		reportslogger.info(" Excel Records list Size in Controller: "+PayPostExportToExcelList.size());
		int rowNumber = 1;
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("Payment_Posting_Vendor_Level");
		XSSFCell cell = null;
		XSSFRow row;
		XSSFCellStyle my_style = wb.createCellStyle();
		XSSFFont my_font=wb.createFont();
		my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		my_style.setFont(my_font);
		XSSFCellStyle rightAligned = wb.createCellStyle();
		rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);

		row = sheet.createRow(0);
		cell = row.createCell(0);
		cell.setCellValue("Vendor ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(1);
		cell.setCellValue("Vendor Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(2);
		cell.setCellValue("Total Records");
		cell.setCellStyle(my_style);
		cell = row.createCell(3);
		cell.setCellValue("Total Value");
		cell.setCellStyle(my_style);
		cell = row.createCell(4);
		cell.setCellValue("In Progress Records");
		cell.setCellStyle(my_style);
		cell = row.createCell(5);
		cell.setCellValue("In Progress Value");
		cell.setCellStyle(my_style);
		cell = row.createCell(6);
		cell.setCellValue("Rejected Records");
		cell.setCellStyle(my_style);
		cell = row.createCell(7);
		cell.setCellValue("Rejected Records Value");
		cell.setCellStyle(my_style);
		cell = row.createCell(8);
		cell.setCellValue("Records Pushed To FX");
		cell.setCellStyle(my_style);
		cell = row.createCell(9);
		cell.setCellValue("Value Pushed To FX");
		cell.setCellStyle(my_style);
		cell = row.createCell(10);
		cell.setCellValue("Records Pending At LIU");
		cell.setCellStyle(my_style);
		cell = row.createCell(11);
		cell.setCellValue("Value Pending At LIU");
		cell.setCellStyle(my_style);
		cell = row.createCell(12);
		cell.setCellValue("Records Deleted At LIU");
		cell.setCellStyle(my_style);
		cell = row.createCell(13);
		cell.setCellValue("Value Deleted At LIU");
		cell.setCellStyle(my_style);

		for (int i = 0; i < PayPostExportToExcelList.size(); i++) {
			// reportslogger.info("i value"+i);
			PayPostingVendorDetails PayPostingVendorDetailsObject = PayPostExportToExcelList
					.get(i);

			row = sheet.createRow(rowNumber);
			cell = row.createCell(0);
			cell.setCellValue(PayPostingVendorDetailsObject.getVendorId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(0);

			cell = row.createCell(1);
			cell.setCellValue(PayPostingVendorDetailsObject.getVendorName());
			//sheet.autoSizeColumn(1);
			cell = row.createCell(2);
			cell.setCellValue(PayPostingVendorDetailsObject.getTotalRec());
			//sheet.autoSizeColumn(2);

			cell = row.createCell(3);
			cell.setCellValue(PayPostingVendorDetailsObject.getTotalVal());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(3);
			cell = row.createCell(4);
			cell.setCellValue(PayPostingVendorDetailsObject.getInProgressRecords());
			cell = row.createCell(5);
			cell.setCellValue(PayPostingVendorDetailsObject.getInProgressValue());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(4);
			cell = row.createCell(6);
			cell.setCellValue(PayPostingVendorDetailsObject.getRejectedRecords());
			cell = row.createCell(7);
			cell.setCellValue(PayPostingVendorDetailsObject.getRejectedValue());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(5);
			cell = row.createCell(8);
			cell.setCellValue(PayPostingVendorDetailsObject.getRecPostedFX());
			//sheet.autoSizeColumn(6);

			cell = row.createCell(9);
			cell.setCellValue(PayPostingVendorDetailsObject.getValuePostedFX());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(7);
			cell = row.createCell(10);
			cell.setCellValue(PayPostingVendorDetailsObject
					.getRecPendingAtLIU());
			//sheet.autoSizeColumn(8);

			cell = row.createCell(11);
			cell.setCellValue(PayPostingVendorDetailsObject
					.getAmountPendingAtLIU());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(9);
			cell = row.createCell(12);
			cell.setCellValue(PayPostingVendorDetailsObject
					.getRecDeletedAtLiu());
			//sheet.autoSizeColumn(10);

			cell = row.createCell(13);
			cell.setCellValue(PayPostingVendorDetailsObject
					.getValueDeletedAtLiu());
			cell.setCellStyle(rightAligned);

			rowNumber++;

		}
		for (int i = 0; i <= 13; i++) {
			sheet.autoSizeColumn(i);
		}
		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		byte[] outArray = outByteStream.toByteArray();

		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
				.format(new Date());

		String fileName = "APS_Payment_Posting_Vendor_Level_"+ date + ".xlsx";
		//	reportslogger.info("filename is" + fileName);

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}

		reportslogger.info("End of Payment Posting Excel Records Download "); 

		return modelAndViewObj;

	}

	/***************************************** PAYMENT POSTING VENDOR SUMMARY ENDS **************************/

	/********************************************* PAYMENT POSTING CHEQUE LEVEL ***************************************/
	/*@RequestMapping(value = "/PayPostingChequeLevel")
	public ModelAndView PayPostingChequeLevel() {
		reportslogger.info("In Payment Posting Cheque level Controller");
		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("PaymentPostingChequeLogin");
		return modelAndViewObj;
	}*/

	@RequestMapping(value = "/getPayPostingChequeRole", method = RequestMethod.GET)
	public ModelAndView getPayPostingChequeRole(HttpServletRequest request,HttpServletResponse response) 
	{
		// session=request.getSession(false);
		session=request.getSession(false);
		PayPostingChequeDetails PyPostChequeDetailsObj = new PayPostingChequeDetails();
		reportslogger.info("In Payment Posting Cheque level Controller");
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);

		//	reportslogger.info("in controller to get  role.");

		ModelAndView modelAndViewObj = new ModelAndView();

		//String parentUserId = request.getParameter("UserId");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		/*Role = ReportsDaoObj.getRole(parentUserId);
		 if(Role==-1)
			{
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("PaymentPostingChequeSearch");
				return modelAndViewObj;
			}*/

		reportslogger.info("User Role: " + Role);

		if ((Role == 1) || (Role == 2) || (Role == 3) || (Role == 4)
				|| (Role == 7)) {

			PyPostChequeDetailsObj.setParentUser(parentUserId);
			/*PyPostChequeDetailsObj.setRole(Role);*/
			PyPostChequeDetailsObj.setChqNo(null);
			PyPostChequeDetailsObj.setUserOLMId(null);
			PyPostChequeDetailsObj.setFileId(null);
			PyPostChequeDetailsObj.setFileName(null);
			PyPostChequeDetailsObj.setVendorId(null);
			PyPostChequeDetailsObj.setToDate(null);
			PyPostChequeDetailsObj.setFromDate(null);
			int page = 1;
			String errMsg = null;

			HashMap<Integer, List<PayPostingChequeDetails>> ReportsMap = new HashMap<Integer, List<PayPostingChequeDetails>>();
			ReportsMap = ReportsDaoObj.getPaymntPostingChequeMap(
					PyPostChequeDetailsObj, page);
			if(ReportsMap==null){
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("UserRole", Role);
				modelAndViewObj.setViewName("PaymentPostingChequeSearch");
				return modelAndViewObj;
			}
			reportslogger.info("Details map Size in Controller: " +ReportsMap.size());
			if(PyPostChequeDetailsObj.getStatusMsg()!=null)
			{

				if(PyPostChequeDetailsObj.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
				{
					errMsg="";
				}

				else
				{
					errMsg=PyPostChequeDetailsObj.getStatusMsg();
				}

			}
			else
				errMsg="Connectivity Issues..Retry..";


			modelAndViewObj.addObject("ReportsMap", ReportsMap);

			modelAndViewObj.addObject("errMsg", errMsg);

			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.addObject("currentPage", page);

			modelAndViewObj.setViewName("PaymentPostingChequeSearch");

		} else {

			modelAndViewObj.addObject("error",
					"You do not have privilige to check the reports !!");
			modelAndViewObj.setViewName("PaymentPostingChequeSearch");
			return modelAndViewObj;
		}

		return modelAndViewObj;

	}

	@RequestMapping(value = "/getPayPostingChequeRecordsOnFilter")
	public ModelAndView getPayPostingChequeRecordsOnFilter(HttpServletRequest request, HttpServletResponse response)
	{
		session=request.getSession(false);
		reportslogger.info("In Payment Posting Cheque level Search");
		PayPostingChequeDetails PyPostChequeDetailsObjSearch = new PayPostingChequeDetails();
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		PyPostChequeDetailsObjSearch.setParentUser(parentUserId);
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);

		ModelAndView modelAndViewObj = new ModelAndView();
		/* if(Role==-1)
			{
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("PaymentPostingChequeSearch");
				return modelAndViewObj;
			}
		 */
		/*	int Role = ReportsDaoObj.getRole(PyPostChequeDetailsObj.getParentUser());*/

		String fromDate = request.getParameter("startDate");
		String toDate = request.getParameter("endDate");
		String chqNo = request.getParameter("chqNo");
		String userOLMId = request.getParameter("userId");
		String fileId = request.getParameter("fileId");
		String fileName = request.getParameter("fileName");
		String vendorId = request.getParameter("vendorId");
		reportslogger.info("From Date:" + fromDate);
		reportslogger.info(" To Date: " + toDate);
		reportslogger.info("Cheque No.: " + chqNo);
		reportslogger.info("User ID: " +userOLMId );
		reportslogger.info(" File ID: " +fileId );
		reportslogger.info(" File Name: " +fileName );
		reportslogger.info(" Vendor ID: " + vendorId);

		if (fromDate != "") {
			PyPostChequeDetailsObjSearch.setFromDate(fromDate);
		} else

			PyPostChequeDetailsObjSearch.setFromDate(null);

		if (toDate != "") {
			PyPostChequeDetailsObjSearch.setToDate(toDate);
		} else

			PyPostChequeDetailsObjSearch.setToDate(null);

		if (vendorId == null || vendorId.equals("")) {
			PyPostChequeDetailsObjSearch.setVendorId(null);
		} else
			PyPostChequeDetailsObjSearch.setVendorId(vendorId.trim());

		if (chqNo == null || chqNo.equals("")) {
			PyPostChequeDetailsObjSearch.setChqNo(null);
		} else
			PyPostChequeDetailsObjSearch.setChqNo(chqNo.trim());

		if (fileId == null || fileId.equals("")) {
			PyPostChequeDetailsObjSearch.setFileId(null);

		} else
			PyPostChequeDetailsObjSearch.setFileId(fileId.trim());

		if (fileName == null || fileName.equals("")) {
			PyPostChequeDetailsObjSearch.setFileName(null);
		} else
			PyPostChequeDetailsObjSearch.setFileName(fileName.trim());
		if (userOLMId == null || userOLMId.equals("")) {
			PyPostChequeDetailsObjSearch.setUserOLMId(null);
		} else
			PyPostChequeDetailsObjSearch.setUserOLMId(userOLMId.trim());



		HashMap<Integer, List<PayPostingChequeDetails>> ReportsMap = new HashMap<Integer, List<PayPostingChequeDetails>>();
		int page = 1;
		String errMsg = null;


		ReportsMap = ReportsDaoObj.getPaymntPostingChequeMap(
				PyPostChequeDetailsObjSearch, page);
		if(ReportsMap==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentPostingChequeSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Details map Size based on search criteria in Controller: "+ReportsMap.size());

		if(PyPostChequeDetailsObjSearch.getStatusMsg()!=null)
		{

			if(PyPostChequeDetailsObjSearch.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				errMsg="";
			}

			else
			{
				errMsg=PyPostChequeDetailsObjSearch.getStatusMsg();
			}

		}
		else
			errMsg="Connectivity Issues..Retry..";




		modelAndViewObj.addObject("errMsg", errMsg);
		modelAndViewObj.addObject("ReportsMap", ReportsMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("PyPostChequeDetailsObjJsp", PyPostChequeDetailsObjSearch);
		modelAndViewObj.addObject("UserRole", Role);
		modelAndViewObj.setViewName("PaymentPostingChequeSearch");

		return modelAndViewObj;
	}

	@RequestMapping(value = "/viewPaginationofPayPostingChequeRecords")
	public ModelAndView viewPyPostingChequeRecordswithPagination(HttpServletRequest request, HttpServletResponse response) 
	{
		session=request.getSession(false);
		PayPostingChequeDetails PyPostChequeDetailsObjPag = new PayPostingChequeDetails();
		reportslogger.info("In Payment Posting Cheque Level Pagination");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		PyPostChequeDetailsObjPag.setParentUser(parentUserId);
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);




		String fromDate = request.getParameter("startDate");
		String toDate = request.getParameter("endDate");
		String chqNo = request.getParameter("chqNo");
		String userOLMId = request.getParameter("userId");
		String fileId = request.getParameter("fileId");
		String fileName = request.getParameter("fileName");
		String vendorId = request.getParameter("vendorId");
		reportslogger.info("From Date:" + fromDate);
		reportslogger.info(" To Date: " + toDate);
		reportslogger.info("Cheque No.: " + chqNo);
		reportslogger.info("User ID: " +userOLMId );
		reportslogger.info(" File ID: " +fileId );
		reportslogger.info(" File Name: " +fileName );
		reportslogger.info(" Vendor ID: " + vendorId);

		if (fromDate != "") {
			PyPostChequeDetailsObjPag.setFromDate(fromDate);
		} else

			PyPostChequeDetailsObjPag.setFromDate(null);

		if (toDate != "") {
			PyPostChequeDetailsObjPag.setToDate(toDate);
		} else

			PyPostChequeDetailsObjPag.setToDate(null);

		if (vendorId == null || vendorId.equals("")) {
			PyPostChequeDetailsObjPag.setVendorId(null);
		} else
			PyPostChequeDetailsObjPag.setVendorId(vendorId.trim());

		if (chqNo == null || chqNo.equals("")) {
			PyPostChequeDetailsObjPag.setChqNo(null);
		} else
			PyPostChequeDetailsObjPag.setChqNo(chqNo.trim());

		if (fileId == null || fileId.equals("")) {
			PyPostChequeDetailsObjPag.setFileId(null);

		} else
			PyPostChequeDetailsObjPag.setFileId(fileId.trim());

		if (fileName == null || fileName.equals("")) {
			PyPostChequeDetailsObjPag.setFileName(null);
		} else
			PyPostChequeDetailsObjPag.setFileName(fileName.trim());
		if (userOLMId == null || userOLMId.equals("")) {
			PyPostChequeDetailsObjPag.setUserOLMId(null);
		} else
			PyPostChequeDetailsObjPag.setUserOLMId(userOLMId.trim());


		/*int Role = ReportsDaoObj
				.getRole(PyPostChequeDetailsObj.getParentUser());*/
		HashMap<Integer, List<PayPostingChequeDetails>> ReportsMap = new HashMap<Integer, List<PayPostingChequeDetails>>();
		int page = Integer.parseInt(request.getParameter("pageNum"));
		String errMsg = null;
		ModelAndView modelAndViewObj = new ModelAndView();
		reportslogger.info("Page No. :"+page);

		ReportsMap = ReportsDaoObj.getPaymntPostingChequeMap(
				PyPostChequeDetailsObjPag, page);

		if(ReportsMap==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentPostingChequeSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Details Map size based on Page no. in Controller :"+ReportsMap.size());


		/*reportslogger.info("pagtn called in controller");

		reportslogger.info("status msg in controller"
				+ PyPostChequeDetailsObj.getStatusMsg());*/
		if(PyPostChequeDetailsObjPag.getStatusMsg()!=null)
		{

			if(PyPostChequeDetailsObjPag.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				errMsg="";
			}

			else
			{
				errMsg=PyPostChequeDetailsObjPag.getStatusMsg();
			}

		}
		else
			errMsg="Connectivity Issues..Retry..";

		modelAndViewObj.addObject("errMsg", errMsg);
		modelAndViewObj.addObject("ReportsMap", ReportsMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("PyPostChequeDetailsObjJsp", PyPostChequeDetailsObjPag);
		modelAndViewObj.addObject("UserRole", Role);
		modelAndViewObj.setViewName("PaymentPostingChequeSearch");

		return modelAndViewObj;
	}

	@RequestMapping(value = "/ExcelofPayPostChequeDetails", method = RequestMethod.POST)
	public ModelAndView PayPostChequeDetailsToExcel(HttpServletRequest request,HttpServletResponse response) 
	{
		ModelAndView modelAndViewObj = new ModelAndView();

		session=request.getSession(false);
		reportslogger.info("In Payment Posting Cheque Level Excel records Downlaod");
		PayPostingChequeDetails PyPostChequeDetailsObjExcel = new PayPostingChequeDetails();
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		PyPostChequeDetailsObjExcel.setParentUser(parentUserId);
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);
		String fromDate = request.getParameter("startDate");
		String toDate = request.getParameter("endDate");
		String chqNo = request.getParameter("chqNo");
		String userOLMId = request.getParameter("userId");
		String fileId = request.getParameter("fileId");
		String fileName = request.getParameter("fileName");
		String vendorId = request.getParameter("vendorId");
		reportslogger.info("From Date:" + fromDate);
		reportslogger.info(" To Date: " + toDate);
		reportslogger.info("Cheque No.: " + chqNo);
		reportslogger.info("User ID: " +userOLMId );
		reportslogger.info(" File ID: " +fileId );
		reportslogger.info(" File Name: " +fileName );
		reportslogger.info(" Vendor ID: " + vendorId);

		if (fromDate != "") {
			PyPostChequeDetailsObjExcel.setFromDate(fromDate);
		} else

			PyPostChequeDetailsObjExcel.setFromDate(null);

		if (toDate != "") {
			PyPostChequeDetailsObjExcel.setToDate(toDate);
		} else

			PyPostChequeDetailsObjExcel.setToDate(null);

		if (vendorId == null || vendorId.equals("")) {
			PyPostChequeDetailsObjExcel.setVendorId(null);
		} else
			PyPostChequeDetailsObjExcel.setVendorId(vendorId.trim());

		if (chqNo == null || chqNo.equals("")) {
			PyPostChequeDetailsObjExcel.setChqNo(null);
		} else
			PyPostChequeDetailsObjExcel.setChqNo(chqNo.trim());

		if (fileId == null || fileId.equals("")) {
			PyPostChequeDetailsObjExcel.setFileId(null);

		} else
			PyPostChequeDetailsObjExcel.setFileId(fileId.trim());

		if (fileName == null || fileName.equals("")) {
			PyPostChequeDetailsObjExcel.setFileName(null);
		} else
			PyPostChequeDetailsObjExcel.setFileName(fileName.trim());
		if (userOLMId == null || userOLMId.equals("")) {
			PyPostChequeDetailsObjExcel.setUserOLMId(null);
		} else
			PyPostChequeDetailsObjExcel.setUserOLMId(userOLMId.trim());


		String pageNum = null;

		List<PayPostingChequeDetails> PayPostChequeExportToExcelList = new ArrayList<PayPostingChequeDetails>();

		PayPostChequeExportToExcelList = ReportsDaoObj
				.getPyPostChequeDetailsList(PyPostChequeDetailsObjExcel, pageNum);

		if(PayPostChequeExportToExcelList==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentPostingChequeSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Excel Records list size in Controller: "+PayPostChequeExportToExcelList.size());

		int rowNumber = 1;
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("Payment_Posting_Cheque_Level");
		XSSFCell cell = null;
		XSSFRow row;
		XSSFCellStyle my_style = wb.createCellStyle();
		XSSFFont my_font=wb.createFont();
		my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		my_style.setFont(my_font);
		XSSFCellStyle rightAligned = wb.createCellStyle();
		rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);




		row = sheet.createRow(0);
		cell = row.createCell(0);
		cell.setCellValue("Cheque No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(1);
		cell.setCellValue("Bank Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(2);
		cell.setCellValue("Vendor ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(3);
		cell.setCellValue("Vendor Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(4);
		cell.setCellValue("Uploaded By(OLM ID)");
		cell.setCellStyle(my_style);

		cell = row.createCell(5);
		cell.setCellValue("File ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(6);
		cell.setCellValue("File Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(7);
		cell.setCellValue("Cheque Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(8);
		cell.setCellValue("Bank Account No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(9);
		cell.setCellValue("No. Of Accounts Posted");
		cell.setCellStyle(my_style);
		cell = row.createCell(10);
		cell.setCellValue("No. Of Invoices posted");
		cell.setCellStyle(my_style);
		cell = row.createCell(11);
		cell.setCellValue("Cheque Value");
		cell.setCellStyle(my_style);
		cell = row.createCell(12);
		cell.setCellValue("Uploaded Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(13);
		cell.setCellValue("Uploaded Time");
		cell.setCellStyle(my_style);
		cell = row.createCell(14);
		cell.setCellValue("Posting Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(15);
		cell.setCellValue("Posting Time");
		cell.setCellStyle(my_style);
		cell = row.createCell(16);
		cell.setCellValue("Cheque Date vs Uploaded Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(17);
		cell.setCellValue("Uploaded Date vs Posted Date");
		cell.setCellStyle(my_style);


		for (int i = 0; i < PayPostChequeExportToExcelList.size(); i++) {
			// reportslogger.info("i value"+i);
			PayPostingChequeDetails PyPostChequeDetailsObject = PayPostChequeExportToExcelList
					.get(i);

			row = sheet.createRow(rowNumber);
			cell = row.createCell(0);
			cell.setCellValue(PyPostChequeDetailsObject.getChqNo());
			//sheet.autoSizeColumn(0);

			cell = row.createCell(1);
			cell.setCellValue(PyPostChequeDetailsObject.getBankName());

			if ((PyPostChequeDetailsObject.getVendorId() == null)
					|| (PyPostChequeDetailsObject.getVendorId()
							.equalsIgnoreCase(""))
					|| (PyPostChequeDetailsObject.getVendorId()
							.equalsIgnoreCase("NA"))) {
				cell = row.createCell(2);
				cell.setCellValue("");
			} else {
				cell = row.createCell(2);
				cell.setCellValue(PyPostChequeDetailsObject.getVendorId());
			}
			cell.setCellStyle(rightAligned);
			if ((PyPostChequeDetailsObject.getVendorName() == null)
					|| (PyPostChequeDetailsObject.getVendorName()
							.equalsIgnoreCase(""))
					|| (PyPostChequeDetailsObject.getVendorName()
							.equalsIgnoreCase("NA"))) {
				cell = row.createCell(3);
				cell.setCellValue("");
			} else {
				cell = row.createCell(3);
				cell.setCellValue(PyPostChequeDetailsObject.getVendorName());
			}
			//sheet.autoSizeColumn(2);

			cell = row.createCell(4);
			cell.setCellValue(PyPostChequeDetailsObject.getUserOLMId());
			//sheet.autoSizeColumn(3);
			cell = row.createCell(5);
			cell.setCellValue(PyPostChequeDetailsObject.getFileId());
			cell.setCellStyle(rightAligned);
			cell = row.createCell(6);
			cell.setCellValue(PyPostChequeDetailsObject.getFileName());
			//sheet.autoSizeColumn(4);

			cell = row.createCell(7);
			cell.setCellValue(PyPostChequeDetailsObject.getDateOnChq());
			cell = row.createCell(8);
			cell.setCellValue(PyPostChequeDetailsObject.getBankAccNo());
			//sheet.autoSizeColumn(5);
			cell = row.createCell(9);
			cell.setCellValue(PyPostChequeDetailsObject.getNoOfAccPosted());
			//sheet.autoSizeColumn(6);

			cell = row.createCell(10);
			cell.setCellValue(PyPostChequeDetailsObject.getNoOfInvPosted());
			//sheet.autoSizeColumn(7);
			cell = row.createCell(11);
			cell.setCellValue(PyPostChequeDetailsObject.getChqVal());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(8);

			cell = row.createCell(12);
			cell.setCellValue(PyPostChequeDetailsObject.getChqUploadDt());
			//sheet.autoSizeColumn(9);
			cell = row.createCell(13);
			cell.setCellValue(PyPostChequeDetailsObject.getChqUploadTym());
			//sheet.autoSizeColumn(10);

			cell = row.createCell(14);
			cell.setCellValue(PyPostChequeDetailsObject.getPostingDate());
			//sheet.autoSizeColumn(11);
			cell = row.createCell(15);
			cell.setCellValue(PyPostChequeDetailsObject.getPostingTime());
			//sheet.autoSizeColumn(12);
			cell = row.createCell(16);
			cell.setCellValue(PyPostChequeDetailsObject.getDiffChqvsUpload());
			//sheet.autoSizeColumn(13);

			cell = row.createCell(17);
			cell.setCellValue(PyPostChequeDetailsObject.getDiffUploadvsPosted());
			//sheet.autoSizeColumn(14);
			rowNumber++;

		}
		for (int i = 0; i <= 17; i++) {
			sheet.autoSizeColumn(i);
		}
		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		byte[] outArray = outByteStream.toByteArray();

		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
				.format(new Date());

		String fileName1 = "APS_Payment_Posting_Cheque_Level_"+ date + ".xlsx";
		//reportslogger.info("filename is" + fileName);

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName1);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
		} catch (IOException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}

		/* reportslogger.info("End of failure records download "); */

		return modelAndViewObj;

	}

	/********************************************* PAYMENT POSTING CHEQUE LEVEL ENDS ***************************************/

	/** PAYMENT REVERSAL FILE LEVEL **/

	/*	@RequestMapping(value = "/paymentReversalFileLevel")
	public ModelAndView paymentReversalFileLevelHome() {
		reportslogger.info("In Payment Reversal File level Controller");
		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("PaymentReversalFileLevelLogin");
		return modelAndViewObj;
	}*/

	@RequestMapping(value = "/paymentReversalFileLevelRole", method = RequestMethod.GET)
	public ModelAndView paymentReversalFileLevelRole(HttpServletRequest request, HttpServletResponse response) 
	{
		ModelAndView modelAndViewObj = new ModelAndView();

		// PayPostingFilelevelDetails payPostingFilelevelDetailsObj=new
		// PayPostingFilelevelDetails();
		//reportslogger.info("in controller to get role.");
		session=request.getSession(false);
		reportslogger.info("In Payment Reversal File level Controller");

		PaymentReversalFileLevelBean PayReversalFileLevelBeanObj = new PaymentReversalFileLevelBean();

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);



		// get role by calling fn.
		//String parentUserId = request.getParameter("parentUserId");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		/*Role = ReportsDaoObj.getRole(parentUserId);
		if(Role==-1)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.setViewName("PaymentReversalFileLevelSearch");
			return modelAndViewObj;
		}*/

		reportslogger.info("User Role" + Role);

		if (Role == 1 || Role == 2 || Role == 3 || Role == 7) {

			PayReversalFileLevelBeanObj.setParentUserId(parentUserId);
			PayReversalFileLevelBeanObj.setChildUserId(null);
			PayReversalFileLevelBeanObj.setVendorId(null);
			PayReversalFileLevelBeanObj.setFileId(null);
			PayReversalFileLevelBeanObj.setFileName(null);
			PayReversalFileLevelBeanObj.setToDate(null);
			PayReversalFileLevelBeanObj.setFromDate(null);
			PayReversalFileLevelBeanObj.setReversalType(null);
			List<String> reversalTypeList = ReportsDaoObj.reversalTypeList();
			if(reversalTypeList==null)
			{
				modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("role", Role);
				modelAndViewObj.setViewName("PaymentReversalFileLevelSearch");
				return modelAndViewObj;
			}
			reportslogger.info("Reversal Type List Size in Controller: "+reversalTypeList.size());
			modelAndViewObj.addObject("reversalTypeList", reversalTypeList);

			HashMap<Integer, List<PaymentReversalFileLevelBean>> payReversalCompleteDetailsMap = new HashMap<Integer, List<PaymentReversalFileLevelBean>>();
			int page = 1;
			String statusMsg = null;

			payReversalCompleteDetailsMap = ReportsDaoObj
					.getPayReversalFilelevelDetails(
							PayReversalFileLevelBeanObj, page);
			if(payReversalCompleteDetailsMap==null)
			{
				modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("role", Role);
				modelAndViewObj.setViewName("PaymentReversalFileLevelSearch");
				return modelAndViewObj;
			}

			reportslogger.info("Details Map Size in Controller: "+ payReversalCompleteDetailsMap.size());



			if(PayReversalFileLevelBeanObj.getStatusMsg()!=null)
			{

				if(PayReversalFileLevelBeanObj.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
				{
					statusMsg="";
				}

				else
				{
					statusMsg=PayReversalFileLevelBeanObj.getStatusMsg();
				}

			}
			else
				statusMsg="Connectivity Issues..Retry..";




			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.addObject("statusMsg", statusMsg);
			modelAndViewObj.addObject("detailsMap",
					payReversalCompleteDetailsMap);
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.setViewName("PaymentReversalFileLevelSearch");
			return modelAndViewObj;
		}

		else
			reportslogger.info("you do not have privilage to view this page!");

		modelAndViewObj.addObject("error",
				"You do not have privilige to View Reports !!");
		modelAndViewObj.setViewName("PaymentReversalFileLevelSearch");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/PaymentReversalFilelevelSearch")
	public ModelAndView getPaymentReversalFileDetails(HttpServletRequest request, HttpServletResponse response)
	{

		/*
		 * PayPostingFilelevelDetails payPostingFilelevelDetailsObj=new
		 * PayPostingFilelevelDetails();
		 */
		reportslogger.info("In Payment Reversal File level Search");
		session=request.getSession(false);
		PaymentReversalFileLevelBean PayReversalFileLevelBeanObjSearch= new PaymentReversalFileLevelBean();
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		PayReversalFileLevelBeanObjSearch.setParentUserId(parentUserId);
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);

		ModelAndView modelAndViewObj = new ModelAndView();
		/*	if(Role==-1)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.setViewName("PaymentReversalFileLevelSearch");
			return modelAndViewObj;
		}*/

		//reportslogger.info("in payReversalFilelevelView tracking");

		String childUserId = request.getParameter("childUserid");
		reportslogger.info("User ID: " + childUserId);

		String vendorID = request.getParameter("vendorid");
		reportslogger.info("Vendor ID: " + vendorID);

		String filedId = request.getParameter("fileid");
		reportslogger.info("File ID: " + filedId);

		String fileName = request.getParameter("fileName");
		reportslogger.info("File Name: " + fileName);

		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date: " + fromDate);

		String toDate = request.getParameter("endDate");
		reportslogger.info("To Date: " + toDate);

		String reversalType = request.getParameter("ReversalType");
		reportslogger.info("Reversal type: " + reversalType);

		if (fromDate != "") {
			PayReversalFileLevelBeanObjSearch.setFromDate(fromDate);
		} else
			PayReversalFileLevelBeanObjSearch.setFromDate(null);


		if (toDate != "") {
			PayReversalFileLevelBeanObjSearch.setToDate(toDate);
		} else {
			PayReversalFileLevelBeanObjSearch.setToDate(null);
		}

		if (vendorID == null || vendorID.equals("")) {
			PayReversalFileLevelBeanObjSearch.setVendorId(null);

		} else {
			PayReversalFileLevelBeanObjSearch.setVendorId(vendorID.trim());
		}

		if (filedId == null || filedId.equals("")) {
			PayReversalFileLevelBeanObjSearch.setFileId(null);

		} else {
			PayReversalFileLevelBeanObjSearch.setFileId(filedId.trim());
		}


		if (childUserId == null || childUserId.equals("")) {
			PayReversalFileLevelBeanObjSearch.setChildUserId(null);

		} else {
			PayReversalFileLevelBeanObjSearch.setChildUserId(childUserId.trim());
		}

		if (fileName == null || fileName.equals("")) {
			PayReversalFileLevelBeanObjSearch.setFileName(null);

		} else {
			PayReversalFileLevelBeanObjSearch.setFileName(fileName.trim());
		}
		if (reversalType != null && reversalType.equalsIgnoreCase("ALL")) {
			PayReversalFileLevelBeanObjSearch.setReversalType("");
		} else {
			PayReversalFileLevelBeanObjSearch.setReversalType(reversalType);
		}

		HashMap<Integer, List<PaymentReversalFileLevelBean>> detailsMap = new HashMap<Integer, List<PaymentReversalFileLevelBean>>();
		int page = 1;
		String statusMsg = null;

		List<String> reversalTypeList = ReportsDaoObj.reversalTypeList();
		if(reversalTypeList==null)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PaymentReversalFileLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Reversal Type List Size in Controller: "+reversalTypeList.size());
		modelAndViewObj.addObject("reversalTypeList", reversalTypeList);


		detailsMap = ReportsDaoObj.getPayReversalFilelevelDetails(
				PayReversalFileLevelBeanObjSearch, page);

		if(detailsMap==null)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PaymentReversalFileLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Details map Size based on search Criteria in Controller: "+detailsMap.size());

		if(PayReversalFileLevelBeanObjSearch.getStatusMsg()!=null)
		{

			if(PayReversalFileLevelBeanObjSearch.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				statusMsg="";
			}

			else
			{
				statusMsg=PayReversalFileLevelBeanObjSearch.getStatusMsg();
			}

		}
		else
			statusMsg="Connectivity Issues..Retry..";



		modelAndViewObj.addObject("role", Role);
		modelAndViewObj.addObject("statusMsg", statusMsg);
		modelAndViewObj.addObject("PayReversalFileLevelBeanObjJsp", PayReversalFileLevelBeanObjSearch);
		modelAndViewObj.addObject("detailsMap", detailsMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.setViewName("PaymentReversalFileLevelSearch");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/paymentReversalFilelevelViewPagination")
	public ModelAndView getPaymentreversalFileLevelPagination(HttpServletRequest request, HttpServletResponse response)
	{


		session=request.getSession(false);
		reportslogger.info("In Payment Reversal File Level Pagination");
		PaymentReversalFileLevelBean PayReversalFileLevelBeanObjPag= new PaymentReversalFileLevelBean();
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		PayReversalFileLevelBeanObjPag.setParentUserId(parentUserId);
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);

		String childUserId = request.getParameter("childUserid");
		reportslogger.info("User ID: " + childUserId);

		String vendorID = request.getParameter("vendorid");
		reportslogger.info("Vendor ID: " + vendorID);

		String filedId = request.getParameter("fileid");
		reportslogger.info("File ID: " + filedId);

		String fileName = request.getParameter("fileName");
		reportslogger.info("File Name: " + fileName);

		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date: " + fromDate);

		String toDate = request.getParameter("endDate");
		reportslogger.info("To Date: " + toDate);

		String reversalType = request.getParameter("ReversalType");
		reportslogger.info("Reversal type: " + reversalType);

		if (fromDate != "") {
			PayReversalFileLevelBeanObjPag.setFromDate(fromDate);
		} else
			PayReversalFileLevelBeanObjPag.setFromDate(null);


		if (toDate != "") {
			PayReversalFileLevelBeanObjPag.setToDate(toDate);
		} else {
			PayReversalFileLevelBeanObjPag.setToDate(null);
		}

		if (vendorID == null || vendorID.equals("")) {
			PayReversalFileLevelBeanObjPag.setVendorId(null);

		} else {
			PayReversalFileLevelBeanObjPag.setVendorId(vendorID.trim());
		}

		if (filedId == null || filedId.equals("")) {
			PayReversalFileLevelBeanObjPag.setFileId(null);

		} else {
			PayReversalFileLevelBeanObjPag.setFileId(filedId.trim());
		}


		if (childUserId == null || childUserId.equals("")) {
			PayReversalFileLevelBeanObjPag.setChildUserId(null);

		} else {
			PayReversalFileLevelBeanObjPag.setChildUserId(childUserId.trim());
		}

		if (fileName == null || fileName.equals("")) {
			PayReversalFileLevelBeanObjPag.setFileName(null);

		} else {
			PayReversalFileLevelBeanObjPag.setFileName(fileName.trim());
		}
		if (reversalType != null && reversalType.equalsIgnoreCase("ALL")) {
			PayReversalFileLevelBeanObjPag.setReversalType("");
		} else {
			PayReversalFileLevelBeanObjPag.setReversalType(reversalType);
		}
		HashMap<Integer, List<PaymentReversalFileLevelBean>> detailsMap = new HashMap<Integer, List<PaymentReversalFileLevelBean>>();
		int page = Integer.parseInt(request.getParameter("pageNum"));
		reportslogger.info("Page No. :"+page);
		String statusMsg = null;
		ModelAndView modelAndViewObj = new ModelAndView();
		List<String> reversalTypeList = ReportsDaoObj.reversalTypeList();
		if(reversalTypeList==null)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PaymentReversalFileLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Reversal Type List Size in Controller: "+reversalTypeList.size());
		modelAndViewObj.addObject("reversalTypeList", reversalTypeList);


		detailsMap = ReportsDaoObj.getPayReversalFilelevelDetails(
				PayReversalFileLevelBeanObjPag, page);
		if(detailsMap==null){
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PaymentReversalFileLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Details Map Size based on Page No In Controller: "+detailsMap.size());



		/*reportslogger.info("in controller"
				+ PayReversalFileLevelBeanObj.getStatusMsg());*/

		if(PayReversalFileLevelBeanObjPag.getStatusMsg()!=null)
		{

			if(PayReversalFileLevelBeanObjPag.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				statusMsg="";
			}

			else
			{
				statusMsg=PayReversalFileLevelBeanObjPag.getStatusMsg();
			}

		}
		else
			statusMsg="Connectivity Issues..Retry..";

		modelAndViewObj.addObject("role", Role);
		modelAndViewObj.addObject("statusMsg", statusMsg);
		modelAndViewObj.addObject("PayReversalFileLevelBeanObjJsp", PayReversalFileLevelBeanObjPag);
		modelAndViewObj.addObject("detailsMap", detailsMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.setViewName("PaymentReversalFileLevelSearch");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/PaymentReversalTransRecordsFileDownload", method = RequestMethod.POST)
	public ModelAndView payReversalTransRecordsFileDownload(HttpServletRequest request, HttpServletResponse response)throws IOException
	{

		session=request.getSession(false);
		reportslogger.info("In Payment Reversal File Level, Transaction Records Excel File download");
		PaymentReversalFileLevelBean PayReversalFileLevelBeanObjtransExcel= new PaymentReversalFileLevelBean();
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		PayReversalFileLevelBeanObjtransExcel.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		// PayDirectRevTransRecords PayDirectRevTransRecordsObj=new
		// PayDirectRevTransRecords();
		List<PayRevDirectTransRecordsDownload> PayDirectRevTransLevelDetailsList = new ArrayList<PayRevDirectTransRecordsDownload>();
		List<PayRevChequeBounceDetailsDownload> PayChequeBounceTransLevelDetailsList = new ArrayList<PayRevChequeBounceDetailsDownload>();
		ModelAndView modelAndViewObj = new ModelAndView();
		String fileID = request.getParameter("fileID");
		reportslogger.info("File ID In Excel File Downlaod: "+fileID);
		String reversalType = request.getParameter("reversalType");
		reportslogger.info("Reversal Type In Excel File Downlaod: "+reversalType);
		int rowNumber = 1;
		List<String> reversalTypeList = ReportsDaoObj.reversalTypeList();
		if(reversalTypeList==null)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PaymentReversalFileLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Reversal Type List Size in Controller: "+reversalTypeList.size());
		modelAndViewObj.addObject("reversalTypeList", reversalTypeList);


		/*reportslogger.info("file ID" + fileID);
		reportslogger.info("reversal type in download" + reversalType);*/
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("Payment_Reversal_Failure_Records");
		XSSFCell cell = null;
		XSSFRow row;
		XSSFCellStyle my_style = wb.createCellStyle();
		XSSFFont my_font=wb.createFont();
		my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		my_style.setFont(my_font);
		XSSFCellStyle rightAligned = wb.createCellStyle();
		rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);



		if (reversalType.equalsIgnoreCase("DIRECT_REVERSAL")) {

			PayDirectRevTransLevelDetailsList = ReportsDaoObj
					.getDirectRevTransLevelRecords(fileID);

			if(PayDirectRevTransLevelDetailsList==null){
				modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("role", Role);
				modelAndViewObj.setViewName("PaymentReversalFileLevelSearch");
				return modelAndViewObj;
			}
			reportslogger.info("Direct Reversal failure record list size in Controller: "+PayDirectRevTransLevelDetailsList.size());

			row = sheet.createRow(0);
			cell = row.createCell(0);
			cell.setCellValue("Account No.");
			cell.setCellStyle(my_style);
			cell = row.createCell(1);
			cell.setCellValue("Tracking ID");
			cell.setCellStyle(my_style);
			cell = row.createCell(2);
			cell.setCellValue("Tracking ID serv");
			cell.setCellStyle(my_style);
			cell = row.createCell(3);
			cell.setCellValue("Uploaded By(OLM ID)");
			cell.setCellStyle(my_style);
			cell = row.createCell(4);
			cell.setCellValue("Uploaded By(Name)");
			cell.setCellStyle(my_style);
			cell = row.createCell(5);
			cell.setCellValue("File ID");
			cell.setCellStyle(my_style);
			cell = row.createCell(6);
			cell.setCellValue("File Name");
			cell.setCellStyle(my_style);
			cell = row.createCell(7);
			cell.setCellValue("Uploaded Date");
			cell.setCellStyle(my_style);
			cell = row.createCell(8);
			cell.setCellValue("Status");
			cell.setCellStyle(my_style);
			/*cell = row.createCell(9);
			cell.setCellValue("FX update time");*/
			cell = row.createCell(9);
			cell.setCellValue("Reason For Failure");
			cell.setCellStyle(my_style);

			for (int i = 0; i < PayDirectRevTransLevelDetailsList.size(); i++) {

				PayRevDirectTransRecordsDownload PayDirectRevTransRecordsObj = PayDirectRevTransLevelDetailsList
						.get(i);

				row = sheet.createRow(rowNumber);
				cell = row.createCell(0);
				cell.setCellValue(PayDirectRevTransRecordsObj
						.getAccountNumber());
				//sheet.autoSizeColumn(0);
				cell = row.createCell(1);
				cell.setCellValue(PayDirectRevTransRecordsObj.getTrackingId());
				cell.setCellStyle(rightAligned);
				//sheet.autoSizeColumn(1);
				cell = row.createCell(2);
				cell.setCellValue(PayDirectRevTransRecordsObj
						.getTrackingIdServ());
				cell.setCellStyle(rightAligned);
				//sheet.autoSizeColumn(2);
				cell = row.createCell(3);
				cell.setCellValue(PayDirectRevTransRecordsObj
						.getUploadedByOlmId());
				//sheet.autoSizeColumn(3);
				cell = row.createCell(4);
				cell.setCellValue(PayDirectRevTransRecordsObj
						.getUploadedByName());
				//sheet.autoSizeColumn(4);
				cell = row.createCell(5);
				cell.setCellValue(PayDirectRevTransRecordsObj.getFileId());
				cell.setCellStyle(rightAligned);
				//sheet.autoSizeColumn(5);
				cell = row.createCell(6);
				cell.setCellValue(PayDirectRevTransRecordsObj.getFileName());
				//sheet.autoSizeColumn(6);
				cell = row.createCell(7);
				CellStyle cellStyle = wb.createCellStyle();
				CreationHelper createHelper = wb.getCreationHelper();

				cellStyle.setDataFormat(createHelper.createDataFormat()
						.getFormat("dd/mm/yyyy"));
				cell.setCellValue(PayDirectRevTransRecordsObj
						.getUploadDateTime());
				cell.setCellStyle(cellStyle);
				//sheet.autoSizeColumn(7);
				cell = row.createCell(8);
				cell.setCellValue(PayDirectRevTransRecordsObj.getStatus());
				//sheet.autoSizeColumn(8);
				/*cell = row.createCell(9);
				cellStyle.setDataFormat(createHelper.createDataFormat()
						.getFormat("dd/mm/yyyy"));
				if (PayDirectRevTransRecordsObj.getFxUpdateTime() != null) {
					cell.setCellValue(PayDirectRevTransRecordsObj
							.getFxUpdateTime());
					// cell.setCellStyle(cellStyle);
				} else
					cell.setCellValue("");
				sheet.autoSizeColumn(9);*/
				cell = row.createCell(9);
				cell.setCellValue(PayDirectRevTransRecordsObj
						.getReasonForFailue());

				//sheet.autoSizeColumn(9);
				rowNumber = rowNumber + 1;

			}
			for (int i = 0; i <=9; i++) {
				sheet.autoSizeColumn(i);
			}
		} else if (reversalType.equalsIgnoreCase("CHEQUE_BOUNCE")) {

			PayChequeBounceTransLevelDetailsList = ReportsDaoObj
					.getChequeBounceTransLevelRecords(fileID);

			if(PayChequeBounceTransLevelDetailsList==null){
				modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("role", Role);
				modelAndViewObj.setViewName("PaymentReversalFileLevelSearch");
				return modelAndViewObj;
			}
			reportslogger.info("Cheque Bounce Failure record list size in Controller: "+PayChequeBounceTransLevelDetailsList.size());

			row = sheet.createRow(0);
			cell = row.createCell(0);
			cell.setCellValue("Uploaded By(OLM ID)");
			cell.setCellStyle(my_style);
			cell = row.createCell(1);
			cell.setCellValue("Vendor ID");
			cell.setCellStyle(my_style);
			cell = row.createCell(2);
			cell.setCellValue("Vendor Name");
			cell.setCellStyle(my_style);
			cell = row.createCell(3);
			cell.setCellValue("LOB");
			cell.setCellStyle(my_style);
			cell = row.createCell(4);
			cell.setCellValue("File ID");
			cell.setCellStyle(my_style);
			cell = row.createCell(5);
			cell.setCellValue("Uploaded File Name");
			cell.setCellStyle(my_style);
			cell = row.createCell(6);
			cell.setCellValue("Cheque No.");
			cell.setCellStyle(my_style);
			cell = row.createCell(7);
			cell.setCellValue("Bank Name");
			cell.setCellStyle(my_style);
			cell = row.createCell(8);
			cell.setCellValue("Cheque Date");
			cell.setCellStyle(my_style);
			cell = row.createCell(9);
			cell.setCellValue("Bank Account No.");
			cell.setCellStyle(my_style);
			/*cell = row.createCell(6);
			cell.setCellValue("No. of Accounts Posted");
			cell = row.createCell(7);
			cell.setCellValue("No. of Invoices posted");*/
			cell = row.createCell(10);
			cell.setCellValue("Total Cheque Value");
			cell.setCellStyle(my_style);
			cell = row.createCell(11);
			cell.setCellValue("Initial Uploaded Date");
			cell.setCellStyle(my_style);
			cell = row.createCell(12);
			cell.setCellValue("Initial Posted Date");
			cell.setCellStyle(my_style);
			cell = row.createCell(13);
			cell.setCellValue("Bounced Date");
			cell.setCellStyle(my_style);
			cell = row.createCell(14);
			cell.setCellValue("Bounced MIS Date");
			cell.setCellStyle(my_style);
			/*cell = row.createCell(13);
			cell.setCellValue("Reversal date");*/
			cell = row.createCell(15);
			cell.setCellValue("Initial Uploaded vs Bounced Date");
			cell.setCellStyle(my_style);
			cell = row.createCell(16);
			cell.setCellValue("Bounced Date vs Bounced MIS Date");
			cell.setCellStyle(my_style);

			/*	cell = row.createCell(16);
			cell.setCellValue("Diff - Bounced Date Vs Reversal Date");
			cell = row.createCell(17);
			cell.setCellValue("Diff - Bounce MIS Date Vs Reversal Date");*/
			cell = row.createCell(17);
			cell.setCellValue("Status");
			cell.setCellStyle(my_style);
			cell = row.createCell(18);
			cell.setCellValue("Reason For Failure");
			cell.setCellStyle(my_style);

			for (int i = 0; i < PayChequeBounceTransLevelDetailsList.size(); i++) {

				PayRevChequeBounceDetailsDownload PymntRevChqBounceRecordsDetailsObj = PayChequeBounceTransLevelDetailsList
						.get(i);
				// reportslogger.info("in controller uplodeddate"+PymntRevChqBounceRecordsDetailsObj.getUploadDateTime());
				row = sheet.createRow(rowNumber);
				cell = row.createCell(0);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getUploadedUser());
				cell = row.createCell(1);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getVendorId());
				cell.setCellStyle(rightAligned);
				cell = row.createCell(2);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getVendorName());
				//sheet.autoSizeColumn(0);
				cell = row.createCell(3);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj.getLob());
				cell = row.createCell(4);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj.getFileId());
				cell.setCellStyle(rightAligned);
				//sheet.autoSizeColumn(1);
				cell = row.createCell(5);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getFileName());
				//sheet.autoSizeColumn(2);
				cell = row.createCell(6);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj.getRefNo());
				//sheet.autoSizeColumn(3);
				cell = row.createCell(7);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getBankName());
				//sheet.autoSizeColumn(4);
				cell = row.createCell(8);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getDateonChq());
				cell = row.createCell(9);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getBankAccNo());
				//sheet.autoSizeColumn(5);
				/*cell = row.createCell(6);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getNoOfAccPostedFx());
				sheet.autoSizeColumn(6);
				cell = row.createCell(7);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getNoOfInvPostedFx());
				sheet.autoSizeColumn(7);*/
				cell = row.createCell(10);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getTotChqVal());
				cell.setCellStyle(rightAligned);
				//sheet.autoSizeColumn(6);
				cell = row.createCell(11);
				CellStyle cellStyle = wb.createCellStyle();
				CreationHelper createHelper = wb.getCreationHelper();

				cellStyle.setDataFormat(createHelper.createDataFormat()
						.getFormat("dd/mm/yyyy"));
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getInitialUploadedDate());
				cell.setCellStyle(cellStyle);
				//sheet.autoSizeColumn(7);
				cell = row.createCell(12);
				cellStyle.setDataFormat(createHelper.createDataFormat()
						.getFormat("dd/mm/yyyy"));
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getInitialPostedDate());
				cell.setCellStyle(cellStyle);
				//sheet.autoSizeColumn(8);
				cell = row.createCell(13);
				cellStyle.setDataFormat(createHelper.createDataFormat()
						.getFormat("dd/mm/yyyy"));
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getBouncedDate());
				cell.setCellStyle(cellStyle);
				//sheet.autoSizeColumn(9);
				cell = row.createCell(14);
				cellStyle.setDataFormat(createHelper.createDataFormat()
						.getFormat("dd/mm/yyyy"));
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getBounceMisDate());
				cell.setCellStyle(cellStyle);
				//sheet.autoSizeColumn(10);
				/*cell = row.createCell(13);
				cellStyle.setDataFormat(createHelper.createDataFormat()
						.getFormat("dd/mm/yyyy"));
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getRevPostingFxDate());
				cell.setCellStyle(cellStyle);
				sheet.autoSizeColumn(13);*/
				cell = row.createCell(15);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getDiffInitalVsBouncedDate());
				//sheet.autoSizeColumn(11);
				cell = row.createCell(16);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getDiffBouncedVsBouncdMisDate());

				//sheet.autoSizeColumn(12);
				/*cell = row.createCell(16);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getDiffBouncedVspostingRevDate());
				sheet.autoSizeColumn(16);
				cell = row.createCell(17);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getDiffBounceMisDateVspostingRevDate());
				sheet.autoSizeColumn(17);*/
				cell = row.createCell(17);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getStatus());
				//sheet.autoSizeColumn(13);
				cell = row.createCell(18);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj.getReasonForFailure());
				//sheet.autoSizeColumn(14);
				rowNumber = rowNumber + 1;

			}
			for (int i = 0; i <= 18; i++) {
				sheet.autoSizeColumn(i);
			}
		}
		// write it as an excel attachment
		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		byte[] outArray = outByteStream.toByteArray();
		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
				.format(new Date());

		String fileName="";
		if (reversalType.equalsIgnoreCase("DIRECT_REVERSAL"))
		{
			fileName = "APS_"+fileID +"_DIRECT_REVERSAL_Failure_Records_"+date +".xlsx";
		}

		else if (reversalType.equalsIgnoreCase("CHEQUE_BOUNCE"))
		{
			fileName = "APS_"+fileID +"_CHEQUE_BOUNCE_Failure_Records_"+date +".xlsx";
		}


		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}

		reportslogger.info("End of Payment Reversal File Level failure records download ");
		// modelAndViewObj.setViewName("viewTracking");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/PaymentReversalFileLevelExcelFileDownload", method = RequestMethod.POST)
	public ModelAndView payReversalFileLevelexcelFileDownload(HttpServletRequest request, HttpServletResponse response)throws IOException
	{
		session=request.getSession(false);
		reportslogger.info("In Payment Reversal File Level Excel File Download");
		PaymentReversalFileLevelBean PayReversalFileLevelBeanObjExcel= new PaymentReversalFileLevelBean();
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		PayReversalFileLevelBeanObjExcel.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);
		String childUserId = request.getParameter("childUserid");
		reportslogger.info("User ID: " + childUserId);

		String vendorID = request.getParameter("vendorid");
		reportslogger.info("Vendor ID: " + vendorID);

		String filedId = request.getParameter("fileid");
		reportslogger.info("File ID: " + filedId);

		String fileName = request.getParameter("fileName");
		reportslogger.info("File Name: " + fileName);

		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date: " + fromDate);

		String toDate = request.getParameter("endDate");
		reportslogger.info("To Date: " + toDate);

		String reversalType = request.getParameter("ReversalType");
		reportslogger.info("Reversal type: " + reversalType);

		if (fromDate != "") {
			PayReversalFileLevelBeanObjExcel.setFromDate(fromDate);
		} else
			PayReversalFileLevelBeanObjExcel.setFromDate(null);


		if (toDate != "") {
			PayReversalFileLevelBeanObjExcel.setToDate(toDate);
		} else {
			PayReversalFileLevelBeanObjExcel.setToDate(null);
		}

		if (vendorID == null || vendorID.equals("")) {
			PayReversalFileLevelBeanObjExcel.setVendorId(null);

		} else {
			PayReversalFileLevelBeanObjExcel.setVendorId(vendorID.trim());
		}

		if (filedId == null || filedId.equals("")) {
			PayReversalFileLevelBeanObjExcel.setFileId(null);

		} else {
			PayReversalFileLevelBeanObjExcel.setFileId(filedId.trim());
		}


		if (childUserId == null || childUserId.equals("")) {
			PayReversalFileLevelBeanObjExcel.setChildUserId(null);

		} else {
			PayReversalFileLevelBeanObjExcel.setChildUserId(childUserId.trim());
		}

		if (fileName == null || fileName.equals("")) {
			PayReversalFileLevelBeanObjExcel.setFileName(null);

		} else {
			PayReversalFileLevelBeanObjExcel.setFileName(fileName.trim());
		}
		if (reversalType != null && reversalType.equalsIgnoreCase("ALL")) {
			PayReversalFileLevelBeanObjExcel.setReversalType("");
		} else {
			PayReversalFileLevelBeanObjExcel.setReversalType(reversalType);
		}



		List<PaymentReversalFileLevelBean> PayRevFileLevelExcelDetailsList = new ArrayList<PaymentReversalFileLevelBean>();
		String pageNo = null;
		int rowNumber = 1;
		ModelAndView modelAndViewObj = new ModelAndView();
		List<String> reversalTypeList = ReportsDaoObj.reversalTypeList();
		if(reversalTypeList==null)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PaymentReversalFileLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Reversal Type List Size in Controller: "+reversalTypeList.size());
		modelAndViewObj.addObject("reversalTypeList", reversalTypeList);


		PayRevFileLevelExcelDetailsList = ReportsDaoObj
				.getPayReversalFilelevelExcelDetails(
						PayReversalFileLevelBeanObjExcel, pageNo);
		if(PayRevFileLevelExcelDetailsList==null){
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PaymentReversalFileLevelSearch");
			return modelAndViewObj;
		}

		reportslogger.info("Excel Details Size in Controller:"+ PayRevFileLevelExcelDetailsList.size());
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("Payment_Reversal_File_Level");
		XSSFCell cell = null;
		XSSFRow row;
		XSSFCellStyle my_style = wb.createCellStyle();
		XSSFFont my_font=wb.createFont();
		my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		my_style.setFont(my_font);
		XSSFCellStyle rightAligned = wb.createCellStyle();
		rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);



		row = sheet.createRow(0);
		cell = row.createCell(0);
		cell.setCellValue("File ID");
		cell.setCellStyle(my_style);

		cell = row.createCell(1);
		cell.setCellValue("Reversal Type ");
		cell.setCellStyle(my_style);

		cell = row.createCell(2);
		cell.setCellValue("Uploaded By(OLM ID) ");
		cell.setCellStyle(my_style);

		cell = row.createCell(3);
		cell.setCellValue("Uploaded By(Name) ");
		cell.setCellStyle(my_style);

		cell = row.createCell(4);
		cell.setCellValue("Uploaded Date");
		cell.setCellStyle(my_style);

		cell = row.createCell(5);
		cell.setCellValue("File Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(6);
		cell.setCellValue("Vendor ID");
		cell.setCellStyle(my_style);

		cell = row.createCell(7);
		cell.setCellValue("Total Records");
		cell.setCellStyle(my_style);

		cell = row.createCell(8);
		cell.setCellValue("Total Value");
		cell.setCellStyle(my_style);
		cell = row.createCell(9);
		cell.setCellValue("In Progress Records");
		cell.setCellStyle(my_style);
		cell = row.createCell(10);
		cell.setCellValue("In Progress Value");
		cell.setCellStyle(my_style);

		cell = row.createCell(11);
		cell.setCellValue("Status");
		cell.setCellStyle(my_style);

		cell = row.createCell(12);
		cell.setCellValue("Records Pushed To Fx");
		cell.setCellStyle(my_style);

		cell = row.createCell(13);
		cell.setCellValue("Value Pushed To Fx");
		cell.setCellStyle(my_style);

		cell = row.createCell(14);
		cell.setCellValue("Failed Record Count");
		cell.setCellStyle(my_style);

		cell = row.createCell(15);
		cell.setCellValue("Failed Record Value");
		cell.setCellStyle(my_style);


		for (int i = 0; i < PayRevFileLevelExcelDetailsList.size(); i++) {

			PaymentReversalFileLevelBean PayDirectReversalBeanObj = PayRevFileLevelExcelDetailsList
					.get(i);
			// reportslogger.info("in controller uplodeddate"+PayPostingFilelevelDetailsObj.getUplodedDateTime());
			row = sheet.createRow(rowNumber);
			cell = row.createCell(0);
			cell.setCellValue(PayDirectReversalBeanObj.getFileId());

			cell.setCellStyle(rightAligned);

			//sheet.autoSizeColumn(0);

			cell = row.createCell(1);
			cell.setCellValue(PayDirectReversalBeanObj.getReversalType());
			//sheet.autoSizeColumn(1);
			cell = row.createCell(2);
			cell.setCellValue(PayDirectReversalBeanObj.getUploadedByOlmId());
			//sheet.autoSizeColumn(2);
			cell = row.createCell(3);
			cell.setCellValue(PayDirectReversalBeanObj.getUploadedByName());
			//sheet.autoSizeColumn(3);
			cell = row.createCell(4);
			CellStyle cellStyle = wb.createCellStyle();
			CreationHelper createHelper = wb.getCreationHelper();

			cellStyle.setDataFormat(createHelper.createDataFormat().getFormat(
					"dd/mm/yyyy"));
			if (PayDirectReversalBeanObj.getUploadTime() != null) {
				cell.setCellValue(PayDirectReversalBeanObj.getUploadTime());
				cell.setCellStyle(cellStyle);
			} else
				cell.setCellValue("");

			//sheet.autoSizeColumn(4);
			cell = row.createCell(5);
			cell.setCellValue(PayDirectReversalBeanObj.getFileName());
			//sheet.autoSizeColumn(5);
			cell = row.createCell(6);
			cell.setCellValue(PayDirectReversalBeanObj.getVendorId());
			cell.setCellStyle(rightAligned);
			cell = row.createCell(7);
			cell.setCellValue(PayDirectReversalBeanObj.getTotalRecords());
			//sheet.autoSizeColumn(6);
			cell = row.createCell(8);
			if(PayDirectReversalBeanObj.getReversalType().equalsIgnoreCase("DIRECT_REVERSAL"))
			{
				cell.setCellValue("");
			}
			else{
				cell.setCellValue(PayDirectReversalBeanObj.getTotalValue());
			}
			cell.setCellStyle(rightAligned);
			cell = row.createCell(9);
			cell.setCellValue(PayDirectReversalBeanObj.getInProgressRecords());
			cell = row.createCell(10);
			if(PayDirectReversalBeanObj.getReversalType().equalsIgnoreCase("DIRECT_REVERSAL"))
			{
				cell.setCellValue("");
			}
			else{
				cell.setCellValue(PayDirectReversalBeanObj.getInProgressValue());
			}
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(7);
			cell = row.createCell(11);
			cell.setCellValue(PayDirectReversalBeanObj.getStatus());
			//sheet.autoSizeColumn(8);
			cell = row.createCell(12);
			cell.setCellValue(PayDirectReversalBeanObj.getSuccessRecordCount());
			//sheet.autoSizeColumn(9);
			cell = row.createCell(13);
			if(PayDirectReversalBeanObj.getReversalType().equalsIgnoreCase("DIRECT_REVERSAL"))
			{
				cell.setCellValue("");
			}
			else{
				cell.setCellValue(PayDirectReversalBeanObj.getSuccessRecordValue());
			}
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(10);
			cell = row.createCell(14);
			cell.setCellValue(PayDirectReversalBeanObj.getFailureRecordCount());
			//sheet.autoSizeColumn(11);
			cell = row.createCell(15);
			if(PayDirectReversalBeanObj.getReversalType().equalsIgnoreCase("DIRECT_REVERSAL"))
			{
				cell.setCellValue("");
			}
			else{
				cell.setCellValue(PayDirectReversalBeanObj.getFailureRecordValue());
			}
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(12);
			rowNumber = rowNumber + 1;

		}
		for (int i = 0; i <= 15; i++) {
			sheet.autoSizeColumn(i);
		}
		// write it as an excel attachment
		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		byte[] outArray = outByteStream.toByteArray();
		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
				.format(new Date());
		String fileName1 = "APS_Payment_Reversal_File_level_" + date + " .xlsx";

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName1);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}

		reportslogger.info("End of Payment Reversal Excel records download ");
		// modelAndViewObj.setViewName("viewTracking");
		return modelAndViewObj;
	}

	/******************** PAYMENT DIRECT REVERSAL ************************/

	/*	@RequestMapping(value = "/paymentDirectReversal")
	public ModelAndView paymentDirectReversalHome() {
		reportslogger.info("In Payment Direct Reversal Controller)");
		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("PaymentDirectReversalLogin");
		return modelAndViewObj;
	}
	 */
	@RequestMapping(value = "/paymentDirectReversalRole", method = RequestMethod.GET)
	public ModelAndView getPaymentDirectReversalUserRole(HttpServletRequest request, HttpServletResponse response) 
	{
		ModelAndView modelAndViewObj = new ModelAndView();

		session=request.getSession(false);
		reportslogger.info("In Payment Direct Reversal Controller)");
		PaymentDirectReversalBean PayDirectReversalBeanObj = new PaymentDirectReversalBean();
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		//reportslogger.info("in controller to get role.");

		// get role by calling fn.
		//String parentUserId = request.getParameter("parentUserId");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User Id: " + parentUserId);
		/*Role = ReportsDaoObj.getRole(parentUserId);
		if(Role==-1)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.setViewName("PaymentDirectReversalSearch");
			return modelAndViewObj;
		}*/

		reportslogger.info("User Role" + Role);

		if (Role == 1 || Role == 2 || Role == 7) {

			PayDirectReversalBeanObj.setParentUserId(parentUserId);
			PayDirectReversalBeanObj.setChildUserId(null);
			PayDirectReversalBeanObj.setVendorId(null);
			PayDirectReversalBeanObj.setFileId(null);
			PayDirectReversalBeanObj.setFileName(null);
			PayDirectReversalBeanObj.setToDate(null);
			PayDirectReversalBeanObj.setFromDate(null);
			PayDirectReversalBeanObj.setTrackingId(null);

			HashMap<Integer, List<PaymentDirectReversalBean>> payDirectReversalCompleteDetailsMap = new HashMap<Integer, List<PaymentDirectReversalBean>>();
			int page = 1;
			String statusMsg = null;

			payDirectReversalCompleteDetailsMap = ReportsDaoObj
					.getPayDirectReversalDetails(PayDirectReversalBeanObj, page);
			if(payDirectReversalCompleteDetailsMap==null){
				modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("role", Role);
				modelAndViewObj.setViewName("PaymentDirectReversalSearch");
				return modelAndViewObj;
			}

			reportslogger.info("Details map size in Controller: "+ payDirectReversalCompleteDetailsMap.size());

			if(PayDirectReversalBeanObj.getStatusMsg()!=null)
			{

				if(PayDirectReversalBeanObj.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
				{
					statusMsg="";
				}

				else
				{
					statusMsg=PayDirectReversalBeanObj.getStatusMsg();
				}

			}
			else
				statusMsg="Connectivity Issues..Retry..";


			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.addObject("statusMsg", statusMsg);
			modelAndViewObj.addObject("payDirectReversalDetailsMap",
					payDirectReversalCompleteDetailsMap);
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.setViewName("PaymentDirectReversalSearch");
			return modelAndViewObj;
		}

		else
			reportslogger.info("you do not have privilage to view this page!");

		modelAndViewObj.addObject("error",
				"You do not have privilige to View Reports !!");
		modelAndViewObj.setViewName("PaymentDirectReversalSearch");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/PaymentDirectReversalSearch")
	public ModelAndView paymentDirectReversalDetails(HttpServletRequest request, HttpServletResponse response)
	{


		session=request.getSession(false);
		PaymentDirectReversalBean PayDirectReversalBeanObjSearch = new PaymentDirectReversalBean();
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		PayDirectReversalBeanObjSearch.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);

		reportslogger.info("In Payment Direct Reversal search");
		ModelAndView modelAndViewObj = new ModelAndView();
		/*if(Role==-1)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.setViewName("PaymentDirectReversalSearch");
			return modelAndViewObj;
		}*/
		String childUserId = request.getParameter("childUserId");
		reportslogger.info("User ID: " + childUserId);
		String trackingID = request.getParameter("trackingId");

		reportslogger.info("Tracking ID: " + trackingID);

		String filedId = request.getParameter("fileId");
		reportslogger.info("File ID: " + filedId);

		String fileName = request.getParameter("fileName");
		reportslogger.info("File Name: " + fileName);

		String vendorId = request.getParameter("vendorId");
		reportslogger.info("Vendor ID: " + vendorId);

		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date: " + fromDate);

		String toDate = request.getParameter("endDate");
		reportslogger.info("To Date: " + toDate);

		if (trackingID == null || trackingID.equals("")) {
			PayDirectReversalBeanObjSearch.setTrackingId(null);
		} else {

			PayDirectReversalBeanObjSearch.setTrackingId(trackingID.trim());
		}
		if (childUserId == null || childUserId.equals("")) {
			PayDirectReversalBeanObjSearch.setChildUserId(null);
		} else {
			PayDirectReversalBeanObjSearch.setChildUserId(childUserId.trim());
		}

		if (filedId == null || filedId.equals("")) {
			PayDirectReversalBeanObjSearch.setFileId(null);
		} else {
			PayDirectReversalBeanObjSearch.setFileId(filedId.trim());
		}


		if (fileName == null || fileName.equals("")) {
			PayDirectReversalBeanObjSearch.setFileName(null);
		} else {
			PayDirectReversalBeanObjSearch.setFileName(fileName.trim());
		}


		if (vendorId == null || vendorId.equals("")) {
			PayDirectReversalBeanObjSearch.setVendorId(null);
		} else {
			PayDirectReversalBeanObjSearch.setVendorId(vendorId.trim());
		}

		if (fromDate != "") {

			PayDirectReversalBeanObjSearch.setFromDate(fromDate);
		} else
			PayDirectReversalBeanObjSearch.setFromDate(null);


		if (toDate != "") {
			PayDirectReversalBeanObjSearch.setToDate(toDate);
		} else {
			PayDirectReversalBeanObjSearch.setToDate(null);
		}



		HashMap<Integer, List<PaymentDirectReversalBean>> payDirectReversalMap = new HashMap<Integer, List<PaymentDirectReversalBean>>();
		int page = 1;
		String statusMsg = null;


		payDirectReversalMap = ReportsDaoObj.getPayDirectReversalDetails(
				PayDirectReversalBeanObjSearch, page);
		if(payDirectReversalMap==null){
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PaymentDirectReversalSearch");
			return modelAndViewObj;
		}


		reportslogger.info("Details Map size Based on Search Criteria in Controller: "+payDirectReversalMap.size());


		if(PayDirectReversalBeanObjSearch.getStatusMsg()!=null)
		{

			if(PayDirectReversalBeanObjSearch.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				statusMsg="";
			}

			else
			{
				statusMsg=PayDirectReversalBeanObjSearch.getStatusMsg();
			}

		}
		else
			statusMsg="Connectivity Issues..Retry..";
		modelAndViewObj.addObject("role", Role);
		modelAndViewObj.addObject("statusMsg", statusMsg);
		modelAndViewObj.addObject("payDirectReversalDetailsMap",
				payDirectReversalMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("PayDirectReversalBeanObjJsp", PayDirectReversalBeanObjSearch);
		modelAndViewObj.setViewName("PaymentDirectReversalSearch");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/paymentDirectReversalPagination")
	public ModelAndView paymentDirectReversalPagination(HttpServletRequest request, HttpServletResponse response)
	{


		session=request.getSession(false);
		PaymentDirectReversalBean PayDirectReversalBeanObjPag = new PaymentDirectReversalBean();
		reportslogger.info("In Payment Direct Reversal Pagination");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		PayDirectReversalBeanObjPag.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);
		String childUserId = request.getParameter("childUserId");
		reportslogger.info("User ID: " + childUserId);
		String trackingID = request.getParameter("trackingId");

		reportslogger.info("Tracking ID: " + trackingID);

		String filedId = request.getParameter("fileId");
		reportslogger.info("File ID: " + filedId);

		String fileName = request.getParameter("fileName");
		reportslogger.info("File Name: " + fileName);

		String vendorId = request.getParameter("vendorId");
		reportslogger.info("Vendor ID: " + vendorId);

		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date: " + fromDate);

		String toDate = request.getParameter("endDate");
		reportslogger.info("To Date: " + toDate);

		if (trackingID == null || trackingID.equals("")) {
			PayDirectReversalBeanObjPag.setTrackingId(null);
		} else {

			PayDirectReversalBeanObjPag.setTrackingId(trackingID.trim());
		}
		if (childUserId == null || childUserId.equals("")) {
			PayDirectReversalBeanObjPag.setChildUserId(null);
		} else {
			PayDirectReversalBeanObjPag.setChildUserId(childUserId.trim());
		}

		if (filedId == null || filedId.equals("")) {
			PayDirectReversalBeanObjPag.setFileId(null);
		} else {
			PayDirectReversalBeanObjPag.setFileId(filedId.trim());
		}


		if (fileName == null || fileName.equals("")) {
			PayDirectReversalBeanObjPag.setFileName(null);
		} else {
			PayDirectReversalBeanObjPag.setFileName(fileName.trim());
		}


		if (vendorId == null || vendorId.equals("")) {
			PayDirectReversalBeanObjPag.setVendorId(null);
		} else {
			PayDirectReversalBeanObjPag.setVendorId(vendorId.trim());
		}

		if (fromDate != "") {

			PayDirectReversalBeanObjPag.setFromDate(fromDate);
		} else
			PayDirectReversalBeanObjPag.setFromDate(null);


		if (toDate != "") {
			PayDirectReversalBeanObjPag.setToDate(toDate);
		} else {
			PayDirectReversalBeanObjPag.setToDate(null);
		}




		HashMap<Integer, List<PaymentDirectReversalBean>> payDirectReversalMap = new HashMap<Integer, List<PaymentDirectReversalBean>>();
		int page = Integer.parseInt(request.getParameter("pageNum"));
		reportslogger.info("Page No. :"+page);
		String statusMsg = null;
		ModelAndView modelAndViewObj = new ModelAndView();

		payDirectReversalMap = ReportsDaoObj.getPayDirectReversalDetails(
				PayDirectReversalBeanObjPag, page);
		if(payDirectReversalMap==null){
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PaymentDirectReversalSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Details map size Based on Page No. in Controller"+payDirectReversalMap.size());


		/*	reportslogger.info("method called in controler");

		reportslogger.info("in controller"
				+ PayDirectReversalBeanObj.getStatusMsg());
		 */if(PayDirectReversalBeanObjPag.getStatusMsg()!=null)
		 {

			 if(PayDirectReversalBeanObjPag.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			 {
				 statusMsg="";
			 }

			 else
			 {
				 statusMsg=PayDirectReversalBeanObjPag.getStatusMsg();
			 }

		 }
		 else
			 statusMsg="Connectivity Issues..Retry..";
		 modelAndViewObj.addObject("role", Role);
		 modelAndViewObj.addObject("statusMsg", statusMsg);
		 modelAndViewObj.addObject("payDirectReversalDetailsMap",
				 payDirectReversalMap);
		 modelAndViewObj.addObject("currentPage", page);
		 modelAndViewObj.addObject("PayDirectReversalBeanObjJsp", PayDirectReversalBeanObjPag);
		 modelAndViewObj.setViewName("PaymentDirectReversalSearch");
		 return modelAndViewObj;
	}

	@RequestMapping(value = "/PaymentDirectReversalExcelFileDownload", method = RequestMethod.POST)
	public ModelAndView paymentDirectRevexcelFileDownload(HttpServletRequest request, HttpServletResponse response)throws IOException 
	{
		session=request.getSession(false);
		PaymentDirectReversalBean PayDirectReversalBeanObjExcel = new PaymentDirectReversalBean();
		reportslogger.info("In Payment Direct Reversal Excel File Download");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		PayDirectReversalBeanObjExcel.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);
		String childUserId = request.getParameter("childUserId");
		reportslogger.info("User ID: " + childUserId);
		String trackingID = request.getParameter("trackingId");

		reportslogger.info("Tracking ID: " + trackingID);

		String filedId = request.getParameter("fileId");
		reportslogger.info("File ID: " + filedId);

		String fileName = request.getParameter("fileName");
		reportslogger.info("File Name: " + fileName);

		String vendorId = request.getParameter("vendorId");
		reportslogger.info("Vendor ID: " + vendorId);

		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date: " + fromDate);

		String toDate = request.getParameter("endDate");
		reportslogger.info("To Date: " + toDate);

		if (trackingID == null || trackingID.equals("")) {
			PayDirectReversalBeanObjExcel.setTrackingId(null);
		} else {

			PayDirectReversalBeanObjExcel.setTrackingId(trackingID.trim());
		}
		if (childUserId == null || childUserId.equals("")) {
			PayDirectReversalBeanObjExcel.setChildUserId(null);
		} else {
			PayDirectReversalBeanObjExcel.setChildUserId(childUserId.trim());
		}

		if (filedId == null || filedId.equals("")) {
			PayDirectReversalBeanObjExcel.setFileId(null);
		} else {
			PayDirectReversalBeanObjExcel.setFileId(filedId.trim());
		}


		if (fileName == null || fileName.equals("")) {
			PayDirectReversalBeanObjExcel.setFileName(null);
		} else {
			PayDirectReversalBeanObjExcel.setFileName(fileName.trim());
		}


		if (vendorId == null || vendorId.equals("")) {
			PayDirectReversalBeanObjExcel.setVendorId(null);
		} else {
			PayDirectReversalBeanObjExcel.setVendorId(vendorId.trim());
		}

		if (fromDate != "") {

			PayDirectReversalBeanObjExcel.setFromDate(fromDate);
		} else
			PayDirectReversalBeanObjExcel.setFromDate(null);


		if (toDate != "") {
			PayDirectReversalBeanObjExcel.setToDate(toDate);
		} else {
			PayDirectReversalBeanObjExcel.setToDate(null);
		}




		List<PaymentDirectReversalBean> PayReversalExcellDetailsList = new ArrayList<PaymentDirectReversalBean>();
		String pageNo = null;
		int rowNumber = 1;
		ModelAndView modelAndViewObj = new ModelAndView();

		PayReversalExcellDetailsList = ReportsDaoObj
				.getPayDirectRevExcelDetails(PayDirectReversalBeanObjExcel, pageNo);
		if(PayReversalExcellDetailsList==null){
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PaymentDirectReversalSearch");
			return modelAndViewObj;
		}

		reportslogger.info("Excel Details size In Controller: "+ PayReversalExcellDetailsList.size());
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("Direct_Reversal_Trans_Level");
		XSSFCell cell = null;
		XSSFRow row;
		XSSFCellStyle my_style = wb.createCellStyle();
		XSSFFont my_font=wb.createFont();
		my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		my_style.setFont(my_font);
		XSSFCellStyle rightAligned = wb.createCellStyle();
		rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);




		row = sheet.createRow(0);
		cell = row.createCell(0);
		cell.setCellValue("Account No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(1);
		cell.setCellValue("Tracking ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(2);
		cell.setCellValue("Tracking ID serv");
		cell.setCellStyle(my_style);
		cell = row.createCell(3);
		cell.setCellValue("Uploaded By(OLM ID) ");
		cell.setCellStyle(my_style);
		cell = row.createCell(4);
		cell.setCellValue("Uploaded By(Name)");
		cell.setCellStyle(my_style);
		cell = row.createCell(5);
		cell.setCellValue("File ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(6);
		cell.setCellValue("File Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(7);
		cell.setCellValue("Uploaded Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(8);
		cell.setCellValue("Status");
		cell.setCellStyle(my_style);
		cell = row.createCell(9);
		cell.setCellValue("Reversal Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(10);
		cell.setCellValue("Reason For Failure");
		cell.setCellStyle(my_style);

		for (int i = 0; i < PayReversalExcellDetailsList.size(); i++) {

			PaymentDirectReversalBean PayDirectReversalBeanObj = PayReversalExcellDetailsList
					.get(i);
			// reportslogger.info("in controller uplodeddate"+PayPostingFilelevelDetailsObj.getUplodedDateTime());
			row = sheet.createRow(rowNumber);
			cell = row.createCell(0);
			cell.setCellValue(PayDirectReversalBeanObj.getAccountNumber());
			//sheet.autoSizeColumn(0);
			cell = row.createCell(1);
			if (PayDirectReversalBeanObj.getTrackingId() == null
					|| PayDirectReversalBeanObj.getTrackingId()
					.equalsIgnoreCase("NA"))
				cell.setCellValue("");
			else
				cell.setCellValue(PayDirectReversalBeanObj.getTrackingId());
			cell.setCellStyle(rightAligned);

			//sheet.autoSizeColumn(1);
			cell = row.createCell(2);
			if (PayDirectReversalBeanObj.getTrackingIdServ() == null
					|| PayDirectReversalBeanObj.getTrackingIdServ()
					.equalsIgnoreCase("NA"))
				cell.setCellValue("");
			else
				cell.setCellValue(PayDirectReversalBeanObj.getTrackingIdServ());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(2);
			cell = row.createCell(3);
			cell.setCellValue(PayDirectReversalBeanObj.getUploadedByOlmId());
			//sheet.autoSizeColumn(3);
			cell = row.createCell(4);
			cell.setCellValue(PayDirectReversalBeanObj.getUploadedByName());
			//sheet.autoSizeColumn(4);
			cell = row.createCell(5);
			cell.setCellValue(PayDirectReversalBeanObj.getFileId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(5);

			cell = row.createCell(6);
			cell.setCellValue(PayDirectReversalBeanObj.getFileName());
			//sheet.autoSizeColumn(6);
			cell = row.createCell(7);
			CellStyle cellStyle = wb.createCellStyle();
			CreationHelper createHelper = wb.getCreationHelper();

			cellStyle.setDataFormat(createHelper.createDataFormat().getFormat(
					"dd/mm/yyyy"));
			if (PayDirectReversalBeanObj.getUploadDateTime() != null) {
				cell.setCellValue(PayDirectReversalBeanObj.getUploadDateTime());
				cell.setCellStyle(cellStyle);
			} else
				cell.setCellValue("");

			//sheet.autoSizeColumn(7);
			cell = row.createCell(8);
			cell.setCellValue(PayDirectReversalBeanObj.getStatus());
			//sheet.autoSizeColumn(8);
			cell = row.createCell(9);
			if (PayDirectReversalBeanObj.getFxUpdateTime() == null
					|| PayDirectReversalBeanObj.getFxUpdateTime()
					.equalsIgnoreCase("NA"))
				cell.setCellValue("");
			else
				cell.setCellValue(PayDirectReversalBeanObj.getFxUpdateTime());
			//sheet.autoSizeColumn(9);
			cell = row.createCell(10);
			if (PayDirectReversalBeanObj.getReasonForFailue() == null
					|| PayDirectReversalBeanObj.getReasonForFailue()
					.equalsIgnoreCase("NA"))
				cell.setCellValue("");
			else
				cell.setCellValue(PayDirectReversalBeanObj.getReasonForFailue());
			//sheet.autoSizeColumn(10);

			rowNumber = rowNumber + 1;

		}
		for (int i = 0; i <= 10; i++) {
			sheet.autoSizeColumn(i);
		}
		// write it as an excel attachment
		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		byte[] outArray = outByteStream.toByteArray();
		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
				.format(new Date());
		String fileName1 = "APS_Direct_Reversal_Transaction_Level_" + date + " .xlsx";

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName1);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}

		reportslogger.info("End of Payment Direct Reversal Excel records download ");
		// modelAndViewObj.setViewName("viewTracking");
		return modelAndViewObj;
	}

	/************************************ PAYMENT REVERSAL CHEQUE BOUNCE ***************************************************/

	/*@RequestMapping(value = "/PymntRevChqBounceRecordsSummary")
	public ModelAndView PymntRevChqBounceRecordsSummary() {
		reportslogger.info("In payment Reversal Cheque Bounce Controller");
		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("PaymentRevChqBounceLogin");
		return modelAndViewObj;
	}*/

	@RequestMapping(value = "/getRolePayRevChqBounce", method = RequestMethod.GET)
	public ModelAndView getRolePayRevChqBounce(HttpServletRequest request,HttpServletResponse response) 
	{
		// session=request.getSession(false);
		session=request.getSession(false);
		reportslogger.info("In payment Reversal Cheque Bounce Controller");
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		PayRevChqBounceRecordsDetails PayRevChqBounceRecordsDetailsObj = new PayRevChqBounceRecordsDetails();
		//reportslogger.info("in controller to get  role.");
		ModelAndView modelAndViewObj = new ModelAndView();

		//String parentUserId = request.getParameter("UserId");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: "+parentUserId);
		/* Role = ReportsDaoObj.getRole(parentUserId);
		 if(Role==-1)
			{
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("PaymentRevChqBounceSearch");
				return modelAndViewObj;
			}*/

		reportslogger.info("User Role:" + Role);

		if ((Role == 1) || (Role == 2) || (Role == 3) || (Role == 4)
				|| (Role == 7)) {

			PayRevChqBounceRecordsDetailsObj.setParentUserId(parentUserId);
			/*PayRevChqBounceRecordsDetailsObj.setRole(Role);*/
			PayRevChqBounceRecordsDetailsObj.setToDate(null);
			PayRevChqBounceRecordsDetailsObj.setFromDate(null);
			PayRevChqBounceRecordsDetailsObj.setVendorId(null);
			PayRevChqBounceRecordsDetailsObj.setRefNo(null);
			PayRevChqBounceRecordsDetailsObj.setChildUserId(null);
			PayRevChqBounceRecordsDetailsObj.setFileId(null);
			PayRevChqBounceRecordsDetailsObj.setFileName(null);

			// call method from dao and get records based on parentuserId only.
			int page = 1;
			String errMsg = null;

			HashMap<Integer, List<PayRevChqBounceRecordsDetails>> ReportsMap = new HashMap<Integer, List<PayRevChqBounceRecordsDetails>>();

			// set statusmsg in daoimpl

			ReportsMap = ReportsDaoObj.getPymntRevChqBounceRecords(
					PayRevChqBounceRecordsDetailsObj, page);
			if(ReportsMap==null){
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("UserRole", Role);
				modelAndViewObj.setViewName("PaymentRevChqBounceSearch");
				return modelAndViewObj;
			}
			reportslogger.info("Deatils Map Size in Controller:"+ReportsMap.size());


			if(PayRevChqBounceRecordsDetailsObj.getStatusMsg()!=null)
			{

				if(PayRevChqBounceRecordsDetailsObj.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
				{
					errMsg="";
				}

				else
				{
					errMsg=PayRevChqBounceRecordsDetailsObj.getStatusMsg();
				}

			}
			else
				errMsg="Connectivity Issues..Retry..";




			modelAndViewObj.addObject("ReportsMap", ReportsMap);
			modelAndViewObj.addObject("errMsg", errMsg);
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.setViewName("PaymentRevChqBounceSearch");
		}

		else {
			modelAndViewObj.addObject("error",
					"You do not have privilige to check the reports !!");
			modelAndViewObj.setViewName("PaymentRevChqBounceSearch");
			return modelAndViewObj;
		}

		return modelAndViewObj;
	}

	@RequestMapping(value = "/getPymntRevChqBounceRecords")
	public ModelAndView getFilteredPymntRevChqBounceRecords(HttpServletRequest request, HttpServletResponse response)
	{
		session=request.getSession(false);
		reportslogger.info("In Payment Reversal Cheque Bounce Search");
		PayRevChqBounceRecordsDetails PayRevChqBounceRecordsDetailsObjSearch = new PayRevChqBounceRecordsDetails();
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		PayRevChqBounceRecordsDetailsObjSearch.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		ModelAndView modelAndViewObj = new ModelAndView();
		/*if(Role==-1)
		{
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.setViewName("PaymentRevChqBounceSearch");
			return modelAndViewObj;
		}*/
		/*int Role = PayRevChqBounceRecordsDetailsObj.getRole();*/
		int page = 1;
		String errMsg = null;
		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date: " + fromDate);
		String toDate = request.getParameter("endDate");
		reportslogger.info("To date: " + toDate);
		String refNo = request.getParameter("refNo");
		reportslogger.info("Reference No. : "+refNo);
		String userOLMId = request.getParameter("userId");
		reportslogger.info("User ID: "+userOLMId);
		String fileId = request.getParameter("fileId");
		reportslogger.info("File ID: "+fileId);
		String fileName = request.getParameter("fileName");
		reportslogger.info("File Name: "+fileName);
		String vendorId = request.getParameter("vendorId");
		reportslogger.info("Vendor ID: "+vendorId);

		if (fromDate != "") {
			PayRevChqBounceRecordsDetailsObjSearch.setFromDate(fromDate);
		} else

			PayRevChqBounceRecordsDetailsObjSearch.setFromDate(null);

		if (toDate != "") {
			PayRevChqBounceRecordsDetailsObjSearch.setToDate(toDate);
		} else

			PayRevChqBounceRecordsDetailsObjSearch.setToDate(null);

		if (vendorId == null || vendorId.equals("")) {
			PayRevChqBounceRecordsDetailsObjSearch.setVendorId(null);
		} else
			PayRevChqBounceRecordsDetailsObjSearch.setVendorId(vendorId.trim());

		if (refNo == null || refNo.equals("")) {
			PayRevChqBounceRecordsDetailsObjSearch.setRefNo(null);
		} else
			PayRevChqBounceRecordsDetailsObjSearch.setRefNo(refNo.trim());

		if (fileId == null || fileId.equals("")) {
			PayRevChqBounceRecordsDetailsObjSearch.setFileId(null);

		} else
			PayRevChqBounceRecordsDetailsObjSearch.setFileId(fileId.trim());

		if (fileName == null || fileName.equals("")) {
			PayRevChqBounceRecordsDetailsObjSearch.setFileName(null);
		} else
			PayRevChqBounceRecordsDetailsObjSearch.setFileName(fileName.trim());
		if (userOLMId == null || userOLMId.equals("")) {
			PayRevChqBounceRecordsDetailsObjSearch.setChildUserId(null);
		} else
			PayRevChqBounceRecordsDetailsObjSearch.setChildUserId(userOLMId.trim());


		HashMap<Integer, List<PayRevChqBounceRecordsDetails>> ReportsMapwithFilter = new HashMap<Integer, List<PayRevChqBounceRecordsDetails>>();

		// set statusmsg in daoimpl

		ReportsMapwithFilter = ReportsDaoObj.getPymntRevChqBounceRecords(
				PayRevChqBounceRecordsDetailsObjSearch, page);
		if(ReportsMapwithFilter==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentRevChqBounceSearch");
			return modelAndViewObj;
		}

		reportslogger.info("Details Map size Based on search Criteria in Controller: "+ ReportsMapwithFilter.size());

		if(PayRevChqBounceRecordsDetailsObjSearch.getStatusMsg()!=null)
		{

			if(PayRevChqBounceRecordsDetailsObjSearch.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				errMsg="";
			}

			else
			{
				errMsg=PayRevChqBounceRecordsDetailsObjSearch.getStatusMsg();
			}

		}
		else
			errMsg="Connectivity Issues..Retry..";
		modelAndViewObj.addObject("ReportsMap", ReportsMapwithFilter);
		modelAndViewObj.addObject("UserRole", Role);
		modelAndViewObj.addObject("errMsg", errMsg);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("PayRevChqBounceRecordsDetailsObjJsp", PayRevChqBounceRecordsDetailsObjSearch);
		modelAndViewObj.setViewName("PaymentRevChqBounceSearch");

		return modelAndViewObj;
	}

	@RequestMapping(value = "/viewRevChqBounceRecordswithPagination")
	public ModelAndView viewRevChqBounceRecordswithPagination(
			HttpServletRequest request, HttpServletResponse response) {
		session=request.getSession(false);
		PayRevChqBounceRecordsDetails PayRevChqBounceRecordsDetailsObjPag = new PayRevChqBounceRecordsDetails();
		reportslogger.info("In Payment Reversal Cheque Bounce Pagination");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		PayRevChqBounceRecordsDetailsObjPag.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);
		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date: " + fromDate);
		String toDate = request.getParameter("endDate");
		reportslogger.info("To date: " + toDate);
		String refNo = request.getParameter("refNo");
		reportslogger.info("Reference No. : "+refNo);
		String userOLMId = request.getParameter("userId");
		reportslogger.info("User ID: "+userOLMId);
		String fileId = request.getParameter("fileId");
		reportslogger.info("File ID: "+fileId);
		String fileName = request.getParameter("fileName");
		reportslogger.info("File Name: "+fileName);
		String vendorId = request.getParameter("vendorId");
		reportslogger.info("Vendor ID: "+vendorId);

		if (fromDate != "") {
			PayRevChqBounceRecordsDetailsObjPag.setFromDate(fromDate);
		} else

			PayRevChqBounceRecordsDetailsObjPag.setFromDate(null);

		if (toDate != "") {
			PayRevChqBounceRecordsDetailsObjPag.setToDate(toDate);
		} else

			PayRevChqBounceRecordsDetailsObjPag.setToDate(null);

		if (vendorId == null || vendorId.equals("")) {
			PayRevChqBounceRecordsDetailsObjPag.setVendorId(null);
		} else
			PayRevChqBounceRecordsDetailsObjPag.setVendorId(vendorId.trim());

		if (refNo == null || refNo.equals("")) {
			PayRevChqBounceRecordsDetailsObjPag.setRefNo(null);
		} else
			PayRevChqBounceRecordsDetailsObjPag.setRefNo(refNo.trim());

		if (fileId == null || fileId.equals("")) {
			PayRevChqBounceRecordsDetailsObjPag.setFileId(null);

		} else
			PayRevChqBounceRecordsDetailsObjPag.setFileId(fileId.trim());

		if (fileName == null || fileName.equals("")) {
			PayRevChqBounceRecordsDetailsObjPag.setFileName(null);
		} else
			PayRevChqBounceRecordsDetailsObjPag.setFileName(fileName.trim());
		if (userOLMId == null || userOLMId.equals("")) {
			PayRevChqBounceRecordsDetailsObjPag.setChildUserId(null);
		} else
			PayRevChqBounceRecordsDetailsObjPag.setChildUserId(userOLMId.trim());



		ModelAndView modelAndViewObj = new ModelAndView();
		String errMsg = null;
		/*int Role = PayRevChqBounceRecordsDetailsObj.getRole();*/
		int page = Integer.parseInt(request.getParameter("pageNum"));
		reportslogger.info("Page No."+page);
		HashMap<Integer, List<PayRevChqBounceRecordsDetails>> ReportsMapwithFilterwithPagination = new HashMap<Integer, List<PayRevChqBounceRecordsDetails>>();

		ReportsMapwithFilterwithPagination = ReportsDaoObj
				.getPymntRevChqBounceRecords(PayRevChqBounceRecordsDetailsObjPag,
						page);
		if(ReportsMapwithFilterwithPagination==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentRevChqBounceSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Details map Size based on Page No in Controller: "+ReportsMapwithFilterwithPagination.size());
		if(PayRevChqBounceRecordsDetailsObjPag.getStatusMsg()!=null)
		{

			if(PayRevChqBounceRecordsDetailsObjPag.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				errMsg="";
			}

			else
			{
				errMsg=PayRevChqBounceRecordsDetailsObjPag.getStatusMsg();
			}

		}
		else
			errMsg="Connectivity Issues..Retry..";

		modelAndViewObj.addObject("ReportsMap",
				ReportsMapwithFilterwithPagination);
		modelAndViewObj.addObject("UserRole", Role);
		modelAndViewObj.addObject("errMsg", errMsg);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("PayRevChqBounceRecordsDetailsObjJsp", PayRevChqBounceRecordsDetailsObjPag);
		modelAndViewObj.setViewName("PaymentRevChqBounceSearch");

		return modelAndViewObj;
	}

	@RequestMapping(value = "/PayRevChqBounceToExcel", method = RequestMethod.POST)
	public ModelAndView PayRevChqBounceToExcel(HttpServletRequest request,HttpServletResponse response) 
	{
		ModelAndView modelAndViewObj = new ModelAndView();
		PayRevChqBounceRecordsDetails PayRevChqBounceRecordsDetailsObjExcel = new PayRevChqBounceRecordsDetails();
		reportslogger.info("In Payment Reversal Cheque Bounce Excel File Download");
		String pageNum =null;
		session=request.getSession(false);

		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		PayRevChqBounceRecordsDetailsObjExcel.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);
		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date: " + fromDate);
		String toDate = request.getParameter("endDate");
		reportslogger.info("To date: " + toDate);
		String refNo = request.getParameter("refNo");
		reportslogger.info("Reference No. : "+refNo);
		String userOLMId = request.getParameter("userId");
		reportslogger.info("User ID: "+userOLMId);
		String fileId = request.getParameter("fileId");
		reportslogger.info("File ID: "+fileId);
		String fileName = request.getParameter("fileName");
		reportslogger.info("File Name: "+fileName);
		String vendorId = request.getParameter("vendorId");
		reportslogger.info("Vendor ID: "+vendorId);

		if (fromDate != "") {
			PayRevChqBounceRecordsDetailsObjExcel.setFromDate(fromDate);
		} else

			PayRevChqBounceRecordsDetailsObjExcel.setFromDate(null);

		if (toDate != "") {
			PayRevChqBounceRecordsDetailsObjExcel.setToDate(toDate);
		} else

			PayRevChqBounceRecordsDetailsObjExcel.setToDate(null);

		if (vendorId == null || vendorId.equals("")) {
			PayRevChqBounceRecordsDetailsObjExcel.setVendorId(null);
		} else
			PayRevChqBounceRecordsDetailsObjExcel.setVendorId(vendorId.trim());

		if (refNo == null || refNo.equals("")) {
			PayRevChqBounceRecordsDetailsObjExcel.setRefNo(null);
		} else
			PayRevChqBounceRecordsDetailsObjExcel.setRefNo(refNo.trim());

		if (fileId == null || fileId.equals("")) {
			PayRevChqBounceRecordsDetailsObjExcel.setFileId(null);

		} else
			PayRevChqBounceRecordsDetailsObjExcel.setFileId(fileId.trim());

		if (fileName == null || fileName.equals("")) {
			PayRevChqBounceRecordsDetailsObjExcel.setFileName(null);
		} else
			PayRevChqBounceRecordsDetailsObjExcel.setFileName(fileName.trim());
		if (userOLMId == null || userOLMId.equals("")) {
			PayRevChqBounceRecordsDetailsObjExcel.setChildUserId(null);
		} else
			PayRevChqBounceRecordsDetailsObjExcel.setChildUserId(userOLMId.trim());


		List<PayRevChqBounceRecordsDetails> PayRevChqBounceExportToExcelList = new ArrayList<PayRevChqBounceRecordsDetails>();

		PayRevChqBounceExportToExcelList = ReportsDaoObj
				.getPymntRevChqBounceList(PayRevChqBounceRecordsDetailsObjExcel,
						pageNum);
		if(PayRevChqBounceExportToExcelList==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentRevChqBounceSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Excel list size in Controller:"+ PayRevChqBounceExportToExcelList.size());
		int rowNumber = 1;
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("Payment_Reversal_Cheque_Bounce");
		XSSFCell cell = null;
		XSSFRow row;
		XSSFCellStyle my_style = wb.createCellStyle();
		XSSFFont my_font=wb.createFont();
		my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		my_style.setFont(my_font);
		XSSFCellStyle rightAligned = wb.createCellStyle();
		rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);




		row = sheet.createRow(0);
		cell = row.createCell(0);
		cell.setCellValue("Uploaded By(OLM ID)");
		cell.setCellStyle(my_style);
		cell = row.createCell(1);
		cell.setCellValue("Vendor ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(2);
		cell.setCellValue("Vendor Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(3);
		cell.setCellValue("LOB");
		cell.setCellStyle(my_style);
		cell = row.createCell(4);
		cell.setCellValue("File ID");

		cell.setCellStyle(my_style);
		cell = row.createCell(5);
		cell.setCellValue("Uploaded File Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(6);
		cell.setCellValue("Cheque No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(7);
		cell.setCellValue("Bank Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(8);
		cell.setCellValue("Cheque Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(9);
		cell.setCellValue("Bank Account No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(10);
		cell.setCellValue("No. Of Accounts Posted");
		cell.setCellStyle(my_style);
		cell = row.createCell(11);
		cell.setCellValue("No. Of Invoices Posted");
		cell.setCellStyle(my_style);
		cell = row.createCell(12);
		cell.setCellValue("Total Cheque Value");
		cell.setCellStyle(my_style);
		cell = row.createCell(13);
		cell.setCellValue("Initial Uploaded Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(14);
		cell.setCellValue("Initial Posted Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(15);
		cell.setCellValue("Bounced Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(16);
		cell.setCellValue("Bounced MIS Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(17);
		cell.setCellValue("Reversal Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(18);
		cell.setCellValue("Initial Uploaded vs Bounced Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(19);
		cell.setCellValue("Bounced Date vs Bounce MIS Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(20);
		cell.setCellValue("Bounced Date vs Reversal Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(21);
		cell.setCellValue("Bounce MIS Date vs Reversal Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(22);
		cell.setCellValue("Status");
		cell.setCellStyle(my_style);
		cell = row.createCell(23);
		cell.setCellValue("Reason For Failure");
		cell.setCellStyle(my_style);

		for (int i = 0; i < PayRevChqBounceExportToExcelList.size(); i++) {
			// reportslogger.info("i value"+i);
			PayRevChqBounceRecordsDetails PayRevChqBounceRecordsDetailsObject = PayRevChqBounceExportToExcelList
					.get(i);

			row = sheet.createRow(rowNumber);
			cell = row.createCell(0);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject
					.getUploadedUser());
			cell = row.createCell(1);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject
					.getVendorId());
			cell.setCellStyle(rightAligned);
			cell = row.createCell(2);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject
					.getVendorName());
			//sheet.autoSizeColumn(0);

			cell = row.createCell(3);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject.getLob());
			//sheet.autoSizeColumn(1);
			cell = row.createCell(4);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject.getFileId());
			cell.setCellStyle(rightAligned);

			//sheet.autoSizeColumn(2);
			cell = row.createCell(5);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject.getFileName());
			cell = row.createCell(6);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject.getRefNo());
			//sheet.autoSizeColumn(3);
			cell = row.createCell(7);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject.getBankName());
			//sheet.autoSizeColumn(4);

			cell = row.createCell(8);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject
					.getDateonChq());
			cell = row.createCell(9);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject
					.getBankAccNo());
			//sheet.autoSizeColumn(5);
			cell = row.createCell(10);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject
					.getNoOfAccPostedFx());
			//sheet.autoSizeColumn(6);

			cell = row.createCell(11);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject
					.getNoOfInvPostedFx());
			//sheet.autoSizeColumn(7);
			cell = row.createCell(12);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject
					.getTotChqVal());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(8);
			cell = row.createCell(13);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject
					.getInitialUploadedDate());
			//sheet.autoSizeColumn(9);
			cell = row.createCell(14);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject
					.getInitialPostedDate());
			//sheet.autoSizeColumn(10);
			cell = row.createCell(15);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject
					.getBouncedDate());
			//sheet.autoSizeColumn(11);
			cell = row.createCell(16);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject
					.getBounceMisDate());
			//sheet.autoSizeColumn(12);
			cell = row.createCell(17);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject
					.getRevPostingFxDate());
			//sheet.autoSizeColumn(13);
			cell = row.createCell(18);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject
					.getDiffInitalVsBouncedDate());
			//sheet.autoSizeColumn(14);
			cell = row.createCell(19);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject
					.getDiffBouncedVsBouncdMisDate());
			//sheet.autoSizeColumn(15);
			cell = row.createCell(20);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject
					.getDiffBouncedVspostingRevDate());
			//sheet.autoSizeColumn(16);
			cell = row.createCell(21);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject
					.getDiffBounceMisDateVspostingRevDate());
			//sheet.autoSizeColumn(17);
			cell = row.createCell(22);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject.getStatus());
			//sheet.autoSizeColumn(18);
			cell = row.createCell(23);
			cell.setCellValue(PayRevChqBounceRecordsDetailsObject.getReasonForFailure());


			rowNumber++;

		}
		for(int i=0;i<=23;i++){

			sheet.autoSizeColumn(i);
		}
		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		byte[] outArray = outByteStream.toByteArray();

		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
				.format(new Date());

		String fileName1 = "APS_Payment_Reversal_Cheque_Bounce" + "_" + date + ".xlsx";
		reportslogger.info("filename is" + fileName);

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName1);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}

		reportslogger.info("End of Payment Reversal Cheque Bounce Excel records download "); 

		return modelAndViewObj;

	}


	/************************ PAYMENT TRANSFER TRANS LEVEL *****************************************/

	/*@RequestMapping(value = "/PaymentTransferTransLevel")
	public ModelAndView PaymentTransferTransLevelHome() {
		reportslogger.info("in controller(PayTransferTransLevel)");
		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("PaymentTransferTransLogin");
		return modelAndViewObj;
	}*/

	@RequestMapping(value = "/PaymentTransferTransRole", method = RequestMethod.GET)
	public ModelAndView paymentTransferRole(HttpServletRequest request,HttpServletResponse response) 
	{

		session=request.getSession(false);
		PaymentTransferTransLevelBean PayTransferTransLevelBeanObj=new PaymentTransferTransLevelBean();
		reportslogger.info("In Payment Transfer Transaction Level Controller");
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in PaymentTransferTransRole mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		//reportslogger.info("in controller to get  role.");
		ModelAndView modelAndViewObj = new ModelAndView();

		//String parentUserId = request.getParameter("UserId");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: "+parentUserId);
		/* Role = ReportsDaoObj.getRole(parentUserId);
		 if(Role==-1)
			{
				modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("PaymentTransferTransSearch");
				return modelAndViewObj;
			}
		 */
		reportslogger.info("User Role:" + Role);
		if (Role==1||Role==2|| Role ==7) {

			PayTransferTransLevelBeanObj.setParentUserId(parentUserId);
			PayTransferTransLevelBeanObj.setChildUserId(null);
			PayTransferTransLevelBeanObj.setVendorId(null);
			PayTransferTransLevelBeanObj.setFileId(null);
			PayTransferTransLevelBeanObj.setFileName(null);
			PayTransferTransLevelBeanObj.setToDate(null);
			PayTransferTransLevelBeanObj.setFromDate(null);
			PayTransferTransLevelBeanObj.setSourceTrackingId(null);

			HashMap<Integer, List<PaymentTransferTransLevelBean>> payTransferTransLevelMap = new HashMap<Integer, List<PaymentTransferTransLevelBean>>();
			int page = 1;
			String statusMsg = null;

			payTransferTransLevelMap= ReportsDaoObj.getPaymentTransferTransLevelDetails(PayTransferTransLevelBeanObj, page);
			if(payTransferTransLevelMap==null){
				modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("role", Role);
				modelAndViewObj.setViewName("PaymentTransferTransSearch");
				return modelAndViewObj;
			}
			reportslogger.info("Details map Size in Controller: "+payTransferTransLevelMap.size());


			if(PayTransferTransLevelBeanObj.getStatusMsg()!=null)
			{

				if(PayTransferTransLevelBeanObj.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
				{
					statusMsg="";
				}

				else
				{
					statusMsg=PayTransferTransLevelBeanObj.getStatusMsg();
				}

			}
			else
				statusMsg="Connectivity Issues..Retry..";




			modelAndViewObj.addObject("role",Role);
			modelAndViewObj.addObject("statusMsg", statusMsg);
			modelAndViewObj.addObject("payTransferTransLevelDetailsMap", payTransferTransLevelMap);
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.setViewName("PaymentTransferTransSearch");
			return modelAndViewObj;
		}

		else
		{
			reportslogger.info("you do not have privilage to view this page!");

			modelAndViewObj.addObject("error",
					"You do not have privilige to View Reports !!");
			modelAndViewObj.setViewName("PaymentTransferTransSearch");
			return modelAndViewObj;
		}
	}

	@RequestMapping(value = "/PaymentTransferTransLevelTracking")

	public ModelAndView getPaymentTransferTransDetails(HttpServletRequest request,HttpServletResponse response)
	{
		session=request.getSession(false);
		PaymentTransferTransLevelBean PayTransferTransLevelBeanObjSearch=new PaymentTransferTransLevelBean();
		reportslogger.info("In Payment Transfer Transaction Level Search");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		PayTransferTransLevelBeanObjSearch.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in PaymentTransferTransLevelTracking mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		/*PayPostingFilelevelDetails payPostingFilelevelDetailsObj=new PayPostingFilelevelDetails();*/

		ModelAndView modelAndViewObj = new ModelAndView();
		/*if(Role==-1)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.setViewName("PaymentTransferTransSearch");
			return modelAndViewObj;
		}*/

		String childUserId=request.getParameter("childUserId");
		reportslogger.info("User ID: "+childUserId);
		String trackingID=request.getParameter("trackingId");


		reportslogger.info("Tracking Id: "+trackingID);

		String filedId=request.getParameter("fileId");
		reportslogger.info("File Id: "+filedId);

		String fileName = request.getParameter("fileName");
		reportslogger.info("File Name: "+fileName);

		String vendorId=request.getParameter("vendorId");
		reportslogger.info("Vendor Id: "+vendorId);

		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date: "+fromDate);

		String toDate = request.getParameter("endDate");
		reportslogger.info("To date: "+toDate);
		if(trackingID==null || trackingID.equals(""))
		{
			PayTransferTransLevelBeanObjSearch.setSourceTrackingId(null);
		}
		else{
			PayTransferTransLevelBeanObjSearch.setSourceTrackingId(trackingID.trim());
		}

		if(childUserId==null || childUserId.equals(""))
		{
			PayTransferTransLevelBeanObjSearch.setChildUserId(null);
		}
		else{
			PayTransferTransLevelBeanObjSearch.setChildUserId(childUserId.trim());
		}

		if(filedId==null || filedId.equals(""))
		{
			PayTransferTransLevelBeanObjSearch.setFileId(null);
		}
		else{
			PayTransferTransLevelBeanObjSearch.setFileId(filedId.trim());
		}

		if(fileName==null || fileName.equals(""))
		{
			PayTransferTransLevelBeanObjSearch.setFileName(null);
		}
		else
		{
			PayTransferTransLevelBeanObjSearch.setFileName(fileName.trim());
		}

		if(vendorId==null || vendorId.equals(""))
		{
			PayTransferTransLevelBeanObjSearch.setVendorId(null);
		}
		else{

			PayTransferTransLevelBeanObjSearch.setVendorId(vendorId.trim());
		}

		if (fromDate != "") {

			PayTransferTransLevelBeanObjSearch.setFromDate(fromDate);
		} else
			PayTransferTransLevelBeanObjSearch.setFromDate(null);

		if (toDate != "") {
			PayTransferTransLevelBeanObjSearch.setToDate(toDate);
		} else {
			PayTransferTransLevelBeanObjSearch.setToDate(null);
		}



		HashMap<Integer, List<PaymentTransferTransLevelBean>> payTransferTransLevelMap = new HashMap<Integer, List<PaymentTransferTransLevelBean>>();
		int page = 1;
		String statusMsg = null;


		payTransferTransLevelMap= ReportsDaoObj.getPaymentTransferTransLevelDetails(PayTransferTransLevelBeanObjSearch, page);
		if(payTransferTransLevelMap==null){
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role",Role);
			modelAndViewObj.setViewName("PaymentTransferTransSearch");
			return modelAndViewObj;
		}


		reportslogger.info("Details map size Based on Search Criteria in Controller: "+payTransferTransLevelMap.size());

		//reportslogger.info("in controller"+PayTransferTransLevelBeanObj.getStatusMsg());
		if(PayTransferTransLevelBeanObjSearch.getStatusMsg()!=null)
		{

			if(PayTransferTransLevelBeanObjSearch.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				statusMsg="";
			}

			else
			{
				statusMsg=PayTransferTransLevelBeanObjSearch.getStatusMsg();
			}

		}
		else
			statusMsg="Connectivity Issues..Retry..";


		modelAndViewObj.addObject("role",Role);
		modelAndViewObj.addObject("statusMsg", statusMsg);
		modelAndViewObj.addObject("PayTransferTransLevelBeanObjJsp", PayTransferTransLevelBeanObjSearch);
		modelAndViewObj.addObject("payTransferTransLevelDetailsMap", payTransferTransLevelMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.setViewName("PaymentTransferTransSearch");
		return modelAndViewObj;
	}



	@RequestMapping(value = "/paymentTransferTransLevelPagination")
	public ModelAndView getpaymentTransferTransPagination(HttpServletRequest request,HttpServletResponse response) 
	{
		session=request.getSession(false);
		PaymentTransferTransLevelBean PayTransferTransLevelBeanObjPag=new PaymentTransferTransLevelBean();
		reportslogger.info("In Payment Transfer Transaction Level Pagination");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		PayTransferTransLevelBeanObjPag.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in paymentTransferTransLevelPagination mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);
		String childUserId=request.getParameter("childUserId");
		reportslogger.info("User ID: "+childUserId);
		String trackingID=request.getParameter("trackingId");


		reportslogger.info("Tracking Id: "+trackingID);

		String filedId=request.getParameter("fileId");
		reportslogger.info("File Id: "+filedId);

		String fileName = request.getParameter("fileName");
		reportslogger.info("File Name: "+fileName);

		String vendorId=request.getParameter("vendorId");
		reportslogger.info("Vendor Id: "+vendorId);

		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date: "+fromDate);

		String toDate = request.getParameter("endDate");
		reportslogger.info("To date: "+toDate);
		if(trackingID==null || trackingID.equals(""))
		{
			PayTransferTransLevelBeanObjPag.setSourceTrackingId(null);
		}
		else{
			PayTransferTransLevelBeanObjPag.setSourceTrackingId(trackingID.trim());
		}

		if(childUserId==null || childUserId.equals(""))
		{
			PayTransferTransLevelBeanObjPag.setChildUserId(null);
		}
		else{
			PayTransferTransLevelBeanObjPag.setChildUserId(childUserId.trim());
		}

		if(filedId==null || filedId.equals(""))
		{
			PayTransferTransLevelBeanObjPag.setFileId(null);
		}
		else{
			PayTransferTransLevelBeanObjPag.setFileId(filedId.trim());
		}

		if(fileName==null || fileName.equals(""))
		{
			PayTransferTransLevelBeanObjPag.setFileName(null);
		}
		else
		{
			PayTransferTransLevelBeanObjPag.setFileName(fileName.trim());
		}

		if(vendorId==null || vendorId.equals(""))
		{
			PayTransferTransLevelBeanObjPag.setVendorId(null);
		}
		else{

			PayTransferTransLevelBeanObjPag.setVendorId(vendorId.trim());
		}

		if (fromDate != "") {

			PayTransferTransLevelBeanObjPag.setFromDate(fromDate);
		} else
			PayTransferTransLevelBeanObjPag.setFromDate(null);

		if (toDate != "") {
			PayTransferTransLevelBeanObjPag.setToDate(toDate);
		} else {
			PayTransferTransLevelBeanObjPag.setToDate(null);
		}



		HashMap<Integer, List<PaymentTransferTransLevelBean>> payTransferTransLevelMap = new HashMap<Integer, List<PaymentTransferTransLevelBean>>();
		int page =Integer.parseInt(request.getParameter("pageNum"));
		reportslogger.info("Page No:"+page);
		String statusMsg = null;
		ModelAndView modelAndViewObj = new ModelAndView();

		payTransferTransLevelMap= ReportsDaoObj.getPaymentTransferTransLevelDetails(PayTransferTransLevelBeanObjPag, page);
		if(payTransferTransLevelMap==null){
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role",Role);
			modelAndViewObj.setViewName("PaymentTransferTransSearch");
			return modelAndViewObj;
		}


		reportslogger.info("Details map Size based on Page No In Controller: "+payTransferTransLevelMap.size());

		//reportslogger.info("in controller"+PayTransferTransLevelBeanObj.getStatusMsg());

		if(PayTransferTransLevelBeanObjPag.getStatusMsg()!=null)
		{

			if(PayTransferTransLevelBeanObjPag.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				statusMsg="";
			}

			else
			{
				statusMsg=PayTransferTransLevelBeanObjPag.getStatusMsg();
			}

		}
		else
			statusMsg="Connectivity Issues..Retry..";


		modelAndViewObj.addObject("role",Role);
		modelAndViewObj.addObject("statusMsg", statusMsg);
		modelAndViewObj.addObject("PayTransferTransLevelBeanObjJsp", PayTransferTransLevelBeanObjPag);
		modelAndViewObj.addObject("payTransferTransLevelDetailsMap", payTransferTransLevelMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.setViewName("PaymentTransferTransSearch");
		return modelAndViewObj;
	}
	@RequestMapping(value = "/PaymentTransferTransLevelExcelFileDownload")
	public ModelAndView paymentTransferTransExcelFileDownload(HttpServletRequest request,HttpServletResponse response) throws IOException 
	{
		session=request.getSession(false);
		PaymentTransferTransLevelBean PayTransferTransLevelBeanObjExcel=new PaymentTransferTransLevelBean();
		reportslogger.info("In Payment Transfer Transaction Level Excel File Download");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		PayTransferTransLevelBeanObjExcel.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in PaymentTransferTransLevelExcelFileDownload mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);
		String childUserId=request.getParameter("childUserId");
		reportslogger.info("User ID: "+childUserId);
		String trackingID=request.getParameter("trackingId");


		reportslogger.info("Tracking Id: "+trackingID);

		String filedId=request.getParameter("fileId");
		reportslogger.info("File Id: "+filedId);

		String fileName = request.getParameter("fileName");
		reportslogger.info("File Name: "+fileName);

		String vendorId=request.getParameter("vendorId");
		reportslogger.info("Vendor Id: "+vendorId);

		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date: "+fromDate);

		String toDate = request.getParameter("endDate");
		reportslogger.info("To date: "+toDate);
		if(trackingID==null || trackingID.equals(""))
		{
			PayTransferTransLevelBeanObjExcel.setSourceTrackingId(null);
		}
		else{
			PayTransferTransLevelBeanObjExcel.setSourceTrackingId(trackingID.trim());
		}

		if(childUserId==null || childUserId.equals(""))
		{
			PayTransferTransLevelBeanObjExcel.setChildUserId(null);
		}
		else{
			PayTransferTransLevelBeanObjExcel.setChildUserId(childUserId.trim());
		}

		if(filedId==null || filedId.equals(""))
		{
			PayTransferTransLevelBeanObjExcel.setFileId(null);
		}
		else{
			PayTransferTransLevelBeanObjExcel.setFileId(filedId.trim());
		}

		if(fileName==null || fileName.equals(""))
		{
			PayTransferTransLevelBeanObjExcel.setFileName(null);
		}
		else
		{
			PayTransferTransLevelBeanObjExcel.setFileName(fileName.trim());
		}

		if(vendorId==null || vendorId.equals(""))
		{
			PayTransferTransLevelBeanObjExcel.setVendorId(null);
		}
		else{

			PayTransferTransLevelBeanObjExcel.setVendorId(vendorId.trim());
		}

		if (fromDate != "") {

			PayTransferTransLevelBeanObjExcel.setFromDate(fromDate);
		} else
			PayTransferTransLevelBeanObjExcel.setFromDate(null);

		if (toDate != "") {
			PayTransferTransLevelBeanObjExcel.setToDate(toDate);
		} else {
			PayTransferTransLevelBeanObjExcel.setToDate(null);
		}




		List<PaymentTransferTransLevelBean> PayTransferTransExcellDetailsList = new ArrayList<PaymentTransferTransLevelBean>();
		String pageNo = null;
		ModelAndView modelAndViewObj = new ModelAndView();
		int rowNumber=1;

		PayTransferTransExcellDetailsList= ReportsDaoObj.getPaymentTransferTransExcelDetails(PayTransferTransLevelBeanObjExcel, pageNo);
		if(PayTransferTransExcellDetailsList==null){
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role",Role);
			modelAndViewObj.setViewName("PaymentTransferTransSearch");
			return modelAndViewObj;
		}

		reportslogger.info("Excel Details size in Controller"+PayTransferTransExcellDetailsList.size());
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("Payment_Transfer_Trans_Level");
		XSSFCell cell = null;
		XSSFRow row;
		XSSFCellStyle my_style = wb.createCellStyle();
		XSSFFont my_font=wb.createFont();
		my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		my_style.setFont(my_font);
		XSSFCellStyle rightAligned = wb.createCellStyle();
		rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);



		row = sheet.createRow(0);
		cell = row.createCell(0);
		cell.setCellValue("Cheque/Trans ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(1);
		cell.setCellValue("Source Tracking ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(2);
		cell.setCellValue("Source Tracking ID Serv");
		cell.setCellStyle(my_style);
		cell = row.createCell(3);
		cell.setCellValue("Destination Tracking ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(4);
		cell.setCellValue("Destination Tracking ID Serv");
		cell.setCellStyle(my_style);
		cell = row.createCell(5);
		cell.setCellValue("Type ");
		cell.setCellStyle(my_style);
		cell = row.createCell(6);
		cell.setCellValue("Payment Mode");
		cell.setCellStyle(my_style);
		cell = row.createCell(7);
		cell.setCellValue("LOB");
		cell.setCellStyle(my_style);
		cell = row.createCell(8);
		cell.setCellValue("Account No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(9);
		cell.setCellValue("Invoice No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(10);
		cell.setCellValue("Amount");
		cell.setCellStyle(my_style);
		cell = row.createCell(11);
		cell.setCellValue("Uploaded By(OLM ID) ");
		cell.setCellStyle(my_style);
		cell = row.createCell(12);
		cell.setCellValue("Uploaded By(Name)");
		cell.setCellStyle(my_style);
		cell = row.createCell(13);
		cell.setCellValue("Uploaded Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(14);
		cell.setCellValue("File Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(15);
		cell.setCellValue("File ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(16);
		cell.setCellValue("Status");
		cell.setCellStyle(my_style);
		cell = row.createCell(17);
		cell.setCellValue("FX Update Time");
		cell.setCellStyle(my_style);
		cell = row.createCell(18);
		cell.setCellValue("Reason For Failure");
		cell.setCellStyle(my_style);


		for (int i = 0; i <PayTransferTransExcellDetailsList.size(); i++) 
		{

			PaymentTransferTransLevelBean PayTransferTransLevelBeanObj = PayTransferTransExcellDetailsList.get(i);
			//reportslogger.info("in controller uplodeddate"+PayPostingFilelevelDetailsObj.getUplodedDateTime());
			row = sheet.createRow(rowNumber);
			cell = row.createCell(0);
			cell.setCellValue(PayTransferTransLevelBeanObj.getTransId());
			//sheet.autoSizeColumn(0);
			cell = row.createCell(1);
			cell.setCellValue(PayTransferTransLevelBeanObj.getSourceTrackingId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(1);
			cell = row.createCell(2);
			cell.setCellValue(PayTransferTransLevelBeanObj.getSourceTrackingIdServ());
			cell.setCellStyle(rightAligned);
			cell = row.createCell(3);
			cell.setCellValue(PayTransferTransLevelBeanObj.getDesTrackingId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(1);
			cell = row.createCell(4);
			cell.setCellValue(PayTransferTransLevelBeanObj.getDesTrackingIdServ());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(2);
			cell = row.createCell(5);
			cell.setCellValue(PayTransferTransLevelBeanObj.getType());
			//sheet.autoSizeColumn(3);
			cell = row.createCell(6);
			cell.setCellValue(PayTransferTransLevelBeanObj.getPaymentMode());
			//sheet.autoSizeColumn(4);
			cell = row.createCell(7);
			cell.setCellValue(PayTransferTransLevelBeanObj.getLob());
			//sheet.autoSizeColumn(5);

			cell = row.createCell(8);
			cell.setCellValue(PayTransferTransLevelBeanObj.getAccountNo());
			//sheet.autoSizeColumn(6);
			cell = row.createCell(9);
			cell.setCellValue(PayTransferTransLevelBeanObj.getInvoiceNo());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(7);
			cell = row.createCell(10);
			cell.setCellValue(PayTransferTransLevelBeanObj.getAmount());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(8);

			cell = row.createCell(11);
			cell.setCellValue(PayTransferTransLevelBeanObj.getUploadedByOlmId());
			//sheet.autoSizeColumn(9);
			cell = row.createCell(12);
			cell.setCellValue(PayTransferTransLevelBeanObj.getUploadedByName());
			//sheet.autoSizeColumn(10);
			cell = row.createCell(13);
			CellStyle cellStyle = wb.createCellStyle();
			CreationHelper createHelper = wb.getCreationHelper();

			cellStyle.setDataFormat(
					createHelper.createDataFormat().getFormat("dd/mm/yyyy"));
			if(PayTransferTransLevelBeanObj.getUploadTime()!=null)
			{
				cell.setCellValue(PayTransferTransLevelBeanObj.getUploadTime());
				cell.setCellStyle(cellStyle);
			}
			else
				cell.setCellValue("");	

			//sheet.autoSizeColumn(11);
			cell = row.createCell(14);
			cell.setCellValue(PayTransferTransLevelBeanObj.getFileName());
			//sheet.autoSizeColumn(12);
			cell = row.createCell(15);
			cell.setCellValue(PayTransferTransLevelBeanObj.getFileId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(13);
			cell = row.createCell(16);
			cell.setCellValue(PayTransferTransLevelBeanObj.getStatus());
			//sheet.autoSizeColumn(14);
			cell = row.createCell(17);
			if(PayTransferTransLevelBeanObj.getFxUpdatedDate()==null||PayTransferTransLevelBeanObj.getFxUpdatedDate().equalsIgnoreCase("NA"))
				cell.setCellValue("");
			else
				cell.setCellValue(PayTransferTransLevelBeanObj.getFxUpdatedDate());
			//sheet.autoSizeColumn(15);
			cell = row.createCell(18);
			if(PayTransferTransLevelBeanObj.getReasonForFailure()==null||PayTransferTransLevelBeanObj.getReasonForFailure().equalsIgnoreCase("NA"))
				cell.setCellValue("");
			else
				cell.setCellValue(PayTransferTransLevelBeanObj.getReasonForFailure());
			//sheet.autoSizeColumn(16);


			rowNumber=rowNumber+1;

		}
		for(int i=0;i<=18;i++){
			sheet.autoSizeColumn(i);
		}
		// write it as an excel attachment
		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);


		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		byte [] outArray = outByteStream.toByteArray();
		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(new Date()); 
		String fileName1="APS_Payment_Transfer_Transaction_Level_"+date+" .xlsx";

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName1);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
			//***********************************//
			outStream.close();
			outByteStream.close();
			//**********************************//
		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}



		reportslogger.info("End of Payment Transfer Transaction level Excel records download ");
		//modelAndViewObj.setViewName("viewTracking");
		return modelAndViewObj;
	}


	/************************************PAYMENT TRANSFER FILE LEVEL**********************************************/




	/*@RequestMapping(value = "/payTransferFileLevelSummary")
		public ModelAndView pymntTransferFileLevelSummary() {
			reportslogger.info("in controller(pymntTransferFileLevelSummary)");
			ModelAndView modelAndViewObj = new ModelAndView();
			modelAndViewObj.setViewName("payTransferFileLevelLogin");
			return modelAndViewObj;
		}*/

	@RequestMapping(value = "/getRolePaymentTransferFileLevel", method = RequestMethod.GET)
	public ModelAndView getRolePaymentTransferFileLevel(HttpServletRequest request,HttpServletResponse response) 
	{
		// session=request.getSession(false);

		session=request.getSession(false);
		PayTransferFileLevelDetails pymntTransFileLevelDetailsObj=new PayTransferFileLevelDetails();
		reportslogger.info("In Payment Transfer File level Controller");
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in getRolePaymentTransferFileLevel mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		ModelAndView modelAndViewObj = new ModelAndView();

		//String parentUserId = request.getParameter("UserId");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User Id: " + parentUserId);
		/* Role = ReportsDaoObj.getRole(parentUserId);
			 if(Role==-1)
				{
					modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
					modelAndViewObj.setViewName("payTransferFileLevelSearch");
					return modelAndViewObj;
				}*/

		reportslogger.info("User Role:" + Role);

		if ((Role == 2) || (Role == 1) || (Role == 7)) {

			pymntTransFileLevelDetailsObj.setParentUserId(parentUserId);
			pymntTransFileLevelDetailsObj.setChildUserId(null);
			pymntTransFileLevelDetailsObj.setFileORreqId(null);
			pymntTransFileLevelDetailsObj.setFileName(null);
			pymntTransFileLevelDetailsObj.setMode(null);
			pymntTransFileLevelDetailsObj.setVendorId(null);
			pymntTransFileLevelDetailsObj.setToDate(null);
			pymntTransFileLevelDetailsObj.setFromDate(null);

			// call method from dao and get records based on parentuserId only.
			int page = 1;
			String errMsg = null;


			HashMap<Integer, List<PayTransferFileLevelDetails>> ReportsMap = new HashMap<Integer, List<PayTransferFileLevelDetails>>();

			// set statusmsg in daoimpl
			/*reportslogger.info("error msg:"
						+ pymntTransFileLevelDetailsObj.getStatusMsg());
			 */

			ReportsMap = ReportsDaoObj.getPymntTransFileSummaryMap(
					pymntTransFileLevelDetailsObj, page);
			if(ReportsMap==null){
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("role",Role);
				modelAndViewObj.setViewName("payTransferFileLevelSearch");
				return modelAndViewObj;
			}
			reportslogger.info("Details map Size in Controller"+ReportsMap.size());


			if(pymntTransFileLevelDetailsObj.getStatusMsg()!=null)
			{

				if(pymntTransFileLevelDetailsObj.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
				{
					errMsg="";
				}

				else
				{
					errMsg=pymntTransFileLevelDetailsObj.getStatusMsg();
				}

			}
			else
				errMsg="Connectivity Issues..Retry..";


			modelAndViewObj.addObject("ReportsMap", ReportsMap);
			modelAndViewObj.addObject("errMsg", errMsg);
			modelAndViewObj.addObject("role",Role);
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.setViewName("payTransferFileLevelSearch");
		}

		else {
			modelAndViewObj.addObject("error",
					"You do not have privilige to check the reports !!");
			modelAndViewObj.setViewName("payTransferFileLevelSearch");
			return modelAndViewObj;
		}

		return modelAndViewObj;
	}

	@RequestMapping(value = "/getPayTransferFilesOnFilter")
	public ModelAndView getpymntTransferFilesOnFilter(HttpServletRequest request, HttpServletResponse response)
	{
		session=request.getSession(false);
		PayTransferFileLevelDetails pymntTransFileLevelDetailsObjSearch=new PayTransferFileLevelDetails();

		reportslogger.info("In Payment Transfer File Level search");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		pymntTransFileLevelDetailsObjSearch.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in getPayTransferFilesOnFilter mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		ModelAndView modelAndViewObj = new ModelAndView();
		/* if(Role==-1)
				{
					modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
					modelAndViewObj.setViewName("payTransferFileLevelSearch");
					return modelAndViewObj;
				}*/

		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date:" + fromDate);
		String toDate = request.getParameter("endDate");
		reportslogger.info("To Date:" + toDate);

		String userOLMId = request.getParameter("userId");

		reportslogger.info("User ID: "+userOLMId);
		String fileId = request.getParameter("fileId");
		reportslogger.info("File ID: "+fileId);
		String fileName = request.getParameter("fileName");
		reportslogger.info("File Name: "+fileName);
		String vendorId = request.getParameter("vendorId");
		reportslogger.info("Vendor ID: "+vendorId);

		if (fromDate != "") {
			pymntTransFileLevelDetailsObjSearch.setFromDate(fromDate);
		} else

			pymntTransFileLevelDetailsObjSearch.setFromDate(null);

		if (toDate != "") {
			pymntTransFileLevelDetailsObjSearch.setToDate(toDate);
		} else

			pymntTransFileLevelDetailsObjSearch.setToDate(null);


		if (vendorId == null || vendorId.equals("")) {
			pymntTransFileLevelDetailsObjSearch.setVendorId(null);
		} else
			pymntTransFileLevelDetailsObjSearch.setVendorId(vendorId.trim());

		if (fileId == null || fileId.equals("")) {
			pymntTransFileLevelDetailsObjSearch.setFileORreqId(null);

		} else
			pymntTransFileLevelDetailsObjSearch.setFileORreqId(fileId.trim());

		if (fileName == null || fileName.equals("")) {
			pymntTransFileLevelDetailsObjSearch.setFileName(null);
		} else
			pymntTransFileLevelDetailsObjSearch.setFileName(fileName.trim());
		if (userOLMId == null || userOLMId.equals("")) {
			pymntTransFileLevelDetailsObjSearch.setChildUserId(null);
		} else
			pymntTransFileLevelDetailsObjSearch.setChildUserId(userOLMId.trim());

		/*	reportslogger.info("todate:"
					+ pymntTransFileLevelDetailsObj.getToDate());
			reportslogger.info("from date:"
					+ pymntTransFileLevelDetailsObj.getFromDate());
			reportslogger.info("user id:"
					+ pymntTransFileLevelDetailsObj.getChildUserId());
			reportslogger.info("vendor id:"
					+ pymntTransFileLevelDetailsObj.getVendorId());


			reportslogger.info("file id:"
					+ pymntTransFileLevelDetailsObj.getFileORreqId());
			reportslogger.info("file name:"
					+ pymntTransFileLevelDetailsObj.getFileName());*/

		HashMap<Integer, List<PayTransferFileLevelDetails>> ReportsMap = new HashMap<Integer, List<PayTransferFileLevelDetails>>();
		int page = 1;
		String errMsg = null;


		ReportsMap = ReportsDaoObj.getPymntTransFileSummaryMap(
				pymntTransFileLevelDetailsObjSearch, page);
		if(ReportsMap==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role",Role);
			modelAndViewObj.setViewName("payTransferFileLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Details Map size based on seach Criteria in Controller: "+ReportsMap.size());


		//	reportslogger.info("method called in controller");

		/*	reportslogger.info("status msg in controller:"
					+ pymntTransFileLevelDetailsObj.getStatusMsg());*/
		if(pymntTransFileLevelDetailsObjSearch.getStatusMsg()!=null)
		{

			if(pymntTransFileLevelDetailsObjSearch.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				errMsg="";
			}

			else
			{
				errMsg=pymntTransFileLevelDetailsObjSearch.getStatusMsg();
			}

		}
		else
			errMsg="Connectivity Issues..Retry..";


		modelAndViewObj.addObject("errMsg", errMsg);
		modelAndViewObj.addObject("ReportsMap", ReportsMap);
		modelAndViewObj.addObject("role",Role);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("pymntTransFileLevelDetailsObjJsp", pymntTransFileLevelDetailsObjSearch);
		modelAndViewObj.setViewName("payTransferFileLevelSearch");
		//reportslogger.info("end of search controller");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/getPayTransferFilesWithPagtn")
	public ModelAndView getpymntTransferFilesWithPagtn(HttpServletRequest request, HttpServletResponse response) 
	{
		session=request.getSession(false);
		PayTransferFileLevelDetails pymntTransFileLevelDetailsObjPag=new PayTransferFileLevelDetails();
		reportslogger.info("In Payment Transfer File Level Pagination");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		pymntTransFileLevelDetailsObjPag.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in getPayTransferFilesWithPagtn mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);
		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date:" + fromDate);
		String toDate = request.getParameter("endDate");
		reportslogger.info("To Date:" + toDate);

		String userOLMId = request.getParameter("userId");

		reportslogger.info("User ID: "+userOLMId);
		String fileId = request.getParameter("fileId");
		reportslogger.info("File ID: "+fileId);
		String fileName = request.getParameter("fileName");
		reportslogger.info("File Name: "+fileName);
		String vendorId = request.getParameter("vendorId");
		reportslogger.info("Vendor ID: "+vendorId);

		if (fromDate != "") {
			pymntTransFileLevelDetailsObjPag.setFromDate(fromDate);
		} else

			pymntTransFileLevelDetailsObjPag.setFromDate(null);

		if (toDate != "") {
			pymntTransFileLevelDetailsObjPag.setToDate(toDate);
		} else

			pymntTransFileLevelDetailsObjPag.setToDate(null);


		if (vendorId == null || vendorId.equals("")) {
			pymntTransFileLevelDetailsObjPag.setVendorId(null);
		} else
			pymntTransFileLevelDetailsObjPag.setVendorId(vendorId.trim());

		if (fileId == null || fileId.equals("")) {
			pymntTransFileLevelDetailsObjPag.setFileORreqId(null);

		} else
			pymntTransFileLevelDetailsObjPag.setFileORreqId(fileId.trim());

		if (fileName == null || fileName.equals("")) {
			pymntTransFileLevelDetailsObjPag.setFileName(null);
		} else
			pymntTransFileLevelDetailsObjPag.setFileName(fileName.trim());
		if (userOLMId == null || userOLMId.equals("")) {
			pymntTransFileLevelDetailsObjPag.setChildUserId(null);
		} else
			pymntTransFileLevelDetailsObjPag.setChildUserId(userOLMId.trim());


		HashMap<Integer, List<PayTransferFileLevelDetails>> ReportsMap = new HashMap<Integer, List<PayTransferFileLevelDetails>>();
		int page = Integer.parseInt(request.getParameter("pageNum"));
		reportslogger.info("Page No: "+page);
		String errMsg = null;
		ModelAndView modelAndViewObj = new ModelAndView();

		ReportsMap = ReportsDaoObj.getPymntTransFileSummaryMap(
				pymntTransFileLevelDetailsObjPag, page);
		if(ReportsMap==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role",Role);
			modelAndViewObj.setViewName("payTransferFileLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Details map size  based on Page No.in Controller : "+ReportsMap.size());


		//reportslogger.info("method called in pagination controller");

		/*reportslogger.info("status msg in controller:"
					+ pymntTransFileLevelDetailsObj.getStatusMsg());
		 */
		if(pymntTransFileLevelDetailsObjPag.getStatusMsg()!=null)
		{

			if(pymntTransFileLevelDetailsObjPag.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				errMsg="";
			}

			else
			{
				errMsg=pymntTransFileLevelDetailsObjPag.getStatusMsg();
			}

		}
		else
			errMsg="Connectivity Issues..Retry..";



		modelAndViewObj.addObject("errMsg", errMsg);
		modelAndViewObj.addObject("ReportsMap", ReportsMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("role",Role);
		modelAndViewObj.addObject("pymntTransFileLevelDetailsObjJsp", pymntTransFileLevelDetailsObjPag);
		modelAndViewObj.setViewName("payTransferFileLevelSearch");

		return modelAndViewObj;
	}



	@RequestMapping(value = "/downloadFailureRecordsTransfer1")
	public ModelAndView downloadFailureRecordsTransfer(HttpServletRequest request,HttpServletResponse response) throws IOException
	{

		reportslogger.info("In Payment Transfer File Level Failure Records download");
		session=request.getSession(false);
		PayTransferFileLevelDetails pymntTransFileLevelDetailsObjTransExcel=new PayTransferFileLevelDetails();
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		pymntTransFileLevelDetailsObjTransExcel.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in downloadFailureRecordsTransfer1 mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		List<PaymentTransferTransLevelBean> PaymentTranferErrorRecordsList = new ArrayList<PaymentTransferTransLevelBean>();
		ModelAndView modelAndViewObj = new ModelAndView();

		String FileId = request.getParameter("FileId");
		reportslogger.info("file Id In payment Transfer File Level Failure Records Dwonlaod: "+ FileId );
		int rowNumber = 1;

		//reportslogger.info("file ID from hidden var:" + FileId);

		PaymentTranferErrorRecordsList = ReportsDaoObj
				.getPymntTransferErrorRecords(FileId);
		if(PaymentTranferErrorRecordsList==null){
			modelAndViewObj.addObject("role",Role);
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.setViewName("payTransferFileLevelSearch");
			return modelAndViewObj;
		}

		reportslogger.info("failure record list size "+PaymentTranferErrorRecordsList.size());


		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("Payment_Transfer_Failure_Records");
		XSSFCell cell = null;
		XSSFRow row;
		XSSFCellStyle my_style = wb.createCellStyle();
		XSSFFont my_font=wb.createFont();
		my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		my_style.setFont(my_font);

		XSSFCellStyle rightAligned = wb.createCellStyle();
		rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);


		row = sheet.createRow(0);
		cell = row.createCell(0);
		cell.setCellValue("Cheque/Trans ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(1);
		cell.setCellValue("Source Tracking ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(2);
		cell.setCellValue("Source Tracking ID Serv");
		cell.setCellStyle(my_style);
		cell = row.createCell(3);
		cell.setCellValue("Type ");
		cell.setCellStyle(my_style);
		cell = row.createCell(4);
		cell.setCellValue("Payment Mode");
		cell.setCellStyle(my_style);
		cell = row.createCell(5);
		cell.setCellValue("LOB");
		cell.setCellStyle(my_style);
		cell = row.createCell(6);
		cell.setCellValue("Account No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(7);
		cell.setCellValue("Invoice No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(8);
		cell.setCellValue("Amount");
		cell.setCellStyle(my_style);
		cell = row.createCell(9);
		cell.setCellValue("Uploaded By(OLM ID) ");
		cell.setCellStyle(my_style);
		cell = row.createCell(10);
		cell.setCellValue("Uploaded By(Name)");
		cell.setCellStyle(my_style);
		cell = row.createCell(11);
		cell.setCellValue("Uploaded Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(12);
		cell.setCellValue("File Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(13);
		cell.setCellValue("File ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(14);
		cell.setCellValue("Status");
		cell.setCellStyle(my_style);
		/*cell = row.createCell(15);
		    	cell.setCellValue("FX update time");*/
		cell = row.createCell(15);
		cell.setCellValue("Reason For Failure");
		cell.setCellStyle(my_style);


		for (int i = 0; i <PaymentTranferErrorRecordsList.size(); i++) 
		{

			PaymentTransferTransLevelBean PayTransferTransLevelBeanObj = PaymentTranferErrorRecordsList.get(i);
			//reportslogger.info("in controller uplodeddate"+PayPostingFilelevelDetailsObj.getUplodedDateTime());
			row = sheet.createRow(rowNumber);
			cell = row.createCell(0);
			cell.setCellValue(PayTransferTransLevelBeanObj.getTransId());
			//sheet.autoSizeColumn(0);
			cell = row.createCell(1);
			cell.setCellValue(PayTransferTransLevelBeanObj.getSourceTrackingId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(1);
			cell = row.createCell(2);
			cell.setCellValue(PayTransferTransLevelBeanObj.getSourceTrackingIdServ());
			//sheet.autoSizeColumn(2);
			cell.setCellStyle(rightAligned);
			cell = row.createCell(3);
			cell.setCellValue(PayTransferTransLevelBeanObj.getType());
			//sheet.autoSizeColumn(3);
			cell = row.createCell(4);
			cell.setCellValue(PayTransferTransLevelBeanObj.getPaymentMode());
			//sheet.autoSizeColumn(4);
			cell = row.createCell(5);
			cell.setCellValue(PayTransferTransLevelBeanObj.getLob());
			//sheet.autoSizeColumn(5);

			cell = row.createCell(6);
			cell.setCellValue(PayTransferTransLevelBeanObj.getAccountNo());
			//sheet.autoSizeColumn(6);
			cell = row.createCell(7);
			cell.setCellValue(PayTransferTransLevelBeanObj.getInvoiceNo());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(7);
			cell = row.createCell(8);
			cell.setCellValue(PayTransferTransLevelBeanObj.getAmount());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(8);

			cell = row.createCell(9);
			cell.setCellValue(PayTransferTransLevelBeanObj.getUploadedByOlmId());
			//sheet.autoSizeColumn(9);
			cell = row.createCell(10);
			cell.setCellValue(PayTransferTransLevelBeanObj.getUploadedByName());
			//sheet.autoSizeColumn(10);
			cell = row.createCell(11);
			CellStyle cellStyle = wb.createCellStyle();
			CreationHelper createHelper = wb.getCreationHelper();

			cellStyle.setDataFormat(
					createHelper.createDataFormat().getFormat("dd/mm/yyyy"));
			if(PayTransferTransLevelBeanObj.getUploadTime()!=null)
			{
				cell.setCellValue(PayTransferTransLevelBeanObj.getUploadTime());
				cell.setCellStyle(cellStyle);
			}
			else
				cell.setCellValue("");	

			//sheet.autoSizeColumn(11);
			cell = row.createCell(12);
			cell.setCellValue(PayTransferTransLevelBeanObj.getFileName());
			//sheet.autoSizeColumn(12);
			cell = row.createCell(13);
			cell.setCellValue(PayTransferTransLevelBeanObj.getFileId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(13);
			cell = row.createCell(14);
			cell.setCellValue(PayTransferTransLevelBeanObj.getStatus());
			//sheet.autoSizeColumn(14);
			cell = row.createCell(15);
			/*if(PayTransferTransLevelBeanObj.getFxUpdatedDate()==null||PayTransferTransLevelBeanObj.getFxUpdatedDate().equalsIgnoreCase("NA"))
					cell.setCellValue("");
				else
				cell.setCellValue(PayTransferTransLevelBeanObj.getFxUpdatedDate());
				//sheet.autoSizeColumn(15);*/
			cell = row.createCell(15);
			if(PayTransferTransLevelBeanObj.getReasonForFailure()==null||PayTransferTransLevelBeanObj.getReasonForFailure().equalsIgnoreCase("NA"))
				cell.setCellValue("");
			else
				cell.setCellValue(PayTransferTransLevelBeanObj.getReasonForFailure());
			//sheet.autoSizeColumn(15);

			rowNumber=rowNumber+1;

		}
		for(int i=0;i<=15;i++){
			sheet.autoSizeColumn(i);					
		}

		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		byte[] outArray = outByteStream.toByteArray();
		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
				.format(new Date());


		String fileName ="APS_"+ FileId +"_Payment_Transfer_Failure_Records"+date+".xlsx";

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}

		reportslogger.info("End of payment Transfer failure records download "); 

		return modelAndViewObj;


	}

	@RequestMapping(value = "/getPayTransferFilesExcel")
	public ModelAndView getpymntTransferFilesExcel(HttpServletRequest request, HttpServletResponse response)
	{
		session=request.getSession(false);
		PayTransferFileLevelDetails pymntTransFileLevelDetailsObjExcel=new PayTransferFileLevelDetails();
		reportslogger.info("In Payment Transfer Excel File Download");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		pymntTransFileLevelDetailsObjExcel.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in getPayTransferFilesExcel mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);
		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date:" + fromDate);
		String toDate = request.getParameter("endDate");
		reportslogger.info("To Date:" + toDate);

		String userOLMId = request.getParameter("userId");

		reportslogger.info("User ID: "+userOLMId);
		String fileId = request.getParameter("fileId");
		reportslogger.info("File ID: "+fileId);
		String fileName = request.getParameter("fileName");
		reportslogger.info("File Name: "+fileName);
		String vendorId = request.getParameter("vendorId");
		reportslogger.info("Vendor ID: "+vendorId);

		if (fromDate != "") {
			pymntTransFileLevelDetailsObjExcel.setFromDate(fromDate);
		} else

			pymntTransFileLevelDetailsObjExcel.setFromDate(null);

		if (toDate != "") {
			pymntTransFileLevelDetailsObjExcel.setToDate(toDate);
		} else

			pymntTransFileLevelDetailsObjExcel.setToDate(null);


		if (vendorId == null || vendorId.equals("")) {
			pymntTransFileLevelDetailsObjExcel.setVendorId(null);
		} else
			pymntTransFileLevelDetailsObjExcel.setVendorId(vendorId.trim());

		if (fileId == null || fileId.equals("")) {
			pymntTransFileLevelDetailsObjExcel.setFileORreqId(null);

		} else
			pymntTransFileLevelDetailsObjExcel.setFileORreqId(fileId.trim());

		if (fileName == null || fileName.equals("")) {
			pymntTransFileLevelDetailsObjExcel.setFileName(null);
		} else
			pymntTransFileLevelDetailsObjExcel.setFileName(fileName.trim());
		if (userOLMId == null || userOLMId.equals("")) {
			pymntTransFileLevelDetailsObjExcel.setChildUserId(null);
		} else
			pymntTransFileLevelDetailsObjExcel.setChildUserId(userOLMId.trim());

		ModelAndView modelAndViewObj=new ModelAndView();

		List<PayTransferFileLevelDetails> pymntTransferExcelDetails=new ArrayList<PayTransferFileLevelDetails>();
		String pageNum=null;
		String errMsg = null;

		pymntTransferExcelDetails=ReportsDaoObj.getpymntTransFileLevelDetailsExcelList(pymntTransFileLevelDetailsObjExcel, pageNum);
		if(pymntTransferExcelDetails==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role",Role);
			modelAndViewObj.setViewName("payTransferFileLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Excel List size in Controller: "+pymntTransferExcelDetails.size());
		int rowNumber = 1;
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("Payment_Transfer_File_Level");
		XSSFCell cell = null;
		XSSFRow row;
		XSSFCellStyle my_style = wb.createCellStyle();
		XSSFFont my_font=wb.createFont();
		my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		my_style.setFont(my_font);
		XSSFCellStyle rightAligned = wb.createCellStyle();
		rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);

		row = sheet.createRow(0);
		cell = row.createCell(0);
		cell.setCellValue("File ID");

		cell.setCellStyle(my_style);
		cell = row.createCell(1);
		cell.setCellValue("Uploaded By(OLM ID)");
		cell.setCellStyle(my_style);
		cell = row.createCell(2);
		cell.setCellValue("Uploaded By(Name)");
		cell.setCellStyle(my_style);
		cell = row.createCell(3);
		cell.setCellValue("Uploaded Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(4);
		cell.setCellValue("File Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(5);
		cell.setCellValue("Total Records");
		cell.setCellStyle(my_style);
		cell = row.createCell(6);
		cell.setCellValue("Total Value");
		cell.setCellStyle(my_style);
		cell = row.createCell(7);
		cell.setCellValue("In Progress Records");
		cell.setCellStyle(my_style);
		cell = row.createCell(8);
		cell.setCellValue("In Progress Value");
		cell.setCellStyle(my_style);
		cell = row.createCell(9);
		cell.setCellValue("Status");
		cell.setCellStyle(my_style);
		cell = row.createCell(10);
		cell.setCellValue("Records Pushed To FX");
		cell.setCellStyle(my_style);
		cell = row.createCell(11);
		cell.setCellValue("Value Pushed To FX");
		cell.setCellStyle(my_style);
		cell = row.createCell(12);
		cell.setCellValue("Failed Record Count");
		cell.setCellStyle(my_style);
		cell = row.createCell(13);
		cell.setCellValue("Failed Record Value");
		cell.setCellStyle(my_style);

		for (int i = 0; i < pymntTransferExcelDetails.size(); i++) {
			// reportslogger.info("i value"+i);
			PayTransferFileLevelDetails pymntTransFileLevelDetailsObject = pymntTransferExcelDetails
					.get(i);

			row = sheet.createRow(rowNumber);
			cell = row.createCell(0);
			cell.setCellValue(pymntTransFileLevelDetailsObject.getFileORreqId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(0);

			cell = row.createCell(1);
			cell.setCellValue(pymntTransFileLevelDetailsObject.getUploadedByOLMId());
			//sheet.autoSizeColumn(1);
			cell = row.createCell(2);
			cell.setCellValue(pymntTransFileLevelDetailsObject.getUploadedByName());

			//sheet.autoSizeColumn(2);

			cell = row.createCell(3);
			cell.setCellValue(pymntTransFileLevelDetailsObject.getUploadedTime());
			//sheet.autoSizeColumn(3);

			cell = row.createCell(4);
			cell.setCellValue(pymntTransFileLevelDetailsObject.getFileName());
			//sheet.autoSizeColumn(4);

			cell = row.createCell(5);
			cell.setCellValue(pymntTransFileLevelDetailsObject.getTotRecCount());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(5);
			cell = row.createCell(6);
			cell.setCellValue(pymntTransFileLevelDetailsObject.getTotVal());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(6);
			cell = row.createCell(7);
			cell.setCellValue(pymntTransFileLevelDetailsObject.getInProgressRecords());
			cell.setCellStyle(rightAligned);
			cell = row.createCell(8);
			cell.setCellValue(pymntTransFileLevelDetailsObject.getInProgressvalue());
			cell.setCellStyle(rightAligned);

			cell = row.createCell(9);
			cell.setCellValue(pymntTransFileLevelDetailsObject.getStatus());
			//sheet.autoSizeColumn(7);
			cell = row.createCell(10);
			cell.setCellValue(pymntTransFileLevelDetailsObject.getSuccessCountFx());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(8);

			cell = row.createCell(11);
			cell.setCellValue(pymntTransFileLevelDetailsObject.getSuccessValFx());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(9);
			cell = row.createCell(12);
			cell.setCellValue(pymntTransFileLevelDetailsObject.getFailedRecCountFx());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(10);

			cell = row.createCell(13);
			cell.setCellValue(pymntTransFileLevelDetailsObject.getFailedRecValFx());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(11);
			rowNumber++;

		}
		for(int i=0;i<=13;i++){
			sheet.autoSizeColumn(i);				
		}
		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		byte[] outArray = outByteStream.toByteArray();

		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
				.format(new Date());

		String fileName1 = "APS_Payment_Transfer_File_Level" + "_" + date + ".xlsx";
		reportslogger.info("filename is" + fileName);

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName1);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}

		reportslogger.info("End of Payment Transfer Excel Records download ");

		return modelAndViewObj;

	}

	/************************************PAYMENT TRANSFER FILE LEVEL ends**********************************************/

	/*****************************************Activity Log************************************************************/


	/*@RequestMapping(value = "/viewActivityLog")
		public ModelAndView viewActivityLog() {
			reportslogger.info("in controller(viewActivityLog)");
			ModelAndView modelAndViewObj = new ModelAndView();
			modelAndViewObj.setViewName("ActivityLogLogin");
			return modelAndViewObj;
		}*/

	@RequestMapping(value = "/getRoleinActivityLog",method = RequestMethod.GET)
	public ModelAndView getRoleOfparentUser(HttpServletRequest request,HttpServletResponse response) 
	{

		session=request.getSession(false);
		reportslogger.info("In Activity Log Controller");
		ActivityLogDetails ActivityLogDetailsObj=new ActivityLogDetails();
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in getRoleinActivityLog mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		ModelAndView modelAndViewObj = new ModelAndView();

		//String parentUserId = request.getParameter("UserId");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		// Role = ReportsDaoObj.getRole(parentUserId);
		/* if(Role==-1)
				{
					modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
					modelAndViewObj.setViewName("ActivityLogSearch");
					return modelAndViewObj;
				}
		 */

		reportslogger.info("User Role :" + Role);

		if ((Role == 1) || (Role == 2) || (Role == 3) || (Role == 4)
				|| (Role == 5) || (Role == 6) || (Role == 7)) {

			ActivityLogDetailsObj.setParentUserId(parentUserId);
			ActivityLogDetailsObj.setChildUserId(null);
			ActivityLogDetailsObj.setToDate(null);
			ActivityLogDetailsObj.setFromDate(null);
			/*	ActivityLogDetailsObj.setRole(Role);*/

			// call method from dao and get records based on parentuserId only.
			int page = 1;
			String errMsg = null;

			HashMap<Integer, List<ActivityLogDetails>> ReportsMap = new HashMap<Integer, List<ActivityLogDetails>>();

			ReportsMap = ReportsDaoObj.getActivityLogMap(
					ActivityLogDetailsObj, page);
			if(ReportsMap==null){
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("UserRole", Role);
				modelAndViewObj.setViewName("ActivityLogSearch");
				return modelAndViewObj;
			}
			reportslogger.info("details map size in Controller: "+ReportsMap.size());



			if(ActivityLogDetailsObj.getErrorMsg()!=null)
			{

				if(ActivityLogDetailsObj.getErrorMsg().equalsIgnoreCase("DATA FETCHED"))
				{
					errMsg="";
				}

				else
				{
					errMsg=ActivityLogDetailsObj.getErrorMsg();
				}

			}
			else
				errMsg="Connectivity Issues..Retry..";




			modelAndViewObj.addObject("ReportsMap", ReportsMap);

			modelAndViewObj.addObject("errMsg", errMsg);
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.addObject("UserRole", Role);

			modelAndViewObj.setViewName("ActivityLogSearch");
		}

		else {
			modelAndViewObj.addObject("error",
					"You do not have privilige to check the reports !!");
			modelAndViewObj.setViewName("ActivityLogSearch");
			return modelAndViewObj;
		}

		return modelAndViewObj;
	}

	@RequestMapping(value = "/getActivityLogRecordsWithFilter")
	public ModelAndView getActivityLogRecordsWithFilter(HttpServletRequest request, HttpServletResponse response) 

	{
		session=request.getSession(false);
		reportslogger.info("In Activity Log search Controller");
		String parentUserId=session.getAttribute("userid").toString();
		ActivityLogDetails ActivityLogDetailsObjSearch=new ActivityLogDetails();
		reportslogger.info("Login User ID: " + parentUserId);
		ActivityLogDetailsObjSearch.setParentUserId(parentUserId);
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in getActivityLogRecordsWithFilter mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		ModelAndView modelAndViewObj = new ModelAndView();
		/* if(Role==-1)
				{
					modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
					modelAndViewObj.setViewName("ActivityLogSearch");
					return modelAndViewObj;
				}*/
		/*int Role = ActivityLogDetailsObj.getRole();*/
		//reportslogger.info("Role from filter :" + Role);
		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date: " + fromDate);
		String toDate = request.getParameter("endDate");
		reportslogger.info("To Date: " + toDate);

		String userOLMId = request.getParameter("userId");
		reportslogger.info("user Id: "+userOLMId);
		if (fromDate != "") {
			ActivityLogDetailsObjSearch.setFromDate(fromDate);
		} else

			ActivityLogDetailsObjSearch.setFromDate(null);

		if (toDate != "") {
			ActivityLogDetailsObjSearch.setToDate(toDate);
		} else

			ActivityLogDetailsObjSearch.setToDate(null);

		if (userOLMId == null || userOLMId.equals("")) {
			ActivityLogDetailsObjSearch.setChildUserId(null);

		} else
			ActivityLogDetailsObjSearch.setChildUserId(userOLMId.trim());

		/*reportslogger.info("todate:" + ActivityLogDetailsObj.getToDate());
			reportslogger.info("from date:"
					+ ActivityLogDetailsObj.getFromDate());
			reportslogger.info("user id:"
					+ ActivityLogDetailsObj.getChildUserId());*/

		HashMap<Integer, List<ActivityLogDetails>> ReportsMap = new HashMap<Integer, List<ActivityLogDetails>>();
		int page = 1;
		String errMsg = null;


		ReportsMap = ReportsDaoObj.getActivityLogMap(
				ActivityLogDetailsObjSearch, page);
		if(ReportsMap==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("ActivityLogSearch");
			return modelAndViewObj;
		}


		reportslogger.info("Details map Size based on search  Criteria in Controller: "+ReportsMap.size());
		if(ActivityLogDetailsObjSearch.getErrorMsg()!=null)
		{

			if(ActivityLogDetailsObjSearch.getErrorMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				errMsg="";
			}

			else
			{
				errMsg=ActivityLogDetailsObjSearch.getErrorMsg();
			}

		}
		else
			errMsg="Connectivity Issues..Retry..";
		modelAndViewObj.addObject("errMsg", errMsg);
		modelAndViewObj.addObject("ReportsMap", ReportsMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("UserRole", Role);
		modelAndViewObj.addObject("ActivityLogDetailsObjJsp",ActivityLogDetailsObjSearch);
		modelAndViewObj.setViewName("ActivityLogSearch");

		return modelAndViewObj;
	}

	@RequestMapping(value = "/getActivityLogWithPagination")
	public ModelAndView getActivityLogWithPagination(HttpServletRequest request,HttpServletResponse response)
	{
		session=request.getSession(false);
		reportslogger.info("In Activity log Pagination");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		ActivityLogDetails ActivityLogDetailsObjPag=new ActivityLogDetails();	
		ActivityLogDetailsObjPag.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in getActivityLogWithPagination mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);

		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date: " + fromDate);
		String toDate = request.getParameter("endDate");
		reportslogger.info("To Date: " + toDate);

		String userOLMId = request.getParameter("userId");
		reportslogger.info("user Id: "+userOLMId);
		if (fromDate != "") {
			ActivityLogDetailsObjPag.setFromDate(fromDate);
		} else

			ActivityLogDetailsObjPag.setFromDate(null);

		if (toDate != "") {
			ActivityLogDetailsObjPag.setToDate(toDate);
		} else

			ActivityLogDetailsObjPag.setToDate(null);

		if (userOLMId == null || userOLMId.equals("")) {
			ActivityLogDetailsObjPag.setChildUserId(null);

		} else
			ActivityLogDetailsObjPag.setChildUserId(userOLMId.trim());
		/*int Role = ActivityLogDetailsObj.getRole();*/
		HashMap<Integer, List<ActivityLogDetails>> ReportsMap = new HashMap<Integer, List<ActivityLogDetails>>();
		int page = Integer.parseInt(request.getParameter("pageNum"));
		reportslogger.info("Page No."+page);

		String errMsg = null;
		ModelAndView modelAndViewObj = new ModelAndView();
		ReportsMap = ReportsDaoObj.getActivityLogMap(
				ActivityLogDetailsObjPag, page);
		if(ReportsMap==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("ActivityLogSearch");
			return modelAndViewObj;
		}


		reportslogger.info("Details map Based on Page No. in Controller: "+ReportsMap.size());

		if(ActivityLogDetailsObjPag.getErrorMsg()!=null)
		{

			if(ActivityLogDetailsObjPag.getErrorMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				errMsg="";
			}

			else
			{
				errMsg=ActivityLogDetailsObjPag.getErrorMsg();
			}

		}
		else
			errMsg="Connectivity Issues..Retry..";
		modelAndViewObj.addObject("errMsg", errMsg);
		modelAndViewObj.addObject("ReportsMap", ReportsMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("UserRole", Role);
		modelAndViewObj.addObject("ActivityLogDetailsObjJsp",ActivityLogDetailsObjPag);
		modelAndViewObj.setViewName("ActivityLogSearch");

		return modelAndViewObj;
	}

	@RequestMapping(value = "/ActivityLogToExcel", method = RequestMethod.POST)
	public ModelAndView ActivityLogToExcel(HttpServletRequest request,HttpServletResponse response) 
	{
		session=request.getSession(false);
		ModelAndView modelAndViewObj = new ModelAndView();
		reportslogger.info("In Activity Log Excel File Download");
		ActivityLogDetails ActivityLogDetailsObjExcel=new ActivityLogDetails();	
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		ActivityLogDetailsObjExcel.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in ActivityLogToExcel mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);
		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date: " + fromDate);
		String toDate = request.getParameter("endDate");
		reportslogger.info("To Date: " + toDate);

		String userOLMId = request.getParameter("userId");
		reportslogger.info("user Id: "+userOLMId);
		if (fromDate != "") {
			ActivityLogDetailsObjExcel.setFromDate(fromDate);
		} else

			ActivityLogDetailsObjExcel.setFromDate(null);

		if (toDate != "") {
			ActivityLogDetailsObjExcel.setToDate(toDate);
		} else

			ActivityLogDetailsObjExcel.setToDate(null);

		if (userOLMId == null || userOLMId.equals("")) {
			ActivityLogDetailsObjExcel.setChildUserId(null);

		} else
			ActivityLogDetailsObjExcel.setChildUserId(userOLMId.trim());


		String pageNum=null;

		List<ActivityLogDetails> ActivityLogExcelList=new ArrayList<ActivityLogDetails>();



		ActivityLogExcelList=ReportsDaoObj.getActivityLogExcelList(ActivityLogDetailsObjExcel, pageNum);
		if(ActivityLogExcelList==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("ActivityLogSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Excel Details List size in Controller:"+ActivityLogExcelList.size());

		int rowNumber = 1;
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("Activity_Log");
		XSSFCell cell = null;
		XSSFRow row;
		XSSFCellStyle my_style = wb.createCellStyle();
		XSSFFont my_font=wb.createFont();
		my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		my_style.setFont(my_font);
		XSSFCellStyle rightAligned = wb.createCellStyle();
		rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);

		row = sheet.createRow(0);
		cell = row.createCell(0);
		cell.setCellValue("User ID");
		cell.setCellStyle(my_style);

		cell = row.createCell(1);
		cell.setCellValue("Role");
		cell.setCellStyle(my_style);

		cell = row.createCell(2);
		cell.setCellValue("Activity");
		cell.setCellStyle(my_style);

		cell = row.createCell(3);
		cell.setCellValue("Activity Start Time");
		cell.setCellStyle(my_style);

		cell = row.createCell(4);
		cell.setCellValue("Status");
		cell.setCellStyle(my_style);


		cell = row.createCell(5);
		cell.setCellValue("Remarks");
		cell.setCellStyle(my_style);
		cell = row.createCell(6);
		cell.setCellValue("File Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(7);
		cell.setCellValue("Record Count");
		cell.setCellStyle(my_style);
		cell = row.createCell(8);
		cell.setCellValue("Value");
		cell.setCellStyle(my_style);


		for (int i = 0; i <ActivityLogExcelList.size(); i++) {
			//reportslogger.info("i value"+i);
			ActivityLogDetails ActivityLogDetailsObject =
					ActivityLogExcelList.get(i);

			row = sheet.createRow(rowNumber); 
			cell = row.createCell(0);
			cell.setCellValue(ActivityLogDetailsObject.getChildUserId());
			//sheet.autoSizeColumn(0); 

			cell = row.createCell(1);
			cell.setCellValue(ActivityLogDetailsObject.getUserRole());
			//sheet.autoSizeColumn(1); 
			cell = row.createCell(2);
			cell.setCellValue(ActivityLogDetailsObject.getActivity());
			//sheet.autoSizeColumn(2); 

			cell = row.createCell(3);
			cell.setCellValue(ActivityLogDetailsObject.getActivityStartTime());
			//sheet.autoSizeColumn(3); 
			cell = row.createCell(4);
			cell.setCellValue(ActivityLogDetailsObject.getStatus());
			//sheet.autoSizeColumn(4); 

			cell = row.createCell(5);
			cell.setCellValue(ActivityLogDetailsObject.getRemarks());
			//sheet.autoSizeColumn(5); 

			if(ActivityLogDetailsObject.getFileName()==null||ActivityLogDetailsObject.getFileName()==""||ActivityLogDetailsObject.getFileName().equalsIgnoreCase(null)){
				cell = row.createCell(6);
				cell.setCellValue("");
			}
			else{
				cell = row.createCell(6);
				cell.setCellValue(ActivityLogDetailsObject.getFileName());
			}

			//sheet.autoSizeColumn(6);
			if(ActivityLogDetailsObject.getRecCount()==null||ActivityLogDetailsObject.getRecCount()==""||ActivityLogDetailsObject.getRecCount().equalsIgnoreCase("null")){
				cell = row.createCell(7);
				cell.setCellValue("");
			}
			//sheet.autoSizeColumn(7);
			else
			{
				cell = row.createCell(7);
				cell.setCellValue(ActivityLogDetailsObject.getRecCount());
				cell.setCellStyle(rightAligned);
			}
			if(ActivityLogDetailsObject.getValueOftheFile()==null||ActivityLogDetailsObject.getValueOftheFile()==""||ActivityLogDetailsObject.getValueOftheFile().equalsIgnoreCase("0.00")){
				cell = row.createCell(8);
				cell.setCellValue("");
			}
			else
			{
				cell = row.createCell(8);
				cell.setCellValue(ActivityLogDetailsObject.getValueOftheFile());
				cell.setCellStyle(rightAligned);

			}
			//sheet.autoSizeColumn(8); 









			//sheet.autoSizeColumn(7);





			//sheet.autoSizeColumn(8); }

			rowNumber++;

		}
		for(int i=0;i<=8;i++){
			sheet.autoSizeColumn(i);							 
		}
		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		byte[] outArray = outByteStream.toByteArray();

		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(new Date());

		String fileName = "APS_Activity_Log"+"_"+date+".xlsx";
		reportslogger.info("filename is"+fileName);

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}

		reportslogger.info("End of Activity Log Excel records download "); 

		return modelAndViewObj;

	}
	@RequestMapping(value = "/viewReports", method = RequestMethod.GET)
	public ModelAndView viewReports(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("Reports");
		return modelAndViewObj;
	}

	//************************PAYMENT ADVICE TRANS LEVEL STATUS TRACKING***********************


	//	PaymentAdviceBean adviceTransBeanObj=new PaymentAdviceBean();

	@RequestMapping(value = "/adviceTransLevel")
	public ModelAndView transLevelDefault(ModelMap model,HttpServletRequest request, HttpServletResponse response)

	{
		ModelAndView modelAndViewObj = new ModelAndView();
		PaymentAdviceBean adviceTransBeanObj1=new PaymentAdviceBean();
		String errorMsg;
		try
		{

			reportslogger.info("Entered in to transLevelDefault mapping at reports controller");			    
			int pageNumber = 1;
			reportslogger.info("PageNumber in transLevelDefault mapping:"+pageNumber);

			session=request.getSession(false);
			String userId=session.getAttribute("userid").toString();
			reportslogger.info("UserId in transLevelDefault mapping is:"+userId);

			String role=session.getAttribute("user_role_id").toString();
			reportslogger.info("User Role in transLevelDefault mapping is:"+role);

			/*int roleType=paymentAdviceDaoObj.getRoleType(userId);
					reportslogger.info("UserId role in transLevelDefault mapping is:"+roleType);*/

			List<String> adviceProcessList=new ArrayList<String>();

			adviceProcessList=paymentAdviceDaoObj.adviceProcessListDropdown(role,userId);

			if(adviceProcessList==null)
			{
				reportslogger.info("Data Base Issues..Retry.....Exception in transLevelDefault");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("adviceTransBeanObjJsp",adviceTransBeanObj1);
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
				modelAndViewObj.setViewName("adviceTransLevelDefault");
				return modelAndViewObj;
			}


			adviceTransBeanObj1.setFromDate(null);

			reportslogger.info("START DATE FROM JSP in transLevelDefault mapping is:"+adviceTransBeanObj1.getFromDate());

			adviceTransBeanObj1.setToDate(null);

			reportslogger.info("END DATE FROM JSP in transLevelDefault mapping is:"+adviceTransBeanObj1.getToDate());

			adviceTransBeanObj1.setTicketId(null);

			adviceTransBeanObj1.setCustBankAcctNum(null);

			adviceTransBeanObj1.setUtrNum(null);

			adviceTransBeanObj1.setProcess(null);

			adviceTransBeanObj1.setUploadedBy(null);

			HashMap<Integer, List<PaymentAdviceBean>> adviceHashMap = paymentAdviceDaoObj.adviceSearchTransLevel(pageNumber,adviceTransBeanObj1,role,userId);

			errorMsg=adviceTransBeanObj1.getErrorMsg();

			reportslogger.info("Error message in transLevelDefault mapping is"+errorMsg);

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(adviceHashMap==null )
			{
				reportslogger.info("Data Base Issues...Exception in transLevelDefault");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
				modelAndViewObj.setViewName("adviceTransLevelDefault");
				return modelAndViewObj;
			}


			modelAndViewObj.addObject("adviceHashMap", adviceHashMap);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			modelAndViewObj.setViewName("adviceTransLevelDefault");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		reportslogger.info("Executed transLevelDefault at reports controller)");	  

		return modelAndViewObj;
	}


	@RequestMapping(value = "/adviceTransLevelSearch")
	public ModelAndView transLevelSearch(ModelMap model,HttpServletRequest request, HttpServletResponse response)

	{
		ModelAndView modelAndViewObj = new ModelAndView();
		PaymentAdviceBean adviceTransBeanObj2=new PaymentAdviceBean();

		try
		{
			reportslogger.info("Entered into adviceTransLevelSearch mapping at reports controller");			    
			int pageNumber = 1;
			reportslogger.info("Pagenumber in adviceTransLevelSearch mapping :"+pageNumber);

			session=request.getSession(false);
			String userId=session.getAttribute("userid").toString();
			reportslogger.info("UserId in adviceTransLevelSearch mapping  is:"+userId);

			String role=session.getAttribute("user_role_id").toString();
			reportslogger.info("User Role in transLevelDefault mapping is:"+role);
			List<String> adviceProcessList=new ArrayList<String>();

			adviceProcessList=paymentAdviceDaoObj.adviceProcessListDropdown(role,userId);

			if(adviceProcessList==null)
			{
				reportslogger.info("Data Base Issues...Exception in adviceTransLevelSearch");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("adviceTransBeanObjJsp",adviceTransBeanObj2);
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
				modelAndViewObj.setViewName("adviceTransLevelDefault");
				return modelAndViewObj;
			}



			String fromDate =request.getParameter("startDateId");
			String toDate=request.getParameter("endDateId");
			String ticketId=request.getParameter("tktNumber");
			String custBankAcct=request.getParameter("bankAcctNum");
			String utrNum=request.getParameter("utrNumberId");
			String process=request.getParameter("process");
			String uploaderId=request.getParameter("uploaderId");

			if (fromDate != "") {
				adviceTransBeanObj2.setFromDate(fromDate);
			}
			else
				adviceTransBeanObj2.setFromDate(null);

			if(toDate !="")
			{
				adviceTransBeanObj2.setToDate(toDate);
			}
			else
				adviceTransBeanObj2.setToDate(null);


			if(ticketId==null||ticketId.equalsIgnoreCase(""))
				adviceTransBeanObj2.setTicketId(null);
			else
				adviceTransBeanObj2.setTicketId(ticketId.trim());

			if(custBankAcct==null||custBankAcct.equalsIgnoreCase(""))
				adviceTransBeanObj2.setCustBankAcctNum(null);
			else
				adviceTransBeanObj2.setCustBankAcctNum(custBankAcct.trim());

			if(utrNum==null||utrNum.equalsIgnoreCase(""))
				adviceTransBeanObj2.setUtrNum(null);
			else
				adviceTransBeanObj2.setUtrNum(utrNum.trim());
			/*
						if(process==null||process.equalsIgnoreCase(""))
							adviceTransBeanObj.setProcess(null);
			            else*/
			adviceTransBeanObj2.setProcess(process);

			if(uploaderId==null||uploaderId.equalsIgnoreCase(""))
				adviceTransBeanObj2.setUploadedBy(null);
			else
				adviceTransBeanObj2.setUploadedBy(uploaderId.trim());

			reportslogger.info("To date from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj2.getToDate());
			reportslogger.info("From date from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj2.getFromDate());
			reportslogger.info("Ticket Id from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj2.getTicketId());
			reportslogger.info("Customer Bank account num from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj2.getCustBankAcctNum());
			reportslogger.info("Utr Number from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj2.getUtrNum());
			reportslogger.info("Uploader user Id from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj2.getUploadedBy());
			reportslogger.info("Process from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj2.getProcess());


			HashMap<Integer, List<PaymentAdviceBean>> adviceHashMap = paymentAdviceDaoObj.adviceSearchTransLevel(pageNumber,adviceTransBeanObj2,role,userId);

			String errorMsg=adviceTransBeanObj2.getErrorMsg();

			reportslogger.info("Error Message in adviceTransLevelSearch mapping:"+errorMsg);

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";


			if(adviceHashMap==null)
			{
				reportslogger.info("Data Base Issues...Exception in adviceTransLevelSearch");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("adviceTransBeanObjJsp",adviceTransBeanObj2);
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
				modelAndViewObj.setViewName("adviceTransLevelDefault");
				return modelAndViewObj;
			}


			modelAndViewObj.addObject("adviceHashMap", adviceHashMap);
			modelAndViewObj.addObject("adviceTransBeanObjJsp",adviceTransBeanObj2);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			if(fromDate!=null || toDate!=null || ticketId != null ||
					custBankAcct!= null || utrNum!=null || process!=null || uploaderId!=null){
				reportslogger.info("searchFlag set");
				modelAndViewObj.addObject("searchFlag", "exportEnabled");
			}
			modelAndViewObj.setViewName("adviceTransLevelDefault");
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		reportslogger.info("Executed adviceTransLevelSearch at reports controller)");	  
		return modelAndViewObj;
	}




	@RequestMapping(value = "/adviceTranslevelNextPage")
	public ModelAndView adviceTransLevelNextPage(HttpServletRequest request,HttpServletResponse response) 
	{
		ModelAndView modelAndViewObj = new ModelAndView();

		PaymentAdviceBean adviceTransBeanObj3=new PaymentAdviceBean();

		int pageNumber = Integer.parseInt(request.getParameter("pageNumber"));

		reportslogger.info(" PageNumber in adviceTranslevelNextPage mapping:" + pageNumber);

		try
		{
			reportslogger.info("Entered into adviceTransLevelNextPage mapping at reports Controller");

			session=request.getSession(false);
			String userId=session.getAttribute("userid").toString();
			reportslogger.info("UserId in adviceTransLevelNextPage mapping is:"+userId);

			String role=session.getAttribute("user_role_id").toString();
			reportslogger.info("User Role in transLevelDefault mapping is:"+role);

			List<String> adviceProcessList=new ArrayList<String>();

			adviceProcessList=paymentAdviceDaoObj.adviceProcessListDropdown(role,userId);


			if(adviceProcessList==null)
			{
				reportslogger.info("Data Base Issues...Exception in adviceTransLevelNextPage");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("adviceTransLevelDefault");
				return modelAndViewObj;
			}

			String fromDate =request.getParameter("startDateId");
			String toDate=request.getParameter("endDateId");
			String ticketId=request.getParameter("tktNumber");
			String custBankAcct=request.getParameter("bankAcctNum");
			String utrNum=request.getParameter("utrNumberId");
			String process=request.getParameter("process");
			String uploaderId=request.getParameter("uploaderId");

			if (fromDate != "") {
				adviceTransBeanObj3.setFromDate(fromDate);
			}
			else
				adviceTransBeanObj3.setFromDate(null);

			if(toDate !="")
			{
				adviceTransBeanObj3.setToDate(toDate);
			}
			else
				adviceTransBeanObj3.setToDate(null);


			if(ticketId==null||ticketId.equalsIgnoreCase(""))
				adviceTransBeanObj3.setTicketId(null);
			else
				adviceTransBeanObj3.setTicketId(ticketId.trim());

			if(custBankAcct==null||custBankAcct.equalsIgnoreCase(""))
				adviceTransBeanObj3.setCustBankAcctNum(null);
			else
				adviceTransBeanObj3.setCustBankAcctNum(custBankAcct.trim());

			if(utrNum==null||utrNum.equalsIgnoreCase(""))
				adviceTransBeanObj3.setUtrNum(null);
			else
				adviceTransBeanObj3.setUtrNum(utrNum.trim());
			/*
					if(process==null||process.equalsIgnoreCase(""))
						adviceTransBeanObj.setProcess(null);
		            else*/
			adviceTransBeanObj3.setProcess(process);

			if(uploaderId==null||uploaderId.equalsIgnoreCase(""))
				adviceTransBeanObj3.setUploadedBy(null);
			else
				adviceTransBeanObj3.setUploadedBy(uploaderId.trim());

			reportslogger.info("To date from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj3.getToDate());
			reportslogger.info("From date from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj3.getFromDate());
			reportslogger.info("Ticket Id from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj3.getTicketId());
			reportslogger.info("Customer Bank account num from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj3.getCustBankAcctNum());
			reportslogger.info("Utr Number from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj3.getUtrNum());
			reportslogger.info("Uploader user Id from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj3.getUploadedBy());
			reportslogger.info("Process from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj3.getProcess());

			HashMap<Integer, List<PaymentAdviceBean>> adviceHashMap = paymentAdviceDaoObj.adviceSearchTransLevel(pageNumber,adviceTransBeanObj3,role,userId);

			String errorMsg=adviceTransBeanObj3.getErrorMsg();

			reportslogger.info("Error Message in adviceTransLevelNextPage mapping:"+errorMsg);

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(adviceHashMap==null)
			{
				reportslogger.info("Data Base Issues...Exception in adviceTransLevelNextPage");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("adviceTransBeanObjJsp",adviceTransBeanObj3);
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
				modelAndViewObj.setViewName("adviceTransLevelDefault");
				return modelAndViewObj;
			}


			modelAndViewObj.addObject("adviceHashMap", adviceHashMap);
			modelAndViewObj.addObject("adviceTransBeanObjJsp",adviceTransBeanObj3);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			modelAndViewObj.setViewName("adviceTransLevelDefault");

		}
		catch (Exception e) {
			e.printStackTrace();
		}
		reportslogger.info("Executed adviceTransLevelNextPage at reports controller)");

		return modelAndViewObj;
	}


	@RequestMapping(value = "/exportToExcelAdviceTransLevel", method = RequestMethod.POST)
	public ModelAndView exportToExcelAdviceTransLevel(ModelMap model,HttpServletRequest request, HttpServletResponse response) 
	{
		ModelAndView modelAndViewObj = new ModelAndView();
		PaymentAdviceBean adviceTransBeanObj4=new PaymentAdviceBean();
		try{

			reportslogger.info("Entered into exportToExcelAdviceTransLevel mapping at reports controller");	

			session=request.getSession(false);
			String userId=session.getAttribute("userid").toString();
			reportslogger.info("UserId in exportToExcelAdviceTransLevel mapping is:"+userId);

			String role=session.getAttribute("user_role_id").toString();
			reportslogger.info("User Role in transLevelDefault mapping is:"+role);

			String page = null;


			List<String> adviceProcessList=new ArrayList<String>();

			adviceProcessList=paymentAdviceDaoObj.adviceProcessListDropdown(role,userId);


			if(adviceProcessList==null)
			{
				reportslogger.info("Data Base Issues...Exception in adviceTransLevelNextPage");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("adviceTransBeanObj",adviceTransBeanObj4);
				modelAndViewObj.setViewName("adviceTransLevelDefault");
				return modelAndViewObj;
			}


			String fromDate =request.getParameter("startDateId");
			String toDate=request.getParameter("endDateId");
			String ticketId=request.getParameter("tktNumber");
			String custBankAcct=request.getParameter("bankAcctNum");
			String utrNum=request.getParameter("utrNumberId");
			String process=request.getParameter("process");
			String uploaderId=request.getParameter("uploaderId");

			if (fromDate != "") {
				adviceTransBeanObj4.setFromDate(fromDate);
			}
			else
				adviceTransBeanObj4.setFromDate(null);

			if(toDate !="")
			{
				adviceTransBeanObj4.setToDate(toDate);
			}
			else
				adviceTransBeanObj4.setToDate(null);


			if(ticketId==null||ticketId.equalsIgnoreCase(""))
				adviceTransBeanObj4.setTicketId(null);
			else
				adviceTransBeanObj4.setTicketId(ticketId.trim());

			if(custBankAcct==null||custBankAcct.equalsIgnoreCase(""))
				adviceTransBeanObj4.setCustBankAcctNum(null);
			else
				adviceTransBeanObj4.setCustBankAcctNum(custBankAcct.trim());

			if(utrNum==null||utrNum.equalsIgnoreCase(""))
				adviceTransBeanObj4.setUtrNum(null);
			else
				adviceTransBeanObj4.setUtrNum(utrNum.trim());
			/*
						if(process==null||process.equalsIgnoreCase(""))
							adviceTransBeanObj.setProcess(null);
			            else*/
			adviceTransBeanObj4.setProcess(process);

			if(uploaderId==null||uploaderId.equalsIgnoreCase(""))
				adviceTransBeanObj4.setUploadedBy(null);
			else
				adviceTransBeanObj4.setUploadedBy(uploaderId.trim());

			reportslogger.info("To date from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj4.getToDate());
			reportslogger.info("From date from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj4.getFromDate());
			reportslogger.info("Ticket Id from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj4.getTicketId());
			reportslogger.info("Customer Bank account num from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj4.getCustBankAcctNum());
			reportslogger.info("Utr Number from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj4.getUtrNum());
			reportslogger.info("Uploader user Id from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj4.getUploadedBy());
			reportslogger.info("Process from jsp in adviceTransLevelSearch mapping:"+adviceTransBeanObj4.getProcess());


			PaymentAdviceBean adviceTransFileObj=paymentAdviceDaoObj.downloadedTransFile(adviceTransBeanObj4,/* downloadedFilesPath,*/ extension, page,role,userId);	  

			String errorMsg=adviceTransBeanObj4.getErrorMsg();
			reportslogger.info("Error Message in payment advcie exportToExcelAdviceTransLevel mapping at controller "+errorMsg);
			/* 
			        if(errorMsg.equalsIgnoreCase("SUCCESS"))
					  {
						  errorMsg="";
					  }
					  else
						  errorMsg="No records Found";
			 */

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(adviceTransFileObj==null)
			{
				reportslogger.info("Data Base Issues...Exception in exportToExcel");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
				modelAndViewObj.setViewName("adviceTransLevelDefault");
				return modelAndViewObj;
			}
			if("FAILURE. NO RECORDS FOUND WITH THE SPECIFIED SEARCH CRITERIA".equalsIgnoreCase
					(adviceTransFileObj.getErrorMsg()))
			{
				reportslogger.info("Data Base Issues...Exception in exportToExcel");
				modelAndViewObj.addObject("errorMsg", "NO RECORDS FOUND WITH THE SPECIFIED SEARCH CRITERIA");
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
				modelAndViewObj.setViewName("adviceTransLevelDefault");
				return modelAndViewObj;
			}

			/*String filePath=downloadedFilesPath;
					reportslogger.info("Filepath is:"+filePath);*/

			String filename="APS_PAY_ADVICE_TRANSACTION_LEVEL_"+paymentAdviceDaoObj.getDateTime()+"."+extension;
			reportslogger.info("Filename in exportToExcelAdviceTransLevel mapping:"+filename);

			//  String finalPath=/*filePath+"\\"+*/filename;

			ServletOutputStream out = response.getOutputStream();
			FileInputStream in = new FileInputStream(filename);
			reportslogger.info("File name:"+in);

			response.setContentType("APPLICATION/OCTET-STREAM");

			response.addHeader("content-disposition",
					"attachment; filename=" +filename);



			int octet;
			while((octet = in.read()) != -1)
				out.write(octet);

			in.close();
			out.flush();
			out.close();
			response.flushBuffer();

			reportslogger.info("Executed exportToExcelAdviceTransLevel at reports controller)");	  

		}catch (Exception e) {
			e.printStackTrace();
		}
		return modelAndViewObj;
	}


	//**********************************************PAYMENT ADVICE TRANS LEVEL STATUS TRACKINGREPORT END***********************************************



	//************************PAYMENT ADVICE EFT LEVEL STATUS TRACKING***********************


	//PaymentAdviceBean adviceEFTBeanObj=new PaymentAdviceBean();

	@RequestMapping(value = "/adviceEFTLevel")
	public ModelAndView eftLevelDefault(ModelMap model,HttpServletRequest request, HttpServletResponse response)

	{
		ModelAndView modelAndViewObj = new ModelAndView();
		PaymentAdviceBean adviceEFTBeanObj1=new PaymentAdviceBean();
		reportslogger.info("Entered into eftLevelDefault mapping at reports controller");	
		try
		{
			int pageNumber = 1;
			reportslogger.info(" PageNumber in eftLevelDefault mapping:" + pageNumber);

			session=request.getSession(false);
			String userId=session.getAttribute("userid").toString();
			reportslogger.info("UserId in eftLevelDefault mapping is:"+userId);
			String role=session.getAttribute("user_role_id").toString();
			reportslogger.info("User Role in transLevelDefault mapping is:"+role);

			List<String> adviceProcessList=new ArrayList<String>();

			adviceProcessList=paymentAdviceDaoObj.adviceProcessListDropdown(role,userId);

			if(adviceProcessList==null)
			{
				reportslogger.info("Data Base Issues...Exception in eftLevelDefault");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("adviceEFTBeanObjJsp",adviceEFTBeanObj1);
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
				modelAndViewObj.setViewName("adviceEFTLevelDefault");

				return modelAndViewObj;
			}


			adviceEFTBeanObj1.setFromDate(null);

			//  reportslogger.info("START DATE FROM JSP:"+ request.getParameter("startDate").trim().replaceAll("(\\s)+", "$0"));

			adviceEFTBeanObj1.setToDate(null);

			//  reportslogger.info("END DATE FROM JSP:"+ request.getParameter("endDateId").trim().replaceAll("(\\s)+", "$0"));

			adviceEFTBeanObj1.setTicketId(null);

			adviceEFTBeanObj1.setCustBankAcctNum(null);

			adviceEFTBeanObj1.setUtrNum(null);

			adviceEFTBeanObj1.setProcess(null);

			adviceEFTBeanObj1.setUploadedBy(null);

			reportslogger.info("To date from jsp in eftLevelDefault mapping:"+adviceEFTBeanObj1.getToDate());
			reportslogger.info("From date from jsp in eftLevelDefault mapping:"+adviceEFTBeanObj1.getFromDate());
			reportslogger.info("Ticket Id from jsp in eftLevelDefault mapping:"+adviceEFTBeanObj1.getTicketId());
			reportslogger.info("Customer Bank account num from jsp in eftLevelDefault mapping:"+adviceEFTBeanObj1.getCustBankAcctNum());
			reportslogger.info("Utr Number from jsp in eftLevelDefault mapping:"+adviceEFTBeanObj1.getUtrNum());
			reportslogger.info("Uploader user Id from jsp in eftLevelDefault mapping:"+adviceEFTBeanObj1.getUploadedBy());
			reportslogger.info("Process from jsp in eftLevelDefault mapping:"+adviceEFTBeanObj1.getProcess());


			HashMap<Integer, List<PaymentAdviceBean>> adviceHashMap = paymentAdviceDaoObj.adviceSearchEFTLevel(pageNumber,adviceEFTBeanObj1,role,userId);

			String errorMsg=adviceEFTBeanObj1.getErrorMsg();
			reportslogger.info("Error Message in eftLevelDefault mapping:"+errorMsg);

			/* if(errorMsg.equalsIgnoreCase("SUCCESS"))
				  {
					  errorMsg="";
				  }
				 else 
					 errorMsg="No records Found";*/

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(adviceHashMap==null)
			{
				reportslogger.info("Data Base Issues...Exception in eftLevelDefault");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
				modelAndViewObj.setViewName("adviceEFTLevelDefault");
				return modelAndViewObj;
			}


			/* reportslogger.info("Model view page is:"+modelAndViewObj.getViewName());
				  reportslogger.info("Context is:"+request.getContextPath());
				  reportslogger.info("Executed eftLevelDefault");*/


			modelAndViewObj.addObject("adviceHashMap", adviceHashMap);
			//	modelAndViewObj.addObject("adviceEFTBeanObjJsp",adviceEFTBeanObj);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			modelAndViewObj.setViewName("adviceEFTLevelDefault");
			return modelAndViewObj;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		reportslogger.info("Executed eftLevelDefault at reports controller)");	  

		return modelAndViewObj;
	}


	@RequestMapping(value = "/adviceEFTLevelSearch")
	public ModelAndView eftLevelSearch(ModelMap model,HttpServletRequest request, HttpServletResponse response)

	{
		ModelAndView modelAndViewObj = new ModelAndView();
		PaymentAdviceBean adviceEFTBeanObj2=new PaymentAdviceBean();

		try
		{
			reportslogger.info("Entered into adviceEFTLevelSearch mapping at reports controller");
			int pageNumber = 1;
			reportslogger.info(" PageNumber in adviceEFTLevelSearch mapping:" + pageNumber);

			session=request.getSession(false);
			String userId=session.getAttribute("userid").toString();
			reportslogger.info("UserId in adviceEFTLevelSearch mapping is:"+userId);

			String role=session.getAttribute("user_role_id").toString();
			reportslogger.info("User Role in transLevelDefault mapping is:"+role);

			List<String> adviceProcessList=new ArrayList<String>();

			adviceProcessList=paymentAdviceDaoObj.adviceProcessListDropdown(role,userId);


			if(adviceProcessList==null)
			{
				reportslogger.info("Data Base Issues...Exception in adviceEFTLevelSearch");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("adviceEFTBeanObjJsp",adviceEFTBeanObj2);
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
				modelAndViewObj.setViewName("adviceEFTLevelDefault");

				return modelAndViewObj;
			}


			String fromDate =request.getParameter("startDateId");
			String toDate=request.getParameter("endDateId");
			String ticketId=request.getParameter("tktNumber");
			String custBankAcct=request.getParameter("bankAcctNum");
			String utrNum=request.getParameter("utrNumberId");
			String process=request.getParameter("process");
			String uploaderId=request.getParameter("uploaderId");

			if (fromDate != "") {
				adviceEFTBeanObj2.setFromDate(fromDate);
			}
			else
				adviceEFTBeanObj2.setFromDate(null);

			if(toDate !="")
			{
				adviceEFTBeanObj2.setToDate(toDate);
			}
			else
				adviceEFTBeanObj2.setToDate(null);


			if(ticketId==null||ticketId.equalsIgnoreCase(""))
				adviceEFTBeanObj2.setTicketId(null);
			else
				adviceEFTBeanObj2.setTicketId(ticketId.trim());

			if(custBankAcct==null||custBankAcct.equalsIgnoreCase(""))
				adviceEFTBeanObj2.setCustBankAcctNum(null);
			else
				adviceEFTBeanObj2.setCustBankAcctNum(custBankAcct.trim());

			if(utrNum==null||utrNum.equalsIgnoreCase(""))
				adviceEFTBeanObj2.setUtrNum(null);
			else
				adviceEFTBeanObj2.setUtrNum(utrNum.trim());

			/*if(process==null||process.equalsIgnoreCase(""))
							adviceEFTBeanObj.setProcess(null);
			            else*/
			adviceEFTBeanObj2.setProcess(process);

			if(uploaderId==null||uploaderId.equalsIgnoreCase(""))
				adviceEFTBeanObj2.setUploadedBy(null);
			else
				adviceEFTBeanObj2.setUploadedBy(uploaderId.trim());

			reportslogger.info("To date from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj2.getToDate());
			reportslogger.info("From date from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj2.getFromDate());
			reportslogger.info("Ticket Id from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj2.getTicketId());
			reportslogger.info("Customer Bank account num from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj2.getCustBankAcctNum());
			reportslogger.info("Utr Number from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj2.getUtrNum());
			reportslogger.info("Uploader user Id from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj2.getUploadedBy());
			reportslogger.info("Process from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj2.getProcess());

			HashMap<Integer, List<PaymentAdviceBean>> adviceHashMap = paymentAdviceDaoObj.adviceSearchEFTLevel(pageNumber,adviceEFTBeanObj2,role,userId);
			/*				  if(adviceHashMap==null)
				  {
					  reportslogger.info("No results Found For hashmap");
						 modelAndViewObj.addObject("error", "No Records Found");
						  modelAndViewObj.addObject("adviceHashMap", adviceHashMap);
							modelAndViewObj.addObject("adviceEFTBeanObjJsp",adviceEFTBeanObj);
							modelAndViewObj.addObject("currentPage", pageNumber);
							modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
						 modelAndViewObj.setViewName("adviceEFTLevelDefault");
						 return modelAndViewObj;
				  }			 

			 */
			String errorMsg=adviceEFTBeanObj2.getErrorMsg();
			reportslogger.info("Error Message in adviceEFTLevelSearch mapping:"+errorMsg);

			/*  if(errorMsg.equalsIgnoreCase("SUCCESS"))
				  {
					  errorMsg="";
				  }
				 else 
					 errorMsg="No records Found";*/

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(adviceHashMap==null)
			{
				reportslogger.info("Data Base Issues...Exception in adviceEFTLevelSearch");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("adviceHashMap", adviceHashMap);
				modelAndViewObj.addObject("adviceEFTBeanObjJsp",adviceEFTBeanObj2);
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
				modelAndViewObj.setViewName("adviceEFTLevelDefault");
				return modelAndViewObj;
			}


			modelAndViewObj.addObject("adviceHashMap", adviceHashMap);
			modelAndViewObj.addObject("adviceEFTBeanObjJsp",adviceEFTBeanObj2);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			modelAndViewObj.setViewName("adviceEFTLevelDefault");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		reportslogger.info("Executed adviceEFTLevelSearch at reports controller)");	  

		return modelAndViewObj;
	}



	@RequestMapping(value = "/adviceEFTLevelNextPage")
	public ModelAndView adviceEFTLevelNextPage(HttpServletRequest request,HttpServletResponse response) 
	{
		ModelAndView modelAndViewObj = new ModelAndView();

		int pageNumber = Integer.parseInt(request.getParameter("pageNumber"));

		reportslogger.info("Entered into adviceEFTLevelNextPage mapping at reports controller");

		reportslogger.info(" PageNumber in adviceEFTLevelNextPage mapping:" + pageNumber);
		PaymentAdviceBean adviceEFTBeanObj3=new PaymentAdviceBean();
		try
		{

			session=request.getSession(false);
			String userId=session.getAttribute("userid").toString();
			reportslogger.info("UserId in adviceEFTLevelNextPage mapping is:"+userId);

			String role=session.getAttribute("user_role_id").toString();
			reportslogger.info("User Role in transLevelDefault mapping is:"+role);

			List<String> adviceProcessList=new ArrayList<String>();

			adviceProcessList=paymentAdviceDaoObj.adviceProcessListDropdown(role,userId);

			if(adviceProcessList==null)
			{
				reportslogger.info("Data Base Issues...Exception in adviceEFTLevelNextPage");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("adviceEFTBeanObjJsp",adviceEFTBeanObj3);
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
				modelAndViewObj.setViewName("adviceEFTLevelDefault");

				return modelAndViewObj;
			}


			String fromDate =request.getParameter("startDateId");
			String toDate=request.getParameter("endDateId");
			String ticketId=request.getParameter("tktNumber");
			String custBankAcct=request.getParameter("bankAcctNum");
			String utrNum=request.getParameter("utrNumberId");
			String process=request.getParameter("process");
			String uploaderId=request.getParameter("uploaderId");

			if (fromDate != "") {
				adviceEFTBeanObj3.setFromDate(fromDate);
			}
			else
				adviceEFTBeanObj3.setFromDate(null);

			if(toDate !="")
			{
				adviceEFTBeanObj3.setToDate(toDate);
			}
			else
				adviceEFTBeanObj3.setToDate(null);


			if(ticketId==null||ticketId.equalsIgnoreCase(""))
				adviceEFTBeanObj3.setTicketId(null);
			else
				adviceEFTBeanObj3.setTicketId(ticketId.trim());

			if(custBankAcct==null||custBankAcct.equalsIgnoreCase(""))
				adviceEFTBeanObj3.setCustBankAcctNum(null);
			else
				adviceEFTBeanObj3.setCustBankAcctNum(custBankAcct.trim());

			if(utrNum==null||utrNum.equalsIgnoreCase(""))
				adviceEFTBeanObj3.setUtrNum(null);
			else
				adviceEFTBeanObj3.setUtrNum(utrNum.trim());

			/*if(process==null||process.equalsIgnoreCase(""))
						adviceEFTBeanObj.setProcess(null);
		            else*/
			adviceEFTBeanObj3.setProcess(process);

			if(uploaderId==null||uploaderId.equalsIgnoreCase(""))
				adviceEFTBeanObj3.setUploadedBy(null);
			else
				adviceEFTBeanObj3.setUploadedBy(uploaderId.trim());

			reportslogger.info("To date from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj3.getToDate());
			reportslogger.info("From date from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj3.getFromDate());
			reportslogger.info("Ticket Id from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj3.getTicketId());
			reportslogger.info("Customer Bank account num from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj3.getCustBankAcctNum());
			reportslogger.info("Utr Number from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj3.getUtrNum());
			reportslogger.info("Uploader user Id from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj3.getUploadedBy());
			reportslogger.info("Process from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj3.getProcess());


			HashMap<Integer, List<PaymentAdviceBean>> adviceHashMap = paymentAdviceDaoObj.adviceSearchEFTLevel(pageNumber,adviceEFTBeanObj3,role,userId);

			String errorMsg=adviceEFTBeanObj3.getErrorMsg();
			reportslogger.info("Error Message in adviceEFTLevelNextPage mapping:"+errorMsg);

			/*  if(errorMsg.equalsIgnoreCase("SUCCESS"))
			  {
				  errorMsg="";
			  }
			 else 
				 errorMsg="No records Found";*/

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(adviceHashMap==null)
			{
				reportslogger.info("Data Base Issues...Exception in adviceEFTLevelNextPage");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("adviceHashMap", adviceHashMap);
				modelAndViewObj.addObject("adviceEFTBeanObjJsp",adviceEFTBeanObj3);
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
				modelAndViewObj.setViewName("adviceEFTLevelDefault");
				return modelAndViewObj;
			}


			modelAndViewObj.addObject("adviceHashMap", adviceHashMap);
			modelAndViewObj.addObject("adviceEFTBeanObjJsp",adviceEFTBeanObj3);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			modelAndViewObj.setViewName("adviceEFTLevelDefault");

		}
		catch (Exception e) {
			e.printStackTrace();
		}
		reportslogger.info("Executed adviceEFTLevelNextPage at reports controller)");	  

		return modelAndViewObj;
	}


	@RequestMapping(value = "/exportToExcelEFTLevel", method = RequestMethod.POST)
	public ModelAndView exportToExcelEFTLevel(ModelMap model,HttpServletRequest request, HttpServletResponse response) 
	{
		ModelAndView modelAndViewObj = new ModelAndView();
		PaymentAdviceBean adviceEFTBeanObj4=new PaymentAdviceBean();

		try{

			reportslogger.info("Entered into exportToExcelEFTLevel mapping at reports controller");

			String page = null;


			session=request.getSession(false);
			String userId=session.getAttribute("userid").toString();
			reportslogger.info("UserId in exportToExcelEFTLevel mapping is:"+userId);

			String role=session.getAttribute("user_role_id").toString();
			reportslogger.info("User Role in transLevelDefault mapping is:"+role);

			List<String> adviceProcessList=new ArrayList<String>();

			adviceProcessList=paymentAdviceDaoObj.adviceProcessListDropdown(role,userId);

			if(adviceProcessList==null)
			{
				reportslogger.info("Data Base Issues...Exception in adviceEFTLevelNextPage");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("adviceEFTBeanObjJsp",adviceEFTBeanObj4);
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
				modelAndViewObj.setViewName("adviceEFTLevelDefault");

				return modelAndViewObj;
			}



			String fromDate =request.getParameter("startDateId");
			String toDate=request.getParameter("endDateId");
			String ticketId=request.getParameter("tktNumber");
			String custBankAcct=request.getParameter("bankAcctNum");
			String utrNum=request.getParameter("utrNumberId");
			String process=request.getParameter("process");
			String uploaderId=request.getParameter("uploaderId");

			if (fromDate != "") {
				adviceEFTBeanObj4.setFromDate(fromDate);
			}
			else
				adviceEFTBeanObj4.setFromDate(null);

			if(toDate !="")
			{
				adviceEFTBeanObj4.setToDate(toDate);
			}
			else
				adviceEFTBeanObj4.setToDate(null);


			if(ticketId==null||ticketId.equalsIgnoreCase(""))
				adviceEFTBeanObj4.setTicketId(null);
			else
				adviceEFTBeanObj4.setTicketId(ticketId.trim());

			if(custBankAcct==null||custBankAcct.equalsIgnoreCase(""))
				adviceEFTBeanObj4.setCustBankAcctNum(null);
			else
				adviceEFTBeanObj4.setCustBankAcctNum(custBankAcct.trim());

			if(utrNum==null||utrNum.equalsIgnoreCase(""))
				adviceEFTBeanObj4.setUtrNum(null);
			else
				adviceEFTBeanObj4.setUtrNum(utrNum.trim());

			/*if(process==null||process.equalsIgnoreCase(""))
								adviceEFTBeanObj.setProcess(null);
				            else*/
			adviceEFTBeanObj4.setProcess(process);

			if(uploaderId==null||uploaderId.equalsIgnoreCase(""))
				adviceEFTBeanObj4.setUploadedBy(null);
			else
				adviceEFTBeanObj4.setUploadedBy(uploaderId.trim());

			reportslogger.info("To date from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj4.getToDate());
			reportslogger.info("From date from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj4.getFromDate());
			reportslogger.info("Ticket Id from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj4.getTicketId());
			reportslogger.info("Customer Bank account num from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj4.getCustBankAcctNum());
			reportslogger.info("Utr Number from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj4.getUtrNum());
			reportslogger.info("Uploader user Id from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj4.getUploadedBy());
			reportslogger.info("Process from jsp in adviceEFTLevelSearch mapping:"+adviceEFTBeanObj4.getProcess());



			PaymentAdviceBean adviceEFTLevelFileObj=paymentAdviceDaoObj.downloadedEFTLevelFile(adviceEFTBeanObj4,/* downloadedFilesPath,*/ extension, page,role,userId);	  

			String errorMsg=adviceEFTBeanObj4.getErrorMsg();
			reportslogger.info("Error Message in payment advcie exportToExcelEFTLevel mapping at controller "+errorMsg);

			/* if(errorMsg.equalsIgnoreCase("SUCCESS"))
					  {
						  errorMsg="";
					  }
					  else
						  errorMsg="No records Found";*/

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(adviceEFTLevelFileObj==null)
			{
				reportslogger.info("Data Base Issues...Exception in exportToExcel");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("adviceProcessList", adviceProcessList);
				modelAndViewObj.setViewName("adviceEFTLevelDefault");
				return modelAndViewObj;
			}
			/*String filePath=downloadedFilesPath;
					reportslogger.info("Filepath is:"+filePath);*/

			String filename="APS_PAY_ADVICE_EFT_LEVEL_"+paymentAdviceDaoObj.getDateTime()+"."+extension;
			reportslogger.info("Filename:"+filename);

			//  String finalPath=/*filePath+"\\"+*/filename;

			ServletOutputStream out = response.getOutputStream();
			FileInputStream in = new FileInputStream(filename);
			reportslogger.info("File name:"+in);

			response.setContentType("APPLICATION/OCTET-STREAM");

			response.addHeader("content-disposition",
					"attachment; filename=" +filename);




			int octet;
			while((octet = in.read()) != -1)
				out.write(octet);

			in.close();
			out.flush();
			out.close();
			response.flushBuffer();
			reportslogger.info("Executed exportToExcelEFTLevel at reports controller)");	  

		}catch (Exception e) {
			e.printStackTrace();
		}
		return modelAndViewObj;
	}



	//**********************************************PAYMENT ADVICE TRANS LEVEL STATUS TRACKING REPORT END***********************************************


	//************************ PAYMENT ADVICE REQUEST LEVEL STATUS TRACKING***********************

	//PaymentAdviceBean adviceRequestBeanObj=new PaymentAdviceBean();

	@RequestMapping(value = "/adviceRequestLevel")
	public ModelAndView requestLevelDefault(ModelMap model,HttpServletRequest request, HttpServletResponse response)

	{
		ModelAndView modelAndViewObj = new ModelAndView();
		PaymentAdviceBean adviceRequestBeanObj1=new PaymentAdviceBean();

		reportslogger.info("Entered into adviceRequestLevel mapping at reports controller");
		try
		{
			int pageNumber = 1;
			reportslogger.info(" PageNumber in adviceRequestLevel mapping:" + pageNumber);

			session=request.getSession(false);
			String userId=session.getAttribute("userid").toString();
			reportslogger.info("UserId in adviceRequestLevel mapping is:"+userId);

			String role=session.getAttribute("user_role_id").toString();
			reportslogger.info("User Role in transLevelDefault mapping is:"+role);


			adviceRequestBeanObj1.setFromDate(null);

			adviceRequestBeanObj1.setToDate(null);

			adviceRequestBeanObj1.setTicketId(null);

			adviceRequestBeanObj1.setUploadedBy(null);

			reportslogger.info("To date from jsp in adviceTransLevelSearch mapping:"+adviceRequestBeanObj1.getToDate());
			reportslogger.info("From date from jsp in adviceTransLevelSearch mapping:"+adviceRequestBeanObj1.getFromDate());
			reportslogger.info("Ticket Id from jsp in adviceTransLevelSearch mapping:"+adviceRequestBeanObj1.getTicketId());
			reportslogger.info("UploaderId from jsp in adviceTransLevelSearch mapping:"+adviceRequestBeanObj1.getUploadedBy());

			HashMap<Integer, List<PaymentAdviceBean>> adviceHashMap = paymentAdviceDaoObj.adviceSearchRequestLevel(pageNumber,adviceRequestBeanObj1,role,userId);

			String errorMsg=adviceRequestBeanObj1.getErrorMsg();
			reportslogger.info("Error Message in adviceRequestLevel mapping:"+errorMsg);

			/*  if(errorMsg.equalsIgnoreCase("SUCCESS"))
				  {
					  errorMsg="";
				  }
				 else 
					 errorMsg="No records Found";*/

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(adviceHashMap==null)
			{
				reportslogger.info("Data Base Issues...Exception in adviceRequestLevel");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("adviceHashMap", adviceHashMap);
				modelAndViewObj.addObject("adviceRequestObjJsp",adviceRequestBeanObj1);
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.setViewName("adviceRequestDefault");
				return modelAndViewObj;
			}



			modelAndViewObj.addObject("adviceHashMap", adviceHashMap);
			//		 modelAndViewObj.addObject("adviceRequestObjJsp",adviceRequestBeanObj);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("sessionRole", role);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			modelAndViewObj.setViewName("adviceRequestDefault");
			return modelAndViewObj;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		reportslogger.info("Executed adviceRequestLevel at reports controller)");	  

		return modelAndViewObj;
	}

	@RequestMapping(value = "/waiverRequestLevel")
	public ModelAndView waiverRequestLevelDefault(ModelMap model,HttpServletRequest request, HttpServletResponse response)

	{
		ModelAndView modelAndViewObj = new ModelAndView();
		PaymentAdviceBean adviceRequestBeanObj1=new PaymentAdviceBean();

		reportslogger.info("Entered into waiverRequestLevel mapping at reports controller");
		try
		{
			int pageNumber = 1;
			reportslogger.info(" PageNumber in waiverRequestLevel mapping:" + pageNumber);

			session=request.getSession(false);
			String userId=session.getAttribute("userid").toString();
			reportslogger.info("UserId in waiverRequestLevel mapping is:"+userId);

			String role=session.getAttribute("user_role_id").toString();
			reportslogger.info("User Role in transLevelDefault mapping is:"+role);


			adviceRequestBeanObj1.setFromDate(null);

			adviceRequestBeanObj1.setToDate(null);

			adviceRequestBeanObj1.setTicketId(null);

			adviceRequestBeanObj1.setUploadedBy(null);

			reportslogger.info("To date from jsp in waiverRequestLevel mapping:"+adviceRequestBeanObj1.getToDate());
			reportslogger.info("From date from jsp in waiverRequestLevel mapping:"+adviceRequestBeanObj1.getFromDate());
			reportslogger.info("Ticket Id from jsp in waiverRequestLevel mapping:"+adviceRequestBeanObj1.getTicketId());
			reportslogger.info("UploaderId from jsp in waiverRequestLevel mapping:"+adviceRequestBeanObj1.getUploadedBy());

			HashMap<Integer, List<PaymentAdviceBean>> adviceHashMap = paymentAdviceDaoObj.waiverSearchRequestLevel(pageNumber,adviceRequestBeanObj1,role,userId);

			String errorMsg=adviceRequestBeanObj1.getErrorMsg();
			reportslogger.info("Error Message in waiverRequestLevel mapping:"+errorMsg);

			/*  if(errorMsg.equalsIgnoreCase("SUCCESS"))
				  {
					  errorMsg="";
				  }
				 else 
					 errorMsg="No records Found";*/

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(adviceHashMap==null)
			{
				reportslogger.info("Data Base Issues...Exception in waiverRequestLevel");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("adviceHashMap", adviceHashMap);
				modelAndViewObj.addObject("adviceRequestObjJsp",adviceRequestBeanObj1);
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.setViewName("WaiverRequestTrack");
				return modelAndViewObj;
			}



			modelAndViewObj.addObject("adviceHashMap", adviceHashMap);
			//		 modelAndViewObj.addObject("adviceRequestObjJsp",adviceRequestBeanObj);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("sessionRole", role);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			modelAndViewObj.setViewName("WaiverRequestTrack");
			return modelAndViewObj;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		reportslogger.info("Executed waiverRequestLevel at reports controller)");	  

		return modelAndViewObj;
	}

	@RequestMapping(value = "/waiverRequestSearch")
	public ModelAndView waiverRequestSearch(ModelMap model,HttpServletRequest request, HttpServletResponse response)

	{
		ModelAndView modelAndViewObj = new ModelAndView();
		PaymentAdviceBean adviceRequestBeanObj2=new PaymentAdviceBean();

		try
		{
			reportslogger.info("Entered into waiverRequestSearch mapping at reports controller");
			int pageNumber = 1;
			reportslogger.info(" PageNumber in waiverRequestSearch mapping:" + pageNumber);

			session=request.getSession(false);
			String userId=session.getAttribute("userid").toString();
			reportslogger.info("UserId in waiverRequestSearch mapping is:"+userId);
			String role=session.getAttribute("user_role_id").toString();
			reportslogger.info("User Role in transLevelDefault mapping is:"+role);


			String fromDate =request.getParameter("startDateId");
			String toDate=request.getParameter("endDateId");
			String ticketId=request.getParameter("tktNumber");
			String uploaderId=request.getParameter("uploaderId");

			if (fromDate != "") {
				adviceRequestBeanObj2.setFromDate(fromDate);
			}
			else
				adviceRequestBeanObj2.setFromDate(null);

			if(toDate !="")
			{
				adviceRequestBeanObj2.setToDate(toDate);
			}
			else
				adviceRequestBeanObj2.setToDate(null);


			if(ticketId==null||ticketId.equalsIgnoreCase(""))
				adviceRequestBeanObj2.setTicketId(null);
			else
				adviceRequestBeanObj2.setTicketId(ticketId.trim());

			if(uploaderId==null||uploaderId.equalsIgnoreCase(""))
				adviceRequestBeanObj2.setUploadedBy(null);
			else
				adviceRequestBeanObj2.setUploadedBy(uploaderId.trim());


			reportslogger.info("To date from jsp in waiverRequestSearch mapping:"+adviceRequestBeanObj2.getToDate());
			reportslogger.info("From date from jsp in waiverRequestSearch mapping:"+adviceRequestBeanObj2.getFromDate());
			reportslogger.info("Ticket Id from jsp in waiverRequestSearch mapping:"+adviceRequestBeanObj2.getTicketId());
			reportslogger.info("UploaderId from jsp in waiverRequestSearch mapping:"+adviceRequestBeanObj2.getUploadedBy());

			HashMap<Integer, List<PaymentAdviceBean>> adviceHashMap = paymentAdviceDaoObj.waiverSearchRequestLevel(pageNumber,adviceRequestBeanObj2,role,userId);			 

			String errorMsg=adviceRequestBeanObj2.getErrorMsg();
			reportslogger.info("Error Message in waiverRequestSearch mapping:"+errorMsg);

			/*  if(errorMsg.equalsIgnoreCase("SUCCESS"))
				  {
					  errorMsg="";
				  }
				 else 
					 errorMsg="No records Found";*/

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(adviceHashMap==null)
			{
				reportslogger.info("Data Base Issues...Exception in waiverRequestSearch");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("adviceHashMap", adviceHashMap);
				modelAndViewObj.addObject("adviceRequestObjJsp",adviceRequestBeanObj2);
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.setViewName("WaiverRequestTrack");
				return modelAndViewObj;
			}

			modelAndViewObj.addObject("adviceHashMap", adviceHashMap);
			modelAndViewObj.addObject("adviceRequestObjJsp",adviceRequestBeanObj2);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("sessionRole", role);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			modelAndViewObj.setViewName("WaiverRequestTrack");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		reportslogger.info("Executed waiverRequestSearch at reports controller)");	  

		return modelAndViewObj;
	}
	
	@RequestMapping(value = "/adviceRequestSearch")
	public ModelAndView requestLevelSearch(ModelMap model,HttpServletRequest request, HttpServletResponse response)

	{
		ModelAndView modelAndViewObj = new ModelAndView();
		PaymentAdviceBean adviceRequestBeanObj2=new PaymentAdviceBean();

		try
		{
			reportslogger.info("Entered into adviceRequestSearch mapping at reports controller");
			int pageNumber = 1;
			reportslogger.info(" PageNumber in adviceRequestSearch mapping:" + pageNumber);

			session=request.getSession(false);
			String userId=session.getAttribute("userid").toString();
			reportslogger.info("UserId in adviceRequestSearch mapping is:"+userId);
			String role=session.getAttribute("user_role_id").toString();
			reportslogger.info("User Role in transLevelDefault mapping is:"+role);


			String fromDate =request.getParameter("startDateId");
			String toDate=request.getParameter("endDateId");
			String ticketId=request.getParameter("tktNumber");
			String uploaderId=request.getParameter("uploaderId");

			if (fromDate != "") {
				adviceRequestBeanObj2.setFromDate(fromDate);
			}
			else
				adviceRequestBeanObj2.setFromDate(null);

			if(toDate !="")
			{
				adviceRequestBeanObj2.setToDate(toDate);
			}
			else
				adviceRequestBeanObj2.setToDate(null);


			if(ticketId==null||ticketId.equalsIgnoreCase(""))
				adviceRequestBeanObj2.setTicketId(null);
			else
				adviceRequestBeanObj2.setTicketId(ticketId.trim());

			if(uploaderId==null||uploaderId.equalsIgnoreCase(""))
				adviceRequestBeanObj2.setUploadedBy(null);
			else
				adviceRequestBeanObj2.setUploadedBy(uploaderId.trim());


			reportslogger.info("To date from jsp in adviceRequestSearch mapping:"+adviceRequestBeanObj2.getToDate());
			reportslogger.info("From date from jsp in adviceRequestSearch mapping:"+adviceRequestBeanObj2.getFromDate());
			reportslogger.info("Ticket Id from jsp in adviceRequestSearch mapping:"+adviceRequestBeanObj2.getTicketId());
			reportslogger.info("UploaderId from jsp in adviceRequestSearch mapping:"+adviceRequestBeanObj2.getUploadedBy());

			HashMap<Integer, List<PaymentAdviceBean>> adviceHashMap = paymentAdviceDaoObj.adviceSearchRequestLevel(pageNumber,adviceRequestBeanObj2,role,userId);			 

			String errorMsg=adviceRequestBeanObj2.getErrorMsg();
			reportslogger.info("Error Message in adviceRequestSearch mapping:"+errorMsg);

			/*  if(errorMsg.equalsIgnoreCase("SUCCESS"))
				  {
					  errorMsg="";
				  }
				 else 
					 errorMsg="No records Found";*/

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(adviceHashMap==null)
			{
				reportslogger.info("Data Base Issues...Exception in adviceRequestSearch");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("adviceHashMap", adviceHashMap);
				modelAndViewObj.addObject("adviceRequestObjJsp",adviceRequestBeanObj2);
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.setViewName("adviceRequestDefault");
				return modelAndViewObj;
			}

			modelAndViewObj.addObject("adviceHashMap", adviceHashMap);
			modelAndViewObj.addObject("adviceRequestObjJsp",adviceRequestBeanObj2);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("sessionRole", role);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			modelAndViewObj.setViewName("adviceRequestDefault");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		reportslogger.info("Executed adviceRequestSearch at reports controller)");	  

		return modelAndViewObj;
	}



	@RequestMapping(value = "/adviceRequestNextPage")
	public ModelAndView adviceRequestNextPage(HttpServletRequest request,HttpServletResponse response) 
	{
		ModelAndView modelAndViewObj = new ModelAndView();

		PaymentAdviceBean adviceRequestBeanObj3=new PaymentAdviceBean();

		int pageNumber = Integer.parseInt(request.getParameter("pageNumber"));

		reportslogger.info("Entered into adviceRequestNextPage mapping at reports controller");

		reportslogger.info(" PageNumber in adviceRequestNextPage mapping:" + pageNumber);

		try
		{

			session=request.getSession(false);
			String userId=session.getAttribute("userid").toString();
			reportslogger.info("UserId in adviceRequestNextPage mapping is:"+userId);

			String role=session.getAttribute("user_role_id").toString();
			reportslogger.info("User Role in transLevelDefault mapping is:"+role);


			String fromDate =request.getParameter("startDateId");
			String toDate=request.getParameter("endDateId");
			String ticketId=request.getParameter("tktNumber");
			String uploaderId=request.getParameter("uploaderId");

			if (fromDate != "") {
				adviceRequestBeanObj3.setFromDate(fromDate);
			}
			else
				adviceRequestBeanObj3.setFromDate(null);

			if(toDate !="")
			{
				adviceRequestBeanObj3.setToDate(toDate);
			}
			else
				adviceRequestBeanObj3.setToDate(null);


			if(ticketId==null||ticketId.equalsIgnoreCase(""))
				adviceRequestBeanObj3.setTicketId(null);
			else
				adviceRequestBeanObj3.setTicketId(ticketId.trim());

			if(uploaderId==null||uploaderId.equalsIgnoreCase(""))
				adviceRequestBeanObj3.setUploadedBy(null);
			else
				adviceRequestBeanObj3.setUploadedBy(uploaderId.trim());


			reportslogger.info("To date from jsp in adviceRequestSearch mapping:"+adviceRequestBeanObj3.getToDate());
			reportslogger.info("From date from jsp in adviceRequestSearch mapping:"+adviceRequestBeanObj3.getFromDate());
			reportslogger.info("Ticket Id from jsp in adviceRequestSearch mapping:"+adviceRequestBeanObj3.getTicketId());
			reportslogger.info("UploaderId from jsp in adviceRequestSearch mapping:"+adviceRequestBeanObj3.getUploadedBy());

			HashMap<Integer, List<PaymentAdviceBean>> adviceHashMap = paymentAdviceDaoObj.adviceSearchRequestLevel(pageNumber,adviceRequestBeanObj3,role,userId);

			String errorMsg=adviceRequestBeanObj3.getErrorMsg();
			reportslogger.info("Error Message in adviceRequestNextPage mapping:"+errorMsg);

			/*  if(errorMsg.equalsIgnoreCase("SUCCESS"))
			  {
				  errorMsg="";
			  }
			 else 
				 errorMsg="No records Found";*/

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(adviceHashMap==null)
			{
				reportslogger.info("Data Base Issues...Exception in adviceRequestNextPage");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("adviceHashMap", adviceHashMap);
				modelAndViewObj.addObject("adviceRequestObjJsp",adviceRequestBeanObj3);
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.setViewName("adviceRequestDefault");
				return modelAndViewObj;
			}

			modelAndViewObj.addObject("adviceHashMap", adviceHashMap);
			modelAndViewObj.addObject("adviceRequestObjJsp",adviceRequestBeanObj3);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("sessionRole", role);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			modelAndViewObj.setViewName("adviceRequestDefault");

		}
		catch (Exception e) {
			e.printStackTrace();
		}
		reportslogger.info("Executed adviceRequestNextPage at reports controller)");	  

		return modelAndViewObj;
	}


	@RequestMapping(value = "/exportToExcelRequest", method = RequestMethod.POST)
	public ModelAndView exportToExcelRequest(ModelMap model,HttpServletRequest request, HttpServletResponse response) 
	{
		ModelAndView modelAndViewObj = new ModelAndView();

		PaymentAdviceBean adviceRequestBeanObj4=new PaymentAdviceBean();

		try{

			reportslogger.info("Entered into exportToExcelRequest mapping at reports controller");

			String page = null;


			session=request.getSession(false);
			String userId=session.getAttribute("userid").toString();
			reportslogger.info("UserId in exportToExcelRequest mapping is:"+userId);

			String role=session.getAttribute("user_role_id").toString();
			reportslogger.info("User Role in transLevelDefault mapping is:"+role);


			String fromDate =request.getParameter("startDateId");
			String toDate=request.getParameter("endDateId");
			String ticketId=request.getParameter("tktNumber");
			String uploaderId=request.getParameter("uploaderId");

			if (fromDate != "") {
				adviceRequestBeanObj4.setFromDate(fromDate);
			}
			else
				adviceRequestBeanObj4.setFromDate(null);

			if(toDate !="")
			{
				adviceRequestBeanObj4.setToDate(toDate);
			}
			else
				adviceRequestBeanObj4.setToDate(null);


			if(ticketId==null||ticketId.equalsIgnoreCase(""))
				adviceRequestBeanObj4.setTicketId(null);
			else
				adviceRequestBeanObj4.setTicketId(ticketId.trim());

			if(uploaderId==null||uploaderId.equalsIgnoreCase(""))
				adviceRequestBeanObj4.setUploadedBy(null);
			else
				adviceRequestBeanObj4.setUploadedBy(uploaderId.trim());


			reportslogger.info("To date from jsp in adviceRequestSearch mapping:"+adviceRequestBeanObj4.getToDate());
			reportslogger.info("From date from jsp in adviceRequestSearch mapping:"+adviceRequestBeanObj4.getFromDate());
			reportslogger.info("Ticket Id from jsp in adviceRequestSearch mapping:"+adviceRequestBeanObj4.getTicketId());
			reportslogger.info("UploaderId from jsp in adviceRequestSearch mapping:"+adviceRequestBeanObj4.getUploadedBy());

			PaymentAdviceBean adviceRequestFileObj=paymentAdviceDaoObj.downloadedRequestLevelFile(adviceRequestBeanObj4,/* downloadedFilesPath,*/ extension, page,role,userId);	  

			String errorMsg=adviceRequestBeanObj4.getErrorMsg();
			reportslogger.info("Error Message in payment advice exportToExcelRequest mapping:"+errorMsg);
			/* 
					  if(errorMsg.equalsIgnoreCase("SUCCESS"))
					  {
						  errorMsg="";
					  }
					 else 
						 errorMsg="No records Found";*/

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(adviceRequestFileObj==null)
			{
				reportslogger.info("Data Base Issues...Exception in adviceRequestNextPage");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("adviceRequestObjJsp",adviceRequestBeanObj4);
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("sessionRole", role);
				modelAndViewObj.setViewName("adviceRequestDefault");
				return modelAndViewObj;
			}


			/*String filePath=downloadedFilesPath;
					reportslogger.info("Filepath is:"+filePath);*/

			String filename="APS_PAY_ADVICE_REQUEST_LEVEL_"+paymentAdviceDaoObj.getDateTime()+"."+extension;
			reportslogger.info("Filename:"+filename);

			//  String finalPath=/*filePath+"\\"+*/filename;

			ServletOutputStream out = response.getOutputStream();
			FileInputStream in = new FileInputStream(filename);
			reportslogger.info("File name:"+in);

			response.setContentType("APPLICATION/OCTET-STREAM");

			response.addHeader("content-disposition",
					"attachment; filename=" +filename);

			int octet;
			while((octet = in.read()) != -1)
				out.write(octet);

			in.close();
			out.flush();
			out.close();
			response.flushBuffer();
			reportslogger.info("Executed exportToExcelRequest at reports controller)");	  

		}catch (Exception e) {
			e.printStackTrace();
		}
		return modelAndViewObj;
	}

	@RequestMapping(value = "/adviceProcessedFiles", method = RequestMethod.GET)
	public ModelAndView adviceProcessedFiles(HttpServletRequest request,HttpServletResponse response) throws IOException 
	{
		ModelAndView modelAndViewObj = new ModelAndView();

		PaymentAdviceBean adviceRequestBeanObj5=new PaymentAdviceBean();


		try{

			reportslogger.info("ENTERED INTO paymentAdviceDownload EXPORT TO EXCEL METHOD @ CONTROLLER");
			String requestId = request.getParameter("ticketId_Mode").split("\\$")[0];
			String paymentMode = request.getParameter("ticketId_Mode").split("\\$")[1];
			reportslogger.info("requesid payment mode" +requestId+paymentMode);


			session=request.getSession(false);
			String userId=session.getAttribute("userid").toString();
			reportslogger.info("UserId in exportToExcelRequest mapping is:"+userId);

			String role=session.getAttribute("user_role_id").toString();
			reportslogger.info("User Role in transLevelDefault mapping is:"+role);



			ProcessedAdviceFileDetails paymentAdviceFileObj=paymentAdviceDaoObj.downloadProcessedFile(userId,requestId, paymentMode,extension);

			String errorMsg=paymentAdviceFileObj.getDownloadStatus();

			if(errorMsg.equalsIgnoreCase("DATA_FETCHED"))
			{
				errorMsg="";
			}
			else 
				errorMsg="No records Found";



			String filename="APS_PAYMENT_ADVICE_PROCESSED_FILE_"+requestId+"_"+paymentAdviceDaoObj.getDateTime()+"."+extension;
			reportslogger.info("Filename:"+filename);



			//  String finalPath=/*filePath+"\\"+*/filename;

			ServletOutputStream out = response.getOutputStream();
			FileInputStream in = new FileInputStream(filename);
			reportslogger.info("File name:"+in);

			response.setContentType("APPLICATION/OCTET-STREAM");

			response.addHeader("content-disposition",
					"attachment; filename=" +filename);

			int octet;
			while((octet = in.read()) != -1)
				out.write(octet);

			in.close();
			out.flush();
			out.close();
			response.flushBuffer();
			reportslogger.info("Executed PROCESEED FILES exportToExcelRequest at reports controller)");	  

		}catch (Exception e) {
			e.printStackTrace();
		}
		return modelAndViewObj;
	}

	//************************ PAYMENT ADVICE REQUEST LEVEL STATUS TRACKING END***********************

	//************************ PAYMENT ADVICE REQUEST LEVEL STATUS TRACKING ZIP FILE ***********************

	@RequestMapping(value = "/downloadPaymentAdviceFilesRequest", method = RequestMethod.GET)
	public void downloadPaymentAdviceFiles(HttpServletRequest request,
			HttpServletResponse response) throws IOException {

		try{

			reportslogger.info("Entered into downloadPaymentAdviceFilesRequest mapping at reports controller");
			String extension="xls";
			String val=null;
			String orgFileName=null;
			//
			String requestId = request.getParameter("requestId1");
			if(requestId!=null){
				val=requestId.substring(0, 1);
				orgFileName=ReportsDaoObj.getOrignalFileName(requestId);
				if(orgFileName.endsWith(".xls")==true)							
					orgFileName=orgFileName.replace(".xls","");						
				else if(orgFileName.endsWith(".xlsx")==true)
					orgFileName=orgFileName.replace(".xlsx","");
				
		
			}
			
			reportslogger.info("ticket starting with>>"+val +" file name>>"+orgFileName);
			//String paymentMode = request.getParameter("FileId").split("\\$")[1];
			//reportslogger.info("requesid payment mode" +requestId+paymentMode);

			session=request.getSession(false);
			String userId=session.getAttribute("userid").toString();
			reportslogger.info("UserId in downloadPaymentAdviceFilesRequest mapping is:"+userId);

			String role=session.getAttribute("user_role_id").toString();
			reportslogger.info("User Role in transLevelDefault mapping is:"+role);

			// ApprovalDetails paymentAdviceFileObj=approvaldao.downloadPaymentAdviceFile(userId,requestId, paymentMode,extension);	

			//*****create empty zip --->get payment advice file --->get support file ---> add files to zip ---> download zip******	        


			//********************creating empty zip***************************** 
			String zipFile =null;
			if(val.equals("1")){
				zipFile = "Payment_Advice_Files_"+requestId+"."+"zip";
				reportslogger.info("PaymentAdviceHomePath" +paymentAdviceRequestDownloadPath);
			}
			if(val.equals("3")){

				zipFile = "Payment_Transfer_Files_"+requestId+"."+"zip";					
			}
			if(val.equals("4")){
				zipFile = "Suspense_Allocation_Files_"+requestId+"."+"zip";
			}
			if(val.equals("2")){
				zipFile = "AES_ChequeWorkflow_Files_"+requestId+"."+"zip";
			}
			if(val.equals("5")){
				zipFile = "TDS_Files_"+requestId+"."+"zip";
			}
			if(val.equals("8")){
				zipFile = "Waiver_Files_"+requestId+"."+"zip";
			}
				//    String zipFile = "Payment_Advice_Files_"+requestId+"."+"zip";
				ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(zipFile));
				zip.putNextEntry(new ZipEntry(zipFile));
				zip.closeEntry();
				zip.flush();
				zip.close();
				reportslogger.info("Successfully generated an empty zip file");
				//*********************creating empty zip completed******************** 


			//********************get payment advice file************************	
			
			//String filename=paymentAdviceHomePath+ File.separator+"UploadedFiles"+File.separator+"InputFiles"+File.separator+"Payment_Advice_"+requestId+"."+extension;
			//filename="C:/Users/1004362/Desktop/A/"+"Payment_Advice_"+requestId+"."+extension;
			//						       /reportslogger.info("Filename:"+filename);	


			//block 2
			String paymentAdviceFileName="";
			//File supportFilesFolder = new File("C:/Users/1004362/Desktop/A");

			File paymentAdviceFilesFolder =null;
			if(val.equals("1")){
				paymentAdviceFilesFolder = new File(paymentAdviceRequestDownloadPath+ File.separator+"UploadedFiles"+File.separator+"InputFiles"+File.separator);			
			}
			if(val.equals("3")){

				paymentAdviceFilesFolder = new File(paymentTransferFile+File.separator+"InputFiles"+File.separator);
			}
			if(val.equals("4")){
				paymentAdviceFilesFolder = new File(suspenseFile+File.separator+"InputFiles"+File.separator);
			}
			
			if(val.equals("2")){
				paymentAdviceFilesFolder = new File(aesChequeWorkflowFile+File.separator+"InputFiles"+File.separator);
			}
			if(val.equals("5")){
				paymentAdviceFilesFolder = new File(TDS_File+File.separator+"InputFiles"+File.separator);
			}
			if(val.equals("8")){
				paymentAdviceFilesFolder = new File(uploadWavierFiles+File.separator);
			}
			
				reportslogger.info("paymentAdviceFilesFolder==>" +paymentAdviceFilesFolder);

			//File paymentAdviceFilesFolder = new File(paymentAdviceRequestDownloadPath+ File.separator+"UploadedFiles"+File.separator+"InputFiles"+File.separator);
			File[] listOfpaymentAdviceFiles = paymentAdviceFilesFolder.listFiles();
			reportslogger.info("listOfpaymentAdviceFiles==>" +listOfpaymentAdviceFiles);
			
			if(listOfpaymentAdviceFiles!=null){
			for (int i = 0; i < listOfpaymentAdviceFiles.length; i++) {
				if (listOfpaymentAdviceFiles[i].isFile()) {
					reportslogger.info("PaymentAdvice file FOUND");
					
					if(val.equals("1")){
						paymentAdviceFileName = "Payment_Advice_Upload_File_"+ requestId;
					}
					if(val.equals("3")){
		                 paymentAdviceFileName =orgFileName+"_"+requestId;
						
					}
					if(val.equals("4")){
						paymentAdviceFileName = requestId+"_"+orgFileName;                     
					}
					
					if(val.equals("2")){
						paymentAdviceFileName = orgFileName+"_"+requestId;
					}
					if(val.equals("5")){
						paymentAdviceFileName = orgFileName+"_"+requestId;
					}
					if(val.equals("8")){
						paymentAdviceFileName = orgFileName+"_"+requestId;
					}
					reportslogger.info("paymentAdviceFileName==>"+paymentAdviceFileName);
					//paymentAdviceFileName = "Payment_Advice_Upload_File_"+ requestId;
					if (listOfpaymentAdviceFiles[i].getName().contains(paymentAdviceFileName)) {
						reportslogger.info("Contains Payment_Advice_Upload_File_ in name");
						reportslogger.info("payment advice File"+ listOfpaymentAdviceFiles[i].getName());
						
						if(val.equals("1")){
							paymentAdviceFileName = paymentAdviceRequestDownloadPath+ File.separator+"UploadedFiles"+File.separator+"InputFiles"+File.separator+listOfpaymentAdviceFiles[i].getName();
						}
						if(val.equals("3")){

							paymentAdviceFileName = paymentTransferFile+File.separator+"InputFiles"+File.separator+listOfpaymentAdviceFiles[i].getName();					
						}
						if(val.equals("4")){
							paymentAdviceFileName = suspenseFile+File.separator+"InputFiles"+File.separator+listOfpaymentAdviceFiles[i].getName();
						}
						
						if(val.equals("2")){
							paymentAdviceFileName = aesChequeWorkflowFile+File.separator+"InputFiles"+File.separator+listOfpaymentAdviceFiles[i].getName();
						}
						if(val.equals("5")){
							paymentAdviceFileName = TDS_File+File.separator+"InputFiles"+File.separator+listOfpaymentAdviceFiles[i].getName();
						}
						if(val.equals("8")){
							paymentAdviceFileName = uploadWavierFiles+File.separator+listOfpaymentAdviceFiles[i].getName();
						}
						
					//	paymentAdviceFileName = paymentAdviceRequestDownloadPath+ File.separator+"UploadedFiles"+File.separator+"InputFiles"+File.separator+listOfpaymentAdviceFiles[i].getName();
						// supportFileName="C:/Users/1004362/Desktop/A/"+listOfSupportFiles[i].getName();
						reportslogger.info("support file after mentioning path is"+ paymentAdviceFileName);
						break;
					} else {
						reportslogger.info("file NOT found");
						paymentAdviceFileName ="FILE_NOT_FOUND";
					}
				}
			}
		}



			//********************get payment advice file completed*******************	


			//******************get support file************************       
			String supportFileName="";
			//File supportFilesFolder = new File("C:/Users/1004362/Desktop/A");
			File supportFilesFolder =null;
			if(val.equals("1")){
				supportFilesFolder = new File(paymentAdviceRequestDownloadPath+File.separator+"UploadedFiles"+File.separator+"SupportFiles"+File.separator);
			}
			if(val.equals("3")){

				supportFilesFolder = new File(paymentTransferFile+File.separator+"SupportFiles"+File.separator);
			}
			if(val.equals("4")){
				supportFilesFolder = new File(suspenseFile+File.separator+"SupportFiles"+File.separator);
			}
			
			if(val.equals("2")){
				supportFilesFolder =  new File(aesChequeWorkflowFile+File.separator+"SupportFiles"+File.separator);
			}
			if(val.equals("5")){
				supportFilesFolder =  new File(TDS_File+File.separator+"SupportFiles"+File.separator);
			}
			if(val.equals("8")){
				supportFilesFolder =  new File(uploadSupportFiles+File.separator);
			}
			//File supportFilesFolder = new File(paymentAdviceRequestDownloadPath+File.separator+"UploadedFiles"+File.separator+"SupportFiles"+File.separator);
			File[] listOfSupportFiles = supportFilesFolder.listFiles();

			for (int i = 0; i < listOfSupportFiles.length; i++) {
				if (listOfSupportFiles[i].isFile()) {
					reportslogger.info("SUPPORT file FOUND");
					
					
					if(val.equals("1")){
						supportFileName = "Payment_Advice_Support_File_"+ requestId;
					}
					if(val.equals("3")){

						supportFileName = "Payment_Transfer_Support_File_"+ requestId;					
					}
					if(val.equals("4")){
						supportFileName = "Suspense_Support_File_"+ requestId;
					}
					if(val.equals("2")){
						supportFileName = "AES_Cheque_WorkFlow_Support_File_"+ requestId;
					}
					if(val.equals("5")){
						supportFileName = "TDS_Support_File_"+ requestId;
					}
					if(val.equals("8")){
						supportFileName =requestId+ "_Waiver_Support_File";
					}
					
				//	supportFileName = "Payment_Advice_Support_File_"+ requestId;
					
					//Payment_Transfer_Support_File_
					//Suspense_Support_File_
					if (listOfSupportFiles[i].getName().contains(supportFileName)) {
						reportslogger.info("contains Payment_Advice_Support_File_ in name");
						reportslogger.info("support File"+ listOfSupportFiles[i].getName());
						
						
						if(val.equals("1")){
							supportFileName = paymentAdviceRequestDownloadPath+ File.separator+"UploadedFiles"+File.separator+"SupportFiles"+File.separator+listOfSupportFiles[i].getName();
						}
						if(val.equals("3")){

							supportFileName = paymentTransferFile+File.separator+"SupportFiles"+File.separator+listOfSupportFiles[i].getName();					
						}
						if(val.equals("4")){
							supportFileName = suspenseFile+File.separator+"SupportFiles"+File.separator+listOfSupportFiles[i].getName();
						}
						
						if(val.equals("2")){
							supportFileName = aesChequeWorkflowFile+File.separator+"SupportFiles"+File.separator+listOfSupportFiles[i].getName();
						}
						if(val.equals("5")){
							supportFileName = TDS_File+File.separator+"SupportFiles"+File.separator+listOfSupportFiles[i].getName();
						}
						if(val.equals("8")){
							supportFileName = uploadSupportFiles+File.separator+listOfSupportFiles[i].getName();
						}
						
						//supportFileName = paymentAdviceRequestDownloadPath+ File.separator+"UploadedFiles"+File.separator+"SupportFiles"+File.separator+listOfSupportFiles[i].getName();
						
						// supportFileName="C:/Users/1004362/Desktop/A/"+listOfSupportFiles[i].getName();
						reportslogger.info("support file after mentioning path is"+ supportFileName);
						break;
					} else {
						reportslogger.info("file NOT found");
						supportFileName ="FILE_NOT_FOUND";
					}
				}
			}
			//**********************get support file completed******************************


			reportslogger.info("Final payment advice file name is......" +paymentAdviceFileName);
			reportslogger.info("Final support file name is............." +supportFileName);


			//****************************adding files to zip********************************		
			List<String> srcFiles = new ArrayList<String>();
			srcFiles.add(paymentAdviceFileName);
			if (supportFileName!=null && supportFileName!="" 
					&& !"FILE_NOT_FOUND".equalsIgnoreCase(supportFileName)) {
				srcFiles.add(supportFileName);
			}
			reportslogger.info("src files size is" +srcFiles.size());
			byte[] buffer = new byte[10240];
			FileOutputStream fos = new FileOutputStream(zipFile);
			ZipOutputStream zos = new ZipOutputStream(fos);
			try {
				for (int i = 0; i < srcFiles.size(); i++) {
					File srcFile = new File(srcFiles.get(i));
					FileInputStream fis = new FileInputStream(srcFile);
					zos.putNextEntry(new ZipEntry(srcFile.getName()));
					int length;
					while ((length = fis.read(buffer)) > 0) {
						zos.write(buffer, 0, length);
					}
					zos.closeEntry();
					fis.close();
					reportslogger.info("Successfully zipped the file");
				}
				zos.close();
			} catch (IOException ioe) {
				reportslogger.info("Error creating zip file: " + ioe);
			}
			//********************************adding files to zip completed*******************************

			//********************************download zip************************************************			
			ServletOutputStream out = response.getOutputStream();
			FileInputStream in = new FileInputStream(zipFile);
			reportslogger.info("zip Input File name:" + in);
			response.setContentType("APPLICATION/OCTET-STREAM");
			response.addHeader("content-disposition", "attachment; filename="+ zipFile);
			reportslogger.info("PROCESS COMPLETED AND FETCHED THE FILE @ CONTROLLER");
			int octet = 0;
			while ((octet = in.read()) != -1)
				out.write(octet);
			in.close();
			out.flush();
			out.close();
			response.flushBuffer();
			reportslogger.info("finished execution of payment Advice download");

		} catch (Exception e) {
			e.printStackTrace();
		}
		//********************************download zip completed*********************************	

	}
	//download....//	   
	//************************ PAYMENT ADVICE REQUEST LEVEL STATUS TRACKING ZIP FILE END ***********************

	/***************************************** User Management Vendor Report ******************************************/

	/*@RequestMapping(value = "/UserManagementVendor")
	public ModelAndView UserManagementVendor() {
		reportslogger.info("In User Management Vendor Report Controller)");
		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("VendorReportLogin");
		return modelAndViewObj;
	}
	 */
	@RequestMapping(value = "/getUserManagementVendorRole", method = RequestMethod.GET)
	public ModelAndView getUserManagementVendorRole(HttpServletRequest request,HttpServletResponse response)
	{
		session=request.getSession(false);
		VendorUserReportBean VendorUserReportBeanObj=new VendorUserReportBean();
		reportslogger.info("In User Management Vendor Report Controller)");
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in getUserManagementVendorRole mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		ModelAndView modelAndViewObj = new ModelAndView();

		//String parentUserId = request.getParameter("UserId");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User Id:" + parentUserId);
		// Role = ReportsDaoObj.getRole(parentUserId);
		/* if(Role==-1)
			{
				modelAndViewObj.addObject("errMsg", "Data Base Issues");
				modelAndViewObj.setViewName("VendorReportSearch");
				return modelAndViewObj;
			}*/

		reportslogger.info("User Role:" + Role);

		if ((Role == 7)) {

			VendorUserReportBeanObj.setParentUserId(parentUserId);
			VendorUserReportBeanObj.setVendorName(null);
			VendorUserReportBeanObj.setVendorId(null);
			//VendorUserReportBeanObj.setStatus("SELECT ONE");
			VendorUserReportBeanObj.setStatus(null);
			// call method from dao and get records based on parentuserId only.
			int page = 1;
			String errMsg = null;
			List<String> statusList = ReportsDaoObj.returnStatusList();
			if(statusList==null){
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("UserRole", Role);
				modelAndViewObj.setViewName("VendorReportSearch");
				return modelAndViewObj;
			}

			reportslogger.info("Status List Size in Controller: "+statusList.size());
			modelAndViewObj.addObject("statusList",statusList);

			HashMap<Integer, List<VendorUserReportBean>> ReportsMap = new HashMap<Integer, List<VendorUserReportBean>>();

			ReportsMap = ReportsDaoObj.getVendorReportMap(
					VendorUserReportBeanObj, page);
			if(ReportsMap==null){
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("UserRole", Role);
				modelAndViewObj.setViewName("VendorReportSearch");
				return modelAndViewObj;
			}
			reportslogger.info("Details map Size in Controller: "+ReportsMap.size());



			if(VendorUserReportBeanObj.getErrorMsg()!=null)
			{

				if(VendorUserReportBeanObj.getErrorMsg().equalsIgnoreCase("DATA FETCHED"))
				{
					errMsg="";
				}

				else
				{
					errMsg=VendorUserReportBeanObj.getErrorMsg();
				}

			}
			else
				errMsg="Connectivity Issues..Retry..";






			modelAndViewObj.addObject("ReportsMap", ReportsMap);

			modelAndViewObj.addObject("errMsg", errMsg);
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.addObject("UserRole", Role);

			modelAndViewObj.setViewName("VendorReportSearch");
		}

		else {
			modelAndViewObj.addObject("error",
					"You do not have privilige to check the reports !!");
			modelAndViewObj.setViewName("VendorReportSearch");
			return modelAndViewObj;
		}

		return modelAndViewObj;
	}

	@RequestMapping(value = "/getVendorReportWithFilter")
	public ModelAndView getVendorReportWithFilter(HttpServletRequest request,HttpServletResponse response) 
	{
		session=request.getSession(false);
		reportslogger.info("In User Management Vendor Report Search");
		ModelAndView modelAndViewObj = new ModelAndView();
		VendorUserReportBean VendorUserReportBeanObjSearch=new VendorUserReportBean();
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		VendorUserReportBeanObjSearch.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in getVendorReportWithFilter mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);

		/* if(Role==-1)
			{
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("VendorReportSearch");
				return modelAndViewObj;
			}*/

		String vendorId = request.getParameter("vendorId");
		reportslogger.info("Vendor ID: "+vendorId);
		String vendorName = request.getParameter("vendorName");
		reportslogger.info("Vendor Name: "+vendorName);
		String status = request.getParameter("status");
		reportslogger.info("Status: "+status);

		if (vendorId == null || vendorId.equals("")) {
			VendorUserReportBeanObjSearch.setVendorId(null);

		} else
			VendorUserReportBeanObjSearch.setVendorId(vendorId.trim());
		if (vendorName == null || vendorName.equals("")) {
			VendorUserReportBeanObjSearch.setVendorName(null);

		} else
			VendorUserReportBeanObjSearch.setVendorName(vendorName.trim());
		if (status == null || status.equals("")) {
			VendorUserReportBeanObjSearch.setStatus(null);

		} else
			VendorUserReportBeanObjSearch.setStatus(status);
		HashMap<Integer, List<VendorUserReportBean>> ReportsMap = new HashMap<Integer, List<VendorUserReportBean>>();
		int page = 1;
		String errMsg = null;

		List<String> statusList = ReportsDaoObj.returnStatusList();
		if(statusList==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("VendorReportSearch");
			return modelAndViewObj;
		}

		reportslogger.info("Status List Size in Controller: "+statusList.size());
		modelAndViewObj.addObject("statusList",statusList);

		ReportsMap = ReportsDaoObj.getVendorReportMap(VendorUserReportBeanObjSearch,
				page);
		if(ReportsMap==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("VendorReportSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Details map Size based on Search Criteria in Controller: "+ReportsMap.size());

		//reportslogger.info("method called in controller");
		if(VendorUserReportBeanObjSearch.getErrorMsg()!=null)
		{

			if(VendorUserReportBeanObjSearch.getErrorMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				errMsg="";
			}

			else
			{
				errMsg=VendorUserReportBeanObjSearch.getErrorMsg();
			}

		}
		else
			errMsg="Connectivity Issues..Retry..";

		modelAndViewObj.addObject("errMsg", errMsg);

		modelAndViewObj.addObject("ReportsMap", ReportsMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("UserRole", Role);
		modelAndViewObj.addObject("VendorUserReportBeanObjJsp",
				VendorUserReportBeanObjSearch);
		modelAndViewObj.setViewName("VendorReportSearch");
		//reportslogger.info("end of search controller");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/getVendorReportWithPagination")
	public ModelAndView getVendorReportWithPagination(HttpServletRequest request, HttpServletResponse response) 
	{
		session=request.getSession(false);
		reportslogger.info("In User Management Vendor Report Pagination");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		VendorUserReportBean VendorUserReportBeanObjPag=new VendorUserReportBean();
		VendorUserReportBeanObjPag.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in getVendorReportWithPagination mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);
		String vendorId = request.getParameter("vendorId");
		reportslogger.info("Vendor ID: "+vendorId);
		String vendorName = request.getParameter("vendorName");
		reportslogger.info("Vendor Name: "+vendorName);
		String status = request.getParameter("status");
		reportslogger.info("Status: "+status);

		if (vendorId == null || vendorId.equals("")) {
			VendorUserReportBeanObjPag.setVendorId(null);

		} else
			VendorUserReportBeanObjPag.setVendorId(vendorId.trim());
		if (vendorName == null || vendorName.equals("")) {
			VendorUserReportBeanObjPag.setVendorName(null);

		} else
			VendorUserReportBeanObjPag.setVendorName(vendorName.trim());
		if (status == null || status.equals("")) {
			VendorUserReportBeanObjPag.setStatus(null);

		} else
			VendorUserReportBeanObjPag.setStatus(status);



		HashMap<Integer, List<VendorUserReportBean>> ReportsMap = new HashMap<Integer, List<VendorUserReportBean>>();
		int page = Integer.parseInt(request.getParameter("pageNum"));
		reportslogger.info("Page No :"+page);
		String errMsg = null;
		ModelAndView modelAndViewObj = new ModelAndView();
		List<String> statusList = ReportsDaoObj.returnStatusList();
		if(statusList==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("VendorReportSearch");
			return modelAndViewObj;
		}

		reportslogger.info("Status List Size in Controller: "+statusList.size());
		modelAndViewObj.addObject("statusList",statusList);

		ReportsMap = ReportsDaoObj.getVendorReportMap(VendorUserReportBeanObjPag,
				page);
		if(ReportsMap==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("VendorReportSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Details map Size based on Page No in Controller: "+ReportsMap.size());


		//reportslogger.info("pagtn called in controller");

		if(VendorUserReportBeanObjPag.getErrorMsg()!=null)
		{

			if(VendorUserReportBeanObjPag.getErrorMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				errMsg="";
			}

			else
			{
				errMsg=VendorUserReportBeanObjPag.getErrorMsg();
			}

		}
		else
			errMsg="Connectivity Issues..Retry..";
		modelAndViewObj.addObject("errMsg", errMsg);

		modelAndViewObj.addObject("ReportsMap", ReportsMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("UserRole", Role);
		modelAndViewObj.addObject("VendorUserReportBeanObjJsp",
				VendorUserReportBeanObjPag);
		modelAndViewObj.setViewName("VendorReportSearch");
		//reportslogger.info("end of pagination");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/UserManagementVendorToExcel", method = RequestMethod.POST)
	public ModelAndView UserManagementVendorToExcel(HttpServletRequest request,HttpServletResponse response)
	{
		ModelAndView modelAndViewObj = new ModelAndView();
		session=request.getSession(false);
		reportslogger.info("In User Management Vendor Report Excel Download ");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		VendorUserReportBean VendorUserReportBeanObjExcel=new VendorUserReportBean();
		VendorUserReportBeanObjExcel.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in UserManagementVendorToExcel mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);
		String vendorId = request.getParameter("vendorId");
		reportslogger.info("Vendor ID: "+vendorId);
		String vendorName = request.getParameter("vendorName");
		reportslogger.info("Vendor Name: "+vendorName);
		String status = request.getParameter("status");
		reportslogger.info("Status: "+status);

		if (vendorId == null || vendorId.equals("")) {
			VendorUserReportBeanObjExcel.setVendorId(null);

		} else
			VendorUserReportBeanObjExcel.setVendorId(vendorId.trim());
		if (vendorName == null || vendorName.equals("")) {
			VendorUserReportBeanObjExcel.setVendorName(null);

		} else
			VendorUserReportBeanObjExcel.setVendorName(vendorName.trim());
		if (status == null || status.equals("")) {
			VendorUserReportBeanObjExcel.setStatus(null);

		} else
			VendorUserReportBeanObjExcel.setStatus(status);


		String pageNum = null;

		List<VendorUserReportBean> VendorsExcelList = new ArrayList<VendorUserReportBean>();

		VendorsExcelList = ReportsDaoObj.getVendorsExcelList(
				VendorUserReportBeanObjExcel, pageNum);

		if(VendorsExcelList==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("VendorReportSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Export details List Size in Controller: "+VendorsExcelList.size());

		int rowNumber = 1;
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("UserManagement_Vendor_Level");
		XSSFCell cell = null;
		XSSFRow row;
		XSSFCellStyle my_style = wb.createCellStyle();
		XSSFFont my_font=wb.createFont();
		my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		my_style.setFont(my_font);

		XSSFCellStyle rightAligned = wb.createCellStyle();
		rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);

		row = sheet.createRow(0);
		cell = row.createCell(0);
		cell.setCellValue("Vendor ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(1);
		cell.setCellValue("Vendor Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(2);
		cell.setCellValue("Vendor SPOC Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(3);
		cell.setCellValue("Vendor SPOC Email");
		cell.setCellStyle(my_style);
		cell = row.createCell(4);
		cell.setCellValue("Vendor SPOC Contact Number");
		cell.setCellStyle(my_style);
		cell = row.createCell(5);
		cell.setCellValue("Vendor Address Line 1");
		cell.setCellStyle(my_style);
		cell = row.createCell(6);
		cell.setCellValue("Vendor Address Line 2");
		cell.setCellStyle(my_style);
		cell = row.createCell(7);
		cell.setCellValue("Vendor City");
		cell.setCellStyle(my_style);
		cell = row.createCell(8);
		cell.setCellValue("Vendor State");
		cell.setCellStyle(my_style);
		cell = row.createCell(9);
		cell.setCellValue("PIN");
		cell.setCellStyle(my_style);
		cell = row.createCell(10);
		cell.setCellValue("LOBs");
		cell.setCellStyle(my_style);
		cell = row.createCell(11);
		cell.setCellValue("Payment Modes");
		cell.setCellStyle(my_style);
		cell = row.createCell(12);
		cell.setCellValue("Active Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(13);
		cell.setCellValue("Inactive date");
		cell.setCellStyle(my_style);
		cell = row.createCell(14);
		cell.setCellValue("Status");
		cell.setCellStyle(my_style);
		for (int i = 0; i < VendorsExcelList.size(); i++) {
			// reportslogger.info("i value"+i);
			VendorUserReportBean VendorUserReportBeanObj = VendorsExcelList
					.get(i);

			row = sheet.createRow(rowNumber);
			cell = row.createCell(0);
			cell.setCellValue(VendorUserReportBeanObj.getVendorId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(0);

			cell = row.createCell(1);
			cell.setCellValue(VendorUserReportBeanObj.getVendorName());
			//sheet.autoSizeColumn(1);
			cell = row.createCell(2);
			cell.setCellValue(VendorUserReportBeanObj.getVendorSpocName());
			//sheet.autoSizeColumn(2);

			cell = row.createCell(3);
			cell.setCellValue(VendorUserReportBeanObj.getVendorSpocEmail());
			//sheet.autoSizeColumn(3);
			cell = row.createCell(4);
			cell.setCellValue(VendorUserReportBeanObj
					.getVendorSpocContactNumber());
			//sheet.autoSizeColumn(4);

			cell = row.createCell(5);
			cell.setCellValue(VendorUserReportBeanObj.getVendorAddressline1());
			//sheet.autoSizeColumn(5);
			cell = row.createCell(6);
			cell.setCellValue(VendorUserReportBeanObj.getVendorAddressLine2());
			//sheet.autoSizeColumn(6);
			cell = row.createCell(7);
			cell.setCellValue(VendorUserReportBeanObj.getVendorCity());
			//sheet.autoSizeColumn(7);

			cell = row.createCell(8);
			cell.setCellValue(VendorUserReportBeanObj.getVendorState());
			//sheet.autoSizeColumn(8);
			cell = row.createCell(9);
			cell.setCellValue(VendorUserReportBeanObj.getPin());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(9);
			cell = row.createCell(10);
			cell.setCellValue(VendorUserReportBeanObj.getLobs());
			//sheet.autoSizeColumn(10);
			cell = row.createCell(11);
			cell.setCellValue(VendorUserReportBeanObj.getPaymentModes());
			//sheet.autoSizeColumn(11);
			cell = row.createCell(12);
			cell.setCellValue(VendorUserReportBeanObj.getActiveDate());
			//sheet.autoSizeColumn(12);
			cell = row.createCell(13);
			cell.setCellValue(VendorUserReportBeanObj.getInActiveDate());
			//sheet.autoSizeColumn(13);
			cell = row.createCell(14);
			cell.setCellValue(VendorUserReportBeanObj.getStatus());
			////sheet.autoSizeColumn(14);
			rowNumber++;

		}
		for(int i=0;i<=14;i++){
			sheet.autoSizeColumn(i);			
		}
		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		byte[] outArray = outByteStream.toByteArray();

		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
				.format(new Date());

		String fileName = "APS_UserManagement_Vendor_Level" + "_" + date + ".xlsx";
		reportslogger.info("filename is" + fileName);

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}

		reportslogger.info("End of User Management Vendor Report Excel records download ");

		return modelAndViewObj;

	}

	/***************************************** User Management Vendor Ends ******************************************/

	/************************************** USER MANAGEMENT -USER LEVEL ********************************************/
	/*@RequestMapping(value = "/userManagementUserLevel")
	public ModelAndView userManagementUserLevel() {

		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("userManagementUserLevelLogin");
		return modelAndViewObj;
	}*/

	@RequestMapping(value = "/getParentRoleUserMgmtUserLevel", method = RequestMethod.GET)
	public ModelAndView getParentRoleUserMgmtUserLevel(HttpServletRequest request, HttpServletResponse response)
	{
		session=request.getSession(false);

		reportslogger.info("In User Management User Report Controller");
		UserManagementUserLevel UserManagementUserLevelObj=new UserManagementUserLevel();

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in getParentRoleUserMgmtUserLevel mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);

		//reportslogger.info("in controller to get  role.");
		ModelAndView modelAndViewObj = new ModelAndView();

		//String parentUserId = request.getParameter("UserId");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login USer ID: " +parentUserId);
		/*Role = ReportsDaoObj.getRole(parentUserId);
		if(Role==-1)
		{
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.setViewName("userManagementUserLevelSearch");
			return modelAndViewObj;
		}*/

		reportslogger.info("User Role:" + Role);


		if ((Role == 7))

		{

			UserManagementUserLevelObj.setParentUserId(parentUserId);
			UserManagementUserLevelObj.setStatus(null);

			UserManagementUserLevelObj.setRoleDesc(null);

			UserManagementUserLevelObj.setChildUserName(null);

			UserManagementUserLevelObj.setChildOlmId(null);

			// call method from dao and get records based on parentuserId only.
			int page = 1;
			String errMsg = null;
			List<String> statusList = ReportsDaoObj.returnStatusList();
			if(statusList==null){
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("UserRole", Role);
				modelAndViewObj.setViewName("userManagementUserLevelSearch");
				return modelAndViewObj;
			}
			reportslogger.info("status list size in controller: "+statusList.size());


			List<String> roleDescList = ReportsDaoObj.returnRoleDescList();
			if(roleDescList==null){
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("UserRole", Role);
				modelAndViewObj.setViewName("userManagementUserLevelSearch");
				return modelAndViewObj;
			}
			reportslogger.info("Role desc List Size in Controller: "+roleDescList.size());
			modelAndViewObj.addObject("statusList", statusList);
			modelAndViewObj.addObject("roleDescList", roleDescList);


			HashMap<Integer, List<UserManagementUserLevel>> ReportsMap = new HashMap<Integer, List<UserManagementUserLevel>>();

			ReportsMap = ReportsDaoObj.getUserMgmtUserLevelMap(
					UserManagementUserLevelObj, page);
			if(ReportsMap==null){
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("UserRole", Role);
				modelAndViewObj.setViewName("userManagementUserLevelSearch");
				return modelAndViewObj;
			}
			reportslogger.info("Details list size in Controller: " + ReportsMap.size() );

			if(UserManagementUserLevelObj.getStatusMsg()!=null)
			{

				if(UserManagementUserLevelObj.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
				{
					errMsg="";
				}

				else
				{
					errMsg=UserManagementUserLevelObj.getStatusMsg();
				}

			}
			else
				errMsg="Connectivity Issues..Retry..";



			modelAndViewObj.addObject("ReportsMap", ReportsMap);



			modelAndViewObj.addObject("errMsg", errMsg);
			modelAndViewObj.addObject("UserManagementUserLevelObjJsp",
					UserManagementUserLevelObj);
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.addObject("currentPage", page);

			modelAndViewObj.setViewName("userManagementUserLevelSearch");
		}

		else {
			modelAndViewObj.addObject("error",
					"You do not have privilige to check the reports !!");
			modelAndViewObj.setViewName("userManagementUserLevelSearch");
			return modelAndViewObj;
		}

		return modelAndViewObj;
	}

	@RequestMapping(value = "/getUserMgmtUserLvlRecordsOnSearch")
	public ModelAndView getUserMgmtUserLvlRecordsOnSearch(HttpServletRequest request, HttpServletResponse response) 
	{
		session=request.getSession(false);
		reportslogger.info("In User Management User Report Search");
		UserManagementUserLevel UserManagementUserLevelObjSearch=new UserManagementUserLevel();
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		UserManagementUserLevelObjSearch.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in getUserMgmtUserLvlRecordsOnSearch mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		ModelAndView modelAndViewObj = new ModelAndView();
		/*if(Role==-1)
		{
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.setViewName("userManagementUserLevelSearch");
			return modelAndViewObj;
		}*/
		String status = request.getParameter("status");
		reportslogger.info("status: " + status );

		String roleDesc = request.getParameter("roleDesc");
		reportslogger.info("Role Description: " + roleDesc );
		String childOLMId = request.getParameter("childOLMId");
		reportslogger.info("User ID: " + childOLMId );
		String childUserName = request.getParameter("userName");
		reportslogger.info("user name"+childUserName);

		if (roleDesc != null) {
			UserManagementUserLevelObjSearch.setRoleDesc(roleDesc);;
		} else {
			UserManagementUserLevelObjSearch.setRoleDesc(null);
		}

		if (status != null) {
			UserManagementUserLevelObjSearch.setStatus(status);
		} else {
			UserManagementUserLevelObjSearch.setStatus(null);
		}

		if (childUserName == null || childUserName.equals("")) {
			UserManagementUserLevelObjSearch.setChildUserName("");
		} else
			UserManagementUserLevelObjSearch.setChildUserName(childUserName.trim());

		if (childOLMId == null || childOLMId.equals("")) {
			UserManagementUserLevelObjSearch.setChildOlmId("");
		} else
			UserManagementUserLevelObjSearch.setChildOlmId(childOLMId.trim());
		//reportslogger.info("User name after Trim:"+UserManagementUserLevelObj.getChildUserName());


		/*	reportslogger.info("status:" + UserManagementUserLevelObj.getStatus());
		reportslogger.info("childUserName:"
				+ UserManagementUserLevelObj.getChildUserName());
		reportslogger.info("roleDesc:"
				+ UserManagementUserLevelObj.getRoleDesc());
		reportslogger.info("childOLMId:"
				+ UserManagementUserLevelObj.getChildOlmId());*/

		HashMap<Integer, List<UserManagementUserLevel>> ReportsMap = new HashMap<Integer, List<UserManagementUserLevel>>();
		int page = 1;
		String errMsg = null;

		List<String> statusList = ReportsDaoObj.returnStatusList();
		if(statusList==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("userManagementUserLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("status list size in controller: "+statusList.size());


		List<String> roleDescList = ReportsDaoObj.returnRoleDescList();
		if(roleDescList==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("userManagementUserLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Role desc List Size in Controller: "+roleDescList.size());
		modelAndViewObj.addObject("statusList", statusList);
		modelAndViewObj.addObject("roleDescList", roleDescList);


		ReportsMap = ReportsDaoObj.getUserMgmtUserLevelMap(
				UserManagementUserLevelObjSearch, page);
		if(ReportsMap==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("userManagementUserLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Details list size Based On Search Criteria in Controller: "+ReportsMap.size());

		/*reportslogger.info("method called in controller");

		reportslogger.info("status msg in controller:"
				+ UserManagementUserLevelObj.getStatusMsg());*/

		if(UserManagementUserLevelObjSearch.getStatusMsg()!=null)
		{

			if(UserManagementUserLevelObjSearch.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				errMsg="";
			}

			else
			{
				errMsg=UserManagementUserLevelObjSearch.getStatusMsg();
			}

		}
		else
			errMsg="Connectivity Issues..Retry..";


		modelAndViewObj.addObject("errMsg", errMsg);
		modelAndViewObj.addObject("ReportsMap", ReportsMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("UserRole", Role);
		modelAndViewObj.addObject("UserManagementUserLevelObjJsp",
				UserManagementUserLevelObjSearch);
		modelAndViewObj.setViewName("userManagementUserLevelSearch");
		//reportslogger.info("end of search controller");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/viewuserMgmtUserLvlRecordswithPagination")
	public ModelAndView viewuserMgmtUserLvlRecordswithPagination(
			HttpServletRequest request, HttpServletResponse response) {
		session=request.getSession(false);
		reportslogger.info("In User Management User Report Pagination");

		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		UserManagementUserLevel UserManagementUserLevelObjPag=new UserManagementUserLevel();
		UserManagementUserLevelObjPag.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in PaymentTransferTransRole mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);
		String status = request.getParameter("status");
		reportslogger.info("status: " + status );

		String roleDesc = request.getParameter("roleDesc");
		reportslogger.info("Role Description: " + roleDesc );
		String childOLMId = request.getParameter("childOLMId");
		reportslogger.info("User ID: " + childOLMId );
		String childUserName = request.getParameter("userName");
		reportslogger.info("user name"+childUserName);

		if (roleDesc != null) {
			UserManagementUserLevelObjPag.setRoleDesc(roleDesc);;
		} else {
			UserManagementUserLevelObjPag.setRoleDesc(null);
		}

		if (status != null) {
			UserManagementUserLevelObjPag.setStatus(status);
		} else {
			UserManagementUserLevelObjPag.setStatus(null);
		}

		if (childUserName == null || childUserName.equals("")) {
			UserManagementUserLevelObjPag.setChildUserName("");
		} else
			UserManagementUserLevelObjPag.setChildUserName(childUserName.trim());

		if (childOLMId == null || childOLMId.equals("")) {
			UserManagementUserLevelObjPag.setChildOlmId("");
		} else
			UserManagementUserLevelObjPag.setChildOlmId(childOLMId.trim());

		HashMap<Integer, List<UserManagementUserLevel>> ReportsMap = new HashMap<Integer, List<UserManagementUserLevel>>();
		int page = Integer.parseInt(request.getParameter("pageNum"));
		reportslogger.info("Page No. "+page);
		String errMsg = null;
		ModelAndView modelAndViewObj = new ModelAndView();
		List<String> statusList = ReportsDaoObj.returnStatusList();
		if(statusList==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("userManagementUserLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("status list size in controller: "+statusList.size());


		List<String> roleDescList = ReportsDaoObj.returnRoleDescList();
		if(roleDescList==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("userManagementUserLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Role desc List Size in Controller: "+roleDescList.size());
		modelAndViewObj.addObject("statusList", statusList);
		modelAndViewObj.addObject("roleDescList", roleDescList);

		ReportsMap = ReportsDaoObj.getUserMgmtUserLevelMap(
				UserManagementUserLevelObjPag, page);
		if(ReportsMap==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("userManagementUserLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Details list size Based On Page No in Controller: "+ReportsMap.size());

		/*reportslogger.info("pagtn called in controller");

		reportslogger.info("status msg in controller:"
				+ UserManagementUserLevelObj.getStatusMsg());*/

		if(UserManagementUserLevelObjPag.getStatusMsg()!=null)
		{

			if(UserManagementUserLevelObjPag.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				errMsg="";
			}

			else
			{
				errMsg=UserManagementUserLevelObjPag.getStatusMsg();
			}

		}
		else
			errMsg="Connectivity Issues..Retry..";



		modelAndViewObj.addObject("errMsg", errMsg);
		modelAndViewObj.addObject("ReportsMap", ReportsMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("UserRole", Role);
		modelAndViewObj.addObject("UserManagementUserLevelObjJsp",
				UserManagementUserLevelObjPag);
		modelAndViewObj.setViewName("userManagementUserLevelSearch");


		return modelAndViewObj;
	}

	/* <-------------export to excel-----------------> */

	@RequestMapping(value = "/UserMgmtUserLvlToExcel", method = RequestMethod.POST)
	public ModelAndView UserMgmtUserLvlToExcel(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		session=request.getSession(false);

		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		UserManagementUserLevel UserManagementUserLevelObjExcel=new UserManagementUserLevel();
		UserManagementUserLevelObjExcel.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in UserMgmtUserLvlToExcel mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);
		String status = request.getParameter("status");
		reportslogger.info("status: " + status );

		String roleDesc = request.getParameter("roleDesc");
		reportslogger.info("Role Description: " + roleDesc );
		String childOLMId = request.getParameter("childOLMId");
		reportslogger.info("User ID: " + childOLMId );
		String childUserName = request.getParameter("userName");
		reportslogger.info("user name"+childUserName);

		if (roleDesc != null) {
			UserManagementUserLevelObjExcel.setRoleDesc(roleDesc);;
		} else {
			UserManagementUserLevelObjExcel.setRoleDesc(null);
		}

		if (status != null) {
			UserManagementUserLevelObjExcel.setStatus(status);
		} else {
			UserManagementUserLevelObjExcel.setStatus(null);
		}

		if (childUserName == null || childUserName.equals("")) {
			UserManagementUserLevelObjExcel.setChildUserName("");
		} else
			UserManagementUserLevelObjExcel.setChildUserName(childUserName.trim());

		if (childOLMId == null || childOLMId.equals("")) {
			UserManagementUserLevelObjExcel.setChildOlmId("");
		} else
			UserManagementUserLevelObjExcel.setChildOlmId(childOLMId.trim());

		reportslogger.info("In User Management User Report Excel File Download");
		String pageNum = null;
		List<String> statusList = ReportsDaoObj.returnStatusList();
		if(statusList==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("userManagementUserLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("status list size in controller: "+statusList.size());
		List<String> roleDescList = ReportsDaoObj.returnRoleDescList();
		if(roleDescList==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("userManagementUserLevelSearch");
			return modelAndViewObj;
		}
		reportslogger.info("Role desc List Size in Controller: "+roleDescList.size());
		modelAndViewObj.addObject("statusList", statusList);
		modelAndViewObj.addObject("roleDescList", roleDescList);

		List<UserManagementUserLevel> UserMgmtUserLvlToExcelList = new ArrayList<UserManagementUserLevel>();

		UserMgmtUserLvlToExcelList = ReportsDaoObj
				.getUserMgmtUserLevelExcelList(UserManagementUserLevelObjExcel,
						pageNum);
		if(UserMgmtUserLvlToExcelList==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("userManagementUserLevelSearch");
			return modelAndViewObj;
		}

		reportslogger.info("Excel details list size in controller: "+UserMgmtUserLvlToExcelList.size());

		int rowNumber = 1;
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("UserManagement_User_Level");
		XSSFCell cell = null;
		XSSFRow row;
		XSSFCellStyle my_style = wb.createCellStyle();
		XSSFFont my_font=wb.createFont();
		my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		my_style.setFont(my_font);
		XSSFCellStyle rightAligned = wb.createCellStyle();
		rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);
		row = sheet.createRow(0);
		cell = row.createCell(0);
		cell.setCellValue("User ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(1);
		cell.setCellValue("Role");
		cell.setCellStyle(my_style);
		cell = row.createCell(2);
		cell.setCellValue("Vendor ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(3);
		cell.setCellValue("User Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(4);
		cell.setCellValue("E-Mail ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(5);
		cell.setCellValue("Contact Number");
		cell.setCellStyle(my_style);
		cell = row.createCell(6);
		cell.setCellValue("User Circle");
		cell.setCellStyle(my_style);
		cell = row.createCell(7);
		cell.setCellValue("Applicable Process");
		cell.setCellStyle(my_style);
		cell = row.createCell(8);
		cell.setCellValue("Active Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(9);
		cell.setCellValue("Inactive Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(10);
		cell.setCellValue("Status");
		cell.setCellStyle(my_style);

		for (int i = 0; i < UserMgmtUserLvlToExcelList.size(); i++) {
			// reportslogger.info("i value"+i);
			UserManagementUserLevel UserManagementUserLevelObject = UserMgmtUserLvlToExcelList
					.get(i);

			row = sheet.createRow(rowNumber);
			cell = row.createCell(0);
			cell.setCellValue(UserManagementUserLevelObject.getChildOlmId());
			//sheet.autoSizeColumn(0);

			cell = row.createCell(1);
			cell.setCellValue(UserManagementUserLevelObject.getRoleDesc());

			cell = row.createCell(2);
			cell.setCellValue(UserManagementUserLevelObject.getVendorId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(2);

			cell = row.createCell(3);
			cell.setCellValue(UserManagementUserLevelObject.getChildUserName());

			cell = row.createCell(4);
			cell.setCellValue(UserManagementUserLevelObject.getEmailId());
			//sheet.autoSizeColumn(4);

			cell = row.createCell(5);
			cell.setCellValue(UserManagementUserLevelObject.getContact());

			cell = row.createCell(6);
			cell.setCellValue(UserManagementUserLevelObject.getCircle());
			//sheet.autoSizeColumn(6);

			cell = row.createCell(7);
			cell.setCellValue(UserManagementUserLevelObject
					.getApplicableProcess());

			cell = row.createCell(8);
			cell.setCellValue(UserManagementUserLevelObject.getActiveDate());
			//sheet.autoSizeColumn(8);

			cell = row.createCell(9);
			cell.setCellValue(UserManagementUserLevelObject.getInactiveDate());

			cell = row.createCell(10);
			cell.setCellValue(UserManagementUserLevelObject.getStatus());
			//sheet.autoSizeColumn(10);

			rowNumber++;

		}
		for(int i=0;i<=10;i++){
			sheet.autoSizeColumn(i);			
		}
		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		byte[] outArray = outByteStream.toByteArray();

		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
				.format(new Date());

		String fileName = "APS_UserManagement_User_Level" + "_" + date + ".xlsx";
		reportslogger.info("filename is" + fileName);

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}

		reportslogger.info("End of User Management Excel records download ");

		return modelAndViewObj;

	}
	//******************************************PAYMENT ICRM REPORT*********************************************


	//PaymentICRMBean paymentIcrmBeanObj=new PaymentICRMBean();

	@RequestMapping(value = "/paymentIcrmReport")
	public ModelAndView paymentIcrmReport(ModelMap model,HttpServletRequest request, HttpServletResponse response)

	{
		ModelAndView modelAndViewObj = new ModelAndView();
		reportslogger.info("Entered into paymentIcrmReport mapping at reports controller");
		PaymentICRMBean paymentIcrmBeanObj=new PaymentICRMBean();
		try
		{
			int pageNumber = 1;
			reportslogger.info(" PageNumber in paymentIcrmReport mapping:" + pageNumber);

			session=request.getSession(false);
			String userId=session.getAttribute("userid").toString();
			reportslogger.info("UserId in paymentIcrmReport mapping is:"+userId);


			String role=session.getAttribute("user_role_id").toString();
			reportslogger.info("User Role in transLevelDefault mapping is:"+role);


			List<String> icrmStatusList=new ArrayList<String>();

			icrmStatusList=paymentIcrmDaoObj.icrmStatusDropDown();


			if(icrmStatusList==null)
			{
				reportslogger.info("Data Base Issues..Retry.....Exception in adviceEFTLevelNextPage");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("paymentIcrmBeanObjJsp",paymentIcrmBeanObj);
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("icrmStatusList", icrmStatusList);
				modelAndViewObj.setViewName("paymentIcrmReport");

				return modelAndViewObj;
			}



			paymentIcrmBeanObj.setFromDate(null);
			paymentIcrmBeanObj.setToDate(null);
			paymentIcrmBeanObj.setSrNumber(null);
			paymentIcrmBeanObj.setAps_Status(null);
			paymentIcrmBeanObj.setTransId_ChequeNum(null);

			reportslogger.info("From date from jsp in paymentIcrmReport mapping:"+paymentIcrmBeanObj.getFromDate());
			reportslogger.info("To Date from jsp in paymentIcrmReport mapping:"+paymentIcrmBeanObj.getToDate());
			reportslogger.info("SR number from jsp in paymentIcrmReport mapping:"+paymentIcrmBeanObj.getSrNumber());
			reportslogger.info("Aps status from jsp in paymentIcrmReport mapping:"+paymentIcrmBeanObj.getAps_Status());


			HashMap<Integer, List<PaymentICRMBean>> icrmHashMap = paymentIcrmDaoObj.paymentIcrmSearch(pageNumber,paymentIcrmBeanObj,role,userId);

			String errorMsg=paymentIcrmBeanObj.getErrorMsg();
			reportslogger.info("Error Message in paymentIcrmReport mapping:"+errorMsg);

			/* if(errorMsg.equalsIgnoreCase("SUCCESS"))
			  {
				  errorMsg="";
			  }
			 else 
				 errorMsg="No records Found";
			 */


			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(icrmHashMap==null)
			{
				reportslogger.info("Data Base Issues...Exception in paymentIcrmReport");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("icrmHashMap", icrmHashMap);
				modelAndViewObj.addObject("icrmStatusList", icrmStatusList);
				modelAndViewObj.addObject("paymentIcrmBeanObjJsp",paymentIcrmBeanObj);
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.setViewName("paymentIcrmReport");
				return modelAndViewObj;
			}


			modelAndViewObj.addObject("icrmHashMap", icrmHashMap);
			modelAndViewObj.addObject("paymentIcrmBeanObjJsp",paymentIcrmBeanObj);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			modelAndViewObj.addObject("icrmStatusList", icrmStatusList);
			modelAndViewObj.setViewName("paymentIcrmReport");
			return modelAndViewObj;
		}
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		reportslogger.info("Executed paymentIcrmReport at reports controller)");	  

		return modelAndViewObj;
	}


	@RequestMapping(value = "/paymentIcrmSearch")
	public ModelAndView paymentIcrmSearch(ModelMap model,HttpServletRequest request, HttpServletResponse response)

	{
		ModelAndView modelAndViewObj = new ModelAndView();
		PaymentICRMBean paymentIcrmBeanObjSearch=new PaymentICRMBean();
		try
		{
			reportslogger.info("Entered into paymentIcrmSearch mapping at reports controller");
			int pageNumber = 1;
			reportslogger.info(" PageNumber in paymentIcrmSearch mapping:" + pageNumber);

			session=request.getSession(false);
			String userId=session.getAttribute("userid").toString();
			reportslogger.info("UserId in paymentIcrmSearch mapping is:"+userId);

			String role=session.getAttribute("user_role_id").toString();
			reportslogger.info("User Role in transLevelDefault mapping is:"+role);


			String srNumber=request.getParameter("SRNumber");
			String status=request.getParameter("aps_status");
			String fromDate =request.getParameter("startDateId");
			String toDate=request.getParameter("endDateId");
			String TransactionId=request.getParameter("TransactionId");


			if (fromDate != "") {
				paymentIcrmBeanObjSearch.setFromDate(fromDate);
			}
			else
				paymentIcrmBeanObjSearch.setFromDate(null);

			if(toDate !="")
			{
				paymentIcrmBeanObjSearch.setToDate(toDate);
			}
			else
				paymentIcrmBeanObjSearch.setToDate(null);


			if(srNumber==null||srNumber.equalsIgnoreCase(""))
				paymentIcrmBeanObjSearch.setSrNumber(null);
			else
				paymentIcrmBeanObjSearch.setSrNumber(srNumber.trim());

			if(TransactionId==null||TransactionId.equalsIgnoreCase(""))
				paymentIcrmBeanObjSearch.setTransId_ChequeNum(null);
			else
				paymentIcrmBeanObjSearch.setTransId_ChequeNum(TransactionId.trim());

			/* if (status==null||status.equalsIgnoreCase("SELECT ONE")) 
		            	paymentIcrmBeanObj.setAps_Status(null);
		    		else*/
			paymentIcrmBeanObjSearch.setAps_Status(status);


			reportslogger.info("From date from jsp in paymentIcrmSearch mapping:"+paymentIcrmBeanObjSearch.getFromDate());
			reportslogger.info("To Date from jsp in paymentIcrmSearch mapping:"+paymentIcrmBeanObjSearch.getToDate());
			reportslogger.info("SR number from jsp in paymentIcrmSearch mapping:"+paymentIcrmBeanObjSearch.getSrNumber());
			reportslogger.info("Aps status from jsp in paymentIcrmSearch mapping:"+paymentIcrmBeanObjSearch.getAps_Status());
			reportslogger.info("Transaction Id/Cheque Numberfrom jsp in paymentIcrmSearch mapping:"+paymentIcrmBeanObjSearch.getTransId_ChequeNum());

			List<String> icrmStatusList=new ArrayList<String>();

			icrmStatusList=paymentIcrmDaoObj.icrmStatusDropDown();


			if(icrmStatusList==null)
			{
				reportslogger.info("Data Base Issues...Exception in adviceEFTLevelNextPage");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("paymentIcrmBeanObjJsp",paymentIcrmBeanObjSearch);
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("icrmStatusList", icrmStatusList);
				modelAndViewObj.setViewName("paymentIcrmReport");

				return modelAndViewObj;
			}



			HashMap<Integer, List<PaymentICRMBean>> icrmHashMap = paymentIcrmDaoObj.paymentIcrmSearch(pageNumber,paymentIcrmBeanObjSearch,role,userId);

			String errorMsg=paymentIcrmBeanObjSearch.getErrorMsg();			  
			reportslogger.info("Error Message in paymentIcrmSearch mapping:"+errorMsg);

			/*  if(errorMsg.equalsIgnoreCase("SUCCESS"))
			  {
				  errorMsg="";
			  }
			 else 
				 errorMsg="No records Found";*/

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(icrmHashMap==null)
			{
				reportslogger.info("Data Base Issues...Exception in paymentIcrmSearch");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("icrmHashMap", icrmHashMap);
				modelAndViewObj.addObject("icrmStatusList", icrmStatusList);
				modelAndViewObj.addObject("paymentIcrmBeanObjJsp",paymentIcrmBeanObjSearch);
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.setViewName("paymentIcrmReport");
				return modelAndViewObj;
			}

			modelAndViewObj.addObject("icrmHashMap", icrmHashMap);
			modelAndViewObj.addObject("paymentIcrmBeanObjJsp",paymentIcrmBeanObjSearch);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			modelAndViewObj.addObject("icrmStatusList", icrmStatusList);
			modelAndViewObj.setViewName("paymentIcrmReport");
		}
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		reportslogger.info("Executed paymentIcrmSearch at reports controller)");	  

		return modelAndViewObj;
	}



	@RequestMapping(value = "/paymentIcrmNextPage")
	public ModelAndView paymentIcrmNextPage(HttpServletRequest request,HttpServletResponse response) 
	{
		ModelAndView modelAndViewObj = new ModelAndView();
		PaymentICRMBean paymentIcrmBeanObjPag=new PaymentICRMBean();

		int pageNumber = Integer.parseInt(request.getParameter("pageNumber"));

		reportslogger.info(" PageNumber in paymentIcrmNextPage mapping:" + pageNumber);

		try
		{
			reportslogger.info("Entered into paymentIcrmNextPage mapping at reports controller");

			session=request.getSession(false);			
			String userId=session.getAttribute("userid").toString();

			reportslogger.info("UserId in paymentIcrmNextPage mapping is:"+userId);

			String role=session.getAttribute("user_role_id").toString();
			reportslogger.info("User Role in transLevelDefault mapping is:"+role);
			String srNumber=request.getParameter("SRNumber");
			String status=request.getParameter("aps_status");
			String fromDate =request.getParameter("startDateId");
			String toDate=request.getParameter("endDateId");
			String TransactionId=request.getParameter("TransactionId");


			if (fromDate != "") {
				paymentIcrmBeanObjPag.setFromDate(fromDate);
			}
			else
				paymentIcrmBeanObjPag.setFromDate(null);

			if(toDate !="")
			{
				paymentIcrmBeanObjPag.setToDate(toDate);
			}
			else
				paymentIcrmBeanObjPag.setToDate(null);


			if(srNumber==null||srNumber.equalsIgnoreCase(""))
				paymentIcrmBeanObjPag.setSrNumber(null);
			else
				paymentIcrmBeanObjPag.setSrNumber(srNumber.trim());

			if(TransactionId==null||TransactionId.equalsIgnoreCase(""))
				paymentIcrmBeanObjPag.setTransId_ChequeNum(null);
			else
				paymentIcrmBeanObjPag.setTransId_ChequeNum(TransactionId.trim());

			/* if (status==null||status.equalsIgnoreCase("SELECT ONE")) 
	            	paymentIcrmBeanObj.setAps_Status(null);
	    		else*/
			paymentIcrmBeanObjPag.setAps_Status(status);


			reportslogger.info("From date from jsp in paymentIcrmPagination mapping:"+paymentIcrmBeanObjPag.getFromDate());
			reportslogger.info("To Date from jsp in paymentIcrmPagination mapping:"+paymentIcrmBeanObjPag.getToDate());
			reportslogger.info("SR number from jsp in paymentIcrmPagination mapping:"+paymentIcrmBeanObjPag.getSrNumber());
			reportslogger.info("Aps status from jsp in paymentIcrmPagination mapping:"+paymentIcrmBeanObjPag.getAps_Status());
			reportslogger.info("Transaction Id/Cheque Numberfrom jsp in paymentIcrmPagination mapping:"+paymentIcrmBeanObjPag.getTransId_ChequeNum());



			List<String> icrmStatusList=new ArrayList<String>();

			icrmStatusList=paymentIcrmDaoObj.icrmStatusDropDown();


			if(icrmStatusList==null)
			{
				reportslogger.info("Data Base Issues...Exception in adviceEFTLevelNextPage");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("paymentIcrmBeanObjJsp",paymentIcrmBeanObjPag);
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("icrmStatusList", icrmStatusList);
				modelAndViewObj.setViewName("paymentIcrmReport");

				return modelAndViewObj;
			}


			HashMap<Integer, List<PaymentICRMBean>> icrmHashMap = paymentIcrmDaoObj.paymentIcrmSearch(pageNumber,paymentIcrmBeanObjPag,role,userId);

			String errorMsg=paymentIcrmBeanObjPag.getErrorMsg();
			reportslogger.info("Error Message in paymentIcrmNextPage mapping:"+errorMsg);

			/*  if(errorMsg.equalsIgnoreCase("SUCCESS"))
		  {
			  errorMsg="";
		  }
		 else 
			 errorMsg="No records Found";*/

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(icrmHashMap==null)
			{
				reportslogger.info("Data Base Issues...Exception in paymentIcrmNextPage");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("icrmHashMap", icrmHashMap);
				modelAndViewObj.addObject("icrmStatusList", icrmStatusList);
				modelAndViewObj.addObject("paymentIcrmBeanObjJsp",paymentIcrmBeanObjPag);
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.setViewName("paymentIcrmReport");
				return modelAndViewObj;
			}

			modelAndViewObj.addObject("icrmHashMap", icrmHashMap);
			modelAndViewObj.addObject("paymentIcrmBeanObjJsp",paymentIcrmBeanObjPag);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("icrmStatusList", icrmStatusList);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			modelAndViewObj.setViewName("paymentIcrmReport");

		}
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		reportslogger.info("Executed paymentIcrmNextPage at reports controller)");	  

		return modelAndViewObj;
	}


	@RequestMapping(value = "/icrmExportToExcel", method = RequestMethod.POST)
	public ModelAndView icrmExportToExcel(ModelMap model,HttpServletRequest request, HttpServletResponse response) 
	{
		ModelAndView modelAndViewObj = new ModelAndView();
		PaymentICRMBean paymentIcrmBeanObjExcel=new PaymentICRMBean();

		try{

			reportslogger.info("Entered into icrmExportToExcel mapping at reports controller");

			String page = null;


			session=request.getSession(false);
			String userId=session.getAttribute("userid").toString();
			reportslogger.info("UserId in icrmExportToExcel mapping is:"+userId);

			String role=session.getAttribute("user_role_id").toString();
			reportslogger.info("User Role in transLevelDefault mapping is:"+role);
			String srNumber=request.getParameter("SRNumber");
			String status=request.getParameter("aps_status");
			String fromDate =request.getParameter("startDateId");
			String toDate=request.getParameter("endDateId");
			String TransactionId=request.getParameter("TransactionId");


			if (fromDate != "") {
				paymentIcrmBeanObjExcel.setFromDate(fromDate);
			}
			else
				paymentIcrmBeanObjExcel.setFromDate(null);

			if(toDate !="")
			{
				paymentIcrmBeanObjExcel.setToDate(toDate);
			}
			else
				paymentIcrmBeanObjExcel.setToDate(null);


			if(srNumber==null||srNumber.equalsIgnoreCase(""))
				paymentIcrmBeanObjExcel.setSrNumber(null);
			else
				paymentIcrmBeanObjExcel.setSrNumber(srNumber.trim());

			if(TransactionId==null||TransactionId.equalsIgnoreCase(""))
				paymentIcrmBeanObjExcel.setTransId_ChequeNum(null);
			else
				paymentIcrmBeanObjExcel.setTransId_ChequeNum(TransactionId.trim());

			/* if (status==null||status.equalsIgnoreCase("SELECT ONE")) 
			            	paymentIcrmBeanObj.setAps_Status(null);
			    		else*/
			paymentIcrmBeanObjExcel.setAps_Status(status);


			reportslogger.info("From date from jsp in paymentIcrmExcel mapping:"+paymentIcrmBeanObjExcel.getFromDate());
			reportslogger.info("To Date from jsp in paymentIcrmExcel mapping:"+paymentIcrmBeanObjExcel.getToDate());
			reportslogger.info("SR number from jsp in paymentIcrmExcel mapping:"+paymentIcrmBeanObjExcel.getSrNumber());
			reportslogger.info("Aps status from jsp in paymentIcrmExcel mapping:"+paymentIcrmBeanObjExcel.getAps_Status());
			reportslogger.info("Transaction Id/Cheque Numberfrom jsp in paymentIcrmExcel mapping:"+paymentIcrmBeanObjExcel.getTransId_ChequeNum());


			List<String> icrmStatusList=new ArrayList<String>();

			icrmStatusList=paymentIcrmDaoObj.icrmStatusDropDown();


			if(icrmStatusList==null)
			{
				reportslogger.info("Data Base Issues...Exception in adviceEFTLevelNextPage");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("paymentIcrmBeanObjJsp",paymentIcrmBeanObjExcel);
				modelAndViewObj.addObject("icrmStatusList", icrmStatusList);
				modelAndViewObj.setViewName("paymentIcrmReport");

				return modelAndViewObj;
			}

			PaymentICRMBean icrmFileObj=paymentIcrmDaoObj.downloadIcrmFile(paymentIcrmBeanObjExcel,extension, page,role,userId);	  

			String errorMsg=paymentIcrmBeanObjExcel.getErrorMsg();
			reportslogger.info("Error Message in paymentIcrmNextPage mapping:"+errorMsg);

			/* if(errorMsg.equalsIgnoreCase("SUCCESS"))
				  {
					  errorMsg="";
				  }
				 else 
					 errorMsg="No records Found";
			 */


			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(icrmFileObj==null)
			{
				reportslogger.info("Data Base Issues...Exception in paymentIcrmNextPage");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("icrmStatusList", icrmStatusList);
				modelAndViewObj.addObject("paymentIcrmBeanObjJsp",paymentIcrmBeanObjExcel);
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.setViewName("paymentIcrmReport");
				return modelAndViewObj;
			}

			/*String filePath=downloadedFilesPath;
				reportslogger.info("Filepath is:"+filePath);*/

			String filename="APS_ICRM_PAYMENT_TRANSFER_LEVEL_"+paymentIcrmDaoObj.getDateTime()+"."+extension;
			reportslogger.info("Filename:"+filename);

			//  String finalPath=/*filePath+"\\"+*/filename;

			ServletOutputStream out = response.getOutputStream();
			FileInputStream in = new FileInputStream(filename);
			reportslogger.info("File name:"+in);

			response.setContentType("APPLICATION/OCTET-STREAM");

			response.addHeader("content-disposition",
					"attachment; filename=" +filename);


			int octet;
			while((octet = in.read()) != -1)
				out.write(octet);

			in.close();
			out.flush();
			out.close();
			response.flushBuffer();
			reportslogger.info("Executed icrmExportToExcel at reports controller)");	  

		}catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		return modelAndViewObj;
	}


	/**********************************************ICRM REPORT END***********************************************/

	/***********************************************************APS Reports Transaction Level**********************************************************************/

	@RequestMapping(value = "/getRolePayPostingTransLevelAps", method = RequestMethod.GET)
	public ModelAndView getParentRoleAps(HttpServletRequest request,
			HttpServletResponse response) {
		session=request.getSession(false);
		PayPostingTransLevelDetails PayPostingTransLevelDetailsObj = new PayPostingTransLevelDetails();

		reportslogger.info("In Payment Posting Transaction Level Controller");

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		ModelAndView modelAndViewObj = new ModelAndView();
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		/* Role = ReportsDaoObj.getRole(parentUserId);
		 if(Role==-1)
			{
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("PaymentPostingTransLevelSearch");
				return modelAndViewObj;
			}*/

		reportslogger.info("User Role: " + Role);

		if ((Role == 1) || (Role == 2) || (Role == 3) || (Role == 4)
				|| (Role == 7)) {

			PayPostingTransLevelDetailsObj.setParentUserId(parentUserId);
			PayPostingTransLevelDetailsObj.setChildUserId(null);
			PayPostingTransLevelDetailsObj.setVendorId(null);
			PayPostingTransLevelDetailsObj.setToDate(null);
			PayPostingTransLevelDetailsObj.setFromDate(null);
			PayPostingTransLevelDetailsObj.setFileId(null);
			PayPostingTransLevelDetailsObj.setFileName(null);
			PayPostingTransLevelDetailsObj.setMode(null);
			PayPostingTransLevelDetailsObj.setRefNo(null);
			/*PayPostingTransLevelDetailsObj.setRole(Role);*/

			// call method from dao and get records based on parentuserId only.
			int page = 1;
			String errMsg = null;
			List<String> modeList = ReportsDaoObj.returnModeList();
			if(modeList==null)
			{
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("UserRole", Role);
				modelAndViewObj.setViewName("PaymentPostingTransLevelSearchAps");
				return modelAndViewObj;
			}
			reportslogger.info("Modes List size in Controller: "+modeList.size());
			modelAndViewObj.addObject("modeList", modeList);

			HashMap<Integer, List<PayPostingTransLevelDetails>> ReportsMap = new HashMap<Integer, List<PayPostingTransLevelDetails>>();
			ReportsMap = ReportsDaoObj.getPaymntPostingTranslevelMapAps(
					PayPostingTransLevelDetailsObj, page);

			if(ReportsMap==null)
			{
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("UserRole", Role);
				modelAndViewObj.setViewName("PaymentPostingTransLevelSearchAps");
				return modelAndViewObj;
			}


			reportslogger.info("Details map  size in Controller: "+ReportsMap.size());


			if(PayPostingTransLevelDetailsObj.getStatusMsg()!=null)
			{

				if(PayPostingTransLevelDetailsObj.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
				{
					errMsg="";
				}

				else
				{
					errMsg=PayPostingTransLevelDetailsObj.getStatusMsg();
				}

			}
			else
				errMsg="Connectivity Issues..Retry..";




			modelAndViewObj.addObject("ReportsMap", ReportsMap);



			modelAndViewObj.addObject("errMsg", errMsg);

			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.addObject("currentPage", page);

			modelAndViewObj.setViewName("PaymentPostingTransLevelSearchAps");
		}

		else {
			modelAndViewObj.addObject("error",
					"You do not have privilige to check the reports !!");
			modelAndViewObj.setViewName("PaymentPostingTransLevelSearchAps");
			return modelAndViewObj;
		}

		return modelAndViewObj;
	}

	@RequestMapping(value = "/getRecordsOnSearchPayPostingTransLevelAps")
	public ModelAndView getRecordsOnSearchAps(HttpServletRequest request,
			HttpServletResponse response) {
		session=request.getSession(false);
		PayPostingTransLevelDetails PayPostingTransLevelDetailsObjSearch = new PayPostingTransLevelDetails();
		reportslogger.info("In Payment Posting Transaction level Search");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		PayPostingTransLevelDetailsObjSearch.setParentUserId(parentUserId);
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		ModelAndView modelAndViewObj = new ModelAndView();
		/* if(Role==-1)
			{
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("PaymentPostingTransLevelSearch");
				return modelAndViewObj;
			}*/
		//reportslogger.info("parent before:"+ PayPostingTransLevelDetailsObj.getParentUserId());
		/*int Role = ReportsDaoObj.getRole(PayPostingTransLevelDetailsObj
				.getParentUserId());*/

		//reportslogger.info("parent:"+ PayPostingTransLevelDetailsObj.getParentUserId());

		String fromDate = request.getParameter("startDate");
		String toDate = request.getParameter("endDate");
		String mode = request.getParameter("mode");
		String refNo = request.getParameter("refNo");
		String userOLMId = request.getParameter("userId");
		String fileId = request.getParameter("fileId");
		String fileName = request.getParameter("fileName");
		String vendorId = request.getParameter("vendorId");
		reportslogger.info("To date : " +toDate );
		reportslogger.info("From date : " +fromDate);
		reportslogger.info("User ID : "+userOLMId );
		reportslogger.info("Vendor ID :"+ vendorId);
		reportslogger.info("Reference No. : " + refNo);
		reportslogger.info("mode:  " + mode);
		reportslogger.info("File Id: "+fileId );
		reportslogger.info("File name:" +fileName);

		if (fromDate != "") {
			PayPostingTransLevelDetailsObjSearch.setFromDate(fromDate);
		} else

			PayPostingTransLevelDetailsObjSearch.setFromDate(null);

		if (toDate != "") {
			PayPostingTransLevelDetailsObjSearch.setToDate(toDate);
		} else

			PayPostingTransLevelDetailsObjSearch.setToDate(null);

		if (mode != null && mode.equalsIgnoreCase("ALL")) {
			PayPostingTransLevelDetailsObjSearch.setMode("");
		} else {
			PayPostingTransLevelDetailsObjSearch.setMode(mode);
		}

		if (vendorId == null || vendorId.equals("")) {
			PayPostingTransLevelDetailsObjSearch.setVendorId(null);
		} else
			PayPostingTransLevelDetailsObjSearch.setVendorId(vendorId.trim());

		if (refNo == null || refNo.equals("")) {
			PayPostingTransLevelDetailsObjSearch.setRefNo(null);
		} else
			PayPostingTransLevelDetailsObjSearch.setRefNo(refNo.trim());

		if (fileId == null || fileId.equals("")) {
			PayPostingTransLevelDetailsObjSearch.setFileId(null);

		} else
			PayPostingTransLevelDetailsObjSearch.setFileId(fileId.trim());

		if (fileName == null || fileName.equals("")) {
			PayPostingTransLevelDetailsObjSearch.setFileName(null);
		} else
			PayPostingTransLevelDetailsObjSearch.setFileName(fileName.trim());
		if (userOLMId == null || userOLMId.equals("")) {
			PayPostingTransLevelDetailsObjSearch.setChildUserId(null);
		} else
			PayPostingTransLevelDetailsObjSearch.setChildUserId(userOLMId.trim());

		/*reportslogger.info("todate:"
				+ PayPostingTransLevelDetailsObj.getToDate());
		reportslogger.info("from date:"
				+ PayPostingTransLevelDetailsObj.getFromDate());
		reportslogger.info("user id:"
				+ PayPostingTransLevelDetailsObj.getChildUserId());
		reportslogger.info("vendor id:"
				+ PayPostingTransLevelDetailsObj.getVendorId());
		reportslogger.info("ref no:"
				+ PayPostingTransLevelDetailsObj.getRefNo());
		reportslogger.info("mode:" + PayPostingTransLevelDetailsObj.getMode());
		reportslogger.info("file id:"
				+ PayPostingTransLevelDetailsObj.getFileId());
		reportslogger.info("file name:"
				+ PayPostingTransLevelDetailsObj.getFileName());*/

		HashMap<Integer, List<PayPostingTransLevelDetails>> ReportsMap = new HashMap<Integer, List<PayPostingTransLevelDetails>>();
		int page = 1;
		String errMsg = null;
		List<String> modeList = ReportsDaoObj.returnModeList();
		if(modeList==null)
		{
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentPostingTransLevelSearchAps");
			return modelAndViewObj;
		}
		reportslogger.info("Modes List size in Controller: "+modeList.size());
		modelAndViewObj.addObject("modeList", modeList);

		ReportsMap = ReportsDaoObj.getPaymntPostingTranslevelMapAps(
				PayPostingTransLevelDetailsObjSearch, page);

		if(ReportsMap==null)
		{	modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
		modelAndViewObj.addObject("UserRole", Role);
		modelAndViewObj.setViewName("PaymentPostingTransLevelSearchAps");
		return modelAndViewObj;
		}
		reportslogger.info("Details Map Size based on Search Criteria in Controller: "+ReportsMap.size());


		/*reportslogger.info("method called in controller");

		reportslogger.info("status msg in controller:"
				+ PayPostingTransLevelDetailsObj.getStatusMsg());*/
		if(PayPostingTransLevelDetailsObjSearch.getStatusMsg()!=null)
		{

			if(PayPostingTransLevelDetailsObjSearch.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				errMsg="";
			}

			else
			{
				errMsg=PayPostingTransLevelDetailsObjSearch.getStatusMsg();
			}

		}
		else
			errMsg="Connectivity Issues..Retry..";



		modelAndViewObj.addObject("modeList", modeList);
		modelAndViewObj.addObject("errMsg", errMsg);
		modelAndViewObj.addObject("ReportsMap", ReportsMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("UserRole", Role);
		modelAndViewObj.addObject("PayPostingTransLevelDetailsObjJsp", PayPostingTransLevelDetailsObjSearch);
		modelAndViewObj.setViewName("PaymentPostingTransLevelSearchAps");

		//	reportslogger.info("end of search controller");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/viewRecordswithPaginationPayPostingTransLevelAps")
	public ModelAndView viewRecordswithPaginationAps(HttpServletRequest request,
			HttpServletResponse response) {
		session=request.getSession(false);
		PayPostingTransLevelDetails PayPostingTransLevelDetailsObjPag = new PayPostingTransLevelDetails();
		reportslogger.info("In Payment Posting Transaction Level Pagination");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		PayPostingTransLevelDetailsObjPag.setParentUserId(parentUserId);
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);




		String fromDate = request.getParameter("startDate");
		String toDate = request.getParameter("endDate");
		String mode = request.getParameter("mode");
		String refNo = request.getParameter("refNo");
		String userOLMId = request.getParameter("userId");
		String fileId = request.getParameter("fileId");
		String fileName = request.getParameter("fileName");
		String vendorId = request.getParameter("vendorId");
		reportslogger.info("To date : " +toDate );
		reportslogger.info("From date : " +fromDate);
		reportslogger.info("User ID : "+userOLMId );
		reportslogger.info("Vendor ID :"+ vendorId);
		reportslogger.info("Reference No. : " + refNo);
		reportslogger.info("mode:  " + mode);
		reportslogger.info("File Id: "+fileId );
		reportslogger.info("File name:" +fileName);

		if (fromDate != "") {
			PayPostingTransLevelDetailsObjPag.setFromDate(fromDate);
		} else

			PayPostingTransLevelDetailsObjPag.setFromDate(null);

		if (toDate != "") {
			PayPostingTransLevelDetailsObjPag.setToDate(toDate);
		} else

			PayPostingTransLevelDetailsObjPag.setToDate(null);

		if (mode != null && mode.equalsIgnoreCase("ALL")) {
			PayPostingTransLevelDetailsObjPag.setMode("");
		} else {
			PayPostingTransLevelDetailsObjPag.setMode(mode);
		}

		if (vendorId == null || vendorId.equals("")) {
			PayPostingTransLevelDetailsObjPag.setVendorId(null);
		} else
			PayPostingTransLevelDetailsObjPag.setVendorId(vendorId.trim());

		if (refNo == null || refNo.equals("")) {
			PayPostingTransLevelDetailsObjPag.setRefNo(null);
		} else
			PayPostingTransLevelDetailsObjPag.setRefNo(refNo.trim());

		if (fileId == null || fileId.equals("")) {
			PayPostingTransLevelDetailsObjPag.setFileId(null);

		} else
			PayPostingTransLevelDetailsObjPag.setFileId(fileId.trim());

		if (fileName == null || fileName.equals("")) {
			PayPostingTransLevelDetailsObjPag.setFileName(null);
		} else
			PayPostingTransLevelDetailsObjPag.setFileName(fileName.trim());
		if (userOLMId == null || userOLMId.equals("")) {
			PayPostingTransLevelDetailsObjPag.setChildUserId(null);
		} else
			PayPostingTransLevelDetailsObjPag.setChildUserId(userOLMId.trim());
		/*int Role = ReportsDaoObj.getRole(PayPostingTransLevelDetailsObj
				.getParentUserId());*/
		HashMap<Integer, List<PayPostingTransLevelDetails>> ReportsMap = new HashMap<Integer, List<PayPostingTransLevelDetails>>();
		int page = Integer.parseInt(request.getParameter("pageNum"));
		reportslogger.info("Page No. " +page);
		ModelAndView modelAndViewObj = new ModelAndView();
		String errMsg = null;
		List<String> modeList = ReportsDaoObj.returnModeList();
		if(modeList==null)
		{
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentPostingTransLevelSearchAps");
			return modelAndViewObj;
		}
		reportslogger.info("Modes List size in Controller: "+modeList.size());
		modelAndViewObj.addObject("modeList", modeList);

		ReportsMap = ReportsDaoObj.getPaymntPostingTranslevelMapAps(
				PayPostingTransLevelDetailsObjPag, page);

		if(ReportsMap==null)
		{
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentPostingTransLevelSearchAps");
			return modelAndViewObj;
		}
		reportslogger.info("Deatils Map size based on Page No. in controller: "+ReportsMap.size());

		/*	reportslogger.info("pagtn called in controller");

		reportslogger.info("status msg in controller"
				+ PayPostingTransLevelDetailsObj.getStatusMsg());*/
		if(PayPostingTransLevelDetailsObjPag.getStatusMsg()!=null)
		{

			if(PayPostingTransLevelDetailsObjPag.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				errMsg="";
			}

			else
			{
				errMsg=PayPostingTransLevelDetailsObjPag.getStatusMsg();
			}

		}
		else
			errMsg="Connectivity Issues..Retry..";


		modelAndViewObj.addObject("modeList", modeList);
		modelAndViewObj.addObject("errMsg", errMsg);
		modelAndViewObj.addObject("ReportsMap", ReportsMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("UserRole", Role);
		modelAndViewObj.addObject("PayPostingTransLevelDetailsObjJsp", PayPostingTransLevelDetailsObjPag);
		modelAndViewObj.setViewName("PaymentPostingTransLevelSearchAps");
		//	reportslogger.info("end of pagination");
		return modelAndViewObj;
	}

	/* <-------------export to excel-----------------> */

	@RequestMapping(value = "/viewPayPostingTransLevelExcelAps", method = RequestMethod.POST)
	public ModelAndView PayPostTansToExcelAps(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		session=request.getSession(false);
		PayPostingTransLevelDetails PayPostingTransLevelDetailsObjExcel = new PayPostingTransLevelDetails();

		reportslogger.info(" In Payment Posting Transaction level Excel Download ");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		PayPostingTransLevelDetailsObjExcel.setParentUserId(parentUserId);
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);
		String fromDate = request.getParameter("startDate");
		String toDate = request.getParameter("endDate");
		String mode = request.getParameter("mode");
		String refNo = request.getParameter("refNo");
		String userOLMId = request.getParameter("userId");
		String fileId = request.getParameter("fileId");
		String fileName = request.getParameter("fileName");
		String vendorId = request.getParameter("vendorId");
		reportslogger.info("To date : " +toDate );
		reportslogger.info("From date : " +fromDate);
		reportslogger.info("User ID : "+userOLMId );
		reportslogger.info("Vendor ID :"+ vendorId);
		reportslogger.info("Reference No. : " + refNo);
		reportslogger.info("mode:  " + mode);
		reportslogger.info("File Id: "+fileId );
		reportslogger.info("File name:" +fileName);

		if (fromDate != "") {
			PayPostingTransLevelDetailsObjExcel.setFromDate(fromDate);
		} else

			PayPostingTransLevelDetailsObjExcel.setFromDate(null);

		if (toDate != "") {
			PayPostingTransLevelDetailsObjExcel.setToDate(toDate);
		} else

			PayPostingTransLevelDetailsObjExcel.setToDate(null);

		if (mode != null && mode.equalsIgnoreCase("ALL")) {
			PayPostingTransLevelDetailsObjExcel.setMode("");
		} else {
			PayPostingTransLevelDetailsObjExcel.setMode(mode);
		}

		if (vendorId == null || vendorId.equals("")) {
			PayPostingTransLevelDetailsObjExcel.setVendorId(null);
		} else
			PayPostingTransLevelDetailsObjExcel.setVendorId(vendorId.trim());

		if (refNo == null || refNo.equals("")) {
			PayPostingTransLevelDetailsObjExcel.setRefNo(null);
		} else
			PayPostingTransLevelDetailsObjExcel.setRefNo(refNo.trim());

		if (fileId == null || fileId.equals("")) {
			PayPostingTransLevelDetailsObjExcel.setFileId(null);

		} else
			PayPostingTransLevelDetailsObjExcel.setFileId(fileId.trim());

		if (fileName == null || fileName.equals("")) {
			PayPostingTransLevelDetailsObjExcel.setFileName(null);
		} else
			PayPostingTransLevelDetailsObjExcel.setFileName(fileName.trim());
		if (userOLMId == null || userOLMId.equals("")) {
			PayPostingTransLevelDetailsObjExcel.setChildUserId(null);
		} else
			PayPostingTransLevelDetailsObjExcel.setChildUserId(userOLMId.trim());
		int Role=Integer.parseInt(sessionRole_string);


		String pageNum = null;

		List<PayPostingTransLevelDetails> PayPostExportToExcelList = new ArrayList<PayPostingTransLevelDetails>();
		List<String> modeList = ReportsDaoObj.returnModeList();
		if(modeList==null)
		{
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentPostingTransLevelSearchAps");
			return modelAndViewObj;
		}
		reportslogger.info("Modes List size in Controller: "+modeList.size());
		modelAndViewObj.addObject("modeList", modeList);

		PayPostExportToExcelList = ReportsDaoObj
				.getPayPostTransactionExcelListAps(PayPostingTransLevelDetailsObjExcel,
						pageNum);
		if(PayPostExportToExcelList==null)
		{
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentPostingTransLevelSearchAps");
			return modelAndViewObj;
		}
		reportslogger.info(" Excel records list size in Controller: "+PayPostExportToExcelList.size());
		int rowNumber = 1;
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("Payment_Posting_Trans_Level");
		XSSFCell cell = null;
		XSSFRow row;
		XSSFCellStyle my_style = wb.createCellStyle();
		XSSFFont my_font=wb.createFont();
		my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		my_style.setFont(my_font);
		XSSFCellStyle rightAligned = wb.createCellStyle();
		rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);

		row = sheet.createRow(0);
		cell = row.createCell(0);
		cell.setCellValue("Reference No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(1);
		cell.setCellValue("Bank Account No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(2);
		cell.setCellValue("Vendor ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(3);
		cell.setCellValue("Vendor Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(4);
		cell.setCellValue("Uploaded By(OLM ID)");
		cell.setCellStyle(my_style);
		cell = row.createCell(5);
		cell.setCellValue("File ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(6);
		cell.setCellValue("File Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(7);
		cell.setCellValue("File Source");
		cell.setCellStyle(my_style);
		cell = row.createCell(8);
		cell.setCellValue("Mode");
		cell.setCellStyle(my_style);
		cell = row.createCell(9);
		cell.setCellValue("Uploaded Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(10);
		cell.setCellValue("Approved/Rejected By(OLM ID)");
		cell.setCellStyle(my_style);
		cell = row.createCell(11);
		cell.setCellValue("Approved/Rejected Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(12);
		cell.setCellValue("LOB");
		cell.setCellStyle(my_style);

		cell = row.createCell(13);
		cell.setCellValue("Account No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(14);
		cell.setCellValue("Invoice");
		cell.setCellStyle(my_style);
		cell = row.createCell(15);
		cell.setCellValue("Amount");
		cell.setCellStyle(my_style);
		cell = row.createCell(16);
		cell.setCellValue("Status");
		cell.setCellStyle(my_style);
		cell = row.createCell(17);
		cell.setCellValue("FX Posting Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(18);
		cell.setCellValue("Tracking ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(19);
		cell.setCellValue("Tracking ID Serv");
		cell.setCellStyle(my_style);
		cell = row.createCell(20);
		cell.setCellValue("Reason For Failure/LIU ");
		cell.setCellStyle(my_style);
		cell = row.createCell(21);
		cell.setCellValue("SI Number ");
		cell.setCellStyle(my_style);


		for (int i = 0; i < PayPostExportToExcelList.size(); i++) {
			// reportslogger.info("i value"+i);
			PayPostingTransLevelDetails PayPostingTransLevelDetailsObject = PayPostExportToExcelList
					.get(i);

			row = sheet.createRow(rowNumber);
			cell = row.createCell(0);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getRefNo());
			cell = row.createCell(1);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getBankAccNo());
			//sheet.autoSizeColumn(0);

			cell = row.createCell(2);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getVendorId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(1);
			cell = row.createCell(3);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getVendorName());
			//sheet.autoSizeColumn(2);

			cell = row.createCell(4);
			cell.setCellValue(PayPostingTransLevelDetailsObject
					.getChildUserId());
			//sheet.autoSizeColumn(3);
			cell = row.createCell(5);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getFileId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(4);

			cell = row.createCell(6);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getFileName());
			//sheet.autoSizeColumn(5);
			cell = row.createCell(7);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getFileSource());
			//sheet.autoSizeColumn(6);

			cell = row.createCell(8);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getMode());
			//sheet.autoSizeColumn(7);
			cell = row.createCell(9);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getUploadTime());
			//sheet.autoSizeColumn(8);
			cell = row.createCell(10);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getApprovedBy());
			//sheet.autoSizeColumn(9);
			cell = row.createCell(11);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getApprovedDate());
			cell = row.createCell(12);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getLob());
			//sheet.autoSizeColumn(10);

			cell = row.createCell(13);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getAccountNo());
			//sheet.autoSizeColumn(11);
			cell = row.createCell(14);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getInvoice());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(12);

			cell = row.createCell(15);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getTotalVal());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(13);
			cell = row.createCell(16);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getStatus());
			//sheet.autoSizeColumn(14);
			cell = row.createCell(17);
			cell.setCellValue(PayPostingTransLevelDetailsObject
					.getFXpostingTime());
			//sheet.autoSizeColumn(15);

			cell = row.createCell(18);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getTrackingId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(16);
			cell = row.createCell(19);
			cell.setCellValue(PayPostingTransLevelDetailsObject
					.getTrackingIdServ());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(17);
			cell = row.createCell(20);
			cell.setCellValue(PayPostingTransLevelDetailsObject
					.getReasonForLiuorFailure());
			cell = row.createCell(21);
			cell.setCellValue(PayPostingTransLevelDetailsObject.getSiNumber());
			//sheet.autoSizeColumn(18);
			rowNumber++;
			//reportslogger.info("row number in getPayPostTransactionExcelList" +rowNumber);
		}
		for (int i = 0; i <= 20; i++) {

			sheet.autoSizeColumn(i);
		}

		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		byte[] outArray = outByteStream.toByteArray();
		//reportslogger.info("out arrray" +outArray);
		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
				.format(new Date());

		String fileName1 = "APS_Payment_Posting_Transaction_Level_"+ date + ".xlsx";
		reportslogger.info("filename is" + fileName1);

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName1);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();

			outStream.close();
			outByteStream.close();

		} catch (IOException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}

		reportslogger.info("End of payment Posting Transaction Excel records download "); 

		return modelAndViewObj;

	}
	/******************************************************************Payment Direct reversal Aps************************************************************/

	@RequestMapping(value = "/paymentDirectReversalRoleAps", method = RequestMethod.GET)
	public ModelAndView getPaymentDirectReversalUserRoleAps(HttpServletRequest request, HttpServletResponse response) 
	{
		ModelAndView modelAndViewObj = new ModelAndView();

		session=request.getSession(false);
		reportslogger.info("In Payment Direct Reversal Controller)");
		PaymentDirectReversalBean PayDirectReversalBeanObj = new PaymentDirectReversalBean();
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);


		//reportslogger.info("in controller to get role.");

		// get role by calling fn.
		//String parentUserId = request.getParameter("parentUserId");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User Id: " + parentUserId);
		/*Role = ReportsDaoObj.getRole(parentUserId);
		if(Role==-1)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.setViewName("PaymentDirectReversalSearch");
			return modelAndViewObj;
		}*/

		reportslogger.info("User Role" + Role);

		if (Role == 1 || Role == 2 || Role == 7) {

			PayDirectReversalBeanObj.setParentUserId(parentUserId);
			PayDirectReversalBeanObj.setChildUserId(null);
			PayDirectReversalBeanObj.setVendorId(null);
			PayDirectReversalBeanObj.setFileId(null);
			PayDirectReversalBeanObj.setFileName(null);
			PayDirectReversalBeanObj.setToDate(null);
			PayDirectReversalBeanObj.setFromDate(null);
			PayDirectReversalBeanObj.setTrackingId(null);

			HashMap<Integer, List<PaymentDirectReversalBean>> payDirectReversalCompleteDetailsMap = new HashMap<Integer, List<PaymentDirectReversalBean>>();
			int page = 1;
			String statusMsg = null;

			payDirectReversalCompleteDetailsMap = ReportsDaoObj
					.getPayDirectReversalDetailsAps(PayDirectReversalBeanObj, page);
			if(payDirectReversalCompleteDetailsMap==null){
				modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("role", Role);
				modelAndViewObj.setViewName("PaymentDirectReversalSearchAps");
				return modelAndViewObj;
			}

			reportslogger.info("Details map size in Controller: "+ payDirectReversalCompleteDetailsMap.size());

			if(PayDirectReversalBeanObj.getStatusMsg()!=null)
			{

				if(PayDirectReversalBeanObj.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
				{
					statusMsg="";
				}

				else
				{
					statusMsg=PayDirectReversalBeanObj.getStatusMsg();
				}

			}
			else
				statusMsg="Connectivity Issues..Retry..";


			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.addObject("statusMsg", statusMsg);
			modelAndViewObj.addObject("payDirectReversalDetailsMap",
					payDirectReversalCompleteDetailsMap);
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.setViewName("PaymentDirectReversalSearchAps");
			return modelAndViewObj;
		}

		else
			reportslogger.info("you do not have privilage to view this page!");

		modelAndViewObj.addObject("error",
				"You do not have privilige to View Reports !!");
		modelAndViewObj.setViewName("PaymentDirectReversalSearchAps");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/PaymentDirectReversalSearchAps")
	public ModelAndView paymentDirectReversalDetailsAps(HttpServletRequest request, HttpServletResponse response)
	{


		session=request.getSession(false);
		PaymentDirectReversalBean PayDirectReversalBeanObjSearch = new PaymentDirectReversalBean();
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		PayDirectReversalBeanObjSearch.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);

		reportslogger.info("In Payment Direct Reversal search");
		ModelAndView modelAndViewObj = new ModelAndView();
		/*if(Role==-1)
		{
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.setViewName("PaymentDirectReversalSearch");
			return modelAndViewObj;
		}*/
		String childUserId = request.getParameter("childUserId");
		reportslogger.info("User ID: " + childUserId);
		String trackingID = request.getParameter("trackingId");

		reportslogger.info("Tracking ID: " + trackingID);

		String filedId = request.getParameter("fileId");
		reportslogger.info("File ID: " + filedId);

		String fileName = request.getParameter("fileName");
		reportslogger.info("File Name: " + fileName);

		String vendorId = request.getParameter("vendorId");
		reportslogger.info("Vendor ID: " + vendorId);

		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date: " + fromDate);

		String toDate = request.getParameter("endDate");
		reportslogger.info("To Date: " + toDate);

		if (trackingID == null || trackingID.equals("")) {
			PayDirectReversalBeanObjSearch.setTrackingId(null);
		} else {

			PayDirectReversalBeanObjSearch.setTrackingId(trackingID.trim());
		}
		if (childUserId == null || childUserId.equals("")) {
			PayDirectReversalBeanObjSearch.setChildUserId(null);
		} else {
			PayDirectReversalBeanObjSearch.setChildUserId(childUserId.trim());
		}

		if (filedId == null || filedId.equals("")) {
			PayDirectReversalBeanObjSearch.setFileId(null);
		} else {
			PayDirectReversalBeanObjSearch.setFileId(filedId.trim());
		}


		if (fileName == null || fileName.equals("")) {
			PayDirectReversalBeanObjSearch.setFileName(null);
		} else {
			PayDirectReversalBeanObjSearch.setFileName(fileName.trim());
		}


		if (vendorId == null || vendorId.equals("")) {
			PayDirectReversalBeanObjSearch.setVendorId(null);
		} else {
			PayDirectReversalBeanObjSearch.setVendorId(vendorId.trim());
		}

		if (fromDate != "") {

			PayDirectReversalBeanObjSearch.setFromDate(fromDate);
		} else
			PayDirectReversalBeanObjSearch.setFromDate(null);


		if (toDate != "") {
			PayDirectReversalBeanObjSearch.setToDate(toDate);
		} else {
			PayDirectReversalBeanObjSearch.setToDate(null);
		}



		HashMap<Integer, List<PaymentDirectReversalBean>> payDirectReversalMap = new HashMap<Integer, List<PaymentDirectReversalBean>>();
		int page = 1;
		String statusMsg = null;


		payDirectReversalMap = ReportsDaoObj.getPayDirectReversalDetailsAps(
				PayDirectReversalBeanObjSearch, page);
		if(payDirectReversalMap==null){
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PaymentDirectReversalSearchAps");
			return modelAndViewObj;
		}


		reportslogger.info("Details Map size Based on Search Criteria in Controller: "+payDirectReversalMap.size());


		if(PayDirectReversalBeanObjSearch.getStatusMsg()!=null)
		{

			if(PayDirectReversalBeanObjSearch.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				statusMsg="";
			}

			else
			{
				statusMsg=PayDirectReversalBeanObjSearch.getStatusMsg();
			}

		}
		else
			statusMsg="Connectivity Issues..Retry..";
		modelAndViewObj.addObject("role", Role);
		modelAndViewObj.addObject("statusMsg", statusMsg);
		modelAndViewObj.addObject("payDirectReversalDetailsMap",
				payDirectReversalMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("PayDirectReversalBeanObjJsp", PayDirectReversalBeanObjSearch);
		modelAndViewObj.setViewName("PaymentDirectReversalSearchAps");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/paymentDirectReversalPaginationAps")
	public ModelAndView paymentDirectReversalPaginationAps(HttpServletRequest request, HttpServletResponse response)
	{


		session=request.getSession(false);
		PaymentDirectReversalBean PayDirectReversalBeanObjPag = new PaymentDirectReversalBean();
		reportslogger.info("In Payment Direct Reversal Pagination");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		PayDirectReversalBeanObjPag.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);
		String childUserId = request.getParameter("childUserId");
		reportslogger.info("User ID: " + childUserId);
		String trackingID = request.getParameter("trackingId");

		reportslogger.info("Tracking ID: " + trackingID);

		String filedId = request.getParameter("fileId");
		reportslogger.info("File ID: " + filedId);

		String fileName = request.getParameter("fileName");
		reportslogger.info("File Name: " + fileName);

		String vendorId = request.getParameter("vendorId");
		reportslogger.info("Vendor ID: " + vendorId);

		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date: " + fromDate);

		String toDate = request.getParameter("endDate");
		reportslogger.info("To Date: " + toDate);

		if (trackingID == null || trackingID.equals("")) {
			PayDirectReversalBeanObjPag.setTrackingId(null);
		} else {

			PayDirectReversalBeanObjPag.setTrackingId(trackingID.trim());
		}
		if (childUserId == null || childUserId.equals("")) {
			PayDirectReversalBeanObjPag.setChildUserId(null);
		} else {
			PayDirectReversalBeanObjPag.setChildUserId(childUserId.trim());
		}

		if (filedId == null || filedId.equals("")) {
			PayDirectReversalBeanObjPag.setFileId(null);
		} else {
			PayDirectReversalBeanObjPag.setFileId(filedId.trim());
		}


		if (fileName == null || fileName.equals("")) {
			PayDirectReversalBeanObjPag.setFileName(null);
		} else {
			PayDirectReversalBeanObjPag.setFileName(fileName.trim());
		}


		if (vendorId == null || vendorId.equals("")) {
			PayDirectReversalBeanObjPag.setVendorId(null);
		} else {
			PayDirectReversalBeanObjPag.setVendorId(vendorId.trim());
		}

		if (fromDate != "") {

			PayDirectReversalBeanObjPag.setFromDate(fromDate);
		} else
			PayDirectReversalBeanObjPag.setFromDate(null);


		if (toDate != "") {
			PayDirectReversalBeanObjPag.setToDate(toDate);
		} else {
			PayDirectReversalBeanObjPag.setToDate(null);
		}




		HashMap<Integer, List<PaymentDirectReversalBean>> payDirectReversalMap = new HashMap<Integer, List<PaymentDirectReversalBean>>();
		int page = Integer.parseInt(request.getParameter("pageNum"));
		reportslogger.info("Page No. :"+page);
		String statusMsg = null;
		ModelAndView modelAndViewObj = new ModelAndView();

		payDirectReversalMap = ReportsDaoObj.getPayDirectReversalDetailsAps(
				PayDirectReversalBeanObjPag, page);
		if(payDirectReversalMap==null){
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PaymentDirectReversalSearchAps");
			return modelAndViewObj;
		}
		reportslogger.info("Details map size Based on Page No. in Controller"+payDirectReversalMap.size());


		/*	reportslogger.info("method called in controler");

		reportslogger.info("in controller"
				+ PayDirectReversalBeanObj.getStatusMsg());
		 */if(PayDirectReversalBeanObjPag.getStatusMsg()!=null)
		 {

			 if(PayDirectReversalBeanObjPag.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			 {
				 statusMsg="";
			 }

			 else
			 {
				 statusMsg=PayDirectReversalBeanObjPag.getStatusMsg();
			 }

		 }
		 else
			 statusMsg="Connectivity Issues..Retry..";
		 modelAndViewObj.addObject("role", Role);
		 modelAndViewObj.addObject("statusMsg", statusMsg);
		 modelAndViewObj.addObject("payDirectReversalDetailsMap",
				 payDirectReversalMap);
		 modelAndViewObj.addObject("currentPage", page);
		 modelAndViewObj.addObject("PayDirectReversalBeanObjJsp", PayDirectReversalBeanObjPag);
		 modelAndViewObj.setViewName("PaymentDirectReversalSearchAps");
		 return modelAndViewObj;
	}

	@RequestMapping(value = "/PaymentDirectReversalExcelFileDownloadAps", method = RequestMethod.POST)
	public ModelAndView paymentDirectRevexcelFileDownloadAps(HttpServletRequest request, HttpServletResponse response)throws IOException 
	{
		session=request.getSession(false);
		PaymentDirectReversalBean PayDirectReversalBeanObjExcel = new PaymentDirectReversalBean();
		reportslogger.info("In Payment Direct Reversal Excel File Download");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		PayDirectReversalBeanObjExcel.setParentUserId(parentUserId);

		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);
		String childUserId = request.getParameter("childUserId");
		reportslogger.info("User ID: " + childUserId);
		String trackingID = request.getParameter("trackingId");

		reportslogger.info("Tracking ID: " + trackingID);

		String filedId = request.getParameter("fileId");
		reportslogger.info("File ID: " + filedId);

		String fileName = request.getParameter("fileName");
		reportslogger.info("File Name: " + fileName);

		String vendorId = request.getParameter("vendorId");
		reportslogger.info("Vendor ID: " + vendorId);

		String fromDate = request.getParameter("startDate");
		reportslogger.info("From Date: " + fromDate);

		String toDate = request.getParameter("endDate");
		reportslogger.info("To Date: " + toDate);

		if (trackingID == null || trackingID.equals("")) {
			PayDirectReversalBeanObjExcel.setTrackingId(null);
		} else {

			PayDirectReversalBeanObjExcel.setTrackingId(trackingID.trim());
		}
		if (childUserId == null || childUserId.equals("")) {
			PayDirectReversalBeanObjExcel.setChildUserId(null);
		} else {
			PayDirectReversalBeanObjExcel.setChildUserId(childUserId.trim());
		}

		if (filedId == null || filedId.equals("")) {
			PayDirectReversalBeanObjExcel.setFileId(null);
		} else {
			PayDirectReversalBeanObjExcel.setFileId(filedId.trim());
		}


		if (fileName == null || fileName.equals("")) {
			PayDirectReversalBeanObjExcel.setFileName(null);
		} else {
			PayDirectReversalBeanObjExcel.setFileName(fileName.trim());
		}


		if (vendorId == null || vendorId.equals("")) {
			PayDirectReversalBeanObjExcel.setVendorId(null);
		} else {
			PayDirectReversalBeanObjExcel.setVendorId(vendorId.trim());
		}

		if (fromDate != "") {

			PayDirectReversalBeanObjExcel.setFromDate(fromDate);
		} else
			PayDirectReversalBeanObjExcel.setFromDate(null);


		if (toDate != "") {
			PayDirectReversalBeanObjExcel.setToDate(toDate);
		} else {
			PayDirectReversalBeanObjExcel.setToDate(null);
		}




		List<PaymentDirectReversalBean> PayReversalExcellDetailsList = new ArrayList<PaymentDirectReversalBean>();
		String pageNo = null;
		int rowNumber = 1;
		ModelAndView modelAndViewObj = new ModelAndView();

		PayReversalExcellDetailsList = ReportsDaoObj
				.getPayDirectRevExcelDetailsAps(PayDirectReversalBeanObjExcel, pageNo);
		if(PayReversalExcellDetailsList==null){
			modelAndViewObj.addObject("statusMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("role", Role);
			modelAndViewObj.setViewName("PaymentDirectReversalSearchAps");
			return modelAndViewObj;
		}

		reportslogger.info("Excel Details size In Controller: "+ PayReversalExcellDetailsList.size());
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("Direct_Reversal_Trans_Level");
		XSSFCell cell = null;
		XSSFRow row;
		XSSFCellStyle my_style = wb.createCellStyle();
		XSSFFont my_font=wb.createFont();
		my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		my_style.setFont(my_font);
		XSSFCellStyle rightAligned = wb.createCellStyle();
		rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);




		row = sheet.createRow(0);
		cell = row.createCell(0);
		cell.setCellValue("Account No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(1);
		cell.setCellValue("Tracking ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(2);
		cell.setCellValue("Tracking ID serv");
		cell.setCellStyle(my_style);
		cell = row.createCell(3);
		cell.setCellValue("Uploaded By(OLM ID) ");
		cell.setCellStyle(my_style);
		cell = row.createCell(4);
		cell.setCellValue("Uploaded By(Name)");
		cell.setCellStyle(my_style);
		cell = row.createCell(5);
		cell.setCellValue("File ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(6);
		cell.setCellValue("File Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(7);
		cell.setCellValue("Uploaded Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(8);
		cell.setCellValue("Status");
		cell.setCellStyle(my_style);
		cell = row.createCell(9);
		cell.setCellValue("Reversal Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(10);
		cell.setCellValue("Reason For Failure");
		cell.setCellStyle(my_style);

		for (int i = 0; i < PayReversalExcellDetailsList.size(); i++) {

			PaymentDirectReversalBean PayDirectReversalBeanObj = PayReversalExcellDetailsList
					.get(i);
			// reportslogger.info("in controller uplodeddate"+PayPostingFilelevelDetailsObj.getUplodedDateTime());
			row = sheet.createRow(rowNumber);
			cell = row.createCell(0);
			cell.setCellValue(PayDirectReversalBeanObj.getAccountNumber());
			//sheet.autoSizeColumn(0);
			cell = row.createCell(1);
			if (PayDirectReversalBeanObj.getTrackingId() == null
					|| PayDirectReversalBeanObj.getTrackingId()
					.equalsIgnoreCase("NA"))
				cell.setCellValue("");
			else
				cell.setCellValue(PayDirectReversalBeanObj.getTrackingId());
			cell.setCellStyle(rightAligned);

			//sheet.autoSizeColumn(1);
			cell = row.createCell(2);
			if (PayDirectReversalBeanObj.getTrackingIdServ() == null
					|| PayDirectReversalBeanObj.getTrackingIdServ()
					.equalsIgnoreCase("NA"))
				cell.setCellValue("");
			else
				cell.setCellValue(PayDirectReversalBeanObj.getTrackingIdServ());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(2);
			cell = row.createCell(3);
			cell.setCellValue(PayDirectReversalBeanObj.getUploadedByOlmId());
			//sheet.autoSizeColumn(3);
			cell = row.createCell(4);
			cell.setCellValue(PayDirectReversalBeanObj.getUploadedByName());
			//sheet.autoSizeColumn(4);
			cell = row.createCell(5);
			cell.setCellValue(PayDirectReversalBeanObj.getFileId());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(5);

			cell = row.createCell(6);
			cell.setCellValue(PayDirectReversalBeanObj.getFileName());
			//sheet.autoSizeColumn(6);
			cell = row.createCell(7);
			CellStyle cellStyle = wb.createCellStyle();
			CreationHelper createHelper = wb.getCreationHelper();

			cellStyle.setDataFormat(createHelper.createDataFormat().getFormat(
					"dd/mm/yyyy"));
			if (PayDirectReversalBeanObj.getUploadDateTime() != null) {
				cell.setCellValue(PayDirectReversalBeanObj.getUploadDateTime());
				cell.setCellStyle(cellStyle);
			} else
				cell.setCellValue("");

			//sheet.autoSizeColumn(7);
			cell = row.createCell(8);
			cell.setCellValue(PayDirectReversalBeanObj.getStatus());
			//sheet.autoSizeColumn(8);
			cell = row.createCell(9);
			if (PayDirectReversalBeanObj.getFxUpdateTime() == null
					|| PayDirectReversalBeanObj.getFxUpdateTime()
					.equalsIgnoreCase("NA"))
				cell.setCellValue("");
			else
				cell.setCellValue(PayDirectReversalBeanObj.getFxUpdateTime());
			//sheet.autoSizeColumn(9);
			cell = row.createCell(10);
			if (PayDirectReversalBeanObj.getReasonForFailue() == null
					|| PayDirectReversalBeanObj.getReasonForFailue()
					.equalsIgnoreCase("NA"))
				cell.setCellValue("");
			else
				cell.setCellValue(PayDirectReversalBeanObj.getReasonForFailue());
			//sheet.autoSizeColumn(10);

			rowNumber = rowNumber + 1;

		}
		for (int i = 0; i <= 10; i++) {
			sheet.autoSizeColumn(i);
		}
		// write it as an excel attachment
		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		byte[] outArray = outByteStream.toByteArray();
		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
				.format(new Date());
		String fileName1 = "APS_Direct_Reversal_Transaction_Level_" + date + " .xlsx";

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName1);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}

		reportslogger.info("End of Payment Direct Reversal Excel records download ");
		// modelAndViewObj.setViewName("viewTracking");
		return modelAndViewObj;
	}


	/**************************************************************payment posting cheque level aps************************************************************/

	@RequestMapping(value = "/getPayPostingChequeRoleAps", method = RequestMethod.GET)
	public ModelAndView getPayPostingChequeRoleAps(HttpServletRequest request,HttpServletResponse response) 
	{
		// session=request.getSession(false);
		session=request.getSession(false);
		PayPostingChequeDetails PyPostChequeDetailsObj = new PayPostingChequeDetails();
		reportslogger.info("In Payment Posting Cheque level Controller");
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);

		//	reportslogger.info("in controller to get  role.");

		ModelAndView modelAndViewObj = new ModelAndView();

		//String parentUserId = request.getParameter("UserId");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		/*Role = ReportsDaoObj.getRole(parentUserId);
		 if(Role==-1)
			{
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("PaymentPostingChequeSearch");
				return modelAndViewObj;
			}*/

		reportslogger.info("User Role: " + Role);

		if ((Role == 1) || (Role == 2) || (Role == 3) || (Role == 4)
				|| (Role == 7)) {

			PyPostChequeDetailsObj.setParentUser(parentUserId);
			/*PyPostChequeDetailsObj.setRole(Role);*/
			PyPostChequeDetailsObj.setChqNo(null);
			PyPostChequeDetailsObj.setUserOLMId(null);
			PyPostChequeDetailsObj.setFileId(null);
			PyPostChequeDetailsObj.setFileName(null);
			PyPostChequeDetailsObj.setVendorId(null);
			PyPostChequeDetailsObj.setToDate(null);
			PyPostChequeDetailsObj.setFromDate(null);
			int page = 1;
			String errMsg = null;

			HashMap<Integer, List<PayPostingChequeDetails>> ReportsMap = new HashMap<Integer, List<PayPostingChequeDetails>>();
			ReportsMap = ReportsDaoObj.getPaymntPostingChequeMapAps(
					PyPostChequeDetailsObj, page);
			if(ReportsMap==null){
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("UserRole", Role);
				modelAndViewObj.setViewName("PaymentPostingChequeSearchAps");
				return modelAndViewObj;
			}
			reportslogger.info("Details map Size in Controller: " +ReportsMap.size());
			if(PyPostChequeDetailsObj.getStatusMsg()!=null)
			{

				if(PyPostChequeDetailsObj.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
				{
					errMsg="";
				}

				else
				{
					errMsg=PyPostChequeDetailsObj.getStatusMsg();
				}

			}
			else
				errMsg="Connectivity Issues..Retry..";


			modelAndViewObj.addObject("ReportsMap", ReportsMap);

			modelAndViewObj.addObject("errMsg", errMsg);

			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.addObject("currentPage", page);

			modelAndViewObj.setViewName("PaymentPostingChequeSearchAps");

		} else {

			modelAndViewObj.addObject("error",
					"You do not have privilige to check the reports !!");
			modelAndViewObj.setViewName("PaymentPostingChequeSearchAps");
			return modelAndViewObj;
		}

		return modelAndViewObj;

	}

	@RequestMapping(value = "/getPayPostingChequeRecordsOnFilterAps")
	public ModelAndView getPayPostingChequeRecordsOnFilterAps(HttpServletRequest request, HttpServletResponse response)
	{
		session=request.getSession(false);
		reportslogger.info("In Payment Posting Cheque level Search");
		PayPostingChequeDetails PyPostChequeDetailsObjSearch = new PayPostingChequeDetails();
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);

		PyPostChequeDetailsObjSearch.setParentUser(parentUserId);
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);

		ModelAndView modelAndViewObj = new ModelAndView();
		/* if(Role==-1)
			{
				modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("PaymentPostingChequeSearch");
				return modelAndViewObj;
			}
		 */
		/*	int Role = ReportsDaoObj.getRole(PyPostChequeDetailsObj.getParentUser());*/

		String fromDate = request.getParameter("startDate");
		String toDate = request.getParameter("endDate");
		String chqNo = request.getParameter("chqNo");
		String userOLMId = request.getParameter("userId");
		String fileId = request.getParameter("fileId");
		String fileName = request.getParameter("fileName");
		String vendorId = request.getParameter("vendorId");
		reportslogger.info("From Date:" + fromDate);
		reportslogger.info(" To Date: " + toDate);
		reportslogger.info("Cheque No.: " + chqNo);
		reportslogger.info("User ID: " +userOLMId );
		reportslogger.info(" File ID: " +fileId );
		reportslogger.info(" File Name: " +fileName );
		reportslogger.info(" Vendor ID: " + vendorId);

		if (fromDate != "") {
			PyPostChequeDetailsObjSearch.setFromDate(fromDate);
		} else

			PyPostChequeDetailsObjSearch.setFromDate(null);

		if (toDate != "") {
			PyPostChequeDetailsObjSearch.setToDate(toDate);
		} else

			PyPostChequeDetailsObjSearch.setToDate(null);

		if (vendorId == null || vendorId.equals("")) {
			PyPostChequeDetailsObjSearch.setVendorId(null);
		} else
			PyPostChequeDetailsObjSearch.setVendorId(vendorId.trim());

		if (chqNo == null || chqNo.equals("")) {
			PyPostChequeDetailsObjSearch.setChqNo(null);
		} else
			PyPostChequeDetailsObjSearch.setChqNo(chqNo.trim());

		if (fileId == null || fileId.equals("")) {
			PyPostChequeDetailsObjSearch.setFileId(null);

		} else
			PyPostChequeDetailsObjSearch.setFileId(fileId.trim());

		if (fileName == null || fileName.equals("")) {
			PyPostChequeDetailsObjSearch.setFileName(null);
		} else
			PyPostChequeDetailsObjSearch.setFileName(fileName.trim());
		if (userOLMId == null || userOLMId.equals("")) {
			PyPostChequeDetailsObjSearch.setUserOLMId(null);
		} else
			PyPostChequeDetailsObjSearch.setUserOLMId(userOLMId.trim());



		HashMap<Integer, List<PayPostingChequeDetails>> ReportsMap = new HashMap<Integer, List<PayPostingChequeDetails>>();
		int page = 1;
		String errMsg = null;


		ReportsMap = ReportsDaoObj.getPaymntPostingChequeMapAps(
				PyPostChequeDetailsObjSearch, page);
		if(ReportsMap==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentPostingChequeSearchAps");
			return modelAndViewObj;
		}
		reportslogger.info("Details map Size based on search criteria in Controller: "+ReportsMap.size());

		if(PyPostChequeDetailsObjSearch.getStatusMsg()!=null)
		{

			if(PyPostChequeDetailsObjSearch.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				errMsg="";
			}

			else
			{
				errMsg=PyPostChequeDetailsObjSearch.getStatusMsg();
			}

		}
		else
			errMsg="Connectivity Issues..Retry..";




		modelAndViewObj.addObject("errMsg", errMsg);
		modelAndViewObj.addObject("ReportsMap", ReportsMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("PyPostChequeDetailsObjJsp", PyPostChequeDetailsObjSearch);
		modelAndViewObj.addObject("UserRole", Role);
		modelAndViewObj.setViewName("PaymentPostingChequeSearchAps");

		return modelAndViewObj;
	}

	@RequestMapping(value = "/viewPaginationofPayPostingChequeRecordsAps")
	public ModelAndView viewPyPostingChequeRecordswithPaginationAps(HttpServletRequest request, HttpServletResponse response) 
	{
		session=request.getSession(false);
		PayPostingChequeDetails PyPostChequeDetailsObjPag = new PayPostingChequeDetails();
		reportslogger.info("In Payment Posting Cheque Level Pagination");
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		PyPostChequeDetailsObjPag.setParentUser(parentUserId);
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);




		String fromDate = request.getParameter("startDate");
		String toDate = request.getParameter("endDate");
		String chqNo = request.getParameter("chqNo");
		String userOLMId = request.getParameter("userId");
		String fileId = request.getParameter("fileId");
		String fileName = request.getParameter("fileName");
		String vendorId = request.getParameter("vendorId");
		reportslogger.info("From Date:" + fromDate);
		reportslogger.info(" To Date: " + toDate);
		reportslogger.info("Cheque No.: " + chqNo);
		reportslogger.info("User ID: " +userOLMId );
		reportslogger.info(" File ID: " +fileId );
		reportslogger.info(" File Name: " +fileName );
		reportslogger.info(" Vendor ID: " + vendorId);

		if (fromDate != "") {
			PyPostChequeDetailsObjPag.setFromDate(fromDate);
		} else

			PyPostChequeDetailsObjPag.setFromDate(null);

		if (toDate != "") {
			PyPostChequeDetailsObjPag.setToDate(toDate);
		} else

			PyPostChequeDetailsObjPag.setToDate(null);

		if (vendorId == null || vendorId.equals("")) {
			PyPostChequeDetailsObjPag.setVendorId(null);
		} else
			PyPostChequeDetailsObjPag.setVendorId(vendorId.trim());

		if (chqNo == null || chqNo.equals("")) {
			PyPostChequeDetailsObjPag.setChqNo(null);
		} else
			PyPostChequeDetailsObjPag.setChqNo(chqNo.trim());

		if (fileId == null || fileId.equals("")) {
			PyPostChequeDetailsObjPag.setFileId(null);

		} else
			PyPostChequeDetailsObjPag.setFileId(fileId.trim());

		if (fileName == null || fileName.equals("")) {
			PyPostChequeDetailsObjPag.setFileName(null);
		} else
			PyPostChequeDetailsObjPag.setFileName(fileName.trim());
		if (userOLMId == null || userOLMId.equals("")) {
			PyPostChequeDetailsObjPag.setUserOLMId(null);
		} else
			PyPostChequeDetailsObjPag.setUserOLMId(userOLMId.trim());


		/*int Role = ReportsDaoObj
				.getRole(PyPostChequeDetailsObj.getParentUser());*/
		HashMap<Integer, List<PayPostingChequeDetails>> ReportsMap = new HashMap<Integer, List<PayPostingChequeDetails>>();
		int page = Integer.parseInt(request.getParameter("pageNum"));
		String errMsg = null;
		ModelAndView modelAndViewObj = new ModelAndView();
		reportslogger.info("Page No. :"+page);

		ReportsMap = ReportsDaoObj.getPaymntPostingChequeMapAps(
				PyPostChequeDetailsObjPag, page);

		if(ReportsMap==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentPostingChequeSearchAps");
			return modelAndViewObj;
		}
		reportslogger.info("Details Map size based on Page no. in Controller :"+ReportsMap.size());


		/*reportslogger.info("pagtn called in controller");

		reportslogger.info("status msg in controller"
				+ PyPostChequeDetailsObj.getStatusMsg());*/
		if(PyPostChequeDetailsObjPag.getStatusMsg()!=null)
		{

			if(PyPostChequeDetailsObjPag.getStatusMsg().equalsIgnoreCase("DATA FETCHED"))
			{
				errMsg="";
			}

			else
			{
				errMsg=PyPostChequeDetailsObjPag.getStatusMsg();
			}

		}
		else
			errMsg="Connectivity Issues..Retry..";

		modelAndViewObj.addObject("errMsg", errMsg);
		modelAndViewObj.addObject("ReportsMap", ReportsMap);
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("PyPostChequeDetailsObjJsp", PyPostChequeDetailsObjPag);
		modelAndViewObj.addObject("UserRole", Role);
		modelAndViewObj.setViewName("PaymentPostingChequeSearchAps");

		return modelAndViewObj;
	}

	@RequestMapping(value = "/ExcelofPayPostChequeDetailsAps", method = RequestMethod.POST)
	public ModelAndView PayPostChequeDetailsToExcelAps(HttpServletRequest request,HttpServletResponse response) 
	{
		ModelAndView modelAndViewObj = new ModelAndView();

		session=request.getSession(false);
		reportslogger.info("In Payment Posting Cheque Level Excel records Downlaod");
		PayPostingChequeDetails PyPostChequeDetailsObjExcel = new PayPostingChequeDetails();
		String parentUserId=session.getAttribute("userid").toString();
		reportslogger.info("Login User ID: " + parentUserId);
		PyPostChequeDetailsObjExcel.setParentUser(parentUserId);
		String sessionRole_string=session.getAttribute("user_role_id").toString();
		reportslogger.info("User Role in transLevelDefault mapping is:"+sessionRole_string);

		int Role=Integer.parseInt(sessionRole_string);
		String fromDate = request.getParameter("startDate");
		String toDate = request.getParameter("endDate");
		String chqNo = request.getParameter("chqNo");
		String userOLMId = request.getParameter("userId");
		String fileId = request.getParameter("fileId");
		String fileName = request.getParameter("fileName");
		String vendorId = request.getParameter("vendorId");
		reportslogger.info("From Date:" + fromDate);
		reportslogger.info(" To Date: " + toDate);
		reportslogger.info("Cheque No.: " + chqNo);
		reportslogger.info("User ID: " +userOLMId );
		reportslogger.info(" File ID: " +fileId );
		reportslogger.info(" File Name: " +fileName );
		reportslogger.info(" Vendor ID: " + vendorId);

		if (fromDate != "") {
			PyPostChequeDetailsObjExcel.setFromDate(fromDate);
		} else

			PyPostChequeDetailsObjExcel.setFromDate(null);

		if (toDate != "") {
			PyPostChequeDetailsObjExcel.setToDate(toDate);
		} else

			PyPostChequeDetailsObjExcel.setToDate(null);

		if (vendorId == null || vendorId.equals("")) {
			PyPostChequeDetailsObjExcel.setVendorId(null);
		} else
			PyPostChequeDetailsObjExcel.setVendorId(vendorId.trim());

		if (chqNo == null || chqNo.equals("")) {
			PyPostChequeDetailsObjExcel.setChqNo(null);
		} else
			PyPostChequeDetailsObjExcel.setChqNo(chqNo.trim());

		if (fileId == null || fileId.equals("")) {
			PyPostChequeDetailsObjExcel.setFileId(null);

		} else
			PyPostChequeDetailsObjExcel.setFileId(fileId.trim());

		if (fileName == null || fileName.equals("")) {
			PyPostChequeDetailsObjExcel.setFileName(null);
		} else
			PyPostChequeDetailsObjExcel.setFileName(fileName.trim());
		if (userOLMId == null || userOLMId.equals("")) {
			PyPostChequeDetailsObjExcel.setUserOLMId(null);
		} else
			PyPostChequeDetailsObjExcel.setUserOLMId(userOLMId.trim());


		String pageNum = null;

		List<PayPostingChequeDetails> PayPostChequeExportToExcelList = new ArrayList<PayPostingChequeDetails>();

		PayPostChequeExportToExcelList = ReportsDaoObj
				.getPyPostChequeDetailsListAps(PyPostChequeDetailsObjExcel, pageNum);

		if(PayPostChequeExportToExcelList==null){
			modelAndViewObj.addObject("errMsg", "Data Base Issues..Retry..");
			modelAndViewObj.addObject("UserRole", Role);
			modelAndViewObj.setViewName("PaymentPostingChequeSearchAps");
			return modelAndViewObj;
		}
		reportslogger.info("Excel Records list size in Controller: "+PayPostChequeExportToExcelList.size());

		int rowNumber = 1;
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("Payment_Posting_Cheque_Level");
		XSSFCell cell = null;
		XSSFRow row;
		XSSFCellStyle my_style = wb.createCellStyle();
		XSSFFont my_font=wb.createFont();
		my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		my_style.setFont(my_font);
		XSSFCellStyle rightAligned = wb.createCellStyle();
		rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);




		row = sheet.createRow(0);
		cell = row.createCell(0);
		cell.setCellValue("Cheque No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(1);
		cell.setCellValue("Bank Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(2);
		cell.setCellValue("Vendor ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(3);
		cell.setCellValue("Vendor Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(4);
		cell.setCellValue("Uploaded By(OLM ID)");
		cell.setCellStyle(my_style);

		cell = row.createCell(5);
		cell.setCellValue("File ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(6);
		cell.setCellValue("File Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(7);
		cell.setCellValue("Cheque Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(8);
		cell.setCellValue("Bank Account No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(9);
		cell.setCellValue("No. Of Accounts Posted");
		cell.setCellStyle(my_style);
		cell = row.createCell(10);
		cell.setCellValue("No. Of Invoices posted");
		cell.setCellStyle(my_style);
		cell = row.createCell(11);
		cell.setCellValue("Cheque Value");
		cell.setCellStyle(my_style);
		cell = row.createCell(12);
		cell.setCellValue("Uploaded Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(13);
		cell.setCellValue("Uploaded Time");
		cell.setCellStyle(my_style);
		cell = row.createCell(14);
		cell.setCellValue("Posting Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(15);
		cell.setCellValue("Posting Time");
		cell.setCellStyle(my_style);
		cell = row.createCell(16);
		cell.setCellValue("Cheque Date vs Uploaded Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(17);
		cell.setCellValue("Uploaded Date vs Posted Date");
		cell.setCellStyle(my_style);


		for (int i = 0; i < PayPostChequeExportToExcelList.size(); i++) {
			// reportslogger.info("i value"+i);
			PayPostingChequeDetails PyPostChequeDetailsObject = PayPostChequeExportToExcelList
					.get(i);

			row = sheet.createRow(rowNumber);
			cell = row.createCell(0);
			cell.setCellValue(PyPostChequeDetailsObject.getChqNo());
			//sheet.autoSizeColumn(0);

			cell = row.createCell(1);
			cell.setCellValue(PyPostChequeDetailsObject.getBankName());

			if ((PyPostChequeDetailsObject.getVendorId() == null)
					|| (PyPostChequeDetailsObject.getVendorId()
							.equalsIgnoreCase(""))
					|| (PyPostChequeDetailsObject.getVendorId()
							.equalsIgnoreCase("NA"))) {
				cell = row.createCell(2);
				cell.setCellValue("");
			} else {
				cell = row.createCell(2);
				cell.setCellValue(PyPostChequeDetailsObject.getVendorId());
			}
			cell.setCellStyle(rightAligned);
			if ((PyPostChequeDetailsObject.getVendorName() == null)
					|| (PyPostChequeDetailsObject.getVendorName()
							.equalsIgnoreCase(""))
					|| (PyPostChequeDetailsObject.getVendorName()
							.equalsIgnoreCase("NA"))) {
				cell = row.createCell(3);
				cell.setCellValue("");
			} else {
				cell = row.createCell(3);
				cell.setCellValue(PyPostChequeDetailsObject.getVendorName());
			}
			//sheet.autoSizeColumn(2);

			cell = row.createCell(4);
			cell.setCellValue(PyPostChequeDetailsObject.getUserOLMId());
			//sheet.autoSizeColumn(3);
			cell = row.createCell(5);
			cell.setCellValue(PyPostChequeDetailsObject.getFileId());
			cell.setCellStyle(rightAligned);
			cell = row.createCell(6);
			cell.setCellValue(PyPostChequeDetailsObject.getFileName());
			//sheet.autoSizeColumn(4);

			cell = row.createCell(7);
			cell.setCellValue(PyPostChequeDetailsObject.getDateOnChq());
			cell = row.createCell(8);
			cell.setCellValue(PyPostChequeDetailsObject.getBankAccNo());
			//sheet.autoSizeColumn(5);
			cell = row.createCell(9);
			cell.setCellValue(PyPostChequeDetailsObject.getNoOfAccPosted());
			//sheet.autoSizeColumn(6);

			cell = row.createCell(10);
			cell.setCellValue(PyPostChequeDetailsObject.getNoOfInvPosted());
			//sheet.autoSizeColumn(7);
			cell = row.createCell(11);
			cell.setCellValue(PyPostChequeDetailsObject.getChqVal());
			cell.setCellStyle(rightAligned);
			//sheet.autoSizeColumn(8);

			cell = row.createCell(12);
			cell.setCellValue(PyPostChequeDetailsObject.getChqUploadDt());
			//sheet.autoSizeColumn(9);
			cell = row.createCell(13);
			cell.setCellValue(PyPostChequeDetailsObject.getChqUploadTym());
			//sheet.autoSizeColumn(10);

			cell = row.createCell(14);
			cell.setCellValue(PyPostChequeDetailsObject.getPostingDate());
			//sheet.autoSizeColumn(11);
			cell = row.createCell(15);
			cell.setCellValue(PyPostChequeDetailsObject.getPostingTime());
			//sheet.autoSizeColumn(12);
			cell = row.createCell(16);
			cell.setCellValue(PyPostChequeDetailsObject.getDiffChqvsUpload());
			//sheet.autoSizeColumn(13);

			cell = row.createCell(17);
			cell.setCellValue(PyPostChequeDetailsObject.getDiffUploadvsPosted());
			//sheet.autoSizeColumn(14);
			rowNumber++;

		}
		for (int i = 0; i <= 17; i++) {
			sheet.autoSizeColumn(i);
		}
		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
		byte[] outArray = outByteStream.toByteArray();

		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
				.format(new Date());

		String fileName1 = "APS_Payment_Posting_Cheque_Level_"+ date + ".xlsx";
		//reportslogger.info("filename is" + fileName);

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName1);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
		} catch (IOException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}

		/* reportslogger.info("End of failure records download "); */

		return modelAndViewObj;

	}






}