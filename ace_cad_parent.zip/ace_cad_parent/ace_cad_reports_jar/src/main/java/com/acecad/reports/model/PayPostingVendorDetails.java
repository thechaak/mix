package com.acecad.reports.model;

import java.sql.Date;

public class PayPostingVendorDetails {

	private String parentUserId;
	private String vendorId;
	private String vendorName;
	private int totalRec;
	private int rejectedRecords;
	private String totalVal;
	private String refNo;
	private int recPostedFX;
	private String valuePostedFX;
	private int recPendingAtLIU;
	private String amountPendingAtLIU;
	private String fromDate;
	private String toDate;
	
	private String inProgressValue;
	private String rejectedValue;
	public String getInProgressValue() {
		return inProgressValue;
	}
	public void setInProgressValue(String inProgressValue) {
		this.inProgressValue = inProgressValue;
	}
	public String getRejectedValue() {
		return rejectedValue;
	}
	public void setRejectedValue(String rejectedValue) {
		this.rejectedValue = rejectedValue;
	}
	public String getValueDeletedAtLiu() {
		return valueDeletedAtLiu;
	}

	public void setValueDeletedAtLiu(String valueDeletedAtLiu) {
		this.valueDeletedAtLiu = valueDeletedAtLiu;
	}
	private String valueDeletedAtLiu;
	public int getRejectedRecords() {
		return rejectedRecords;
	}
	public void setRejectedRecords(int rejectedRecords) {
		this.rejectedRecords = rejectedRecords;
	}
	private String statusMsg;
	private String fileSource;
	private String accountNo;
	private String invoice;
	private int role;
	private int inProgressRecords;
	private int recDeletedAtLiu;
	public int getInProgressRecords() {
		return inProgressRecords;
	}
	public void setInProgressRecords(int inProgressRecords) {
		this.inProgressRecords = inProgressRecords;
	}
	public int getRecDeletedAtLiu() {
		return recDeletedAtLiu;
	}
	public void setRecDeletedAtLiu(int recDeletedAtLiu) {
		this.recDeletedAtLiu = recDeletedAtLiu;
	}
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}
	public String getParentUserId() {
		return parentUserId;
	}
	public void setParentUserId(String parentUserId) {
		this.parentUserId = parentUserId;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public int getTotalRec() {
		return totalRec;
	}
	public void setTotalRec(int totalRec) {
		this.totalRec = totalRec;
	}
	public String getTotalVal() {
		return totalVal;
	}
	public void setTotalVal(String totalVal) {
		this.totalVal = totalVal;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public int getRecPostedFX() {
		return recPostedFX;
	}
	public void setRecPostedFX(int recPostedFX) {
		this.recPostedFX = recPostedFX;
	}
	public String getValuePostedFX() {
		return valuePostedFX;
	}
	public void setValuePostedFX(String valuePostedFX) {
		this.valuePostedFX = valuePostedFX;
	}
	public int getRecPendingAtLIU() {
		return recPendingAtLIU;
	}
	public void setRecPendingAtLIU(int recPendingAtLIU) {
		this.recPendingAtLIU = recPendingAtLIU;
	}
	public String getAmountPendingAtLIU() {
		return amountPendingAtLIU;
	}
	public void setAmountPendingAtLIU(String amountPendingAtLIU) {
		this.amountPendingAtLIU = amountPendingAtLIU;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getStatusMsg() {
		return statusMsg;
	}
	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}
	public String getFileSource() {
		return fileSource;
	}
	public void setFileSource(String fileSource) {
		this.fileSource = fileSource;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getInvoice() {
		return invoice;
	}
	public void setInvoice(String invoice) {
		this.invoice = invoice;
	}
	public Date getFXpostingTime() {
		return FXpostingTime;
	}
	public void setFXpostingTime(Date fXpostingTime) {
		FXpostingTime = fXpostingTime;
	}
	public int getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(int trackingId) {
		this.trackingId = trackingId;
	}
	public int getTrackingIdServ() {
		return trackingIdServ;
	}
	public void setTrackingIdServ(int trackingIdServ) {
		this.trackingIdServ = trackingIdServ;
	}
	public String getReasonForLiuorFailure() {
		return reasonForLiuorFailure;
	}
	public void setReasonForLiuorFailure(String reasonForLiuorFailure) {
		this.reasonForLiuorFailure = reasonForLiuorFailure;
	}
	private Date FXpostingTime;
	private int trackingId;
	private int trackingIdServ;
	private String reasonForLiuorFailure;
	
	
	
	
	
}
