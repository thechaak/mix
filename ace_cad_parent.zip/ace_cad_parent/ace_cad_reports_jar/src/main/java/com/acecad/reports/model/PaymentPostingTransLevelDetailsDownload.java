package com.acecad.reports.model;

import java.sql.Date;

public class PaymentPostingTransLevelDetailsDownload {
	public String fileSource;

	public String refNo;
	public String vendorId;
	public String vendorName;
	public String userOlmId;
	public String fileId;
	public String fileName;
	public String mode;
	public String uplodedDateTime;
	private String approvedBy;
	private String approvedDate;
	public String getApprovedBy() {
		return approvedBy;
	}
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}
	public String getApprovedDate() {
		return approvedDate;
	}
	public void setApprovedDate(String approvedDate) {
		this.approvedDate = approvedDate;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getBankAccNo() {
		return bankAccNo;
	}
	public void setBankAccNo(String bankAccNo) {
		this.bankAccNo = bankAccNo;
	}
	private String lob;
	private String bankAccNo;
	public String getRefNo() {
		return refNo;
	}
	public String getFileSource() {
		return fileSource;
	}
	public void setFileSource(String fileSource) {
		this.fileSource = fileSource;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getUserOlmId() {
		return userOlmId;
	}
	public void setUserOlmId(String userOlmId) {
		this.userOlmId = userOlmId;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getUplodedDateTime() {
		return uplodedDateTime;
	}
	public void setUplodedDateTime(String uplodedDateTime) {
		this.uplodedDateTime = uplodedDateTime;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getInvoice() {
		return invoice;
	}
	public void setInvoice(String invoice) {
		this.invoice = invoice;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getFxPostingTime() {
		return fxPostingTime;
	}
	public void setFxPostingTime(String fxPostingTime) {
		this.fxPostingTime = fxPostingTime;
	}
	public String getTrackingid() {
		return trackingid;
	}
	public void setTrackingid(String trackingid) {
		this.trackingid = trackingid;
	}
	public String getTrackingServ() {
		return trackingServ;
	}
	public void setTrackingServ(String trackingServ) {
		this.trackingServ = trackingServ;
	}
	public String getReasonForLiuFailure() {
		return reasonForLiuFailure;
	}
	public void setReasonForLiuFailure(String reasonForLiuFailure) {
		this.reasonForLiuFailure = reasonForLiuFailure;
	}
	public String accountNumber;
	public String invoice;
	public String amount;
	public String status;
	public String fxPostingTime;
	public String trackingid;
	public String trackingServ;
	public String reasonForLiuFailure;

}
