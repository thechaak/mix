package com.acecad.reports.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import com.acecad.reports.daoImpl.PaymentICRMDaoImpl;
import com.acecad.reports.model.PaymentICRMBean;


public interface PaymentICRMDao {
	
	public HashMap<Integer, List<PaymentICRMBean>> paymentIcrmSearch(int pageNumber,PaymentICRMBean paymentICRMBeanObj,String userRole,String userId) throws SQLException;

   	public int getRoleType(String userId);
   	
    public List<String> icrmStatusDropDown(); 
   	
	public  String getDateTime();

	public PaymentICRMBean downloadIcrmFile(PaymentICRMBean paymentICRMDownloadObj,String extension,String pageNumber,String userRole,String userId) throws SQLException;


}
