package com.acecad.reports.model;

public class PaymentPostingModewiseBean {
	public int role;
	public String parentUserId;
	public String statusMsg;
	private int recDeletedAtLiu;
	private int inProgressRecords;
	private int RejectedRecords;
	public String getInProgressValue() {
		return inProgressValue;
	}
	public void setInProgressValue(String inProgressValue) {
		this.inProgressValue = inProgressValue;
	}
	public String getRejectedValue() {
		return rejectedValue;
	}
	public void setRejectedValue(String rejectedValue) {
		this.rejectedValue = rejectedValue;
	}
	private String valueDeletedAtLiu;
	private String inProgressValue;
	private String rejectedValue;


	
	 public int getRejectedRecords() {
		return RejectedRecords;
	}
	public void setRejectedRecords(int rejectedRecords) {
		RejectedRecords = rejectedRecords;
	}
	public String getStatusMsg() {
		return statusMsg;
	}
	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}
	public int getRecDeletedAtLiu() {
		return recDeletedAtLiu;
	}
	public void setRecDeletedAtLiu(int recDeletedAtLiu) {
		this.recDeletedAtLiu = recDeletedAtLiu;
	}
	public int getInProgressRecords() {
		return inProgressRecords;
	}
	public void setInProgressRecords(int inProgressRecords) {
		this.inProgressRecords = inProgressRecords;
	}
	public String getParentUserId() {
		return parentUserId;
	}
	public void setParentUserId(String parentUserId) {
		this.parentUserId = parentUserId;
	}
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}
	public String fromDate;
	 public String toDate;
	 public String mode;
	 public int totalRecords;
	 
	 public String totalValue;
	 public int recordsPostedToFx;
	 public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public int getTotalRecords() {
		return totalRecords;
	}
	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}
	public String getTotalValue() {
		return totalValue;
	}
	public void setTotalValue(String totalValue) {
		this.totalValue = totalValue;
	}
	public int getRecordsPostedToFx() {
		return recordsPostedToFx;
	}
	public void setRecordsPostedToFx(int recordsPostedToFx) {
		this.recordsPostedToFx = recordsPostedToFx;
	}
	public String getValuePostedToFx() {
		return valuePostedToFx;
	}
	public void setValuePostedToFx(String valuePostedToFx) {
		this.valuePostedToFx = valuePostedToFx;
	}
	public int getRecordsPendingAtLiu() {
		return recordsPendingAtLiu;
	}
	public void setRecordsPendingAtLiu(int recordsPendingAtLiu) {
		this.recordsPendingAtLiu = recordsPendingAtLiu;
	}
	public String getValuePendingAtLiu() {
		return valuePendingAtLiu;
	}
	public void setValuePendingAtLiu(String valuePendingAtLiu) {
		this.valuePendingAtLiu = valuePendingAtLiu;
	}
	public String getValueDeletedAtLiu() {
		return valueDeletedAtLiu;
	}
	public void setValueDeletedAtLiu(String valueDeletedAtLiu) {
		this.valueDeletedAtLiu = valueDeletedAtLiu;
	}
	public String valuePostedToFx;
	 public int recordsPendingAtLiu;
	 public String valuePendingAtLiu; 

}
