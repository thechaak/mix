package com.acecad.reports.model;

public class UserManagementUserLevel {
	private String parentUserId;
	private String childUserName;
	private String childOlmId;
	private String roleDesc;
	private String status;
	private String vendorId;
	private String emailId;
	private String contact;
	private String circle;
	private String applicableProcess;
	private String activeDate;
	private String inactiveDate;
	private int Role;
	private String statusMsg;
	
	
	public String getChildUserName() {
		return childUserName;
	}
	public void setChildUserName(String childUserName) {
		this.childUserName = childUserName;
	}
	public String getStatusMsg() {
		return statusMsg;
	}
	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}
	public String getParentUserId() {
		return parentUserId;
	}
	public void setParentUserId(String parentUserId) {
		this.parentUserId = parentUserId;
	}
	
	
	public String getChildOlmId() {
		return childOlmId;
	}
	public void setChildOlmId(String childOlmId) {
		this.childOlmId = childOlmId;
	}
	public String getRoleDesc() {
		return roleDesc;
	}
	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getApplicableProcess() {
		return applicableProcess;
	}
	public void setApplicableProcess(String applicableProcess) {
		this.applicableProcess = applicableProcess;
	}
	public String getActiveDate() {
		return activeDate;
	}
	public void setActiveDate(String activeDate) {
		this.activeDate = activeDate;
	}
	public String getInactiveDate() {
		return inactiveDate;
	}
	public void setInactiveDate(String inactiveDate) {
		this.inactiveDate = inactiveDate;
	}
	public int getRole() {
		return Role;
	}
	public void setRole(int role) {
		Role = role;
	}
	
}
