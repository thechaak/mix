package com.acecad.reports.daoImpl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.acecad.reports.dao.PaymentICRMDao;
import com.acecad.reports.model.PaymentICRMBean;

public class PaymentICRMDaoImpl implements PaymentICRMDao {
	
	
//private static Logger reportslogger =LogManager.getLogger("paymentAdviceLogger");

private static Logger reportslogger =LogManager.getLogger("reportsLogger");

	
	@Autowired
	private PlatformTransactionManager transactionManager;
	
	public void setTransactionManager(
		      PlatformTransactionManager transactionManager) {
		      this.transactionManager = transactionManager;
		   }
	
	public PaymentICRMDaoImpl(DataSource dataSource) {
		this.dataSource = dataSource;
		setTransactionManager(transactionManager);
	}

	private DataSource dataSource;
	Connection conn = null;
	ResultSet resultsetshowdetails = null;

	public PaymentICRMDaoImpl() {

	}
	
	
	public  String getDateTime() {
		Date today = (Date) Calendar.getInstance().getTime();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		return formatter.format(today);
	} 
	
	
	
	public int getRoleType(String userId)
	{
		int roleType=0;
		try 
		{
			reportslogger.info("Entered getRoleType method in PaymentICRMDaoImpl");

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			String functionCall = "{? = call GETUSERROLE(?)}";

			CallableStatement callableStatement = conn
					.prepareCall(functionCall);

			callableStatement.registerOutParameter(1, Types.INTEGER);
			callableStatement.setString(2, userId);
			callableStatement.execute();

			roleType = callableStatement.getInt(1);
			
				
				if (roleType == 0) 
		        {
					reportslogger.info("DB returning NULL values at getRoleType method in PaymentICRMDaoImpl");
				}
				
				else
				{
			     	roleType=callableStatement.getInt(1);
				    reportslogger.info("Role of the logged in user at getRoleType method in PaymentICRMDaoImpl:"+roleType);
				}
		}catch (Exception e) {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
			
				}
		finally{
			try {
				conn.close();
			} catch (SQLException e) {
				  StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					reportslogger.error(errors);
			}
		}
		
		reportslogger.info("executed getRoleType method in PaymentICRMDaoImpl");	

		return roleType; 
	}

	
	
   public List<String> icrmStatusDropDown() 
	{		
		List<String> icrmStatusList=new ArrayList<String>();
		
		try 
		{
			reportslogger.info("Entered icrmStatusDropDown method in PaymentICRMDaoImpl");

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();

			final String procedureCall = "{call ACE_CAD_ICRM_APS_STATUS(?,?,?)}";

			CallableStatement callableStatement = conn.prepareCall(procedureCall);
			
			callableStatement.registerOutParameter(1, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(2, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
		
		      String errorMsg=callableStatement.getString(3);
		      reportslogger.info("Error Message at icrmStatusDropDown method in PaymentICRMDaoImpl:"+errorMsg);
			  
			
			ResultSet icrmResultSet=(ResultSet) callableStatement.getObject(1);
			
			if (icrmResultSet == null) 
	        {
				reportslogger.info("DB returning NULL values at icrmStatusDropDown method in PaymentICRMDaoImpl");
			}
			else
			{
		       while(icrmResultSet.next())
		         {
		    	    icrmStatusList.add(icrmResultSet.getString(1));
			        // reportslogger.info("icrmStatusDropDown @ IMPL:"+icrmResultSet.getString(1));
		         }
			  reportslogger.info("Size of icrmStatusList at icrmStatusDropDown method in PaymentICRMDaoImpl:"+ icrmStatusList.size());
		  }
	}catch (Exception e) {
		  StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		}
	finally{
		try {
			conn.close();
		} catch (SQLException e) {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
				}
	}
		reportslogger.info("executed icrmStatusDropDown method in PaymentICRMDaoImpl");	
		return icrmStatusList ;
}
   
   
   
   public HashMap<Integer, List<PaymentICRMBean>> paymentIcrmSearch(int pageNumber,PaymentICRMBean paymentICRMBeanObj,String userRole,String userId) throws SQLException	
   {
		ResultSet resultsetdetails = null;
		HashMap<Integer, List<PaymentICRMBean>> icrmHashMap=new HashMap<Integer, List<PaymentICRMBean>>();
		CallableStatement callableStatement=null;
		List<PaymentICRMBean> icrmBeanListObj = new ArrayList<PaymentICRMBean>();
		try {

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			
			reportslogger.info("Entered paymentIcrmSearch method in PaymentICRMDaoImpl");

			final String procedureCall = "{call ACE_CAD_ICRM_TRANSFER_SEARCH1(?,?,?,?,?,?,?,?,?,?,?,?)}";

			callableStatement = conn.prepareCall(procedureCall);

			callableStatement.setString(1, paymentICRMBeanObj.getToDate());
			callableStatement.setString(2, paymentICRMBeanObj.getFromDate());
			callableStatement.setString(3, paymentICRMBeanObj.getSrNumber());
			callableStatement.setString(4, paymentICRMBeanObj.getAps_Status());	
			callableStatement.setString(5, paymentICRMBeanObj.getTransId_ChequeNum());

			callableStatement.setString(6, userId);
			callableStatement.setString(7, userRole);
			callableStatement.setInt(8, pageNumber);			
			
			reportslogger.info("To Date at paymentIcrmSearch method in PaymentICRMDaoImpl:"+ paymentICRMBeanObj.getToDate());
			reportslogger.info("From Date at paymentIcrmSearch method in PaymentICRMDaoImpl:"+ paymentICRMBeanObj.getFromDate());


			callableStatement.registerOutParameter(9, Types.INTEGER);
			callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(11,OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(12,OracleTypes.VARCHAR);
			

			callableStatement.executeUpdate();
           int totalPages=callableStatement.getInt(9);
           String errorMsg=callableStatement.getString(11);
           
           reportslogger.info("Error Message at paymentIcrmSearch method in PaymentICRMDaoImpl:"+errorMsg );
           paymentICRMBeanObj.setErrorMsg(errorMsg);
           
			resultsetdetails = (ResultSet) callableStatement.getObject(10);

			if (resultsetdetails == null) 
	        {
				reportslogger.info("DB returning NULL values at paymentIcrmSearch method in PaymentICRMDaoImpl");

			}
			
			else
			{
				while (resultsetdetails.next()) 
				 {
					PaymentICRMBean paymentICRMBeanObj1 = new PaymentICRMBean();

					paymentICRMBeanObj1.setSrNumber(resultsetdetails.getString("SR_NUMBER"));
					
					String date = resultsetdetails.getString("SR_CREATED_TIME");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date date1 = dateString.parse(date);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateString1.format(date1);
					paymentICRMBeanObj1
					.setSrCreatedDate(finalDate);
					
					
					
					
					
					
					paymentICRMBeanObj1.setAps_Status(resultsetdetails.getString("APS_SR_STATUS"));
					paymentICRMBeanObj1.setApprovedBy(resultsetdetails.getString("UPDATED_BY"));
					//reportslogger.info("updated date"+resultsetdetails.getString("UPDATED_DATE"));
					
					if(resultsetdetails.getString("UPDATED_DATE")==null||resultsetdetails.getString("UPDATED_DATE").equalsIgnoreCase("")||resultsetdetails.getString("UPDATED_DATE").equalsIgnoreCase("null"))
					{
						paymentICRMBeanObj1.setApprovedDate("");
					}
					else{
					String dateUpdated = resultsetdetails.getString("UPDATED_DATE");
					SimpleDateFormat dateStringUpdated = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date dateUpdated1 = dateStringUpdated.parse(dateUpdated);
					SimpleDateFormat dateStringUpdated1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDateUpdated = dateStringUpdated1.format(dateUpdated1);
					paymentICRMBeanObj1.setApprovedDate(finalDateUpdated);
					}
					//paymentICRMBeanObj1.setApprovedDate(resultsetdetails.getString("UPDATED_DATE"));
					paymentICRMBeanObj1.setAmount(resultsetdetails.getString("AMOUNT_NEW"));
					paymentICRMBeanObj1.setSourceAcctNum(resultsetdetails.getString("SOURCE_ACCOUNT_NUMBER_NEW"));
					paymentICRMBeanObj1.setDestAccNum(resultsetdetails.getString("DESTINATION_ACCOUNT_NUMBER_NEW"));
					paymentICRMBeanObj1.setBillDate(resultsetdetails.getString("BILL_DATE_NEW"));
					paymentICRMBeanObj1.setReasonForTransfer(resultsetdetails.getString("REASON_FOR_TRANSFER_NEW"));
					paymentICRMBeanObj1.setRemarks(resultsetdetails.getString("REMARKS"));
					paymentICRMBeanObj1.setPaymentMode(resultsetdetails.getString("PAYMENT_MODE_NEW"));
					
					if(resultsetdetails.getString("SOURCE_TRACKING_ID")==null||resultsetdetails.getString("SOURCE_TRACKING_ID").equalsIgnoreCase("")||resultsetdetails.getString("SOURCE_TRACKING_ID").equalsIgnoreCase("null"))
					{
						paymentICRMBeanObj1.setTrackingId("");
					}
					else
					paymentICRMBeanObj1.setTrackingId(resultsetdetails.getString("SOURCE_TRACKING_ID"));
					if(resultsetdetails.getString("SOURCE_TRACKING_ID_SERV")==null||resultsetdetails.getString("SOURCE_TRACKING_ID_SERV").equalsIgnoreCase("")||resultsetdetails.getString("SOURCE_TRACKING_ID_SERV").equalsIgnoreCase("null"))
					{
						paymentICRMBeanObj1.setTrackingIdServ("");
					}
					else
					paymentICRMBeanObj1.setTrackingIdServ(resultsetdetails.getString("SOURCE_TRACKING_ID_SERV"));
					paymentICRMBeanObj1.setTransId_ChequeNum(resultsetdetails.getString("REF_NUMBER_NEW"));
					paymentICRMBeanObj1.setChequeDate_bankName(resultsetdetails.getString("CHQ_DATE_BANK_NAME_NEW"));
					paymentICRMBeanObj1.setSr_Status(resultsetdetails.getString("SR_STATUS"));
					//paymentICRMBeanObj1.setRejectionReason(resultsetdetails.getString("REJECTION_REASON"));
					if(resultsetdetails.getString("POSTING_TRACKING_ID")==null||resultsetdetails.getString("POSTING_TRACKING_ID").equalsIgnoreCase("")||resultsetdetails.getString("POSTING_TRACKING_ID").equalsIgnoreCase("null"))
					{
						paymentICRMBeanObj1.setPostingTrackingId("");
					}
					else
					paymentICRMBeanObj1.setPostingTrackingId(resultsetdetails.getString("POSTING_TRACKING_ID"));
					if(resultsetdetails.getString("POSTING_TRACKING_ID_SERV")==null||resultsetdetails.getString("POSTING_TRACKING_ID_SERV").equalsIgnoreCase("")||resultsetdetails.getString("POSTING_TRACKING_ID_SERV").equalsIgnoreCase("null"))
					{
						paymentICRMBeanObj1.setPostingTrackingIdServ("");
					}
					else
					paymentICRMBeanObj1.setPostingTrackingIdServ(resultsetdetails.getString("POSTING_TRACKING_ID_SERV"));
					paymentICRMBeanObj1.setRecordType(resultsetdetails.getString("RECORD_TYPE"));
					if(resultsetdetails.getString("FX_POSTING_TIME")==null||resultsetdetails.getString("FX_POSTING_TIME").equalsIgnoreCase(""))
					{
						paymentICRMBeanObj1.setFxPostingTime("");
					}
					else{
					String datePosting = resultsetdetails.getString("FX_POSTING_TIME");
					SimpleDateFormat dateStringPosting = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date datePosting1 = dateStringPosting.parse(datePosting);
					SimpleDateFormat dateStringPosting1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDatePosting = dateStringPosting1.format(datePosting1);
					paymentICRMBeanObj1.setFxPostingTime(finalDatePosting);
					}

					
					icrmBeanListObj.add(paymentICRMBeanObj1);
                }				
			}
			
			icrmHashMap.put(totalPages,icrmBeanListObj);
			
			reportslogger.info("Size of icrmHashMap at paymentIcrmSearch method in PaymentICRMDaoImpl:"+ icrmHashMap.size());
			
		} catch (SQLException e) 
	     {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
		return null;
	     }
	catch(Exception e)
	{
		  StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			reportslogger.error(errors);
		return null;
	}
	           finally{
	        	   
			    	if(resultsetdetails!=null){
			 	     	   try {
			 	     		 resultsetdetails.close();
			 				} catch (Exception e) {
			 					  StringWriter errors= new StringWriter();
			 						e.printStackTrace(new PrintWriter(errors));
			 						reportslogger.error(errors);
			 				}
			 	     	   }
			 		
			 		if(callableStatement!=null){
			 	     	   try {
			 	     		  callableStatement.close();
			 				} catch (Exception e) {
			 					  StringWriter errors= new StringWriter();
			 						e.printStackTrace(new PrintWriter(errors));
			 						reportslogger.error(errors);
			 				}
			 	     	   }
	        	   
	        	   if(conn!=null){
	        	   try {
					conn.close();
				} catch (Exception e) {
					  StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
				}
	        	   }
	           }
		reportslogger.info("executed paymentIcrmSearch method in PaymentICRMDaoImpl");
     return icrmHashMap;
      
	}
   

   
   public PaymentICRMBean downloadIcrmFile(PaymentICRMBean paymentICRMDownloadObj,String extension,String pageNumber,String userRole,String userId) throws SQLException
  	{
  		
  		ResultSet resultsetdetails = null;
  		CallableStatement callableStatement=null;
  		int i=1;
  		
  		try {

  			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
  			conn = jdbcTemplate.getDataSource().getConnection();
  			reportslogger.info("Entered downloadIcrmFile method in PaymentICRMDaoImpl");

  			final String procedureCall = "{call ACE_CAD_ICRM_TRANSFER_SEARCH1(?,?,?,?,?,?,?,?,?,?,?,?)}";

			callableStatement = conn.prepareCall(procedureCall);

			callableStatement.setString(1, paymentICRMDownloadObj.getToDate());
			callableStatement.setString(2, paymentICRMDownloadObj.getFromDate());
			callableStatement.setString(3, paymentICRMDownloadObj.getSrNumber());
			callableStatement.setString(4, paymentICRMDownloadObj.getAps_Status());	
			callableStatement.setString(5, paymentICRMDownloadObj.getTransId_ChequeNum());
			callableStatement.setString(6, userId);
			callableStatement.setString(7, userRole);
			callableStatement.setString(8, pageNumber);			

			callableStatement.registerOutParameter(9, Types.INTEGER);
			callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(11,OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(12,OracleTypes.VARCHAR);
			

			callableStatement.executeUpdate();
           int totalPages=callableStatement.getInt(9);
           String errorMsg=callableStatement.getString(11);
           
           reportslogger.info("Error Message at downloadIcrmFile method in PaymentICRMDaoImpl:"+errorMsg );
           reportslogger.info("Ttoatal no. of pages at downloadIcrmFile method:"+totalPages);
           paymentICRMDownloadObj.setErrorMsg(errorMsg);
           
			resultsetdetails = (ResultSet) callableStatement.getObject(10);

  			if (resultsetdetails == null) 
  	        {
  				reportslogger.info("DB returning NULL values at downloadIcrmFile method in PaymentICRMDaoImpl");
  			}
  			
  			FileOutputStream downloadFile = null;
  			
  			try 
  			{
  				downloadFile = new FileOutputStream(new File("APS_ICRM_PAYMENT_TRANSFER_LEVEL_"+getDateTime()+"."+extension));
  			
  			XSSFWorkbook workbook = new XSSFWorkbook();
  			XSSFSheet worksheet = workbook.createSheet("TRANSFER ICRM REPORTS");
  			XSSFRow row=null;
  			row = worksheet.createRow(0);
  			//HSSFCellStyle cellStyle = workbook.createCellStyle();
  			
  			XSSFCellStyle my_style = workbook.createCellStyle();
			 XSSFFont my_font=workbook.createFont();
			 my_font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
			 my_style.setFont(my_font);
			 
			 XSSFCellStyle rightAligned = workbook.createCellStyle();
			 rightAligned.setAlignment(XSSFCellStyle.ALIGN_RIGHT);
  			
  			Cell cellA1 = row.createCell((short) 0);
  			cellA1.setCellValue("SR Number");
			cellA1.setCellStyle(my_style);
			
			Cell cellAA1 = row.createCell((short) 1);
  			cellAA1.setCellValue("SR Created Date");
			cellAA1.setCellStyle(my_style);

  			Cell cellB1 = row.createCell((short) 2);
  			cellB1.setCellValue("Source Account No.");
			cellB1.setCellStyle(my_style);

  			Cell cellC1 = row.createCell((short) 3);
  			cellC1.setCellValue("Destination Account No.");
			cellC1.setCellStyle(my_style);

  			Cell cellD1 = row.createCell((short) 4);
  			cellD1.setCellValue("Bill Date");
			cellD1.setCellStyle(my_style);

  			Cell cellE1 = row.createCell((short) 5);
  			cellE1.setCellValue("Amount");
			cellE1.setCellStyle(my_style);

  			Cell cellF1 = row.createCell((short) 6);
  			cellF1.setCellValue("Reason For Transfer");
			cellF1.setCellStyle(my_style);

  	        Cell cellG1 = row.createCell((short) 7);
  			cellG1.setCellValue("Transaction ID/ Cheque Number");
			cellG1.setCellStyle(my_style);

  			Cell cellH1 = row.createCell((short) 8);
  			cellH1.setCellValue("Cheque Date/Bank Name");
  			//celStyle = workbook.createCellStyle();
			cellH1.setCellStyle(my_style);

  			Cell cellI1 = row.createCell((short) 9);
  			cellI1.setCellValue("Payment Mode");
			cellI1.setCellStyle(my_style);

  			Cell cellJ1 = row.createCell((short) 10);
  			cellJ1.setCellValue("Source Tracking ID");
			cellJ1.setCellStyle(my_style);

  			Cell cellK1 = row.createCell((short) 11);
  			cellK1.setCellValue("Source Tracking ID Serv");
			cellK1.setCellStyle(my_style);
			
			Cell cellKk1 = row.createCell((short) 12);
  			cellKk1.setCellValue("Record Type");
			cellKk1.setCellStyle(my_style);
			
			Cell cellN1 = row.createCell((short) 13);
  			cellN1.setCellValue("Approved/Rejected By(OLM ID)");
  			cellN1.setCellStyle(my_style);

  			Cell cellO1 = row.createCell((short) 14);
  			cellO1.setCellValue("Approved/Rejected Date");
  			cellO1.setCellStyle(my_style);
  			
  			Cell cellP1 = row.createCell((short) 15);
  			cellP1.setCellValue("SR Status(APS)");
  			cellP1.setCellStyle(my_style);

  			Cell cellQ1 = row.createCell((short) 16);
  			cellQ1.setCellValue("SR Task Status(ICRM)");
  			cellQ1.setCellStyle(my_style);
  			
  			Cell cellLl1 = row.createCell((short) 17);
			cellLl1.setCellValue("FX Posting Time");
			cellLl1.setCellStyle(my_style);
  			
  			Cell cellL1 = row.createCell((short) 18);
			cellL1.setCellValue("Posting Tracking ID");
			cellL1.setCellStyle(my_style);
			
	          Cell cellM1 = row.createCell((short) 19);
  			cellM1.setCellValue("Posting Tracking ID Serv");
  			cellM1.setCellStyle(my_style);
		
  			Cell cellR1 = row.createCell((short) 20);
  			cellR1.setCellValue("Rejection/Failure Remarks");
  			cellR1.setCellStyle(my_style);

  			

  			
  		
  			
  			
  if(resultsetdetails!=null){
  				while (resultsetdetails.next()) {
  					//reportslogger.info("invoice number is " +resultsetdetails.getString("invoice_no"));
  					//error_code = resultsetdetails.getString("error_reason_code");
  				
  				//	fileObj.setErrorReasonCode(error_code);
  					PaymentICRMBean icrmObj=new PaymentICRMBean();
  					
  					icrmObj.setSrNumber(resultsetdetails.getString("SR_NUMBER"));
					
					String date = resultsetdetails.getString("SR_CREATED_TIME");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date date1 = dateString.parse(date);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateString1.format(date1);
					icrmObj
					.setSrCreatedDate(finalDate);
					
					
					
					
					
					
					icrmObj.setAps_Status(resultsetdetails.getString("APS_SR_STATUS"));
					icrmObj.setApprovedBy(resultsetdetails.getString("UPDATED_BY"));
					//reportslogger.info("updated date"+resultsetdetails.getString("UPDATED_DATE"));
					
					if(resultsetdetails.getString("UPDATED_DATE")==null||resultsetdetails.getString("UPDATED_DATE").equalsIgnoreCase("")||resultsetdetails.getString("UPDATED_DATE").equalsIgnoreCase("null"))
					{
						icrmObj.setApprovedDate("");
					}
					else{
					String dateUpdated = resultsetdetails.getString("UPDATED_DATE");
					SimpleDateFormat dateStringUpdated = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date dateUpdated1 = dateStringUpdated.parse(dateUpdated);
					SimpleDateFormat dateStringUpdated1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDateUpdated = dateStringUpdated1.format(dateUpdated1);
					icrmObj.setApprovedDate(finalDateUpdated);
					}
					//paymentICRMBeanObj1.setApprovedDate(resultsetdetails.getString("UPDATED_DATE"));
					icrmObj.setAmount(resultsetdetails.getString("AMOUNT_NEW"));
					icrmObj.setSourceAcctNum(resultsetdetails.getString("SOURCE_ACCOUNT_NUMBER_NEW"));
					icrmObj.setDestAccNum(resultsetdetails.getString("DESTINATION_ACCOUNT_NUMBER_NEW"));
					icrmObj.setBillDate(resultsetdetails.getString("BILL_DATE_NEW"));
					icrmObj.setReasonForTransfer(resultsetdetails.getString("REASON_FOR_TRANSFER_NEW"));
					icrmObj.setRemarks(resultsetdetails.getString("REMARKS"));
					icrmObj.setPaymentMode(resultsetdetails.getString("PAYMENT_MODE_NEW"));
					
					if(resultsetdetails.getString("SOURCE_TRACKING_ID")==null||resultsetdetails.getString("SOURCE_TRACKING_ID").equalsIgnoreCase("")||resultsetdetails.getString("SOURCE_TRACKING_ID").equalsIgnoreCase("null"))
					{
						icrmObj.setTrackingId("");
					}
					else
						icrmObj.setTrackingId(resultsetdetails.getString("SOURCE_TRACKING_ID"));
					if(resultsetdetails.getString("SOURCE_TRACKING_ID_SERV")==null||resultsetdetails.getString("SOURCE_TRACKING_ID_SERV").equalsIgnoreCase("")||resultsetdetails.getString("SOURCE_TRACKING_ID_SERV").equalsIgnoreCase("null"))
					{
						icrmObj.setTrackingIdServ("");
					}
					else
						icrmObj.setTrackingIdServ(resultsetdetails.getString("SOURCE_TRACKING_ID_SERV"));
					icrmObj.setTransId_ChequeNum(resultsetdetails.getString("REF_NUMBER_NEW"));
					icrmObj.setChequeDate_bankName(resultsetdetails.getString("CHQ_DATE_BANK_NAME_NEW"));
					icrmObj.setSr_Status(resultsetdetails.getString("SR_STATUS"));
					//paymentICRMBeanObj1.setRejectionReason(resultsetdetails.getString("REJECTION_REASON"));
					if(resultsetdetails.getString("POSTING_TRACKING_ID")==null||resultsetdetails.getString("POSTING_TRACKING_ID").equalsIgnoreCase("")||resultsetdetails.getString("POSTING_TRACKING_ID").equalsIgnoreCase("null"))
					{
						icrmObj.setPostingTrackingId("");
					}
					else
						icrmObj.setPostingTrackingId(resultsetdetails.getString("POSTING_TRACKING_ID"));
					if(resultsetdetails.getString("POSTING_TRACKING_ID_SERV")==null||resultsetdetails.getString("POSTING_TRACKING_ID_SERV").equalsIgnoreCase("")||resultsetdetails.getString("POSTING_TRACKING_ID_SERV").equalsIgnoreCase("null"))
					{
						icrmObj.setPostingTrackingIdServ("");
					}
					else
						icrmObj.setPostingTrackingIdServ(resultsetdetails.getString("POSTING_TRACKING_ID_SERV"));
					icrmObj.setRecordType(resultsetdetails.getString("RECORD_TYPE"));
					if(resultsetdetails.getString("FX_POSTING_TIME")==null||resultsetdetails.getString("FX_POSTING_TIME").equalsIgnoreCase(""))
					{
						icrmObj.setFxPostingTime("");
					}
					else{
					String datePosting = resultsetdetails.getString("FX_POSTING_TIME");
					SimpleDateFormat dateStringPosting = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date datePosting1 = dateStringPosting.parse(datePosting);
					SimpleDateFormat dateStringPosting1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDatePosting = dateStringPosting1.format(datePosting1);
					icrmObj.setFxPostingTime(finalDatePosting);
					}
					

					

  			
  						 row = worksheet.createRow(i);
  						 
  						 

  						XSSFCell cellA2 = row.createCell((short) 0);
  						cellA2.setCellValue(icrmObj.getSrNumber());
  						cellA2.setCellStyle(rightAligned);
  						 
  						XSSFCell cellAA2 = row.createCell((short) 1);
  						cellAA2.setCellValue(icrmObj.getSrCreatedDate());
  						
  						 
  						XSSFCell cellB2 = row.createCell((short) 2);
  						cellB2.setCellValue(icrmObj.getSourceAcctNum());
  						
  						XSSFCell cellC2 = row.createCell((short) 3);
  						cellC2.setCellValue(icrmObj.getDestAccNum());
  						
  						
  						XSSFCell cellD2 = row.createCell((short) 4);
  						cellD2.setCellValue(icrmObj.getBillDate());
  						
  						XSSFCell cellE2 = row.createCell((short) 5);
  						cellE2.setCellValue(icrmObj.getAmount());
  						cellE2.setCellStyle(rightAligned);
  						
  						XSSFCell cellF2 = row.createCell((short) 6);
  						cellF2.setCellValue(icrmObj.getReasonForTransfer());
  						
  						XSSFCell cellG2 = row.createCell((short) 7);
  						cellG2.setCellValue(icrmObj.getTransId_ChequeNum());

  						XSSFCell cellH2 = row.createCell((short) 8);
  						cellH2.setCellValue(icrmObj.getChequeDate_bankName());
  			
  						XSSFCell cellI2 = row.createCell((short) 9);
  						cellI2.setCellValue(icrmObj.getPaymentMode());
  						
  						XSSFCell cellJ2 = row.createCell((short) 10);
  						cellJ2.setCellValue(icrmObj.getTrackingId());
  						cellJ2.setCellStyle(rightAligned);
  						
  						XSSFCell cellK2 = row.createCell((short) 11);
  						cellK2.setCellValue(icrmObj.getTrackingIdServ());
  						cellK2.setCellStyle(rightAligned);
  						
  						XSSFCell cellKk2 = row.createCell((short) 12);
  						cellKk2.setCellValue(icrmObj.getRecordType());
  						cellKk2.setCellStyle(rightAligned);
  						
  						XSSFCell cellN2 = row.createCell((short) 13);
  						cellN2.setCellValue(icrmObj.getApprovedBy());
  						
  						XSSFCell cellO2 = row.createCell((short) 14);
  						cellO2.setCellValue(icrmObj.getApprovedDate());
  						
  						XSSFCell cellP2 = row.createCell((short) 15);
  						cellP2.setCellValue(icrmObj.getAps_Status());

  						XSSFCell cellQ2 = row.createCell((short) 16);
  						cellQ2.setCellValue(icrmObj.getSr_Status());
  						
  						XSSFCell cellLl2 = row.createCell((short) 17);
  						cellLl2.setCellValue(icrmObj.getFxPostingTime());
  						
  						
  						XSSFCell cellL2 = row.createCell((short) 18);
  						cellL2.setCellValue(icrmObj.getPostingTrackingId());
  						cellL2.setCellStyle(rightAligned);
  						
  						XSSFCell cellM2 = row.createCell((short) 19);
  						cellM2.setCellValue(icrmObj.getPostingTrackingIdServ());
  						cellM2.setCellStyle(rightAligned);
  						
  						XSSFCell cellR2 = row.createCell((short) 20);
  						cellR2.setCellValue(icrmObj.getRemarks());
  			            
  			        
  					
  			            i++;
  					
  					} 

  				for(int j=0;j<20;j++)
				{
					worksheet.autoSizeColumn(j);
					
				}
  				    try {
  						workbook.write(downloadFile);
  						  downloadFile.flush();
  						    downloadFile.close();
  					} catch (IOException e) {
  					  StringWriter errors= new StringWriter();
  					e.printStackTrace(new PrintWriter(errors));
  					reportslogger.error(errors);
					return null;

  					}
            }				  
  				    
  		}catch (FileNotFoundException e) {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
				return null;
		}
		catch (Exception e) {
			  StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				reportslogger.error(errors);
				return null;

		}
  	
  	}    finally{
  		
  		if(resultsetdetails!=null){
	     	   try {
	     		 resultsetdetails.close();
				} catch (Exception e) {
					  StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
				}
	     	   }
		
		if(callableStatement!=null){
	     	   try {
	     		  callableStatement.close();
				} catch (Exception e) {
					  StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						reportslogger.error(errors);
				}
	     	   }
  		
  		        	 if(conn!=null)
  		        	 {
  		        	       try {
  						conn.close();
  					           } 
  		        	       catch (Exception e) {
  		        	    	  StringWriter errors= new StringWriter();
  		        			e.printStackTrace(new PrintWriter(errors));
  		        			reportslogger.error(errors);
  		        			}
  		        	   }
  		           }
  				
		reportslogger.info("executed downloadIcrmFile method in PaymentICRMDaoImpl");

  		return paymentICRMDownloadObj;   
  	}
   
   
   

}
