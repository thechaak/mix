package com.acecad.reports.model;

public class CheckedSR {
private String oldRecord;

public String getOldRecord() {
	return oldRecord;
}

public void setOldRecord(String oldRecord) {
	this.oldRecord = oldRecord;
}
}
