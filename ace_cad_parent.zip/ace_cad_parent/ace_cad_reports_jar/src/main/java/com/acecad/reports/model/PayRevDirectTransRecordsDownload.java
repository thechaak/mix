package com.acecad.reports.model;

import java.sql.Date;

public class PayRevDirectTransRecordsDownload {

	private String accountNumber;
	private String uploadedByOlmId;
	private String uploadedByName;
	private String fileId;
	private String fileName;
	private String status;
	private String reasonForFailue;
	private String uploadDateTime;
	private String fxUpdateTime;
	private String trackingId;
	private String trackingIdServ;
	private String parentUserId;
	private String childUserId;
	private String vendorId;
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getUploadedByOlmId() {
		return uploadedByOlmId;
	}
	public void setUploadedByOlmId(String uploadedByOlmId) {
		this.uploadedByOlmId = uploadedByOlmId;
	}
	public String getUploadedByName() {
		return uploadedByName;
	}
	public void setUploadedByName(String uploadedByName) {
		this.uploadedByName = uploadedByName;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getReasonForFailue() {
		return reasonForFailue;
	}
	public void setReasonForFailue(String reasonForFailue) {
		this.reasonForFailue = reasonForFailue;
	}
	public String getUploadDateTime() {
		return uploadDateTime;
	}
	public void setUploadDateTime(String uploadDateTime) {
		this.uploadDateTime = uploadDateTime;
	}
	public String getFxUpdateTime() {
		return fxUpdateTime;
	}
	public void setFxUpdateTime(String fxUpdateTime) {
		this.fxUpdateTime = fxUpdateTime;
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	public String getTrackingIdServ() {
		return trackingIdServ;
	}
	public void setTrackingIdServ(String trackingIdServ) {
		this.trackingIdServ = trackingIdServ;
	}
	public String getParentUserId() {
		return parentUserId;
	}
	public void setParentUserId(String parentUserId) {
		this.parentUserId = parentUserId;
	}
	public String getChildUserId() {
		return childUserId;
	}
	public void setChildUserId(String childUserId) {
		this.childUserId = childUserId;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	private String fromDate;
	private String toDate;
	public String getStatusMsg() {
		return statusMsg;
	}
	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}
	public int getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	private String statusMsg;
	private int totalPages;




}
