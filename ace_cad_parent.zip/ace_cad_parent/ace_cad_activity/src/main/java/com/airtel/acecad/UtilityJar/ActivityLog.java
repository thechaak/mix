package com.airtel.acecad.UtilityJar;

import java.sql.CallableStatement;
import java.sql.Connection;


import java.sql.Types;

import javax.sql.DataSource;






import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;







import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;


//import com.acecad.util.Writeexcel;


public class ActivityLog {
	
	@Autowired
	private PlatformTransactionManager transactionManager;
	private static Logger logger =LogManager.getLogger("activityLogger");

	 DataSource dataSource;
		final long startTime = System.nanoTime();

		public ActivityLog()
		{
			
		}
		public ActivityLog(DataSource dataSource) {
			this.dataSource = dataSource;
			setTransactionManager(transactionManager);
		}
		public void setTransactionManager(
			      PlatformTransactionManager transactionManager) {
			      this.transactionManager = transactionManager;
			   }
	
	public Long insertActivityLog(Long SNo,String userID,String activity_desc,String status,String remarks,String fileName,String totalCount,String totalValue) throws SQLException
	{
		 Connection conn = null;
	//	System.out.println("entered into updateLog..@DAOIMPL ");
		 
		 TransactionDefinition def = new DefaultTransactionDefinition();
		    TransactionStatus tstatus = transactionManager.getTransaction(def);
		try {
			
			
			//System.out.println("connect"+ "ion:" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			conn.setAutoCommit(false);
		//	System.out.println("connection established in update method!!");
			
			final String procedureCall = "{call ACE_CAD_ACTIVITY_LOG_PKG.USER_ACTIVITYLOG_PROC1(?,?,?,?,?,?,?,?)}";
			
			CallableStatement callableStatement = conn.prepareCall(procedureCall);

		//	System.out.println("ENTERED INTO callable statements..@IMPL");
			callableStatement.registerOutParameter(1, Types.BIGINT);
			callableStatement.setLong(1, SNo);
		
			callableStatement.setString(2,userID );
			callableStatement.setString(3, activity_desc);
			callableStatement.setString(4, status);	
			callableStatement.setString(5,remarks);
			callableStatement.setString(6, fileName);
			callableStatement.setString(7,totalCount);
			callableStatement.setString(8,totalValue);
			
			//System.out.println("callable statements executed..@IMPL");
			
			
			
			callableStatement.executeUpdate();
			SNo=callableStatement.getLong(1);
			
			//System.out.println(("status is:"+callableStatement.getString(6)));
			//System.out.println(fileId);
			//System.out.println(("flag is:"+callableStatement.getString(7)));
			
		//System.out.println("executed update log method@DAOIMPL");
			transactionManager.commit(tstatus);
			conn.commit();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			transactionManager.rollback(tstatus);
			e.printStackTrace();
		}
		   catch (Exception e) {
				transactionManager.rollback(tstatus);
				e.printStackTrace();
			//	return 0;

			}
		 finally
			{
				try {
					//dataSource.getConnection().close();
					conn.close();
					logger.info("connection Close:");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} 

		
		return SNo;
	
	}
	
	
	
	
	
}
