package com.airtel.acecad.client;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.codec.binary.Base64;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.airtel.acecad.client.dao.ClientDAO;
import com.airtel.acecad.client.dao.ClientDAOImpl;
import com.airtel.acecad.client.dto.NrcDetails;
import com.airtel.acecad.client.dto.PostPaymentToFXRequest;
import com.airtel.acecad.client.json.CustomerAccountSummaryJson.MyResponsePojo;
import com.airtel.acecad.client.json.invoicePaymentJson.Fault;
import com.airtel.acecad.client.json.invoicePaymentJson.PostMyPojo;
import com.airtel.acecad.client.json.invoicePaymentJson.PostPartyResponse;
import com.airtel.acecad.client.json.invoicePaymentJson.PostPaymentResMsg;
import com.airtel.acecad.client.json.nrcDetailsV5.CustomerNrcDetailsResponse;
import com.airtel.acecad.client.json.nrcDetailsV5.DataArea;
import com.airtel.acecad.client.json.nrcDetailsV5.NrcDetail;
import com.airtel.acecad.client.json.nrcDetailsV5.SoaFault;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.CustomResponseErrorHandler;
import com.airtel.acecad.client.util.EncryDecrypUtility;
import com.airtel.acecad.client.util.GenericConfiguration;
import com.airtel.acecad.client.util.GlobalConstants;
import com.fasterxml.jackson.databind.ObjectMapper;

public class GetCustomerNrcDetailsClientV5 implements GlobalConstants {

private static final ObjectMapper mapper = new ObjectMapper();
private static Logger logger = LogManager.getLogger("serviceClientUI");
	public List<NrcDetail> getNrcDetails(String extAccNo,String mobileNo) throws Exception {
		RestTemplate restTemplate = new RestTemplate();
		NrcDetails nrcData =null;
		List<NrcDetail> nrcList =null;
		String result ="";
		String status_code = EMPTY_STRING;
		SoaFault soaFault =null;
		String domain="B2C";
		String lob="Mobility";
		String subLob="Postpaid";
		String consumerTransactionId="11343";
		String consumerName="APS";
		String programmeName="EAIMigration";
		String customerMigrated="false";
		//String AccountNumber="1270273342";
		//String id="9740232322";
		String paymentFromDate="";
		String paymentToDate="";
		String typeIdNrc="";
		logger.info("START----in getNrcDetails method  formation of Rest client of GetCustomerNrcDetailsClientV5");
		ClientDAO dao = new ClientDAOImpl();
		List<NrcDetails> nrc = dao.fetchNrcDetailsByAccOrMob(extAccNo, mobileNo);
		try {
			String userpass = GenericConfiguration.getDescription("kenon.postPaymentToFX.userName") + ":"
					+ EncryDecrypUtility.decrypt(GenericConfiguration.getDescription("kenon.postPaymentToFX.password"));

			String clientURL = GenericConfiguration.getDescription("kenon.postCustomerNrcDetailsV5.url") 
					+"domain="+domain+"&lob="+lob+"&subLob="+subLob+"&consumerTransactionId="+consumerTransactionId+"&consumerName="+
					consumerName+"&programmeName="+programmeName+"&customerMigrated="+customerMigrated+
					"&AccountNumber="+extAccNo+"&id="+mobileNo+"&typeIdNrc="+typeIdNrc+"&serviceType=MSISDN";
			
			restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
			HttpHeaders headers = new HttpHeaders();

			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
					.setConnectTimeout(Integer.parseInt(GenericConfiguration.getDescription("connect_time_out")));

			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
					.setReadTimeout(Integer.parseInt(GenericConfiguration.getDescription("read_time_out")));

			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
			restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
			restTemplate.setErrorHandler(new CustomResponseErrorHandler());

			
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));

			HttpEntity<String> entity = new HttpEntity<>(headers);
			ResponseEntity<CustomerNrcDetailsResponse> responsePojo = null;
			responsePojo = restTemplate.exchange(clientURL, HttpMethod.GET, entity, CustomerNrcDetailsResponse.class);
			logger.info("responsePojo getNrcDetails---" + responsePojo);
			
			logger.info("responsePojo--->>" + responsePojo.getBody());

			logger.info("responsePojo getNrcDetails--->" + responsePojo);

			if (responsePojo != null) {
				if (HttpStatus.OK == responsePojo.getStatusCode()) {
					if (responsePojo.getBody().getEbmHeader() != null && responsePojo.getBody().getDataArea() != null) {
						logger.info("success--getNrcDetails--->>" + responsePojo.getBody());

					} else {
						status_code = responsePojo.getStatusCode().toString();
						soaFault = responsePojo.getBody().getSoaFault();
						logger.info("faultResponsePojo getNrcDetails -->>"
								+ responsePojo.getBody().getSoaFault());
					}
				}

				else {
					status_code = responsePojo.getStatusCode().toString();
					soaFault = responsePojo.getBody().getSoaFault();
					logger.info("faultResponsePojo getNrcDetails -->>"
							+ responsePojo.getBody().getSoaFault());
					
				}
				logger.info("BEFORE create responsegetNrcDetails  in getNrcDetails ");
				 nrcList= createResponseJSONForGetCustomerNrcDetails(responsePojo, status_code, soaFault,clientURL,extAccNo);
				logger.info("AFTER createResponseJSONForGetNRCDetails  in postCustAccountSummaryToFX ");
			} else {
				logger.info("IN method  createResponseJSONForGetNRCDetails response pojo is null");
			}

			
		} catch (Exception e) {
			logger.info("Got error in the response of FX  pTransactionId getNrcDetails-->"
					, e);
			
		}

		logger.info("END--->in getNrcDetails method of GetCustomerNrcDetailsClientV5");
		return nrcList;
		
	}
	private List<NrcDetail> createResponseJSONForGetCustomerNrcDetails(
			ResponseEntity<CustomerNrcDetailsResponse> responsePojo, String status_code, SoaFault soaFault,String clientURL,String accNo) {
		String consumerTransactionId="";
		List<NrcDetail> nrcDetailList =null;
		if(responsePojo!=null){
			if(responsePojo.getBody().getEbmHeader()!=null){
				consumerTransactionId =CommonUtil.isNotNull(responsePojo.getBody().getEbmHeader().getConsumerTransactionId()) ? responsePojo.getBody().getEbmHeader().getConsumerTransactionId() :"";
			}
			if(responsePojo.getBody().getDataArea()!=null){
				DataArea dataArea = responsePojo.getBody().getDataArea();
				if(dataArea.getGetCustomerNrcDetailsResponse()!=null){
					if(dataArea.getGetCustomerNrcDetailsResponse().getNrcDetails()!=null)
						 nrcDetailList =dataArea.getGetCustomerNrcDetailsResponse().getNrcDetails();
				}
			}
			
		}
		ClientDAO dao = new ClientDAOImpl();
		String statusCod = status_code=="200"?"SUCCESS":"FAILED";
		try{
			dao.insertFxLog(accNo, null, clientURL, mapper.writeValueAsString(responsePojo), null, null, "NRC FIND", null, null, null, null);
		}
		catch(Exception e){
			logger.error("Error occur while insert NRC Find data in insertFxLog() ", e);
		}
		return nrcDetailList;
	}
	
	public static void main(String[] args) {
		try {
			new GetCustomerNrcDetailsClientV5().getNrcDetails("1270273342", "9740232322");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
