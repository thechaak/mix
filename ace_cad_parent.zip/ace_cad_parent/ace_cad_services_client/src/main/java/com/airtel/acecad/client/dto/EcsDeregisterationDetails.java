package com.airtel.acecad.client.dto;

public class EcsDeregisterationDetails {

	String statusDescription;
	String mobileNo;
	int nachLimit;
	int balanceDue;
	//int mtNoOfHit;

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public int getNachLimit() {
		return nachLimit;
	}

	public void setNachLimit(int nachLimit) {
		this.nachLimit = nachLimit;
	}

	public int getBalanceDue() {
		return balanceDue;
	}

	public void setBalanceDue(int balanceDue) {
		this.balanceDue = balanceDue;
	}

	
	
}
