package com.airtel.acecad.client.dto;

public class PaymentDetails {
	private String acctExtId;
	private String fxAccountNo;
	private String customerName;
	private String invoiceNo;
	private String delNo;
	private String paymentMode;
	private String paymentAmount;
	private String refNumber;
	private String chequeDate;
	private String customerBankAccountno;
	private String paymentReceivedDate;
	private String paymentPostedDate;
	private String transactionId;
	private String receiptId;
	private String amsAccountNumber;
	private String postingStatusFx;
	private String postingRetrialAttempts;
	private String fxPostingErrorDescription;
	private String latePaymentCharges;
	private String latePaymentNRCId;
	private String adjustmentCharges;
	private String sourceOfRecord;
	private String nameOfSource;
	private String fileId;
	private String latePaymentFxPostingStatus;
	private String trackingId;
	private String trackingIdServ;
	private String origTrackingId;
	private String origTrackingIdServ;
	private String changeWho;
	private String changeDate;
	private String insertDate;
	private String vendorId;
	private String userId;
	private String circle;
	private String lbxLocationId;
	private String lbxSourceId;
	private String sessionId;
	private String sourceReferenceId;
	private String paymentAdvice;
	private String customerType;
	private String isPaymentBounced;
	private String recordType;
	private String vcReferenceId;
	private String bmsTransType;
	private String srNumber;
	private String annotaion;
	private String jobId;
	private String errorCode;
	private String errorMessage;
	private String currencyCode;
	private String origBillRefNo;
	private String origBillRefResets;
	private String paymentCode;
	private String statusFx;
	private String LOB;
	private String orderId;
	private String viewId;
	private String remitterBranch;
	private String recordId;
	private String nrcAmount;
	public String getAcctExtId() {
		return acctExtId;
	}
	public void setAcctExtId(String acctExtId) {
		this.acctExtId = acctExtId;
	}
	public String getFxAccountNo() {
		return fxAccountNo;
	}
	public void setFxAccountNo(String fxAccountNo) {
		this.fxAccountNo = fxAccountNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public String getDelNo() {
		return delNo;
	}
	public void setDelNo(String delNo) {
		this.delNo = delNo;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public String getRefNumber() {
		return refNumber;
	}
	public void setRefNumber(String refNumber) {
		this.refNumber = refNumber;
	}
	public String getChequeDate() {
		return chequeDate;
	}
	public void setChequeDate(String chequeDate) {
		this.chequeDate = chequeDate;
	}
	public String getCustomerBankAccountno() {
		return customerBankAccountno;
	}
	public void setCustomerBankAccountno(String customerBankAccountno) {
		this.customerBankAccountno = customerBankAccountno;
	}
	public String getPaymentReceivedDate() {
		return paymentReceivedDate;
	}
	public void setPaymentReceivedDate(String paymentReceivedDate) {
		this.paymentReceivedDate = paymentReceivedDate;
	}
	public String getPaymentPostedDate() {
		return paymentPostedDate;
	}
	public void setPaymentPostedDate(String paymentPostedDate) {
		this.paymentPostedDate = paymentPostedDate;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getReceiptId() {
		return receiptId;
	}
	public void setReceiptId(String receiptId) {
		this.receiptId = receiptId;
	}
	public String getAmsAccountNumber() {
		return amsAccountNumber;
	}
	public void setAmsAccountNumber(String amsAccountNumber) {
		this.amsAccountNumber = amsAccountNumber;
	}
	public String getPostingStatusFx() {
		return postingStatusFx;
	}
	public void setPostingStatusFx(String postingStatusFx) {
		this.postingStatusFx = postingStatusFx;
	}
	public String getPostingRetrialAttempts() {
		return postingRetrialAttempts;
	}
	public void setPostingRetrialAttempts(String postingRetrialAttempts) {
		this.postingRetrialAttempts = postingRetrialAttempts;
	}
	public String getFxPostingErrorDescription() {
		return fxPostingErrorDescription;
	}
	public void setFxPostingErrorDescription(String fxPostingErrorDescription) {
		this.fxPostingErrorDescription = fxPostingErrorDescription;
	}
	public String getLatePaymentCharges() {
		return latePaymentCharges;
	}
	public void setLatePaymentCharges(String latePaymentCharges) {
		this.latePaymentCharges = latePaymentCharges;
	}
	public String getLatePaymentNRCId() {
		return latePaymentNRCId;
	}
	public void setLatePaymentNRCId(String latePaymentNRCId) {
		this.latePaymentNRCId = latePaymentNRCId;
	}
	public String getAdjustmentCharges() {
		return adjustmentCharges;
	}
	public void setAdjustmentCharges(String adjustmentCharges) {
		this.adjustmentCharges = adjustmentCharges;
	}
	public String getSourceOfRecord() {
		return sourceOfRecord;
	}
	public void setSourceOfRecord(String sourceOfRecord) {
		this.sourceOfRecord = sourceOfRecord;
	}
	public String getNameOfSource() {
		return nameOfSource;
	}
	public void setNameOfSource(String nameOfSource) {
		this.nameOfSource = nameOfSource;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getLatePaymentFxPostingStatus() {
		return latePaymentFxPostingStatus;
	}
	public void setLatePaymentFxPostingStatus(String latePaymentFxPostingStatus) {
		this.latePaymentFxPostingStatus = latePaymentFxPostingStatus;
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	public String getTrackingIdServ() {
		return trackingIdServ;
	}
	public void setTrackingIdServ(String trackingIdServ) {
		this.trackingIdServ = trackingIdServ;
	}
	public String getOrigTrackingId() {
		return origTrackingId;
	}
	public void setOrigTrackingId(String origTrackingId) {
		this.origTrackingId = origTrackingId;
	}
	public String getOrigTrackingIdServ() {
		return origTrackingIdServ;
	}
	public void setOrigTrackingIdServ(String origTrackingIdServ) {
		this.origTrackingIdServ = origTrackingIdServ;
	}
	public String getChangeWho() {
		return changeWho;
	}
	public void setChangeWho(String changeWho) {
		this.changeWho = changeWho;
	}
	public String getChangeDate() {
		return changeDate;
	}
	public void setChangeDate(String changeDate) {
		this.changeDate = changeDate;
	}
	public String getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(String insertDate) {
		this.insertDate = insertDate;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getLbxLocationId() {
		return lbxLocationId;
	}
	public void setLbxLocationId(String lbxLocationId) {
		this.lbxLocationId = lbxLocationId;
	}
	public String getLbxSourceId() {
		return lbxSourceId;
	}
	public void setLbxSourceId(String lbxSourceId) {
		this.lbxSourceId = lbxSourceId;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public String getSourceReferenceId() {
		return sourceReferenceId;
	}
	public void setSourceReferenceId(String sourceReferenceId) {
		this.sourceReferenceId = sourceReferenceId;
	}
	public String getPaymentAdvice() {
		return paymentAdvice;
	}
	public void setPaymentAdvice(String paymentAdvice) {
		this.paymentAdvice = paymentAdvice;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getIsPaymentBounced() {
		return isPaymentBounced;
	}
	public void setIsPaymentBounced(String isPaymentBounced) {
		this.isPaymentBounced = isPaymentBounced;
	}
	public String getRecordType() {
		return recordType;
	}
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
	public String getVcReferenceId() {
		return vcReferenceId;
	}
	public void setVcReferenceId(String vcReferenceId) {
		this.vcReferenceId = vcReferenceId;
	}
	public String getBmsTransType() {
		return bmsTransType;
	}
	public void setBmsTransType(String bmsTransType) {
		this.bmsTransType = bmsTransType;
	}
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getAnnotaion() {
		return annotaion;
	}
	public void setAnnotaion(String annotaion) {
		this.annotaion = annotaion;
	}
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getOrigBillRefNo() {
		return origBillRefNo;
	}
	public void setOrigBillRefNo(String origBillRefNo) {
		this.origBillRefNo = origBillRefNo;
	}
	public String getOrigBillRefResets() {
		return origBillRefResets;
	}
	public void setOrigBillRefResets(String origBillRefResets) {
		this.origBillRefResets = origBillRefResets;
	}
	public String getPaymentCode() {
		return paymentCode;
	}
	public void setPaymentCode(String paymentCode) {
		this.paymentCode = paymentCode;
	}
	public String getStatusFx() {
		return statusFx;
	}
	public void setStatusFx(String statusFx) {
		this.statusFx = statusFx;
	}
	public String getLOB() {
		return LOB;
	}
	public void setLOB(String lOB) {
		LOB = lOB;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getViewId() {
		return viewId;
	}
	public void setViewId(String viewId) {
		this.viewId = viewId;
	}
	public String getRemitterBranch() {
		return remitterBranch;
	}
	public void setRemitterBranch(String remitterBranch) {
		this.remitterBranch = remitterBranch;
	}
	public String getRecordId() {
		return recordId;
	}
	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}
	public String getNrcAmount() {
		return nrcAmount;
	}
	public void setNrcAmount(String nrcAmount) {
		this.nrcAmount = nrcAmount;
	}
	
	
	
}
