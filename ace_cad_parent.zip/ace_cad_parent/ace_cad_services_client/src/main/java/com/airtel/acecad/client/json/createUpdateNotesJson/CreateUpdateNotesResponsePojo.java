package com.airtel.acecad.client.json.createUpdateNotesJson;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CreateUpdateNotesResponsePojo {
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonProperty("Fault")
	  private Fault Fault;

	    public Fault getFault ()
	    {
	        return Fault;
	    }

	    public void setFault (Fault Fault)
	    {
	        this.Fault = Fault;
	    }

	 private SyncCustomerInteractionResMsg syncCustomerInteractionResMsg;

	    public SyncCustomerInteractionResMsg getSyncCustomerInteractionResMsg ()
	    {
	        return syncCustomerInteractionResMsg;
	    }

	    public void setSyncCustomerInteractionResMsg (SyncCustomerInteractionResMsg syncCustomerInteractionResMsg)
	    {
	        this.syncCustomerInteractionResMsg = syncCustomerInteractionResMsg;
	    }

	    @Override
	    public String toString()
	    {
	        return "{\"syncCustomerInteractionResMsg\" : "+syncCustomerInteractionResMsg+"}";
	    }
}
