package com.airtel.acecad.client.json.adjustmentJson;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY )
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DetailFault
{
	
    
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private SyncBillingAdjustmentFault syncBillingAdjustmentFault;

    public SyncBillingAdjustmentFault getSyncBillingAdjustmentFault ()
    {
        return syncBillingAdjustmentFault;
    }

    public void setSyncBillingAdjustmentFault (SyncBillingAdjustmentFault syncBillingAdjustmentFault)
    {
        this.syncBillingAdjustmentFault = syncBillingAdjustmentFault;
    }


	@Override
    public String toString()
    {
        return "{\"syncBillingAdjustmentFault\":"+syncBillingAdjustmentFault+"}";
    }
}