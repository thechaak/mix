package com.airtel.acecad.client.json.custAccountSummaryJson;

public class PartyBill {

	 private String billNo;

	    private String dueAmount;

	    private String billAmount;

	    public String getBillNo ()
	    {
	        return billNo;
	    }

	    public void setBillNo (String billNo)
	    {
	        this.billNo = billNo;
	    }

	    public String getDueAmount ()
	    {
	        return dueAmount;
	    }

	    public void setDueAmount (String dueAmount)
	    {
	        this.dueAmount = dueAmount;
	    }

	    public String getBillAmount ()
	    {
	        return billAmount;
	    }

	    public void setBillAmount (String billAmount)
	    {
	        this.billAmount = billAmount;
	    }

	    @Override
	    public String toString()
	    {
	        return "{\"billNo\" : \""+billNo+"\", \"dueAmount\" : \""+dueAmount+"\", \"billAmount\" : \""+billAmount+"\"}";
	    }
}
