package com.airtel.acecad.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.codec.binary.Base64;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.airtel.acecad.client.dao.ClientDAO;
import com.airtel.acecad.client.dao.ClientDAOImpl;
import com.airtel.acecad.client.dto.DepositDetails;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.Attribute;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.CreditCardPM;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.Currency;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.CustomerAccount;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.CustomerDepositRequest;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.CustomerDepositResponse;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.CustomerPayment;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.DataArea;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.DataAreaResponse;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.EbmHeader;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.EbmHeaderResponse;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.Ext;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.Identification;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.IdentificationResponse;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.LogicalIdentification;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.LogicalResource;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.PartyPayment;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.SoaFault;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.Status;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.TrackingRecord;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.UpdateCustomerDeposit;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.UpdateCustomerDepositResMsg;
import com.airtel.acecad.client.json.UpdateCustomerDepositV5.UpdateCustomerDepositResponse;
import com.airtel.acecad.client.json.depositJson.DepositMyPojo;
import com.airtel.acecad.client.json.depositJson.DepositResMsg1;
import com.airtel.acecad.client.json.depositJson.DepositResponsePojo;
import com.airtel.acecad.client.json.depositJson.Fault;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.CustomResponseErrorHandler;
import com.airtel.acecad.client.util.EncryDecrypUtility;
import com.airtel.acecad.client.util.GenericConfiguration;
import com.airtel.acecad.client.util.GlobalConstants;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CustomerDepositClient_V5 implements GlobalConstants {

	private static Logger logger = LogManager.getLogger("serviceClientUI");
	private static final ObjectMapper mapper = new ObjectMapper();

	public String postUpdateCustomerDepositToFX(CustomerDepositRequest requestPojo, DepositDetails depositDetails,
			String tableName, int jobId) throws Exception {

		logger.info(
				"START --> in postUpdateCustomerDepositToFX method  rest formation of DepositDetailsClient and transaction_no:"
						+ depositDetails.getTransactionNo());
		CustomerDepositResponse customerDepositResponse = null;
		SoaFault fault = null;
		String result = EMPTY_STRING;
		String status_code = EMPTY_STRING;
		int transaction_no = depositDetails.getTransactionNo();

		ClientDAO clientDao = new ClientDAOImpl();
		String resultConectRead = EMPTY_STRING;

		logger.info("CustomerDeposit INT Request json====>" + mapper.writeValueAsString(requestPojo));

		String clientURL = GenericConfiguration.getDescription("kenon.postUpdateCustomerDepositToFXV5.url");
		RestTemplate restTemplate = new RestTemplate();

		// ADDED FOR HANDLING TIMEOUT ERRORS
		restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
		((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
				.setConnectTimeout(Integer.parseInt(GenericConfiguration.getDescription("connect_time_out")));// 60000=
		((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
				.setReadTimeout(Integer.parseInt(GenericConfiguration.getDescription("read_time_out")));
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
		restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
		restTemplate.setErrorHandler(new CustomResponseErrorHandler());
		HttpHeaders headers = new HttpHeaders();

		String userpass = GenericConfiguration.getDescription("kenon.postPaymentToFX.userName") + ":"
				+ EncryDecrypUtility.decrypt(GenericConfiguration.getDescription("kenon.postPaymentToFX.password"));
		logger.info(
				"clientURL  postUpdateCustomerDepositToFX -->" + clientURL + " and transaction_no " + transaction_no);
		headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		HttpEntity<CustomerDepositRequest> entity = new HttpEntity<CustomerDepositRequest>(requestPojo, headers);
		ResponseEntity<CustomerDepositResponse> responsePojo = null;
		try {
			// Execute the httpMethod to given uri template,writing the
			// given request and returns the response as ResponseEntity
			responsePojo = restTemplate.exchange(clientURL, HttpMethod.POST, entity, CustomerDepositResponse.class);
			logger.info("responsePojo postUpdateCustomerDepositToFX---" + mapper.writeValueAsString(responsePojo)
					+ " and transaction_no " + transaction_no);

			if (responsePojo != null) {
				if (HttpStatus.OK == responsePojo.getStatusCode()) {

					if (responsePojo.getBody() != null) {
						if (responsePojo.getBody().getEbmHeader() != null
								&& responsePojo.getBody().getDataArea() != null) {
							customerDepositResponse = responsePojo.getBody();
							logger.info("success--postUpdateCustomerDepositToFX--->>" + responsePojo.getBody()
									+ " and transaction_no " + transaction_no);

						} else {
							status_code = responsePojo.getStatusCode().toString();
							fault = responsePojo.getBody().getSoaFault();
							logger.info(
									"faultResponsePojo  postUpdateCustomerDepositToFX in http 200 ok and soafault is-->>"
											+ fault + " and transaction_no " + transaction_no);
						}
					}
				} else {
					status_code = responsePojo.getStatusCode().toString();
					fault = responsePojo.getBody().getSoaFault();
					logger.info("faultResponsePojo  postUpdateCustomerDepositToFX-->>" + fault + " and transaction_no "
							+ transaction_no);
				}
				logger.info(
						"Before createResponseJSONForPostCustomerDepositeToFX in postUpdateCustomerDepositToFX and transaction_no "
								+ transaction_no);

				result = createResponseJSONForPostCustomerDepositeToFX(responsePojo, depositDetails, status_code, jobId,
						requestPojo);
				logger.info(
						"After createResponseJSONForPostCustomerDepositeToFX in postUpdateCustomerDepositToFX result---->"
								+ result + " and transaction_no " + transaction_no);
			} else {
				logger.info(
						"IN method  createResponseJSONForPostCustomerDepositeToFX response pojo is null and transaction_no "
								+ transaction_no);
			}
		} catch (Exception e) {
			logger.info("Got faulty code from the response of FX createResponseJSONForPostCustomerDepositeToFX", e);

			if (e.getCause().toString().contains(CONNECT_TEXT)) {

				resultConectRead = clientDao.updateConnectionReadResponse(transaction_no, tableName, CONNECT_TEXT);
				logger.info("Got faulty code from the response CONNECT_TEXT of FX resultConectRead----->"
						+ resultConectRead + " and transaction_no " + transaction_no);
			}

			if (e.getCause().toString().contains(READ_TEXT)) {

				resultConectRead = clientDao.updateConnectionReadResponse(transaction_no, tableName, READ_TEXT);
				logger.info("Got faulty code from the response READ_TEXT  of FX resultConectRead----->"
						+ resultConectRead + " and transaction_no " + transaction_no);

			}

		}
		logger.info("END--->in postUpdateCustomerDepositToFX method of DepositDetailsClient and transaction_no "
				+ transaction_no);
		return result;
	}

	private String createResponseJSONForPostCustomerDepositeToFX(ResponseEntity<CustomerDepositResponse> responsePojo,
			DepositDetails depositDetails, String statusCode, int jobId, CustomerDepositRequest requestPojo) {
		String result = EMPTY_STRING;
		String faultDescription = EMPTY_STRING;
		String status_description = EMPTY_STRING;
		int trackingServId = EMPTY_VALUE;
		int trackingId = EMPTY_VALUE;
		String cons_tans_id = EMPTY_STRING;
		int viewId = EMPTY_VALUE;
		int transactionNo = depositDetails.getTransactionNo();
		String annotation3 = EMPTY_STRING;
		String annotation5 = EMPTY_STRING;
		String faultTrace = EMPTY_STRING;
		Status status = null;
		TrackingRecord trackingRecord = null;
		SoaFault soaFault = null;

		if (responsePojo != null) {
			// if(responsePojo.getBody().getUpdateCustomerDepositResMsg()!=
			// null){
			if (responsePojo.getBody().getEbmHeader() != null) {
				EbmHeaderResponse ebmHeader = responsePojo.getBody().getEbmHeader();
				if (CommonUtil.isNotNull(ebmHeader.getConsumerTransactionId())) {
					cons_tans_id = ebmHeader.getConsumerTransactionId();
					logger.info("inside createResponseJSONForPostCustomerDepositeToFX() consu,erTransactinId==>"
							+ cons_tans_id);

				}

				if (responsePojo.getBody().getDataArea() != null) {
					DataAreaResponse areaResponse = responsePojo.getBody().getDataArea();
					if (areaResponse.getUpdateCustomerDepositResponse() != null) {
						UpdateCustomerDepositResponse customerDepositResponse = areaResponse
								.getUpdateCustomerDepositResponse();
						if (customerDepositResponse != null) {
							if (customerDepositResponse.getStatus() != null) {
								status = customerDepositResponse.getStatus();
								if (CommonUtil.isNotNull(status.getStatusCode())) {
									String[] statusCodeArray = status.getStatusCode().split("-");
									statusCode = statusCodeArray[1] + "-" + statusCodeArray[2];
									logger.info("status code in createResponseJSONForPostCustomerDepositeToFX----->>>"
											+ statusCode + "and transaction_no-->>" + transactionNo);
								}

								if (CommonUtil.isNotNull(status.getStatusCode())
										|| CommonUtil.isNotNull(status.getStatusDescription())) {
									status_description = statusCode + ":" + status.getStatusDescription();

									logger.info(
											"status_description in createResponseJSONForPostCustomerDepositeToFX--->>"
													+ status_description + " and transaction_no-->>" + transactionNo);
								}
								if (customerDepositResponse.getTrackingRecord() != null) {
									trackingRecord = customerDepositResponse.getTrackingRecord();
									if (CommonUtil.isNotNull(trackingRecord.getSystemId())) {
										trackingServId = Integer.parseInt(trackingRecord.getSystemId());
										logger.info(
												"tracking_serv_id in createResponseJSONForPostCustomerDepositeToFX--->>"
														+ trackingServId + " and transaction_no-->>" + transactionNo);
									}

									IdentificationResponse identificationResponse = trackingRecord.getIdentification();
									if (CommonUtil.isNotNull(identificationResponse.getId())) {
										trackingId = Integer.parseInt(identificationResponse.getId());
										logger.info("tracking_id in createResponseJSONForPostCustomerDepositeToFX--->>"
												+ trackingId + " and transaction_no-->>" + transactionNo);
									}
								}

							}
						}
					}
				}
			} else if (responsePojo.getBody().getSoaFault() != null) {
				soaFault =responsePojo.getBody().getSoaFault();
				logger.info(
						"createResponseJSONForPostCustomerDepositeToFX method  when ebmHeader is null from resonse===");
				String[] soaFaultCodeArray = soaFault.getSoaFaultCode().split("-");
				statusCode = soaFaultCodeArray[1] + "-" + soaFaultCodeArray[2];
				String fault_value = soaFault.getFaultDescription();
				if (fault_value.length() > 999)
					fault_value = fault_value.substring(0, 1000);

				status_description = statusCode + ":" + fault_value;
				status_description = status_description.replace("'", "");
				logger.info(
						"Status description is in createResponseJSONForPostCustomerDepositeToFX when error response from webservice---> "
								+ status_description);

			}

			// }
		}

		ClientDAO clientDAO = new ClientDAOImpl();
		try {
			// String table_name =
			// clientDAO.fetchTableName(FILE_IDENTIFIER_DPP);
			// log.info("trans no in method
			// createResponseJSONForNrcForFailedPaymentToFX---->" +
			// transactionNo);
			logger.info("Before updateResponse in createResponseJSONForPostCustomerDepositeToFX and transaction_no-->>"
					+ transactionNo + " and job_id-->" + jobId);
			result = clientDAO.updateResponse(status_description, trackingId, trackingServId,
					depositDetails.getTransactionNo(), "DEPOSIT_APS", viewId, jobId, annotation3, annotation5,
					faultTrace);
			logger.info("After updateResponse in createResponseJSONForPostCustomerDepositeToFX response-result----->>>"
					+ result + "and transaction_no-->>" + transactionNo);
			String status_Code = statusCode == "200" ? "SUCCESS" : "FAILED";
			String apsFlag = requestPojo.getEbmHeader().getCustomerMigrated().equalsIgnoreCase("true") ? "APS" : "CAD";
			clientDAO.insertFxLog(status_Code, transactionNo + "", mapper.writeValueAsString(requestPojo),
					mapper.writeValueAsString(responsePojo), requestPojo.getEbmHeader().getLob(), apsFlag,
					"Payment Deposit", null, null, null, null);
			logger.info(
					"END----in createResponseJSONForPostCustomerDepositeToFX method of DepositDetailsClient and transaction_no-->>"
							+ transactionNo);
		} catch (Exception e) {
			logger.error("Error occur while updating RESPONSE CustomerDeposit INT", e);
		}

		return result;
	}

	public String createRequestJSONForPostCustomerDepositToFX(String accountId, String tableName, int job_id)
			throws Exception {

		List<DepositDetails> depositDetailsList = new ArrayList<DepositDetails>();
		String result = EMPTY_STRING;
		int transactionNo = EMPTY_VALUE;
		ClientDAO clientDAO = new ClientDAOImpl();
		depositDetailsList = clientDAO.fetchDepositDetails(accountId);
		for (DepositDetails data : depositDetailsList) {
			EbmHeader ebmHeader = new EbmHeader();
			if (data.getLob() != null)
				ebmHeader.setLob(data.getLob());
			else
				ebmHeader.setLob(LOB);
			ebmHeader.setSubLob(SUBLOB);
			ebmHeader.setConsumerTransactionId("APS_" + data.getTransactionNo());
			if (data.getApsFlag() != null && data.getApsFlag().equalsIgnoreCase("APS"))
				ebmHeader.setCustomerMigrated("true");
			else
				ebmHeader.setCustomerMigrated("false");
			ebmHeader.setConsumerName("APS");
			ebmHeader.setDomain("B2B");
			ebmHeader.setProgrammeName("EAIMigration");

			DataArea dataArea = new DataArea();
			CustomerAccount customerAccount = new CustomerAccount();
			UpdateCustomerDeposit updateCustomerDeposit = new UpdateCustomerDeposit();
			List<Identification> identificationList = new ArrayList<>();
			Identification internalIdentification = new Identification();
			internalIdentification.setId("");
			internalIdentification.setType("AccountInternalId");
			Identification externalIdentification = new Identification();
			externalIdentification.setId(accountId);
			externalIdentification.setType("AccountExternalId");
			Identification hierarchyIdentification = new Identification();
			hierarchyIdentification.setId("14");
			hierarchyIdentification.setType("HierarchyId");

			identificationList.add(internalIdentification);
			identificationList.add(externalIdentification);
			identificationList.add(hierarchyIdentification);

			customerAccount.setIdentification(identificationList);
			List<LogicalIdentification> logicalIdenList = new ArrayList<>();
			LogicalResource logicalResource = new LogicalResource();
			LogicalIdentification logicalIdentification = new LogicalIdentification();
			logicalIdentification.setId(data.getMobileNo());
			logicalIdenList.add(logicalIdentification);
			logicalResource.setIdentification(logicalIdenList);
			logicalResource.setType("MSISDN");

			CustomerPayment customerPayment = new CustomerPayment();
			PartyPayment partyPayment = new PartyPayment();
			double addAmount = data.getAddAmount();
			int amount = (int) addAmount;
			partyPayment.setAmount(String.valueOf(amount));
			String finalDate1 = null;
			if (data.getDateReceived() != null) {

				String[] finalDate = data.getDateReceived().split("T");
				String val = finalDate[1];
				String[] val1 = val.split("\\+");
				val = val1[0];
				val = val.replaceAll(":", "");
				val = val.replaceAll("0", "");
				finalDate1 = val.length() == 0 ? finalDate[0] + "T23:59:59+" + val1[1] : data.getDateReceived();

			}
			partyPayment.setPaymentDate(finalDate1);
			if (CommonUtil.isNotNull(data.getModeOfPayment())) {
				partyPayment.setMode(data.getModeOfPayment());
			}
			partyPayment.setTaxAmount("");
			partyPayment.setInterestAmount("");
			partyPayment.setCurrency(INR);
			partyPayment.setDepositType(data.getDepositType());

			customerPayment.setPartyPayment(partyPayment);

			Currency currency = new Currency();
			currency.setCode("1");

			Ext ext = new Ext();
			List<Attribute> attributeList = new ArrayList<>();

			for (int j = 0; j < 5; j++) {
				Attribute at = new Attribute();
				
					if (j == 0) {
						at.setName("Annotation1");
						if (data.getAnnotation1() != null && data.getAnnotation1() != ""){
						at.setValue(data.getAnnotation1());
					}
						else{
							at.setValue("");
						}
						
				}

				if (j == 1) {
					at.setName("Annotation2");
					at.setValue(accountId);
				}
					if (j == 2) {
						at.setName("Annotation3");
						if (CommonUtil.isNotNull(data.getCsrNotes())) {
							logger.info("value--->>"+data.getCsrNotes());
						at.setValue(data.getCsrNotes());
						}
						else{ 
							at.setValue("");
						}
				}
					if (j == 3) {
						at.setName("Annotation4");
						if (CommonUtil.isNotNull(data.getAnnotation4())) {
						at.setValue(data.getAnnotation4());
						}else
						{
							at.setValue("");
						}

				}
					if (j == 4) {
						at.setName("Annotation5");
						if (CommonUtil.isNotNull(data.getChequeNo())) {
						at.setValue(data.getChequeNo());
						}
						else{
							at.setValue("");
						}
				}
				attributeList.add(at);

			}
			ext.setAttribute(attributeList);
			CreditCardPM creditCardPM = new CreditCardPM();
			creditCardPM.setCardAuthCode("1234566");
			creditCardPM.setCardAuthDate("2018-04-05T00:00:00");

			updateCustomerDeposit.setCustomerAccount(customerAccount);
			updateCustomerDeposit.setLogicalResource(logicalResource);
			updateCustomerDeposit.setCustomerPayment(customerPayment);
			updateCustomerDeposit.setCurrency(currency);
			updateCustomerDeposit.setExt(ext);
			updateCustomerDeposit.setCreditCardPM(creditCardPM);
			dataArea.setUpdateCustomerDeposit(updateCustomerDeposit);

			CustomerDepositRequest customerDepositRequest = new CustomerDepositRequest();
			customerDepositRequest.setEbmHeader(ebmHeader);
			customerDepositRequest.setDataArea(dataArea);

			if (data.getTransactionNo() != 0) {
				transactionNo = data.getTransactionNo();
			}

			logger.info("Before hitting the posting fx job_id for transaction no in INT---" + transactionNo
					+ " in createRequestJSONForPostCustomerDepositToFX and account_no--->>" + accountId
					+ " and transactionNo " + transactionNo);
			Object[] resultobj = clientDAO.updateJobId("DEPOSIT_APS", transactionNo, null, job_id);
			logger.info(
					"After hitting the posting fx job_id jobId in createRequestJSONForPostCustomerDepositToFX result is:"
							+ resultobj[0] + "and job id is" + resultobj[1] + " and transaction_no " + transactionNo);
			if (RESULT_DB_SUCCESFUL.equalsIgnoreCase((String) resultobj[0])) {

				logger.info(
						"Before calling postUpdateCustomerDepositToFX method from createRequestJSONForPostCustomerDepositToFX and account_no--->>"
								+ accountId + " and transactionNo " + transactionNo);
				result = postUpdateCustomerDepositToFX(customerDepositRequest, data, tableName, (int) resultobj[1]);
				logger.info(
						"After calling postUpdateCustomerDepositToFX method from createRequestJSONForPostCustomerDepositToFX result--->"
								+ result + " and account_no--->>" + accountId + " and transactionNo " + transactionNo);
			}
			logger.info(
					"END----in createRequestJSONForPostCustomerDepositToFX method of DepositDetailsClient and account_no--->>"
							+ accountId + " and transactionNo " + transactionNo);
		}
		return result;

	}

	public static void main(String[] args) throws Exception {
		new CustomerDepositClient_V5().createRequestJSONForPostCustomerDepositToFX("1121315315", "DEPOSIT_APS", 5);
	}
}
