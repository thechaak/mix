package com.airtel.acecad.client.json.customerAccBillingDetails;

public class CustomerBillingDetailResponse {
	 private EbmHeader ebmHeader;
	 private DataArea dataArea;
	 private SoaFault soaFault;

	    public EbmHeader getEbmHeader ()
	    {
	        return ebmHeader;
	    }

	    public void setEbmHeader (EbmHeader ebmHeader)
	    {
	        this.ebmHeader = ebmHeader;
	    }

	    public DataArea getDataArea ()
	    {
	        return dataArea;
	    }

	    public void setDataArea (DataArea dataArea)
	    {
	        this.dataArea = dataArea;
	    }

	    
	    public SoaFault getSoaFault() {
			return soaFault;
		}

		public void setSoaFault(SoaFault soaFault) {
			this.soaFault = soaFault;
		}

		@Override
		public String toString() {
			return "CustomerBillingDetailResponse [ebmHeader=" + ebmHeader + ", dataArea=" + dataArea + ", soaFault="
					+ soaFault + "]";
		}

		
}
