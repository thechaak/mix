package com.airtel.acecad.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.airtel.acecad.client.dao.ClientDAO;
import com.airtel.acecad.client.dao.ClientDAOImpl;
import com.airtel.acecad.client.dto.AdjReversalDetails;

import com.airtel.acecad.client.json.adjustmentReversalJson.AdjustmentRequestPojo;
import com.airtel.acecad.client.json.adjustmentReversalJson.AdjustmentResponsePojo;
import com.airtel.acecad.client.json.adjustmentReversalJson.Customer;
import com.airtel.acecad.client.json.adjustmentReversalJson.CustomerAccount;
import com.airtel.acecad.client.json.adjustmentReversalJson.CustomerBill;
import com.airtel.acecad.client.json.adjustmentReversalJson.CustomerBillIdentification;
import com.airtel.acecad.client.json.adjustmentReversalJson.CustomerPayment;
import com.airtel.acecad.client.json.adjustmentReversalJson.DetailFault;
import com.airtel.acecad.client.json.adjustmentReversalJson.EbmHeader;
import com.airtel.acecad.client.json.adjustmentReversalJson.EbmHeader1;
import com.airtel.acecad.client.json.adjustmentReversalJson.Fault;
import com.airtel.acecad.client.json.adjustmentReversalJson.Identification;
import com.airtel.acecad.client.json.adjustmentReversalJson.PartyPayment;
import com.airtel.acecad.client.json.adjustmentReversalJson.RequestDataArea;
import com.airtel.acecad.client.json.adjustmentReversalJson.ResponseDataArea;
import com.airtel.acecad.client.json.adjustmentReversalJson.ResponseTrackingRecord;
import com.airtel.acecad.client.json.adjustmentReversalJson.SoaFault;
import com.airtel.acecad.client.json.adjustmentReversalJson.Status;
import com.airtel.acecad.client.json.adjustmentReversalJson.SyncBillingAdjustment;
import com.airtel.acecad.client.json.adjustmentReversalJson.SyncBillingAdjustmentFault;
import com.airtel.acecad.client.json.adjustmentReversalJson.SyncBillingAdjustmentReqMsg;
import com.airtel.acecad.client.json.adjustmentReversalJson.SyncBillingAdjustmentResMsg;
import com.airtel.acecad.client.json.adjustmentReversalJson.SyncBillingAdjustmentResponse;
import com.airtel.acecad.client.json.adjustmentReversalJson.TrackingRecord;
import com.airtel.acecad.client.json.adjustmentReversalJson.TrackingRecordIdentification;
import com.airtel.acecad.client.util.GenericConfiguration;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.CustomResponseErrorHandler;
import com.airtel.acecad.client.util.EncryDecrypUtility;
import com.airtel.acecad.client.util.GlobalConstants;

/////////////////////////////INT_418///////////////////////////////////////////
public class AdjustmentReversalDetailsClient implements GlobalConstants {

	private static Logger log = LogManager.getLogger("serviceClientUI");

	/*
	 * @author :- Geeta Rajput-FOR Ajustment Posting(create) to FX
	 */
	public String postUpdateAdjustmentReversalToFX(AdjustmentRequestPojo requestPojo,
			AdjReversalDetails adjReversalDetails, String tableName, int jobId) throws Exception {

		log.info(
				"START --> in postUpdateAdjustmentReversalToFX method of AdjustmentReversalDetailsClient and transaction_no"
						+ adjReversalDetails.getTransactionNo());
		SyncBillingAdjustmentResMsg syncBillingAdjustmentResMsg = null;
		Fault fault = null;
		String result = EMPTY_STRING;
		String status_code = EMPTY_STRING;

		ClientDAO clientDao = new ClientDAOImpl();
		// int pTransactionId = EMPTY_VALUE;
		String resultConectRead = EMPTY_STRING;
		int transaction_no = adjReversalDetails.getTransactionNo();

		try {

			String clientURL = GenericConfiguration.getDescription("kenon.postUpdateAdjustmentPostingToFX.url");

			RestTemplate restTemplate = new RestTemplate();
			// ADDED FOR HANDLING TIMEOUT ERRORS
			restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
					.setConnectTimeout(Integer.parseInt(GenericConfiguration.getDescription("connect_time_out")));// 60000=
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
					.setReadTimeout(Integer.parseInt(GenericConfiguration.getDescription("read_time_out")));

			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
			restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
			restTemplate.setErrorHandler(new CustomResponseErrorHandler());
			HttpHeaders headers = new HttpHeaders();
            
			//Added by Ritu (EncryptDecrypt Password)
			String userpass = GenericConfiguration.getDescription("kenon.postPaymentToFX.userName") + ":"
					+ EncryDecrypUtility.decrypt(GenericConfiguration.getDescription("kenon.postPaymentToFX.password"));

			log.info("clientURL in postUpdateAdjustmentReversalToFX-->" + clientURL + " and transaction_no "
					+ transaction_no);
			headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

			HttpEntity<AdjustmentRequestPojo> entity = new HttpEntity<AdjustmentRequestPojo>(requestPojo, headers);
			ResponseEntity<AdjustmentResponsePojo> responsePojo = null;
			try {
				log.info("requestPojo  in postUpdateAdjustmentReversalToFX" + requestPojo + " and transaction_no "
						+ transaction_no);
				// Execute the httpMethod to given uri template,writing the
				// given request and returns the response as ResponseEntity
				responsePojo = restTemplate.exchange(clientURL, HttpMethod.POST, entity, AdjustmentResponsePojo.class);
				log.info("responsePojo  in postUpdateAdjustmentReversalToFX---" + responsePojo + " and transaction_no "
						+ transaction_no);

				log.info("responsePojo  in postUpdateAdjustmentReversalToFX---" + responsePojo.getBody().toString()
						+ " and transaction_no " + transaction_no);
				if (responsePojo != null) {
					if (HttpStatus.OK == responsePojo.getStatusCode()) {
						if (responsePojo.getBody().getSyncBillingAdjustmentResMsg() != null) {
							syncBillingAdjustmentResMsg = responsePojo.getBody().getSyncBillingAdjustmentResMsg();
							log.info("success-- in postUpdateAdjustmentReversalToFX--->>"
									+ responsePojo.getBody().getSyncBillingAdjustmentResMsg() + " and transaction_no "
									+ transaction_no);

						} else {
							status_code = responsePojo.getStatusCode().toString();
							fault = responsePojo.getBody().getFault();
							log.info("faultResponsePojo  in postUpdateAdjustmentReversalToFX in http 200 ok-->>" + fault
									+ " and transaction_no " + transaction_no);
						}
					} else {
						status_code = responsePojo.getStatusCode().toString();
						fault = responsePojo.getBody().getFault();
						log.info("faultResponsePojo  in postUpdateAdjustmentReversalToFX-->>" + fault
								+ " and transaction_no " + transaction_no);
					}
					log.info("Before createResponseJSONForAdjustmentReversalToFX in postUpdateAdjustmentReversalToFX ");

					result = createResponseJSONForAdjustmentReversalToFX(syncBillingAdjustmentResMsg, fault,
							adjReversalDetails, status_code, jobId);
					log.info("After createResponseJSONForAdjustmentReversalToFX Response in postUpdateAdjustmentReversalToFX-->>" + result + " and transaction_no "
							+ transaction_no);

				/*	log.info(
							"After createResponseJSONForAdjustmentReversalToFX in postUpdateAdjustmentReversalToFX result-->>"
									+ result + " and transaction_no " + transaction_no);*/
				} else {
					log.info("IN method  postUpdateAdjustmentReversalToFX response pojo is null and transaction_no "
							+ transaction_no);
				}
			} catch (Exception e) {
				log.info("Got faulty code from the response of FX and transaction_no " + transaction_no);
				// call for the filedaoImpl to update only the no. of hits
		
				if (e.getCause().toString().contains(CONNECT_TEXT)) {

					resultConectRead = clientDao.updateConnectionReadResponse(transaction_no, tableName, CONNECT_TEXT);
					log.info("Got faulty code from the response CONNECT_TEXT of FX resultConectRead----->"
							+ resultConectRead + " and transaction_no " + transaction_no);
				}

				if (e.getCause().toString().contains(READ_TEXT)) {

					resultConectRead = clientDao.updateConnectionReadResponse(transaction_no, tableName, READ_TEXT);
					log.info("Got faulty code from the response READ_TEXT  of FX resultConectRead----->"
							+ resultConectRead + " and transaction_no " + transaction_no);

				}

			}

		} catch (Exception e) {
			log.info("exception in postUpdateAdjustmentPostingToFX" + e);
			if (e.getCause().toString().contains(CONNECT_TEXT)) {

				resultConectRead = clientDao.updateConnectionReadResponse(transaction_no, tableName, CONNECT_TEXT);
				log.info("Got faulty code from the response CONNECT_TEXT of FX resultConectRead postUpdateAdjustmentPostingToFX----->"
						+ resultConectRead + " and transaction_no " + transaction_no);
			}

			if (e.getCause().toString().contains(READ_TEXT)) {

				resultConectRead = clientDao.updateConnectionReadResponse(transaction_no, tableName, READ_TEXT);
				log.info("Got faulty code from the response READ_TEXT  of FX resultConectRead postUpdateAdjustmentPostingToFX----->" + resultConectRead
						+ " and transaction_no " + transaction_no);

			}

		}
		log.info(
				"END--->in postUpdateAdjustmentPostingToFX method of AdjustmentReversalDetailsClient and transaction_no "
						+ transaction_no);
		return result;
	}

	/*
	 * @author :- Geeta Rajput--create request json for FOR Ajustment
	 * Posting(create) to FX
	 */
	public String createRequestJSONForAdjustmentReversalToFX(String accountId, String tableName,int job_id) throws Exception {

		log.info("START--->in createRequestJSONForAdjustmentReversalToFX method of AdjustmentReversalDetailsClient");

		String result = EMPTY_STRING;
		int transactionNo = EMPTY_VALUE;
		AdjustmentReversalDetailsClient AdjustmentReversalDetailsClient = new AdjustmentReversalDetailsClient();
		List<AdjReversalDetails> adjReversalDetailsList = new ArrayList<AdjReversalDetails>();

		ClientDAO clientDAO = new ClientDAOImpl();
		adjReversalDetailsList = clientDAO.fetchAdjustmentReversalDetails(accountId);

		log.info("adjPostDetailsList in createRequestJSONForAdjustmentReversalToFX---->>" + adjReversalDetailsList);

		for (int i = 0; i < adjReversalDetailsList.size(); i++) {

			AdjReversalDetails adjReversalDetails = new AdjReversalDetails();
			adjReversalDetails = adjReversalDetailsList.get(i);

			SyncBillingAdjustmentReqMsg syncBillingAdjustmentReqMsg = new SyncBillingAdjustmentReqMsg();
			EbmHeader ebmHeader = new EbmHeader();
			ebmHeader.setLob(LOB);
			String consumerTransactionId = APS + + adjReversalDetails.getTransactionNo();
			log.info("consumerTransactionId in createRequestJSONForAdjustmentReversalToFX----->"
					+ consumerTransactionId);
			ebmHeader.setConsumerTransactionId(consumerTransactionId);
			ebmHeader.setCustomerMigrated(TRUE);
			ebmHeader.setConsumerName(ADJ_CREATE_CONSUMER_NAME);
			syncBillingAdjustmentReqMsg.setEbmHeader(ebmHeader);

			RequestDataArea dataArea = new RequestDataArea();
			SyncBillingAdjustment syncBillingAdjustment = new SyncBillingAdjustment();

			Customer customer = new Customer();

			CustomerAccount customerAccount = new CustomerAccount();
			Identification identification = new Identification();
			customerAccount.setIdentification(identification);
			identification.setId(accountId);

			customer.setCustomerAccount(customerAccount);
			syncBillingAdjustment.setCustomer(customer);

			CustomerPayment customerPayment = new CustomerPayment();

			CustomerBill customerBill = new CustomerBill();
			CustomerBillIdentification customerBillIdentification = new CustomerBillIdentification();
			customerBill.setIdentification(customerBillIdentification);
			customerBillIdentification.setId(adjReversalDetails.getOrigBillRefNo());
			customerBill.setBillRefResets(String.valueOf(adjReversalDetails.getOrigBillRefResets()));

			customerPayment.setCustomerBill(customerBill);

			PartyPayment partyPayment = new PartyPayment();

			partyPayment.setPaymentDirection(ADJ_TYPE_CANCEL);

			customerPayment.setPartyPayment(partyPayment);
			syncBillingAdjustment.setCustomerPayment(customerPayment);

			TrackingRecord trackingRecord = new TrackingRecord();
			TrackingRecordIdentification trackingRecordIdentification = new TrackingRecordIdentification();
			trackingRecord.setIdentification(trackingRecordIdentification);
			trackingRecordIdentification.setId(String.valueOf(adjReversalDetails.getOrigTrackingId()));

			trackingRecord.setSystemId(String.valueOf(adjReversalDetails.getOrigTrackinIdServ()));
			trackingRecord.setUserId(adjReversalDetails.getUserId());

			syncBillingAdjustment.setTrackingRecord(trackingRecord);

			/*
			 * LogicalResource logicalResource = new LogicalResource();
			 * LogicalResourceIdentification logicalResourceIdentification = new
			 * LogicalResourceIdentification();
			 * logicalResource.setIdentification(logicalResourceIdentification);
			 * logicalResourceIdentification.setId(String.valueOf(adjPostDetails
			 * .getServiceExternalId()));
			 * 
			 * syncBillingAdjustment.setLogicalResource(logicalResource);
			 */

			dataArea.setSyncBillingAdjustment(syncBillingAdjustment);

			syncBillingAdjustmentReqMsg.setDataArea(dataArea);

			AdjustmentRequestPojo adjustmentRequestPojo = new AdjustmentRequestPojo();

			adjustmentRequestPojo.setSyncBillingAdjustmentReqMsg(syncBillingAdjustmentReqMsg);

			if (adjReversalDetails.getTransactionNo() != 0) {
				transactionNo = adjReversalDetails.getTransactionNo();
			}

			/*log.info("Request in createRequestJSONForAdjustmentReversalToFX--->>"
					+ syncBillingAdjustmentReqMsg.toString() + " and transaction_no " + transactionNo);*/

			log.info("Request mypojo  in createRequestJSONForAdjustmentReversalToFX---->>" + adjustmentRequestPojo
					+ "and account_no-->" + accountId + " and transaction_no " + transactionNo);

			log.info("Before hitting the posting fx job_id for transaction no in INT---" + transactionNo
					+ " in createRequestJSONForAdjustmentReversalToFX");
			Object[] resultobj = clientDAO.updateJobId(tableName, transactionNo,null,job_id);

			log.info(
					"After hitting the posting fx job_id jobId in createRequestJSONForAdjustmentReversalToFX result is:"
							+ resultobj[0] + "and job id is" + resultobj[1] + " and transaction_no " + transactionNo);
			if (RESULT_DB_SUCCESFUL.equalsIgnoreCase((String) resultobj[0])) {

				log.info(
						"Before postUpdateAdjustmentReversalToFX in createRequestJSONForAdjustmentReversalToFX and account_no-->"
								+ accountId + " and transaction_no " + transactionNo);

				result = AdjustmentReversalDetailsClient.postUpdateAdjustmentReversalToFX(adjustmentRequestPojo,
						adjReversalDetails, tableName, (int) resultobj[1]);
				log.info(
						"After postUpdateAdjustmentReversalToFX in createRequestJSONForAdjustmentReversalToFX result------>"
								+ result + "and account_no-->" + accountId + " and transaction_no " + transactionNo);

			}
			log.info(
					"END----in createRequestJSONForAdjustmentReversalToFX method of AdjustmentReversalDetailsClient and transaction_no "
							+ transactionNo);
		}
		return result;
	}

	/*
	 * @author :- Geeta Rajput--create response json for FOR Ajustment
	 * Posting(create) to FX for update Adjustment details Request
	 */
	public String createResponseJSONForAdjustmentReversalToFX(SyncBillingAdjustmentResMsg syncBillingAdjustmentResMsg,
			Fault fault, AdjReversalDetails adjReversalDetails, String statusCode, int jobId) throws Exception {

		log.info("START----in createResponseJSONForAdjustmentReversalToFX method of AdjustmentReversalDetailsClient");

		String result = EMPTY_STRING;
		String faultDescription = EMPTY_STRING;
		String status_description = EMPTY_STRING;
		int trackingServId = EMPTY_VALUE;
		int trackingId = EMPTY_VALUE;
		int viewId = EMPTY_VALUE;
		int transaction_no = adjReversalDetails.getTransactionNo();
		String annotation3=EMPTY_STRING;
		String annotation5=EMPTY_STRING;
		String faultTrace=EMPTY_STRING;

		if (syncBillingAdjustmentResMsg != null) {
			log.info(
					"In if loop when got success response from webservice in createResponseJSONForAdjustmentReversalToFX--418 INT and transaction_no-->>"
							+ transaction_no);

			EbmHeader1 ebmHeader = new EbmHeader1();
			if (ebmHeader != null) {
				ebmHeader = syncBillingAdjustmentResMsg.getEbmHeader();
				if (CommonUtil.isNotNull(ebmHeader.getConsumerTransactionId())) {
					ebmHeader.getConsumerTransactionId();
				}
			}

			ResponseDataArea responseDataArea = new ResponseDataArea();
			if (responseDataArea != null) {
				if (syncBillingAdjustmentResMsg.getDataArea() != null) {
					responseDataArea = syncBillingAdjustmentResMsg.getDataArea();
				}
			}
			SyncBillingAdjustmentResponse syncBillingAdjustmentResponse = new SyncBillingAdjustmentResponse();
			if (responseDataArea.getSyncBillingAdjustmentResponse() != null) {

				syncBillingAdjustmentResponse = responseDataArea.getSyncBillingAdjustmentResponse();
			}

			Status status = new Status();
			if (status != null) {
				status = syncBillingAdjustmentResponse.getStatus();
			}
			if (status != null) {

				if (CommonUtil.isNotNull(status.getStatusCode())) {
					String[] statusCodeArray = status.getStatusCode().split("-");
					statusCode = statusCodeArray[1] + "-" + statusCodeArray[2];
					log.info("status code in createResponseJSONForAdjustmentReversalToFX-->>" + statusCode
							+ "and transaction_no-->>" + transaction_no);
				}

				if (CommonUtil.isNotNull(status.getStatusCode())) {
					status_description = statusCode + ":" + status.getStatusDescription();

					System.out.println("status_description--->>" + status_description);
					log.info("status_description in createResponseJSONForAdjustmentReversalToFX--->>"
							+ status_description + "and transaction_no-->>" + transaction_no);
				}
			}

			ResponseTrackingRecord trackingRecord = new ResponseTrackingRecord();
			if (trackingRecord != null) {
				if (syncBillingAdjustmentResponse.getTrackingRecord() != null) {

					trackingRecord = syncBillingAdjustmentResponse.getTrackingRecord();
					if (CommonUtil.isNotNull(trackingRecord.getSystemId())) {
						trackingServId = Integer.parseInt(trackingRecord.getSystemId());
						log.info("tracking_serv_id in createResponseJSONForAdjustmentReversalToFX--->>"
								+ trackingServId);
					}
					if (trackingRecord.getIdentification() != null) {
						TrackingRecordIdentification identification = trackingRecord.getIdentification();
						if (CommonUtil.isNotNull(identification.getId())) {
							trackingId = Integer.parseInt(identification.getId());
							log.info("tracking_id in createResponseJSONForAdjustmentReversalToFX--->>" + trackingId);
						}
					}
				}
			}

			AdjustmentResponsePojo adjustmentResponsePojo = new AdjustmentResponsePojo();
			if (adjustmentResponsePojo.getSyncBillingAdjustmentResMsg() != null) {
				syncBillingAdjustmentResMsg = adjustmentResponsePojo.getSyncBillingAdjustmentResMsg();
			}
		} else if (fault != null) {
			log.info(
					"In else loop when got error response from webservice in createResponseJSONForAdjustmentReversalToFX--418 InT");
			if (statusCode.contains(status_code_504) || statusCode.contains(status_code_500)) {
				//status_description = fault.getFaultstring();
				String fault_value=fault.getFaultstring();
				if(fault_value.length()>999){
					fault_value=fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description= status_description.replace("'", "");
				log.info("Status description is in createResponseJSONForAdjustmentReversalToFX---> "
						+ status_description + "and transaction_no-->>" + transaction_no);
			} else if (statusCode.contains(status_code_502)) {
				//status_description = fault.getFaultstring();
				String fault_value=fault.getFaultstring();
				if(fault_value.length()>999){
					fault_value=fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description= status_description.replace("'", "");
				log.info("Status description is in  createResponseJSONForAdjustmentReversalToFX---> "
						+ status_description + "and transaction_no-->>" + transaction_no);
			} else if (statusCode.contains(status_code_400)) {
				//status_description = fault.getFaultstring();
				String fault_value=fault.getFaultstring();
				if(fault_value.length()>999){
					fault_value=fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description= status_description.replace("'", "");
				log.info("Status description is in createResponseJSONForAdjustmentReversalToFX---> "
						+ status_description + "and transaction_no-->>" + transaction_no);

			} else {
				DetailFault detail = fault.getDetail();
				SyncBillingAdjustmentFault syncBillingAdjustmentFault = detail.getSyncBillingAdjustmentFault();
				SoaFault soaFault = syncBillingAdjustmentFault.getSoaFault();
				if (soaFault != null) {
					// Added by geeta
					if (CommonUtil.isNotNull(soaFault.getSoaFaultCode())) {
						String[] soaFaultCodeArray = soaFault.getSoaFaultCode().split("-");
						statusCode = soaFaultCodeArray[1] + "-" + soaFaultCodeArray[2];
						log.info("soa fault status code in createResponseJSONForAdjustmentReversalToFX----->>>"
								+ statusCode + " and transaction_no-->>" + transaction_no);

					}
					if (CommonUtil.isNotNull(soaFault.getFaultDescription())) {
						//status_description = statusCode + ":" + soaFault.getFaultDescription();
						String fault_value=soaFault.getFaultDescription();
						if(fault_value.length()>999){
							fault_value=fault_value.substring(0, 1000);
						}
						status_description = statusCode + ":" + fault_value;
						status_description= status_description.replace("'", "");
						log.info("faultDescription in createResponseJSONForAdjustmentReversalToFX---->"
								+ status_description + "and transaction_no-->>" + transaction_no);
					}
				}
			}
		}
		ClientDAO clientDAO = new ClientDAOImpl();
		String table_name = clientDAO.fetchTableName(FILE_IDENTIFIER_RDJ);
		log.info("trans no in method in createResponseJSONForAdjustmentReversalToFX---->"
				+ adjReversalDetails.getTransactionNo() + " and job_id-->" + jobId);
		result = clientDAO.updateResponse(status_description, trackingId, trackingServId,
				adjReversalDetails.getTransactionNo(), table_name, viewId, jobId,annotation3,annotation5,faultTrace);
		log.info("response-result in createResponseJSONForAdjustmentReversalToFX----->>>" + result
				+ " and transaction_no-->>" + transaction_no);
		log.info(
				"END----in createResponseJSONForAdjustmentReversalToFX method of AdjustmentReversalDetailsClient and transaction_no-->>"
						+ transaction_no);
		return result;

	}
	/*public static void main(String[] args) throws Exception {
		AdjustmentReversalDetailsClient adjustmentReversalDetailsClient=new AdjustmentReversalDetailsClient();
		adjustmentReversalDetailsClient.createRequestJSONForAdjustmentReversalToFX("697451720", "ADJ_REVERSAL_APS");
	}*/
}
