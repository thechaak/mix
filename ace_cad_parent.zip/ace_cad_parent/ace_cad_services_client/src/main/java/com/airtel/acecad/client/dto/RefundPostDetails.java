package com.airtel.acecad.client.dto;

import java.sql.Timestamp;
import java.util.Date;

public class RefundPostDetails {

	int transactionNo;
	int srTransactionNo;
	int fileId;
	String fileIdentifier;
	String srNumber;
	String srCategory;
	
	String accountExternalId;
	String dateOfRefund;
	Double refundAmount;
	String refundReasonCode;
	String refundTypeCode;
	String refundType;
	
	String source;
	String apsFalg;
	
	String chequeNo;
	String address1;
	String address2;
	String address3;
	String payeeCity;
	String payeeCompany;
	String payeeFirstName;
	String payeeLasttName;
	String payeeZipCode;
	String payeeState;
	String lob;
	String approvalLevel;
	int sNo;
	String segment;
	
	Timestamp createdDate;
	Timestamp modifiedDate;
	
	int targetTrackingId;
	int targettrackinIdServ;
	int statusCode;
	String statusDescription;
	int noOfHit;
	String userId;
	
	public int getTransactionNo() {
		return transactionNo;
	}
	public void setTransactionNo(int transactionNo) {
		this.transactionNo = transactionNo;
	}
	public int getSrTransactionNo() {
		return srTransactionNo;
	}
	public void setSrTransactionNo(int srTransactionNo) {
		this.srTransactionNo = srTransactionNo;
	}
	public int getFileId() {
		return fileId;
	}
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}
	public String getFileIdentifier() {
		return fileIdentifier;
	}
	public void setFileIdentifier(String fileIdentifier) {
		this.fileIdentifier = fileIdentifier;
	}
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getSrCategory() {
		return srCategory;
	}
	public void setSrCategory(String srCategory) {
		this.srCategory = srCategory;
	}
	
	public String getAccountExternalId() {
		return accountExternalId;
	}
	public void setAccountExternalId(String accountExternalId) {
		this.accountExternalId = accountExternalId;
	}
	public String getDateOfRefund() {
		return dateOfRefund;
	}
	public void setDateOfRefund(String dateOfRefund) {
		this.dateOfRefund = dateOfRefund;
	}
	public Double getRefundAmount() {
		return refundAmount;
	}
	public void setRefundAmount(Double refundAmount) {
		this.refundAmount = refundAmount;
	}
	public String getRefundReasonCode() {
		return refundReasonCode;
	}
	public void setRefundReasonCode(String refundReasonCode) {
		this.refundReasonCode = refundReasonCode;
	}
	public String getRefundTypeCode() {
		return refundTypeCode;
	}
	public void setRefundTypeCode(String refundTypeCode) {
		this.refundTypeCode = refundTypeCode;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getApsFalg() {
		return apsFalg;
	}
	public void setApsFalg(String apsFalg) {
		this.apsFalg = apsFalg;
	}
	public String getChequeNo() {
		return chequeNo;
	}
	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getAddress3() {
		return address3;
	}
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	public String getPayeeCity() {
		return payeeCity;
	}
	public void setPayeeCity(String payeeCity) {
		this.payeeCity = payeeCity;
	}
	public String getPayeeCompany() {
		return payeeCompany;
	}
	public void setPayeeCompany(String payeeCompany) {
		this.payeeCompany = payeeCompany;
	}
	public String getPayeeFirstName() {
		return payeeFirstName;
	}
	public void setPayeeFirstName(String payeeFirstName) {
		this.payeeFirstName = payeeFirstName;
	}
	public String getPayeeLasttName() {
		return payeeLasttName;
	}
	public void setPayeeLasttName(String payeeLasttName) {
		this.payeeLasttName = payeeLasttName;
	}
	public String getPayeeZipCode() {
		return payeeZipCode;
	}
	public void setPayeeZipCode(String payeeZipCode) {
		this.payeeZipCode = payeeZipCode;
	}
	public String getPayeeState() {
		return payeeState;
	}
	public void setPayeeState(String payeeState) {
		this.payeeState = payeeState;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getApprovalLevel() {
		return approvalLevel;
	}
	public void setApprovalLevel(String approvalLevel) {
		this.approvalLevel = approvalLevel;
	}
	public int getsNo() {
		return sNo;
	}
	public void setsNo(int sNo) {
		this.sNo = sNo;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public int getTargetTrackingId() {
		return targetTrackingId;
	}
	public void setTargetTrackingId(int targetTrackingId) {
		this.targetTrackingId = targetTrackingId;
	}
	public int getTargettrackinIdServ() {
		return targettrackinIdServ;
	}
	public void setTargettrackinIdServ(int targettrackinIdServ) {
		this.targettrackinIdServ = targettrackinIdServ;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	public int getNoOfHit() {
		return noOfHit;
	}
	public void setNoOfHit(int noOfHit) {
		this.noOfHit = noOfHit;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getRefundType() {
		return refundType;
	}
	public void setRefundType(String refundType) {
		this.refundType = refundType;
	}
	public String getSegment() {
		return segment;
	}
	public void setSegment(String segment) {
		this.segment = segment;
	}
	
	
}
