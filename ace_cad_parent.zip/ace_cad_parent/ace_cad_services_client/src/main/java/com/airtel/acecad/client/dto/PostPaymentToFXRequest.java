package com.airtel.acecad.client.dto;



public class PostPaymentToFXRequest {
	
	private String lob;
	private String refNum;
	private String currency;
	private String submitter;
	private String chequeNumber;
	private String code;
	private Double currencyAmount;
	private Double amount;
	private String mode;
	private String depositType;
	private String customerAccountId;
	private String paymentRecievedDate;
	private String bmfTransType;
	private String invoiceNum;
	private String customerBillId;
	private String recordId;
	private String partyPaymentId;
	private String statusCode;
	private String statusMessage;
	private String postRetrialAttempts;
	private String trackingId;
	private String trackingIdServ;
	private String origTrackingId;
	private String origTrackingIdServ;
	private String changeWho;
	//ADDED FOR ECS CHARGING
	private String srNumber;
	private String billRefResets;
	private String b2bB2c;
//	ADDED for paymentAdvice
	private String paymentDetails3;
	private String paymenAdviceRequestID;
	//For NEFT UTR no-18JAN2018
		private String incomingTransactionRefNo;
	
	private String acctExtId;
	private String recordType;
	private String paymentMode;
	private String invoiceNumber;
	private String refNumber;
	private String paymentCode;
	private String paymentDate;
	private String paymentAmount;
	private String annotation;
	private String noOfHits;
	private String transactionId;
	private String bankName;
	private String b2bB2cSeg;
	private String billRefReset;
	private String incomingTransRefNumber;
	private String userId;
	private String apsFlag;
	
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public String getRefNumber() {
		return refNumber;
	}
	public void setRefNumber(String refNumber) {
		this.refNumber = refNumber;
	}
	public String getPaymentCode() {
		return paymentCode;
	}
	public void setPaymentCode(String paymentCode) {
		this.paymentCode = paymentCode;
	}
	public String getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}
	public String getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public String getAnnotation() {
		return annotation;
	}
	public void setAnnotation(String annotation) {
		this.annotation = annotation;
	}
	public String getNoOfHits() {
		return noOfHits;
	}
	public void setNoOfHits(String noOfHits) {
		this.noOfHits = noOfHits;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getB2bB2cSeg() {
		return b2bB2cSeg;
	}
	public void setB2bB2cSeg(String b2bB2cSeg) {
		this.b2bB2cSeg = b2bB2cSeg;
	}
	public String getBillRefReset() {
		return billRefReset;
	}
	public void setBillRefReset(String billRefReset) {
		this.billRefReset = billRefReset;
	}
	public String getIncomingTransRefNumber() {
		return incomingTransRefNumber;
	}
	public void setIncomingTransRefNumber(String incomingTransRefNumber) {
		this.incomingTransRefNumber = incomingTransRefNumber;
	}
	public String getAcctExtId() {
		return acctExtId;
	}
	public void setAcctExtId(String acctExtId) {
		this.acctExtId = acctExtId;
	}
	public String getRecordType() {
		return recordType;
	}
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getRefNum() {
		return refNum;
	}
	public void setRefNum(String refNum) {
		this.refNum = refNum;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getSubmitter() {
		return submitter;
	}
	public void setSubmitter(String submitter) {
		this.submitter = submitter;
	}
	public String getChequeNumber() {
		return chequeNumber;
	}
	public void setChequeNumber(String chequeNumber) {
		this.chequeNumber = chequeNumber;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Double getCurrencyAmount() {
		return currencyAmount;
	}
	public void setCurrencyAmount(Double currencyAmount) {
		this.currencyAmount = currencyAmount;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getDepositType() {
		return depositType;
	}
	public void setDepositType(String depositType) {
		this.depositType = depositType;
	}
	public String getCustomerAccountId() {
		return customerAccountId;
	}
	public void setCustomerAccountId(String customerAccountId) {
		this.customerAccountId = customerAccountId;
	}
	public String getPaymentRecievedDate() {
		return paymentRecievedDate;
	}
	public void setPaymentRecievedDate(String paymentRecievedDate) {
		this.paymentRecievedDate = paymentRecievedDate;
	}
	public String getBmfTransType() {
		return bmfTransType;
	}
	public void setBmfTransType(String bmfTransType) {
		this.bmfTransType = bmfTransType;
	}
	public String getInvoiceNum() {
		return invoiceNum;
	}
	public void setInvoiceNum(String invoiceNum) {
		this.invoiceNum = invoiceNum;
	}
	public String getCustomerBillId() {
		return customerBillId;
	}
	public void setCustomerBillId(String customerBillId) {
		this.customerBillId = customerBillId;
	}
	public String getRecordId() {
		return recordId;
	}
	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}
	public String getPartyPaymentId() {
		return partyPaymentId;
	}
	public void setPartyPaymentId(String partyPaymentId) {
		this.partyPaymentId = partyPaymentId;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public String getPostRetrialAttempts() {
		return postRetrialAttempts;
	}
	public void setPostRetrialAttempts(String postRetrialAttempts) {
		this.postRetrialAttempts = postRetrialAttempts;
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	public String getTrackingIdServ() {
		return trackingIdServ;
	}
	public void setTrackingIdServ(String trackingIdServ) {
		this.trackingIdServ = trackingIdServ;
	}
	public String getOrigTrackingId() {
		return origTrackingId;
	}
	public void setOrigTrackingId(String origTrackingId) {
		this.origTrackingId = origTrackingId;
	}
	public String getOrigTrackingIdServ() {
		return origTrackingIdServ;
	}
	public void setOrigTrackingIdServ(String origTrackingIdServ) {
		this.origTrackingIdServ = origTrackingIdServ;
	}
	public String getChangeWho() {
		return changeWho;
	}
	public void setChangeWho(String changeWho) {
		this.changeWho = changeWho;
	}
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getBillRefResets() {
		return billRefResets;
	}
	public void setBillRefResets(String billRefResets) {
		this.billRefResets = billRefResets;
	}
	public String getB2bB2c() {
		return b2bB2c;
	}
	public void setB2bB2c(String b2bB2c) {
		this.b2bB2c = b2bB2c;
	}
	public String getPaymentDetails3() {
		return paymentDetails3;
	}
	public void setPaymentDetails3(String paymentDetails3) {
		this.paymentDetails3 = paymentDetails3;
	}
	public String getPaymenAdviceRequestID() {
		return paymenAdviceRequestID;
	}
	public void setPaymenAdviceRequestID(String paymenAdviceRequestID) {
		this.paymenAdviceRequestID = paymenAdviceRequestID;
	}
	public String getIncomingTransactionRefNo() {
		return incomingTransactionRefNo;
	}
	public void setIncomingTransactionRefNo(String incomingTransactionRefNo) {
		this.incomingTransactionRefNo = incomingTransactionRefNo;
	}
	public String getApsFlag() {
		return apsFlag;
	}
	public void setApsFlag(String apsFlag) {
		this.apsFlag = apsFlag;
	}

	
	
}
