package com.airtel.acecad.client.json.custAccountSummaryJson;

public class RequestDataArea {

	private GetCustomerAccountSummary getCustomerAccountSummary;

    public GetCustomerAccountSummary getGetCustomerAccountSummary ()
    {
        return getCustomerAccountSummary;
    }

    public void setGetCustomerAccountSummary (GetCustomerAccountSummary getCustomerAccountSummary)
    {
        this.getCustomerAccountSummary = getCustomerAccountSummary;
    }

    @Override
    public String toString()
    {
        return "{\"getCustomerAccountSummary\" : "+getCustomerAccountSummary+"}";
    }
}
