package com.airtel.acecad.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.airtel.acecad.client.dao.ClientDAO;
import com.airtel.acecad.client.dao.ClientDAOImpl;
import com.airtel.acecad.client.dto.AdjPostDetails;
import com.airtel.acecad.client.dto.CreateUpdateNotesDetails;
import com.airtel.acecad.client.dto.DepositReversalDetails;
import com.airtel.acecad.client.dto.SRApprovalTaskCallbackDetails;
import com.airtel.acecad.client.json.createUpdateNotesJson.BusinessInteraction;
import com.airtel.acecad.client.json.createUpdateNotesJson.CreateUpdateNotesRequestPojo;
import com.airtel.acecad.client.json.createUpdateNotesJson.CreateUpdateNotesResponsePojo;
import com.airtel.acecad.client.json.createUpdateNotesJson.DetailFault;
import com.airtel.acecad.client.json.createUpdateNotesJson.EbmHeader;
import com.airtel.acecad.client.json.createUpdateNotesJson.EbmHeader1;
import com.airtel.acecad.client.json.createUpdateNotesJson.Fault;
import com.airtel.acecad.client.json.createUpdateNotesJson.Identification;
import com.airtel.acecad.client.json.createUpdateNotesJson.LogicalResource;
import com.airtel.acecad.client.json.createUpdateNotesJson.LogicalResourceIdentification;
import com.airtel.acecad.client.json.createUpdateNotesJson.RequestDataArea;
import com.airtel.acecad.client.json.createUpdateNotesJson.ResponseDataArea;
import com.airtel.acecad.client.json.createUpdateNotesJson.SoaFault;
import com.airtel.acecad.client.json.createUpdateNotesJson.Status;
import com.airtel.acecad.client.json.createUpdateNotesJson.SyncCustomerInteraction;
import com.airtel.acecad.client.json.createUpdateNotesJson.SyncCustomerInteractionFault;
import com.airtel.acecad.client.json.createUpdateNotesJson.SyncCustomerInteractionReqMsg;
import com.airtel.acecad.client.json.createUpdateNotesJson.SyncCustomerInteractionResMsg;
import com.airtel.acecad.client.json.createUpdateNotesJson.SyncCustomerInteractionResponse;
import com.airtel.acecad.client.json.createUpdateNotesJson.TrackingRecord;

import com.airtel.acecad.client.util.GenericConfiguration;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.CustomResponseErrorHandler;
import com.airtel.acecad.client.util.EncryDecrypUtility;
import com.airtel.acecad.client.util.GlobalConstants;

////////////////////////////////////INT_226_F////////////////////////////////////

public class CreateUpdateNotesDetailsClient implements GlobalConstants {

	private static Logger log = LogManager.getLogger("serviceClientUI");
	/*
	 * @author :- Geeta Rajput-- To Create Request Json Format for update
	 * deposite details Request
	 */
	public String createRequestJSONForCreateUpdateNotesToFX(int sr_transaction_no,String file_identifier) throws Exception {

		log.info(
				"START--->in createRequestJSONForCreateUpdateNotesToFX method of CreateUpdateNotesDetailsClient and sr_transaction_no--->>"
						+ sr_transaction_no);

		CreateUpdateNotesDetailsClient createUpdateNotesDetailsClient = new CreateUpdateNotesDetailsClient();
		//List<CreateUpdateNotesDetails> updateNotesDetailsList = new ArrayList<CreateUpdateNotesDetails>();
		CreateUpdateNotesDetails createUpdateNotesDetails= new CreateUpdateNotesDetails();
		String result = EMPTY_STRING;
		int srTransactionNo = EMPTY_VALUE;
		String tableName=EMPTY_STRING;
		ClientDAO clientDAO = new ClientDAOImpl();
		//updateNotesDetailsList = clientDAO.fetchUpdateNotesDetails(sr_transaction_no); 
		Object[] obj = clientDAO.fetchCreateUpdateNotesDetails(sr_transaction_no);
		/*log.info("updateNotesDetailsList in createRequestJSONForCreateUpdateNotesToFX---->>" + updateNotesDetailsList
				+ "and sr_transaction_no--->>" + sr_transaction_no);*/
		String successFlag=(String) obj[0];
		createUpdateNotesDetails=(CreateUpdateNotesDetails) obj[1];
		if ("SUCCESS".equalsIgnoreCase(successFlag)) {
		//for (int i = 0; i < updateNotesDetailsList.size(); i++) {

			//CreateUpdateNotesDetails createUpdateNotesDetails = new CreateUpdateNotesDetails();
			//createUpdateNotesDetails = updateNotesDetailsList.get(i);

			SyncCustomerInteractionReqMsg syncCustomerInteractionReqMsg = new SyncCustomerInteractionReqMsg();
			EbmHeader ebmHeader = new EbmHeader();
			ebmHeader.setLob(LOB);
			String consumerTransactionId = APS + CommonUtil.randomMethod();
			log.info("consumerTransactionId in createRequestJSONForAdjustmentReversalToFX----->"
					+ consumerTransactionId);
			ebmHeader.setConsumerTransactionId(consumerTransactionId);
			ebmHeader.setCustomerMigrated(TRUE);

			syncCustomerInteractionReqMsg.setEbmHeader(ebmHeader);

			RequestDataArea requestDataArea = new RequestDataArea();

			SyncCustomerInteraction syncCustomerInteraction = new SyncCustomerInteraction();
			syncCustomerInteraction.setOperationType(OPRERATION_TYPE_NOTES);

			
		    //Change to NULL	
			LogicalResource logicalResource = new LogicalResource();

			LogicalResourceIdentification logicalResourceIdentification = new LogicalResourceIdentification();

			logicalResourceIdentification.setId("");// conditional

			logicalResource.setIdentification(logicalResourceIdentification);

			syncCustomerInteraction.setLogicalResource(logicalResource);

			BusinessInteraction businessInteraction = new BusinessInteraction();

			Identification identification = new Identification();
			identification.setId(createUpdateNotesDetails.getSrNumber());

			identification.setType(BUSSINESS_INTERACTION_IDTYPE_SR);// For SR

			businessInteraction.setIdentification(identification);

			businessInteraction.setDescription(createUpdateNotesDetails.getComments());

			// businessInteraction.setType("General");

			syncCustomerInteraction.setBusinessInteraction(businessInteraction);

			TrackingRecord trackingRecord = new TrackingRecord();
			trackingRecord.setSystemId(APS_SYSTEMID);// TO BE CONFIGURED---CHECK BY RITU
			trackingRecord.setUserId(createUpdateNotesDetails.getUserId());

			syncCustomerInteraction.setTrackingRecord(trackingRecord);

			requestDataArea.setSyncCustomerInteraction(syncCustomerInteraction);

			syncCustomerInteractionReqMsg.setDataArea(requestDataArea);

			CreateUpdateNotesRequestPojo requestPojo = new CreateUpdateNotesRequestPojo();
			if (syncCustomerInteractionReqMsg != null) {
				requestPojo.setSyncCustomerInteractionReqMsg(syncCustomerInteractionReqMsg);
			}
			log.info(syncCustomerInteractionReqMsg.toString());
			log.info("requestpojo in createRequestJSONForCreateUpdateNotesToFX--->>" + requestPojo
					+ " and sr_transaction_no--->>" + sr_transaction_no);
			if (createUpdateNotesDetails.getSrTransactionNo() != 0) {
				srTransactionNo = createUpdateNotesDetails.getSrTransactionNo();
			}

			log.info("Before hitting the posting fx job_id for transaction no in INT---" + srTransactionNo
					+ " in createRequestJSONForCreateUpdateNotesToFX");
			
			if(INTERIM.equalsIgnoreCase(file_identifier))
				tableName="SR_DETAILS_APS";
			else
				tableName="REFUND_PAYMENT_APS";
		
			Object[] resultobj = clientDAO.updateJobId(tableName, srTransactionNo,null,0);
			
			log.info("After hitting the posting fx job_id jobId in createRequestJSONForCreateUpdateNotesToFX result is:"
					+ resultobj[0] + "and job id is"+resultobj[1]+" and srtransaction_no " + srTransactionNo);
			if (RESULT_DB_SUCCESFUL.equalsIgnoreCase((String) resultobj[0])) {

				log.info(
						"Before postUpdateCreateUpadteNotesToFX in createRequestJSONForCreateUpdateNotesToFX and sr_transaction_no--->>"
								+ sr_transaction_no);

				result = createUpdateNotesDetailsClient.postUpdateCreateUpadteNotesToFX(requestPojo,
						createUpdateNotesDetails, sr_transaction_no,(int)resultobj[1],file_identifier,tableName);
				log.info(
						"After postUpdateCreateUpadteNotesToFX in createRequestJSONForCreateUpdateNotesToFX result------>"
								+ result + "and sr_transaction_no--->>" + sr_transaction_no);

			}

		//}
        }
		
		//}
		else{
			result="Failure";
		}
			log.info(
					"END----in createRequestJSONForCreateUpdateNotesToFX method of CreateUpdateNotesDetailsClient and sr_transaction_no--->>"
							+ sr_transaction_no);
		return result;

	}

	/*
	 * @author :- Geeta Rajput-FOR Ajustment Posting(create) to FX
	 */
	public String postUpdateCreateUpadteNotesToFX(CreateUpdateNotesRequestPojo requestPojo,
			CreateUpdateNotesDetails createUpdateNotesDetails, int sr_transaction_no,int jobId,String file_identifier
			,String tableName) throws Exception {

		log.info("START --> in postUpdateCreateUpadteNotesToFX method of CreateUpdateNotesDetailsClient");
		SyncCustomerInteractionResMsg syncCustomerInteractionResMsg = null;
		Fault fault = null;
		String result = EMPTY_STRING;
		String status_code = EMPTY_STRING;

		ClientDAO clientDao = new ClientDAOImpl();
		String resultConectRead = EMPTY_STRING;

		try {

			String clientURL = GenericConfiguration.getDescription("kenon.postUpdateCreateUpdateNotesToFX.url");

			RestTemplate restTemplate = new RestTemplate();

			//ADDED FOR HANDLING TIMEOUT ERRORS
			restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
			.setConnectTimeout(Integer.parseInt(GenericConfiguration.getDescription("connect_time_out")));
	        ((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
			.setReadTimeout(Integer.parseInt(GenericConfiguration.getDescription("read_time_out")));
			
			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
			restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
			restTemplate.setErrorHandler(new CustomResponseErrorHandler());
			HttpHeaders headers = new HttpHeaders();
            
			//Added by Ritu (EncryptDecrypt Password)
			String userpass = GenericConfiguration.getDescription("kenon.postUpdateCreateUpdateNotesToFX.userName") + ":"
					+ EncryDecrypUtility.decrypt(GenericConfiguration.getDescription("kenon.postUpdateCreateUpdateNotesToFX.password"));

			log.info("clientURL in postUpdateCreateUpadteNotesToFX-->" + clientURL+ "and sr_transaction_no--->>" + sr_transaction_no);
			headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

			HttpEntity<CreateUpdateNotesRequestPojo> entity = new HttpEntity<CreateUpdateNotesRequestPojo>(requestPojo,
					headers);
			ResponseEntity<CreateUpdateNotesResponsePojo> responsePojo = null;
			try {
				//System.out.println("requestPojo " + requestPojo);
				// Execute the httpMethod to given uri template,writing the
				// given request and returns the response as ResponseEntity
				responsePojo = restTemplate.exchange(clientURL, HttpMethod.POST, entity,
						CreateUpdateNotesResponsePojo.class);
				log.info("responsePojo in postUpdateCreateUpadteNotesToFX---" + responsePojo
						+ " and sr_transaction_no--->>" + sr_transaction_no);

				status_code = responsePojo.getStatusCode().toString();
				if (responsePojo != null) {
					if (HttpStatus.OK == responsePojo.getStatusCode()) {
						if(responsePojo.getBody().getSyncCustomerInteractionResMsg()!=null){
							status_code = responsePojo.getStatusCode().toString();
						syncCustomerInteractionResMsg = responsePojo.getBody().getSyncCustomerInteractionResMsg();
						log.info("success-->in postUpdateCreateUpadteNotesToFX--->>"
								+ responsePojo.getBody().getSyncCustomerInteractionResMsg()
								+ " and sr_transaction_no--->>" + sr_transaction_no);

					} else {
						status_code = responsePojo.getStatusCode().toString();
						fault = responsePojo.getBody().getFault();
						log.info("faultResponsePojo in postUpdateCreateUpadteNotesToFX in http 200 ok-->>" + fault
								+ " and sr_transaction_no--->>" + sr_transaction_no);
					}
					}
					else {
						status_code = responsePojo.getStatusCode().toString();
						fault = responsePojo.getBody().getFault();
						log.info("faultResponsePojo in postUpdateCreateUpadteNotesToFX-->>" + fault
								+ " and sr_transaction_no--->>" + sr_transaction_no);
					}
					result = createResponseJSONForCreateUpdateNotesToFX(syncCustomerInteractionResMsg, fault,
							createUpdateNotesDetails, status_code, sr_transaction_no,jobId,file_identifier);
					log.info("After createResponseJSONForCreateUpdateNotesToFX response in postUpdateCreateUpadteNotesToFX-->>" + result+ "and sr_transaction_no--->>" + sr_transaction_no);

					/*log.info(
							"After createResponseJSONForCreateUpdateNotesToFX in postUpdateCreateUpadteNotesToFX result-->>"
									+ result+ "and sr_transaction_no--->>" + sr_transaction_no);*/
				} 
			} catch (Exception e) {
				log.info(
						"Got faulty code from the response of FX in postUpdateCreateUpadteNotesToFX and sr_transaction_no--->>"
								+ sr_transaction_no);
			/*	log.info("Got faulty code from the response of FX in postUpdateCreateUpadteNotesToFX" + responsePojo
						+ " and sr_transaction_no--->>" + sr_transaction_no);*/
				
				if (e.getCause().toString().contains(CONNECT_TEXT)) {

					resultConectRead = clientDao.updateConnectionReadResponse(sr_transaction_no, tableName,
							CONNECT_TEXT);
					log.info("Got faulty code from the response CONNECT_TEXT of FX resultConectRead postUpdateCreateUpadteNotesToFX----->"
							+ resultConectRead+ "and sr_transaction_no--->>" + sr_transaction_no);
				}

				if (e.getCause().toString().contains(READ_TEXT)) {

					resultConectRead = clientDao.updateConnectionReadResponse(sr_transaction_no, tableName,
							READ_TEXT);
					log.info("Got faulty code from the response READ_TEXT  of FX resultConectRead postUpdateCreateUpadteNotesToFX----->"
							+ resultConectRead+ "and sr_transaction_no--->>" + sr_transaction_no);

				}

			}

		} catch (Exception e) {
			log.info("exception in postUpdateCreateUpadteNotesToFX" + e);

			if (e.getCause().toString().contains(CONNECT_TEXT)) {

				resultConectRead = clientDao.updateConnectionReadResponse(sr_transaction_no, tableName, CONNECT_TEXT);
				log.info("Got faulty code from the response CONNECT_TEXT of FX resultConectRead----->"
						+ resultConectRead+ "and sr_transaction_no--->>" + sr_transaction_no);
			}

			if (e.getCause().toString().contains(READ_TEXT)) {

				resultConectRead = clientDao.updateConnectionReadResponse(sr_transaction_no, tableName, READ_TEXT);
				log.info(
						"Got faulty code from the response READ_TEXT  of FX resultConectRead----->" + resultConectRead+ "and sr_transaction_no--->>" + sr_transaction_no);

			}
		}
		log.info(
				"END--->in postUpdateCreateUpadteNotesToFX method of CreateUpdateNotesDetailsClient and sr_transaction_no--->>"
						+ sr_transaction_no);
		return result;
	}

	/*
	 * @author :- Geeta Rajput-- To Create ResponseJson Format for update
	 * 
	 */
	public String createResponseJSONForCreateUpdateNotesToFX(
			SyncCustomerInteractionResMsg syncCustomerInteractionResMsg, Fault fault,
			CreateUpdateNotesDetails createUpdateNotesDetails, String statusCodeWeb, int sr_transaction_no,int jobId,String file_identifier)
			throws Exception {

		log.info(
				"START----in createResponseJSONForCreateUpdateNotesToFX method of CreateUpdateNotesDetailsClient and sr_transaction_no--->>"
						+ sr_transaction_no);

		String result = EMPTY_STRING;
		String faultDescription = EMPTY_STRING;
		String status_description = EMPTY_STRING;
		String status_code=EMPTY_STRING;

		EbmHeader1 ebmHeader1 = new EbmHeader1();
		if (syncCustomerInteractionResMsg != null) {
			log.info("In if loop when got success response from webservice --226_F INT and sr_transaction_no -->>"
					+ sr_transaction_no + "in createResponseJSONForCreateUpdateNotesToFX");

			if (syncCustomerInteractionResMsg.getEbmHeader() != null) {
				ebmHeader1 = syncCustomerInteractionResMsg.getEbmHeader();
			}
			ResponseDataArea responseDataArea = new ResponseDataArea();
			if (syncCustomerInteractionResMsg.getDataArea() != null) {
				responseDataArea = syncCustomerInteractionResMsg.getDataArea();
			}

			SyncCustomerInteractionResponse syncCustomerInteractionResponse = new SyncCustomerInteractionResponse();
			if (responseDataArea.getSyncCustomerInteractionResponse() != null) {
				syncCustomerInteractionResponse = responseDataArea.getSyncCustomerInteractionResponse();
			}

			Status status = new Status();
			if (syncCustomerInteractionResponse.getStatus() != null) {
				status = syncCustomerInteractionResponse.getStatus();
			}
			
			if (status != null) {
				if (CommonUtil.isNotNull(status.getStatusCode())) {
					String[] statusCodeArray = status.getStatusCode().split("-");
					status_code = statusCodeArray[1] + "-" + statusCodeArray[2];
					log.info("status code in createResponseJSONForCreateUpdateNotesToFX-->>" + status_code);
				}
			if (CommonUtil.isNotNull(status.getStatusCode()) || CommonUtil.isNotNull(status.getStatusDescription())) {
				status_description = status_code + ":" + status.getStatusDescription();
				log.info("status_description--->>" + status_description);
			}
			}
			log.info("status_description after response in createResponseJSONForCreateUpdateNotesToFX--"
					+ status_description + "and sr_transaction_no-->>" + sr_transaction_no);

			CreateUpdateNotesResponsePojo createUpdateNotesResponsePojo = new CreateUpdateNotesResponsePojo();
			if (createUpdateNotesResponsePojo != null) {
				syncCustomerInteractionResMsg = createUpdateNotesResponsePojo.getSyncCustomerInteractionResMsg();
			}
		} else if (fault != null) {
			log.info(
					"In else loop when got error response from webservice in createResponseJSONForCreateUpdateNotesToFX --362 InT and sr_transaction_no-->>"
							+ sr_transaction_no);
			if (statusCodeWeb.contains(status_code_504)) {
				//status_description = fault.getFaultstring();
				String fault_value=fault.getFaultstring();
				if(fault_value.length()>999){
					fault_value=fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description= status_description.replace("'", "");
				log.info("Status description is in createResponseJSONForCreateUpdateNotesToFX---> " + status_description
						+ "and sr_transaction_no-->>" + sr_transaction_no);
			} else if (statusCodeWeb.contains(status_code_502)) {
				//status_description = fault.getFaultstring();
				String fault_value=fault.getFaultstring();
				if(fault_value.length()>999){
					fault_value=fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description= status_description.replace("'", "");
				log.info("Status description is in createResponseJSONForCreateUpdateNotesToFX---> " + status_description
						+ "and sr_transaction_no-->>" + sr_transaction_no);
			} else if (statusCodeWeb.contains(status_code_400)) {
				//status_description = fault.getFaultstring();
				String fault_value=fault.getFaultstring();
				if(fault_value.length()>999){
					fault_value=fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description= status_description.replace("'", "");
				log.info("Status description is in createResponseJSONForDepositReversalToFX---> "
						+ status_description + "and sr_transaction_no-->>" + sr_transaction_no);
				
			} else {
				DetailFault detail = fault.getDetail();
				if (detail != null) {
					SyncCustomerInteractionFault syncCustomerInteractionFault = detail
							.getSyncCustomerInteractionFault();
					if (syncCustomerInteractionFault != null) {
						SoaFault soaFault = syncCustomerInteractionFault.getSoaFault();
						if (soaFault != null) {
							
							if (CommonUtil.isNotNull(soaFault.getSoaFaultCode())) {
								String[] soaFaultCodeArray = soaFault.getSoaFaultCode().split("-");
								status_code = soaFaultCodeArray[1] + "-" + soaFaultCodeArray[2];
								log.info("soa fault status code in createResponseJSONForCreateUpdateNotesToFX----->>>"
										+ status_code + "and sr_transaction_no-->>" + sr_transaction_no);

							}
							
							if (CommonUtil.isNotNull(soaFault.getFaultDescription())) {
								//status_description = status_code+":"+soaFault.getFaultDescription();
								String fault_value=soaFault.getFaultDescription();
								if(fault_value.length()>999){
									fault_value=fault_value.substring(0, 1000);
								}
								status_description = status_code + ":" + fault_value;
								status_description= status_description.replace("'", "");
								log.info("faultDescription in createResponseJSONForCreateUpdateNotesToFX---->"
										+ status_description + "and sr_transaction_no-->>" + sr_transaction_no);
							}
						}

					}

				}

			}

		}
		ClientDAO clientDAO = new ClientDAOImpl();
		//log.info("sr trans no in method createResponseJSONForCreateUpdateNotesToFX---->" + sr_transaction_no);
		log.info(
				"Before updateResponseForCreateUpdateNotes in createResponseJSONForCreateUpdateNotesToFX and sr_transaction_no-->>"
						+ sr_transaction_no+" and job_id-->"+jobId);
		/*result = clientDAO.updateResponseForCreateUpdateNotes(statusCodeWeb, status_description, sr_transaction_no,
				createUpdateNotesDetails,status_code,jobId,file_identifier);*/
		result = clientDAO.updateResponseForNotes(status_description, sr_transaction_no,file_identifier);
		log.info("After updateResponseForCreateUpdateNotes in createResponseJSONForCreateUpdateNotesToFX result----->>>"
				+ result + "and transaction_no-->>" + sr_transaction_no);
		log.info("END----in createResponseJSONForCreateUpdateNotesToFX method of CreateUpdateNotesDetailsClient "
				+ faultDescription + "and transaction_no-->>" + sr_transaction_no);
		return result;

	}

	/*public static void main(String[] args) throws Exception {
		CreateUpdateNotesDetailsClient createUpdateNotesDetailsClient=new CreateUpdateNotesDetailsClient();
		createUpdateNotesDetailsClient.createRequestJSONForCreateUpdateNotesToFX(918);
	}*/
}
