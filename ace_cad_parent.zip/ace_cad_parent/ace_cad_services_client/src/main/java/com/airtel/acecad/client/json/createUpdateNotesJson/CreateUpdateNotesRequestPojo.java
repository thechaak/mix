package com.airtel.acecad.client.json.createUpdateNotesJson;

public class CreateUpdateNotesRequestPojo {

	private SyncCustomerInteractionReqMsg syncCustomerInteractionReqMsg;

    public SyncCustomerInteractionReqMsg getSyncCustomerInteractionReqMsg ()
    {
        return syncCustomerInteractionReqMsg;
    }

    public void setSyncCustomerInteractionReqMsg (SyncCustomerInteractionReqMsg syncCustomerInteractionReqMsg)
    {
        this.syncCustomerInteractionReqMsg = syncCustomerInteractionReqMsg;
    }

    @Override
    public String toString()
    {
        return "{\"syncCustomerInteractionReqMsg\" : "+syncCustomerInteractionReqMsg+"}";
    }
}
