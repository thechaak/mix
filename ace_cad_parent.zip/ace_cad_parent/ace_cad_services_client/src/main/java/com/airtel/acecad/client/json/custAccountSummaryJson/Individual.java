package com.airtel.acecad.client.json.custAccountSummaryJson;

public class Individual {

	private IndividualName individualName;
	
	private Contact contact;

    public IndividualName getIndividualName ()
    {
        return individualName;
    }

    public void setIndividualName (IndividualName individualName)
    {
        this.individualName = individualName;
    }

    
    public Contact getContact() {
		return contact;
	}

	public void setContact(Contact contact) {
		this.contact = contact;
	}

	@Override
    public String toString()
    {
        return "{\"individualName\" : "+individualName+",\"contact\" : "+contact+"}";
    }
}
