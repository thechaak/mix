package com.airtel.acecad.client;

import java.util.Arrays;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.impl.client.HttpClients;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.airtel.acecad.client.dto.BulkDetails;
import com.airtel.acecad.client.json.customerInvoiceJson.BillPeriod;
import com.airtel.acecad.client.json.customerInvoiceJson.Customer;
import com.airtel.acecad.client.json.customerInvoiceJson.CustomerAccount;
import com.airtel.acecad.client.json.customerInvoiceJson.CustomerBillingCycle;
import com.airtel.acecad.client.json.customerInvoiceJson.CustomerInvoiceResponsePojo;
import com.airtel.acecad.client.json.customerInvoiceJson.CustomerPayment;
import com.airtel.acecad.client.json.customerInvoiceJson.DataArea;
import com.airtel.acecad.client.json.customerInvoiceJson.EbmHeader1;
import com.airtel.acecad.client.json.customerInvoiceJson.Fault;
import com.airtel.acecad.client.json.customerInvoiceJson.GetCustomerInvoiceSummaryResMsg;
import com.airtel.acecad.client.json.customerInvoiceJson.GetCustomerInvoiceSummaryResponse;
import com.airtel.acecad.client.json.customerInvoiceJson.Identification;
import com.airtel.acecad.client.json.customerInvoiceJson.InvoiceDetails;
import com.airtel.acecad.client.json.customerInvoiceJson.PartyBill;
import com.airtel.acecad.client.json.customerInvoiceJson.PartyPayment;
import com.airtel.acecad.client.json.customerInvoiceJson.Status;
import com.airtel.acecad.client.util.GenericConfiguration;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.EncryDecrypUtility;
import com.airtel.acecad.client.util.GlobalConstants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
/////////////////////////////INT_220///////////////////////////////////////////
public class CustomerInvoiceDetailsClient implements GlobalConstants {

	private static final Logger log = LogManager.getLogger("serviceClientUI");

	public BulkDetails postUpdateCustomerInvoiceToFX(BulkDetails fileRecords) throws Exception {

		log.info("Start :postUpdateCustomerInvoiceToFX in CustomerInvoiceDetailsClient");

		GetCustomerInvoiceSummaryResMsg getCustomerInvoiceSummaryResMsg = null;
		Fault fault = null;
		String result = EMPTY_STRING;

		try {
			ClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(
					HttpClients.createDefault());

			RestTemplate restTemplate = new RestTemplate(requestFactory);

			HttpHeaders headers = new HttpHeaders();
			
			String clientURL = GenericConfiguration.getDescription("Kenon.postUpdateCustomerInvoiceToFXFullURL.url") + fileRecords.getAcctEXTID();
            
			//Added by Ritu (EncryptDecrypt Password)
			String userpass = GenericConfiguration.getDescription("kenon.postUpdateCustomerInvoiceToFX.userName") + ":"
					+ EncryDecrypUtility.decrypt(GenericConfiguration.getDescription("kenon.postUpdateCustomerInvoiceToFX.password"));
			log.info("clientURL-->" + clientURL + "USERPASS--->" + userpass);
			headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);

			HttpEntity<String> entity = new HttpEntity<String>(headers);
			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(clientURL);
			 ResponseEntity<CustomerInvoiceResponsePojo> response =restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.GET, entity,
			CustomerInvoiceResponsePojo.class);
			 log.info("responsePojo--->>" + response.getBody().getGetCustomerInvoiceSummaryResMsg());

			try {
				
				 log.info("responsePojo--->>" + response);
				 
				if (HttpStatus.OK == response.getStatusCode()) {
					if(response.getBody().getGetCustomerInvoiceSummaryResMsg()!=null){
				 log.info("success--getCustomerInvoiceSummaryResMsg--->>" +response.getBody().getGetCustomerInvoiceSummaryResMsg());
				 getCustomerInvoiceSummaryResMsg =response.getBody().getGetCustomerInvoiceSummaryResMsg();
					}
				else { 
					fault = response.getBody().getFault();
				log.info("faultResponsePojo in postUpdateCustomerInvoiceToFX in http 200 ok-->>" + fault);
				}
				}
				else { 
					fault = response.getBody().getFault();
				log.info("faultResponsePojo in postUpdateCustomerInvoiceToFX-->>" + fault);
				}
			
				fileRecords = createResponseJSONForPostCustomerInvoiceDetailsToFX(getCustomerInvoiceSummaryResMsg, fault, fileRecords);
				log.info("response-->>" + result);
				 

			} catch (Exception e) {
				log.info("Got exception of 220 InT", e);
				fileRecords.setInvoiceNo("0");
				fileRecords.setOrigBillRefResets("0");
			}

		} catch (Exception e) {
			log.info("Got exception of 220 InT", e);
			fileRecords.setInvoiceNo("0");
			fileRecords.setOrigBillRefResets("0");
		}

		log.info("END--->in postUpdateCustomerInvoiceToFX method of CustomerInvoiceDetailsClient");
		return fileRecords;
	}

	public BulkDetails createResponseJSONForPostCustomerInvoiceDetailsToFX(
			GetCustomerInvoiceSummaryResMsg getCustomerInvoiceSummaryResMsg, Fault fault,BulkDetails fileRecords) {

		log.info("START--->in createResponseJSONForPostCustomerInvoiceDetailsToFX method of CustomerInvoiceDetailsClient");
//		String responsePojo = EMPTY_STRING;
		String result = EMPTY_STRING;
		String faultDescription = EMPTY_STRING;
		String status_description = EMPTY_STRING;
		String rowValues = EMPTY_STRING;

		if (getCustomerInvoiceSummaryResMsg != null) {

			EbmHeader1 ebmHeader = new EbmHeader1();
			if (ebmHeader != null) {
				if (CommonUtil.isNotNull(ebmHeader.getLob())) {
					ebmHeader.getLob();
				}
				if (CommonUtil.isNotNull(ebmHeader.getConsumerTransactionId())) {
					ebmHeader.getConsumerTransactionId();
				}
			}
			if (getCustomerInvoiceSummaryResMsg.getEbmHeader() != null) {

				ebmHeader = getCustomerInvoiceSummaryResMsg.getEbmHeader();

			}

			DataArea dataArea = new DataArea();
			if (getCustomerInvoiceSummaryResMsg.getDataArea() != null) {
				dataArea = getCustomerInvoiceSummaryResMsg.getDataArea();
			}

			GetCustomerInvoiceSummaryResponse getCustomerInvoiceSummaryResponse = new GetCustomerInvoiceSummaryResponse();
			if (dataArea.getGetCustomerInvoiceSummaryResponse() != null) {
				getCustomerInvoiceSummaryResponse = dataArea.getGetCustomerInvoiceSummaryResponse();
			}

			Status status = new Status();
			if (getCustomerInvoiceSummaryResponse.getStatus() != null) {
				status = getCustomerInvoiceSummaryResponse.getStatus();

				status_description = status.getStatusCode() + ":" + status.getStatusDescription();

				log.info("status_description in createResponseJSONForPostCustomerInvoiceDetailsToFX--->>" + status_description);
			}

			Customer customer = new Customer();
			CustomerBillingCycle customerBillingCycle = new CustomerBillingCycle();
			CustomerPayment customerPayment = new CustomerPayment();
			BillPeriod billPeriod = new BillPeriod();

			if(dataArea!=null){
			if (getCustomerInvoiceSummaryResponse != null) {

				InvoiceDetails[] invoiceDetails = new InvoiceDetails[getCustomerInvoiceSummaryResponse
						.getInvoiceDetails().length];
				invoiceDetails = getCustomerInvoiceSummaryResponse.getInvoiceDetails();

				log.info("invoiceDetails.length-->> " + invoiceDetails.length);
				if (invoiceDetails.length > 0) {
					log.info("invoiceDetails.length11-->> " + invoiceDetails.length);
					int count = 0;
					for (int i = invoiceDetails.length - 1; i >= 0; i--) {

						count++;
						rowValues = rowValues + " AND ROW " + count + "-->> ";
						log.info("payment.length22-->> " + invoiceDetails.length);
						boolean amountMatched = true;

						customer = invoiceDetails[i].getCustomer();
						customerBillingCycle = invoiceDetails[i].getCustomerBillingCycle();
						customerPayment = invoiceDetails[i].getCustomerPayment();
						billPeriod = invoiceDetails[i].getBillPeriod();

						if (customer != null) {
							CustomerAccount customerAccount = new CustomerAccount();
							if (customer.getCustomerAccount() != null) {
								customerAccount = customer.getCustomerAccount();
							}
							Identification identification = new Identification();
							if (customerAccount.getIdentification() != null) {
								identification = customerAccount.getIdentification();
							}
							if (CommonUtil.isNotNull(identification.getId())) {
								identification.getId();
								log.info("account id in createResponseJSONForPostCustomerInvoiceDetailsToFX-->>"+identification.getId());
							}
						}

						if (customerBillingCycle != null) {
							if (CommonUtil.isNotNull(customerBillingCycle.getBillingDate())) {
								customerBillingCycle.getBillingDate();
								log.info("BillingDate in createResponseJSONForPostCustomerInvoiceDetailsToFX-->>"+customerBillingCycle.getBillingDate());
							}
							if (CommonUtil.isNotNull(customerBillingCycle.getPaymentDueDate())) {
								customerBillingCycle.getPaymentDueDate();
								log.info("PaymentDueDate in createResponseJSONForPostCustomerInvoiceDetailsToFX-->>"+customerBillingCycle.getPaymentDueDate());
							}
							PartyBill partyBill = new PartyBill();
							if (partyBill != null) {

								if (CommonUtil.isNotNull(partyBill.getDueAmount())) {
									partyBill.getDueAmount();
									log.info("DueAmount in createResponseJSONForPostCustomerInvoiceDetailsToFX-->>"+partyBill.getDueAmount());
								}
								if (CommonUtil.isNotNull(partyBill.getTotalPaymentMade())) {
									partyBill.getTotalPaymentMade();
								}
								if (CommonUtil.isNotNull(partyBill.getTotalAdjustment())) {
									partyBill.getTotalAdjustment();
								}
								if (CommonUtil.isNotNull(partyBill.getNetAmountPayable())) {
									
									if(fileRecords.getAmountInr().equalsIgnoreCase(partyBill.getNetAmountPayable())){
										amountMatched = true;
									}else{
										amountMatched = false;
									}
									
									partyBill.getNetAmountPayable();
								}else{
									amountMatched = false;
								}
								if (CommonUtil.isNotNull(partyBill.getCarriedForward())) {
									partyBill.getCarriedForward();
								}
							}
							if (CommonUtil.isNotNull(customerBillingCycle.getBillActivationDate())) {
								customerBillingCycle.getBillActivationDate();
							}

							if (CommonUtil.isNotNull(customerBillingCycle.getLateExemptCharges())) {
								customerBillingCycle.getLateExemptCharges();
							}

						}

						if (customerPayment != null) {
							PartyPayment partyPayment = new PartyPayment();
							if (partyPayment != null) {
 
								if(amountMatched){
								
								if (CommonUtil.isNotNull(partyPayment.getReferenceNumber())) {
									partyPayment.getReferenceNumber();
									log.info("ref no in createresponsejasonfor customerinvoivce details--->>"+partyPayment.getReferenceNumber());
									
									if(fileRecords.getInvoiceNo().equalsIgnoreCase(partyPayment.getReferenceNumber())){
										fileRecords.setInvoiceNo(partyPayment.getReferenceNumber());
									}else{
										fileRecords.setInvoiceNo("0");
									}
								}else{
									fileRecords.setInvoiceNo("0");
								}

								if (CommonUtil.isNotNull(partyPayment.getBillResets())) {
									partyPayment.getBillResets();
									
									if(fileRecords.getInvoiceNo().equalsIgnoreCase("0") ){
										fileRecords.setOrigBillRefResets("0");
									}
									else{
										fileRecords.setOrigBillRefResets(partyPayment.getBillResets());
										break;
									}
									
								}else{
									fileRecords.setOrigBillRefResets("0");
								}
								}else{
									fileRecords.setInvoiceNo("0");
									fileRecords.setOrigBillRefResets("0");
								}
								/*
								 * BillResets billResets=new BillResets();
								 * if(billResets!=null){
								 * partyPayment.getBillResets(); Column
								 * column=new Column(); if(column!=null){
								 * billResets.getColumn();
								 * if(CommonUtil.isNotNull(column.getName())){
								 * column.getName(); }
								 * if(CommonUtil.isNotNull(column.getSqltype()))
								 * { column.getSqltype(); }
								 * if(CommonUtil.isNotNull(column.get$())){
								 * column.get$(); }
								 * 
								 * }
								 * 
								 * }
								 */
							}
						}
						if (billPeriod != null) {
							if (CommonUtil.isNotNull(billPeriod.getStartDate())) {
								billPeriod.getStartDate();
							}

							if (CommonUtil.isNotNull(billPeriod.getEndDate())) {
								billPeriod.getEndDate();
							}
						}

					}
				}
			}
			}
			
			CustomerInvoiceResponsePojo customerInvoiceResponsePojo=new CustomerInvoiceResponsePojo();
			if(customerInvoiceResponsePojo!=null){
			customerInvoiceResponsePojo.getGetCustomerInvoiceSummaryResMsg();
			}
		}
		
		else{
			log.info("in fault in createResponseJSONForPostCustomerInvoiceDetailsToFX");
		}
		return fileRecords;
	}

public static void main(String[] args) throws Exception {

		/*CustomerInvoiceDetailsClient customerInvoiceDetailsClient = new CustomerInvoiceDetailsClient();
		String result = customerInvoiceDetailsClient.postUpdateCustomerInvoiceToFX("156");
		System.out.println("result---->>" + result);*/
	String a="MANISH GAUTAM";
	
	String[] str =a.split(" ");
	String result="";
	for(int i=0;i<str.length;i++){
		String wrd = str[i];
		for(int j=wrd.length()-1;i>=0;i--){
			result +=wrd.charAt(j)+"";
		}
			
		
	}
	
	System.out.println("tesf="+result);

	}
}
