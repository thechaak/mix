package com.airtel.acecad.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.codec.binary.Base64;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.airtel.acecad.client.dao.ClientDAO;
import com.airtel.acecad.client.dao.ClientDAOImpl;
import com.airtel.acecad.client.dto.CallBackDTO;
import com.airtel.acecad.client.json.custPaymentCallbackJson.CustomerPayment;
import com.airtel.acecad.client.json.custPaymentCallbackJson.Detail;
import com.airtel.acecad.client.json.custPaymentCallbackJson.Fault;
import com.airtel.acecad.client.json.custPaymentCallbackJson.Identification;
import com.airtel.acecad.client.json.custPaymentCallbackJson.MyRequestPojo;
import com.airtel.acecad.client.json.custPaymentCallbackJson.MyResponsePojo;
import com.airtel.acecad.client.json.custPaymentCallbackJson.PartyPayment;
import com.airtel.acecad.client.json.custPaymentCallbackJson.RequestDataArea;
import com.airtel.acecad.client.json.custPaymentCallbackJson.RequestEbmHeader;
import com.airtel.acecad.client.json.custPaymentCallbackJson.ResponseDataArea;
import com.airtel.acecad.client.json.custPaymentCallbackJson.ResponseEbmHeader;
import com.airtel.acecad.client.json.custPaymentCallbackJson.SalesChannel;
import com.airtel.acecad.client.json.custPaymentCallbackJson.SalesChannelId;
import com.airtel.acecad.client.json.custPaymentCallbackJson.SoaFault;
import com.airtel.acecad.client.json.custPaymentCallbackJson.Status;
import com.airtel.acecad.client.json.custPaymentCallbackJson.UpdateCustomerPayment;
import com.airtel.acecad.client.json.custPaymentCallbackJson.UpdateCustomerPaymentFault;
import com.airtel.acecad.client.json.custPaymentCallbackJson.UpdateCustomerPaymentReqMsg;
import com.airtel.acecad.client.json.custPaymentCallbackJson.UpdateCustomerPaymentResMsg;
import com.airtel.acecad.client.json.custPaymentCallbackJson.UpdateCustomerPaymentResponse;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.CustomResponseErrorHandler;
import com.airtel.acecad.client.util.EncryDecrypUtility;
import com.airtel.acecad.client.util.GenericConfiguration;
import com.airtel.acecad.client.util.GlobalConstants;

//////////////////////////////////////////INT_229_F Back response update to siebel//////////////////////////////////////////////////
public class CustPaymentCallbackDetailsClient implements GlobalConstants {

	private static Logger log = LogManager.getLogger("serviceClientUI");
	public String createRequestJSONForCustPaymentCallback(int transactionId) {

		log.info("START--->in 229F createRequestJSONForCustPaymentCallback method of CustPaymentCallbackDetailsClient");

		String result = EMPTY_STRING;
		List<CallBackDTO> CallBackDTOList =new ArrayList<CallBackDTO>();
		CallBackDTO callBackDTO=null;

		ClientDAO clientDAO=new ClientDAOImpl();
		CallBackDTOList=clientDAO.getCallBackDetails(transactionId);
		
		for(int i=0;i<CallBackDTOList.size();i++){

			
			callBackDTO=new CallBackDTO();
			callBackDTO=CallBackDTOList.get(i);
			UpdateCustomerPaymentReqMsg updateCustomerPaymentReqMsg = new UpdateCustomerPaymentReqMsg();
			RequestEbmHeader requestEbmHeader = new RequestEbmHeader();
			requestEbmHeader.setDomain("B2C");
			requestEbmHeader.setLob("Mobility");
			requestEbmHeader.setConsumerName("APS");
			requestEbmHeader.setProgrammeName("Butterfly");
			requestEbmHeader.setCustomerMigrated("0");
			requestEbmHeader.setDebugFlag("true");

			updateCustomerPaymentReqMsg.setEbmHeader(requestEbmHeader);

			RequestDataArea requestDataArea = new RequestDataArea();
			UpdateCustomerPayment updateCustomerPayment = new UpdateCustomerPayment();
			CustomerPayment customerPayment = new CustomerPayment();

			PartyPayment partyPayment = new PartyPayment();

			Identification identification = new Identification();
			identification.setId(callBackDTO.getSrNumber());//SR_NUMBER
			identification.setType(callBackDTO.getCafNumber());//TEXT AS "CAF NUMBER"

			partyPayment.setIdentification(identification);

			partyPayment.setPaymentDate(callBackDTO.getPostedDate()+"T"+callBackDTO.getPostedTime()); //FX_POSTED_DATE
			partyPayment.setStatus(callBackDTO.getStatus()); //SUCCESS
			partyPayment.setMode(callBackDTO.getPaymentMode()); //LIKE OTHERS
			partyPayment.setPaymentType("New");
			partyPayment.setReferenceNumber(callBackDTO.getRefNumber());//REF NUMBER 

			customerPayment.setPartyPayment(partyPayment);
			updateCustomerPayment.setCustomerPayment(customerPayment);

			SalesChannel salesChannel = new SalesChannel();
			SalesChannelId salesChannelId = new SalesChannelId();
			salesChannelId.setChannelId(callBackDTO.getTrackingId());

			salesChannel.setSalesChannelId(salesChannelId);//TRACKING ID

			updateCustomerPayment.setSalesChannel(salesChannel);

			requestDataArea.setUpdateCustomerPayment(updateCustomerPayment);

			updateCustomerPaymentReqMsg.setDataArea(requestDataArea);

			MyRequestPojo requestPojo = new MyRequestPojo();

			requestPojo.setUpdateCustomerPaymentReqMsg(updateCustomerPaymentReqMsg);

			log.info("requestpojo  in 229F createRequestJSONForCustPaymentCallback---->>" + requestPojo + "and transactionId-->"
					+ transactionId);

			result = postCustPaymentCallback(requestPojo,transactionId);
		}
		//} //for loop end
		log.info("END--->in 229F createRequestJSONForCustPaymentCallback method of CustPaymentCallbackDetailsClient");
		return result;

	}

	
	public static void main(String[] args) {

		CustPaymentCallbackDetailsClient custPaymentCallbackDetailsClient=new CustPaymentCallbackDetailsClient();
		custPaymentCallbackDetailsClient.createRequestJSONForCustPaymentCallback(12345);
	}

	public String postCustPaymentCallback(MyRequestPojo requestPojo,int transactionId) {

		String result = EMPTY_STRING;

		UpdateCustomerPaymentResMsg updateCustomerPaymentResMsg = null;
		Fault fault = null;

		String status_code = EMPTY_STRING;

		ClientDAO clientDao = new ClientDAOImpl();
		String resultConectRead = EMPTY_STRING;
		//int transaction_no = adjPostDetails.getTransactionNo();

		try
		{
			String clientURL = GenericConfiguration.getDescription("kenon.postCustPaymentCallback.url");
			RestTemplate restTemplate = new RestTemplate();

			// ADDED FOR HANDLING TIMEOUT ERRORS

			restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
			.setConnectTimeout(Integer.parseInt(GenericConfiguration.getDescription("connect_time_out")));// 60000=
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
			.setReadTimeout(Integer.parseInt(GenericConfiguration.getDescription("read_time_out")));

			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
			restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
			restTemplate.setErrorHandler(new CustomResponseErrorHandler());
			HttpHeaders headers = new HttpHeaders();

			// Added by Ritu (EncryptDecrypt Password)
			String userpass = GenericConfiguration.getDescription("kenon.postPaymentToFX.userName") + ":"
					+ EncryDecrypUtility.decrypt(GenericConfiguration.getDescription("kenon.postPaymentToFX.password"));
			log.info("clientURL in postCustPaymentCallback in CustPaymentCallbackDetailsClient-->" + clientURL);
			headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

			HttpEntity<MyRequestPojo> entity = new HttpEntity<MyRequestPojo>(requestPojo, headers);
			ResponseEntity<MyResponsePojo> responsePojo = null;
			try {
				log.info("requestPojo in postCustPaymentCallback" + requestPojo);
				// Execute the httpMethod to given uri template,writing the
				// given request and returns the response as ResponseEntity
				responsePojo = restTemplate.exchange(clientURL, HttpMethod.POST, entity, MyResponsePojo.class);
				log.info("responsePojo in postCustPaymentCallback in CustPaymentCallbackDetailsClient--->" + responsePojo);

				if (responsePojo != null) {
					if (HttpStatus.OK == responsePojo.getStatusCode()) {
						if (responsePojo.getBody().getUpdateCustomerPaymentResMsg() != null) {
							updateCustomerPaymentResMsg = responsePojo.getBody().getUpdateCustomerPaymentResMsg();
							log.info("success--in postCustPaymentCallback in CustPaymentCallbackDetailsClient--->>"
									+ responsePojo.getBody().getUpdateCustomerPaymentResMsg());

						} else {
							status_code = responsePojo.getStatusCode().toString();
							fault = responsePojo.getBody().getFault();
							log.info(
									"faultResponsePojo in postCustPaymentCallback in CustPaymentCallbackDetailsClient in http 200 ok-->>"
											+ fault);
						}

					} else {
						status_code = responsePojo.getStatusCode().toString();
						fault = responsePojo.getBody().getFault();
						log.info("faultResponsePojo in postCustPaymentCallback in CustPaymentCallbackDetailsClient-->>"
								+ fault);
					}
					result = createResponseJSONForCustPaymentCallback(updateCustomerPaymentResMsg, fault,status_code,transactionId);
					log.info(
							"After createResponseJSONForCustPaymentCallback Response in postCustPaymentCallback in CustPaymentCallbackDetailsClient-->>"
									+ result);

				} else {
					log.info(
							"IN method  postCustPaymentCallback response pojo is null in CustPaymentCallbackDetailsClient");
				}
			} catch (Exception e) {
				log.info(
						"Got faulty code from the response of FX in postCustPaymentCallback in CustPaymentCallbackDetailsClient");

			}

		} catch (Exception e) {
			log.info("exception in postUpdateAdjustmentPostingToFX in CustPaymentCallbackDetailsClient" + e);

			
		}
		log.info("END--->in postUpdateAdjustmentPostingToFX method of CustPaymentCallbackDetailsClient");
		return result;

	}

	public String createResponseJSONForCustPaymentCallback(UpdateCustomerPaymentResMsg updateCustomerPaymentResMsg,
			Fault fault, String statusCode,int transactionId) throws Exception {

		log.info(
				"START----in createResponseJSONForCustPaymentCallback method of CustPaymentCallbackDetailsClient");
		
		log.info("fault=====>>"+fault);

		String result = EMPTY_STRING;
		String status_description = EMPTY_STRING;
		

		//if (updateCustomerPaymentResMsg.getDataArea() != null || updateCustomerPaymentResMsg.getEbmHeader()!=null) {
		if (updateCustomerPaymentResMsg!=null) {
			log.info(
					"In if loop when got success response from webservice in createResponseJSONForCustPaymentCallback--229_F INT ");

			ResponseEbmHeader responseEbmHeader=new ResponseEbmHeader();

			if(updateCustomerPaymentResMsg.getEbmHeader()!=null){
				responseEbmHeader=updateCustomerPaymentResMsg.getEbmHeader();
				if(CommonUtil.isNotNull(responseEbmHeader.getConsumerTransactionId()))
					responseEbmHeader.getConsumerTransactionId();

			}

			ResponseDataArea responseDataArea=new ResponseDataArea();
			if(updateCustomerPaymentResMsg.getDataArea()!=null){
				responseDataArea=updateCustomerPaymentResMsg.getDataArea();
			}

			UpdateCustomerPaymentResponse updateCustomerPaymentResponse=new UpdateCustomerPaymentResponse();
			if(responseDataArea.getUpdateCustomerPaymentResponse()!=null){
				updateCustomerPaymentResponse=responseDataArea.getUpdateCustomerPaymentResponse();
			}

			Status status=new Status();
			if(updateCustomerPaymentResponse.getStatus()!=null){
				status=updateCustomerPaymentResponse.getStatus();

				if (CommonUtil.isNotNull(status.getStatusCode())) {
					String[] statusCodeArray = status.getStatusCode().split("-");
					statusCode = statusCodeArray[1] + "-" + statusCodeArray[2];
					log.info("status code in createResponseJSONForCustPaymentCallback----->>>" + statusCode);
				}

				if (CommonUtil.isNotNull(status.getStatusCode())
						|| CommonUtil.isNotNull(status.getStatusDescription())) {
					status_description = statusCode + ":" + status.getStatusDescription();

					log.info("status_description in createResponseJSONForCustPaymentCallback--->>"
							+ status_description);
				}
			}
		}
		else if (fault != null) {
			log.info(
					"In else loop when got error response from webservice in createResponseJSONForCustPaymentCallback--314 INT");
			if (statusCode.contains(status_code_504) || statusCode.contains(status_code_500)) {
				//status_description = fault.getFaultstring();
				String fault_value=fault.getFaultstring();
				if(fault_value.length()>999){
					fault_value=fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description= status_description.replace("'", "");
				log.info("Status description is in createResponseJSONForCustPaymentCallback---> "
						+ status_description);
			} else if (statusCode.contains(status_code_502)) {
				//status_description = fault.getFaultstring();
				String fault_value=fault.getFaultstring();
				if(fault_value.length()>999){
					fault_value=fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description= status_description.replace("'", "");
				log.info("Status description is in createResponseJSONForCustPaymentCallback---> "
						+ status_description );
			} else if (statusCode.contains(status_code_400)) {
				//status_description = fault.getFaultstring();
				String fault_value=fault.getFaultstring();
				if(fault_value.length()>999){
					fault_value=fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description= status_description.replace("'", "");
				log.info("Status description is in createResponseJSONForCustPaymentCallback---> "
						+ status_description);
			} else {
				Detail detail = fault.getDetail();
				log.info("SoaFault=====>");
				if (detail != null) {
					UpdateCustomerPaymentFault updateCustomerPaymentFault = detail.getUpdateCustomerPaymentFault();
					if (updateCustomerPaymentFault != null) {
						SoaFault soaFault = updateCustomerPaymentFault.getSoaFault();
						if (soaFault != null) {
							// Added by geeta
							if (CommonUtil.isNotNull(soaFault.getSoaFaultCode())) {
								String[] soaFaultCodeArray = soaFault.getSoaFaultCode().split("-");
								statusCode = soaFaultCodeArray[1] + "-" + soaFaultCodeArray[2];
								log.info("soa fault status code in createResponseJSONForCustPaymentCallback---->>>"
										+ statusCode);

							}
							if (CommonUtil.isNotNull(soaFault.getFaultDescription())) {
								// added by geeta
								//status_description = statusCode + ":" + soaFault.getFaultDescription();
								String fault_value=soaFault.getFaultDescription();
								if(fault_value.length()>999){
									fault_value=fault_value.substring(0, 1000);
								}
								status_description = statusCode + ":" + fault_value;
								status_description= status_description.replace("'", "");
								log.info("faultDescription in createResponseJSONForCustPaymentCallback---->"
										+ status_description );
							}
						}

					}

				}

			}
		}
		ClientDAO clientDAO = new ClientDAOImpl();
		
		 clientDAO.updateCallBackResponse(status_description, statusCode, transactionId);
		
		
		log.info(
				"END----in createResponseJSONForCustPaymentCallback method of CustPaymentCallbackDetailsClient");

		return result;
	}
}
