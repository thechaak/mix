package com.airtel.acecad.client.json.billingPaymentManagerHomes;

public class SiList {

	private String id;

    private String subLob;

    private String type;

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String getSubLob ()
    {
        return subLob;
    }

    public void setSubLob (String subLob)
    {
        this.subLob = subLob;
    }

    public String getType ()
    {
        return type;
    }

    public void setType (String type)
    {
        this.type = type;
    }

    @Override
    public String toString()
    {
        return "{\"id\" : \""+id+"\", \"subLob\" : \""+subLob+"\", \"type\" : \""+type+"\"}";
    }
}
