package com.airtel.acecad.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.codec.binary.Base64;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.airtel.acecad.client.dao.ClientDAO;
import com.airtel.acecad.client.dao.ClientDAOImpl;
import com.airtel.acecad.client.dto.DepositDetails;
import com.airtel.acecad.client.json.depositJson.Attribute;
import com.airtel.acecad.client.json.depositJson.CustomerAccount;
import com.airtel.acecad.client.json.depositJson.Deposit;
import com.airtel.acecad.client.json.depositJson.DepositCustomerPayment;
import com.airtel.acecad.client.json.depositJson.DepositDataArea;
import com.airtel.acecad.client.json.depositJson.DepositFault;
import com.airtel.acecad.client.json.depositJson.DepositMyPojo;
import com.airtel.acecad.client.json.depositJson.DepositPartyPayment;
import com.airtel.acecad.client.json.depositJson.DepositReqMsg;
import com.airtel.acecad.client.json.depositJson.DepositResMsg1;
import com.airtel.acecad.client.json.depositJson.DepositResponse;
import com.airtel.acecad.client.json.depositJson.DepositResponseDataArea;
import com.airtel.acecad.client.json.depositJson.DepositResponsePojo;
import com.airtel.acecad.client.json.depositJson.DetailFault;
import com.airtel.acecad.client.json.depositJson.EbmHeader;
import com.airtel.acecad.client.json.depositJson.EbmHeader1;
import com.airtel.acecad.client.json.depositJson.Ext;
import com.airtel.acecad.client.json.depositJson.Fault;
import com.airtel.acecad.client.json.depositJson.Identification;
import com.airtel.acecad.client.json.depositJson.LogicalResource;
import com.airtel.acecad.client.json.depositJson.SoaFault;
import com.airtel.acecad.client.json.depositJson.Status;
import com.airtel.acecad.client.json.depositJson.TrackingRecord;
import com.airtel.acecad.client.json.depositJson.TrackingRecordIdentification;
import com.airtel.acecad.client.json.depositRefundJson.LogicalIdentification;
import com.airtel.acecad.client.util.GenericConfiguration;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.CustomResponseErrorHandler;
import com.airtel.acecad.client.util.EncryDecrypUtility;
import com.airtel.acecad.client.util.GlobalConstants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
////////////////////////////////INT_314////////////////////////////////////////

public class DepositDetailsClient implements GlobalConstants {

	private static final Logger log = LogManager.getLogger("serviceClientUI");

	/*
	 * @author :- Geeta Rajput
	 */
	public String postUpdateCustomerDepositToFX(DepositMyPojo requestPojo, DepositDetails depositDetails,
			String tableName,int jobId) throws Exception {

		log.info("START --> in postUpdateCustomerDepositToFX method  rest formation of DepositDetailsClient and transaction_no:"+depositDetails.getTransactionNo());
		DepositResMsg1 updateCustomerDepositResMsg = null;
		Fault fault = null;
		String result = EMPTY_STRING;
		String status_code = EMPTY_STRING;
		int transaction_no=depositDetails.getTransactionNo();

		ClientDAO clientDao = new ClientDAOImpl();
		//int pTransactionId = EMPTY_VALUE;
		String resultConectRead = EMPTY_STRING;

		String clientURL = GenericConfiguration.getDescription("kenon.postUpdateCustomerDepositToFX.url");
		RestTemplate restTemplate = new RestTemplate();

		// ADDED FOR HANDLING TIMEOUT ERRORS
		restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
		((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
		.setConnectTimeout(Integer.parseInt(GenericConfiguration.getDescription("connect_time_out")));// 60000=
        ((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
		.setReadTimeout(Integer.parseInt(GenericConfiguration.getDescription("read_time_out")));
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
		restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
		restTemplate.setErrorHandler(new CustomResponseErrorHandler());
		HttpHeaders headers = new HttpHeaders();
        
		//Added by Ritu (EncryptDecrypt Password)
		String userpass = GenericConfiguration.getDescription("kenon.postPaymentToFX.userName") + ":"
				+ EncryDecrypUtility.decrypt(GenericConfiguration.getDescription("kenon.postPaymentToFX.password"));
		log.info("clientURL  postUpdateCustomerDepositToFX -->" + clientURL+" and transaction_no "+transaction_no);
		headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		HttpEntity<DepositMyPojo> entity = new HttpEntity<DepositMyPojo>(requestPojo, headers);
		ResponseEntity<DepositResponsePojo> responsePojo = null;
		try {
			// Execute the httpMethod to given uri template,writing the
			// given request and returns the response as ResponseEntity
			responsePojo = restTemplate.exchange(clientURL, HttpMethod.POST, entity, DepositResponsePojo.class);
			log.info("responsePojo postUpdateCustomerDepositToFX---" + responsePojo+" and transaction_no "+transaction_no);

			if (responsePojo != null) {
				if (HttpStatus.OK == responsePojo.getStatusCode()) {

					if (responsePojo.getBody().getUpdateCustomerDepositResMsg1() != null) {
						updateCustomerDepositResMsg = responsePojo.getBody().getUpdateCustomerDepositResMsg1();
						log.info("success--postUpdateCustomerDepositToFX--->>"
								+ responsePojo.getBody().getUpdateCustomerDepositResMsg1()+" and transaction_no "+transaction_no);

					} else {
						status_code = responsePojo.getStatusCode().toString();
						fault = responsePojo.getBody().getFault();
						log.info("faultResponsePojo  postUpdateCustomerDepositToFX in http 200 ok-->>" + fault+" and transaction_no "+transaction_no);
					}
				}
				else {
					status_code = responsePojo.getStatusCode().toString();
					fault = responsePojo.getBody().getFault();
					log.info("faultResponsePojo  postUpdateCustomerDepositToFX-->>" + fault+" and transaction_no "+transaction_no);
				}
				log.info("Before createResponseJSONForPostCustomerDepositeToFX in postUpdateCustomerDepositToFX and transaction_no "+transaction_no);

				result = createResponseJSONForPostCustomerDepositeToFX(updateCustomerDepositResMsg, fault,
						depositDetails, status_code,jobId);
				log.info(
						"After createResponseJSONForPostCustomerDepositeToFX in postUpdateCustomerDepositToFX result---->"
								+ result+" and transaction_no "+transaction_no);
			} else {
				log.info("IN method  createResponseJSONForPostCustomerDepositeToFX response pojo is null and transaction_no "+transaction_no);
			}
		} catch (Exception e) {
			log.info("Got faulty code from the response of FX createResponseJSONForPostCustomerDepositeToFX", e);
			log.info("Got faulty code from the response of FX createResponseJSONForPostCustomerDepositeToFX----"
					+ responsePojo.getStatusCode()+" and transaction_no "+transaction_no);

			if (e.getCause().toString().contains(CONNECT_TEXT)) {

				resultConectRead = clientDao.updateConnectionReadResponse(transaction_no, tableName, CONNECT_TEXT);
				log.info("Got faulty code from the response CONNECT_TEXT of FX resultConectRead----->"
						+ resultConectRead+" and transaction_no "+transaction_no);
			}

			if (e.getCause().toString().contains(READ_TEXT)) {

				resultConectRead = clientDao.updateConnectionReadResponse(transaction_no, tableName, READ_TEXT);
				log.info(
						"Got faulty code from the response READ_TEXT  of FX resultConectRead----->" + resultConectRead+" and transaction_no "+transaction_no);

			}

		}
		log.info("END--->in postUpdateCustomerDepositToFX method of DepositDetailsClient and transaction_no "+transaction_no);
		return result;
	}

	/*
	 * @author :- Geeta Rajput-- To Create Request Json Format for update
	 * deposite details Request
	 */
	public String createRequestJSONForPostCustomerDepositToFX(String accountId, String tableName) throws Exception {

		log.info(
				"START--->in createRequestJSONForPostCustomerDepositToFX method of DepositDetailsClient and account_no--->>"
						+ accountId);

		DepositDetailsClient depositDetailsClient = new DepositDetailsClient();
		List<DepositDetails> depositDetailsList = new ArrayList<DepositDetails>();
		String result = EMPTY_STRING;
		int transactionNo = EMPTY_VALUE;
		ClientDAO clientDAO = new ClientDAOImpl();
		depositDetailsList = clientDAO.fetchDepositDetails(accountId);
		log.info("depositlist in createRequestJSONForPostCustomerDepositToFX---->>" + depositDetailsList
				+ "and account_no--->>" + accountId);
		for (int i = 0; i < depositDetailsList.size(); i++) {

			DepositDetails depositDetails = new DepositDetails();
			depositDetails = depositDetailsList.get(i);

			DepositReqMsg updateCustomerDepositReqMsg = new DepositReqMsg();
			EbmHeader ebmHeader = new EbmHeader();
			ebmHeader.setLob(LOB);
			String consumerTransactionId = APS + CommonUtil.randomMethod();
			log.info("consumerTransactionId in createRequestJSONForPostCustomerDepositToFX----->"
					+ consumerTransactionId);
			ebmHeader.setConsumerTransactionId(consumerTransactionId);
			ebmHeader.setCustomerMigrated(TRUE);

			updateCustomerDepositReqMsg.setEbmHeader(ebmHeader);

			Identification identification = new Identification();
			identification.setId(accountId);
			log.info("Account_No in createRequestJSONForPostCustomerDepositToFX--->>" + accountId);
			// identification.setId("106");

			CustomerAccount customerAccount = new CustomerAccount();
			customerAccount.setIdentification(identification);

			Deposit updateCustomerDeposit = new Deposit();
			updateCustomerDeposit.setCustomerAccount(customerAccount);

			if(CommonUtil.isNotNull(depositDetails.getMobileNo())){
			LogicalResource logicalResource=new LogicalResource();
			LogicalIdentification logicalIdentification=new LogicalIdentification();
			logicalIdentification.setId(depositDetails.getMobileNo());
			logicalResource.setIdentification(logicalIdentification);
			
			updateCustomerDeposit.setLogicalResource(logicalResource);
			}
			DepositDataArea dataArea = new DepositDataArea();
			dataArea.setUpdateCustomerDeposit(updateCustomerDeposit);

			DepositPartyPayment partyPayment = new DepositPartyPayment();

			/*
			 * double d = (depositDetails.getAddAmount()) * 100; int amount =
			 * (int) d; String addAmount = String.valueOf(amount);
			 */

			double addAmount = depositDetails.getAddAmount();
			int amount = (int) addAmount;
			partyPayment.setAmount(String.valueOf(amount));
			// partyPayment.setAmount("1908");
			log.info("addAmount in createRequestJSONForPostCustomerDepositToFX--->>" + addAmount
					+ " and account_no--->>" + accountId);

			/*
			 * SimpleDateFormat dateFormat = new
			 * SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'"); String paymentDate
			 * =dateFormat.format(depositDetails.getDateReceived());
			 * System.out.println(paymentDate);
			 */
			partyPayment.setPaymentDate(depositDetails.getDateReceived());
			// partyPayment.setPaymentDate("2016-10-13T20:45:04+05:30");

			// currencycode is not mandatory
			// if(CURRENCYCODE_INR.equalsIgnoreCase(depositDetails.getCurrencyCode())){
			partyPayment.setCurrency(INR);
			// }
			// partyPayment.setCurrency("16");
			log.info("currencycode in createRequestJSONForPostCustomerDepositToFX---->>"
					+ depositDetails.getCurrencyCode() + " and account_no--->>" + accountId);
			partyPayment.setDepositType(depositDetails.getDepositType());

			log.info(depositDetails.getBankName());
			// if (depositDetails.getBankName() != null) {
			if (CommonUtil.isNotNull(depositDetails.getModeOfPayment())) {
				partyPayment.setMode(depositDetails.getModeOfPayment());
			}

			// partyPayment.setPaymentMethod("CARD");

			DepositCustomerPayment customerPayment = new DepositCustomerPayment();
			customerPayment.setPartyPayment(partyPayment);

			updateCustomerDeposit.setCustomerPayment(customerPayment);

			///Added by geeta(CR--29-MAY-2017)
			
			Ext ext=new Ext();
		    List<Attribute> attribute = new ArrayList<>();
		/*	JsonObjectBuilder jsonBuilder = Json.createObjectBuilder(); 
			JsonArrayBuilder depositArrBld = Json.createArrayBuilder();
			
			depositArrBld.add(Json.createObjectBuilder().add("name", "Annotation1").build());
			depositArrBld.add(Json.createObjectBuilder().add("mobile", "123123123123").build());
		         
		        JsonArray contactsArr = depositArrBld.build();
		        // add contacts array object
		        jsonBuilder.add("attribute", contactsArr);*/
			    log.info("list in createRequestJSONForPostCustomerDepositToFX-->>"+attribute.size());
				for(int j=0 ; j<5;j++){
					
					Attribute at = new Attribute();
					if(j==0){
						at.setName("Annotation1");
						at.setValue(depositDetails.getAnnotation1());
					}
					if(j==1){
						at.setName("Annotation2");
						at.setValue(accountId);
					}
					if(j==2){
						
						at.setName("Annotation3");
						if(CommonUtil.isNotNull(depositDetails.getCsrNotes())){
							at.setValue(depositDetails.getCsrNotes());
					}
					}
					if(j==3){
						at.setName("Annotation4");
						at.setValue(depositDetails.getAnnotation4());
					}
					if(j==4){
						at.setName("Annotation5");
						at.setValue(depositDetails.getAnnotation5());
					}
					attribute.add(at);
					
				}
				
			ext.setAttribute(attribute);		
			updateCustomerDeposit.setExt(ext);
			updateCustomerDepositReqMsg.setDataArea(dataArea);

			DepositMyPojo requestPojo = new DepositMyPojo();
			if (updateCustomerDepositReqMsg != null) {
				requestPojo.setUpdateCustomerDepositReqMsg(updateCustomerDepositReqMsg);
			}
			log.info(updateCustomerDepositReqMsg.toString());
			log.info("requestpojo in createRequestJSONForPostCustomerDepositToFX--->>" + requestPojo
					+ " and account_no--->>" + accountId);

			if (depositDetails.getTransactionNo() != 0) {
				transactionNo = depositDetails.getTransactionNo();
			}

			log.info("Before hitting the posting fx job_id for transaction no in INT---" + transactionNo
					+ " in createRequestJSONForPostCustomerDepositToFX and account_no--->>" + accountId+" and transactionNo "+transactionNo);
			Object[] resultobj= clientDAO.updateJobId(tableName, transactionNo,null,1);
			log.info("After hitting the posting fx job_id jobId in createRequestJSONForPostCustomerDepositToFX result is:"
					+ resultobj[0] + "and job id is"+resultobj[1]+" and transaction_no " + transactionNo);
			if (RESULT_DB_SUCCESFUL.equalsIgnoreCase((String) resultobj[0])) {

				log.info(
						"Before calling postUpdateCustomerDepositToFX method from createRequestJSONForPostCustomerDepositToFX and account_no--->>" + accountId+" and transactionNo "+transactionNo);
				result = depositDetailsClient.postUpdateCustomerDepositToFX(requestPojo, depositDetails, tableName,(int)resultobj[1]);
				log.info(
						"After calling postUpdateCustomerDepositToFX method from createRequestJSONForPostCustomerDepositToFX result--->"
								+ result+ " and account_no--->>" + accountId+" and transactionNo "+transactionNo);
			}
			log.info(
					"END----in createRequestJSONForPostCustomerDepositToFX method of DepositDetailsClient and account_no--->>"
							+ accountId+" and transactionNo "+transactionNo);
		}
		return result;

	}

	/*
	 * @author :- Geeta Rajput-- To Create ResponseJson Format for update
	 * deposite details Request
	 */
	public String createResponseJSONForPostCustomerDepositeToFX(DepositResMsg1 updateCustomerDepositResMsg, Fault fault,
			DepositDetails depositDetails, String statusCode,int jobId) throws Exception {

		log.info("START----in createResponseJSONForPostCustomerDepositeToFX method of DepositDetailsClient and transaction_no"+depositDetails.getTransactionNo());

		String result = EMPTY_STRING;
		String faultDescription = EMPTY_STRING;
		String status_description = EMPTY_STRING;
		int trackingServId = EMPTY_VALUE;
		int trackingId = EMPTY_VALUE;
		String cons_tans_id = EMPTY_STRING;
		int viewId = EMPTY_VALUE;
		int transactionNo = depositDetails.getTransactionNo();
		String annotation3=EMPTY_STRING;
		String annotation5=EMPTY_STRING;
		String faultTrace=EMPTY_STRING;
		

		EbmHeader1 ebmHeader1 = new EbmHeader1();
		if (updateCustomerDepositResMsg != null) {
			log.info(
					"In if loop when got success response from webservice in createResponseJSONForPostCustomerDepositeToFX --314 INT and transaction_no-->>"
							+ transactionNo);

			if (updateCustomerDepositResMsg.getEbmHeader() != null) {
				ebmHeader1 = updateCustomerDepositResMsg.getEbmHeader();
			}
			DepositResponseDataArea dataArea = new DepositResponseDataArea();
			if (updateCustomerDepositResMsg.getDataArea() != null) {
				dataArea = updateCustomerDepositResMsg.getDataArea();
			}
			DepositResponse updateCustomerDepositResponse = new DepositResponse();
			if (dataArea.getUpdateCustomerDepositResponse() != null) {

				updateCustomerDepositResponse = dataArea.getUpdateCustomerDepositResponse();
			}
			Status status = new Status();
			if (updateCustomerDepositResponse.getStatus() != null) {
				status = updateCustomerDepositResponse.getStatus();
			}
			// Added by geeta
			if (status != null) {
				if (CommonUtil.isNotNull(status.getStatusCode())) {
					String[] statusCodeArray = status.getStatusCode().split("-");
					statusCode = statusCodeArray[1] + "-" + statusCodeArray[2];
					log.info("status code in createResponseJSONForPostCustomerDepositeToFX----->>>" + statusCode
							+ "and transaction_no-->>" + transactionNo);
				}

				if (CommonUtil.isNotNull(status.getStatusCode())
						|| CommonUtil.isNotNull(status.getStatusDescription())) {
					status_description = statusCode + ":" + status.getStatusDescription();

					log.info("status_description in createResponseJSONForPostCustomerDepositeToFX--->>"
							+ status_description + " and transaction_no-->>" + transactionNo);
				}
			}

			TrackingRecord trackingRecord = updateCustomerDepositResponse.getTrackingRecord();

			if (CommonUtil.isNotNull(trackingRecord.getSystemId())) {
				trackingServId = Integer.parseInt(trackingRecord.getSystemId());
				log.info("tracking_serv_id in createResponseJSONForPostCustomerDepositeToFX--->>" + trackingServId
						+ " and transaction_no-->>" + transactionNo);
			}

			TrackingRecordIdentification trackingRecordIdentification = trackingRecord.getIdentification();
			if (CommonUtil.isNotNull(trackingRecordIdentification.getId())) {
				trackingId = Integer.parseInt(trackingRecordIdentification.getId());
				log.info("tracking_id in createResponseJSONForPostCustomerDepositeToFX--->>" + trackingId
						+ " and transaction_no-->>" + transactionNo);
			}

			if (CommonUtil.isNotNull(ebmHeader1.getConsumerTransactionId())) {
				cons_tans_id = ebmHeader1.getConsumerTransactionId();
				log.info("cons_tans_id in createResponseJSONForPostCustomerDepositeToFX--->>" + cons_tans_id
						+ " and transaction_no-->>" + transactionNo);
			}

		} else if (fault != null) {
			log.info(
					"In else loop when got error response from webservice in createResponseJSONForPostCustomerDepositeToFX--314 INT and transaction_no-->>"
							+ transactionNo);
			if (statusCode.contains(status_code_504) || statusCode.contains(status_code_500)) {
				//status_description = fault.getFaultstring();
				String fault_value=fault.getFaultstring();
				if(fault_value.length()>999){
					fault_value=fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description= status_description.replace("'", "");
				log.info("Status description is in createResponseJSONForPostCustomerDepositeToFX---> "
						+ status_description + " and transaction_no-->>" + transactionNo);
			} else if (statusCode.contains(status_code_502)) {
				//status_description = fault.getFaultstring();
				String fault_value=fault.getFaultstring();
				if(fault_value.length()>999){
					fault_value=fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description= status_description.replace("'", "");
				log.info("Status description is in createResponseJSONForPostCustomerDepositeToFX---> "
						+ status_description + " and transaction_no-->>" + transactionNo);
			} else if (statusCode.contains(status_code_400)) {
				//status_description = fault.getFaultstring();
				String fault_value=fault.getFaultstring();
				if(fault_value.length()>999){
					fault_value=fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description= status_description.replace("'", "");
				log.info("Status description is in createResponseJSONForPostCustomerDepositeToFX---> "
						+ status_description + " and transaction_no-->>" + transactionNo);
			} else {
				DetailFault detail = fault.getDetail();
				if (detail != null) {
					DepositFault depositFault = detail.getUpdateCustomerDepositFault();
					if (depositFault != null) {
						SoaFault soaFault = depositFault.getSoaFault();
						if (soaFault != null) {
							// Added by geeta
							if (CommonUtil.isNotNull(soaFault.getSoaFaultCode())) {
								String[] soaFaultCodeArray = soaFault.getSoaFaultCode().split("-");
								statusCode = soaFaultCodeArray[1] + "-" + soaFaultCodeArray[2];
								log.info("soa fault status code in createResponseJSONForPostCustomerDepositeToFX---->>>"
										+ statusCode + " and transaction_no-->>" + transactionNo);

							}
							if (CommonUtil.isNotNull(soaFault.getFaultDescription())) {
								// added by geeta
								//status_description = statusCode + ":" + soaFault.getFaultDescription();
								String fault_value=soaFault.getFaultDescription();
								if(fault_value.length()>999){
									fault_value=fault_value.substring(0, 1000);
								}
								status_description = statusCode + ":" + fault_value;
								status_description= status_description.replace("'", "");
								log.info("faultDescription in createResponseJSONForPostCustomerDepositeToFX---->"
										+ status_description + " and transaction_no-->>" + transactionNo);
							}
						}

					}

				}

			}
		}
		ClientDAO clientDAO = new ClientDAOImpl();
		String table_name = clientDAO.fetchTableName(FILE_IDENTIFIER_DPP);
		log.info("trans no in method createResponseJSONForNrcForFailedPaymentToFX---->" + transactionNo);
		log.info("Before updateResponse in createResponseJSONForPostCustomerDepositeToFX and transaction_no-->>"
				+ transactionNo+" and job_id-->"+jobId);
		result = clientDAO.updateResponse(status_description, trackingId, trackingServId,
				depositDetails.getTransactionNo(), table_name, viewId,jobId,annotation3,annotation5,faultTrace);
		log.info("Before updateResponse in createResponseJSONForPostCustomerDepositeToFX response-result----->>>"
				+ result + "and transaction_no-->>" + transactionNo);

		log.info(
				"END----in createResponseJSONForPostCustomerDepositeToFX method of DepositDetailsClient and transaction_no-->>"
						+ transactionNo);
		return result;

	}

	public static void main(String[] args) throws Exception {
		DepositDetailsClient depositDetailsClient = new DepositDetailsClient();
		depositDetailsClient.createRequestJSONForPostCustomerDepositToFX("106", "DEPOSIT_APS");

	}

}