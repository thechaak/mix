package com.airtel.acecad.client;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.codec.binary.Base64;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.airtel.acecad.client.dao.ClientDAO;
import com.airtel.acecad.client.dao.ClientDAOImpl;
import com.airtel.acecad.client.dto.BulkDetails;
import com.airtel.acecad.client.json.CustomerAccountSummaryJson.MyResponsePojo;
import com.airtel.acecad.client.json.CustomerInvoiceSummaryV5.BillPeriod;
import com.airtel.acecad.client.json.CustomerInvoiceSummaryV5.Customer;
import com.airtel.acecad.client.json.CustomerInvoiceSummaryV5.CustomerAccount;
import com.airtel.acecad.client.json.CustomerInvoiceSummaryV5.CustomerBillingCycle;
import com.airtel.acecad.client.json.CustomerInvoiceSummaryV5.CustomerInvoiceSummaryResponse;
import com.airtel.acecad.client.json.CustomerInvoiceSummaryV5.CustomerPayment;
import com.airtel.acecad.client.json.CustomerInvoiceSummaryV5.DataArea;
import com.airtel.acecad.client.json.CustomerInvoiceSummaryV5.EbmHeader;
import com.airtel.acecad.client.json.CustomerInvoiceSummaryV5.GetCustomerInvoiceSummaryResponse;
import com.airtel.acecad.client.json.CustomerInvoiceSummaryV5.Identification;
import com.airtel.acecad.client.json.CustomerInvoiceSummaryV5.InvoiceDetail;
import com.airtel.acecad.client.json.CustomerInvoiceSummaryV5.PartyBill;
import com.airtel.acecad.client.json.CustomerInvoiceSummaryV5.PartyPayment;
import com.airtel.acecad.client.json.CustomerInvoiceSummaryV5.SoaFault;
import com.airtel.acecad.client.json.CustomerInvoiceSummaryV5.Status;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.CustomResponseErrorHandler;
import com.airtel.acecad.client.util.EncryDecrypUtility;
import com.airtel.acecad.client.util.GenericConfiguration;
import com.airtel.acecad.client.util.GlobalConstants;
import com.fasterxml.jackson.databind.ObjectMapper;

public class GetCustomerInvoiceSummaryV5 implements GlobalConstants{
	private static final ObjectMapper mapper= new ObjectMapper();
	private static Logger logger = LogManager.getLogger("serviceClientUI");
	
	public BulkDetails postUpdateCustomerInvoiceToFX(BulkDetails bulkDetails,String fileIdentifier) throws Exception {
		
		logger.info("START-- in method postUpdateCustomerInvoiceToFX of GetCustomerInvoiceSummaryV5");
			String result = EMPTY_STRING;
			String status_code = EMPTY_STRING;
			String domain ="B2C";
			String lob ="Mobility";
			String subLob ="Postpaid";
			String consumerTransactionId ="APS_12541";
			String customerMigratedFlag ="false";
			BulkDetails bulkDetailsres = new BulkDetails();
			SoaFault soaFault = null;
			String fromDate="1990-01-01T23:59:59";
			String toDate ="";
			
			Date d= new  Date();
			Calendar c = Calendar.getInstance(); 
			c.setTime(d); 
			c.add(Calendar.DATE, 1);
			d = c.getTime();
			toDate= new SimpleDateFormat("yyyy-MM-dd").format(d);
			toDate+="T23:59:59";
			
			if(CommonUtil.isNotNull(bulkDetails.getLob())){
				if(bulkDetails.getLob().equalsIgnoreCase("MOB") || bulkDetails.getLob().equalsIgnoreCase("Mobility"))
					lob= "Mobility";
				
				else if(bulkDetails.getLob().equalsIgnoreCase("BTS"))
					lob= "Telemedia";
				
				else
					lob=bulkDetails.getLob() ;
				
			}
			if(lob==null){
				lob="AES";
				
			}
			RestTemplate restTemplate = new RestTemplate();
			if(bulkDetails.getApsFlag()!= null && bulkDetails.getApsFlag().equalsIgnoreCase("APS"))
				customerMigratedFlag ="true";
					
			try {
				String userpass = GenericConfiguration.getDescription("kenon.postPaymentToFX.userName") + ":"
						+ EncryDecrypUtility.decrypt(GenericConfiguration.getDescription("kenon.postPaymentToFX.password"));
		
				String clientURL = GenericConfiguration.getDescription("kenon.postUpdateCustomerInvoiceSummaryURLV5.url")+ 
						"domain="+domain+"&lob="+lob+"&subLob="+subLob+"&consumerTransactionId="+11343+"&consumerName="+APS+"&programmeName="+
						"EAIMigration"+"&customerMigrated="+customerMigratedFlag+"&accountId="+bulkDetails.getAcctEXTID()+"&MSISDN=&startDate="+
						fromDate+"&endDate="+toDate;
				logger.info("InvoiceSummary INT 220 URL===>>"+clientURL);
				restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
				HttpHeaders headers = new HttpHeaders();
		
				((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
						.setConnectTimeout(Integer.parseInt(GenericConfiguration.getDescription("connect_time_out")));
		
				((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
						.setReadTimeout(Integer.parseInt(GenericConfiguration.getDescription("read_time_out")));
		
				restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
				restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
				restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
				restTemplate.setErrorHandler(new CustomResponseErrorHandler());
		
				
				headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
				headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));
		
				HttpEntity<String> entity = new HttpEntity<>(headers);
				ResponseEntity<CustomerInvoiceSummaryResponse> responsePojo = null;
				responsePojo = restTemplate.exchange(clientURL, HttpMethod.GET, entity, CustomerInvoiceSummaryResponse.class);
				logger.info("responsePojo postUpdateCustomerInvoiceToFX---" + mapper.writeValueAsString(responsePojo));
		
				logger.info("responsePojo--->>" + responsePojo.getBody());
		
				if (responsePojo != null) {
					if (HttpStatus.OK == responsePojo.getStatusCode()) {
						if (responsePojo.getBody().getEbmHeader() != null && responsePojo.getBody().getDataArea() != null) {
							logger.info("success--postUpdateCustomerInvoiceToFX--->>" + responsePojo.getBody());
		
						} else {
							status_code = responsePojo.getStatusCode().toString();
							soaFault = responsePojo.getBody().getSoaFault();
							logger.info("faultResponsePojo postUpdateCustomerInvoiceToFX -->>"
									+ responsePojo.getBody().getSoaFault());
						}
					}
		
					else {
						status_code = responsePojo.getStatusCode().toString();
						soaFault = responsePojo.getBody().getSoaFault();
						logger.info("faultResponsePojo postUpdateCustomerInvoiceToFX -->>"
								+ responsePojo.getBody().getSoaFault());
						
					}
					logger.info("BEFORE createResponseJSONForpostUpdateCustomerInvoiceToFX  in postUpdateCustomerInvoiceToFX ");
					if(fileIdentifier!= null && fileIdentifier .equalsIgnoreCase("SAL"))
						bulkDetailsres = createResponseJSONForpostUpdateCustomerInvoiceToFX1(responsePojo, fileIdentifier,bulkDetails, status_code,clientURL);
					else
						bulkDetailsres = createResponseJSONForpostUpdateCustomerInvoiceToFX(responsePojo, fileIdentifier,bulkDetails, status_code,clientURL);
					logger.info("AFTER createResponseJSONForpostUpdateCustomerInvoiceToFX  in postUpdateCustomerInvoiceToFX ");
				} 
		
			
			} catch (Exception e) {
				logger.info("Got error in the response of FX  pTransactionId postUpdateCustomerInvoiceToFX-->"
						+ bulkDetailsres.getRecordId(), e);
				bulkDetailsres.setErrorMsg(e.getMessage());
				bulkDetailsres.setErrorReasonCode(e.getMessage());
				bulkDetailsres.setErrorCode(e.getMessage());
				bulkDetailsres.setErrorCodeDescription(e.getMessage());
				bulkDetailsres.setInvoiceNo("0");
				bulkDetailsres.setOrigBillRefResets("0");
		
					logger.info(
							"Got faulty code from the response READ_TEXT  of FX resultConectRead postUpdateCustomerInvoiceToFX-----> pTransactionId"
									+ bulkDetailsres.getRecordId() + " " + READ_TEXT);
		
				
			}
		
			logger.info("END--->in postUpdateCustomerInvoiceToFX method of GetCustomerInvoiceSummaryV5");
			return bulkDetailsres;
}

	private BulkDetails createResponseJSONForpostUpdateCustomerInvoiceToFX(
			ResponseEntity<CustomerInvoiceSummaryResponse> responsePojo, String fileIdentifier ,BulkDetails bulkDetails,String status_code,String reqUrl) {
		
		String result = EMPTY_STRING;
		String status_description = EMPTY_STRING;
		String rowValues = EMPTY_STRING;
		boolean invoiceMatched=false;
		String interfaceStatusFlag=EMPTY_STRING;
		String statusCode =EMPTY_STRING;
		
		List<BulkDetails> bulkDetailsList = new ArrayList<BulkDetails>();
		ClientDAO clientDAO = new ClientDAOImpl();
		bulkDetailsList = clientDAO.fetchInvoiceDetails(bulkDetails.getAcctEXTID());
		BulkDetails bulkDetail=new BulkDetails();
		

		for(BulkDetails bulkData : bulkDetailsList){
			try{
				bulkData.setAcctEXTID(bulkDetails.getAcctEXTID());
				
				if(responsePojo != null){
					if(responsePojo.getBody().getEbmHeader() != null && responsePojo.getBody().getDataArea()!= null ){
						interfaceStatusFlag=SUCCESS;
						logger.info("if success from int_220 interfaceStatusFlag-->"+interfaceStatusFlag);
					
						EbmHeader ebmHeader = responsePojo.getBody().getEbmHeader();
						if(CommonUtil.isNotNull(ebmHeader.getConsumerTransactionId()))
							ebmHeader.getConsumerTransactionId();
						
						Customer customer =null;
						CustomerBillingCycle customerBillingCycle =null;
						CustomerPayment customerPayment =null;
						BillPeriod billPeriod =null;
						if(responsePojo.getBody().getDataArea()!= null){
							
							DataArea dataArea = responsePojo.getBody().getDataArea();
							if(dataArea.getGetCustomerInvoiceSummaryResponse()!= null){
								GetCustomerInvoiceSummaryResponse invoiceResponse = dataArea.getGetCustomerInvoiceSummaryResponse();
								if(invoiceResponse.getStatus()!= null){
									Status status =invoiceResponse.getStatus();
									status_description =status.getStatusCode()+ ":" +status.getStatusDescription();
									logger.info("status_description in createResponseJSONForpostUpdateCustomerInvoiceToFX--->>" + status_description);
								}
								List<InvoiceDetail> invoiceList = invoiceResponse.getInvoiceDetails();
								if(invoiceList != null && invoiceList.size()>0){
									logger.info("invoiceDetails.length11-->> " + invoiceList.size());
									bulkData.setInvoiceList(invoiceList);
									int count = 0;
									for(InvoiceDetail invoiceDetails :invoiceList){
										count++;
										rowValues = rowValues + " AND ROW " + count + "-->> ";
										boolean amountMatched = true;
										customer= invoiceDetails.getCustomer();
										customerBillingCycle =invoiceDetails.getCustomerBillingCycle();
										customerPayment =invoiceDetails.getCustomerPayment();
										billPeriod =invoiceDetails.getBillPeriod();
										
										if(customer !=null){
											if(customer.getCustomerAccount()!=null){
												List<CustomerAccount> customerAccountList = customer.getCustomerAccount();
												if(customerAccountList != null && customerAccountList.size()>0){
													for(CustomerAccount customerAccount :customerAccountList){
														List<Identification> identificationList= customerAccount.getIdentification();
														if(identificationList!= null && identificationList.size()>0){
															for(Identification ident:identificationList){
																if (CommonUtil.isNotNull(ident.getId())) {
																	ident.getId();
																	bulkData.setAcctEXTID(ident.getId());
																	logger.info(ident.getType()+"in createResponseJSONForPostCustomerInvoiceDetailsToFX-->>"+ident.getId());
																}
															}
														}
														
													}
												}
											}
										}
										if(customerBillingCycle!=null){
											if (CommonUtil.isNotNull(customerBillingCycle.getBillingDate())) {
												customerBillingCycle.getBillingDate();
												logger.info("BillingDate in createResponseJSONForPostCustomerInvoiceDetailsToFX-->>"+customerBillingCycle.getBillingDate());
											}
											
											if (CommonUtil.isNotNull(customerBillingCycle.getPaymentDueDate())) {
												customerBillingCycle.getPaymentDueDate();
												logger.info("PaymentDueDate in createResponseJSONForPostCustomerInvoiceDetailsToFX-->>"+customerBillingCycle.getPaymentDueDate());
											}
											
											if(customerBillingCycle.getPartyBill()!= null){
												PartyBill partyBill=customerBillingCycle.getPartyBill();
												if (CommonUtil.isNotNull(partyBill.getDueAmount())) {
													partyBill.getDueAmount();
													logger.info("DueAmount in createResponseJSONForPostCustomerInvoiceDetailsToFX-->>"+partyBill.getDueAmount());
												}
												if (CommonUtil.isNotNull(partyBill.getTotalPaymentMade())) {
													logger.info("TotalPaymentMade in createResponseJSONForPostCustomerInvoiceDetailsToFX-->>"+partyBill.getTotalPaymentMade());
												}
												if (CommonUtil.isNotNull(partyBill.getTotalAdjustment())) {
													logger.info("TotalAdjustment in createResponseJSONForPostCustomerInvoiceDetailsToFX-->>"+partyBill.getTotalAdjustment());
												}
												if(CommonUtil.isNotNull(partyBill.getNetAmountPayable())){
													logger.info("NetAmountPayable in createResponseJSONForPostCustomerInvoiceDetailsToFX-->>"+partyBill.getNetAmountPayable());
												}
												
												if(CommonUtil.isNotNull(partyBill.getTotalDepositAmount())){
													logger.info("TotalDepositAmount in createResponseJSONForPostCustomerInvoiceDetailsToFX-->>"+partyBill.getTotalDepositAmount());
												}
											}
										}
										
										if(customerPayment!= null){
											if(customerPayment.getPartyPayment()!=null){
												PartyPayment partyPayment =customerPayment.getPartyPayment();
												if (CommonUtil.isNotNull(partyPayment.getReferenceNumber())) {
													logger.info("ref no in createresponsejasonfor customerinvoivce details--->>"+partyPayment.getReferenceNumber());
													logger.info("invoice no from file or epp--->>>"+bulkData.getInvoiceNo());
													if(bulkData.getInvoiceNo().equalsIgnoreCase(partyPayment.getReferenceNumber())){
														invoiceMatched = true;
														bulkData.setInvoiceNo(partyPayment.getReferenceNumber());
														logger.info("invoice no matched--->>>"+bulkData.getInvoiceNo());
														
														if (CommonUtil.isNotNull(partyPayment.getBillResets())) {
															logger.info("orig bill refresets in createResponseJSONForPostCustomerInvoiceDetailsToFX----->>"+partyPayment.getBillResets());
															bulkData.setOrigBillRefResets(partyPayment.getBillResets());
															logger.info("orig bill refresets set in fileRecords----->>"+bulkData.getOrigBillRefResets());

														}else{
															bulkData.setOrigBillRefResets("0");
														}
														break;
													}
													else{
														invoiceMatched=false;
													}
												}
												else{
													logger.info("reference number is null then invoice no is 0");
													bulkData.setInvoiceNo("0");
												}
												
											}
										}
										
										if(billPeriod!=null){
											if (CommonUtil.isNotNull(billPeriod.getStartDate())) {
												billPeriod.getStartDate();
											}

											if (CommonUtil.isNotNull(billPeriod.getEndDate())) {
												billPeriod.getEndDate();
											}
										}

									}
									if(!invoiceMatched){
										bulkData.setInvoiceNo("0");
										bulkData.setOrigBillRefResets("0");

									}
									
								}
								else{
								      bulkData.setInvoiceNo("0");
								      bulkData.setOrigBillRefResets("0");
								}
								
								
							}
						
							bulkDetail=bulkData;
							}
					}
					else if(responsePojo.getBody().getSoaFault() != null){
						SoaFault fault =responsePojo.getBody().getSoaFault();
						String[] soaFaultCodeArray = fault.getSoaFaultCode().split("-");
						statusCode = soaFaultCodeArray[1] + "-" + soaFaultCodeArray[2];
						String fault_value = fault.getFaultDescription();
						if (fault_value.length() > 999)
							fault_value = fault_value.substring(0, 1000);

						status_description = statusCode + ":" + fault_value;
						status_description = status_description.replace("'", "");
						logger.info(
								"Status description is in createResponseJSONForPaymentReversalToFX when error response from webservice---> "
										+ status_description);
						
					}
					
					result="";//clientDAO.updateInvoiceDetails(fileIdentifier,bulkData.getAcctEXTID(),bulkData.getInvoiceNo(),
							//bulkData.getOrigBillRefResets(),bulkData.getTransactionId(),status_description,interfaceStatusFlag,"");
					String statuss =status_code.equals("200")?"SUCCESS":"FAILED";
					clientDAO.insertFxLog(statuss, bulkDetails.getAcctEXTID(), reqUrl, mapper.writeValueAsString(responsePojo), "Mobility", bulkDetails.getApsFlag(), "CustomerInvoice", null, null, null, null);
					
				}
				
			}
			catch(Exception e){
				logger.error("erroe occur while file fx "+e.getMessage(), e);
			}
		
		}
		return bulkDetail;
	}
	
	private BulkDetails createResponseJSONForpostUpdateCustomerInvoiceToFX1(
			ResponseEntity<CustomerInvoiceSummaryResponse> responsePojo, String fileIdentifier ,BulkDetails bulkDetails,String status_code,String reqUrl) {
		
		String result = EMPTY_STRING;
		String status_description = EMPTY_STRING;
		String rowValues = EMPTY_STRING;
		boolean invoiceMatched=false;
		String interfaceStatusFlag=EMPTY_STRING;
		String statusCode =EMPTY_STRING;
		
		List<BulkDetails> bulkDetailsList = new ArrayList<BulkDetails>();
		ClientDAO clientDAO = new ClientDAOImpl();
		bulkDetailsList = clientDAO.fetchInvoiceDetails(bulkDetails.getAcctEXTID());
		BulkDetails bulkDetail1=new BulkDetails();
		
		if(responsePojo != null){
			
			

			if(responsePojo.getBody().getEbmHeader() != null && responsePojo.getBody().getDataArea()!= null ){
				interfaceStatusFlag=SUCCESS;
				logger.info("if success from int_220 interfaceStatusFlag-->"+interfaceStatusFlag);
			
				EbmHeader ebmHeader = responsePojo.getBody().getEbmHeader();
				if(CommonUtil.isNotNull(ebmHeader.getConsumerTransactionId()))
					ebmHeader.getConsumerTransactionId();
				
				Customer customer =null;
				CustomerBillingCycle customerBillingCycle =null;
				CustomerPayment customerPayment =null;
				BillPeriod billPeriod =null;
				if(responsePojo.getBody().getDataArea()!= null){
					
					DataArea dataArea = responsePojo.getBody().getDataArea();
					if(dataArea.getGetCustomerInvoiceSummaryResponse()!= null){
						GetCustomerInvoiceSummaryResponse invoiceResponse = dataArea.getGetCustomerInvoiceSummaryResponse();
						if(invoiceResponse.getStatus()!= null){
							Status status =invoiceResponse.getStatus();
							status_description =status.getStatusCode()+ ":" +status.getStatusDescription();
							logger.info("status_description in createResponseJSONForpostUpdateCustomerInvoiceToFX--->>" + status_description);
						}
						List<InvoiceDetail> invoiceList = invoiceResponse.getInvoiceDetails();
						if(invoiceList != null && invoiceList.size()>0){
							bulkDetail1.setAcctEXTID(bulkDetails.getAcctEXTID());
							bulkDetail1.setInvoiceList(invoiceList);
							}
						}
					}
			}
			
			try{
				clientDAO.insertFxLog(responsePojo.getStatusCode()+"", bulkDetails.getAcctEXTID(), reqUrl, mapper.writeValueAsString(responsePojo), null, null, "INT-220 UI", null, null, null, null);
			}
			catch(Exception e){
				logger.error("error in createResponseJSONForpostUpdateCustomerInvoiceToFX1--->>"+e.getMessage());
				}
			
		}
		return bulkDetail1;
		
	}
	
	
	public static void main(String[] args) throws Exception {
		BulkDetails bulkDetails =new BulkDetails();
		bulkDetails.setAcctEXTID("1270273342");
		bulkDetails.setApsFlag("CAD");
		new GetCustomerInvoiceSummaryV5().postUpdateCustomerInvoiceToFX(bulkDetails, "MISC_220");
	}

}
