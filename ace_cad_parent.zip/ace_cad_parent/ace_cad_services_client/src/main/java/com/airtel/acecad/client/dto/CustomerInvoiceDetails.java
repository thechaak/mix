package com.airtel.acecad.client.dto;

public class CustomerInvoiceDetails {

	String invoiceNo;
	String billRefResets;
	String balanceDue;
	String carriedForward;
	String fromDate;
	String lateExemptCharges;
	String paymentDueDate;
	String statementDate;
	String toDate;
	String totalAdj;
	String totalDue;
	String statusCode;
	String statusDescription;
	
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public String getBillRefResets() {
		return billRefResets;
	}
	public void setBillRefResets(String billRefResets) {
		this.billRefResets = billRefResets;
	}
	public String getBalanceDue() {
		return balanceDue;
	}
	public void setBalanceDue(String balanceDue) {
		this.balanceDue = balanceDue;
	}
	public String getCarriedForward() {
		return carriedForward;
	}
	public void setCarriedForward(String carriedForward) {
		this.carriedForward = carriedForward;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getLateExemptCharges() {
		return lateExemptCharges;
	}
	public void setLateExemptCharges(String lateExemptCharges) {
		this.lateExemptCharges = lateExemptCharges;
	}
	public String getPaymentDueDate() {
		return paymentDueDate;
	}
	public void setPaymentDueDate(String paymentDueDate) {
		this.paymentDueDate = paymentDueDate;
	}
	public String getStatementDate() {
		return statementDate;
	}
	public void setStatementDate(String statementDate) {
		this.statementDate = statementDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getTotalAdj() {
		return totalAdj;
	}
	public void setTotalAdj(String totalAdj) {
		this.totalAdj = totalAdj;
	}
	public String getTotalDue() {
		return totalDue;
	}
	public void setTotalDue(String totalDue) {
		this.totalDue = totalDue;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	
}
