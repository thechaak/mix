package com.airtel.acecad.client.json.custAccountSummaryJson;

public class LogicalResource {

	private LogicalResourceIdentification Identification;

    private String type;


	public LogicalResourceIdentification getIdentification() {
		return Identification;
	}

	public void setIdentification(LogicalResourceIdentification identification) {
		Identification = identification;
	}

	public String getType ()
    {
        return type;
    }

    public void setType (String type)
    {
        this.type = type;
    }

    @Override
    public String toString()
    {
        return "{\"identification\" : "+Identification+", \"type\" : \""+type+"\"}";
    }
}
