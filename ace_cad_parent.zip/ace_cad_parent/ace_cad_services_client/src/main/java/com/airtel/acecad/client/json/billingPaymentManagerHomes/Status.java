package com.airtel.acecad.client.json.billingPaymentManagerHomes;

public class Status {

	 private String statusCode;

	    private String statusDescription;

	    private String backendErrorCode;

	    public String getStatusCode ()
	    {
	        return statusCode;
	    }

	    public void setStatusCode (String statusCode)
	    {
	        this.statusCode = statusCode;
	    }

	    public String getStatusDescription ()
	    {
	        return statusDescription;
	    }

	    public void setStatusDescription (String statusDescription)
	    {
	        this.statusDescription = statusDescription;
	    }


	    public String getBackendErrorCode() {
			return backendErrorCode;
		}

		public void setBackendErrorCode(String backendErrorCode) {
			this.backendErrorCode = backendErrorCode;
		}

		@Override
	    public String toString()
	    {
	        return "{\"statusCode\":\""+statusCode+"\", \"statusDescription\":\""+statusDescription+"\", \"backendErrorCode\":\""+backendErrorCode+"\"}";
	    }
}
