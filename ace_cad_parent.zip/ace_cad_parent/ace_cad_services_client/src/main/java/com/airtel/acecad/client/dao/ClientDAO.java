package com.airtel.acecad.client.dao;

import java.util.List;

import com.airtel.acecad.client.dto.AdjPostDetails;
import com.airtel.acecad.client.dto.AdjReversalDetails;
import com.airtel.acecad.client.dto.BulkDetails;
import com.airtel.acecad.client.dto.CreateUpdateNotesDetails;
import com.airtel.acecad.client.dto.DepositDetails;
import com.airtel.acecad.client.dto.DepositReversalDetails;
import com.airtel.acecad.client.dto.NrcDetails;
import com.airtel.acecad.client.dto.NrcReversalDetails;
import com.airtel.acecad.client.dto.PaymentBreakupHomesDetails;
import com.airtel.acecad.client.dto.PostPaymentToFXRequest;
import com.airtel.acecad.client.dto.RefundPostDetails;
import com.airtel.acecad.client.dto.ResponsePojoForHomes;
import com.airtel.acecad.client.dto.SRApprovalTaskCallbackDetails;
import com.airtel.acecad.client.json.billingPaymentManagerHomes.ResponseFromGetAnchorIdPojo;

public interface ClientDAO {
	/*
	 * @author :- Tanu Goyal--for Post Payment to FX
	 */
	
	public List<PostPaymentToFXRequest> fetchPaymentPostDetails(String accountId, String fileIdentifier) throws Exception;

	/* * @author :- GEETA Rajput--for Customer Deposit to FX
	 */
	
	public List<DepositDetails> fetchDepositDetails(String accountId) throws Exception;
	
	/*
	 * @author :- GEETA Rajput--for Adjustment Posting to FX
	 */
	public List<AdjPostDetails> fetchAdjustmentPostDetails(String accountId) throws Exception;
	
	/*
	 * @author :- GEETA Rajput--for NRC FOR FAILED PAYMENT to FX
	 */
	public List<NrcDetails> fetchNrcDetails(String accountId) throws Exception;
	
	/*
	 * @author :- GEETA Rajput--for NRC CHEQUE BOUNCE to FX
	 */
	public List<NrcDetails> fetchNrcChequeBounceDetails(String accountId) throws Exception;
	
	/*public String updateResponseForNrcChequeBounce(String StatusDescription, int trackingId, int trackingServId,
			NrcDetails nrcChequeBounceDetails, String tableName, int viewID) throws Exception;*/
	
	public String updateResponseForNrcChequeBounce(String StatusDescription, int trackingId, int trackingServId,
			NrcDetails nrcChequeBounceDetails, String tableName, int viewID,int jobId) throws Exception;
	
	/*
	 * @author :- GEETA Rajput--for NRC Reversal to FX
	 */
	public List<NrcReversalDetails> fetchNrcReversalDetails(String accountId) throws Exception;
	
	/*
	 * @author :- GEETA Rajput--for REFUND to FX
	 */
	public List<RefundPostDetails> fetchRefundDetails(String accountId) throws Exception;
	
	///////For INT_632
	//public String fetchFormCustAccountSummary(String accountId, int fxOutstandingAmount) throws Exception;
	
	public String fetchFormCustAccountSummary(String accountId, String fxOutstandingAmount, String mktCode,
			String givenName, String FamilyName,BulkDetails bulkDetails) throws Exception;

	
	public List<DepositReversalDetails> fetchDepositReversalDetails(String accountId) throws Exception;
	
	//public String fetchUserName(String userId) throws Exception;
	
	/*
	 * @author :- GEETA Rajput--for SRApprovalTaskCallback to FX
	 */
	public Object[] fetchSRApprovalTaskCallbackDetails(int srTransactionNo)
			throws Exception;
	/*public String updateResponseForSeibelCallback(String statusCode, String StatusDescription, SRApprovalTaskCallbackDetails srApprovalTaskCallbackDetails)
			throws Exception;*/
/*	public String updateResponseForSeibelCallback(String statusCodeWeb, String StatusDescription,
			SRApprovalTaskCallbackDetails srApprovalTaskCallbackDetails,String statusCode) throws Exception;*/
	
	public String updateResponseForSeibelCallback(String statusCodeWeb, String StatusDescription,
			SRApprovalTaskCallbackDetails srApprovalTaskCallbackDetails, String statusCode,int jobId) throws Exception;
	
	
	/*
	 * @author :- GEETA Rajput--Common
	 */
	//public String updateApsFlag(int accountId ) throws Exception;
	
	public String fetchTableName(String fileIdentifier) throws Exception;

	
	/*public String updateResponse(String statusDescription, int trackingId, int trackingServId, int transactionNo,
			String tableName, int viewId,int jobId) throws Exception;*/
	
	public String updateResponse(String statusDescription, int trackingId, int trackingServId, int transactionNo,
			String tableName, int viewId, int jobId,String annotation3,String annotation5,String faultTrace) throws Exception ;
	
	public String deriveApsFlagAndUpdate(String apsFlag, String account_external_id,String msisdn, String service_multi_type);
	//public void updateAPSFlag(String i_jobId,String level,String fxThread,String siebelThread,String anchorThread,String homesThread);
	public void updateAPSFlag(String i_jobId,String level,String fxThread,String siebelThread,
			String anchorThread,String homesThread);
	
	/*ADED BY TANU TO IDENTIFY TO CALL 313 OR 315*/
	public List deriveRecordType( String account_external_id) throws Exception;
	
	
	/*
	 * @author :- GEETA Rajput---For Adjustment Reversal (418_A cancel)
	 */
	public List<AdjReversalDetails> fetchAdjustmentReversalDetails(String accountId) throws Exception;
	
	/*
	 * @author :- GEETA Rajput--After 632 Refund statuscode 
	 */
	public String updateStatusAfterCustAccSummary(String accountId) throws Exception;
	
	/*
	 * @author :- GEETA Rajput--INT_226_F (Create updateNotes) 
	 */
	//public List<CreateUpdateNotesDetails> fetchUpdateNotesDetails(int sr_transaction_no) throws Exception;
	//Added for Refund 226_F
	public Object[] fetchCreateUpdateNotesDetails(int srTransactionNo) throws Exception;
	
	/*public String updateResponseForCreateUpdateNotes(String statusCodeWeb, String satus_description,
			int sr_transaction_no, CreateUpdateNotesDetails createUpdateNotesDetails,String statusCode) throws Exception;*/
	//comment this one
	/*public String updateResponseForCreateUpdateNotes(String statusCodeWeb, String satus_description,
			int sr_transaction_no, CreateUpdateNotesDetails createUpdateNotesDetails, String statusCode,int jobId)
			throws Exception;*/
	//Added new for response update 226_F
	public String updateResponseForNotes(String statusDescription, int srTransactionNo,String fileIdentifier)
			throws Exception;
	
	//commneted by geeta
	//public String updateJobId(String tableName, int transactionNo) throws Exception;
	public Object[] updateJobId(String tableName, int transactionNo,String homes_job_id,int job_id) throws Exception;
	
	//ADDED BY TANU
		public String updateConnectionReadResponse( int transactionNo,
				String tableName,String conectReadText) throws Exception;
		
		//For Homes inteface 
		public String updateHomeIdDetails(String accountId,String lob,String fileIdentifier,String homesId,
				String homesIdDesc) throws Exception;
		
		
		public String updateResponseForPaymentBreakupFetch(List<ResponsePojoForHomes> responsePojoList,String status_description
				,String transactionId,String accountNo,String lob,String aps_flag,String homesId) throws Exception;
		
		public List<BulkDetails> fetchInvoiceDetails(String account_no);
		
		 //public String updateInvoiceDetails(String fileIdentifier,String acct_no,String invoice_no,String billRefResets,String transactionId);
		public String updateInvoiceDetails(String fileIdentifier,String acct_no,String invoice_no,String billRefResets,
				 String transactionId,String statusDescription,String interfaceStatusFlag,String suspenseAmount) throws Exception; 
		
		 public String updateFailureResponseFromHomes(String status_description,String transactionId,String backendErrorCode,
				 String aps_flag) throws Exception;
		 
		 //FOR REVERSAL HOMES BREAKUP
		 public String updateResponseForRevHomes(String status_description,String transactionId,String tableName) throws Exception;
		 
		  public List getCallBackDetails(int transactionId);

public void updateCallBackResponse(String statusDesc,String statusCode,int transactionId);

	public String insertFxLog(String statusCode,String trxnId,String reqJson,String respJson,String lob,String apsFlag,String identifier,String array1,String array2,String dataSet1,String dataSet2) ;
   public String getCustomerBillingAccDetail(String transactionId);
	public List<NrcDetails> fetchNrcDetailsByAccOrMob(String accountId,String mobile) throws Exception ;
	public  String updateResponseForPTSRRevHomes(String statusDescription,String transactionId,String tableName)throws Exception;
	public String updateResponseForPTSRAPPHomes(List<ResponsePojoForHomes> responsePojoList ,String statusDescription,String transactionId,String accountId,String lob,String aps_Flag,String homesId,String tableName)throws Exception;
	public String getDepositTypeValue(String depositCode);

	public String getLobFromServerId(String serverId);

}

