package com.airtel.acecad.client.json.custAccountSummaryJson;


public class GetCustomerAccountSummaryReqMsg {

	 private EbmHeader ebmHeader;

	    private RequestDataArea dataArea;

	    public EbmHeader getEbmHeader ()
	    {
	        return ebmHeader;
	    }

	    public void setEbmHeader (EbmHeader ebmHeader)
	    {
	        this.ebmHeader = ebmHeader;
	    }

	    public RequestDataArea getDataArea ()
	    {
	        return dataArea;
	    }

	    public void setDataArea (RequestDataArea dataArea)
	    {
	        this.dataArea = dataArea;
	    }

	    @Override
	    public String toString()
	    {
	        return "{\"ebmHeader\" : "+ebmHeader+", \"dataArea\" : "+dataArea+"}";
	    }
}
