package com.airtel.acecad.client.dto;

import java.util.Arrays;

public class PaymentHistoryBaseResponse {
private Object[] object;
private String result;
public Object[] getObject() {
	return object;
}
public void setObject(Object[] object) {
	this.object = object;
}
public String getResult() {
	return result;
}
public void setResult(String result) {
	this.result = result;
}
@Override
public String toString() {
	return "PaymentHistoryBaseResponse [object=" + Arrays.toString(object) + ", result=" + result + "]";
}


}
