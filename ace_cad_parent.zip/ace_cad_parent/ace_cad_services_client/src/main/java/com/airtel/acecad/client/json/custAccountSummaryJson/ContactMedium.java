package com.airtel.acecad.client.json.custAccountSummaryJson;

public class ContactMedium {

	private String emailAddress;

    public String getEmailAddress ()
    {
        return emailAddress;
    }

    public void setEmailAddress (String emailAddress)
    {
        this.emailAddress = emailAddress;
    }

    @Override
    public String toString()
    {
        return "{\"emailAddress\" : \""+emailAddress+"\"}";
    }
}
