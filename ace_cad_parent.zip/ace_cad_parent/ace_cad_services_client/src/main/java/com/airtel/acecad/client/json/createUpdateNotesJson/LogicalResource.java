package com.airtel.acecad.client.json.createUpdateNotesJson;

public class LogicalResource {

	private LogicalResourceIdentification Identification;

    //private String type;


	public LogicalResourceIdentification getIdentification() {
		return Identification;
	}

	public void setIdentification(LogicalResourceIdentification identification) {
		Identification = identification;
	}

	

    @Override
    public String toString()
    {
        return "{\"identification\" : "+Identification+"}";
    }
}
