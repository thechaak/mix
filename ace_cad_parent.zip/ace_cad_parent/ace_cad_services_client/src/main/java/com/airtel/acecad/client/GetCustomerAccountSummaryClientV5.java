package com.airtel.acecad.client;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.codec.binary.Base64;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.airtel.acecad.client.dao.ClientDAO;
import com.airtel.acecad.client.dao.ClientDAOImpl;
import com.airtel.acecad.client.dto.BulkDetails;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.Address;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.BillPeriod;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.Contact;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.Customer;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.CustomerAccount;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.CustomerAccountSummaryResponse;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.CustomerBill;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.DataArea;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.EbmHeader;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.GetCustomerAccountSummaryResponse;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.Identification;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.IdentificationById;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.IndividualName;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.LogicalResource;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.ParentAccount;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.PartyAccount;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.PartyBill;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.PartyPayment;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.SoaFault;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.Status;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.TelephoneNumber;

import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.CustomResponseErrorHandler;
import com.airtel.acecad.client.util.EncryDecrypUtility;
import com.airtel.acecad.client.util.GenericConfiguration;
import com.airtel.acecad.client.util.GlobalConstants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
public class GetCustomerAccountSummaryClientV5 implements GlobalConstants {

	private static final Logger logger = LogManager.getLogger("serviceClientUI");
	private static final ObjectMapper mapper = new ObjectMapper();
	public BulkDetails postCustomerAccountSummaryToFX(BulkDetails bulkDetails,String customerMigratedFlag) throws Exception {

		logger.info("Start :postCustomerAccountSummaryToFX in CustomerAccountSummaryClient");
		String result = EMPTY_STRING;
		String status_code = EMPTY_STRING;
		BulkDetails bulkDetailsres = new BulkDetails();
		SoaFault soaFault = null;
		RestTemplate restTemplate = new RestTemplate();

	
		try {
			String userpass = GenericConfiguration.getDescription("kenon.postPaymentToFX.userName") + ":"
					+ EncryDecrypUtility.decrypt(GenericConfiguration.getDescription("kenon.postPaymentToFX.password"));

			String clientURL = GenericConfiguration.getDescription("kenon.postUpdateRefundCustomerAccountSummaryToFXV5.url")+
					"domain=B2C&lob=Mobility&subLob=Postpaid&consumerTransactionId=11343&consumerName=APS"+
					"&programmeName=EAIMigration&customerMigrated="+customerMigratedFlag+"&accountId="+bulkDetails.getAcctEXTID()+"&accountType=&flag=&MSISDN=&serviceType=MSISDN";
					//+ customerMigratedFlag+  GenericConfiguration.getDescription("accountId") + bulkDetails.getAcctEXTID();
			restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
			HttpHeaders headers = new HttpHeaders();
			logger.info("client url in postCustomerAccountSummaryToFX-->>>"+clientURL);
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
					.setConnectTimeout(Integer.parseInt(GenericConfiguration.getDescription("connect_time_out")));

			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
					.setReadTimeout(Integer.parseInt(GenericConfiguration.getDescription("read_time_out")));

			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
			restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
			restTemplate.setErrorHandler(new CustomResponseErrorHandler());

			userpass = GenericConfiguration.getDescription("kenon.postPaymentToFX.userName") + ":"
					+ EncryDecrypUtility.decrypt(GenericConfiguration.getDescription("kenon.postPaymentToFX.password"));
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));

			HttpEntity<String> entity = new HttpEntity<>(headers);
			ResponseEntity<CustomerAccountSummaryResponse> responsePojo = null;
			responsePojo = restTemplate.exchange(clientURL, HttpMethod.GET, entity, CustomerAccountSummaryResponse.class);
			logger.info("responsePojo postUpdatePaymentReversalToFX---" + mapper.writeValueAsString(responsePojo));

		
			logger.info("responsePojo--->>" + responsePojo.getBody());

			logger.info("responsePojo postCustomerAccountSummaryToFX--->" + mapper.writeValueAsString(responsePojo));

			if (responsePojo != null) {
				if (HttpStatus.OK == responsePojo.getStatusCode()) {
					if (responsePojo.getBody().getEbmHeader() != null && responsePojo.getBody().getDataArea() != null) {
						
						logger.info("success--postCustomerAccountSummaryToFX--->>" + responsePojo.getBody());

					} else {
						status_code = responsePojo.getStatusCode().toString();
						soaFault = responsePojo.getBody().getSoaFault();
						logger.info("faultResponsePojo postCustomerAccountSummaryToFX -->>"
								+ responsePojo.getBody().getSoaFault());
					}
				}

				else {
					status_code = responsePojo.getStatusCode().toString();
					soaFault = responsePojo.getBody().getSoaFault();
					logger.info("faultResponsePojo postCustomerAccountSummaryToFX -->>"
							+ responsePojo.getBody().getSoaFault());
					// log.info("faultResponsePojo
					// postCustomerAccountSummaryToFX-->>" + fault);
				}
				logger.info("BEFORE createResponseJSONForPostCustAccountSummaryToFX  in postCustAccountSummaryToFX INT-632");
				bulkDetailsres = createResponseJSONForPostCustAccountSummaryToFX(responsePojo, status_code, soaFault,clientURL);
				logger.info("AFTER createResponseJSONForPostCustAccountSummaryToFX  in postCustAccountSummaryToFX ");
			} else {
				logger.info("IN method  createResponseJSONForPostCustAccountSummaryToFX response pojo is null");
			}

		
		} catch (Exception e) {
			logger.info("Got error in the response of FX  pTransactionId postCustomerAccountSummaryToFX-->"
					+ bulkDetailsres.getRecordId(), e);
			bulkDetailsres.setErrorMsg(e.getMessage());
			bulkDetailsres.setErrorReasonCode(e.getMessage());
			bulkDetailsres.setErrorCode(e.getMessage());
			bulkDetailsres.setErrorCodeDescription(e.getMessage());
			if (e.getCause().toString().contains(CONNECT_TEXT)) {
				bulkDetailsres.setErrorMsg(CONNECT_TEXT);
				bulkDetailsres.setErrorReasonCode(CONNECT_TEXT);
				bulkDetailsres.setErrorCode(CONNECT_TEXT);
				bulkDetailsres.setErrorCodeDescription(CONNECT_TEXT);

			}

			if (e.getCause().toString().contains(READ_TEXT)) {
				bulkDetailsres.setErrorMsg(READ_TEXT);
				bulkDetailsres.setErrorReasonCode(READ_TEXT);
				bulkDetailsres.setErrorCode(READ_TEXT);
				bulkDetailsres.setErrorCodeDescription(READ_TEXT);
				logger.info(
						"Got faulty code from the response READ_TEXT  of FX resultConectRead postCustomerAccountSummaryToFX-----> pTransactionId"
								+ bulkDetailsres.getRecordId() + " " + READ_TEXT);

			}
		}

		logger.info("END--->in postCustomerAccountSummaryToFX method of CustAccountSummaryClient");
		return bulkDetailsres;
	}
	public BulkDetails createResponseJSONForPostCustAccountSummaryToFX(
			ResponseEntity<CustomerAccountSummaryResponse> responsePojo, String status_code, SoaFault soaFault,
			String clientURL) {
		
		logger.info("START----in createResponseJSONForPostCustAccountSummaryToFX method of CustAccountSummaryClient");
		BulkDetails bulkDetails = new BulkDetails();
		String status_description = EMPTY_STRING;
		String dueAmount = EMPTY_STRING;
		String statusCode = EMPTY_STRING;
		String errorCode="";
		
		if(responsePojo !=null){
		 if(responsePojo.getBody().getEbmHeader()!=null)	{
			 EbmHeader ebmHeader = responsePojo.getBody().getEbmHeader();
			 if(ebmHeader!=null){
				 if(CommonUtil.isNotNull(ebmHeader.getLob())){
					 if("Telemedia".equalsIgnoreCase(ebmHeader.getLob())){
						 bulkDetails.setLob("BTS");
					 }else if("Mobility".equalsIgnoreCase(ebmHeader.getLob())){
					 bulkDetails.setLob("MOB");
					 }else{
						 bulkDetails.setLob(ebmHeader.getLob());
					 }
				 }
			 }
			 if(responsePojo.getBody().getDataArea()!=null){
				 DataArea dataArea = responsePojo.getBody().getDataArea();
				 if(dataArea.getGetCustomerAccountSummaryResponse()!=null){
					 GetCustomerAccountSummaryResponse response = dataArea.getGetCustomerAccountSummaryResponse();
					 Customer customer =response.getCustomer();
					 if(customer!=null){
						List<CustomerAccount> customerAccList = customer.getCustomerAccount();
						if(customerAccList != null && customerAccList.size()>0){
							for(CustomerAccount custAcc :customerAccList){
								List<Identification> identificationList = custAcc.getIdentification();
								if(identificationList!= null && identificationList.size()>0){
									for(Identification identification :identificationList){
										String id= identification.getId();
										String type = identification.getType();
										if(type != null && type.toUpperCase().contains(BILLABLE)){
											logger.info("BillableAccountid from INT_632------------------>>>>>"+id);	
											bulkDetails.setAcctEXTID(id);
											break;
										}
									}
								}
								
								if (CommonUtil.isNotNull(custAcc.getAccountType())) {
									bulkDetails.setAccountType(custAcc.getAccountType());
								}
								if (CommonUtil.isNotNull(custAcc.getAccountStatus())) {
									custAcc.getAccountStatus();
								}
								
								if(custAcc.getParentAccount()!=null){
									List<ParentAccount> parentAccList = custAcc.getParentAccount();
									if(parentAccList != null && parentAccList.size()>0){
										for(ParentAccount parentAcc : parentAccList){
											if(parentAcc!=null){
											if (CommonUtil.isNotNull(parentAcc.getId())) {
												bulkDetails.setParentAccountNumber(parentAcc.getId());
											}
											if (CommonUtil.isNotNull(parentAcc.getType())) {
												parentAcc.getType();
											}
										}
										}
										
										if(CommonUtil.isNotNull(custAcc.getProductLevel())){
											logger.info("custAcc.getProductLevel() LEGAL ENTITY-"+ custAcc.getProductLevel());
										}
										if(CommonUtil.isNotNull(custAcc.getCostCenter())){
											bulkDetails.setLegalEntity(custAcc.getCostCenter());
											logger.info("custCustomerAccount.getCostCenter() LEGAL ENTITY-"	+ custAcc.getCostCenter());
										}
										if(CommonUtil.isNotNull(custAcc.getRevRecCostCenter())){
											logger.info("custAcc.getProductLevel() LEGAL ENTITY-"+ custAcc.getRevRecCostCenter());
										}
										if(CommonUtil.isNotNull(custAcc.getRevRecCostCenter())){
											logger.info("custAcc.getProductLevel() LEGAL ENTITY-"+ custAcc.getRevRecCostCenter());
										}
										if (CommonUtil.isNotNull(custAcc.getCategory())) {
											if (custAcc.getCategory().equalsIgnoreCase("0")) {
												bulkDetails.setB2b2c("B2C");
											} else if (custAcc.getCategory().equalsIgnoreCase("1")) {
												bulkDetails.setB2b2c("B2B");
											}
										}
										
										if(CommonUtil.isNotNull(custAcc.getLinkAccountFlag())){
											logger.info("custAcc.getLinkAccountFlag() LEGAL ENTITY-"+ custAcc.getLinkAccountFlag());
										}
										
										if(CommonUtil.isNotNull(custAcc.getSegment())){
											logger.info("custAcc.getSegment() LEGAL ENTITY-"+ custAcc.getSegment());
										}
										
										if(CommonUtil.isNotNull(custAcc.getActiveDate())){
											logger.info("custAcc.getActiveDate() LEGAL ENTITY-"+ custAcc.getActiveDate());
										}
										
										if(CommonUtil.isNotNull(custAcc.getInactiveDate())){
											logger.info("custAcc.getInactiveDate() LEGAL ENTITY-"+ custAcc.getInactiveDate());
										}
										if(CommonUtil.isNotNull(custAcc.getMarketCode())){
											logger.info("custAcc.getMarketCode() LEGAL ENTITY-"+ custAcc.getMarketCode());
											bulkDetails.setMktCode(custAcc.getMarketCode());
										}
										else{
											bulkDetails.setMktCode("-1");
										}
										if(CommonUtil.isNotNull(custAcc.getActivationDate())){
											logger.info("custAcc.getActivationDate() LEGAL ENTITY-"+ custAcc.getActivationDate());
										}
										
										if(CommonUtil.isNotNull(custAcc.getBillableFlag())){
											logger.info("custAcc.getBillableFlag() LEGAL ENTITY-"+ custAcc.getBillableFlag());
										}
										
									}
								}
								
							}
						}
						
						if(CommonUtil.isNotNull(customer.getCustomerClass())){
							bulkDetails.setCustomerClass(customer.getCustomerClass());
						}
						else{
							bulkDetails.setCustomerClass("-1");
						}
						if(CommonUtil.isNotNull(customer.getCustomerType())){
							bulkDetails.setCustomerType(customer.getCustomerType());
						}
						else{
							bulkDetails.setCustomerType("-1");
						}
						
						if(CommonUtil.isNotNull(customer.getVIPFlag())){
							bulkDetails.setVipFlag(customer.getVIPFlag());
						}
						else{
							bulkDetails.setVipFlag("-1");
						}
						if(CommonUtil.isNotNull(customer.getOrganizationType())){
							logger.info("customer.getOrganizationType() LEGAL ENTITY-"+ customer.getOrganizationType());
						}
						if(CommonUtil.isNotNull(customer.getRiskSegment())){
							logger.info("customer.getRiskSegment() LEGAL ENTITY-"+ customer.getRiskSegment());
						}
						
						if(customer.getEmail()!=null){
							if(CommonUtil.isNotNull(customer.getEmail().getEMailAddress())){
								logger.info("customer.getEmail().getEMailAddress() LEGAL ENTITY-"+ customer.getEmail().getEMailAddress());
							}
						}
						
						if(customer.getIndividual()!=null){
							if(customer.getIndividual().getIndividualName()!=null){
								IndividualName individualName =customer.getIndividual().getIndividualName();
								 if(CommonUtil.isNotNull(individualName.getGivenName())) 
								 {
								 individualName.getGivenName();
								 bulkDetails.setGivenName(individualName.getGivenName());
								  } 
								  if(CommonUtil.isNotNull(individualName.getFamilyNames())) 
								  {
								 individualName.getFamilyNames();
								 bulkDetails.setFamilyName(individualName.getFamilyNames());
								 }
							}
							
							if(customer.getIndividual().getContact()!=null){
								List<Contact> contactList = customer.getIndividual().getContact();
								if(contactList!= null && contactList.size()>0){
									for(Contact contact : contactList){
										List<TelephoneNumber> telephoneList = contact.getTelephoneNumber();
										if(telephoneList!=null && telephoneList.size()>0){
											for(TelephoneNumber telephone : telephoneList){
												if (telephone.getType().contains("PrimaryContact")) {
													bulkDetails.setPrimaryContactNumber(telephone.getNumber());
													logger.info("PrimaryContact from INT_632------------------>>>>>"+telephone.getNumber());
												}
												if (telephone.getType().contains("AlternateContact")) {
													logger.info("AlternateContact from INT_632------------------>>>>>"+telephone.getNumber());
													bulkDetails.setAlternateContactNumber(telephone.getNumber());
												}
											}
										}
									}
								}
							}
						}
						
						if(customer.getAddress()!=null){
							List<Address> addressList = customer.getAddress();
							for(Address address : addressList){
								if(address.getAddressType() !=null && address.getAddressType()!= "" && address.getAddressType().equalsIgnoreCase("BillingAddress")){
									
									String addr =address.getAddressLine1()+" "+address.getAddressLine2()+" "+address.getAddressLine2()+" "+address.getCity();
									bulkDetails.setFullAddress(addr);
									
									bulkDetails.setState(address.getState());
									bulkDetails.setZipCode(address.getPincode());
									logger.info("Address in Customer account summary from INT_632-->>"+addr+" and state-->>"+address.getState()+" and pincode--->>"+address.getPincode());
								}
								
								//address of customer
								//bulkDetails.setAddress(address.getAddressLine1());
							}
							
						}
						
						if(response.getLogicalResource()!=null){
							LogicalResource logicalResource = response.getLogicalResource();
							List<IdentificationById>logicalIdentificationList = logicalResource.getIdentification();
							if(logicalIdentificationList!=null && logicalIdentificationList.size()>0){
								for(IdentificationById identificationLog:logicalIdentificationList){
									if (CommonUtil.isNotNull(identificationLog.getId())) {
										identificationLog.getId();
									}
								}
							}
							
							if(CommonUtil.isNotNull(logicalResource.getLrStatus())){
								logger.info("logicalResource.getLrStatus()" +logicalResource.getLrStatus());
							}
							
							if(CommonUtil.isNotNull(logicalResource.getReasonId())){
								logger.info("logicalResource.getReasonId()" +logicalResource.getReasonId());
							}
							if(CommonUtil.isNotNull(logicalResource.getType())){
								logger.info("logicalResource.getType()" +logicalResource.getType());
							}
						}
						
						if(response.getPartyAccount()!=null){
							PartyAccount partyAcc =response.getPartyAccount();
							if(partyAcc.getIdentification()!= null && partyAcc.getIdentification().size()>0){
								List<IdentificationById> partyAccIdentification = partyAcc.getIdentification();
									for(IdentificationById ids : partyAccIdentification){
										logger.info("Identification id In PartyAccount" +ids.getId());
									}
								}
							if(CommonUtil.isNotNull(partyAcc.getAccountCategory()))
								bulkDetails.setAccountCategory(partyAcc.getAccountCategory());
								else
									bulkDetails.setAccountCategory("-1");	
							
						}
						else
							bulkDetails.setAccountCategory("-1");
							
						if(response.getMarketSegment()!=null){
							logger.info("MarketSegment code "+response.getMarketSegment() );
						}
						
						if(response.getCustomerPayment()!=null){
							CustomerBill customerBill =response.getCustomerPayment().getCustomerBill();
						    PartyBill partyBill = customerBill.getPartyBill();
						    if(partyBill!=null){
							    if (CommonUtil.isNotNull(partyBill.getBillNo())) {
									bulkDetails.setOrigBillRefNo(partyBill.getBillNo());
								}
								if (CommonUtil.isNotNull(partyBill.getBillAmount())) {
									String amount = partyBill.getBillAmount();
									logger.info("billamount in createResponseJSONForPostCustAccountSummaryToFX--->>>"
											+ amount);
								}
								if (CommonUtil.isNotNull(partyBill.getDueAmount())) {
									dueAmount = partyBill.getDueAmount();
									bulkDetails.setFxOutstandingAmount(partyBill.getDueAmount());
									System.out.println(bulkDetails.getFxOutstandingAmount());
									logger.info("dueAmount in createResponseJSONForPostCustAccountSummaryToFX--->>>"
											+ dueAmount);
								}
						    }
						    if(CommonUtil.isNotNull(customerBill.getNextBillDate())){
						    	customerBill.getNextBillDate();
						    }
						    if(CommonUtil.isNotNull(customerBill.getPreviousBillDate())){
						    	customerBill.getPreviousBillDate();
						    }
						    
						    if (CommonUtil.isNotNull(customerBill.getBillRefResets())) {
								bulkDetails.setOrigBillRefResets(customerBill.getBillRefResets());
							}
						    
						    BillPeriod billPeriod = customerBill.getBillPeriod();
						    if (CommonUtil.isNotNull(billPeriod.getStartDate())) {
								billPeriod.getStartDate();
							}
							if (CommonUtil.isNotNull(billPeriod.getEndDate())) {
								billPeriod.getEndDate();
							}
							
							PartyPayment partyPayment =response.getCustomerPayment().getPartyPayment();
							
							if(partyPayment!=null){
								if (CommonUtil.isNotNull(partyPayment.getMode())) {
									bulkDetails.setPaymentMode(partyPayment.getMode());// PAYMENT
																						// MODE
									logger.info(
											"partyPayment.getMode() in createResponseJSONForPostCustAccountSummaryToFX-->>"
													+ partyPayment.getMode());
								}

								if (CommonUtil.isNotNull(partyPayment.getPaymentDate())) {
									partyPayment.getPaymentDate();
								}

								if (CommonUtil.isNotNull(
										response.getOperationStatusCode())) {
									response.getOperationStatusCode();
								}
							}
							
							if(response.getStatus()!= null){
								Status status =response.getStatus();
								if (CommonUtil.isNotNull(status.getStatusCode())) {
									String[] statusCodeArray = status.getStatusCode().split("-");
									statusCode = statusCodeArray[1] + "-" + statusCodeArray[2];
									logger.info("status code in createResponseJSONForPostCustAccountSummaryToFX-->>"
											+ statusCode);
								}
								if (CommonUtil.isNotNull(status.getStatusCode())
										|| CommonUtil.isNotNull(status.getStatusDescription())) {
									status_description = statusCode + ":" + status.getStatusDescription();
									logger.info(
											"status_description in createResponseJSONForPostCustAccountSummaryToFX--->>"
													+ status.getStatusDescription());

									logger.info(
											"statusCode after response in createResponseJSONForPostCustAccountSummaryToFX--->>"
													+ status.getStatusCode());
									//bulkDetails.setErrorMsg(status_description);
									errorCode="SUCCESS";
								}
							}
						    
						}
						
						
						
					 }
				 }
			 }
		 }
		 else if(responsePojo.getBody().getSoaFault()!=null){
			 
			 SoaFault fault =responsePojo.getBody().getSoaFault();
				String[] soaFaultCodeArray = fault.getSoaFaultCode().split("-");
				statusCode = soaFaultCodeArray[1] + "-" + soaFaultCodeArray[2];
				String fault_value = fault.getFaultDescription();
				if (fault_value.length() > 999)
					fault_value = fault_value.substring(0, 1000);

				status_description = statusCode + ":" + fault_value;
				status_description = status_description.replace("'", "");
				logger.info(
						"Status description is in createResponseJSONFor INT-632 when error response from webservice---> "
								+ status_description);
			 
				bulkDetails.setErrorMsg(status_description);
				errorCode ="FAIL";
		 }
		 bulkDetails.setErrorCode(errorCode);
			 
		}
		
		ClientDAO dao = new ClientDAOImpl();
		String statusCod =status_code=="200"?"SUCCESS":"FAILED";
		try {
			dao.insertFxLog(statusCod, null, clientURL, mapper.writeValueAsString(responsePojo), null, null, "INT-632", null, null, null, null);
		} catch (JsonProcessingException e) {
			logger.info("Error occur while insertIntoFX", e);
			e.printStackTrace();
		}
		return bulkDetails;
	}
    public static void main(String[] args) {
    	BulkDetails bulkDetail = new BulkDetails();
    	bulkDetail.setAcctEXTID("1272802547");
		try {
			BulkDetails bd =new GetCustomerAccountSummaryClientV5().postCustomerAccountSummaryToFX(bulkDetail, "false");
		System.out.println(bd.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
