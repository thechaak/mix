package com.airtel.acecad.client.dto;

import java.util.List;




public class DepositFindDto {
private String status;
private String depositFindStatus;
private List<DepositDetails> dataList;
private List<MultiAccountsDto> multiAccountsDtos;


public List<MultiAccountsDto> getMultiAccountsDtos() {
	return multiAccountsDtos;
}
public void setMultiAccountsDtos(List<MultiAccountsDto> multiAccountsDtos) {
	this.multiAccountsDtos = multiAccountsDtos;
}
private BulkDetails bulkData;
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public List<DepositDetails> getDataList() {
	return dataList;
}
public void setDataList(List<DepositDetails> dataList) {
	this.dataList = dataList;
}
public BulkDetails getBulkData() {
	return bulkData;
}
public void setBulkData(BulkDetails bulkData) {
	this.bulkData = bulkData;
}
public String getDepositFindStatus() {
	return depositFindStatus;
}
public void setDepositFindStatus(String depositFindStatus) {
	this.depositFindStatus = depositFindStatus;
}


	

}
