package com.airtel.acecad.client.json.billingPaymentManagerHomes;

public class ErrorResponse {

	
	private String message;

    private String isError;

    private String requestid;

    public String getMessage ()
    {
        return message;
    }

    public void setMessage (String message)
    {
        this.message = message;
    }

    public String getIsError ()
    {
        return isError;
    }

    public void setIsError (String isError)
    {
        this.isError = isError;
    }

    public String getRequestid ()
    {
        return requestid;
    }

    public void setRequestid (String requestid)
    {
        this.requestid = requestid;
    }

    @Override
    public String toString()
    {
        return "{\"message\" : \""+message+"\", \"isError\" : \""+isError+"\", \"requestid\" : \""+requestid+"\"}";
    }
}
