package com.airtel.acecad.client;

import java.util.Arrays;

import org.apache.commons.codec.binary.Base64;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.airtel.acecad.client.dto.BulkDetails;
import com.airtel.acecad.client.json.custAccountSummaryJson.BillPeriod;
import com.airtel.acecad.client.json.custAccountSummaryJson.CustCustomerAccount;
import com.airtel.acecad.client.json.custAccountSummaryJson.Customer;
import com.airtel.acecad.client.json.custAccountSummaryJson.CustomerAccount;
import com.airtel.acecad.client.json.custAccountSummaryJson.CustomerAccountRequestPojo;
import com.airtel.acecad.client.json.custAccountSummaryJson.CustomerAccountSummaryResponsePojo;
import com.airtel.acecad.client.json.custAccountSummaryJson.CustomerBill;
import com.airtel.acecad.client.json.custAccountSummaryJson.CustomerIdentification;
import com.airtel.acecad.client.json.custAccountSummaryJson.CustomerPayment;
import com.airtel.acecad.client.json.custAccountSummaryJson.DetailFault;
import com.airtel.acecad.client.json.custAccountSummaryJson.EbmHeader;
import com.airtel.acecad.client.json.custAccountSummaryJson.EbmHeader1;
import com.airtel.acecad.client.json.custAccountSummaryJson.Fault;
import com.airtel.acecad.client.json.custAccountSummaryJson.GetCustomerAccountSummary;
import com.airtel.acecad.client.json.custAccountSummaryJson.GetCustomerAccountSummaryFault;
import com.airtel.acecad.client.json.custAccountSummaryJson.GetCustomerAccountSummaryReqMsg;
import com.airtel.acecad.client.json.custAccountSummaryJson.GetCustomerAccountSummaryResMsg;
import com.airtel.acecad.client.json.custAccountSummaryJson.GetCustomerAccountSummaryResponse;
import com.airtel.acecad.client.json.custAccountSummaryJson.Identification;
import com.airtel.acecad.client.json.custAccountSummaryJson.LogicalResource;
import com.airtel.acecad.client.json.custAccountSummaryJson.LogicalResourceIdentification;
import com.airtel.acecad.client.json.custAccountSummaryJson.ParentAccount;
import com.airtel.acecad.client.json.custAccountSummaryJson.PartyBill;
import com.airtel.acecad.client.json.custAccountSummaryJson.PartyPayment;
import com.airtel.acecad.client.json.custAccountSummaryJson.RequestDataArea;
import com.airtel.acecad.client.json.custAccountSummaryJson.ResponseCustomer;
import com.airtel.acecad.client.json.custAccountSummaryJson.ResponseDataArea;
import com.airtel.acecad.client.json.custAccountSummaryJson.SoaFault;
import com.airtel.acecad.client.json.custAccountSummaryJson.Status;
import com.airtel.acecad.client.util.GenericConfiguration;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.CustomResponseErrorHandler;
import com.airtel.acecad.client.util.EncryDecrypUtility;
import com.airtel.acecad.client.util.GlobalConstants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/////////////////////////////INT_632///////////////////////////////////////////
public class CustAccountSummaryClient implements GlobalConstants {

	private static final Logger log = LogManager.getLogger("serviceClientUI");

	public BulkDetails createRequestJSONForPostCustAccountSummaryToFX(BulkDetails bulkDetails) throws Exception {

		log.info("START--->in createRequestJSONForPostCustAccountSummaryToFX method of CustAccountSummaryClient");

		CustAccountSummaryClient custAccountSummaryClient = new CustAccountSummaryClient();
		GetCustomerAccountSummaryReqMsg getCustomerAccountSummaryReqMsg = new GetCustomerAccountSummaryReqMsg();
		EbmHeader ebmHeader = new EbmHeader();
		// ebmHeader.setDomain("B2C");
		ebmHeader.setLob(LOB);// HARD CODE
		ebmHeader.setSubLob(SUBLOB);// HARD CODE
		String consumerTransactionId = APS + CommonUtil.randomMethod();
		log.info("consumerTransactionId in createRequestJSONForPostCustAccountSummaryToFX----->"
				+ consumerTransactionId);
		ebmHeader.setConsumerTransactionId(consumerTransactionId);
		ebmHeader.setCustomerMigrated(TRUE);

		getCustomerAccountSummaryReqMsg.setEbmHeader(ebmHeader);

		GetCustomerAccountSummary getCustomerAccountSummary = new GetCustomerAccountSummary();

		Customer customer = new Customer();
		CustomerIdentification customerIdentification = new CustomerIdentification();
		customer.setIdentification(customerIdentification);
		getCustomerAccountSummary.setCustomer(customer);

		// cutomerAccidentification.setId("393");//account Num
		if (CommonUtil.isNotNull(bulkDetails.getAcctEXTID())) {

			CustomerAccount customerAccount = new CustomerAccount();

			Identification cutomerAccidentification = new Identification();

			cutomerAccidentification.setId(bulkDetails.getAcctEXTID());// account
																		// Num
			cutomerAccidentification.setType(ACC_EXT_ID_TYPE);// HARD CODE FOR
																// ACCOUNT 1
			customerAccount.setIdentification(cutomerAccidentification);
			customer.setCustomerAccount(customerAccount);
		}
		
		RequestDataArea requestDataArea = new RequestDataArea();
		requestDataArea.setGetCustomerAccountSummary(getCustomerAccountSummary);

		LogicalResource logicalResource = new LogicalResource();

		if (CommonUtil.isNotNull(bulkDetails.getDelNO())) {
			if (!CommonUtil.isNotNull(bulkDetails.getAcctEXTID())) {
				LogicalResourceIdentification logicalResourceIdentification = new LogicalResourceIdentification();
				logicalResourceIdentification.setId(bulkDetails.getDelNO());
				logicalResourceIdentification.setType(MOBILE_NUM_TYPE);
				logicalResource.setType(MSISDN);

				logicalResource.setIdentification(logicalResourceIdentification);
				getCustomerAccountSummary.setLogicalResource(logicalResource);
			}

		}

		getCustomerAccountSummaryReqMsg.setDataArea(requestDataArea);

		CustomerAccountRequestPojo requestPojo = new CustomerAccountRequestPojo();
		requestPojo.setGetCustomerAccountSummaryReqMsg(getCustomerAccountSummaryReqMsg);

		log.info(getCustomerAccountSummaryReqMsg.toString());
		log.info("mypojo  createRequestJSONForPostCustAccountSummaryToFX--->>" + requestPojo + " and accountid---->>"
				+ bulkDetails.getAcctEXTID());

		BulkDetails bulkDetailsres = custAccountSummaryClient.postCustAccountSummaryToFX(requestPojo);

		log.info("END----in createRequestJSONForPostCustAccountSummaryToFX method of CustAccountSummaryClient and accountid---->>"
				+ bulkDetails.getAcctEXTID());
		return bulkDetailsres;

	}

	/*
	 * @author :- Geeta Rajput
	 */
	public BulkDetails postCustAccountSummaryToFX(CustomerAccountRequestPojo requestPojo) throws Exception  {

		GetCustomerAccountSummaryResMsg getCustomerAccountSummaryResMsg = null;
		Fault fault = null;
		String status_code = EMPTY_STRING;
		BulkDetails bulkDetailsres = new BulkDetails();

		String clientURL = GenericConfiguration.getDescription("kenon.postUpdateCustomerAccountSummaryToFX.url");
		RestTemplate restTemplate = new RestTemplate();


		//ADDED FOR HANDLING TIMEOUT ERRORS
		restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
		((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
		.setConnectTimeout(Integer.parseInt(GenericConfiguration.getDescription("connect_time_out")));// 60000=
         ((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
		.setReadTimeout(Integer.parseInt(GenericConfiguration.getDescription("read_time_out")));
		
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
		restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
		restTemplate.setErrorHandler(new CustomResponseErrorHandler());
		HttpHeaders headers = new HttpHeaders();
        
		//Added by Ritu (EncryptDecrypt Password)
		String userpass = GenericConfiguration.getDescription("kenon.postPaymentToFX.userName") + ":"
				+ EncryDecrypUtility.decrypt(GenericConfiguration.getDescription("kenon.postPaymentToFX.password"));
		log.info("clientURL postCustAccountSummaryToFX -->" + clientURL);
		headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		HttpEntity<CustomerAccountRequestPojo> entity = new HttpEntity<CustomerAccountRequestPojo>(requestPojo,
				headers);
		ResponseEntity<CustomerAccountSummaryResponsePojo> responsePojo = null;
		try {
			// Execute the httpMethod to given uri template,writing the
			// given request and returns the response as ResponseEntity
			responsePojo = restTemplate.exchange(clientURL, HttpMethod.POST, entity,
					CustomerAccountSummaryResponsePojo.class);
			log.info("responsePojo postCustAccountSummaryToFX---" + responsePojo);

			if (responsePojo != null) {
				if (HttpStatus.OK == responsePojo.getStatusCode()) {
					if (responsePojo.getBody().getGetCustomerAccountSummaryResMsg() != null) {
						getCustomerAccountSummaryResMsg = responsePojo.getBody().getGetCustomerAccountSummaryResMsg();
						log.info("success--postCustAccountSummaryToFX--->>"
								+ responsePojo.getBody().getGetCustomerAccountSummaryResMsg());

					} else {
						status_code = responsePojo.getStatusCode().toString();
						fault = responsePojo.getBody().getFault();
						log.info("faultResponsePojo postCustAccountSummaryToFX in http 200 ok-->>" + fault);
					}
				} else {
					status_code = responsePojo.getStatusCode().toString();
					fault = responsePojo.getBody().getFault();
					log.info("faultResponsePojo postCustAccountSummaryToFX-->>" + fault);
				}
				log.info("BEFORE createResponseJSONForPostCustAccountSummaryToFX  in postCustAccountSummaryToFX ");
				bulkDetailsres = createResponseJSONForPostCustAccountSummaryToFX(getCustomerAccountSummaryResMsg, fault,
						status_code);
				log.info("AFTER createResponseJSONForPostCustAccountSummaryToFX  in postCustAccountSummaryToFX ");
			} else {
				log.info("IN method  createResponseJSONForPostCustAccountSummaryToFX response pojo is null");
			}

		} catch (Exception e) {
			log.info("Got error in the response of FX  pTransactionId postCustAccountSummaryToFX-->"+bulkDetailsres.getRecordId(), e);
			bulkDetailsres.setErrorMsg(e.getMessage());
			bulkDetailsres.setErrorReasonCode(e.getMessage());
			bulkDetailsres.setErrorCode(e.getMessage());
			bulkDetailsres.setErrorCodeDescription(e.getMessage());
			if (e.getCause().toString().contains(CONNECT_TEXT)) {
				bulkDetailsres.setErrorMsg(CONNECT_TEXT);
				bulkDetailsres.setErrorReasonCode(CONNECT_TEXT);
				bulkDetailsres.setErrorCode(CONNECT_TEXT);
				bulkDetailsres.setErrorCodeDescription(CONNECT_TEXT);

				
			}

			if(e.getCause().toString().contains(READ_TEXT)){
				bulkDetailsres.setErrorMsg(READ_TEXT);
				bulkDetailsres.setErrorReasonCode(READ_TEXT);
				bulkDetailsres.setErrorCode(READ_TEXT);
				bulkDetailsres.setErrorCodeDescription(READ_TEXT);
				log.info("Got faulty code from the response READ_TEXT  of FX resultConectRead postCustAccountSummaryToFX-----> pTransactionId"+bulkDetailsres.getRecordId()+" "+READ_TEXT);
				
			}
		}

		log.info("END--->in postCustAccountSummaryToFX method of CustAccountSummaryClient");
		return bulkDetailsres;
	}

	/*
	 * @author :- Geeta Rajput-- Create Response Json for Nrc for failed payment
	 */
	public BulkDetails createResponseJSONForPostCustAccountSummaryToFX(
			GetCustomerAccountSummaryResMsg getCustomerAccountSummaryResMsg, Fault fault, String statusCodeWeb)
			throws Exception {

		log.info("START----in createResponseJSONForPostCustAccountSummaryToFX method of CustAccountSummaryClient");
		BulkDetails bulkDetails = new BulkDetails();
		String status_description = EMPTY_STRING;
		String dueAmount = EMPTY_STRING;
		String statusCode = EMPTY_STRING;

		if (getCustomerAccountSummaryResMsg != null) {
			log.info("In if loop when got success response from webservice --632 INT");
			EbmHeader1 ebmHeader1 = new EbmHeader1();
			ebmHeader1 = getCustomerAccountSummaryResMsg.getEbmHeader();
			if (ebmHeader1 != null) {
				ResponseDataArea responseDataArea = new ResponseDataArea();

				responseDataArea = getCustomerAccountSummaryResMsg.getDataArea();

				if (responseDataArea != null) {
					GetCustomerAccountSummaryResponse getCustomerAccountSummaryResponse = new GetCustomerAccountSummaryResponse();
					getCustomerAccountSummaryResponse = responseDataArea.getGetCustomerAccountSummaryResponse();
					if (getCustomerAccountSummaryResponse != null) {
						ResponseCustomer responseCustomer = new ResponseCustomer();
						responseCustomer = getCustomerAccountSummaryResponse.getCustomer();
						if (responseCustomer != null) {
							CustCustomerAccount custCustomerAccount = responseCustomer.getCustomerAccount();
							if (custCustomerAccount != null) {
								Identification[] identification = custCustomerAccount.getIdentification();
								if (identification.length > 0) {
									for (int i = 0; i < identification.length; i++) {
										Identification id = identification[i];

										String accountID = id.getId();
										String accountType = id.getType();
										// added as it can be queried on basis
										// of mobile num also in case of cheque
										// and others file by tanu
										if (accountType.toUpperCase().contains(BILLABLE)) {
											bulkDetails.setAcctEXTID(accountID);
											break;
										}

									}
								}
								if (CommonUtil.isNotNull(custCustomerAccount.getAccountType())) {
									bulkDetails.setAccountType(custCustomerAccount.getAccountType());
								}
								if (CommonUtil.isNotNull(custCustomerAccount.getAccountStatus())) {
									custCustomerAccount.getAccountStatus();
								}

								// custCustomerAccount.getActiveDate();
								ParentAccount parentAccount = new ParentAccount();
								parentAccount = custCustomerAccount.getParentAccount();
								if (parentAccount != null) {
									if (CommonUtil.isNotNull(parentAccount.getId())) {
										bulkDetails.setParentAccountNumber(parentAccount.getId());
									}
									if (CommonUtil.isNotNull(parentAccount.getType())) {
										parentAccount.getType();
									}
								
								}

								if (CommonUtil.isNotNull(custCustomerAccount.getCostCenter())) {
									bulkDetails.setLegalEntity(custCustomerAccount.getCostCenter());// LEGAL
									// ENTITY
									log.info("custCustomerAccount.getCostCenter() LEGAL ENTITY-"
											+ custCustomerAccount.getCostCenter());
								}

								if (CommonUtil.isNotNull(custCustomerAccount.getCurrencyCode())) {
									custCustomerAccount.getCurrencyCode();
								}
								if (CommonUtil.isNotNull(custCustomerAccount.getRevRecCostCenter())) {
									custCustomerAccount.getRevRecCostCenter();
								}
								if (CommonUtil.isNotNull(custCustomerAccount.getCategory())) {
									custCustomerAccount.getCategory();
								}
								if (CommonUtil.isNotNull(custCustomerAccount.getActiveDate())) {
									custCustomerAccount.getActiveDate();
								}
								if (CommonUtil.isNotNull(custCustomerAccount.getInactiveDate())) {
									custCustomerAccount.getInactiveDate();
								}
								if (CommonUtil.isNotNull(custCustomerAccount.getMarketCode())) {

									bulkDetails.setMktCode(custCustomerAccount.getMarketCode());
								}
								if (CommonUtil.isNotNull(responseCustomer.getCustomerClass())) {
									responseCustomer.getCustomerClass();
								}
								if (CommonUtil.isNotNull(responseCustomer.getCustomerType())) {
									if (responseCustomer.getCustomerType().equalsIgnoreCase("2")) {
										bulkDetails.setB2b2c("B2C");
									} else if (responseCustomer.getCustomerType().equalsIgnoreCase("1")) {
										bulkDetails.setB2b2c("B2B");
									}

								}
								if (CommonUtil.isNotNull(responseCustomer.getVIPFlag())) {
									responseCustomer.getVIPFlag();
								}

								LogicalResource logicalResource = new LogicalResource();
								logicalResource = getCustomerAccountSummaryResponse.getLogicalResource();
								if (logicalResource != null) {
									LogicalResourceIdentification logicalResourceIdentification = new LogicalResourceIdentification();
									logicalResourceIdentification = logicalResource.getIdentification();
									if (logicalResourceIdentification != null)
										if (CommonUtil.isNotNull(logicalResourceIdentification.getId())) {
											logicalResourceIdentification.getId();
										}
									if (CommonUtil.isNotNull(logicalResource.getType())) {
										logicalResource.getType();
									}
								}
								/* NOT REQUIRED AS OF NOW */
								/*
								 * Service service =
								 * getCustomerAccountSummaryResponse.getService(
								 * ); if (CommonUtil.isNotNull(service.
								 * getActivationDate())) {
								 * service.getActivationDate(); } if
								 * (CommonUtil.isNotNull(service.getInactiveDate
								 * ())) { service.getInactiveDate(); }
								 * 
								 * Individual individual =
								 * getCustomerAccountSummaryResponse.
								 * getIndividual(); IndividualName
								 * individualName =
								 * individual.getIndividualName(); if
								 * (CommonUtil.isNotNull(individualName.
								 * getGivenName())) {
								 * individualName.getGivenName(); } if
								 * (CommonUtil.isNotNull(individualName.
								 * getFamilyNames())) {
								 * individualName.getFamilyNames(); }
								 * 
								 * PartyAccount partyAccount =
								 * getCustomerAccountSummaryResponse.
								 * getPartyAccount(); PartyAccountIdentification
								 * partyAccountIdentification = partyAccount
								 * .getIdentification(); if
								 * (CommonUtil.isNotNull(
								 * partyAccountIdentification.getId())) {
								 * partyAccountIdentification.getId(); } if
								 * (CommonUtil.isNotNull(partyAccount.
								 * getAccountCategory())) {
								 * partyAccount.getAccountCategory(); }
								 */
								CustomerPayment customerPayment = getCustomerAccountSummaryResponse
										.getCustomerPayment();

								////// Uncomment BY Geeta///////

								CustomerBill customerBill = customerPayment.getCustomerBill();
								PartyBill partyBill = customerBill.getPartyBill();
								if (CommonUtil.isNotNull(partyBill.getBillNo())) {
									partyBill.getBillNo();
								}
								if (CommonUtil.isNotNull(partyBill.getBillAmount())) {
									String amount = partyBill.getBillAmount();
									log.info("billamount in createResponseJSONForPostCustAccountSummaryToFX--->>>"
											+ amount);
								}
								if (CommonUtil.isNotNull(partyBill.getDueAmount())) {
									dueAmount = partyBill.getDueAmount();
									bulkDetails.setFxOutstandingAmount(partyBill.getDueAmount());
									System.out.println(bulkDetails.getFxOutstandingAmount());
									log.info("dueAmount in createResponseJSONForPostCustAccountSummaryToFX--->>>"
											+ dueAmount);
								}

								if (CommonUtil.isNotNull(customerBill.getNextBillDate())) {
									customerBill.getNextBillDate();
								}
								if (CommonUtil.isNotNull(customerBill.getPreviousBillDate())) {
									customerBill.getPreviousBillDate();
								}
								if (CommonUtil.isNotNull(customerBill.getBillRefResets())) {
									customerBill.getBillRefResets();
								}

								BillPeriod billPeriod = customerBill.getBillPeriod();
								if (CommonUtil.isNotNull(billPeriod.getStartDate())) {
									billPeriod.getStartDate();
								}
								if (CommonUtil.isNotNull(billPeriod.getEndDate())) {
									billPeriod.getEndDate();
								}

								/////////// End ////////////

								if (customerPayment != null) {
									PartyPayment partyPayment = customerPayment.getPartyPayment();
									if (partyPayment != null) {
										if (CommonUtil.isNotNull(partyPayment.getMode())) {
											bulkDetails.setPaymentMode(partyPayment.getMode());// PAYMENT
																								// MODE
											log.info(
													"partyPayment.getMode() in createResponseJSONForPostCustAccountSummaryToFX-->>"
															+ partyPayment.getMode());
										}

										// partyPayment.getMode();// PAYMENT
										// MODE
										if (CommonUtil.isNotNull(partyPayment.getPaymentDate())) {
											partyPayment.getPaymentDate();
										}

										if (CommonUtil.isNotNull(
												getCustomerAccountSummaryResponse.getOperationStatusCode())) {
											getCustomerAccountSummaryResponse.getOperationStatusCode();
										}
									}

								}

								Status status = getCustomerAccountSummaryResponse.getStatus();
								if (status != null) {

									if (CommonUtil.isNotNull(status.getStatusCode())) {
										String[] statusCodeArray = status.getStatusCode().split("-");
										statusCode = statusCodeArray[1] + "-" + statusCodeArray[2];
										log.info("status code in createResponseJSONForPostCustAccountSummaryToFX-->>"
												+ statusCode);
									}
									if (CommonUtil.isNotNull(status.getStatusCode())
											|| CommonUtil.isNotNull(status.getStatusDescription())) {
										status_description = statusCode + ":" + status.getStatusDescription();
										log.info(
												"status_description in createResponseJSONForPostCustAccountSummaryToFX--->>"
														+ status.getStatusDescription());

										log.info(
												"statusCode after response in createResponseJSONForPostCustAccountSummaryToFX--->>"
														+ status.getStatusCode());
									}

								}

								CustomerAccountSummaryResponsePojo customerAccountSummaryResponsePojo = new CustomerAccountSummaryResponsePojo();

								getCustomerAccountSummaryResMsg = customerAccountSummaryResponsePojo
										.getGetCustomerAccountSummaryResMsg();
							}

						}

					}

				}

			}

		} else if (fault != null) {
			log.info("In else loop when got error response from webservice --632 InT");
			if (statusCodeWeb.contains(status_code_504) || statusCodeWeb.contains(status_code_500)) {
				//status_description = fault.getFaultstring();
				String fault_value=fault.getFaultstring();
				if(fault_value.length()>999){
					fault_value=fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description= status_description.replace("'", "");
				bulkDetails.setErrorMsg(status_description);
				log.info("Status description is in createResponseJSONForPostCustAccountSummaryToFX--->> "
						+ status_description);
			} else if (statusCodeWeb.contains(status_code_502)) {
				//status_description = fault.getFaultstring();
				String fault_value=fault.getFaultstring();
				if(fault_value.length()>999){
					fault_value=fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description= status_description.replace("'", "");
				bulkDetails.setErrorMsg(status_description);
				log.info("Status description is in createResponseJSONForPostCustAccountSummaryToFX--->> "
						+ status_description);
			} else if (statusCode.contains(status_code_400)) {
				//status_description = fault.getFaultstring();
				String fault_value=fault.getFaultstring();
				if(fault_value.length()>999){
					fault_value=fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description= status_description.replace("'", "");
				log.info("Status description is in createResponseJSONForPostCustAccountSummaryToFX---> "
						+ status_description);
			} else {
				DetailFault detail = fault.getDetail();
				if (detail != null) {
					GetCustomerAccountSummaryFault getCustomerAccountSummaryFault = detail
							.getGetCustomerAccountSummaryFault();
					if (getCustomerAccountSummaryFault != null) {
						SoaFault soaFault = getCustomerAccountSummaryFault.getSoaFault();
						if (soaFault != null) {

							if (CommonUtil.isNotNull(soaFault.getSoaFaultCode())) {
								String[] soaFaultCodeArray = soaFault.getSoaFaultCode().split("-");
								statusCode = soaFaultCodeArray[1] + "-" + soaFaultCodeArray[2];
								log.info(
										"soa fault status code in createResponseJSONForPostCustAccountSummaryToFX----->>"
												+ statusCode);
							}

							if (CommonUtil.isNotNull(soaFault.getFaultDescription())) {
								//status_description = statusCode + ":" + soaFault.getFaultDescription();
								String fault_value=soaFault.getFaultDescription();
								if(fault_value.length()>999){
									fault_value=fault_value.substring(0, 1000);
								}
								status_description = statusCode + ":" + fault_value;
								status_description= status_description.replace("'", "");
								bulkDetails.setErrorMsg(status_description);
								log.info(
										"fault_status_description in createResponseJSONForPostCustAccountSummaryToFX----->>"
												+ status_description);
							}
						}
					}

				}

			}

			log.info("faultDescription createResponseJSONForPostCustAccountSummaryToFX-----> " + status_description);
		} else {
			log.info("WHEN CAUGHT NOTHING FROM RESPONSE");
		}

		log.info("END----in createResponseJSONForPostCustAccountSummaryToFX method of CustAccountSummaryClient");
		return bulkDetails;

	}

	
	/* public static void main(String[] args) throws Exception 
	 { 
		 CustAccountSummaryClient custAccountSummaryClient=new CustAccountSummaryClient();
		 BulkDetails bulkDetails = new BulkDetails();
		 bulkDetails.setAcctEXTID("106");
	  custAccountSummaryClient.createRequestJSONForPostCustAccountSummaryToFX(bulkDetails); 
	  }*/
	 
}
