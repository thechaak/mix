package com.airtel.acecad.client.json.adjustmentJson;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class Status{
    private String statusCode;

    private String statusDescription;

    public String getStatusCode ()
    {
        return statusCode;
    }

    public void setStatusCode (String statusCode)
    {
        this.statusCode = statusCode;
    }

    public String getStatusDescription ()
    {
        return statusDescription;
    }

    public void setStatusDescription (String statusDescription)
    {
        this.statusDescription = statusDescription;
    }

    @Override
    public String toString()
    {
        return "{\"statusCode\":\""+statusCode+"\", \"statusDescription\":\""+statusDescription+"\"}";
    }
}