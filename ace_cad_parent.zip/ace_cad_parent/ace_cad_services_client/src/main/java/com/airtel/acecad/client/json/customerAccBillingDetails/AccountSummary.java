package com.airtel.acecad.client.json.customerAccBillingDetails;

public class AccountSummary {
	private Customer customer;

    public Customer getCustomer ()
    {
        return customer;
    }

    public void setCustomer (Customer customer)
    {
        this.customer = customer;
    }

	@Override
	public String toString() {
		return "AccountSummary [customer=" + customer + "]";
	}

    
}
