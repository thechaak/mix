package com.airtel.acecad.client.json.custAccountSummaryJson;

public class CustomerAccountRequestPojo {

	 private GetCustomerAccountSummaryReqMsg getCustomerAccountSummaryReqMsg;

	    public GetCustomerAccountSummaryReqMsg getGetCustomerAccountSummaryReqMsg ()
	    {
	        return getCustomerAccountSummaryReqMsg;
	    }

	    public void setGetCustomerAccountSummaryReqMsg (GetCustomerAccountSummaryReqMsg getCustomerAccountSummaryReqMsg)
	    {
	        this.getCustomerAccountSummaryReqMsg = getCustomerAccountSummaryReqMsg;
	    }

	    @Override
	    public String toString()
	    {
	        return "{\"getCustomerAccountSummaryReqMsg\" : "+getCustomerAccountSummaryReqMsg+"}";
	    }
}
