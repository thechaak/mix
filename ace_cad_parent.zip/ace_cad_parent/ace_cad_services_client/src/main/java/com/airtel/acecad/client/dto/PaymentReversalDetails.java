package com.airtel.acecad.client.dto;

public class PaymentReversalDetails {

	String acctExtId;
	String srNumber;
	String origTrackingId;
	String OrigTrackingIdServ;
	String annotation;
	String paymentCode;
	String transactionId;
	String userId;
	int noOfHits;
	private String lobType;
	private String apsFlag;
	private String b2b2c;
	
	public String getB2b2c() {
		return b2b2c;
	}
	public void setB2b2c(String b2b2c) {
		this.b2b2c = b2b2c;
	}
	public String getAcctExtId() {
		return acctExtId;
	}
	public void setAcctExtId(String acctExtId) {
		this.acctExtId = acctExtId;
	}
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getOrigTrackingId() {
		return origTrackingId;
	}
	public void setOrigTrackingId(String origTrackingId) {
		this.origTrackingId = origTrackingId;
	}
	public String getOrigTrackingIdServ() {
		return OrigTrackingIdServ;
	}
	public void setOrigTrackingIdServ(String origTrackingIdServ) {
		OrigTrackingIdServ = origTrackingIdServ;
	}
	public String getAnnotation() {
		return annotation;
	}
	public void setAnnotation(String annotation) {
		this.annotation = annotation;
	}
	public String getPaymentCode() {
		return paymentCode;
	}
	public void setPaymentCode(String paymentCode) {
		this.paymentCode = paymentCode;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getNoOfHits() {
		return noOfHits;
	}
	public void setNoOfHits(int noOfHits) {
		this.noOfHits = noOfHits;
	}
	public String getLobType() {
		return lobType;
	}
	public void setLobType(String lobType) {
		this.lobType = lobType;
	}
	public String getApsFlag() {
		return apsFlag;
	}
	public void setApsFlag(String apsFlag) {
		this.apsFlag = apsFlag;
	}
	
}
