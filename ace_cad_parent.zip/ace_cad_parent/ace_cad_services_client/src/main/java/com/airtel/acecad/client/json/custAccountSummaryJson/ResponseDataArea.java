package com.airtel.acecad.client.json.custAccountSummaryJson;

public class ResponseDataArea {

	private GetCustomerAccountSummaryResponse getCustomerAccountSummaryResponse;

    public GetCustomerAccountSummaryResponse getGetCustomerAccountSummaryResponse ()
    {
        return getCustomerAccountSummaryResponse;
    }

    public void setGetCustomerAccountSummaryResponse (GetCustomerAccountSummaryResponse getCustomerAccountSummaryResponse)
    {
        this.getCustomerAccountSummaryResponse = getCustomerAccountSummaryResponse;
    }

    @Override
    public String toString()
    {
        return "{\"getCustomerAccountSummaryResponse\" : "+getCustomerAccountSummaryResponse+"}";
    }
}
