package com.airtel.acecad.client;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.airtel.acecad.client.dao.ClientDAO;
import com.airtel.acecad.client.dao.ClientDAOImpl;
import com.airtel.acecad.client.dto.BulkDetails;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.Address;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.BillPeriod;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.Contact;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.Customer;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.CustomerAccount;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.CustomerAccountSummaryResponse;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.CustomerBill;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.DataArea;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.EbmHeader;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.GetCustomerAccountSummaryResponse;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.Identification;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.IdentificationById;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.IndividualName;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.LogicalResource;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.ParentAccount;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.PartyAccount;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.PartyBill;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.PartyPayment;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.SoaFault;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.Status;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.TelephoneNumber;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.CommonValidator;
import com.airtel.acecad.client.util.CustomResponseErrorHandler;
import com.airtel.acecad.client.util.EncryDecrypUtility;
import com.airtel.acecad.client.util.GenericConfiguration;
import com.airtel.acecad.client.util.GlobalConstants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CustomerAccountSummaryClient implements GlobalConstants {

	private static final Logger logger = LogManager.getLogger("serviceClientUI");
	private static final ObjectMapper mapper = new ObjectMapper();
	public BulkDetails postCustomerAccountSummaryToFX(BulkDetails bulkDetails,String customerMigratedFlag,String lob) throws Exception {

		logger.info("Start :postCustomerAccountSummaryToFX in CustomerAccountSummaryClient");
		String result = EMPTY_STRING;
		String status_code = EMPTY_STRING;
		BulkDetails bulkDetailsres = new BulkDetails();
		SoaFault soaFault = null;
		RestTemplate restTemplate = new RestTemplate();
		//String lob ="Mobility";
		String clientURL="";
		if(lob==null && !CommonValidator.isNull(bulkDetails.getLob())){
			lob =bulkDetails.getLob();
		}
		if(lob==null || CommonValidator.isNull(bulkDetails.getLob())){
			lob ="Mobility";
		}

		try {
			String userpass = GenericConfiguration.getDescription("kenon.postPaymentToFX.userName") + ":"
					+ EncryDecrypUtility.decrypt(GenericConfiguration.getDescription("kenon.postPaymentToFX.password"));

			if(bulkDetails.getAcctEXTID()!=null && !bulkDetails.getAcctEXTID().equals("")&& !bulkDetails.getAcctEXTID().equals("0")){
				clientURL = GenericConfiguration.getDescription("kenon.postUpdateRefundCustomerAccountSummaryToFXV5.url")+
						"domain=B2C&lob="+lob+"&subLob=Postpaid&consumerTransactionId=11343&consumerName=APS"+
						"&programmeName=EAIMigration&customerMigrated="+customerMigratedFlag+"&accountId="+bulkDetails.getAcctEXTID()+"&accountType=1&flag=&MSISDN=&type=MSISDN&serviceType=11";
			}
			else if(bulkDetails.getDelNO()!=null && !bulkDetails.getDelNO().equals("") )
			{
				clientURL = GenericConfiguration.getDescription("kenon.postUpdateRefundCustomerAccountSummaryToFXV5.url")+
						"domain=B2C&lob="+lob+"&subLob=Postpaid&consumerTransactionId=11343&consumerName=APS"+
						"&programmeName=EAIMigration&customerMigrated="+customerMigratedFlag+"&accountId=&accountType=1&flag=&MSISDN="+bulkDetails.getDelNO()+"&type=MSISDN&serviceType=11";

			}
			//+ customerMigratedFlag+  GenericConfiguration.getDescription("accountId") + bulkDetails.getAcctEXTID();

			restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
			HttpHeaders headers = new HttpHeaders();
			logger.info("client url in postCustomerAccountSummaryToFX-->>>"+clientURL);
			logger.info("client userpass --->"+userpass);
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
			.setConnectTimeout(Integer.parseInt(GenericConfiguration.getDescription("connect_time_out")));

			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
			.setReadTimeout(Integer.parseInt(GenericConfiguration.getDescription("read_time_out")));

			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
			restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
			restTemplate.setErrorHandler(new CustomResponseErrorHandler());

			
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));

			HttpEntity<String> entity = new HttpEntity<>(headers);
			ResponseEntity<CustomerAccountSummaryResponse> responsePojo = null;
			responsePojo = restTemplate.exchange(clientURL, HttpMethod.GET, entity, CustomerAccountSummaryResponse.class);
			logger.info("responsePojo INT-632 CustomerAccountSummary---" + mapper.writeValueAsString(responsePojo));


			logger.info("responsePojo--->>" + responsePojo.getBody());

			logger.info("responsePojo postCustomerAccountSummaryToFX--->" + mapper.writeValueAsString(responsePojo));

			if (responsePojo != null) {
				if (HttpStatus.OK == responsePojo.getStatusCode()) {
					if (responsePojo.getBody().getEbmHeader() != null && responsePojo.getBody().getDataArea() != null) {
						status_code = responsePojo.getStatusCode().toString();
						logger.info("success--postCustomerAccountSummaryToFX--->>" + responsePojo.getBody());

					} else {
						status_code = responsePojo.getStatusCode().toString();
						soaFault = responsePojo.getBody().getSoaFault();
						logger.info("faultResponsePojo postCustomerAccountSummaryToFX -->>"
								+ responsePojo.getBody().getSoaFault());
					}
				}

				else {
					status_code = responsePojo.getStatusCode().toString();
					soaFault = responsePojo.getBody().getSoaFault();
					logger.info("faultResponsePojo postCustomerAccountSummaryToFX -->>"
							+ responsePojo.getBody().getSoaFault());
					// log.info("faultResponsePojo
					// postCustomerAccountSummaryToFX-->>" + fault);
				}
				logger.info("BEFORE createResponseJSONForPostCustAccountSummaryToFX  in postCustAccountSummaryToFX INT-632");
				bulkDetailsres = createResponseJSONForPostCustAccountSummaryToFX(responsePojo, status_code, soaFault,clientURL,customerMigratedFlag);
				logger.info("AFTER createResponseJSONForPostCustAccountSummaryToFX  in postCustAccountSummaryToFX ");
			} 

		} catch (Exception e) {
			logger.info("Got error in the response of FX  pTransactionId postCustomerAccountSummaryToFX-->"
					+ bulkDetailsres.getRecordId(), e);
			bulkDetailsres.setErrorMsg(e.getMessage());
			bulkDetailsres.setErrorReasonCode(e.getMessage());
			bulkDetailsres.setErrorCode(e.getMessage());
			bulkDetailsres.setErrorCodeDescription(e.getMessage());
			if (e.getCause().toString().contains(CONNECT_TEXT)) {
				bulkDetailsres.setErrorMsg(CONNECT_TEXT);
				bulkDetailsres.setErrorReasonCode(CONNECT_TEXT);
				bulkDetailsres.setErrorCode(CONNECT_TEXT);
				bulkDetailsres.setErrorCodeDescription(CONNECT_TEXT);

			}

			if (e.getCause().toString().contains(READ_TEXT)) {
				bulkDetailsres.setErrorMsg(READ_TEXT);
				bulkDetailsres.setErrorReasonCode(READ_TEXT);
				bulkDetailsres.setErrorCode(READ_TEXT);
				bulkDetailsres.setErrorCodeDescription(READ_TEXT);
				logger.info(
						"Got faulty code from the response READ_TEXT  of FX resultConectRead postCustomerAccountSummaryToFX-----> pTransactionId"
								+ bulkDetailsres.getRecordId() + " " + READ_TEXT);

			}
		}

		logger.info("END--->in postCustomerAccountSummaryToFX method of CustAccountSummaryClient");
		return bulkDetailsres;
	}
	public BulkDetails createResponseJSONForPostCustAccountSummaryToFX(
			ResponseEntity<CustomerAccountSummaryResponse> responsePojo, String status_code, SoaFault soaFault,
			String clientURL,String customerMigratedFlag) {

		logger.info("START----in createResponseJSONForPostCustAccountSummaryToFX method of CustAccountSummaryClient");
		BulkDetails bulkDetails = new BulkDetails();
		String status_description = EMPTY_STRING;
		String dueAmount = EMPTY_STRING;
		String statusCode = EMPTY_STRING;
		String errorCode="";
		ClientDAO dao = new ClientDAOImpl();
		if(responsePojo !=null){
			if(responsePojo.getBody().getEbmHeader()!=null)	{
				EbmHeader ebmHeader = responsePojo.getBody().getEbmHeader();
				if(ebmHeader!=null){
					if(CommonUtil.isNotNull(ebmHeader.getLob())){
						if("Telemedia".equalsIgnoreCase(ebmHeader.getLob())){
							bulkDetails.setLob("BTS");
						}else if("Mobility".equalsIgnoreCase(ebmHeader.getLob())){
							bulkDetails.setLob("MOB");
						}else{
							bulkDetails.setLob(ebmHeader.getLob());
						}
					}
				}
				if(responsePojo.getBody().getDataArea()!=null){
					DataArea dataArea = responsePojo.getBody().getDataArea();
					if(dataArea.getGetCustomerAccountSummaryResponse()!=null){
						GetCustomerAccountSummaryResponse response = dataArea.getGetCustomerAccountSummaryResponse();
						Customer customer =response.getCustomer();
						if(customer!=null){
							List<CustomerAccount> customerAccList = customer.getCustomerAccount();
							if(customerAccList != null && customerAccList.size()>0){
								for(CustomerAccount custAcc :customerAccList){
									List<Identification> identificationList = custAcc.getIdentification();
									if(identificationList!= null && identificationList.size()>0){
										for(Identification identification :identificationList){
											String id= identification.getId();
											String type = identification.getType();
											if(type != null && type.equals("AccountExternalId")){
												logger.info("AccountExternalId from INT_632------------------>>>>>"+id);	
												bulkDetails.setAcctEXTID(id);
												//break;
											}
											if(type != null && type.equalsIgnoreCase("AccountInternalId")){
												logger.info("AccountInternalId from INT_632------------------>>>>>"+id);	
												bulkDetails.setAccountInternalid(id);
												//break;
											}
											
											//20-May-2019(Changed asked by vikram on Prod)
											if(type!=null && type.equalsIgnoreCase("BillableAccountExternalId")){
												logger.info("BillableAccountExternalId from INT_632------------------>>>>>"+id);
												//bulkDetails.setInternalAccountNo(id);
												//if("0".equalsIgnoreCase(custAcc.getAccountType()) && "false".equalsIgnoreCase(customerMigratedFlag))
													bulkDetails.setParentAccountNumber(id);
												
												//break;
											}
										}
									}

									if (CommonUtil.isNotNull(custAcc.getAccountType())) {
										bulkDetails.setAccountType(custAcc.getAccountType());
									}
									if (CommonUtil.isNotNull(custAcc.getAccountStatus())) {
										custAcc.getAccountStatus();
										bulkDetails.setAccountStatus(custAcc.getAccountStatus());
									}

									if(custAcc.getParentAccount()!=null){
										List<ParentAccount> parentAccList = custAcc.getParentAccount();
										if(parentAccList != null && parentAccList.size()>0){
											for(ParentAccount parentAcc : parentAccList){
												if(parentAcc!=null){
													if (CommonUtil.isNotNull(parentAcc.getId())) {
														
														logger.info("custAcc.getAccountType() from INT_632------------------>>>>>"+custAcc.getAccountType()+" and customerMigratedFlag-->"+customerMigratedFlag);
														/*if("1".equalsIgnoreCase(custAcc.getAccountType()) && "false".equalsIgnoreCase(customerMigratedFlag))
															bulkDetails.setParentAccountNumber(null);
														else
														bulkDetails.setParentAccountNumber(parentAcc.getId());*/
														
														if(!CommonUtil.isNotNull(bulkDetails.getParentAccountNumber()))
															bulkDetails.setParentAccountNumber(parentAcc.getId());
															
													}
													if (CommonUtil.isNotNull(parentAcc.getType())) {
														parentAcc.getType();
													}
												}
											}
										}
									}


									if(CommonUtil.isNotNull(custAcc.getProductLevel())){
										bulkDetails.setProductType(custAcc.getProductLevel());
										logger.info("custAcc.getProductLevel() LEGAL ENTITY-"+ custAcc.getProductLevel());

									}
									if(CommonUtil.isNotNull(custAcc.getCostCenter())){
										bulkDetails.setLegalEntity(custAcc.getCostCenter());
										logger.info("custCustomerAccount.getCostCenter() LEGAL ENTITY-"	+ custAcc.getCostCenter());
									}
									if(CommonUtil.isNotNull(custAcc.getRevRecCostCenter())){
										logger.info("custAcc.getRevRecCostCenter()-"+ custAcc.getRevRecCostCenter());
									}
									if(CommonUtil.isNotNull(custAcc.getRevRecCostCenter())){
										logger.info("custAcc.getRevRecCostCenter() -"+ custAcc.getRevRecCostCenter());
									}
									if(CommonUtil.isNotNull(custAcc.getCurrencyCode())){
										logger.info("payment Currency-"+ custAcc.getCurrencyCode());
										bulkDetails.setPaymentCurrency(custAcc.getCurrencyCode());
									}
									
									if (CommonUtil.isNotNull(custAcc.getCategory())) {
										if("Telemedia".equalsIgnoreCase(ebmHeader.getLob()) || "Mobility".equalsIgnoreCase(ebmHeader.getLob())){
										if (custAcc.getCategory().equalsIgnoreCase("0")) {
											bulkDetails.setB2b2c("B2C");
										} else if (custAcc.getCategory().equalsIgnoreCase("1")) {
											bulkDetails.setB2b2c("B2B");
										}}
										else
										{
											bulkDetails.setB2b2c("B2B");
										}
										
										logger.info("custAcc.getCategory()-"+ custAcc.getCategory());
									
									}
									else{
										bulkDetails.setB2b2c("B2B");
									}
										

									if(CommonUtil.isNotNull(custAcc.getLinkAccountFlag())){
										logger.info("custAcc.getLinkAccountFlag() LEGAL ENTITY-"+ custAcc.getLinkAccountFlag());
									}

									if(CommonUtil.isNotNull(custAcc.getSegment())){
										logger.info("custAcc.getSegment() --"+ custAcc.getSegment());
									}

									if(CommonUtil.isNotNull(custAcc.getActiveDate())){
										logger.info("custAcc.getActiveDate() --"+ custAcc.getActiveDate());
										bulkDetails.setActiveDate(custAcc.getActiveDate());
									}

									if(CommonUtil.isNotNull(custAcc.getInactiveDate())){
										logger.info("custAcc.getInactiveDate() --"+ custAcc.getInactiveDate());
										bulkDetails.setAccountInactiveDate(custAcc.getInactiveDate());
									}
									if(CommonUtil.isNotNull(custAcc.getMarketCode())){
										logger.info("custAcc.getMarketCode() --"+ custAcc.getMarketCode());
										bulkDetails.setMktCode(custAcc.getMarketCode());
									}

									if(CommonUtil.isNotNull(custAcc.getActivationDate())){
										logger.info("custAcc.getActivationDate() LEGAL ENTITY-"+ custAcc.getActivationDate());
										bulkDetails.setAccActivationDate(custAcc.getActivationDate());
									}

									if(CommonUtil.isNotNull(custAcc.getBillableFlag())){
										logger.info("custAcc.getBillableFlag() --"+ custAcc.getBillableFlag());
									}

								}

							}


							if(CommonUtil.isNotNull(customer.getCustomerClass())){
								bulkDetails.setCustomerClass(customer.getCustomerClass());
							}

							if(CommonUtil.isNotNull(customer.getCustomerType())){
								bulkDetails.setCustomerType(customer.getCustomerType());
							}

							if(!CommonUtil.isNotNull(ebmHeader.getLob()))
								if(CommonUtil.isNotNull(customer.getLoginId())){
									logger.info("customer.server id -"+ customer.getLoginId());
									bulkDetails.setLob(dao.getLobFromServerId(customer.getLoginId()));
									logger.info("customer.lob from server id -"+ bulkDetails.getLob());

								}
							if(CommonUtil.isNotNull(customer.getVIPFlag())){
								bulkDetails.setVipFlag(customer.getVIPFlag());
							}

							if(CommonUtil.isNotNull(customer.getOrganizationType())){
								logger.info("customer.getOrganizationType() -"+ customer.getOrganizationType());
							}
							if(CommonUtil.isNotNull(customer.getRiskSegment())){
								logger.info("customer.getRiskSegment() -"+ customer.getRiskSegment());
							}

							if(customer.getEmail()!=null){
								if(CommonUtil.isNotNull(customer.getEmail().getEMailAddress())){
									logger.info("customer.getEmail().getEMailAddress() -"+ customer.getEmail().getEMailAddress());
									bulkDetails.setEmailId( customer.getEmail().getEMailAddress());
								}
							}

							if(response.getIndividual()!=null){
								if(response.getIndividual().getIndividualName()!=null){
									IndividualName individualName =response.getIndividual().getIndividualName();
									if(CommonUtil.isNotNull(individualName.getGivenName())) 
									{
										individualName.getGivenName();
										logger.info("Given Name=="+ individualName.getGivenName());
										System.out.println(" Name=="+ individualName.getFamilyNames());
										bulkDetails.setGivenName(individualName.getGivenName());
									} 
									if(CommonUtil.isNotNull(individualName.getFamilyNames())) 
									{
										individualName.getFamilyNames();
										System.out.println("FamilyNames Name=="+ individualName.getFamilyNames());
										logger.info("FamilyNames Name=="+ individualName.getFamilyNames());
										bulkDetails.setFamilyName(individualName.getFamilyNames());
									}
								}

								if(response.getIndividual().getContact()!=null){
									List<Contact> contactList = response.getIndividual().getContact();
									if(contactList!= null && contactList.size()>0 && contactList.isEmpty()){
										for(Contact contact : contactList){
											if(contact!=null){
											List<TelephoneNumber> telephoneList = contact.getTelephoneNumber();
											if(telephoneList!=null && telephoneList.size()>0){
												for(TelephoneNumber telephone : telephoneList){
													if (telephone.getType().contains("PrimaryContact")) {
														bulkDetails.setPrimaryContactNumber(telephone.getNumber());
														logger.info("PrimaryContact from INT_632------------------>>>>>"+telephone.getNumber());
													}
													if (telephone.getType().contains("AlternateContact")) {
														logger.info("AlternateContact from INT_632------------------>>>>>"+telephone.getNumber());
														bulkDetails.setAlternateContactNumber(telephone.getNumber());
													}
												}
											}
										  }
										}
									}
								}
							}

							if(customer.getAddress()!=null){
								List<Address> addressList = customer.getAddress();
								for(Address address : addressList){
									if(address.getAddressType() !=null && address.getAddressType()!= "" && address.getAddressType().equalsIgnoreCase("BillingAddress")){

										String addr =address.getAddressLine1()+" "+address.getAddressLine2()+" "+address.getAddressLine2()+" "+address.getCity();
										bulkDetails.setFullAddress(addr);

										bulkDetails.setState(address.getState());
										bulkDetails.setZipCode(address.getPincode());
										logger.info("Address in Customer account summary from INT_632-->>"+addr+" and state-->>"+address.getState()+" and pincode--->>"+address.getPincode());
									}

									//address of customer
									//bulkDetails.setAddress(address.getAddressLine1());
								}

							}

							if(response.getLogicalResource()!=null){
								LogicalResource logicalResource = response.getLogicalResource();
								List<IdentificationById>logicalIdentificationList = logicalResource.getIdentification();
								if(logicalIdentificationList!=null && logicalIdentificationList.size()>0){
									for(IdentificationById identificationLog:logicalIdentificationList){
										if (CommonUtil.isNotNull(identificationLog.getId())) {
											identificationLog.getId();
											bulkDetails.setFxAcctNo(identificationLog.getId());//Ask Manish
											bulkDetails.setDelNO(identificationLog.getId());
											logger.info("Del no in INT 632 response--->>" +bulkDetails.getDelNO());
										}
									}
								}

								if(CommonUtil.isNotNull(logicalResource.getLrStatus())){
									logger.info("logicalResource.getLrStatus()" +logicalResource.getLrStatus());
								}

								if(CommonUtil.isNotNull(logicalResource.getReasonId())){
									logger.info("logicalResource.getReasonId()" +logicalResource.getReasonId());
								}
								if(CommonUtil.isNotNull(logicalResource.getType())){
									logger.info("logicalResource.getType()" +logicalResource.getType());
								}
							}

							if(response.getPartyAccount()!=null){
								PartyAccount partyAcc =response.getPartyAccount();
								if(partyAcc.getIdentification()!= null && partyAcc.getIdentification().size()>0){
									List<IdentificationById> partyAccIdentification = partyAcc.getIdentification();
									for(IdentificationById ids : partyAccIdentification){
										logger.info("Identification id In PartyAccount" +ids.getId());
									}
								}
								if(CommonUtil.isNotNull(partyAcc.getAccountCategory()))
									bulkDetails.setAccountCategory(partyAcc.getAccountCategory());

							}

							if(response.getMarketSegment()!=null){
								logger.info("MarketSegment code "+response.getMarketSegment() );
							}

							if(response.getCustomerPayment()!=null){
								CustomerBill customerBill =response.getCustomerPayment().getCustomerBill();
								PartyBill partyBill = customerBill.getPartyBill();
								if(partyBill!=null){
									if (CommonUtil.isNotNull(partyBill.getBillNo())) {
										bulkDetails.setOrigBillRefNo(partyBill.getBillNo());
									}
									if (CommonUtil.isNotNull(partyBill.getBillAmount())) {
										String amount = partyBill.getBillAmount();
										logger.info("billamount in createResponseJSONForPostCustAccountSummaryToFX--->>>"
												+ amount);
									}
									if (CommonUtil.isNotNull(partyBill.getDueAmount())) {
										dueAmount = partyBill.getDueAmount();
										bulkDetails.setFxOutstandingAmount(partyBill.getDueAmount());
										System.out.println(bulkDetails.getFxOutstandingAmount());
										logger.info("dueAmount in createResponseJSONForPostCustAccountSummaryToFX--->>>"
												+ dueAmount);
									}

									/*if (CommonUtil.isNotNull(partyBill.getDueTotalAmount())) {
									dueAmount = partyBill.getDueTotalAmount();
									bulkDetails.setFxOutstandingAmount(partyBill.getDueTotalAmount());
									System.out.println(bulkDetails.getFxOutstandingAmount());
									logger.info("dueAmount in createResponseJSONForPostCustAccountSummaryToFX--->>>"
											+ dueAmount);
								}*/
								}
								if(CommonUtil.isNotNull(customerBill.getNextBillDate())){
									customerBill.getNextBillDate();
								}
								if(CommonUtil.isNotNull(customerBill.getPreviousBillDate())){
									customerBill.getPreviousBillDate();
								}

								if (CommonUtil.isNotNull(customerBill.getBillRefResets())) {
									bulkDetails.setOrigBillRefResets(customerBill.getBillRefResets());
								}

								if (CommonUtil.isNotNull(customerBill.getBillCompany())) {
									bulkDetails.setBillCompany(customerBill.getBillCompany());
								}

								if (CommonUtil.isNotNull(customerBill.getBillfrequency())) {
									//bulkDetails.setBillFrequency(customerBill.getBillfrequency());
								}

								BillPeriod billPeriod = customerBill.getBillPeriod();
								if(billPeriod!=null){
									if (CommonUtil.isNotNull(billPeriod.getStartDate())) {
										billPeriod.getStartDate();
									}
									if (CommonUtil.isNotNull(billPeriod.getEndDate())) {
										billPeriod.getEndDate();
									}

									if (CommonUtil.isNotNull(billPeriod.getName())) {
										bulkDetails.setBillFrequency(billPeriod.getName());
									}
								}





								PartyPayment partyPayment =response.getCustomerPayment().getPartyPayment();

								if(partyPayment!=null){
									if (CommonUtil.isNotNull(partyPayment.getMode())) {
										bulkDetails.setPaymentMode(partyPayment.getMode());// PAYMENT
										// MODE
										logger.info(
												"partyPayment.getMode() in createResponseJSONForPostCustAccountSummaryToFX-->>"
														+ partyPayment.getMode());
									}

									if (CommonUtil.isNotNull(partyPayment.getPaymentDate())) {
										partyPayment.getPaymentDate();
									}

									if (CommonUtil.isNotNull(
											response.getOperationStatusCode())) {
										response.getOperationStatusCode();
									}
								}
								if(response.getService()!=null)
								{
									if(response.getService().getInactiveDate()!=null)
									{
										bulkDetails.setAccountInactiveDate(response.getService().getInactiveDate());
									}
									if(response.getService().getActivationDate()!=null)
									{
										bulkDetails.setAccActivationDate(response.getService().getActivationDate());	
									}
								}
								if(response.getStatus()!= null){
									Status status =response.getStatus();
									if (CommonUtil.isNotNull(status.getStatusCode())) {
										String[] statusCodeArray = status.getStatusCode().split("-");
										statusCode = statusCodeArray[1] + "-" + statusCodeArray[2];
										logger.info("status code in createResponseJSONForPostCustAccountSummaryToFX-->>"
												+ statusCode);
									}
									if (CommonUtil.isNotNull(status.getStatusCode())
											|| CommonUtil.isNotNull(status.getStatusDescription())) {
										status_description = statusCode + ":" + status.getStatusDescription();
										logger.info(
												"status_description in createResponseJSONForPostCustAccountSummaryToFX--->>"
														+ status.getStatusDescription());

										logger.info(
												"statusCode after response in createResponseJSONForPostCustAccountSummaryToFX--->>"
														+ status.getStatusCode());
										//bulkDetails.setErrorMsg(status_description);

									}
									errorCode="SUCCESS";
								}

							}



						}
					}
				}
			}
			else if(responsePojo.getBody().getSoaFault()!=null){

				SoaFault fault =responsePojo.getBody().getSoaFault();
				String[] soaFaultCodeArray=null;
				if(CommonUtil.isNotNull(fault.getSoaFaultCode())){
					soaFaultCodeArray = fault.getSoaFaultCode().split("-");
					if(soaFaultCodeArray!=null)
						statusCode = soaFaultCodeArray[1] + "-" + soaFaultCodeArray[2];
				}
				String fault_value="";
				if(CommonUtil.isNotNull( fault.getFaultDescription())){
					fault_value = fault.getFaultDescription();
					if (fault_value.length() > 999)
						fault_value = fault_value.substring(0, 1000);
				}

				status_description = statusCode + ":" + fault_value;
				status_description = status_description.replace("'", "");
				logger.info(
						"Status description is in createResponseJSONFor INT-632 when error response from webservice---> "
								+ status_description);

				bulkDetails.setErrorMsg(status_description);
				errorCode ="FAIL";
			}
			bulkDetails.setErrorCode(errorCode);

		}


		String statusCod =status_code=="200"?"SUCCESS":"FAILED";
		try {
			String trnxId= (bulkDetails.getAcctEXTID()!=null && !bulkDetails.getAcctEXTID().equals("")) ?bulkDetails.getAcctEXTID() :bulkDetails.getDelNO();
			//dao.insertFxLog(statusCod, trnxId, clientURL, mapper.writeValueAsString(responsePojo), null, null, "INT-632", null, null, null, null);
		} catch (Exception e) {
			logger.info("Error occur while insertIntoFX", e);
			e.printStackTrace();
		}
		return bulkDetails;
	}
	public static void main(String[] args) {
		BulkDetails bulkDetail = new BulkDetails();
		bulkDetail.setAcctEXTID("21-1113");
		bulkDetail.setLob("AES");
		
		try {
			BulkDetails bd =new CustomerAccountSummaryClient().postCustomerAccountSummaryToFX(bulkDetail, "true",null);
			System.out.println(bd.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
