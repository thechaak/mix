package com.airtel.acecad.client.json.createUpdateNotesJson;

public class TrackingRecord {

	private String userId;

    private String systemId;

    public String getUserId ()
    {
        return userId;
    }

    public void setUserId (String userId)
    {
        this.userId = userId;
    }

    public String getSystemId ()
    {
        return systemId;
    }

    public void setSystemId (String systemId)
    {
        this.systemId = systemId;
    }

    @Override
    public String toString()
    {
        return "{\"userId\" : \""+userId+"\", \"systemId\" : \""+systemId+"\"}";
    }
}
