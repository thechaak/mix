package com.airtel.acecad.client.json.custAccountSummaryJson;

public class IndividualName {

	private String familyNames;

    private String givenName;

    public String getFamilyNames()
    {
        return familyNames;
    }

    public void setFamilyNames (String familyNames)
    {
        this.familyNames = familyNames;
    }

    public String getGivenName() {
		return givenName;
	}

	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	@Override
    public String toString()
    {
        return "{\"familyNames\" : \""+familyNames+"\", \"givenName\" : \""+givenName+"\"}";
    }
}
