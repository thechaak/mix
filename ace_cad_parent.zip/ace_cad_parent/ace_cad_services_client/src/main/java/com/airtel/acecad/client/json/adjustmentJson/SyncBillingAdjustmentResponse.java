package com.airtel.acecad.client.json.adjustmentJson;


public class SyncBillingAdjustmentResponse {

	 private Status status;

	    private ResponseTrackingRecord trackingRecord;

	    public Status getStatus ()
	    {
	        return status;
	    }

	    public void setStatus (Status status)
	    {
	        this.status = status;
	    }

	    public ResponseTrackingRecord getTrackingRecord() {
			return trackingRecord;
		}

		public void setTrackingRecord(ResponseTrackingRecord trackingRecord) {
			this.trackingRecord = trackingRecord;
		}

		@Override
	    public String toString()
	    {
	        return "{\"status\" : "+status+", \"trackingRecord\" : "+trackingRecord+"}";
	    }
}
