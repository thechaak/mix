package com.airtel.acecad.client.json.createUpdateNotesJson;

public class RequestDataArea {

	  private SyncCustomerInteraction syncCustomerInteraction;

	    public SyncCustomerInteraction getSyncCustomerInteraction ()
	    {
	        return syncCustomerInteraction;
	    }

	    public void setSyncCustomerInteraction (SyncCustomerInteraction syncCustomerInteraction)
	    {
	        this.syncCustomerInteraction = syncCustomerInteraction;
	    }

	    @Override
	    public String toString()
	    {
	        return "{\"syncCustomerInteraction\" : "+syncCustomerInteraction+"}";
	    }
}
