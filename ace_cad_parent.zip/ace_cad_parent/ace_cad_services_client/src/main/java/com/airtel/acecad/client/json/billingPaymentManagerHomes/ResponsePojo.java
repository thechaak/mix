package com.airtel.acecad.client.json.billingPaymentManagerHomes;

public class ResponsePojo {

	private String postingDate;

    private String paymentDate;

    private Status status;

    private String homesId;

    private String amountPaid;

    private BundledServices[] bundledServices;

    public String getPostingDate ()
    {
        return postingDate;
    }

    public void setPostingDate (String postingDate)
    {
        this.postingDate = postingDate;
    }

    public String getPaymentDate ()
    {
        return paymentDate;
    }

    public void setPaymentDate (String paymentDate)
    {
        this.paymentDate = paymentDate;
    }

    public Status getStatus ()
    {
        return status;
    }

    public void setStatus (Status status)
    {
        this.status = status;
    }

    public String getHomesId ()
    {
        return homesId;
    }

    public void setHomesId (String homesId)
    {
        this.homesId = homesId;
    }

    public String getAmountPaid ()
    {
        return amountPaid;
    }

    public void setAmountPaid (String amountPaid)
    {
        this.amountPaid = amountPaid;
    }

    public BundledServices[] getBundledServices ()
    {
        return bundledServices;
    }

    public void setBundledServices (BundledServices[] bundledServices)
    {
        this.bundledServices = bundledServices;
    }

    @Override
    public String toString()
    {
        return "{\"postingDate\":\""+postingDate+"\",\"paymentDate\":\""+paymentDate+"\",\"status\":\""+status+"\",\"homesId\":\""+homesId+"\", \"amountPaid\":\""+amountPaid+"\", \"bundledServices\":"+bundledServices+"}";
    }
}
