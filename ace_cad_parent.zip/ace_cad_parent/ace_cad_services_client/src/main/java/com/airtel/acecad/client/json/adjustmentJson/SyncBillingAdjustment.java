package com.airtel.acecad.client.json.adjustmentJson;

public class SyncBillingAdjustment {

	 private LogicalResource logicalResource;

	    private CustomerPayment customerPayment;

	    private TrackingRecord trackingRecord;

	    private Customer customer;

	    public LogicalResource getLogicalResource ()
	    {
	        return logicalResource;
	    }

	    public void setLogicalResource (LogicalResource logicalResource)
	    {
	        this.logicalResource = logicalResource;
	    }

	    public CustomerPayment getCustomerPayment ()
	    {
	        return customerPayment;
	    }

	    public void setCustomerPayment (CustomerPayment customerPayment)
	    {
	        this.customerPayment = customerPayment;
	    }

	    public TrackingRecord getTrackingRecord ()
	    {
	        return trackingRecord;
	    }

	    public void setTrackingRecord (TrackingRecord trackingRecord)
	    {
	        this.trackingRecord = trackingRecord;
	    }

	    public Customer getCustomer ()
	    {
	        return customer;
	    }

	    public void setCustomer (Customer customer)
	    {
	        this.customer = customer;
	    }

	    @Override
	    public String toString()
	    {
	        return "{\"logicalResource\" : "+logicalResource+", \"customerPayment\" : "+customerPayment+", \"trackingRecord\" : "+trackingRecord+", \"customer\" : "+customer+"}";
	    }
}
