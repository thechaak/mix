package com.airtel.acecad.client;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.codec.binary.Base64;


import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.airtel.acecad.client.dao.ClientDAO;
import com.airtel.acecad.client.dao.ClientDAOImpl;
import com.airtel.acecad.client.dao.MessageSendCallDao;
import com.airtel.acecad.client.dao.MessageSendCallDaoImpl;
import com.airtel.acecad.client.dao.ReversalDaoImpl;
import com.airtel.acecad.client.dao.ReverseDao;
import com.airtel.acecad.client.dto.ChqBounceKciDetails;
import com.airtel.acecad.client.dto.NrcDetails;
import com.airtel.acecad.client.json.customerAccBillingDetails.AccountSummary;
import com.airtel.acecad.client.json.customerAccBillingDetails.Customer;
import com.airtel.acecad.client.json.customerAccBillingDetails.GetCustomerBillingAccountDetailsResponse;
import com.airtel.acecad.client.json.customerBillableComponent.CreateCustomerBilliableComponent;
import com.airtel.acecad.client.json.customerBillableComponent.CreateCustomerBilliableComponentResponse;
import com.airtel.acecad.client.json.customerBillableComponent.CustomerAccount;
import com.airtel.acecad.client.json.customerBillableComponent.CustomerBillableComponentRequest;
import com.airtel.acecad.client.json.customerBillableComponent.CustomerBillableComponentResponse;
import com.airtel.acecad.client.json.customerBillableComponent.DataArea;
import com.airtel.acecad.client.json.customerBillableComponent.DataAreaResponse;
import com.airtel.acecad.client.json.customerBillableComponent.EbmHeader;
import com.airtel.acecad.client.json.customerBillableComponent.Identification;
import com.airtel.acecad.client.json.customerBillableComponent.IdentificationResponse;
import com.airtel.acecad.client.json.customerBillableComponent.PartyPayment;
import com.airtel.acecad.client.json.customerBillableComponent.ProdPriceCharge;
import com.airtel.acecad.client.json.customerBillableComponent.Product;
import com.airtel.acecad.client.json.customerBillableComponent.SoaFault;
import com.airtel.acecad.client.json.customerBillableComponent.Status;
import com.airtel.acecad.client.json.customerBillableComponent.TrackingRecord;
import com.airtel.acecad.client.json.customerBillableComponent.TrackingRecordResponse;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.CustomResponseErrorHandler;
import com.airtel.acecad.client.util.EncryDecrypUtility;
import com.airtel.acecad.client.util.GenericConfiguration;
import com.airtel.acecad.client.util.GlobalConstants;
import com.airtel.acecad.mtservice.PushSMSAsMTService;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CustomerBillableComponentClientV5 implements GlobalConstants {

	private static final ObjectMapper mapper = new ObjectMapper();
	private static Logger logger = LogManager.getLogger("serviceClientUI");
	public String createRequestJsonForCustomerBillable(String extAccNo, int jobId,String file_identifier) {
		String result = "";
		int transactionId =0;
		ClientDAO dao = new ClientDAOImpl();
		try {
			List<NrcDetails> nrcList = dao.fetchNrcDetails(extAccNo);
			for (NrcDetails data : nrcList) {
				CustomerBillableComponentRequest requestObj = new CustomerBillableComponentRequest();
				EbmHeader ebmHeader = new EbmHeader();

				ebmHeader.setLob("Mobility");
				ebmHeader.setConsumerTransactionId("APS" + data.getTransactionNo());
				if (data.getApsFlag() != null && data.getApsFlag().equalsIgnoreCase("APS"))
					ebmHeader.setCustomerMigrated("true");
				else
					ebmHeader.setCustomerMigrated("false");
				DataArea dataArea = new DataArea();

				CreateCustomerBilliableComponent createCustomerBilliableComponent = new CreateCustomerBilliableComponent();
				CustomerAccount customerAccount = new CustomerAccount();
				Identification identification = new Identification();
				PartyPayment partyPayment = new PartyPayment();
				Product product = new Product();
				ProdPriceCharge prodPriceCharge = new ProdPriceCharge();
				TrackingRecord trackingRecord = new TrackingRecord();

				identification.setId(extAccNo);//data.getAcctNo() tracking id
				customerAccount.setIdentification(identification);
				
				//double amount=data.getNrcAmount()
				double d = data.getNrcAmount();
				int nrcAmount = (int) d;
				partyPayment.setAmount(String.valueOf(nrcAmount));
				//partyPayment.setAmount(String.valueOf(data.getNrcAmount()));
				partyPayment.setEffectiveDate(data.getEffectiveDate());
				partyPayment.setRemarks(data.getAnnotation());

				prodPriceCharge.setPriceType(String.valueOf(data.getTypeIdNrc()));
				product.setProdPriceCharge(prodPriceCharge);

				createCustomerBilliableComponent.setCustomerAccount(customerAccount);
				createCustomerBilliableComponent.setPartyPayment(partyPayment);
				createCustomerBilliableComponent.setProduct(product);
				createCustomerBilliableComponent.setTrackingRecord(trackingRecord);

				dataArea.setCreateCustomerBilliableComponent(createCustomerBilliableComponent);
				requestObj.setEbmHeader(ebmHeader);
				requestObj.setDataArea(dataArea);
				
				
				if (CommonUtil.isNotNull(String.valueOf(data.getTransactionNo()))) {
					transactionId = data.getTransactionNo();
				}
				Object[] resultobj = dao.updateJobId(NRC_APS, transactionId,null,jobId);
				
				logger.info("After hitting the posting fx job_id jobId in createRequestJsonForCustomerBillable result is:"
						+ resultobj[0] + "and job id is" + resultobj[1] + " and transactionId " + transactionId);

				if (RESULT_DB_SUCCESFUL.equalsIgnoreCase((String) resultobj[0])) {
					result = postCustomerBillableToFX(requestObj, data, jobId,file_identifier,NRC_APS);
					logger.info(
							"After postUpdateNrcForFailedPaymentToFX in createRequestJSONForNrcChequeBounceToFX result------>"
									+ result + "and account_no-->" + extAccNo+ "and transaction_no"+ transactionId);

				}

				
			}

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return result;
	}

	public String createRequestJSONForNrcChequeBounceToFX(String accountId,int jobId,String file_identifier){
		logger.info("START--->in createRequestJSONForNrcChequeBounceToFX method of NrcDetailsClient and account_no-->"
				+ accountId);
		String result = EMPTY_STRING;
		int transactionNo = EMPTY_VALUE;
		List<NrcDetails> nrcChequeBounceDetailsList = new ArrayList<NrcDetails>();
		ClientDAO clientDAO = new ClientDAOImpl();
		try {
			nrcChequeBounceDetailsList = clientDAO.fetchNrcChequeBounceDetails(accountId);
			logger.info("nrcDetailsList in createRequestJSONForNrcChequeBounceToFX---->>" + nrcChequeBounceDetailsList
					+ "and account_no-->" + accountId);
			for(NrcDetails nrcDetails : nrcChequeBounceDetailsList){
				
				logger.info("Before message trigger for cheque bounce nrc for account no --->>"+accountId);
				String result1=msgTriggerForNrcChqBounce(accountId,nrcDetails.getRefNumber());
				logger.info("After message trigger for cheque bounce nrc and result after updation:"+result1);
				CustomerBillableComponentRequest requestObj = new CustomerBillableComponentRequest();
				EbmHeader ebmHeader = new EbmHeader();

				ebmHeader.setLob("Mobility");//NEED TO BE DYNAMIC
				ebmHeader.setConsumerTransactionId("APS" + nrcDetails.getTransactionNo());
				if (nrcDetails.getApsFlag().equalsIgnoreCase("APS"))
					ebmHeader.setCustomerMigrated("true");

				ebmHeader.setCustomerMigrated("false");
				DataArea dataArea = new DataArea();

				CreateCustomerBilliableComponent createCustomerBilliableComponent = new CreateCustomerBilliableComponent();
				CustomerAccount customerAccount = new CustomerAccount();
				Identification identification = new Identification();
				PartyPayment partyPayment = new PartyPayment();
				Product product = new Product();
				ProdPriceCharge prodPriceCharge = new ProdPriceCharge();
				TrackingRecord trackingRecord = new TrackingRecord();

				identification.setId(accountId);//data.getAcctNo() tracking id
				customerAccount.setIdentification(identification);
				int amount = (int) nrcDetails.getNrcAmount();
				String nrcAmount = String.valueOf(amount*100);
				partyPayment.setAmount(nrcAmount);
				
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
				Date date = new Date();

				partyPayment.setEffectiveDate(dateFormat.format(date));//nrcDetails.getEffectiveDate()
				partyPayment.setRemarks(nrcDetails.getAnnotation());

				prodPriceCharge.setPriceType(String.valueOf(nrcDetails.getTypeIdNrc()));
				product.setProdPriceCharge(prodPriceCharge);

				createCustomerBilliableComponent.setCustomerAccount(customerAccount);
				createCustomerBilliableComponent.setPartyPayment(partyPayment);
				createCustomerBilliableComponent.setProduct(product);
				createCustomerBilliableComponent.setTrackingRecord(trackingRecord);

				dataArea.setCreateCustomerBilliableComponent(createCustomerBilliableComponent);
				requestObj.setEbmHeader(ebmHeader);
				requestObj.setDataArea(dataArea);
				
				
				if (CommonUtil.isNotNull(String.valueOf(nrcDetails.getTransactionNo()))) {
					transactionNo = nrcDetails.getTransactionNo();
				}
				Object[] resultobj = clientDAO.updateJobId(AIRTL_CHQ_BOUNCE_NRC_RECORDS, transactionNo,null,jobId);
				
				logger.info("After hitting the posting fx job_id jobId in createRequestJSONForPaymentReversalToFX result is:"
						+ resultobj[0] + "and job id is" + resultobj[1] + " and transactionId " + transactionNo);

				if (RESULT_DB_SUCCESFUL.equalsIgnoreCase((String) resultobj[0])) {
					result = postCustomerBillableToFX(requestObj, nrcDetails, jobId,file_identifier,AIRTL_CHQ_BOUNCE_NRC_RECORDS);
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;

	}
	public String postCustomerBillableToFX(CustomerBillableComponentRequest requestObj, NrcDetails nrcData,
			int jobId,String fileIdentifier ,String tableName) {
		String result = EMPTY_STRING;
		String status_code = null;
		ClientDAO clientDao = new ClientDAOImpl();
		SoaFault soaFault = null;
		int pTransactionId = EMPTY_VALUE;
		String resultConectRead = EMPTY_STRING;
		try {
			String clientURL = GenericConfiguration.getDescription("kenon.postCustomerBillableComponentV5.url");
			logger.info("clientURL  postUpdatePaymentReversalToFX -->" + clientURL);
			RestTemplate restTemplate = new RestTemplate();

			logger.info("Generated Json request for payment  Reversal ===>" + mapper.writeValueAsString(requestObj));

			restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
					.setConnectTimeout(Integer.parseInt(GenericConfiguration.getDescription("connect_time_out")));// 60000=
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
					.setReadTimeout(Integer.parseInt(GenericConfiguration.getDescription("read_time_out")));

			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
			restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
			restTemplate.setErrorHandler(new CustomResponseErrorHandler());
			HttpHeaders headers = new HttpHeaders();

			String userpass = GenericConfiguration.getDescription("kenon.postPaymentToFX.userName") + ":"
					+ EncryDecrypUtility.decrypt(GenericConfiguration.getDescription("kenon.postPaymentToFX.password"));

			headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			HttpEntity<CustomerBillableComponentRequest> entity = new HttpEntity<CustomerBillableComponentRequest>(
					requestObj, headers);
			ResponseEntity<CustomerBillableComponentResponse> responsePojo = null;
			responsePojo = restTemplate.exchange(clientURL, HttpMethod.POST, entity,
					CustomerBillableComponentResponse.class);
			logger.info("responsePojo for NRC Create---" + responsePojo);
			if (responsePojo != null) {
				logger.info("Response generated for INT-659===>" + mapper.writeValueAsString(responsePojo));
				status_code = responsePojo.getStatusCode().toString();
				if (HttpStatus.OK == responsePojo.getStatusCode()) {
					if (responsePojo.getBody().getDataArea() != null && responsePojo.getBody().getEbmHeader() != null) {
						logger.info(
								"status code is 200 Response from  postPaymentToFX EBMHeader and DataArea with transaction id is===>"
										+ responsePojo.getBody().getEbmHeader() + " : " + " : "
										+ responsePojo.getBody().getDataArea() + " : " + pTransactionId);
					} else {
						status_code = responsePojo.getStatusCode().toString();
						soaFault = responsePojo.getBody().getSoaFault();
						logger.info("status code in postPaymentToFX in http status not  200ok--->" + soaFault
								+ "and pTransactionId" + pTransactionId + " & StatusCode = " + status_code);

					}
				} else {
					status_code = responsePojo.getStatusCode().toString();
					soaFault = responsePojo.getBody().getSoaFault();
					logger.info("status code in postPaymentToFX in http status not 200ok--->" + soaFault
							+ " and pTransactionId = " + pTransactionId + " & StatusCode = " + status_code);
				}

				result = createResponseForFX(responsePojo, nrcData, soaFault, requestObj, status_code, jobId,fileIdentifier,tableName);
			}

		} catch (Exception e) {
			logger.info("exception in postPaymentToFX", e);
			if (CommonUtil.isNotNull(String.valueOf(nrcData.getTransactionNo()))) {

				pTransactionId = nrcData.getTransactionNo();
			}
			try {
				if (e.getCause().toString().contains(CONNECT_TEXT)) {
					resultConectRead = clientDao.updateConnectionReadResponse(pTransactionId, tableName, CONNECT_TEXT);
					logger.info("Got faulty code from the response CONNECT_TEXT of FX resultConectRead----->"
							+ resultConectRead + "and pTransactionId" + pTransactionId);
				}
				if (e.getCause().toString().contains(READ_TEXT)) {
					resultConectRead = clientDao.updateConnectionReadResponse(pTransactionId, tableName, READ_TEXT);
					logger.info("Got faulty code from the response READ_TEXT  of FX resultConectRead----->"
							+ resultConectRead + "and pTransactionId" + pTransactionId);

				}
			} catch (Exception e1) {
				logger.info("Exception occur in postCustomerBillableToFX() NRC Create INT", e1);
			}

		}
		return result;

	}

	private String createResponseForFX(ResponseEntity<CustomerBillableComponentResponse> responsePojo,
			NrcDetails nrcData, SoaFault soaFault, CustomerBillableComponentRequest requestObj, String status_code,
			int jobId,String fileIdentifier ,String tableName) {

		String result = EMPTY_STRING;
		String faultDescription = EMPTY_STRING;
		String statusCode = "";
		int trackIdServ = 0;
		int viewId = 0;
		int trackId = 0;

		if (responsePojo != null) {
			DataAreaResponse dataArea = responsePojo.getBody().getDataArea();
			if (dataArea != null) {
				CreateCustomerBilliableComponentResponse accountDetails = dataArea
						.getCreateCustomerBilliableComponentResponse();
				if (accountDetails != null) {
					TrackingRecordResponse trackRecord = accountDetails.getTrackingRecord();
					if (trackRecord != null) {
						trackIdServ =CommonUtil.isNotNull(trackRecord.getSystemId())? Integer.parseInt(trackRecord.getSystemId()) :0;
								 
						if (CommonUtil.isNotNull(trackRecord.getViewId()))
							viewId  = CommonUtil.isNotNull(trackRecord.getViewId())? Integer.parseInt(trackRecord.getViewId()) :0;
						
						IdentificationResponse identification = trackRecord.getIdentification();
						if (identification != null) {
							if (CommonUtil.isNotNull(identification.getId()))
								trackId =  CommonUtil.isNotNull(identification.getId())? Integer.parseInt(identification.getId()) :0;
						}
					}

					Status status = accountDetails.getStatus();
					if (status != null) {
						if (CommonUtil.isNotNull(status.getStatusCode())) {
							String[] soaFaultCodeArray = status.getStatusCode().split("-");
							statusCode = soaFaultCodeArray[1] + "-" + soaFaultCodeArray[2];
						}
						if (CommonUtil.isNotNull(status.getStatusCode())
								|| CommonUtil.isNotNull(status.getStatusDescription())) {
							faultDescription = statusCode + ":" + status.getStatusDescription();
							logger.info("status_description in  response of NRC CREATE--->>"
									+ faultDescription);
						}
					}

				}
			}
			SoaFault fault = responsePojo.getBody().getSoaFault();
			if (fault != null) {
				String[] soaFaultCodeArray = fault.getSoaFaultCode().split("-");
				statusCode = soaFaultCodeArray[1] + "-" + soaFaultCodeArray[2];
				String fault_value = fault.getFaultDescription();
				if (fault_value.length() > 999)
					fault_value = fault_value.substring(0, 1000);

				faultDescription = statusCode + ":" + fault_value;
				faultDescription = faultDescription.replace("'", "");
				logger.info(
						"Status description is in response of NRC CREATE when error response from webservice---> "
								+ faultDescription);
			}
		}
		ClientDAO clientDao = new ClientDAOImpl();

		try {
			result = clientDao.updateResponse(faultDescription, trackId, trackIdServ, nrcData.getTransactionNo(), tableName, viewId, jobId, "", "", "");

			String statusDiscription = statusCode.equals("200") ? "SUCCESS" : "FAILURE";
			clientDao.insertFxLog(statusDiscription,  String.valueOf(nrcData.getTransactionNo()),mapper.writeValueAsString(requestObj), mapper.writeValueAsString(responsePojo),
					"NRC", "APS", "NRC CREATE", null, null, null, null);
			logger.info("AFTER UPDATE RESPONSE ==" + result);
		} catch (Exception e) {
			logger.info("Exception occur while updateResponseInt() for NRC CREATE ", e);
		}
		logger.info(
				"After updateResponse in for NRC CREATE response-result----->>>" + result);

		return result;

	}

	public String msgTriggerForNrcChqBounce(String accountNo,String chequeNumber) throws Exception{
		
		logger.info("START --> in msgTriggerForNrcChqBounce method of NrcDetailsClient");
		
		String msg_result = EMPTY_STRING;
		String msg_tobe_sent = "Dear customer your cheque "+chequeNumber+" is bounce";
		String result=EMPTY_STRING;
	
		ChqBounceKciDetails chqBounceKciDTO=new ChqBounceKciDetails();
		PushSMSAsMTService pushSMSAsMTService = new PushSMSAsMTService();
		
		MessageSendCallDao messageSendCallDao = new MessageSendCallDaoImpl();
		chqBounceKciDTO=messageSendCallDao.fetchContactNo(accountNo);
		try{
		if (CommonUtil.isNotNull(msg_tobe_sent) && !CommonUtil.isNotNull(chqBounceKciDTO.getErrorDescription())) {
			
			if(CommonUtil.isNotNull(chqBounceKciDTO.getPrimaryContactNo())){
				logger.info("if primary contact no is not null--->"+chqBounceKciDTO.getPrimaryContactNo());
			msg_result = pushSMSAsMTService.pushSmsToUser(chqBounceKciDTO.getPrimaryContactNo(), msg_tobe_sent);
			}
			else if(CommonUtil.isNotNull(chqBounceKciDTO.getAlternateContactNo())){
				logger.info("if primary contact no is null and alternate no is--->"+chqBounceKciDTO.getAlternateContactNo());
				msg_result = pushSMSAsMTService.pushSmsToUser(chqBounceKciDTO.getAlternateContactNo(), msg_tobe_sent);
			}
			else{
				logger.info("both primary and alternate contact no is null");
			}
			
			if (CommonUtil.isNotNull(msg_result)) {
				result=messageSendCallDao.updateResponseForChqBounceKci(chqBounceKciDTO.getPrimaryContactNo(),msg_result,accountNo);
			}
		}
		} catch (Exception e) {
			logger.info("exception in msgTriggerForNrcChqBounce in NrcDetailsClient" + e);
		}
		logger.info("END --> in msgTriggerForNrcChqBounce method of NrcDetailsClient");
		
		return result;
	}
	public static void main(String[] args) {
		new CustomerBillableComponentClientV5().createRequestJsonForCustomerBillable("1367449887",45,"");
	}
}
