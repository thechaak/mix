package com.airtel.acecad.client.json.billingPaymentManagerHomes;

import java.util.List;

public class OriginalServiceDetails {

	private String lob;

    private String accountId;

    private String rtn;

    private List<SiList> siList;

    public String getLob ()
    {
        return lob;
    }

    public void setLob (String lob)
    {
        this.lob = lob;
    }

    public String getAccountId ()
    {
        return accountId;
    }

    public void setAccountId (String accountId)
    {
        this.accountId = accountId;
    }
   
    public String getRtn() {
		return rtn;
	}

	public void setRtn(String rtn) {
		this.rtn = rtn;
	}

    public List<SiList> getSiList() {
		return siList;
	}

	public void setSiList(List<SiList> siList) {
		this.siList = siList;
	}

	@Override
    public String toString()
    {
        return "{\"lob\" : \""+lob+"\", \"accountId\" : \""+accountId+"\", \"rtn\" : \""+rtn+"\", \"siList\" : "+siList+"}";
    }
}
