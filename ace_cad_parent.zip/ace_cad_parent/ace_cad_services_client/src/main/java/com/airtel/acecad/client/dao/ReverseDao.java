package com.airtel.acecad.client.dao;

import java.util.List;

import com.airtel.acecad.client.dto.BulkDetails;
import com.airtel.acecad.client.dto.PaymentReversalDetails;
import com.airtel.acecad.client.dto.PostPaymentToFXRequest;

public interface ReverseDao {

	public String insertCustPayment( String accountNum) throws Exception;
	
	public List<PostPaymentToFXRequest> fetchPaymenReversalDetails(String accountId,String recordType) throws Exception;
	
//	ADDED on 1 JAN
	/*public String updateResponseInt(String trackingId, String trackingServId,String faultDescription,
			 PostPaymentToFXRequest postPaymentToFXRequest,int jobId) throws Exception;*/
	
	/*public String updateResponseInt(String trackingId, String trackingServId, String faultDescription,
			PaymentReversalDetails paymentReversalDetails, int jobId) throws Exception;*/
	
	public String updateResponseInt(String trackingId, String trackingServId, String faultDescription,
			PaymentReversalDetails paymentReversalDetails, int jobId,String fileIdentifier) throws Exception;
	
	public String updateAdviceRev(BulkDetails bulkObj) throws Exception;
	public List<BulkDetails> getreversalPaymentAdvice(String accountNo,String recordType) throws Exception;
	
	
	public String updateResponseForPaymentPosting(String trackingId, String trackingServId, String faultDescription,
			PostPaymentToFXRequest postPaymentToFXRequest, int jobId,String val,String tableName) throws Exception;
	
	public List<PaymentReversalDetails> fetchPaymentRevDirDetails(String accountId,String fileIdentifier) throws Exception;
	 public String updateResonseCustomerBillingAccount(String invoiceNo,String transactionId,String faultDescription);
	  public String updateResponsePaymentTransferPayment(String trackingId, String trackingServId, String faultDescription,
	 			PostPaymentToFXRequest postPaymentToFXRequest, int jobId,String transferType,String tableName ) throws Exception ;

	  public String updateResponsePaymentTransferRev(String trackingId, String trackingServId, String faultDescription,
	    		 PaymentReversalDetails paymentReversalDetails, int jobId,String fileIdentifier ,String transferType ) throws Exception;
				 
				 	public String updateReversalDetails(String recordId,String status) throws Exception;
	public List<BulkDetails> getReversalAdviceDetails(String accountNo, String recordType) throws Exception;
}
