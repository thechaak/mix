package com.airtel.acecad.client.dao;

import com.airtel.acecad.client.dto.ChqBounceKciDetails;
import com.airtel.acecad.client.dto.EcsDeregisterationDetails;

public interface MessageSendCallDao {

	//Added by Geeta 
	//public EcsDeregisterationDetails fetchMsgContent(int srTransactionId,String srCategory) throws Exception;
		/*public String updateMessageForMT(String mobileNo,int srTransactionNo,String srCategory,String msgResult)
				throws Exception;*/
		public String updateForMsgTrigger(String mobileNo,int srTransactionNo,String msgResult,String file_identifier)
				throws Exception;
		
		public ChqBounceKciDetails fetchContactNo(String accountNo) throws Exception;
		
		public String updateResponseForChqBounceKci(String mobileNo,String msgResult,String accountNo) throws Exception;
		
		public Object[] fetchMsgTriggerDetails(int srTransactionNo) throws Exception;
}
