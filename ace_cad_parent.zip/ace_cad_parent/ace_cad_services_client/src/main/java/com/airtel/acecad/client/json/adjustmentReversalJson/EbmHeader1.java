package com.airtel.acecad.client.json.adjustmentReversalJson;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class EbmHeader1 {
	 private String consumerTransactionId;
	 
	 
	    public String getConsumerTransactionId ()
	    {
	        return consumerTransactionId;
	    }

	    public void setConsumerTransactionId (String consumerTransactionId)
	    {
	        this.consumerTransactionId = consumerTransactionId;
	    }

	  
		@Override
	    public String toString()
	    {
	        return "{\"consumerTransactionId\": \""+consumerTransactionId+"\"}";
	    
	}
}
