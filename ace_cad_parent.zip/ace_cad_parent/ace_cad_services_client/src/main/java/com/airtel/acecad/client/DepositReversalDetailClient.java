package com.airtel.acecad.client;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.codec.binary.Base64;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.airtel.acecad.client.dao.ClientDAO;
import com.airtel.acecad.client.dao.ClientDAOImpl;
import com.airtel.acecad.client.dto.DepositReversalDetails;
import com.airtel.acecad.client.json.depositRefundJson.Attribute;
import com.airtel.acecad.client.json.depositRefundJson.CustomerAccount;
import com.airtel.acecad.client.json.depositRefundJson.DaaCreated;
import com.airtel.acecad.client.json.depositRefundJson.DepositRefundFault;
import com.airtel.acecad.client.json.depositRefundJson.DepositRefundTrackingRecord;
import com.airtel.acecad.client.json.depositRefundJson.DetailFault;
import com.airtel.acecad.client.json.depositRefundJson.DisputedAmount;
import com.airtel.acecad.client.json.depositRefundJson.EbmHeader;
import com.airtel.acecad.client.json.depositRefundJson.EbmHeader1;
import com.airtel.acecad.client.json.depositRefundJson.Ext;
import com.airtel.acecad.client.json.depositRefundJson.Fault;
import com.airtel.acecad.client.json.depositRefundJson.Identification;
import com.airtel.acecad.client.json.depositRefundJson.RefundCustomerPayment;
import com.airtel.acecad.client.json.depositRefundJson.RefundCustomerPaymentReqMsg;
import com.airtel.acecad.client.json.depositRefundJson.RefundCustomerPaymentRequestPojo;
import com.airtel.acecad.client.json.depositRefundJson.RefundCustomerPaymentResMsg;
import com.airtel.acecad.client.json.depositRefundJson.RefundCustomerPaymentResponse;
import com.airtel.acecad.client.json.depositRefundJson.RefundCustomerPaymentResponsePojo;
import com.airtel.acecad.client.json.depositRefundJson.RequestDataArea;
import com.airtel.acecad.client.json.depositRefundJson.ResponseDataArea;
import com.airtel.acecad.client.json.depositRefundJson.SoaFault;
import com.airtel.acecad.client.json.depositRefundJson.Status;
import com.airtel.acecad.client.json.depositRefundJson.TrackingRecord;
import com.airtel.acecad.client.json.depositRefundJson.TrackingRecordIdentification;
import com.airtel.acecad.client.util.GenericConfiguration;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.CustomResponseErrorHandler;
import com.airtel.acecad.client.util.EncryDecrypUtility;
import com.airtel.acecad.client.util.GlobalConstants;

///////////////////////////////////INT_362(DEPOSIT_REFUND)//////////////////////////////////////////

public class DepositReversalDetailClient implements GlobalConstants {
	private static Logger log = LogManager.getLogger("serviceClientUI");

	/*
	 * @author :- Geeta Rajput-FOR REFUND DepositReversal TO FX-DEPOSIT REFUND
	 */
	public String postUpdateDepositReversalToFX(RefundCustomerPaymentRequestPojo requestPojo,
			DepositReversalDetails depositReversalDetails, String tableName, int jobId) throws Exception {

		log.info("START --> in postUpdateDepositReversalToFX method of DepositReversalDetailClient and transaction_no"
				+ depositReversalDetails.getTransactionNo());
		RefundCustomerPaymentResMsg refundCustomerPaymentResMsg = null;
		Fault fault = null;
		String result = EMPTY_STRING;
		String status_code = EMPTY_STRING;

		ClientDAO clientDao = new ClientDAOImpl();
		// int pTransactionId = EMPTY_VALUE;
		String resultConectRead = EMPTY_STRING;
		int transaction_no = depositReversalDetails.getTransactionNo();

		try {

			String clientURL = GenericConfiguration.getDescription("kenon.postUpdateRefundCustomerPaymentToFX.url");

			RestTemplate restTemplate = new RestTemplate();
			// ADDED FOR HANDLING TIMEOUT ERRORS
			restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
					.setConnectTimeout(Integer.parseInt(GenericConfiguration.getDescription("connect_time_out")));// 60000=
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
					.setReadTimeout(Integer.parseInt(GenericConfiguration.getDescription("read_time_out")));

			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
			restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
			restTemplate.setErrorHandler(new CustomResponseErrorHandler());
			HttpHeaders headers = new HttpHeaders();
            
			//Added by Ritu (EncryptDecrypt Password)
			String userpass = GenericConfiguration.getDescription("kenon.postPaymentToFX.userName") + ":"
					+ EncryDecrypUtility.decrypt(GenericConfiguration.getDescription("kenon.postPaymentToFX.password"));
			//System.out.println("username----------" + userpass);
			log.info("clientURL in postUpdateDepositReversalToFX-->" + clientURL + " and transaction_no "
					+ transaction_no);
			headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

			HttpEntity<RefundCustomerPaymentRequestPojo> entity = new HttpEntity<RefundCustomerPaymentRequestPojo>(
					requestPojo, headers);
			ResponseEntity<RefundCustomerPaymentResponsePojo> responsePojo = null;
			try {
				// Execute the httpMethod to given uri template,writing the
				// given request and returns the response as ResponseEntity
				responsePojo = restTemplate.exchange(clientURL, HttpMethod.POST, entity,
						RefundCustomerPaymentResponsePojo.class);
		/*		log.info("responsePojo in postUpdateDepositReversalToFX----" + responsePojo + " and transaction_no "
						+ transaction_no);*/
				log.info("responsePojo in postUpdateDepositReversalToFX----" + responsePojo.getBody().toString()
						+ " and transaction_no " + transaction_no);
				if (responsePojo != null) {
					if (HttpStatus.OK == responsePojo.getStatusCode()) {
						if (responsePojo.getBody().getRefundCustomerPaymentResMsg() != null) {
							refundCustomerPaymentResMsg = responsePojo.getBody().getRefundCustomerPaymentResMsg();
							log.info("success--in postUpdateDepositReversalToFX---->>"
									+ responsePojo.getBody().getRefundCustomerPaymentResMsg() + " and transaction_no "
									+ transaction_no);

						} else {
							status_code = responsePojo.getStatusCode().toString();
							fault = responsePojo.getBody().getFault();
							log.info("faultResponsePojo in postUpdateDepositReversalToFX in http 200 ok -->>" + fault
									+ " and transaction_no " + transaction_no);
						}
					} else {
						status_code = responsePojo.getStatusCode().toString();
						fault = responsePojo.getBody().getFault();
						log.info("faultResponsePojo in postUpdateDepositReversalToFX--->>" + fault
								+ " and transaction_no " + transaction_no);
					}
					log.info(
							"Before createResponseJSONForDepositReversalToFX in postUpdateDepositReversalToFX and transaction_no "
									+ transaction_no);
					result = createResponseJSONForDepositReversalToFX(refundCustomerPaymentResMsg, fault,
							depositReversalDetails, status_code, jobId);
					log.info(
							"After createResponseJSONForDepositReversalToFX in postUpdateDepositReversalToFX result-->>"
									+ result + " and transaction_no " + transaction_no);
				} else {
					log.info("IN method  createResponseJSONForPostPaymentToFX response pojo is null and transaction_no "
							+ transaction_no);

				}
			} catch (Exception e) {
				log.info("Got faulty code from the response of FX postUpdateDepositReversalToFX", e);
				if (e.getCause().toString().contains(CONNECT_TEXT)) {

					resultConectRead = clientDao.updateConnectionReadResponse(transaction_no, tableName, CONNECT_TEXT);
					log.info("Got faulty code from the response CONNECT_TEXT of FX resultConectRead----->"
							+ resultConectRead + " and transaction_no " + transaction_no);
				}

				if (e.getCause().toString().contains(READ_TEXT)) {

					resultConectRead = clientDao.updateConnectionReadResponse(transaction_no, tableName, READ_TEXT);
					log.info("Got faulty code from the response READ_TEXT  of FX resultConectRead----->"
							+ resultConectRead + " and transaction_no " + transaction_no);

				}
			}

		} catch (Exception e) {
			log.info("exception in postUpdateDepositReversalToFX" + e);

			if (e.getCause().toString().contains(CONNECT_TEXT)) {

				resultConectRead = clientDao.updateConnectionReadResponse(transaction_no, tableName, CONNECT_TEXT);
				log.info("Got faulty code from the response CONNECT_TEXT of FX resultConectRead----->"
						+ resultConectRead + " and transaction_no " + transaction_no);
			}

			if (e.getCause().toString().contains(READ_TEXT)) {

				resultConectRead = clientDao.updateConnectionReadResponse(transaction_no, tableName, READ_TEXT);
				log.info("Got faulty code from the response READ_TEXT  of FX resultConectRead----->" + resultConectRead
						+ " and transaction_no " + transaction_no);

			}
		}
		log.info("END--->in postUpdateDepositReversalToFX method of DepositReversalDetailClient and transaction_no "
				+ transaction_no);
		return result;
	}

	/*
	 * @author :- Geeta Rajput--For Deposit Reversal Request json
	 */
	public String createRequestJSONForDepositReversalToFX(String accountId, String tableName,int job_id) throws Exception {

		log.info(
				"START--->in createRequestJSONForDepositReversalToFX method of DepositReversalDetailClient and account_no-->"
						+ accountId);

		String result = EMPTY_STRING;
		Date sysdate = new Date();
		int transactionNo = EMPTY_VALUE;
		List<DepositReversalDetails> depositReversalDetailsList = new ArrayList<DepositReversalDetails>();

		ClientDAO clientDAO = new ClientDAOImpl();
		depositReversalDetailsList = clientDAO.fetchDepositReversalDetails(accountId);

		log.info("depositReversalDetailsList in createRequestJSONForDepositReversalToFX---->>"
				+ depositReversalDetailsList + "and account_no-->" + accountId);

		for (int i = 0; i < depositReversalDetailsList.size(); i++) {

			DepositReversalDetails depositReversalDetails = new DepositReversalDetails();
			depositReversalDetails = depositReversalDetailsList.get(i);

			RefundCustomerPaymentReqMsg refundCustomerPaymentReqMsg = new RefundCustomerPaymentReqMsg();
			EbmHeader ebmHeader = new EbmHeader();
			ebmHeader.setLob(LOB);
			ebmHeader.setSubLob(SUBLOB);
			ebmHeader.setConsumerName(REFUND_CONSUMER_NAME);
			String consumerTransactionId = APS + depositReversalDetails.getTransactionNo();
			//log.info("consumerTransactionId in createRequestJSONForDepositReversalToFX----->" + consumerTransactionId);
			ebmHeader.setConsumerTransactionId(consumerTransactionId);
			ebmHeader.setCustomerMigrated(TRUE);
			// ebmHeader.setConsumerTransactionId("99999");
			// ebmHeader.setCustomerMigrated("true");
			refundCustomerPaymentReqMsg.setEbmHeader(ebmHeader);

			RequestDataArea dataArea = new RequestDataArea();
			RefundCustomerPayment refundCustomerPayment = new RefundCustomerPayment();
			refundCustomerPayment.setOperationType(OPERATION_TYPE2);

			CustomerAccount customerAccount = new CustomerAccount();
			Identification identification = new Identification();
			customerAccount.setIdentification(identification);
			identification.setId(accountId);

			refundCustomerPayment.setCustomerAccount(customerAccount);

			DepositRefundTrackingRecord trackingRecord = new DepositRefundTrackingRecord();
			TrackingRecordIdentification trackingRecordId = new TrackingRecordIdentification();

			if (CommonUtil.isNotNull(depositReversalDetails.getOrigTrackingId())) {
				trackingRecordId.setId(depositReversalDetails.getOrigTrackingId());
			}

			if (CommonUtil.isNotNull(depositReversalDetails.getOrigTrackinIdServ())) {
				trackingRecord.setSystemId(depositReversalDetails.getOrigTrackinIdServ());
			}

			trackingRecord.setIdentification(trackingRecordId);
			refundCustomerPayment.setTrackingRecord(trackingRecord);

			DisputedAmount disputedAmount = new DisputedAmount();
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			Date date = new Date();

			disputedAmount.setInteractionDate(String.valueOf(dateFormat.format(date)));
			refundCustomerPayment.setDisputedAmount(disputedAmount);

			if (CommonUtil.isNotNull(depositReversalDetails.getRefundType())) {

				log.info("refund  type is 1 in createRequestJSONForDepositReversalToFX ");
				DaaCreated daaCreated = new DaaCreated();

				if (CommonUtil.isNotNull(depositReversalDetails.getRefundReasonCode())) {
					daaCreated.setReason(depositReversalDetails.getRefundReasonCode());// refundreasoncode
																						// from
																						// seibel
				}

				daaCreated.setType(depositReversalDetails.getRefundType());// refund_type=1

				refundCustomerPayment.setDaaCreated(daaCreated);
			} else {
				log.info("refund  type is not 1 in createRequestJSONForDepositReversalToFX ");
			}

			dataArea.setRefundCustomerPayment(refundCustomerPayment);
			refundCustomerPaymentReqMsg.setDataArea(dataArea);

			RefundCustomerPaymentRequestPojo refundCustomerPaymentRequestPojo = new RefundCustomerPaymentRequestPojo();

			refundCustomerPaymentRequestPojo.setRefundCustomerPaymentReqMsg(refundCustomerPaymentReqMsg);
			//log.info(refundCustomerPaymentReqMsg.toString() + "and account_no -->" + accountId);
			log.info("mypojo  in createRequestJSONForDepositReversalToFX---->>" + refundCustomerPaymentRequestPojo
					+ "and account_no-->" + accountId);

			if (depositReversalDetails.getTransactionNo() != 0) {
				transactionNo = depositReversalDetails.getTransactionNo();
			}

			log.info("Before hitting the posting fx job_id for transaction no in INT---" + transactionNo
					+ " in createRequestJSONForDepositReversalToFX");
			Object[] resultobj = clientDAO.updateJobId(tableName, transactionNo,null,job_id);

			log.info("After hitting the posting fx job_id jobId in createRequestJSONForDepositReversalToFX result is:"
					+ resultobj[0] + "and job id is" + resultobj[1] + " and transaction_no " + transactionNo);
			if (RESULT_DB_SUCCESFUL.equalsIgnoreCase((String) resultobj[0])) {

				log.info(
						"Before postUpdateDepositReversalToFX in createRequestJSONForDepositReversalToFX and account_no-->"
								+ accountId + " and transaction_no " + transactionNo);
				DepositReversalDetailClient depositTransferDetailClient = new DepositReversalDetailClient();
				result = depositTransferDetailClient.postUpdateDepositReversalToFX(refundCustomerPaymentRequestPojo,
						depositReversalDetails, tableName, (int) resultobj[1]);
				log.info("After postUpdateDepositReversalToFX in createRequestJSONForDepositReversalToFX result------>"
						+ result + "and account_no-->" + accountId + " and transaction_no " + transactionNo);
			}
			log.info(
					"END--->in createRequestJSONForDepositReversalToFX method of DepositReversalDetailClient and account_no-->"
							+ accountId + " and transaction_no " + transactionNo);
		}
		return result;
	}

	/*
	 * @author :- Geeta Rajput-- To Create ResponseJson Format for update
	 * 
	 */
	public String createResponseJSONForDepositReversalToFX(RefundCustomerPaymentResMsg refundCustomerPaymentResMsg,
			Fault fault, DepositReversalDetails depositReversalDetails, String statusCode, int jobId) throws Exception {

		log.info("START----in createResponseJSONForDepositReversalToFX method of DepositReversalDetailClient");

		String result = EMPTY_STRING;
		String faultDescription = EMPTY_STRING;
		String status_description = EMPTY_STRING;
		int trackingServId = EMPTY_VALUE;
		int trackingId = EMPTY_VALUE;
		int viewId = EMPTY_VALUE;
		int transaction_no = depositReversalDetails.getTransactionNo();
		String annotation3 = EMPTY_STRING;
		String annotation5 = EMPTY_STRING;
		String faultTrace = EMPTY_STRING;

		EbmHeader1 ebmHeader1 = new EbmHeader1();
		if (refundCustomerPaymentResMsg != null) {
			log.info("In if loop when got success response from webservice --362 INT and transaction_no-->>"
					+ transaction_no);

			if (refundCustomerPaymentResMsg.getEbmHeader() != null) {
				ebmHeader1 = refundCustomerPaymentResMsg.getEbmHeader();
			}
			ResponseDataArea responseDataArea = new ResponseDataArea();
			if (refundCustomerPaymentResMsg.getDataArea() != null) {
				responseDataArea = refundCustomerPaymentResMsg.getDataArea();
			}

			RefundCustomerPaymentResponse refundCustomerPaymentResponse = new RefundCustomerPaymentResponse();
			if (responseDataArea.getRefundCustomerPaymentResponse() != null) {
				refundCustomerPaymentResponse = responseDataArea.getRefundCustomerPaymentResponse();
			}

			TrackingRecord trackingRecord = new TrackingRecord();
			if (refundCustomerPaymentResponse.getTrackingRecord() != null) {
				trackingRecord = refundCustomerPaymentResponse.getTrackingRecord();
			}

			TrackingRecordIdentification trackingRecordIdentification = new TrackingRecordIdentification();
			if (trackingRecord.getIdentification() != null) {
				trackingRecordIdentification = trackingRecord.getIdentification();
			}

			if (CommonUtil.isNotNull(trackingRecordIdentification.getId())) {
				trackingId = Integer.parseInt(trackingRecordIdentification.getId());
				log.info("tracking_id in createResponseJSONForDepositReversalToFX--->>" + trackingId
						+ "and transaction_no-->>" + transaction_no);
			} else {
				trackingId = 0;
			}

			if (CommonUtil.isNotNull(trackingRecord.getSystemId())) {
				trackingServId = Integer.parseInt(trackingRecord.getSystemId());
				log.info("tracking_serv_id in createResponseJSONForDepositReversalToFX--->>" + trackingServId
						+ "and transaction_no-->>" + transaction_no);
			} else {
				trackingServId = 0;
			}

			Status status = new Status();
			if (refundCustomerPaymentResponse.getStatus() != null) {
				status = refundCustomerPaymentResponse.getStatus();
			}
			if (status != null) {
				if (CommonUtil.isNotNull(status.getStatusCode())) {
					String[] statusCodeArray = status.getStatusCode().split("-");
					statusCode = statusCodeArray[1] + "-" + statusCodeArray[2];
					log.info("status code in createResponseJSONForDepositReversalToFX-->>" + statusCode
							+ " and transaction_no " + transaction_no);
				}
				if (CommonUtil.isNotNull(status.getStatusCode())
						|| CommonUtil.isNotNull(status.getStatusDescription())) {
					status_description = statusCode + ":" + status.getStatusDescription();
					log.info("status_description in createResponseJSONForDepositReversalToFX-->>" + status_description
							+ " and transaction_no " + transaction_no);
				}
			}
			log.info("status_description after response in createResponseJSONForDepositReversalToFX-->>"
					+ status_description + "and transaction_no-->>" + transaction_no);

			Ext ext = new Ext();
			if (refundCustomerPaymentResponse.getExt()!= null) {
				ext=refundCustomerPaymentResponse.getExt();
				if (ext.getAttribute() != null) {
//					Attribute[] attribute = ext.getAttribute();
					List<Attribute> attribute = ext.getAttribute();
//					for (int i = 0; i < attribute.length; i++) {

//						Attribute at = attribute[i];
//
//						at.getName();
//						at.getValue();
//
//						if (attribute.length >= 5) {
//							annotation3 = attribute[2].getValue();
//							log.info("annotation3 is in createResponseJSONForDepositReversalToFX->"+annotation3);
//							annotation5 = attribute[4].getValue();
//							log.info("annotation5 is in createResponseJSONForDepositReversalToFX->"+annotation5);
//						}
//					}
					
					
					for (int i = 0; i < attribute.size(); i++) {

					Attribute at = attribute.get(i);

					at.getName();
					at.getValue();

					if (attribute.size() <= 5) {
						if(i==2){
							annotation3 = attribute.get(i).getValue();
							log.info("annotation3 is in createResponseJSONForDepositReversalToFX->"+annotation3);
						}
						if(i==3){
							annotation5 = attribute.get(i).getValue();
							log.info("annotation5 is in createResponseJSONForDepositReversalToFX->"+annotation5);
						}
						
					}
				}	
					
				}

			}

			RefundCustomerPaymentResponsePojo refundCustomerPaymentResponsePojo = new RefundCustomerPaymentResponsePojo();
			if (refundCustomerPaymentResponsePojo != null) {
				refundCustomerPaymentResMsg = refundCustomerPaymentResponsePojo.getRefundCustomerPaymentResMsg();
			}
		} else if (fault != null) {
			log.info(
					"In else loop when got error response from webservice in createResponseJSONForDepositReversalToFX --362 InT and transaction_no-->>"
							+ transaction_no);
			if (statusCode.contains(status_code_504) || statusCode.contains(status_code_500)) {
				// status_description = fault.getFaultstring();
				String fault_value = fault.getFaultstring();
				if (fault_value.length() > 999) {
					fault_value = fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description = status_description.replace("'", "");
				log.info("Status description is in createResponseJSONForDepositReversalToFX---> " + status_description
						+ "and transaction_no-->>" + transaction_no);
			} else if (statusCode.contains(status_code_502)) {
				// status_description = fault.getFaultstring();
				String fault_value = fault.getFaultstring();
				if (fault_value.length() > 999) {
					fault_value = fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description = status_description.replace("'", "");
				log.info("Status description is in createResponseJSONForDepositReversalToFX---> " + status_description
						+ "and transaction_no-->>" + transaction_no);

			} else if (statusCode.contains(status_code_400)) {
				// status_description = fault.getFaultstring();
				String fault_value = fault.getFaultstring();
				if (fault_value.length() > 999) {
					fault_value = fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description = status_description.replace("'", "");
				log.info("Status description is in createResponseJSONForDepositReversalToFX---> " + status_description
						+ "and transaction_no-->>" + transaction_no);

			} else {
				DetailFault detail = fault.getDetail();
				if (detail != null) {
					DepositRefundFault depositRefundFault = detail.getDepositRefundFault();
					if (depositRefundFault != null) {
						SoaFault soaFault = depositRefundFault.getSoaFault();
						if (soaFault != null) {
							// Added by geeta
							if (CommonUtil.isNotNull(soaFault.getSoaFaultCode())) {
								String[] soaFaultCodeArray = soaFault.getSoaFaultCode().split("-");
								statusCode = soaFaultCodeArray[1] + "-" + soaFaultCodeArray[2];
								log.info("soa fault status code in createResponseJSONForDepositReversalToFX----->>>"
										+ statusCode + " and transaction_no-->>" + transaction_no);

							}

							if (CommonUtil.isNotNull(soaFault.getFaultDescription())) {
								// status_description = statusCode + ":" +
								// soaFault.getFaultDescription();
								String fault_value = soaFault.getFaultDescription();
								if (fault_value.length() > 999) {
									fault_value = fault_value.substring(0, 1000);
								}
								status_description = statusCode + ":" + fault_value;
								status_description = status_description.replace("'", "");
								log.info("faultDescription in createResponseJSONForDepositReversalToFX---->"
										+ status_description + " and transaction_no-->>" + transaction_no);
							}
						}

					}

				}

			}

		}
		ClientDAO clientDAO = new ClientDAOImpl();
		String table_name = clientDAO.fetchTableName(FILE_IDENTIFIER_RDP);
		/*log.info("trans no in method createResponseJSONForDepositReversalToFX---->" + transaction_no + " and job_id-->"
				+ jobId);*/
		log.info("Before updateResponse in createResponseJSONForDepositReversalToFX and transaction_no-->>"
				+ transaction_no+ " and job_id-->"+ jobId);
		result = clientDAO.updateResponse(status_description, trackingId, trackingServId,
				depositReversalDetails.getTransactionNo(), table_name, viewId, jobId, annotation3, annotation5,
				faultTrace);
		log.info("After updateResponse in createResponseJSONForDepositReversalToFX result----->>>" + result
				+ "and transaction_no-->>" + transaction_no);
		log.info("END----in createResponseJSONForDepositReversalToFX method of DepositReversalDetailClient "
				+ faultDescription + "and transaction_no-->>" + transaction_no);
		return result;

	}

	/*public static void main(String[] args) throws Exception {
		DepositReversalDetailClient depositReversalDetailClient = new DepositReversalDetailClient();
		depositReversalDetailClient.createRequestJSONForDepositReversalToFX("8398005390", "DEPOSIT_REVERSAL_APS");
	}*/
}
