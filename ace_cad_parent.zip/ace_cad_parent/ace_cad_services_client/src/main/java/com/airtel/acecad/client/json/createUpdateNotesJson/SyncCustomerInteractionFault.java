package com.airtel.acecad.client.json.createUpdateNotesJson;


public class SyncCustomerInteractionFault {

	private  SoaFault  soaFault;

    public  SoaFault getSoaFault ()
    {
        return  soaFault;
    }

    public void setSoaFault ( SoaFault  soaFault)
    {
        this. soaFault =  soaFault;
    }

    @Override
    public String toString()
    {
        return "{\"soaFault\" : "+ soaFault+"}";
    }
}
