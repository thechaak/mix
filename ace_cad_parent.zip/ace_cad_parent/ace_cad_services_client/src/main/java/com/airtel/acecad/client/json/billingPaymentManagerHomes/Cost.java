package com.airtel.acecad.client.json.billingPaymentManagerHomes;

public class Cost {

	private String name;

    private String value;

    private String descriptionType;

    private String frequency;

    private String descriptionValue;

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getValue ()
    {
        return value;
    }

    public void setValue (String value)
    {
        this.value = value;
    }

   
    public String getFrequency ()
    {
        return frequency;
    }

    public void setFrequency (String frequency)
    {
        this.frequency = frequency;
    }

    public String getDescriptionType() {
		return descriptionType;
	}

	public void setDescriptionType(String descriptionType) {
		this.descriptionType = descriptionType;
	}

	public String getDescriptionValue() {
		return descriptionValue;
	}

	public void setDescriptionValue(String descriptionValue) {
		this.descriptionValue = descriptionValue;
	}

	@Override
    public String toString()
    {
        return "{\"name\" : \""+name+"\", \"value\" : \""+value+"\", \"descriptionType\" : \""+descriptionType+"\", \"frequency\" : \""+frequency+"\", \"descriptionValue\" : \""+descriptionValue+"\"}";
    }
}
