package com.airtel.acecad.client.common.json;

import com.airtel.acecad.client.json.adjustmentJson.TrackingRecordIdentification;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TrackingRecord
{
    private Identification identification;

    private String systemId;
    
    private TrackingRecordIdentification trackingRecordIdentification;
    
    private String userId;
    

    public Identification getIdentification ()
    {
        return identification;
    }

    public void setIdentification (Identification identification)
    {
        this.identification = identification;
    }

    public String getSystemId ()
    {
        return systemId;
    }

    public void setSystemId (String systemId)
    {
        this.systemId = systemId;
    }

    
    public TrackingRecordIdentification getTrackingRecordIdentification() {
		return trackingRecordIdentification;
	}

	public void setTrackingRecordIdentification(TrackingRecordIdentification trackingRecordIdentification) {
		this.trackingRecordIdentification = trackingRecordIdentification;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
    public String toString()
    {
        return "{\"identification\":"+identification+", \"systemId\":\""+systemId+"\",\"trackingRecordIdentification\":"+trackingRecordIdentification+",\"userId\":\""+userId+"\"}";
    }
}
