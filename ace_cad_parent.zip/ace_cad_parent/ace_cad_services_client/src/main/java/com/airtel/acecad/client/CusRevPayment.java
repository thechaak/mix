package com.airtel.acecad.client;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.airtel.acecad.client.dao.ClientDAO;
import com.airtel.acecad.client.dao.ClientDAOImpl;
import com.airtel.acecad.client.util.GlobalConstants;

public class CusRevPayment implements GlobalConstants {


private static Logger log = LogManager.getLogger("serviceClientUI");

	public void reversalPayment(String accountNum,String Identifier,int job_id) {

		log.info("START----in reversalPayment method of CusRevPayment");

		ClientDAO clientDao = new ClientDAOImpl();
		List postPaymentToFXRequestList = null;
		try {
			if("ADVICE_313".equalsIgnoreCase(Identifier)){
				postPaymentToFXRequestList=new ArrayList<>(); 
				postPaymentToFXRequestList.add("ADVICE_313");
			}else
			postPaymentToFXRequestList = clientDao.deriveRecordType(accountNum);

			//commented for new tag is to be added fro APP,ADVICE,Payment
			if (postPaymentToFXRequestList != null && postPaymentToFXRequestList.size() > 0) {/*
					if(postPaymentToFXRequestList.contains(REV)){
						log.info("START:Inside ' REV ' FILE INDENTIFIER-313 INTERFACE CALL");
						PaymentReversalDetailsClient paymentReversalDetailsClient = new PaymentReversalDetailsClient();
						paymentReversalDetailsClient.createRequestJSONForPaymentReversalToFX(accountNum,REV,0);
						log.info("END:Inside ' REV ' FILE INDENTIFIER-313 INTERFACE CALL");
						
					} if(postPaymentToFXRequestList.contains(REVERSAL)){
						
						log.info("START:Inside 'REVERSAL' FILE INDENTIFIER-313 INTERFACE CALL");
						PaymentReversalDetailsClient paymentReversalDetailsClient = new PaymentReversalDetailsClient();
						paymentReversalDetailsClient.createRequestJSONForPaymentReversalToFX(accountNum,REVERSAL,0);
						log.info("END:Inside 'REVERSAL' FILE INDENTIFIER-313 INTERFACE CALL");
						
					} if(postPaymentToFXRequestList.contains(APP)){
						
						log.info(
								"START:Inside APP FILE INDENTIFIER--313 INTERFACE CALL--> "
										+ accountNum);
						InvoicePaymentDetailsClient invoicePaymentDetailsClient = new InvoicePaymentDetailsClient();
						invoicePaymentDetailsClient.createRequestJSONForPostPaymentToFX(accountNum,APP,0);
						log.info("END:Inside APP FILE INDENTIFIER");
						
					} if(postPaymentToFXRequestList.contains("ADVICE_313")){
						log.info(
								"START:Inside PAYMENT FILE INDENTIFIER--313 INTERFACE CALL--> "
										+ accountNum);
						InvoicePaymentDetailsClient invoicePaymentDetailsClient = new InvoicePaymentDetailsClient();
						invoicePaymentDetailsClient.createRequestJSONForPostPaymentToFX(accountNum,"ADVICE_313",job_id);
						log.info("END:Inside PAYMENT FILE INDENTIFIER");
				}
					if(postPaymentToFXRequestList.contains(PAYMENT)){
						log.info(
								"START:Inside PAYMENT FILE INDENTIFIER--313 INTERFACE CALL--> "
										+ accountNum);
						InvoicePaymentDetailsClient invoicePaymentDetailsClient = new InvoicePaymentDetailsClient();
						invoicePaymentDetailsClient.createRequestJSONForPostPaymentToFX(accountNum,PAYMENT,0);
						log.info("END:Inside PAYMENT FILE INDENTIFIER");
				}
					if(postPaymentToFXRequestList.contains("REPOSTING")){
						log.info(
								"START:Inside PAYMENT FILE INDENTIFIER--313 INTERFACE CALL--> "
										+ accountNum);
						InvoicePaymentDetailsClient invoicePaymentDetailsClient = new InvoicePaymentDetailsClient();
						invoicePaymentDetailsClient.createRequestJSONForPostPaymentToFX(accountNum,"REPOSTING",0);
						log.info("END:Inside PAYMENT FILE INDENTIFIER");
				}

			*/}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		log.info("END----in reversalPayment method of CusRevPayment");

	}
	
	public static void main(String[] args) {
		CusRevPayment cusRevPayment = new CusRevPayment();
		cusRevPayment.reversalPayment("538526456",null,0);
	}

}
