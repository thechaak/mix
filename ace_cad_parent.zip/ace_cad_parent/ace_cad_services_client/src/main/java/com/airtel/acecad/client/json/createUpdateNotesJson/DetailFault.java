package com.airtel.acecad.client.json.createUpdateNotesJson;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY )
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DetailFault
{
    
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private SyncCustomerInteractionFault syncCustomerInteractionFault;

    public SyncCustomerInteractionFault getSyncCustomerInteractionFault ()
    {
        return syncCustomerInteractionFault;
    }

    public void setSyncCustomerInteractionFault (SyncCustomerInteractionFault syncCustomerInteractionFault)
    {
        this.syncCustomerInteractionFault = syncCustomerInteractionFault;
    }

  
	@Override
    public String toString()
    {
        return "{\"syncCustomerInteractionFault\":"+syncCustomerInteractionFault+"}";
    }
}