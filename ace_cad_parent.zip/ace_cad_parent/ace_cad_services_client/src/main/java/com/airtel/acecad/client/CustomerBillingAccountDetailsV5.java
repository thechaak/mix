package com.airtel.acecad.client;

import java.util.Arrays;

import org.apache.commons.codec.binary.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.airtel.acecad.client.dao.ClientDAO;
import com.airtel.acecad.client.dao.ClientDAOImpl;
import com.airtel.acecad.client.dao.ReversalDaoImpl;
import com.airtel.acecad.client.dao.ReverseDao;
import com.airtel.acecad.client.json.customerAccBillingDetails.AccountSummary;
import com.airtel.acecad.client.json.customerAccBillingDetails.Customer;
import com.airtel.acecad.client.json.customerAccBillingDetails.CustomerAccount;
import com.airtel.acecad.client.json.customerAccBillingDetails.CustomerBillingDetailResponse;
import com.airtel.acecad.client.json.customerAccBillingDetails.DataArea;
import com.airtel.acecad.client.json.customerAccBillingDetails.GetCustomerBillingAccountDetailsResponse;
import com.airtel.acecad.client.json.customerAccBillingDetails.Identification;
import com.airtel.acecad.client.json.customerAccBillingDetails.SoaFault;
import com.airtel.acecad.client.json.customerAccBillingDetails.Status;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.CustomResponseErrorHandler;
import com.airtel.acecad.client.util.EncryDecrypUtility;
import com.airtel.acecad.client.util.GenericConfiguration;
import com.airtel.acecad.client.util.GlobalConstants;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CustomerBillingAccountDetailsV5 implements GlobalConstants {
	private static Logger logger = LogManager.getLogger("serviceClientUI");
	ObjectMapper mapper = new ObjectMapper();
	public String postCustomerBillingAccountDetails(String transactionId){
		
		
		String result = EMPTY_STRING;
		String status_code = EMPTY_STRING;
		SoaFault fault;
		RestTemplate restTemplate = new RestTemplate();
		String domain = "B2C";
		String lob ="AES";
		String customerMigrated ="false";
		ClientDAO dao ;
		try {
			dao = new ClientDAOImpl();
			String invoiceNo =dao.getCustomerBillingAccDetail(transactionId);
			logger.info("getCustomerBillingAccDetail InvoiceNo  && transaction id ==>"+ invoiceNo +"<<==>>" +transactionId);
			String userpass = GenericConfiguration.getDescription("kenon.postPaymentToFX.userName") + ":"
					+ EncryDecrypUtility.decrypt(GenericConfiguration.getDescription("kenon.postPaymentToFX.password"));

			String clientURL = GenericConfiguration.getDescription("kenon.postCustomerBillingAccountdetailsV5.url") 
					+"domain="+domain+"&lob="+lob+"&consumerTransactionId="+transactionId+"&providerTransactionId="+transactionId+"&consumerName="+APS+"&programmeName=EAIMigration&customerMigrated="+customerMigrated+"&accountNumber="+invoiceNo+"&activity=Fetch_ExternalId";
			restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
			HttpHeaders headers = new HttpHeaders();
			logger.info("CustomerBillingAccountDetailsV5 clientURL is===>"+clientURL);

			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
					.setConnectTimeout(Integer.parseInt(GenericConfiguration.getDescription("connect_time_out")));

			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
					.setReadTimeout(Integer.parseInt(GenericConfiguration.getDescription("read_time_out")));

			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
			restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
			restTemplate.setErrorHandler(new CustomResponseErrorHandler());

			
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));

			HttpEntity<String> entity = new HttpEntity<>(headers);
			ResponseEntity<CustomerBillingDetailResponse> responsePojo = null;
			responsePojo = restTemplate.exchange(clientURL, HttpMethod.GET, entity, CustomerBillingDetailResponse.class);
			logger.info("responsePojo postUpdatePaymentReversalToFX---" + mapper.writeValueAsString(responsePojo));
			
			if (responsePojo != null) {
				status_code = responsePojo.getStatusCode().toString();
				if (HttpStatus.OK == responsePojo.getStatusCode()) {
					if (responsePojo.getBody().getDataArea() != null && responsePojo.getBody().getEbmHeader()!=null) {
						status_code = responsePojo.getStatusCode().toString();
						logger.info("RESPONSE success--postCustomerBillingAccountDetails --->> DataArea==> "+responsePojo.getBody().getDataArea() +" <<===>> "+ responsePojo.getBody().getEbmHeader());
								
					}
					 else {
							status_code = responsePojo.getStatusCode().toString();
							fault = responsePojo.getBody().getSoaFault();
							logger.info("Inside postCustomerBillingAccountDetails STATUS CODE ==>"+status_code+" : "
									+ responsePojo.getBody().getSoaFault());
						
					}
				} else {
						status_code = responsePojo.getStatusCode().toString();
						fault = responsePojo.getBody().getSoaFault();
						logger.info("Inside postCustomerBillingAccountDetails STATUS CODE ==>"+status_code+" : SoaFault==>"
								+ responsePojo.getBody().getSoaFault());
					
				}
				
				result =createResponseForFXRequest(responsePojo,transactionId,clientURL,status_code);
			} else {
				logger.info("getting null response from fx postCustomerBillingAccountDetails is null");
			}
		}
		catch(Exception e){
			
		}
		return result;
	}
	public String createResponseForFXRequest(ResponseEntity<CustomerBillingDetailResponse> response,String transactionId,String requestUrl,String statuCode ){
		String result = EMPTY_STRING;
		String faultDescription = EMPTY_STRING;
	    String invoiceNo="";
	    String statusCode ="";
	    
	    if(response!=null){
	    	DataArea dataArea = response.getBody().getDataArea();
	    	if(dataArea != null){
	    		GetCustomerBillingAccountDetailsResponse  accountDetails=dataArea.getGetCustomerBillingAccountDetailsResponse();
	    		if(accountDetails != null){
	    			AccountSummary accountSummary = accountDetails.getAccountSummary();
	    			if(accountSummary != null){
	    				Customer customer = accountSummary.getCustomer();
	    				if(customer != null){
	    					CustomerAccount[] customerAccount = customer.getCustomerAccount();
	    					if(customerAccount !=null && customerAccount.length>0){
	    						for(int i =0; i<customerAccount.length ;i++){
	    							Identification[] identification =customerAccount[i].getIdentification(); 
	    							if(identification != null && identification.length >0){
	    								for(int j= 0; i<identification.length ;i++){
	    									invoiceNo = identification[j].getId();
	    									logger.info("Invoice no from customerBillingAccountDetailsV5===>"+invoiceNo);
	    								}
	    							}
	    						}
	    					}
	    				}
	    			}
	    			
	    			Status status = accountDetails.getStatus();
	    			if (status != null) {
						if (CommonUtil.isNotNull(status.getStatusCode())) {
							String[] soaFaultCodeArray = status.getStatusCode().split("-");
							statusCode = soaFaultCodeArray[1] + "-" + soaFaultCodeArray[2];
						}
						if (CommonUtil.isNotNull(status.getStatusCode())
								|| CommonUtil.isNotNull(status.getStatusDescription())) {
							faultDescription = statusCode + ":" + status.getStatusDescription();
							logger.info("status_description in createResponseForFXRequest--->>"
									+ faultDescription);
						}
					}
	    			
	    		}
	    	}
	    	SoaFault fault = response.getBody().getSoaFault();
	    	if(fault != null){
	    		String[] soaFaultCodeArray = fault.getSoaFaultCode().split("-");
	    		statusCode = soaFaultCodeArray[1] + "-" + soaFaultCodeArray[2];
				String fault_value = fault.getFaultDescription();
				if (fault_value.length() > 999)
					fault_value = fault_value.substring(0, 1000);
	
				faultDescription = statusCode + ":" + fault_value;
				faultDescription = faultDescription.replace("'", "");
				logger.info("Status description is in createResponseForFXRequest when error response from webservice---> " + faultDescription);
	    	}
	    }
	    ReverseDao revDao = new ReversalDaoImpl();
		ClientDAO clientDao = new ClientDAOImpl();
		
		try {
			result = revDao.updateResonseCustomerBillingAccount(invoiceNo, transactionId, faultDescription );
			
			String statusDiscription = statuCode.equals("200")?"SUCCESS" :"FAILURE";
			clientDao.insertFxLog(statusDiscription,transactionId, requestUrl,  mapper.writeValueAsString(response),"AES", "APS", "BillingAccountDetails", null, null, null, null);
			logger.info("AFTER UPDATE RESPONSE FOR CustomerBillingAccountDetailsV5 =="+ result);
		} catch (Exception e) {
			logger.info("Exception occur while updateResonseCustomerBillingAccount()  ", e);		}
		logger.info(
				"After updateResponse in createResponseForFXRequest response-result----->>>" + result);

	    
		return result;
	}
	
	public static void main(String[] args) {
		new CustomerBillingAccountDetailsV5().postCustomerBillingAccountDetails("45");
	}

}
