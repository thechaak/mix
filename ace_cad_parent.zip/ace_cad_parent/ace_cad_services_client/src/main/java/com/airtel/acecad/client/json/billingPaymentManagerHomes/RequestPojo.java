package com.airtel.acecad.client.json.billingPaymentManagerHomes;

public class RequestPojo {

	private String consumerName;

    private String paymentMode;

    private String paymentDate;

    private OriginalServiceDetails originalServiceDetails;

    private String onBoardingDate;

    private String homesId;

    private String amountPaid;

    private String consumerTransactionId;

    public String getConsumerName ()
    {
        return consumerName;
    }

    public void setConsumerName (String consumerName)
    {
        this.consumerName = consumerName;
    }

    public String getPaymentMode ()
    {
        return paymentMode;
    }

    public void setPaymentMode (String paymentMode)
    {
        this.paymentMode = paymentMode;
    }

    public String getPaymentDate ()
    {
        return paymentDate;
    }

    public void setPaymentDate (String paymentDate)
    {
        this.paymentDate = paymentDate;
    }

    public OriginalServiceDetails getOriginalServiceDetails ()
    {
        return originalServiceDetails;
    }

    public void setOriginalServiceDetails (OriginalServiceDetails originalServiceDetails)
    {
        this.originalServiceDetails = originalServiceDetails;
    }

    public String getOnBoardingDate ()
    {
        return onBoardingDate;
    }

    public void setOnBoardingDate (String onBoardingDate)
    {
        this.onBoardingDate = onBoardingDate;
    }

    public String getHomesId ()
    {
        return homesId;
    }

    public void setHomesId (String homesId)
    {
        this.homesId = homesId;
    }

    public String getAmountPaid ()
    {
        return amountPaid;
    }

    public void setAmountPaid (String amountPaid)
    {
        this.amountPaid = amountPaid;
    }

    public String getConsumerTransactionId ()
    {
        return consumerTransactionId;
    }

    public void setConsumerTransactionId (String consumerTransactionId)
    {
        this.consumerTransactionId = consumerTransactionId;
    }

    @Override
    public String toString()
    {
        return "{\"consumerName\" : \""+consumerName+"\", \"paymentMode\" : \""+paymentMode+"\", \"paymentDate\" : \""+paymentDate+"\", \"originalServiceDetails\" : "+originalServiceDetails+", \"onBoardingDate\" : \""+onBoardingDate+"\", \"homesId\" : \""+homesId+"\", \"amountPaid\" : \""+amountPaid+"\", \"consumerTransactionId\" : \""+consumerTransactionId+"\"}";
    }
}
