package com.airtel.acecad.client.json.custAccountSummaryJson;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class EbmHeader1 {
	 private String consumerTransactionId;
	 
	 private String providerTransactionId;
	 
	  private String debugFlag;
	  
	  private String domain;
	  
	    public String getConsumerTransactionId ()
	    {
	        return consumerTransactionId;
	    }

	    public void setConsumerTransactionId (String consumerTransactionId)
	    {
	        this.consumerTransactionId = consumerTransactionId;
	    }

	    
	    public String getProviderTransactionId() {
			return providerTransactionId;
		}

		public void setProviderTransactionId(String providerTransactionId) {
			this.providerTransactionId = providerTransactionId;
		}

		
		public String getDebugFlag() {
			return debugFlag;
		}

		public void setDebugFlag(String debugFlag) {
			this.debugFlag = debugFlag;
		}

		public String getDomain() {
			return domain;
		}

		public void setDomain(String domain) {
			this.domain = domain;
		}

		@Override
	    public String toString()
	    {
	        return "{\"consumerTransactionId\": \""+consumerTransactionId+"\",\"providerTransactionId\": \""+providerTransactionId+"\",\"domain\":\" "+domain+"\",\"debugFlag\":\" "+debugFlag+"\"}";
	    
	}
}
