package com.airtel.acecad.client.json.custAccountSummaryJson;

public class PartyAccount {

	 private String accountCategory;

	    private PartyAccountIdentification identification;

	    public String getAccountCategory ()
	    {
	        return accountCategory;
	    }

	    public void setAccountCategory (String accountCategory)
	    {
	        this.accountCategory = accountCategory;
	    }

	    public PartyAccountIdentification getIdentification() {
			return identification;
		}

		public void setIdentification(PartyAccountIdentification identification) {
			this.identification = identification;
		}

		@Override
	    public String toString()
	    {
	        return "{\"accountCategory\" : \""+accountCategory+"\", \"identification\" : "+identification+"}";
	    }
}
