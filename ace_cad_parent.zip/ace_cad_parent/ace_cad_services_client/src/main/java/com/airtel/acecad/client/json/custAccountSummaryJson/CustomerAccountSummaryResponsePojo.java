package com.airtel.acecad.client.json.custAccountSummaryJson;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CustomerAccountSummaryResponsePojo {

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonProperty("Fault")
	  private Fault Fault;

	    public Fault getFault ()
	    {
	        return Fault;
	    }

	    public void setFault (Fault Fault)
	    {
	        this.Fault = Fault;
	    }
	
	private GetCustomerAccountSummaryResMsg getCustomerAccountSummaryResMsg;

    public GetCustomerAccountSummaryResMsg getGetCustomerAccountSummaryResMsg ()
    {
        return getCustomerAccountSummaryResMsg;
    }

    public void setGetCustomerAccountSummaryResMsg (GetCustomerAccountSummaryResMsg getCustomerAccountSummaryResMsg)
    {
        this.getCustomerAccountSummaryResMsg = getCustomerAccountSummaryResMsg;
    }

   /* @Override
    public String toString()
    {
        return "{\"getCustomerAccountSummaryResMsg\" : "+getCustomerAccountSummaryResMsg+"}";
    }*/
}
