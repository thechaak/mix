package com.airtel.acecad.client.json.custAccountSummaryJson;


public class CustCustomerAccount {

	 private String category;

	    private String currencyCode;

	    private ParentAccount parentAccount;

	    private String accountStatus;

	    private Identification[] identification;

	    private String activeDate;

	    private String accountType;

	    private String inactiveDate;

	    private String costCenter;

	    private String revRecCostCenter;

	    private String marketCode;

	 
	  public String getCategory() {
			return category;
		}

		public void setCategory(String category) {
			this.category = category;
		}


		public String getCurrencyCode() {
			return currencyCode;
		}


		public void setCurrencyCode(String currencyCode) {
			this.currencyCode = currencyCode;
		}


		public ParentAccount getParentAccount() {
			return parentAccount;
		}


		public void setParentAccount(ParentAccount parentAccount) {
			this.parentAccount = parentAccount;
		}


		public String getAccountStatus() {
			return accountStatus;
		}


		public void setAccountStatus(String accountStatus) {
			this.accountStatus = accountStatus;
		}


		public Identification[] getIdentification() {
			return identification;
		}


		public void setIdentification(Identification[] identification) {
			this.identification = identification;
		}


		public String getActiveDate() {
			return activeDate;
		}


		public void setActiveDate(String activeDate) {
			this.activeDate = activeDate;
		}


		public String getAccountType() {
			return accountType;
		}


		public void setAccountType(String accountType) {
			this.accountType = accountType;
		}


		public String getInactiveDate() {
			return inactiveDate;
		}


		public void setInactiveDate(String inactiveDate) {
			this.inactiveDate = inactiveDate;
		}


		public String getCostCenter() {
			return costCenter;
		}


		public void setCostCenter(String costCenter) {
			this.costCenter = costCenter;
		}


		public String getRevRecCostCenter() {
			return revRecCostCenter;
		}


		public void setRevRecCostCenter(String revRecCostCenter) {
			this.revRecCostCenter = revRecCostCenter;
		}


		public String getMarketCode() {
			return marketCode;
		}


		public void setMarketCode(String marketCode) {
			this.marketCode = marketCode;
		}


	    @Override
	    public String toString()
	    {
	        return "{\"category\" : \""+category+"\",\"currencyCode\" : \""+currencyCode+"\", \"parentAccount\" : "+parentAccount+", \"accountStatus\" : \""+accountStatus+"\", \"identification\" : "+identification+", \"activeDate\" : \""+activeDate+"\", \"accountType\" : \""+accountType+"\", \"inactiveDate\" : \""+inactiveDate+"\", \"costCenter\" : \""+costCenter+"\", \"revRecCostCenter\" : \""+revRecCostCenter+"\", \"marketCode\" : \""+marketCode+"\"}";
	    }
}
