package com.airtel.acecad.client.json.adjustmentJson;

public class PartyPayment {

	private String revRevCostCenter;

    private String amount;

    private String transSign;

    private String paymentDirection;

    private String reasonCode;

    private String transCode;
    
    private String remarks;
    
    private String effectiveDate;

    public String getRevRevCostCenter ()
    {
        return revRevCostCenter;
    }

    public void setRevRevCostCenter (String revRevCostCenter)
    {
        this.revRevCostCenter = revRevCostCenter;
    }

    public String getAmount ()
    {
        return amount;
    }

    public void setAmount (String amount)
    {
        this.amount = amount;
    }

    public String getTransSign ()
    {
        return transSign;
    }

    public void setTransSign (String transSign)
    {
        this.transSign = transSign;
    }

    public String getPaymentDirection ()
    {
        return paymentDirection;
    }

    public void setPaymentDirection (String paymentDirection)
    {
        this.paymentDirection = paymentDirection;
    }

    public String getReasonCode ()
    {
        return reasonCode;
    }

    public void setReasonCode (String reasonCode)
    {
        this.reasonCode = reasonCode;
    }

    public String getTransCode ()
    {
        return transCode;
    }

    public void setTransCode (String transCode)
    {
        this.transCode = transCode;
    }

    
    public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	@Override
    public String toString()
    {
        return "{\"revRevCostCenter\" : \""+revRevCostCenter+"\", \"amount\" : \""+amount+"\", \"transSign\" : \""+transSign+"\", \"paymentDirection\" : \""+paymentDirection+"\",\"remarks\" :\""+remarks+"\",  \"reasonCode\" : \""+reasonCode+"\",\"effectiveDate\" : \""+effectiveDate+"\", \"transCode\" : \""+transCode+"\"}";
    }
}
