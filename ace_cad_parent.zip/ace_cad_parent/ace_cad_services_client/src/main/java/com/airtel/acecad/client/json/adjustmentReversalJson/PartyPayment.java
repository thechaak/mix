package com.airtel.acecad.client.json.adjustmentReversalJson;

public class PartyPayment {

	//private String revRevCostCenter;

   // private String amount;

    //private String transSign;

    private String paymentDirection;

    //private String reasonCode;

    //private String transCode;

    
    public String getPaymentDirection ()
    {
        return paymentDirection;
    }

    public void setPaymentDirection (String paymentDirection)
    {
        this.paymentDirection = paymentDirection;
    }


    @Override
    public String toString()
    {
        //return "{\"revRevCostCenter\" : \""+revRevCostCenter+"\", \"amount\" : \""+amount+"\", \"transSign\" : \""+transSign+"\", \"paymentDirection\" : \""+paymentDirection+"\", \"reasonCode\" : \""+reasonCode+"\", \"transCode\" : \""+transCode+"\"}";
    	 return "{\"paymentDirection\" : \""+paymentDirection+"\"}";
    }
}
