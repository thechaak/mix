package com.airtel.acecad.client.common.json;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class EbmHeader
{
	//private String domain;
	
    private String consumerName;
    
    private String lob;
    
   // private String subLob;

    private String customerMigrated;
    
    //private String debugFlag;
    
    //private String isRepushed;
    
    //private String repushedCount;

    private String consumerTransactionId;
    
    //private String providerTransactionId; 

    //private String programmeName;
    

	public String getConsumerTransactionId() {
		return consumerTransactionId;
	}

	public void setConsumerTransactionId(String consumerTransactionId) {
		this.consumerTransactionId = consumerTransactionId;
	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}


	public String getConsumerName() {
		return consumerName;
	}

	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}

	
	public String getCustomerMigrated() {
		return customerMigrated;
	}

	public void setCustomerMigrated(String customerMigrated) {
		this.customerMigrated = customerMigrated;
	}

	@Override
    public String toString()
    {
        return "{\"lob\" : \""+lob+"\",\"consumerName\":\" "+consumerName+"\", \"customerMigrated\" : \""+customerMigrated+"\"}";
    }
	/*@Override
    public String toString()
    {
        return "{\"domain\" : \""+domain+"\",\"consumerName\":\" "+consumerName+"\", \"lob\" : \""+lob+"\",\"subLob\" : \""+subLob+"\", \"debugFlag\" : \""+debugFlag+"\", \"isRepushed\" : \""+isRepushed+"\", \"repushedCount\" : \""+repushedCount+"\", \"customerMigrated\" : \""+customerMigrated+"\",  \"consumerTransactionId\": \""+consumerTransactionId+"\",\"providerTransactionId\": \""+providerTransactionId+"\", \"programmeName\":\""+programmeName+"\"}";
    }
*/

}