package com.airtel.acecad.client;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.commons.codec.binary.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.airtel.acecad.client.dao.ClientDAO;
import com.airtel.acecad.client.dao.ClientDAOImpl;
import com.airtel.acecad.client.dto.PaymentHistoryBaseResponse;
import com.airtel.acecad.client.json.CustomerInvoiceSummaryV5.CustomerInvoiceSummaryResponse;
import com.airtel.acecad.client.json.PaymentHistoryV5.CustomerAccount;
import com.airtel.acecad.client.json.PaymentHistoryV5.CustomerBill;
import com.airtel.acecad.client.json.PaymentHistoryV5.DataArea;
import com.airtel.acecad.client.json.PaymentHistoryV5.EbmHeader;
import com.airtel.acecad.client.json.PaymentHistoryV5.GetPaymentHistoryResponse;
import com.airtel.acecad.client.json.PaymentHistoryV5.Identification;
import com.airtel.acecad.client.json.PaymentHistoryV5.Identification1;
import com.airtel.acecad.client.json.PaymentHistoryV5.PartyPayment;
import com.airtel.acecad.client.json.PaymentHistoryV5.Payment;
import com.airtel.acecad.client.json.PaymentHistoryV5.PaymentHistoryResponse;
import com.airtel.acecad.client.json.PaymentHistoryV5.SoaFault;
import com.airtel.acecad.client.json.PaymentHistoryV5.Status;
import com.airtel.acecad.client.json.PaymentHistoryV5.TrackingRecord;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.CommonValidator;
import com.airtel.acecad.client.util.ConnectionUtil;
import com.airtel.acecad.client.util.CustomResponseErrorHandler;
import com.airtel.acecad.client.util.EncryDecrypUtility;
import com.airtel.acecad.client.util.GenericConfiguration;
import com.airtel.acecad.client.util.GlobalConstants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class GetPaymentHistoryClientV5 implements GlobalConstants {
private static final Logger log = LogManager.getLogger("serviceClientUI");
private static final ObjectMapper mapper= new ObjectMapper();
	public PaymentHistoryBaseResponse postPaymentHistoryClientToFX(String accountNo,String revOrSrFalg,String reconcileId){
		log.info("START----in updatePaymentHistoryDetails method of PaymentHistoryDetailsClient");

		SoaFault fault = null;
		String result = EMPTY_STRING;
		String status_code = EMPTY_STRING;
		String exceptionMessage=null;
		boolean exceFlag=false;
		PaymentHistoryBaseResponse baseResponse =null;
		
		String fromDate="1990-01-01T23:59:59";
		String toDate ="";
		
		Date d= new  Date();
		Calendar c = Calendar.getInstance(); 
		c.setTime(d); 
		c.add(Calendar.DATE, 1);
		d = c.getTime();
		toDate= new SimpleDateFormat("yyyy-MM-dd").format(d);
		toDate+="T23:59:59";
		

		try {

			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			String clientURL ="";
			
			clientURL= GenericConfiguration.getDescription("kenon.postPaymentHistoryToFXV5.url")
					+"domain=B2C&lob=Mobility&subLob=Postpaid&consumerTransactionId=11343"
					+"&consumerName=APS&programmeName=EAIMigration&customerMigrated=false&accountId="+accountNo+"&msisdn=9740232322"
					+"&billNo=&billResets=&origBillNo=&origbillResets=origTrackingId&origTrackingIdServ=&trackingId=&trackingIdServ=&PaymenttransferFlag=&lowerLimit=&upperLimit=";
			log.info("clientURL in updatePaymentHistoryDetails  INT-219 URL-->> "+clientURL);

			String userpass = GenericConfiguration.getDescription("kenon.postPaymentToFX.userName") + ":"
					+ EncryDecrypUtility.decrypt(GenericConfiguration.getDescription("kenon.postPaymentToFX.password"));


			headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);

			restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
		
	
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
					.setConnectTimeout(Integer.parseInt(GenericConfiguration.getDescription("connect_time_out")));
	
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
					.setReadTimeout(Integer.parseInt(GenericConfiguration.getDescription("read_time_out")));
	
			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
			restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
			restTemplate.setErrorHandler(new CustomResponseErrorHandler());
	
			
	
			HttpEntity<String> entity = new HttpEntity<>(headers);
			ResponseEntity<PaymentHistoryResponse> responsePojo = null;
			responsePojo = restTemplate.exchange(clientURL, HttpMethod.GET, entity, PaymentHistoryResponse.class);
			log.info("response  For Payment Find INT 219---" + mapper.writeValueAsString(responsePojo));
	
			if(responsePojo != null){

				if (HttpStatus.OK ==responsePojo.getStatusCode()) {
					if(responsePojo.getBody().getEbmHeader()!=null && responsePojo.getBody().getDataArea()!=null)
					{
						log.info("success --updatePaymentHistoryDetails---EBMHeader>>"+ mapper.writeValueAsString(responsePojo.getBody().getEbmHeader()));
						log.info("success --updatePaymentHistoryDetails---Data Area>>"+ mapper.writeValueAsString(responsePojo.getBody().getDataArea()));
					} else{
						status_code = responsePojo.getStatusCode().toString();
						System.out.println("status_code-->> "+status_code);
						fault = responsePojo.getBody().getSoaFault();
						log.info("paymentHistoryResponsePojo in updatePaymentHistoryDetails in http code is not 200-->>" + fault);
					}
				}
				else {

					status_code = responsePojo.getStatusCode().toString();
					System.out.println("status_code-->> "+status_code);
					fault = responsePojo.getBody().getSoaFault();
					log.info("paymentHistoryResponsePojo in updatePaymentHistoryDetails-->>" + fault);

				}
				log.info("Before updatePaymentHistoryDetails in PaymentHistoryDetailsClient ");
				if(revOrSrFalg.equalsIgnoreCase("REV")){
				baseResponse = createResponseJSONForFetchPaymentHistory(responsePojo, fault,
						accountNo, status_code,clientURL);
				}
				else{
					baseResponse = createResponseJSONForFetchPaymentHistory2(responsePojo, fault,
							accountNo, status_code,clientURL,reconcileId);
				}
				log.info("After updatePaymentHistoryDetails in PaymentHistoryDetailsClient result-->>"+ baseResponse);

			}
			else{
				log.info("IN method  updatePaymentHistoryDetails response pojo is null" );
			}
		} catch (Exception e) {
			log.info("Got exception while processing",e);
			if (e.getCause().toString().contains(CONNECT_TEXT)) {
				exceptionMessage = CONNECT_TEXT;
			}
			else if(e.getCause().toString().contains(READ_TEXT)){
				exceptionMessage = READ_TEXT;
			}
			else{
				exceptionMessage=e.getMessage();
			}

			exceFlag=true;
		}

		if(exceFlag){
			String faultMsg="Error: Got "+exceptionMessage+" exception while processing";
			if(CONNECT_TEXT.equalsIgnoreCase(exceptionMessage)){
				System.out.println("here" +faultMsg);
				result=updatedDetails(faultMsg, accountNo);
			}
			else{
				System.out.println("here" +faultMsg);
				result=insertDataInSRDetails(faultMsg, accountNo,faultMsg,"");
			}

		}
		baseResponse.setResult(result);
		log.info("END----in updatePaymentHistoryDetails method of PaymentHistoryDetailsClient");
		return baseResponse;

		
	}
	private String updatedDetails(String faultMsg, String accountNo) {
		log.info("START----in insertDataInSRDetails method of PaymentHistoryDetailsClient");
		Connection con = null;
		PreparedStatement ps = null;

		String retVal=null;

		try {

			if (!CommonValidator.isNull(accountNo)) {

				String query = "UPDATE REFUND_PAYMENT_APS set PAYMENT_HISTORY=? ,status_description=?,"
						+ " job_id=-1,modified_date=systimestamp  WHERE ACCOUNT_no=? "
						+ " AND SR_CATEGORY LIKE '%Refund%' AND pending_approval_level in (10,9,1) and file_id>0 AND"
						+ " status_code in (1,2) AND (PAYMENT_HISTORY IS NULL OR PAYMENT_HISTORY LIKE 'Error%')";
				log.info("query of payment 219-->> " + query);
				con = ConnectionUtil.getConnection();
				ps = con.prepareStatement(query);
				ps.setString(1, faultMsg);
				ps.setString(2, faultMsg);
				ps.setString(3, accountNo);
				int val = ps.executeUpdate();
				retVal = "Rows updated " + val;

			}
			log.info("ret--->>>"+retVal);

		} catch (Exception e) {
			log.info("Exception--->",e);
		} finally {

			try {
				if (con != null) {
					con.close();
					ps.close();

				}
			} catch (SQLException e) {
				log.info("Exception--->",e);
			}
		}
		log.info("END----in insertDataInSRDetails method of PaymentHistoryDetailsClient");

		return retVal;

	}
	private String insertDataInSRDetails(String rowData, String accountNo, String servfault,String maxPostDate) {
		log.info("START----in insertDataInSRDetails method of PaymentHistoryDetailsClient");
		Connection con = null;
		PreparedStatement ps = null;

		String retVal=null;

		try {

			if (!CommonValidator.isNull(accountNo)) {

				String query = "UPDATE REFUND_PAYMENT_APS set PAYMENT_HISTORY='"+rowData+ "' ,status_description=?, modified_date=systimestamp,PAYMENT_HISTORY_DATE=(TO_DATE('"+maxPostDate+"', 'yyyy-mm-dd'))  WHERE ACCOUNT_no=? "
						+ " AND SR_CATEGORY LIKE '%Refund%' AND pending_approval_level in (10,9,1) and file_id>0 AND"
						+ " status_code in (1,2) AND (PAYMENT_HISTORY IS NULL OR PAYMENT_HISTORY LIKE 'Error%')";
				log.info("query of payment 219-->> " + query);
				con = ConnectionUtil.getConnection();
				ps = con.prepareStatement(query);
				//ps.setString(1, rowData);
				ps.setString(1, servfault);
				ps.setString(2, accountNo);
				int val = ps.executeUpdate();
				retVal = "Rows updated " + val;

			}
			log.info("ret--->>>"+retVal);

		} catch (Exception e) {
			log.info("Exception--->",e);
		} finally {

			try {
				if (con != null) {
					con.close();
					ps.close();

				}
			} catch (SQLException e) {
				log.info("Exception--->",e);
			}
		}
		log.info("END----in insertDataInSRDetails method of PaymentHistoryDetailsClient");

		return retVal;
	}
	private PaymentHistoryBaseResponse createResponseJSONForFetchPaymentHistory(ResponseEntity<PaymentHistoryResponse> responsePojo,
			SoaFault fault, String accountNo, String status_code, String clientURL) {
		log.info("START----in createResponseJSONForFetchPaymentHistory method of GetPaymentHistoryDetailsClientv5");

		String result = EMPTY_STRING;
		String status_description = EMPTY_STRING;
		String faultDescription = EMPTY_STRING;
		String rowValues=EMPTY_STRING;
		String statusCode =EMPTY_STRING;
		String remarks = EMPTY_STRING;
		String maxPostDate = EMPTY_STRING;
		PaymentHistoryBaseResponse baseResponse = new PaymentHistoryBaseResponse();
		ClientDAO dao = new ClientDAOImpl();
        try{
		if(responsePojo != null){
			SortedSet<Date> set = new TreeSet<>();
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			if(responsePojo.getBody().getEbmHeader()!=null && responsePojo.getBody().getDataArea()!=null){
				String consumerTransactionId=null;
				EbmHeader ebmHeader = responsePojo.getBody().getEbmHeader();
				if(CommonUtil.isNotNull(ebmHeader.getConsumerTransactionId())){
					consumerTransactionId =ebmHeader.getConsumerTransactionId();
					log.info("consumerTransactionId in Response  GetPaymentHistoryDetailsClientV5-->> "+consumerTransactionId);
				}
					Status status=null;
					CustomerBill customerBill=null;
					PartyPayment partyPayment=null;
					TrackingRecord trackingRecord=null;
					
					if(responsePojo.getBody().getDataArea().getGetPaymentHistoryResponse()!=null){
						GetPaymentHistoryResponse paymentHistoryResponse= responsePojo.getBody().getDataArea().getGetPaymentHistoryResponse();
						if(paymentHistoryResponse.getPayment()!= null && paymentHistoryResponse.getPayment().size()>0){
							List<Payment> paymentList = paymentHistoryResponse.getPayment();
							log.info("payment.length in Response GetPaymentHistoryDetailsClientV5-->> "+paymentList.size());
							if(!paymentList.isEmpty()){
								int count=0;
								for(Payment payment:paymentList){
									/*if(payment != null){
										
									}*/
									count++;
									rowValues=rowValues+"";
									customerBill =payment.getCustomerBill();
									partyPayment = payment.getPartyPayment();
									trackingRecord = payment.getTrackingRecord();
									if(customerBill !=null){
										if(!CommonValidator.isNull(customerBill.getBillRefResets())){
											//rowValues=rowValues+"billRefResets:"+customerBill.getBillRefResets();
										}
										if(!CommonValidator.isNull(customerBill.getOrigBillRefResets())){
											//rowValues=rowValues+",origBillRefResets:"+customerBill.getOrigBillRefResets();
										}
									}
									
									if(partyPayment !=null){
										if(!CommonValidator.isNull(partyPayment.getAmount()))
											rowValues+="Amount :"+(Double.valueOf(partyPayment.getAmount())/100);
										
										if(!CommonValidator.isNull(partyPayment.getPaymentDate())){
											//rowValues=rowValues+",paymentDate:"+partyPayment.getPaymentDate();
										}
										if(!CommonValidator.isNull(partyPayment.getRemarks())){
											log.info("getRemarks()--->>"+partyPayment.getRemarks());
											remarks = partyPayment.getRemarks();
											rowValues=rowValues+",description:"+partyPayment.getRemarks();
										}
										
										if(!CommonValidator.isNull(partyPayment.getPaymentMethod())){

											if(partyPayment.getPaymentMethod()=="1"){
												//rowValues=rowValues+",paymentMethod:CHEQUE";
											}
											if(partyPayment.getPaymentMethod()=="2"){
												//rowValues=rowValues+",paymentMethod:NEFT";
											}
										}
										
										if(!CommonValidator.isNull(partyPayment.getPostDate())){
											log.info("partyPayment.getPostDate()--->>"+partyPayment.getPostDate());

											String partyPaymentDate=partyPayment.getPostDate();
											if(partyPaymentDate.length()>10){
												partyPaymentDate=partyPaymentDate.substring(0,10);
												if(remarks!="" && remarks!=null){
													if(remarks.equalsIgnoreCase("Payment ECS")|| remarks.equalsIgnoreCase("Payment - Chq") || remarks.equalsIgnoreCase(" Deposit Payment")){
														Date date = dateFormat.parse(partyPaymentDate);
														set.add(date);
													}
												}
												
											}
											else{
												if(remarks!="" && remarks!=null){
													if(remarks.equalsIgnoreCase("Payment ECS")|| remarks.equalsIgnoreCase("Payment - Chq") || remarks.equalsIgnoreCase(" Deposit Payment")){
														Date date = dateFormat.parse(partyPaymentDate);
														set.add(date);
													}
												}
											}
											
											rowValues=rowValues+",postDate:"+partyPaymentDate;

										}
										
										if(!CommonValidator.isNull(partyPayment.getChequeNumber())){
											rowValues=rowValues+",chequeNumber:"+partyPayment.getChequeNumber()+" '||chr(10)||chr(10)||' ";
										}
									}
									
									if(trackingRecord != null){
										if(!CommonValidator.isNull(trackingRecord.getSystemId())){
											//rowValues=rowValues+",systemId:"+trackingRecord.getSystemId();
										}
										if(trackingRecord.getIdentification()!=null){
											if(!CommonValidator.isNull(trackingRecord.getIdentification().getId())){

												//rowValues=rowValues+",identification:"+identification.getId();
											}
										}
										
									}
									
									if(count==3){
										if(set.size()>0)
											maxPostDate=dateFormat.format(set.last());
										break;
									}
									
								}
							}
							status = responsePojo.getBody().getDataArea().getGetPaymentHistoryResponse().getStatus();
							if(status != null){
								if(status.getStatusCode()!=null){
									String[] code=status.getStatusCode().split("-");
									String code1=null;

									if(code.length>=3){
										code1=code[1]+"-"+code[2];						
									}				
									status_description = code1 + " QI :" + status.getStatusDescription();
									log.info("status_description in createResponseJSONForFetchPaymentHistory--->>" + status_description);
								
								}
							}
						}
						
					}
					log.info("complete Row-->> "+rowValues);
					log.info("Max date for paymet post ===>"+maxPostDate);

				}
				
			}
			else if(responsePojo.getBody().getSoaFault()!=null){
				SoaFault soaFault=responsePojo.getBody().getSoaFault();
				log.info("createResponseForFX method  when ebmHeader is null from resonse===");
				String[] soaFaultCodeArray = soaFault.getSoaFaultCode().split("-");
				statusCode = soaFaultCodeArray[1] + "-" + soaFaultCodeArray[2];
				String fault_value = soaFault.getFaultDescription();
				if (fault_value.length() > 999)
					fault_value = fault_value.substring(0, 1000);

				faultDescription ="Error->"+statusCode + " QI:" + fault_value;
				faultDescription= faultDescription.replace("'", "");
				log.info("Status description is in createResponseJSONForPaymentFind when error response from webservice---> " + faultDescription);
			
			}
			
			if(!CommonValidator.isNull(faultDescription)){
				String statusCod =status_code=="200"?"SUCCESS":"FAILED";
				try {
					result=insertDataInSRDetails(faultDescription, accountNo,faultDescription,"");
					dao.insertFxLog(statusCod, null, clientURL, mapper.writeValueAsString(responsePojo), null, null, "INT-219", null, null, null, null);
				} catch (JsonProcessingException e) {
					log.error("Exception occur in createResponseJSONForPaymentFind()==",e);
				}
			}
			else{
				try{
					result=insertDataInSRDetails(rowValues,accountNo,status_description,maxPostDate);
					dao.insertFxLog(status_code, null, clientURL, mapper.writeValueAsString(responsePojo), null, null, "INT-219", null, null, null, null);
				}
				catch(Exception e){
					log.info("exception  occur while updating data in db createResponseJSONForFetchPaymentHistory()", e);
				}
			}
			baseResponse.setResult(result);
        }
        catch(Exception e){
        	log.info("Exception occur in INT-219 createResponseJSONForFetchPaymentHistory()", e);
        }
		return baseResponse;
	}
    public PaymentHistoryBaseResponse createResponseJSONForFetchPaymentHistory2(ResponseEntity<PaymentHistoryResponse> responsePojo,
			SoaFault fault, String accountNo, String status_code, String clientURL,String reconcileId){
    	
    	String result = EMPTY_STRING;
		String status_description = EMPTY_STRING;
		String faultDescription = EMPTY_STRING;
		String rowValues=EMPTY_STRING;
		String statusCode =EMPTY_STRING;
		String reconcileFlag =EMPTY_STRING;
		List<Object> list=new ArrayList<Object>();
		PaymentHistoryBaseResponse baseResponse = new PaymentHistoryBaseResponse();
		Object[] returnObject=new Object[2];
		String trackingId ="" ;
		String trackingIdServ ="" ;
		String postDate=EMPTY_STRING;
		
		try{
    	if(responsePojo!=null){
		if(responsePojo.getBody().getEbmHeader()!= null && responsePojo.getBody().getDataArea()!=null){
			String consumerTransactionId= EMPTY_STRING;
			EbmHeader ebmHeader =responsePojo.getBody().getEbmHeader();
			
			if(CommonUtil.isNotNull(ebmHeader.getConsumerTransactionId())){
				rowValues=rowValues+"consumerTransactionId:"+ebmHeader.getConsumerTransactionId();
				consumerTransactionId =ebmHeader.getConsumerTransactionId();
				log.info("consumerTransactionId in Response  GetPaymentHistoryDetailsClientV5 Method 2-->> "+consumerTransactionId);
			}
				
			Status status=null;
			CustomerBill customerBill=null;
			PartyPayment partyPayment=null;
			TrackingRecord trackingRecord=null;
			CustomerAccount customerAccount =null;

			if(responsePojo.getBody().getDataArea().getGetPaymentHistoryResponse()!=null){
				DataArea dataArea = responsePojo.getBody().getDataArea();
				GetPaymentHistoryResponse paymentHistoryResponse = dataArea.getGetPaymentHistoryResponse();
				if(paymentHistoryResponse.getPayment()!= null && paymentHistoryResponse.getPayment().size()>0){
					
					List<Payment> paymentList =paymentHistoryResponse.getPayment();
					if(!paymentList.isEmpty()){
						log.info("payment.length11-->> "+paymentList.size());
						for(Payment payment : paymentList){
							Object[] obj=new Object[3];
							customerBill = payment.getCustomerBill();
							partyPayment = payment.getPartyPayment();
							customerAccount =payment.getCustomerAccount();
							trackingRecord=  payment.getTrackingRecord();
							
							if(partyPayment!=null){
								if(!CommonValidator.isNull(partyPayment.getAmount())){
									rowValues=rowValues+",amount:"+partyPayment.getAmount();

								}
								obj[0]=partyPayment.getAmount();
								if(!CommonValidator.isNull(partyPayment.getPaymentDate())){
									rowValues=rowValues+",paymentDate:"+partyPayment.getPaymentDate();
								}
								if(!CommonValidator.isNull(partyPayment.getDescription())){
									rowValues=rowValues+",description:"+partyPayment.getDescription();
								}
								if(!CommonValidator.isNull(partyPayment.getPaymentMethod())){

									if(partyPayment.getPaymentMethod()=="1"){
										rowValues=rowValues+",paymentMethod:CHEQUE";
									}
									if(partyPayment.getPaymentMethod()=="2"){
										rowValues=rowValues+",paymentMethod:NEFT";
									}

								}
								if(!CommonValidator.isNull(partyPayment.getPostDate())){
									rowValues=rowValues+",postDate:"+partyPayment.getPostDate();
									postDate=partyPayment.getPostDate();
									log.info("Post date from payment history 219--->>"+postDate);
								}
								if(!CommonValidator.isNull(partyPayment.getChequeNumber())){
									rowValues=rowValues+",chequeNumber:"+partyPayment.getChequeNumber();
								}
								
								if(!CommonValidator.isNull(partyPayment.getSubmitter())){
									rowValues=rowValues+",Submitter:"+partyPayment.getSubmitter();
									log.info("Submitter from payment history 219--->>"+partyPayment.getSubmitter());

									if(partyPayment.getSubmitter().equalsIgnoreCase(reconcileId)){
										reconcileFlag="true";
									}else{
										reconcileFlag="false";
									}
									
								}
								
								log.info("reconcileFlag from payment history 219--->>"+reconcileFlag);
							}
							
							if(trackingRecord!=null){
								if(!CommonValidator.isNull(trackingRecord.getSystemId())){
									rowValues=rowValues+",systemId:"+trackingRecord.getSystemId();
									trackingIdServ = trackingRecord.getSystemId();
									log.info("trackingIdServ from payment history 219--->>"+trackingIdServ);

								}
								obj[1]=trackingRecord.getSystemId();
								 Identification1 identification=trackingRecord.getIdentification();

								if(!CommonValidator.isNull(identification.getId())){
									rowValues=rowValues+",identification:"+identification.getId();
									trackingId =identification.getId();
									log.info("trackingId from payment history 219--->>"+trackingId);

								}
								obj[2]=identification.getId();
							}
							
							list.add(obj);
							
							updateReconcileRecord(accountNo,reconcileId,trackingId,trackingIdServ,postDate);
							
						}
						
					}
					System.out.println("List###########--------->> "+list);
					status=paymentHistoryResponse.getStatus();
					if(status.getStatusCode()!=null){
						String[] code=status.getStatusCode().split("-");
						String code1=null;

						if(code.length>=3){
							code1=code[1]+"-"+code[2];						
						}				
						status_description = code1 + " QI :" + status.getStatusDescription();
						log.info("status_description in createResponseJSONForFetchPaymentHistory--->>" + status_description);
					}
				}
				
				
			}
			log.info("complete Row-->> "+rowValues);
		}
		else if(responsePojo.getBody().getSoaFault()!=null){
			SoaFault soaFault=responsePojo.getBody().getSoaFault();
			log.info("createResponseForFX method  when ebmHeader is null from resonse===");
			if(CommonUtil.isNotNull(soaFault.getSoaFaultCode())){
				String[] soaFaultCodeArray = soaFault.getSoaFaultCode().split("-");
				if(soaFaultCodeArray.length>=3){
					statusCode = soaFaultCodeArray[1] + "-" + soaFaultCodeArray[2];
				}
				log.info("Status code is in createResponseJSONForPaymentFind when error response from webservice---> " + statusCode);
			}
			if(CommonUtil.isNotNull(soaFault.getFaultDescription())){
				String fault_value = soaFault.getFaultDescription();
				if (fault_value.length() > 999)
					fault_value = fault_value.substring(0, 1000);
	
				faultDescription ="Error->"+statusCode + " QI:" + fault_value;
				faultDescription= faultDescription.replace("'", "");
				log.info("Status description is in createResponseJSONForPaymentFind when error response from webservice---> " + faultDescription);
			}
		}
    	}
    	returnObject[0]=faultDescription;
		returnObject[1]=list;
		baseResponse.setObject(returnObject);
		ClientDAO dao = new ClientDAOImpl();
		//log.info("BaseResponse object in createResponseJSONForFetchPaymentHistory2===> "returnObject[0].toString());
		//log.info("BaseResponse object in createResponseJSONForFetchPaymentHistory2===> "returnObject[1].toString());
		String statusCod =status_code=="200"?"SUCCESS":"FAILED";
		dao.insertFxLog(statusCod, null, clientURL, mapper.writeValueAsString(responsePojo), null, null, "INT-219", null, null, null, null);
		log.info("END updateResponse in method createResponseJSONForFetchPaymentHistory2 result----->>>" + baseResponse.toString());
    	
    }
		catch(Exception e){
			log.error("Exception in createResponseJSONForFetchPaymentHistory2() ", e);
			}
		return baseResponse;
		}
    
    public String updateReconcileRecord(String account_no, String reconcile_id,String trackingId,String trackingIdServ,String postDate){
    	
    	log.info("START----in updateReconcileRecord method of PaymentHistoryDetailsClient");
		Connection con = null;
		PreparedStatement ps = null;

		String result=null;

			if (!CommonValidator.isNull(account_no)) {

				String sql = "UPDATE PAYMENT_RECONCILIATION_APS SET TRACKING_ID = '"+trackingId+"' ,TRACKING_ID_SERV= '"+trackingId+"' "
						+ " ,STATUS_CODE=0,FX_POSTED_DATE='"+postDate+"' WHERE ACCT_EXT_ID='"+account_no+"' AND RECONCILE_TRANSACTION_ID='"+reconcile_id+"'";
				log.info("query of payment 219 for Reconcile-->> " + sql);
				try {
					con = ConnectionUtil.getConnection();
					log.info("connection formed in updateReconcileRecord--------->" + con);

				} catch (Exception e) {

					log.info("Connection not established in updateReconcileRecord ", e);
				}
				
				if (con != null) {
					log.info("query of updateReconcileRecord---" + sql);
					try {
						con.setAutoCommit(false);
						ps = con.prepareStatement(sql);
						int resultSet = ps.executeUpdate();
					
						try {
							if (resultSet > 0) {
								result = RESULT_DB_SUCCESFUL;
							} else {
								result = RESULT_DB_FAILURE;
							}
						} catch (Exception e) {
							log.info("Query execution updateReconcileRecord---->", e);
						} finally {
							if (con != null) {
								try {
									con.commit();
									ps.close();
									con.close();
								} catch (Exception e) {
									log.info("Exception in the updateReconcileRecord", e);
								}
							}
						}
					} catch (Exception e) {

						log.info("Exception in updateReconcileRecord-->", e);
					}

				}
			}
		log.info("END----in updateReconcileRecord method of PaymentHistoryDetailsClient");

		return result;

		
    	
		} 
		
		public ResponseEntity<PaymentHistoryResponse>  postPaymentHistoryClientToFXForSR(String accountNo,String revOrSrFalg,String lob,String fromDate1,String toDate1){
		log.info("START----in updatePaymentHistoryDetails method of PaymentHistoryDetailsClient");

		SoaFault fault = null;
		String result = EMPTY_STRING;
		String status_code = EMPTY_STRING;
		String exceptionMessage=null;
		boolean exceFlag=false;
		PaymentHistoryBaseResponse baseResponse =null;
		ResponseEntity<PaymentHistoryResponse> responsePojo = null;
		SimpleDateFormat sdf=new SimpleDateFormat("dd-mm-yyyy");
		String fromDate=getFormatDate(fromDate1);
		String toDate =getFormatDate(toDate1);
		ClientDAO dao = new ClientDAOImpl();
		
		//Date d= new  Date();
		//Calendar c = Calendar.getInstance(); 
		//c.setTime(d); 
		//c.add(Calendar.DATE, 1);
		//d = c.getTime();
		//toDate= new SimpleDateFormat("yyyy-mm-dd").format(d);
		//toDate+="T23:59:59";
		
		try {

			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();

			String clientURL ="";
			/*if(revOrSrFalg.equalsIgnoreCase("true")){
				clientURL = GenericConfiguration.getDescription("kenon.postPaymentHistoryToFXV5.url")
						+"domain=B2C&lob="+lob+"&subLob=Postpaid&consumerTransactionId=11343"
						+"&consumerName=APS&programmeName=EAIMigration&customerMigrated="+revOrSrFalg+"&accountId="+accountNo+"&msisdn=9740232322"
						+"&billNo=&billResets=&origBillNo=&origbillResets=origTrackingId&origTrackingIdServ=&trackingId=&trackingIdServ="
						+"&fromDate="+fromDate+"&toDate="+toDate+"&PaymenttransferFlag=&lowerLimit=&upperLimit=";
			log.info("clientURL in updatePaymentHistoryDetails  INT-219 URL-->> "+clientURL);
			}
			else{
				clientURL = GenericConfiguration.getDescription("kenon.postPaymentHistoryToFXV5.url")
						+"domain=B2C&lob="+lob+"&subLob=Postpaid&consumerTransactionId=11343"
						+"&consumerName=APS&programmeName=EAIMigration&customerMigrated="+revOrSrFalg+"&accountId="+accountNo+"&msisdn=9740232322"
						+"&billNo=&billResets=&origBillNo=&origbillResets=origTrackingId&origTrackingIdServ=&trackingId=&trackingIdServ="
						+"&PaymenttransferFlag=&lowerLimit=&upperLimit=";
			log.info("clientURL in updatePaymentHistoryDetails  INT-219 URL-->> "+clientURL);
			}*/
			clientURL = GenericConfiguration.getDescription("kenon.postPaymentHistoryToFXV5.url")
					+"domain=B2C&lob="+lob+"&subLob=Postpaid&consumerTransactionId=11343"
					+"&consumerName=APS&programmeName=EAIMigration&customerMigrated="+revOrSrFalg+"&accountId="+accountNo+"&fromDate="+fromDate+"&toDate="+toDate;
			log.info("clientURL in updatePaymentHistoryDetails  INT-219 URL-->> "+clientURL);
		
			String userpass = GenericConfiguration.getDescription("kenon.postPaymentToFX.userName") + ":"
					+ EncryDecrypUtility.decrypt(GenericConfiguration.getDescription("kenon.postPaymentToFX.password"));


			headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);

			restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
		
	
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
					.setConnectTimeout(Integer.parseInt(GenericConfiguration.getDescription("connect_time_out")));
	
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
					.setReadTimeout(Integer.parseInt(GenericConfiguration.getDescription("read_time_out")));
	
			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
			restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
			restTemplate.setErrorHandler(new CustomResponseErrorHandler());
	
			
	
			HttpEntity<String> entity = new HttpEntity<>(headers);
			
			responsePojo = restTemplate.exchange(clientURL, HttpMethod.GET, entity, PaymentHistoryResponse.class);
			log.info("response  For Payment Find INT 219---" + mapper.writeValueAsString(responsePojo));
	          String respCode = "";
	          if(responsePojo.getStatusCode()!=null)
	        	  respCode =responsePojo.getStatusCode().toString();
			//dao.insertFxLog(respCode, null, clientURL, mapper.writeValueAsString(responsePojo), null, null, "INT-219-PAYMENT SEARCH", null, null, null, null);
			if(responsePojo != null){

				if (HttpStatus.OK ==responsePojo.getStatusCode()) {
					if(responsePojo.getBody().getEbmHeader()!=null && responsePojo.getBody().getDataArea()!=null)
					{
						log.info("success --updatePaymentHistoryDetails---EBMHeader>>"+ mapper.writeValueAsString(responsePojo.getBody().getEbmHeader()));
						log.info("success --updatePaymentHistoryDetails---Data Area>>"+ mapper.writeValueAsString(responsePojo.getBody().getDataArea()));
					} else{
						status_code = responsePojo.getStatusCode().toString();
						System.out.println("status_code-->> "+status_code);
						fault = responsePojo.getBody().getSoaFault();
						log.info("paymentHistoryResponsePojo in updatePaymentHistoryDetails in http code is not 200-->>" + fault);
					}
				}
				else {

					status_code = responsePojo.getStatusCode().toString();
					System.out.println("status_code-->> "+status_code);
					fault = responsePojo.getBody().getSoaFault();
					log.info("paymentHistoryResponsePojo in updatePaymentHistoryDetails-->>" + fault);

				}
				log.info("Before updatePaymentHistoryDetails in PaymentHistoryDetailsClient ");		

			}
			else{
				log.info("IN method  updatePaymentHistoryDetails response pojo is null" );
			}
		} catch (Exception e) {
			log.info("Got exception while processing",e);
			if (e.getCause().toString().contains(CONNECT_TEXT)) {
				exceptionMessage = CONNECT_TEXT;
			}
			else if(e.getCause().toString().contains(READ_TEXT)){
				exceptionMessage = READ_TEXT;
			}
			else{
				exceptionMessage=e.getMessage();
			}

			exceFlag=true;
		}

		if(exceFlag){
			String faultMsg="Error: Got "+exceptionMessage+" exception while processing";
			if(CONNECT_TEXT.equalsIgnoreCase(exceptionMessage)){
				System.out.println("here" +faultMsg);
				result=updatedDetails(faultMsg, accountNo);
			}
			else{
				System.out.println("here" +faultMsg);
				result=insertDataInSRDetails(faultMsg, accountNo,faultMsg,"");
			}

		}
		
		//baseResponse.setResult(result);
		log.info("END----in updatePaymentHistoryDetails method of PaymentHistoryDetailsClient");
		return responsePojo;

		
	}

  public static String getFormatDate(String date1){
	  
	  String resdate=null;
	  
	  String appen="T23:59:59";
		SimpleDateFormat sdf=new SimpleDateFormat("dd-mm-yyyy");

		Date date;
		try {
			date = sdf.parse(date1);
			sdf=new SimpleDateFormat("yyyy-mm-dd");
			System.out.println(sdf.format(date));
			resdate=sdf.format(date)+appen;
			//Calendar c = Calendar.getInstance(); 
			//c.setTime(date); 
			//c.add(Calendar.DATE, 1);
			//date = c.getTime();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		log.info("Date "+resdate);
		return resdate;
		
	}

  
}

