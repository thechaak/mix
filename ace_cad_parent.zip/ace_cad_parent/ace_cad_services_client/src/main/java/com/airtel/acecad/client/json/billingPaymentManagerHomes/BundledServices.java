package com.airtel.acecad.client.json.billingPaymentManagerHomes;

public class BundledServices {

	private String paymentAmount;

    private String lob;

    private String accountId;

    private String sublob;

    private String rtn;

    private Plan plan;

    private String billingAmount;

    private PaymentBreakup paymentBreakup;

    //private String siList;
    private SiList[] siList;

    private String paymentStatus;

    public String getPaymentAmount ()
    {
        return paymentAmount;
    }

    public void setPaymentAmount (String paymentAmount)
    {
        this.paymentAmount = paymentAmount;
    }

    public String getLob ()
    {
        return lob;
    }

    public void setLob (String lob)
    {
        this.lob = lob;
    }

    public String getAccountId ()
    {
        return accountId;
    }

    public void setAccountId (String accountId)
    {
        this.accountId = accountId;
    }

    public String getSublob() {
		return sublob;
	}

	public void setSublob(String sublob) {
		this.sublob = sublob;
	}

	public String getRtn() {
		return rtn;
	}

	public void setRtn(String rtn) {
		this.rtn = rtn;
	}

	
	public Plan getPlan ()
    {
        return plan;
    }

    public void setPlan (Plan plan)
    {
        this.plan = plan;
    }

    public String getBillingAmount ()
    {
        return billingAmount;
    }

    public void setBillingAmount (String billingAmount)
    {
        this.billingAmount = billingAmount;
    }

    public PaymentBreakup getPaymentBreakup ()
    {
        return paymentBreakup;
    }

    public void setPaymentBreakup (PaymentBreakup paymentBreakup)
    {
        this.paymentBreakup = paymentBreakup;
    }


	public SiList[] getSiList() {
		return siList;
	}

	public void setSiList(SiList[] siList) {
		this.siList = siList;
	}

	public String getPaymentStatus ()
    {
        return paymentStatus;
    }

    public void setPaymentStatus (String paymentStatus)
    {
        this.paymentStatus = paymentStatus;
    }

    @Override
    public String toString()
    {
        return "{\"paymentAmount\":\""+paymentAmount+"\", \"lob\":\""+lob+"\", \"accountId\":\""+accountId+"\", \"sublob\":\""+sublob+"\", \"rtn\":\""+rtn+"\", \"plan\":"+plan+", \"billingAmount\":\""+billingAmount+"\", \"paymentBreakup\":"+paymentBreakup+", \"siList\":"+siList+", \"paymentStatus\":\""+paymentStatus+"\"}";
    }
}
