package com.airtel.acecad.client.json.CustomerAccountSummaryJson;

public class AccCustomerAccount {

	 private String category;

	    private String billableFlag;

	   // private String parentAccount;

	    private String segment;

	    private String productLevel;

	    private String accountStatus;

	    private String activeDate;

	    private String accountType;

	    private String activationDate;

	    private String costCenter;

	    private String marketCode;
	    
	  private ParentAccount[] parentAccount;

	    public String getCategory ()
	    {
	        return category;
	    }

	    public void setCategory (String category)
	    {
	        this.category = category;
	    }

	    public String getBillableFlag ()
	    {
	        return billableFlag;
	    }

	    public void setBillableFlag (String billableFlag)
	    {
	        this.billableFlag = billableFlag;
	    }

		public ParentAccount[] getParentAccount() {
			return parentAccount;
		}

		public void setParentAccount(ParentAccount[] parentAccount) {
			this.parentAccount = parentAccount;
		}

		public String getSegment ()
	    {
	        return segment;
	    }

	    public void setSegment (String segment)
	    {
	        this.segment = segment;
	    }

	    public String getProductLevel ()
	    {
	        return productLevel;
	    }

	    public void setProductLevel (String productLevel)
	    {
	        this.productLevel = productLevel;
	    }

	    public String getAccountStatus ()
	    {
	        return accountStatus;
	    }

	    public void setAccountStatus (String accountStatus)
	    {
	        this.accountStatus = accountStatus;
	    }

	    public String getActiveDate ()
	    {
	        return activeDate;
	    }

	    public void setActiveDate (String activeDate)
	    {
	        this.activeDate = activeDate;
	    }

	    public String getAccountType ()
	    {
	        return accountType;
	    }

	    public void setAccountType (String accountType)
	    {
	        this.accountType = accountType;
	    }

	    public String getActivationDate ()
	    {
	        return activationDate;
	    }

	    public void setActivationDate (String activationDate)
	    {
	        this.activationDate = activationDate;
	    }

	    public String getCostCenter ()
	    {
	        return costCenter;
	    }

	    public void setCostCenter (String costCenter)
	    {
	        this.costCenter = costCenter;
	    }

	    public String getMarketCode ()
	    {
	        return marketCode;
	    }

	    public void setMarketCode (String marketCode)
	    {
	        this.marketCode = marketCode;
	    }

	    @Override
	    public String toString()
	    {
	        return "{\"category\" : \""+category+"\", \"billableFlag\" : \""+billableFlag+"\", \"parentAccount\" : "+parentAccount+", \"segment\" : \""+segment+"\", \"productLevel\" : \""+productLevel+"\", \"accountStatus\" : \""+accountStatus+"\", \"activeDate\" : \""+activeDate+"\", \"accountType\" : \""+accountType+"\", \"activationDate\" : \""+activationDate+"\", \"costCenter\" : \""+costCenter+"\", \"marketCode\" : \""+marketCode+"\"}";
	    }
}
