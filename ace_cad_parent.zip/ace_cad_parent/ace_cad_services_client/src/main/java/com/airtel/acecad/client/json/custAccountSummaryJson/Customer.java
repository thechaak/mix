package com.airtel.acecad.client.json.custAccountSummaryJson;

public class Customer {

	 private ContactMedium contactMedium;

	    private CustomerIdentification identification;

	    private CustomerAccount customerAccount;

	    public ContactMedium getContactMedium ()
	    {
	        return contactMedium;
	    }

	    public void setContactMedium (ContactMedium contactMedium)
	    {
	        this.contactMedium = contactMedium;
	    }

	    public CustomerIdentification getIdentification() {
			return identification;
		}

		public void setIdentification(CustomerIdentification identification) {
			this.identification = identification;
		}

		public CustomerAccount getCustomerAccount ()
	    {
	        return customerAccount;
	    }

	    public void setCustomerAccount (CustomerAccount customerAccount)
	    {
	        this.customerAccount = customerAccount;
	    }

	    @Override
	    public String toString()
	    {
	        return "{\"contactMedium\" : "+contactMedium+", \"identification\" : "+identification+", \"customerAccount\" : "+customerAccount+"}";
	    }
}
