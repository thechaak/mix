package com.airtel.acecad.client.json.billingPaymentManagerHomes;

public class Plan {

	
	 private String renewalDate;

	    private String servicePlanName;

	    private String pinCode;

	    private String servicePlanType;

	    private String servicePlanId;

	    private String cityName;

	    private Cost cost;

	    private String circleId;

	    private String circleName;

	    public String getRenewalDate() {
			return renewalDate;
		}

		public void setRenewalDate(String renewalDate) {
			this.renewalDate = renewalDate;
		}

		public String getServicePlanName() {
			return servicePlanName;
		}

		public void setServicePlanName(String servicePlanName) {
			this.servicePlanName = servicePlanName;
		}

		public String getPinCode() {
			return pinCode;
		}

		public void setPinCode(String pinCode) {
			this.pinCode = pinCode;
		}

		public String getServicePlanType() {
			return servicePlanType;
		}

		public void setServicePlanType(String servicePlanType) {
			this.servicePlanType = servicePlanType;
		}

		public String getServicePlanId() {
			return servicePlanId;
		}

		public void setServicePlanId(String servicePlanId) {
			this.servicePlanId = servicePlanId;
		}

		public String getCityName() {
			return cityName;
		}

		public void setCityName(String cityName) {
			this.cityName = cityName;
		}

		public Cost getCost() {
			return cost;
		}

		public void setCost(Cost cost) {
			this.cost = cost;
		}

		public String getCircleId() {
			return circleId;
		}

		public void setCircleId(String circleId) {
			this.circleId = circleId;
		}

		public String getCircleName() {
			return circleName;
		}

		public void setCircleName(String circleName) {
			this.circleName = circleName;
		}

		@Override
	    public String toString()
	    {
	        return "{\"renewalDate\" : \""+renewalDate+"\", \"servicePlanName\" : \""+servicePlanName+"\", \"pinCode\" : \""+pinCode+"\", \"servicePlanType\" : \""+servicePlanType+"\", \"servicePlanId\" : \""+servicePlanId+"\", \"cityName\" : \""+cityName+"\", \"cost\" : "+cost+", \"circleId\" : \""+circleId+"\", \"circleName\" : \""+circleName+"\"}";
	    }
}
