package com.airtel.acecad.client.json.adjustmentJson;

public class ResponseDataArea {

	 private SyncBillingAdjustmentResponse syncBillingAdjustmentResponse;

	    public SyncBillingAdjustmentResponse getSyncBillingAdjustmentResponse ()
	    {
	        return syncBillingAdjustmentResponse;
	    }

	    public void setSyncBillingAdjustmentResponse (SyncBillingAdjustmentResponse syncBillingAdjustmentResponse)
	    {
	        this.syncBillingAdjustmentResponse = syncBillingAdjustmentResponse;
	    }

	    @Override
	    public String toString()
	    {
	        return "{\"syncBillingAdjustmentResponse\" : "+syncBillingAdjustmentResponse+"}";
	    }
}
