package com.airtel.acecad.client.dto;

import java.sql.Timestamp;

public class DepositReversalDetails {

	int transactionNo;
	int srTransactionNo;
	int fileId;
	String fileIdentifier;
	String srNumber;
	String srCategory;
	
	String accountExternalId;
	String origTrackingId;
	String origTrackinIdServ;
	String refundReasonCode;
	String depositTypeCode;
	
	int mobileNo;
	String source;
	String apsFalg;
	
	String crsId;
	String csrRemark;
	String businessUnit;
	int sNo;
	
	Timestamp createdDate;
	Timestamp modifiedDate;
	
	int targetTrackingId;
	int targettrackinIdServ;
	int statusCode;
	String statusDescription;
	int noOfHit;
	String userId;
	String refundType;
	
	public int getTransactionNo() {
		return transactionNo;
	}
	public void setTransactionNo(int transactionNo) {
		this.transactionNo = transactionNo;
	}
	public int getSrTransactionNo() {
		return srTransactionNo;
	}
	public void setSrTransactionNo(int srTransactionNo) {
		this.srTransactionNo = srTransactionNo;
	}
	public int getFileId() {
		return fileId;
	}
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}
	public String getFileIdentifier() {
		return fileIdentifier;
	}
	public void setFileIdentifier(String fileIdentifier) {
		this.fileIdentifier = fileIdentifier;
	}
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getSrCategory() {
		return srCategory;
	}
	public void setSrCategory(String srCategory) {
		this.srCategory = srCategory;
	}
	
	public String getAccountExternalId() {
		return accountExternalId;
	}
	public void setAccountExternalId(String accountExternalId) {
		this.accountExternalId = accountExternalId;
	}
	
	public String getOrigTrackingId() {
		return origTrackingId;
	}
	public void setOrigTrackingId(String origTrackingId) {
		this.origTrackingId = origTrackingId;
	}
	public String getOrigTrackinIdServ() {
		return origTrackinIdServ;
	}
	public void setOrigTrackinIdServ(String origTrackinIdServ) {
		this.origTrackinIdServ = origTrackinIdServ;
	}
	public String getRefundReasonCode() {
		return refundReasonCode;
	}
	public void setRefundReasonCode(String refundReasonCode) {
		this.refundReasonCode = refundReasonCode;
	}
	public String getDepositTypeCode() {
		return depositTypeCode;
	}
	public void setDepositTypeCode(String depositTypeCode) {
		this.depositTypeCode = depositTypeCode;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getApsFalg() {
		return apsFalg;
	}
	public void setApsFalg(String apsFalg) {
		this.apsFalg = apsFalg;
	}
	public String getCrsId() {
		return crsId;
	}
	public void setCrsId(String crsId) {
		this.crsId = crsId;
	}
	public String getCsrRemark() {
		return csrRemark;
	}
	public void setCsrRemark(String csrRemark) {
		this.csrRemark = csrRemark;
	}
	public String getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}
	public int getsNo() {
		return sNo;
	}
	public void setsNo(int sNo) {
		this.sNo = sNo;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public int getTargetTrackingId() {
		return targetTrackingId;
	}
	public void setTargetTrackingId(int targetTrackingId) {
		this.targetTrackingId = targetTrackingId;
	}
	public int getTargettrackinIdServ() {
		return targettrackinIdServ;
	}
	public void setTargettrackinIdServ(int targettrackinIdServ) {
		this.targettrackinIdServ = targettrackinIdServ;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	public int getNoOfHit() {
		return noOfHit;
	}
	public void setNoOfHit(int noOfHit) {
		this.noOfHit = noOfHit;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getRefundType() {
		return refundType;
	}
	public void setRefundType(String refundType) {
		this.refundType = refundType;
	}
	
	
}
