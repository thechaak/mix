package com.airtel.acecad.client;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.airtel.acecad.client.dao.ClientDAO;
import com.airtel.acecad.client.dao.ClientDAOImpl;
import com.airtel.acecad.client.dao.ReversalDaoImpl;
import com.airtel.acecad.client.dao.ReverseDao;
import com.airtel.acecad.client.dto.PostPaymentToFXRequest;
import com.airtel.acecad.client.json.invoicePaymentJson.Bank;
import com.airtel.acecad.client.json.invoicePaymentJson.CustomerAccount;
import com.airtel.acecad.client.json.invoicePaymentJson.DetailFault;
import com.airtel.acecad.client.json.invoicePaymentJson.EbmHeader;
import com.airtel.acecad.client.json.invoicePaymentJson.EbmHeader1;
import com.airtel.acecad.client.json.invoicePaymentJson.Fault;
import com.airtel.acecad.client.json.invoicePaymentJson.Identification;
import com.airtel.acecad.client.json.invoicePaymentJson.PostCustomerBill;
import com.airtel.acecad.client.json.invoicePaymentJson.PostCustomerPayment;
import com.airtel.acecad.client.json.invoicePaymentJson.PostMyPojo;
import com.airtel.acecad.client.json.invoicePaymentJson.PostPartyPayment;
import com.airtel.acecad.client.json.invoicePaymentJson.PostPartyResponse;
import com.airtel.acecad.client.json.invoicePaymentJson.PostPayment;
import com.airtel.acecad.client.json.invoicePaymentJson.PostPaymentDataArea;
import com.airtel.acecad.client.json.invoicePaymentJson.PostPaymentFault;
import com.airtel.acecad.client.json.invoicePaymentJson.PostPaymentReqMsg;
import com.airtel.acecad.client.json.invoicePaymentJson.PostPaymentResMsg;
import com.airtel.acecad.client.json.invoicePaymentJson.PostPaymentResponse;
import com.airtel.acecad.client.json.invoicePaymentJson.PostResponseDataArea;
import com.airtel.acecad.client.json.invoicePaymentJson.SoaFault;
import com.airtel.acecad.client.json.invoicePaymentJson.Status;
import com.airtel.acecad.client.json.invoicePaymentJson.TrackingRecord;
import com.airtel.acecad.client.util.GenericConfiguration;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.CustomResponseErrorHandler;
import com.airtel.acecad.client.util.EncryDecrypUtility;
import com.airtel.acecad.client.util.GlobalConstants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
public class InvoicePaymentDetailsClient implements GlobalConstants {

	private static final Logger log = LogManager.getLogger("serviceClientUI");

	/*
	 * @author :- Tanu Goyal-- FOR PAYMENT POSTING
	 */
	public String postPaymentToFX(PostMyPojo requestPojo, PostPaymentToFXRequest postPaymentToFXRequest,int jobId)
			throws Exception {

		log.info("START----in postPaymentToFX method  formation of Rest client of InvoicePaymentDetailsClient");
		String result = EMPTY_STRING;
		PostPaymentResMsg updateInvoicePaymentResMsg = null;
		Fault fault = null;
		String status_code=null;
		
		ClientDAO clientDao = new ClientDAOImpl();
		int pTransactionId = EMPTY_VALUE;
		String resultConectRead =EMPTY_STRING;
		try {

			if(CommonUtil.isNotNull(postPaymentToFXRequest.getTransactionId())){
				
				pTransactionId = Integer.parseInt(postPaymentToFXRequest.getTransactionId());
			}
			
			String clientURL = GenericConfiguration.getDescription("kenon.postPaymentToFX.url");
			RestTemplate restTemplate = new RestTemplate();
			//ADDED FOR HANDLING TIMEOUT ERRORS
			restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
			.setConnectTimeout(Integer.parseInt(GenericConfiguration.getDescription("connect_time_out")));
	        ((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
			.setReadTimeout(Integer.parseInt(GenericConfiguration.getDescription("read_time_out")));
			
			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
			restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
			restTemplate.setErrorHandler(new CustomResponseErrorHandler());

			HttpHeaders headers = new HttpHeaders();
			
			//Added by Ritu (EncryptDecrypt Password)
			String userpass = GenericConfiguration.getDescription("kenon.postPaymentToFX.userName") + ":"
					+ EncryDecrypUtility.decrypt(GenericConfiguration.getDescription("kenon.postPaymentToFX.password"));
			log.info("clientURL in postPaymentToFX----" + clientURL+ "and pTransactionId"+pTransactionId);
			headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

			HttpEntity<PostMyPojo> entity = new HttpEntity<PostMyPojo>(requestPojo, headers);

			log.info("requestPojo in postPaymentToFX----" + requestPojo.toString()+ "and pTransactionId"+pTransactionId);

			ResponseEntity<PostPartyResponse> responsePojo = null;

			try {
				responsePojo = restTemplate.exchange(clientURL, HttpMethod.POST, entity, PostPartyResponse.class);
				log.info("responsePojo  in postPaymentToFX-------->" + responsePojo.toString() + " status code------>"
						+ responsePojo.getStatusCode()+ "and pTransactionId"+pTransactionId);
				if(responsePojo != null){
					log.info("Response pojo is not null in 632 ");
					status_code=responsePojo.getStatusCode().toString();
				if (HttpStatus.OK ==responsePojo.getStatusCode()) {
					if (responsePojo.getBody().getUpdateInvoicePaymentResMsg() != null) {
						updateInvoicePaymentResMsg = responsePojo.getBody().getUpdateInvoicePaymentResMsg();
						log.info("responsePojo.getBody().getUpdateInvoicePaymentResMsg()  in postPaymentToFX--->"
								+ responsePojo.getBody().getUpdateInvoicePaymentResMsg()+ "and pTransactionId"+pTransactionId);
					}
					else {
						status_code=responsePojo.getStatusCode().toString();
						fault = responsePojo.getBody().getFault();
						log.info("responsePojo.getBody().getFault()  in postPaymentToFX in http 200ok--->"
								+ responsePojo.getBody().getFault()+ "and pTransactionId"+pTransactionId);
					}
					
				}
				else {
					status_code=responsePojo.getStatusCode().toString();
					fault = responsePojo.getBody().getFault();
					log.info("responsePojo.getBody().getFault()  in postPaymentToFX--->"
							+ responsePojo.getBody().getFault()+ "and pTransactionId"+pTransactionId);
				}
				log.info("BEFORE method in createResponseJSONForPostPaymentToFX>");
				result = createResponseJSONForPostPaymentToFX(updateInvoicePaymentResMsg, fault,
						postPaymentToFXRequest,status_code,jobId);
				log.info("AFTER method in createResponseJSONForPostPaymentToFX ------>" + result+ "and pTransactionId"+pTransactionId);
				}
				else{
					log.info("IN method  createResponseJSONForPostPaymentToFX response pojo is null and pTransactionId"+pTransactionId);
				}
			} catch (Exception e) {
                 log.info("Got faulty code from the response of FX  id-->>"+pTransactionId, e);
				
				
				if(e.getCause().toString().contains(CONNECT_TEXT)){
					
					resultConectRead = clientDao.updateConnectionReadResponse(pTransactionId,AIRTL_CUST_PAYMENT_DETAILS,CONNECT_TEXT);
					log.info("Got faulty code from the response CONNECT_TEXT of FX resultConectRead----->"+resultConectRead+ "and pTransactionId"+pTransactionId);
				}

				if(e.getCause().toString().contains(READ_TEXT)){
					
					resultConectRead = clientDao.updateConnectionReadResponse(pTransactionId,AIRTL_CUST_PAYMENT_DETAILS,READ_TEXT);
					log.info("Got faulty code from the response READ_TEXT  of FX resultConectRead----->"+resultConectRead+ "and pTransactionId"+pTransactionId);
					
				}
				
				
			}

		} catch (Exception e) {
			
			log.info("exception in postPaymentToFX", e);
			if(CommonUtil.isNotNull(postPaymentToFXRequest.getTransactionId())){
				
				pTransactionId = Integer.parseInt(postPaymentToFXRequest.getTransactionId());
			}
			if(e.getCause().toString().contains(CONNECT_TEXT)){
				
				resultConectRead = clientDao.updateConnectionReadResponse(pTransactionId,AIRTL_CUST_PAYMENT_DETAILS,CONNECT_TEXT);
				log.info("Got faulty code from the response CONNECT_TEXT of FX resultConectRead----->"+resultConectRead+ "and pTransactionId"+pTransactionId);
			}

			if(e.getCause().toString().contains(READ_TEXT)){
				
				resultConectRead = clientDao.updateConnectionReadResponse(pTransactionId,AIRTL_CUST_PAYMENT_DETAILS,READ_TEXT);
				log.info("Got faulty code from the response READ_TEXT  of FX resultConectRead----->"+resultConectRead+ "and pTransactionId"+pTransactionId);
				
			}
		}
		log.info("END----in postPaymentToFX method of InvoicePaymentDetailsClient");
		return result;
	}

	/*
	 * @author :- Tanu Goyal-- To Create Request Json Format for Posting Payment
	 * Request
	 */
	public String createRequestJSONForPostPaymentToFX(String accountId,String recordType) throws Exception {

		log.info("START----in createRequestJSONForPostPaymentToFX method of InvoicePaymentDetailsClient");
		String result = EMPTY_STRING;
		log.info("accountNo in payment posting 313--->" + accountId);
		ClientDAO clientDAO = new ClientDAOImpl();
		int transactionId = 0;
	
		List<PostPaymentToFXRequest> postPaymentToFX = clientDAO.fetchPaymentPostDetails(accountId,recordType);
		log.info("Response fetch postPaymentToFX from query--->" + postPaymentToFX);
		if (postPaymentToFX.size() > 0) {
			for (int request = 0; request < postPaymentToFX.size(); request++) {

				PostPaymentToFXRequest postPaymentToFXRequest = new PostPaymentToFXRequest();

				postPaymentToFXRequest = postPaymentToFX.get(request);

				EbmHeader ebmHeader = new EbmHeader();
				ebmHeader.setLob(LOB);
				String consumerTransactionId = APS +CommonUtil.randomMethod();
				log.info("consumerTransactionId-----"+consumerTransactionId);
				 ebmHeader.setConsumerTransactionId(consumerTransactionId);//sequencegenerated
				ebmHeader.setCustomerMigrated(TRUE);//Hard code as determines whether to legacy or new for new =true

				Identification customerAccountidentification = new Identification();
				customerAccountidentification.setId(accountId);

				CustomerAccount customerAccount = new CustomerAccount();
				customerAccount.setIdentification(customerAccountidentification);

				Identification customerBillIdentification = new Identification();
//				customerBillIdentification.setId("0");
				 

				 if(B2B.equalsIgnoreCase(postPaymentToFXRequest.getB2bB2c())){
					 customerBillIdentification.setId(postPaymentToFXRequest.getInvoiceNum());
					}else{
						 customerBillIdentification.setId("0");//B2c=0 
					}
				 
				 
				PostCustomerBill customerBill = new PostCustomerBill();
				customerBill.setIdentification(customerBillIdentification);
				if(B2B.equalsIgnoreCase(postPaymentToFXRequest.getB2bB2c())){
					customerBill.setOrigBillRefResets(postPaymentToFXRequest.getBillRefResets());
				}else{
					customerBill.setOrigBillRefResets("0");//B2c=0 
				}
				
//				 customerBill.setOrigBillRefResets(postPaymentToFXRequest.getRefNum());
				PostPartyPayment partyPayment = new PostPartyPayment();
				if(CommonUtil.isNotNull(postPaymentToFXRequest.getAnnotation())){
					Identification partyIdentification = new Identification();
					 partyIdentification.setId(postPaymentToFXRequest.getAnnotation());
						partyPayment.setIdentification(partyIdentification);
				}
			
				partyPayment.setAmount(postPaymentToFXRequest.getPaymentAmount());
				 partyPayment.setPaymentDate(postPaymentToFXRequest.getPaymentRecievedDate());
				log.info("partyPayment.setPaymentDate--" + postPaymentToFXRequest.getPaymentRecievedDate());
				 partyPayment.setPaymentTransType(postPaymentToFXRequest.getBmfTransType());
				partyPayment.setCurrency("1");// set and HARD CODE TO 1
				if(CommonUtil.isNotNull(postPaymentToFXRequest.getUserId())){
				 partyPayment.setSubmitter(postPaymentToFXRequest.getUserId());
				}
				 partyPayment.setChequeNumber(postPaymentToFXRequest.getRefNum());

				 Bank bank = new Bank();
				 bank.setBankName(postPaymentToFXRequest.getBankName());
				PostCustomerPayment customerPayment = new PostCustomerPayment();
				customerPayment.setCustomerBill(customerBill);
				customerPayment.setPartyPayment(partyPayment);
				PostPayment updateInvoicePayment = new PostPayment();
				updateInvoicePayment.setCustomerPayment(customerPayment);
				updateInvoicePayment.setCustomerAccount(customerAccount);
				
				
				updateInvoicePayment.setBank(bank);
				PostPaymentDataArea dataArea = new PostPaymentDataArea();
				dataArea.setUpdateInvoicePayment(updateInvoicePayment);

				PostPaymentReqMsg updateInvoicePaymentReqMsg = new PostPaymentReqMsg();
				updateInvoicePaymentReqMsg.setEbmHeader(ebmHeader);
				updateInvoicePaymentReqMsg.setDataArea(dataArea);

				PostMyPojo requestPojo = new PostMyPojo();
				requestPojo.setUpdateInvoicePaymentReqMsg(updateInvoicePaymentReqMsg);
				InvoicePaymentDetailsClient invoicePaymentDetailsClient = new InvoicePaymentDetailsClient();
				postPaymentToFXRequest.setAcctExtId(accountId);

				if(CommonUtil.isNotNull(postPaymentToFXRequest.getTransactionId())){
					transactionId= Integer.parseInt(postPaymentToFXRequest.getTransactionId());
				}
				
				log.info("Before hitting the posting fx job_id for transaction ID in INT---"+transactionId);
				Object[] resultobj=  clientDAO.updateJobId(AIRTL_CUST_PAYMENT_DETAILS, transactionId,null,1);
				log.info("After hitting the posting fx job_id jobId in createRequestJSONForPostPaymentToFX result is:"
						+ resultobj[0] + "and job id is"+resultobj[1]+" and TransactionId " + transactionId);
				
				if (RESULT_DB_SUCCESFUL.equalsIgnoreCase((String) resultobj[0])) {
				log.info("Before calling postPaymentToFX method from createRequestJSONForPostPaymentToFX");
				result = invoicePaymentDetailsClient.postPaymentToFX(requestPojo, postPaymentToFXRequest,(int)resultobj[1]);
				log.info("After calling postPaymentToFX method from createRequestJSONForPostPaymentToFX result--->"
						+ result+ "and TransactionId"+transactionId);
				}
			}
		}
		log.info("END----in createRequestJSONForPostPaymentToFX method of InvoicePaymentDetailsClient and TransactionId"+transactionId);
		return result;
	}

	/*
	 * @author :- Tanu Goyal-- To Create Response Json Format for Posting
	 * Payment Request
	 */
	public String createResponseJSONForPostPaymentToFX(PostPaymentResMsg updateInvoicePaymentResMsg, Fault fault,
			PostPaymentToFXRequest postPaymentToFXRequest ,String statusCodeWeb,int jobId) throws Exception {
		log.info("START----in createResponseJSONForPostPaymentToFX method of InvoicePaymentDetailsClient");

		String result = EMPTY_STRING;
		String faultDescription = EMPTY_STRING;
		String statusCode = EMPTY_STRING;
		String systemId = EMPTY_STRING;
		String id = EMPTY_STRING;
		String transactionId=postPaymentToFXRequest.getTransactionId();

		if (updateInvoicePaymentResMsg != null) {

			log.info("In if loop when got success response from webservice --313 INT");

			EbmHeader1 ebmHeader1 = new EbmHeader1();
			if (ebmHeader1 != null) {
				ebmHeader1 = updateInvoicePaymentResMsg.getEbmHeader();

				PostResponseDataArea dataArea1 = new PostResponseDataArea();
				dataArea1 = updateInvoicePaymentResMsg.getDataArea();
				if (dataArea1 != null) {

					PostPaymentResponse updateInvoicePaymentResponse = new PostPaymentResponse();

					updateInvoicePaymentResponse = dataArea1.getUpdateInvoicePaymentResponse();
					if (updateInvoicePaymentResponse != null) {
						TrackingRecord trackingRecord = new TrackingRecord();

						trackingRecord = updateInvoicePaymentResponse.getTrackingRecord();
						if (trackingRecord != null) {
							Identification identification = trackingRecord.getIdentification();
							if (CommonUtil.isNotNull(trackingRecord.getSystemId())) {
								systemId = trackingRecord.getSystemId();
							}
							if (CommonUtil.isNotNull(identification.getId())) {
								id = identification.getId();
							}
							Status status = updateInvoicePaymentResponse.getStatus();
							
							if (CommonUtil.isNotNull(status.getStatusCode())) {
								String[] soaFaultCodeArray = status.getStatusCode().split("-");
								statusCode = soaFaultCodeArray[1] + "-" + soaFaultCodeArray[2];
							}
							if (CommonUtil.isNotNull(status.getStatusDescription())) {
								faultDescription = statusCode+":"+status.getStatusDescription();
							}
						}

					}

					log.info("statusCode after response--" + faultDescription);
				}
			}
		} else if (fault != null) {
			log.info("In else loop when got error response from webservice --313 InT statusCodeWeb--->"+statusCodeWeb+" and transactionId"+transactionId);
			if(statusCodeWeb.contains(status_code_504)){
				//faultDescription = fault.getFaultstring();
				String fault_value=fault.getFaultstring();
				if(fault_value.length()>999){
					fault_value=fault_value.substring(0, 1000);
				}
				faultDescription = fault_value;
				faultDescription= faultDescription.replace("'", "");
				log.info("Status description is in createResponseJSONForPostCustomerDepositeToFX---> "+faultDescription+" and transactionId"+transactionId);
			} else if (statusCodeWeb.contains(status_code_502)){
				//faultDescription = fault.getFaultstring();
				String fault_value=fault.getFaultstring();
				if(fault_value.length()>999){
					fault_value=fault_value.substring(0, 1000);
				}
				faultDescription = fault_value;
				faultDescription= faultDescription.replace("'", "");
					log.info("Status description is in createResponseJSONForPostCustomerDepositeToFX---> " + faultDescription+" and transactionId"+transactionId);
				} else {
				DetailFault detail = new DetailFault();
				if (detail != null) {
					detail = fault.getDetail();
					PostPaymentFault updateInvoicePaymentFault = new PostPaymentFault();
					if (updateInvoicePaymentFault != null) {
						updateInvoicePaymentFault = detail.getUpdateInvoicePaymentFault();
						SoaFault soaFault = updateInvoicePaymentFault.getSoaFault();
						String[] soaFaultCodeArray = soaFault.getSoaFaultCode().split("-");
						statusCode = soaFaultCodeArray[1] + "-" + soaFaultCodeArray[2];
						if (CommonUtil.isNotNull(soaFault.getFaultDescription())) {
							//faultDescription = statusCode+":"+soaFault.getFaultDescription();
							String fault_value=soaFault.getFaultDescription();
							if(fault_value.length()>999){
								fault_value=fault_value.substring(0, 1000);
							}
							faultDescription = statusCode + ":" + fault_value;
							faultDescription= faultDescription.replace("'", "");
						}
						log.info("faultDescription-------->" + faultDescription+" and transactionId"+transactionId);
					}

				}
			}
			

		}
		log.info("BEFORE  updatePaymentPostDetails in createResponseJSONForPostPaymentToFX ");
		ReverseDao revDao = new ReversalDaoImpl();
		//ADDED ON 1 JAN
		
		log.info("Input in proc--->>>id+...."+id+" systemId--->"+systemId+" faultDescription-->"+faultDescription+ "  postPaymentToFXRequest.getTransactionId()---"+postPaymentToFXRequest.getTransactionId()+" postPaymentToFXRequest.getAcctExtId() + "+postPaymentToFXRequest.getAcctExtId()
		+"  postPaymentToFXRequest.getPaymentMode()--->"+postPaymentToFXRequest.getPaymentMode()+"  postPaymentToFXRequest.getRecordType()--->"+postPaymentToFXRequest.getRecordType());
				//result = revDao.updateResponseInt(id, systemId, faultDescription, postPaymentToFXRequest,jobId);
		log.info("result from DBB AFTER updatePaymentPostDetails in createResponseJSONForPostPaymentToFX---" + result+" and transactionId"+transactionId);
		log.info("END----in createResponseJSONForPostPaymentToFX method of InvoicePaymentDetailsClient");

		return result;
	}

	
	/*public static void main(String[] args) throws Exception {
		
		InvoicePaymentDetailsClient i = new InvoicePaymentDetailsClient();
		i.createRequestJSONForPostPaymentToFX("2213", "PAYMENT");
	}*/

}
