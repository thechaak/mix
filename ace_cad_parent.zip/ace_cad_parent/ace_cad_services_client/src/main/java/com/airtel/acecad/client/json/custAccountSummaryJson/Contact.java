package com.airtel.acecad.client.json.custAccountSummaryJson;

public class Contact {

	private TelephoneNumber[] telephoneNumber;

    public TelephoneNumber[] getTelephoneNumber ()
    {
        return telephoneNumber;
    }

    public void setTelephoneNumber (TelephoneNumber[] telephoneNumber)
    {
        this.telephoneNumber = telephoneNumber;
    }

    @Override
    public String toString()
    {
        return "{\"telephoneNumber\" : "+telephoneNumber+"}";
    }
}
