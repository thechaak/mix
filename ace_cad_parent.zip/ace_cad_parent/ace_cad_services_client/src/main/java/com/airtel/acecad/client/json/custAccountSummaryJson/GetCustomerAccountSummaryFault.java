package com.airtel.acecad.client.json.custAccountSummaryJson;


public class GetCustomerAccountSummaryFault {

	 private  SoaFault  soaFault;


	    public SoaFault getSoaFault() {
		return soaFault;
	}

	public void setSoaFault(SoaFault soaFault) {
		this.soaFault = soaFault;
	}

		@Override
	    public String toString()
	    {
	        return "{\"soaFault\" : "+soaFault+"}";
	    }
}
