package com.airtel.acecad.client.json.createUpdateNotesJson;

public class EbmHeader {
		
	   // private String consumerName;
	    
	    private String lob;
	    
	   // private String subLob;

	    private String customerMigrated;
	    
	    private String consumerTransactionId;
	    
	   // private String providerTransactionId; 

	    //private String programmeName;
	    

		public String getLob() {
			return lob;
		}

		public void setLob(String lob) {
			this.lob = lob;
		}


		public String getCustomerMigrated() {
			return customerMigrated;
		}

		public void setCustomerMigrated(String customerMigrated) {
			this.customerMigrated = customerMigrated;
		}

		public String getConsumerTransactionId() {
			return consumerTransactionId;
		}

		public void setConsumerTransactionId(String consumerTransactionId) {
			this.consumerTransactionId = consumerTransactionId;
		}

		@Override
	    public String toString()
	    {
	        return "{\"lob\" : \""+lob+"\", \"customerMigrated\" : \""+customerMigrated+"\",  \"consumerTransactionId\": \""+consumerTransactionId+"\"}";
	    
	    }
		/*@Override
	    public String toString()
	    {
	        return "{\"domain\" : \""+domain+"\",\"consumerName\":\" "+consumerName+"\", \"lob\" : \""+lob+"\",\"subLob\" : \""+subLob+"\", \"debugFlag\" : \""+debugFlag+"\", \"isRepushed\" : \""+isRepushed+"\", \"repushedCount\" : \""+repushedCount+"\", \"customerMigrated\" : \""+customerMigrated+"\",  \"consumerTransactionId\": \""+consumerTransactionId+"\",\"providerTransactionId\": \""+providerTransactionId+"\", \"programmeName\":\""+programmeName+"\"}";
	    }*/
}

