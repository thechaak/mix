package com.airtel.acecad.client.json.adjustmentReversalJson;

public class ResponseTrackingRecord {

	private TrackingRecordIdentification identification;

    private String systemId;

   
    public TrackingRecordIdentification getIdentification() {
		return identification;
	}

	public void setIdentification(TrackingRecordIdentification identification) {
		this.identification = identification;
	}

	public String getSystemId ()
    {
        return systemId;
    }

    public void setSystemId (String systemId)
    {
        this.systemId = systemId;
    }

    @Override
    public String toString()
    {
        return "{\"identification\" : "+identification+", \"systemId\" : \""+systemId+"\"}";
    }
}
