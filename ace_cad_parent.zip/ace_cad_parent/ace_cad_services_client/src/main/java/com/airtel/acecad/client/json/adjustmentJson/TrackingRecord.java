package com.airtel.acecad.client.json.adjustmentJson;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TrackingRecord
{
	//private TrackingRecordIdentification identification;

   // private String systemId;
    
    private String userId;
    
   
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
    public String toString()
    {
        return "{\"userId\":\""+userId+"\"}";
    }
}
