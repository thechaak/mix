package com.airtel.acecad.client.dto;

import java.sql.Timestamp;
import java.util.Date;

public class DepositDetails{
	int transactionNo;
	int fileId;
	int sNo;
	String mobileNo;
	String accountExternalId;
	String depositType;
	String dateReceived;
	double addAmount;
	double interestAmount;
	String currencyCode;
	int openItemId;
	String micrBankId;
	String chequeNo;
	Date chequeDate;
	String bankName;
	String branchName;
	String bankCity;
	String csrNotes;
	String annotation1;
	String annotation4;
	String annotation5;
	String businessUnit;
	String srNumber;
	Timestamp createdDate;
	Timestamp modifiedDate;
	int trackingId;
	int trackinIdServ;
	int statusCode;
	String statusDescription;
	String sentFxFlag;
	int noOfHit;
	String userId;
	String source;
	String modeOfPayment;
	private String apsFlag;
	private String lob;
	private String amount;
	//added for Deposit find request parameter uses
	private String fromDate;
	private String toDate;
	private String isMigrated;
	
	
	
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public int getTransactionNo() {
		return transactionNo;
	}
	public void setTransactionNo(int transactionNo) {
		this.transactionNo = transactionNo;
	}
	public int getFileId() {
		return fileId;
	}
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}
	public int getsNo() {
		return sNo;
	}
	public void setsNo(int sNo) {
		this.sNo = sNo;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	public String getAccountExternalId() {
		return accountExternalId;
	}
	public void setAccountExternalId(String accountExternalId) {
		this.accountExternalId = accountExternalId;
	}
	public String getDepositType() {
		return depositType;
	}
	public void setDepositType(String depositType) {
		this.depositType = depositType;
	}
	public String getDateReceived() {
		return dateReceived;
	}
	public void setDateReceived(String dateReceived) {
		this.dateReceived = dateReceived;
	}
	public double getAddAmount() {
		return addAmount;
	}
	public void setAddAmount(double addAmount) {
		this.addAmount = addAmount;
	}
	public double getInterestAmount() {
		return interestAmount;
	}
	public void setInterestAmount(double interestAmount) {
		this.interestAmount = interestAmount;
	}
	
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public int getOpenItemId() {
		return openItemId;
	}
	public void setOpenItemId(int openItemId) {
		this.openItemId = openItemId;
	}
	public String getMicrBankId() {
		return micrBankId;
	}
	public void setMicrBankId(String micrBankId) {
		this.micrBankId = micrBankId;
	}
	public String getChequeNo() {
		return chequeNo;
	}
	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}
	public Date getChequeDate() {
		return chequeDate;
	}
	public void setChequeDate(Date chequeDate) {
		this.chequeDate = chequeDate;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getBankCity() {
		return bankCity;
	}
	public void setBankCity(String bankCity) {
		this.bankCity = bankCity;
	}
	public String getCsrNotes() {
		return csrNotes;
	}
	public void setCsrNotes(String csrNotes) {
		this.csrNotes = csrNotes;
	}
	public String getAnnotation1() {
		return annotation1;
	}
	public void setAnnotation1(String annotation1) {
		this.annotation1 = annotation1;
	}
	public String getAnnotation4() {
		return annotation4;
	}
	public void setAnnotation4(String annotation4) {
		this.annotation4 = annotation4;
	}
	public String getAnnotation5() {
		return annotation5;
	}
	public void setAnnotation5(String annotation5) {
		this.annotation5 = annotation5;
	}
	public String getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public int getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(int trackingId) {
		this.trackingId = trackingId;
	}
	public int getTrackinIdServ() {
		return trackinIdServ;
	}
	public void setTrackinIdServ(int trackinIdServ) {
		this.trackinIdServ = trackinIdServ;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	public String getSentFxFlag() {
		return sentFxFlag;
	}
	public void setSentFxFlag(String sentFxFlag) {
		this.sentFxFlag = sentFxFlag;
	}
	public int getNoOfHit() {
		return noOfHit;
	}
	public void setNoOfHit(int noOfHit) {
		this.noOfHit = noOfHit;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getModeOfPayment() {
		return modeOfPayment;
	}
	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}
	public String getApsFlag() {
		return apsFlag;
	}
	public void setApsFlag(String apsFlag) {
		this.apsFlag = apsFlag;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getIsMigrated() {
		return isMigrated;
	}
	public void setIsMigrated(String isMigrated) {
		this.isMigrated = isMigrated;
	}
	
	
}
