package com.airtel.acecad.client.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.airtel.acecad.client.dto.ChqBounceKciDetails;
import com.airtel.acecad.client.dto.EcsDeregisterationDetails;

import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.ConnectionUtil;
import com.airtel.acecad.client.util.GlobalConstants;

import oracle.jdbc.OracleTypes;


public class MessageSendCallDaoImpl implements GlobalConstants,MessageSendCallDao{

	private static Logger log = LogManager.getLogger("serviceClientUI");
	//Added by Geeta--For ECS-DeRegisteration
	
	/*
		public EcsDeregisterationDetails fetchMsgContent(int srTransactionId,String srCategory) throws Exception{
			
			log.info("START--->in fetchMsgContent method of MessageSendCallDaoImpl- For srTransactionId--->"+srTransactionId);
			
			EcsDeregisterationDetails ecsDeregisterationDTO = new EcsDeregisterationDetails();
			Connection con = null;
			PreparedStatement preparedStatement = null;
			ResultSet rs = null;
			String str=EMPTY_STRING;

			if(srCategory.equalsIgnoreCase(ECS_DE_REGISTERATION)){
				//sr_detail_aps else ecsCharginf table
			
			str = "SELECT COMMENTS,MSISDN,null,null FROM SR_DETAILS_APS where STATUS_CODE="+INITIAL_STATUS_CODE+" "
					+ "and SR_CATEGORY='"+srCategory+"' and SR_TRANSACTION_NO="+srTransactionId+" ";
			}else{
				// change by geeta service external id to MSISDN
				str = "SELECT  null,SERVICE_EXTERNAL_ID,NACH_LIMIT,BALANCE_DUE FROM ECS_CHARGING_APS where upper(MT_STATUS)=upper('"+MT_STATUS_IN_PROGRESS+"')"
						+ " and TRANSACTION_NO="+srTransactionId+" ";
			}
			log.info("QUERY in fetchMsgContent in MessageSendCallDaoImpl ++" + str.toString()+" and srTransactionId is-->"+srTransactionId);
			try {
				con = ConnectionUtil.getConnection();
				log.info("connection in fetchMsgContent __________" + con+" and srTransactionId is-->"+srTransactionId);
				
			} catch (Exception e) {
				log.info("Connection not established in fetchMsgContent", e);
			}
			if (con != null) {
				try {
					con.setAutoCommit(false);
					preparedStatement = con.prepareStatement(str);
					rs = preparedStatement.executeQuery();
					try {

						if (rs != null) {
							while (rs.next()) {
								if(CommonUtil.isNotNull(rs.getString(1))){
								ecsDeregisterationDTO.setStatusDescription(rs.getString(1));
							log.info("comments--->>"+rs.getString(1));
								}
								log.info("STATUS_DESCRIPTION  in fetchMsgContent in MessageSendCallDaoImpl -->>" + rs.getString(1));
								ecsDeregisterationDTO.setMobileNo(rs.getString(2));
								log.info("MobileNo in fetchMsgContent -->>" + rs.getString(2));
								log.info("mob no in fetchMsgContent in MessageSendCallDaoImpl--->>"+rs.getString(2));
								//if(rs.getInt(3)!=0){
								ecsDeregisterationDTO.setNachLimit(rs.getInt(3));
								log.info("nachlimit in fetchMsgContent in MessageSendCallDaoImpl--->>"+rs.getString(3));
								ecsDeregisterationDTO.setBalanceDue(rs.getInt(4));
								log.info("bALANCEDUE in fetchMsgContent in MessageSendCallDaoImpl--->>"+rs.getString(4));
								//ecsDeregisterationDTO.setMtNoOfHit(rs.getInt(3));
							}
						}

					} catch (Exception e) {
						log.info("Query execution of fetchMsgContent in MessageSendCallDaoImpl", e);
					} finally {
						con.commit();
						preparedStatement.close();
						rs.close();
						con.close();
					}
				} catch (Exception e) {
					// TODO: handle exception
					log.info("Query execution of fetchMsgContent ", e);
				}
			
			}
			log.info("END--->in fetchMsgContent method of MessageSendCallDaoImpl and srTransactionId is-->"+srTransactionId);
		
			return ecsDeregisterationDTO;
		}*/
		
		//Added new method for 226_F(Fetch proc)--on 29june2018
		public Object[] fetchMsgTriggerDetails(int srTransactionNo) throws Exception {

			log.info("START--->in fetchMsgTriggerDetails method of MessageSendCallDaoImpl");
			String procSuccess = null;
			Object[] obj = new Object[2];
			EcsDeregisterationDetails ecsDeregisterationDTO = new EcsDeregisterationDetails();
			Connection con = null;
			CallableStatement callableStatement = null;
			ResultSet rs = null;
			String result = EMPTY_STRING;

			String str = "{call FETCH_MSG_TRIGGER_DETAILS(?,?,?) }";

			log.info("QUERY in fetchMsgTriggerDetails---->>+" + str.toString());
			try {
				con = ConnectionUtil.getConnection();
				log.info("connection in fetchMsgTriggerDetails __________" + con);

			} catch (Exception e) {
				log.info("Connection not established in fetchMsgTriggerDetails", e);
			}
			if (con != null) {
				try {
					con.setAutoCommit(false);
					callableStatement = con.prepareCall(str);

					callableStatement.setInt(1, srTransactionNo);
					callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
					callableStatement.registerOutParameter(3, Types.VARCHAR);

					callableStatement.executeUpdate();
					result = callableStatement.getString(3);
                    log.info("status from proc in fetchMsgTriggerDetails--->>>"+result);
					rs = (ResultSet) callableStatement.getObject(2);

					while (rs != null && rs.next()) {

						procSuccess = "SUCCESS";
						if(CommonUtil.isNotNull(rs.getString("message"))){
							ecsDeregisterationDTO.setStatusDescription(rs.getString("message"));
						    log.info("comments to be send in fetchMsgTriggerDetails--->>"+rs.getString("message"));
							}
							log.info("STATUS_DESCRIPTION  in fetchMsgTriggerDetails in MessageSendCallDaoImpl -->>" + rs.getString("message"));
							ecsDeregisterationDTO.setMobileNo(rs.getString("msisdn"));
							log.info("MobileNo in fetchMsgTriggerDetails in MessageSendCallDaoImpl-->>" + rs.getString("msisdn"));
							ecsDeregisterationDTO.setNachLimit(rs.getInt("nach_limit"));
							log.info("nachlimit in fetchMsgTriggerDetails in MessageSendCallDaoImpl--->>"+rs.getString("nach_limit"));
							ecsDeregisterationDTO.setBalanceDue(rs.getInt("balance_due"));
							log.info("bALANCEDUE in fetchMsgTriggerDetails in MessageSendCallDaoImpl--->>"+rs.getString("balance_due"));
					}

					obj[0] = procSuccess;
					obj[1] = ecsDeregisterationDTO;

				} catch (Exception e) {
					log.info("Query execution of fetchMsgTriggerDetails ", e);
				} finally {
					if (con != null) {
						try {
							con.commit();
							rs.close();
							callableStatement.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in the fetchMsgTriggerDetails", e);
						}
					}

				}
			}
			log.info("list in fetchMsgTriggerDetails-->>" + ecsDeregisterationDTO);
			log.info("END--->in fetchMsgTriggerDetails method of MessageSendCallDaoImpl");
			return obj;

		}
		
	//Commented by geeta for new refund functionality---on 29june2018
	/*
		public String updateMessageForMT(String mobileNo,int srTransactionNo,String srCategory,String msgResult)
				throws Exception{
			
			log.info("START--in updateMessageForMT in MessageSendCallDaoImpl and srTransactionNo-->>"+srTransactionNo);
			Connection con = null;
			CallableStatement callableStatement = null;

			String result = EMPTY_STRING;
			String sql = EMPTY_STRING;

			sql = "{call MT_RESPONSE_APS(?,?,?,?,?,?)}";
			
			try {

				try {
					con = ConnectionUtil.getConnection();
					

				} catch (Exception e) {
					log.info("Connection not established IN updateMessageForMT", e);
				}
				if (con != null) {
					try {
						con.setAutoCommit(false);
						callableStatement = con.prepareCall(sql);
						callableStatement.setString(1, mobileNo);
						callableStatement.setInt(2, srTransactionNo);
						callableStatement.setString(3, srCategory);
						callableStatement.setString(4, msgResult);
						callableStatement.registerOutParameter(5, Types.VARCHAR);
						callableStatement.registerOutParameter(6, Types.INTEGER);
						int count = callableStatement.executeUpdate();
						//int count = callableStatement.getInt(6);
						log.info("updated rows in updateResponse--->>" + count+" and srTransactionNo-->>"+srTransactionNo);
						if (count > 0) {
							result = RESULT_DB_SUCCESFUL;
						} else {
							result = RESULT_DB_FAILURE;
						}
					} catch (Exception e) {
						log.info("Exception in updateMessageForMT  ", e);
					}
				}
			} catch (Exception e) {
				log.info("Exception in updateMessageForMT  ", e);
			} finally {
				con.commit();
				callableStatement.close();
				con.close();
			}
			log.info("END--in updateMessageForMT in MessageSendCallDaoImpl result --->>" + result+" and srTransactionNo-->>"+srTransactionNo);
			return result;
	}*/
		
		public String updateForMsgTrigger(String mobileNo,int srTransactionNo,String msgResult,String file_identifier)
				throws Exception{
			
			log.info("START--in updateMessageForMT in MessageSendCallDaoImpl and srTransactionNo-->>"+srTransactionNo);
			Connection con = null;
			CallableStatement callableStatement = null;

			String result = EMPTY_STRING;
			String sql = EMPTY_STRING;

			sql = "{call MT_RESPONSE_APS(?,?,?,?,?,?)}";
			
			try {

				try {
					con = ConnectionUtil.getConnection();
					

				} catch (Exception e) {
					log.info("Connection not established IN updateMessageForMT", e);
				}
				if (con != null) {
					try {
						con.setAutoCommit(false);
						callableStatement = con.prepareCall(sql);
						callableStatement.setString(1, mobileNo);
						callableStatement.setInt(2, srTransactionNo);
						callableStatement.setString(3, msgResult);
						callableStatement.setString(4, file_identifier);
						callableStatement.registerOutParameter(5, Types.VARCHAR);
						callableStatement.registerOutParameter(6, Types.INTEGER);
						int count = callableStatement.executeUpdate();
						//int count = callableStatement.getInt(5);
						log.info("updated rows in updateResponse--->>" + count+" and srTransactionNo-->>"+srTransactionNo);
						if (count > 0) {
							result = RESULT_DB_SUCCESFUL;
						} else {
							result = RESULT_DB_FAILURE;
						}
					} catch (Exception e) {
						log.info("Exception in updateMessageForMT  ", e);
					}
				}
			} catch (Exception e) {
				log.info("Exception in updateMessageForMT  ", e);
			} finally {
				con.commit();
				callableStatement.close();
				con.close();
			}
			log.info("END--in updateMessageForMT in MessageSendCallDaoImpl result --->>" + result+" and srTransactionNo-->>"+srTransactionNo);
			return result;
					}
		
					
	//For Chq Bounce KCI Implementation	(fetch contact no from int_632)			
	public ChqBounceKciDetails fetchContactNo(String accountNo) throws Exception {

		log.info("START : In method fetchContactNo in  MessageSendCallDaoImpl and AccountNo-->" + accountNo);

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = EMPTY_STRING;

		ChqBounceKciDetails chqBounceKciDTO = new ChqBounceKciDetails();

		/*sql = "SELECT PRIMARY_CONTACT_NUMBER,ALTERNATE_CONTACT,ERROR_DESCRIPTION FROM ACCOUNT_PROFILE_APS WHERE ACCOUNT_NO='" + accountNo
				+ "' AND ERROR_DESCRIPTION IS NULL" + " AND APS_FLAG !='ERROR'";*/
		
		sql = "SELECT PRIMARY_CONTACT_NUMBER, ALTERNATE_CONTACT,ERROR_DESCRIPTION FROM (SELECT PRIMARY_CONTACT_NUMBER,"
				+ "ALTERNATE_CONTACT, ERROR_DESCRIPTION FROM ACCOUNT_PROFILE_APS WHERE ACCOUNT_NO = '"+accountNo+"' "
				+ "ORDER BY INTHIT_DATE DESC ) WHERE ROWNUM <2";

		log.info("QUERY in fetchContactNo in MessageSendCallDaoImpl ++" + sql.toString() + " and ACCOUNT_NO is-->"
				+ accountNo);
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection in fetchContactNo __________" + con + " and ACCOUNT_NO is-->" + accountNo);

		} catch (Exception e) {
			log.info("Connection not established in fetchContactNo", e);
		}
		if (con != null) {
			try {
				con.setAutoCommit(false);
				ps = con.prepareStatement(sql);
				rs = ps.executeQuery();
				try {

					if (rs != null) {
						while (rs.next()) {
							if (CommonUtil.isNotNull(rs.getString(1))) {
								chqBounceKciDTO.setPrimaryContactNo(rs.getString(1));
								log.info("PrimaryContactNo in fetchContactNo--->>" + rs.getString(1));
							}
							if (CommonUtil.isNotNull(rs.getString(2))) {
								chqBounceKciDTO.setAlternateContactNo(rs.getString(2));
								log.info("AlternateContactNo in fetchContactNo -->>" + rs.getString(2));
							}
							if (CommonUtil.isNotNull(rs.getString(3))) {
								chqBounceKciDTO.setErrorDescription(rs.getString(3));
								log.info("ErrorDescription in fetchContactNo -->>" + rs.getString(3));
							}
						}
					}

				} catch (Exception e) {
					log.info("Query execution of fetchContactNo in MessageSendCallDaoImpl", e);
				} finally {
					con.commit();
					ps.close();
					rs.close();
					con.close();
				}
			} catch (Exception e) {
				// TODO: handle exception
				log.info("Query execution of fetchContactNo ", e);
			}

		}
		log.info("END--->in fetchContactNo method of MessageSendCallDaoImpl and ACCOUNT_NO is-->" + accountNo);

		return chqBounceKciDTO;
	}
	
	public String updateResponseForChqBounceKci(String mobileNo,String msgResult,String accountNo) throws Exception{
		
		log.info("START--in updateResponseForChqBounceKci in MessageSendCallDaoImpl and mobileNo-->"+mobileNo);
		Connection con = null;
		CallableStatement callableStatement = null;

		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;

		sql = "{call CHQ_BOUNCE_KCI_RESPONSE_APS(?,?,?,?,?)}";

		try {

			try {
				con = ConnectionUtil.getConnection();

			} catch (Exception e) {
				log.info("Connection not established IN updateResponseForChqBounceKci", e);
			}
			if (con != null) {
				try {
					con.setAutoCommit(false);
					callableStatement = con.prepareCall(sql);
					callableStatement.setString(1, mobileNo);
					log.info("mobile no in updateResponseForChqBounceKci--->"+mobileNo);
					callableStatement.setString(2, msgResult);
					callableStatement.setString(3, accountNo);
					
					callableStatement.registerOutParameter(4, Types.VARCHAR);
					callableStatement.registerOutParameter(5, Types.INTEGER);
					int count = callableStatement.executeUpdate();
					// int count = callableStatement.getInt(6);
					log.info("updated rows in updateResponseForChqBounceKci--->>" + count + " and accountNo-->>"
							+ accountNo);
					if (count > 0) {
						result = RESULT_DB_SUCCESFUL;
					} else {
						result = RESULT_DB_FAILURE;
					}
				} catch (Exception e) {
					log.info("Exception in updateResponseForChqBounceKci  ", e);
				}
			}
		} catch (Exception e) {
			log.info("Exception in updateResponseForChqBounceKci ", e);
		} finally {
			con.commit();
			callableStatement.close();
			con.close();
		}
		log.info("END--in updateResponseForChqBounceKci in MessageSendCallDaoImpl result --->>" + result
				+ " and accountNo-->>" + accountNo);
		return result;
	}
	
	
}
