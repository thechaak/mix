package com.airtel.acecad.client.json.customerAccBillingDetails;

public class DataArea {
	private GetCustomerBillingAccountDetailsResponse getCustomerBillingAccountDetailsResponse;

    public GetCustomerBillingAccountDetailsResponse getGetCustomerBillingAccountDetailsResponse ()
    {
        return getCustomerBillingAccountDetailsResponse;
    }

    public void setGetCustomerBillingAccountDetailsResponse (GetCustomerBillingAccountDetailsResponse getCustomerBillingAccountDetailsResponse)
    {
        this.getCustomerBillingAccountDetailsResponse = getCustomerBillingAccountDetailsResponse;
    }

	@Override
	public String toString() {
		return "DataArea [getCustomerBillingAccountDetailsResponse=" + getCustomerBillingAccountDetailsResponse + "]";
	}

  
}
