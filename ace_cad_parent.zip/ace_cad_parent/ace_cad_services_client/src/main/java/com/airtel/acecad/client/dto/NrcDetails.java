package com.airtel.acecad.client.dto;

import java.sql.Timestamp;
import java.util.Date;

public class NrcDetails {

	//This is used for both nrc and nrc cheque bounce
	
	int transactionNo;
	int srTransactionNo;
	int fileId;
	String fileIdentifier;
	String srNumber;
	String srCategory;
	
	String acctNo;
	int typeIdNrc;
	String effectiveDate;
	double nrcAmount;
	
	String mobileNo;
	String serviceExternalIdType;
	String source;
	String apsFlag;
	
	String annotation;
	
	Timestamp createdDate;
	Timestamp modifiedDate;
	
	int viewId;
	int trackingId;
	int trackinIdServ;
	int statusCode;
	String statusDescription;
	int noOfHit;
	String userId;
	//Added by geeta(for cheque bounce kci)
	String refNumber;
	private String lob;
	private int sNo;
	
	public int getTransactionNo() {
		return transactionNo;
	}
	public void setTransactionNo(int transactionNo) {
		this.transactionNo = transactionNo;
	}
	public int getSrTransactionNo() {
		return srTransactionNo;
	}
	public void setSrTransactionNo(int srTransactionNo) {
		this.srTransactionNo = srTransactionNo;
	}
	public int getFileId() {
		return fileId;
	}
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}
	public String getFileIdentifier() {
		return fileIdentifier;
	}
	public void setFileIdentifier(String fileIdentifier) {
		this.fileIdentifier = fileIdentifier;
	}
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getSrCategory() {
		return srCategory;
	}
	public void setSrCategory(String srCategory) {
		this.srCategory = srCategory;
	}
	
	public String getAcctNo() {
		return acctNo;
	}
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}
	public int getTypeIdNrc() {
		return typeIdNrc;
	}
	public void setTypeIdNrc(int typeIdNrc) {
		this.typeIdNrc = typeIdNrc;
	}
	
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public double getNrcAmount() {
		return nrcAmount;
	}
	public void setNrcAmount(double nrcAmount) {
		this.nrcAmount = nrcAmount;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getServiceExternalIdType() {
		return serviceExternalIdType;
	}
	public void setServiceExternalIdType(String serviceExternalIdType) {
		this.serviceExternalIdType = serviceExternalIdType;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getApsFlag() {
		return apsFlag;
	}
	public void setApsFlag(String apsFlag) {
		this.apsFlag = apsFlag;
	}
	public String getAnnotation() {
		return annotation;
	}
	public void setAnnotation(String annotation) {
		this.annotation = annotation;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public int getViewId() {
		return viewId;
	}
	public void setViewId(int viewId) {
		this.viewId = viewId;
	}
	public int getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(int trackingId) {
		this.trackingId = trackingId;
	}
	public int getTrackinIdServ() {
		return trackinIdServ;
	}
	public void setTrackinIdServ(int trackinIdServ) {
		this.trackinIdServ = trackinIdServ;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	public int getNoOfHit() {
		return noOfHit;
	}
	public void setNoOfHit(int noOfHit) {
		this.noOfHit = noOfHit;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getRefNumber() {
		return refNumber;
	}
	public void setRefNumber(String refNumber) {
		this.refNumber = refNumber;
	}
	public String getLob() {
		return lob;
	}
	public int getsNo() {
		return sNo;
	}
	public void setsNo(int sNo) {
		this.sNo = sNo;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	
	
	
}