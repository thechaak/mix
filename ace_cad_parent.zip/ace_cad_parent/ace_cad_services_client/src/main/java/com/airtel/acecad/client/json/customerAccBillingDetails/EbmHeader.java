package com.airtel.acecad.client.json.customerAccBillingDetails;

public class EbmHeader {
	 private String consumerTransactionId;

	    public String getConsumerTransactionId ()
	    {
	        return consumerTransactionId;
	    }

	    public void setConsumerTransactionId (String consumerTransactionId)
	    {
	        this.consumerTransactionId = consumerTransactionId;
	    }

		@Override
		public String toString() {
			return "EbmHeader [consumerTransactionId=" + consumerTransactionId + "]";
		}

	  
}
