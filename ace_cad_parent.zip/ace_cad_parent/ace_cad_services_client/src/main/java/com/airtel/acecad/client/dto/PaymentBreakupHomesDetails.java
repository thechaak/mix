package com.airtel.acecad.client.dto;

import java.util.Date;

public class PaymentBreakupHomesDetails {

	
	String homesId;
	String lob;
	String accountId;
	String rtn;
	String siListId;
	String siListType;
	String subLob;
	//String onBoardingDate;
	String consumerTransactionId;
	String paymentDate;
	double amountPaid;
	String transactionId;
	String apsFlag;

	public String getHomesId() {
		return homesId;
	}
	public void setHomesId(String homesId) {
		this.homesId = homesId;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getRtn() {
		return rtn;
	}
	public void setRtn(String rtn) {
		this.rtn = rtn;
	}
	public String getSiListId() {
		return siListId;
	}
	public void setSiListId(String siListId) {
		this.siListId = siListId;
	}
	public String getSiListType() {
		return siListType;
	}
	public void setSiListType(String siListType) {
		this.siListType = siListType;
	}
	public String getSubLob() {
		return subLob;
	}
	public void setSubLob(String subLob) {
		this.subLob = subLob;
	}

	public String getConsumerTransactionId() {
		return consumerTransactionId;
	}
	public void setConsumerTransactionId(String consumerTransactionId) {
		this.consumerTransactionId = consumerTransactionId;
	}
	
	public String getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}
	public double getAmountPaid() {
		return amountPaid;
	}
	public void setAmountPaid(double amountPaid) {
		this.amountPaid = amountPaid;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	String paymentMode;

	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getApsFlag() {
		return apsFlag;
	}
	public void setApsFlag(String apsFlag) {
		this.apsFlag = apsFlag;
	}
	
	
	
}
