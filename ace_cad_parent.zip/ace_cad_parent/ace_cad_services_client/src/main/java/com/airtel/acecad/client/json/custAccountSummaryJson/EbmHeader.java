package com.airtel.acecad.client.json.custAccountSummaryJson;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class EbmHeader
{
	//private String domain;
	
    //private String consumerName;
    
    private String lob;
    
    private String subLob;

    private String customerMigrated;
    
   // private String debugFlag;
    
   // private String isRepushed;
    
   // private String repushedCount;
    
    private String consumerTransactionId;
    
    //private String providerTransactionId; 

    //private String programmeName;
    

	

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public String getSubLob() {
		return subLob;
	}

	public void setSubLob(String subLob) {
		this.subLob = subLob;
	}

	

	public String getCustomerMigrated() {
		return customerMigrated;
	}

	public void setCustomerMigrated(String customerMigrated) {
		this.customerMigrated = customerMigrated;
	}

	

	public String getConsumerTransactionId() {
		return consumerTransactionId;
	}

	public void setConsumerTransactionId(String consumerTransactionId) {
		this.consumerTransactionId = consumerTransactionId;
	}

	
	
	@Override
    public String toString()
    {
        return "{\"lob\" : \""+lob+"\",\"subLob\" : \""+subLob+"\", \"customerMigrated\" : \""+customerMigrated+"\",  \"consumerTransactionId\": \""+consumerTransactionId+"\"}";
    }


}