package com.airtel.acecad.client.json.createUpdateNotesJson;

public class BusinessInteraction {

	 private String description;

	    private Identification identification;

	   // private String type;

	    public String getDescription ()
	    {
	        return description;
	    }

	    public void setDescription (String description)
	    {
	        this.description = description;
	    }

	    public Identification getIdentification ()
	    {
	        return identification;
	    }

	    public void setIdentification (Identification identification)
	    {
	        this.identification = identification;
	    }

	 /*   public String getType ()
	    {
	        return type;
	    }

	    public void setType (String type)
	    {
	        this.type = type;
	    }*/

	    @Override
	    public String toString()
	    {
	        return "{\"description\" : \""+description+"\", \"identification\" : "+identification+"}";
	        
	    }
}
