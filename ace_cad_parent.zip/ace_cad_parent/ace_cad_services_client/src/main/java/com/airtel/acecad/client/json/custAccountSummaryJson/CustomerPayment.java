package com.airtel.acecad.client.json.custAccountSummaryJson;

public class CustomerPayment {

	 private CustomerBill customerBill;

	    private PartyPayment partyPayment;

	    public CustomerBill getCustomerBill ()
	    {
	        return customerBill;
	    }

	    public void setCustomerBill (CustomerBill customerBill)
	    {
	        this.customerBill = customerBill;
	    }

	    public PartyPayment getPartyPayment ()
	    {
	        return partyPayment;
	    }

	    public void setPartyPayment (PartyPayment partyPayment)
	    {
	        this.partyPayment = partyPayment;
	    }

	    @Override
	    public String toString()
	    {
	        return "{\"customerBill\" : "+customerBill+", \"partyPayment\" : "+partyPayment+"}";
	    }
}
