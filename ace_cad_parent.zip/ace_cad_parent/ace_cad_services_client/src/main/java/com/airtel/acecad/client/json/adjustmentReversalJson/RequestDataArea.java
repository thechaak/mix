package com.airtel.acecad.client.json.adjustmentReversalJson;

public class RequestDataArea {

	 private SyncBillingAdjustment syncBillingAdjustment;

	    public SyncBillingAdjustment getSyncBillingAdjustment ()
	    {
	        return syncBillingAdjustment;
	    }

	    public void setSyncBillingAdjustment (SyncBillingAdjustment syncBillingAdjustment)
	    {
	        this.syncBillingAdjustment = syncBillingAdjustment;
	    }

	    @Override
	    public String toString()
	    {
	        return "{\"syncBillingAdjustment\" : "+syncBillingAdjustment+"}";
	    }
}
