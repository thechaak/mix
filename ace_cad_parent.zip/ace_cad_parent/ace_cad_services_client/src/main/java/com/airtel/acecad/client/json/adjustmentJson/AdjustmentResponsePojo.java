package com.airtel.acecad.client.json.adjustmentJson;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY )
@JsonInclude(JsonInclude.Include.NON_EMPTY)

public class AdjustmentResponsePojo {

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonProperty("Fault")
	  private Fault Fault;

	    public Fault getFault ()
	    {
	        return Fault;
	    }

	    public void setFault (Fault Fault)
	    {
	        this.Fault = Fault;
	    }
	
	   @JsonInclude(JsonInclude.Include.NON_NULL)
	 private SyncBillingAdjustmentResMsg syncBillingAdjustmentResMsg;

	    public SyncBillingAdjustmentResMsg getSyncBillingAdjustmentResMsg ()
	    {
	        return syncBillingAdjustmentResMsg;
	    }

	    public void setSyncBillingAdjustmentResMsg (SyncBillingAdjustmentResMsg syncBillingAdjustmentResMsg)
	    {
	        this.syncBillingAdjustmentResMsg = syncBillingAdjustmentResMsg;
	    }

	  /*  @Override
	    public String toString()
	    {
	        return "{\"syncBillingAdjustmentResMsg\" : "+syncBillingAdjustmentResMsg+"}";
	    }*/
}
