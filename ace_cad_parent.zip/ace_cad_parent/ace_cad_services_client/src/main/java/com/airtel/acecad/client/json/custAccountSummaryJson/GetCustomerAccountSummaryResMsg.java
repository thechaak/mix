package com.airtel.acecad.client.json.custAccountSummaryJson;


public class GetCustomerAccountSummaryResMsg {

	private EbmHeader1 ebmHeader;

    private ResponseDataArea dataArea;


    public EbmHeader1 getEbmHeader() {
		return ebmHeader;
	}

	public void setEbmHeader(EbmHeader1 ebmHeader) {
		this.ebmHeader = ebmHeader;
	}

    public ResponseDataArea getDataArea() {
		return dataArea;
	}

	public void setDataArea(ResponseDataArea dataArea) {
		this.dataArea = dataArea;
	}

	@Override
    public String toString()
    {
        return "{\"ebmHeader\" : "+ebmHeader+", \"dataArea\" : "+dataArea+"}";
    }
}
