package com.airtel.acecad.client.dto;

public class CustAccountSummaryDetails {

//	String 
}
