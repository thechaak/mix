package com.airtel.acecad.client.json.custAccountSummaryJson;

public class CustomerBill {

	 private String billRefResets;
	
	 private BillPeriod billPeriod;

	    private String previousBillDate;

	    private PartyBill partyBill;

	    private String nextBillDate;

	    
	    public String getBillRefResets() {
			return billRefResets;
		}

		public void setBillRefResets(String billRefResets) {
			this.billRefResets = billRefResets;
		}

		public BillPeriod getBillPeriod ()
	    {
	        return billPeriod;
	    }

	    public void setBillPeriod (BillPeriod billPeriod)
	    {
	        this.billPeriod = billPeriod;
	    }

	    public String getPreviousBillDate ()
	    {
	        return previousBillDate;
	    }

	    public void setPreviousBillDate (String previousBillDate)
	    {
	        this.previousBillDate = previousBillDate;
	    }

	    public PartyBill getPartyBill ()
	    {
	        return partyBill;
	    }

	    public void setPartyBill (PartyBill partyBill)
	    {
	        this.partyBill = partyBill;
	    }

	    public String getNextBillDate ()
	    {
	        return nextBillDate;
	    }

	    public void setNextBillDate (String nextBillDate)
	    {
	        this.nextBillDate = nextBillDate;
	    }
	    
	    @Override
	    public String toString()
	    {
	        return "{\"billRefResets\" : "+billRefResets+",\"billPeriod\" : "+billPeriod+", \"previousBillDate\" : \""+previousBillDate+"\", \"partyBill\" : "+partyBill+", \"nextBillDate\" : \""+nextBillDate+"\"}";
	    }
}
