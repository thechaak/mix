package com.airtel.acecad.client;

import java.util.Arrays;

import org.apache.http.impl.client.HttpClients;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.airtel.acecad.client.dao.ClientDAO;
import com.airtel.acecad.client.dao.ClientDAOImpl;
import com.airtel.acecad.client.json.billingPaymentManagerHomes.ErrorResponse;
import com.airtel.acecad.client.json.billingPaymentManagerHomes.ResponseFromGetAnchorIdPojo;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.GenericConfiguration;
import com.airtel.acecad.client.util.GlobalConstants;

//////////////////////////Homes_interface_1///////////////////////////////////////////////////
public class GetHomesIdClient implements GlobalConstants{

	private static Logger log = LogManager.getLogger("serviceClientUI");
	
	
	public String fetchHomesId(String accountId,String msisdn,String lob,String fileIdentifier){
		
		log.info("START--->in fetchHomesId method of GetHomesIdClient");
		
		String result=EMPTY_STRING;
		String homesId=EMPTY_STRING;
		ResponseFromGetAnchorIdPojo responseFromGetAnchorIdPojo=null;
		
		try {
		
			ClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(
					HttpClients.createDefault());

			RestTemplate restTemplate = new RestTemplate(requestFactory);

			HttpHeaders headers = new HttpHeaders();
			
			String clientURL = GenericConfiguration.getDescription("kenon.getHomesId1") +lob+ GenericConfiguration.getDescription("kenon.getHomesId2") +accountId+ GenericConfiguration.getDescription("kenon.getHomesId3") +msisdn;
            log.info("URL in fetchHomesId --->>>"+clientURL);
			
			//headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);

			HttpEntity<String> entity = new HttpEntity<String>(headers);
			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(clientURL);
			 ResponseEntity<ResponseFromGetAnchorIdPojo> response =restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.GET, entity,
					 ResponseFromGetAnchorIdPojo.class);
			 log.info("responsePojo in fetchHomesId--->>" + response.getBody());
			 
				try {
					
					 log.info("responsePojo in fetchHomesId--->>" + response);
					 
					if (HttpStatus.OK == response.getStatusCode()) {
						if(response.getBody()!=null){
					 log.info("success--fetchHomesId11--->>" +response.getBody());
					 responseFromGetAnchorIdPojo =response.getBody();
					 log.info("success--fetchHomesId22--->>" +responseFromGetAnchorIdPojo);
						}
					else { 
						responseFromGetAnchorIdPojo = response.getBody();
					log.info("faultResponsePojo in fetchHomesId-->>" + responseFromGetAnchorIdPojo);
					}
					}
					else { 
						responseFromGetAnchorIdPojo = response.getBody();
					log.info("faultResponsePojo in fetchHomesId-->>" + responseFromGetAnchorIdPojo);
					}
				
					responseFromGetAnchorIdPojo = createResponseJSONForGetAnchorId(responseFromGetAnchorIdPojo,accountId,msisdn,lob,fileIdentifier);
					log.info("homesId in fetchHomesId-->>" + responseFromGetAnchorIdPojo.getAnchorId());
					 

				} catch (Exception e) {
					log.info("Got exception in fetchHomesId-->>", e);
				}

			} catch (Exception e) {
				log.info("Got exception in fetchHomesId---->>>", e);
			}

			log.info("END--->in fetchHomesId method of GetHomesIdClient");
			return result;

		
	}
	
	/*public static void main(String[] args) {
		
		GetHomesIdClient getHomesIdClient=new GetHomesIdClient();
		//getHomesIdClient.fetchHomesId("919160099966", "919160099966","CHQ");
	}
	*/
	
	public ResponseFromGetAnchorIdPojo createResponseJSONForGetAnchorId(ResponseFromGetAnchorIdPojo responseFromGetAnchorIdPojo,
			String accountId, String msisdn,String lob,String fileIdentifier) throws Exception{
		
		log.info("START--->in createResponseJSONForGetAnchorId method of GetHomesIdClient");
		
		String result=EMPTY_STRING;
		String homesId=EMPTY_STRING;
		String homesIdDesc=EMPTY_STRING;
		
		if(responseFromGetAnchorIdPojo!=null){
			
			if(CommonUtil.isNotNull(responseFromGetAnchorIdPojo.getIsError()) && "false".equalsIgnoreCase(responseFromGetAnchorIdPojo.getIsError())){
				
				log.info("success response in createResponseJSONForGetAnchorId error code is-->>" + responseFromGetAnchorIdPojo.getIsError());
				responseFromGetAnchorIdPojo.getIsError();
				
				if(CommonUtil.isNotNull(responseFromGetAnchorIdPojo.getRequestid()))
				responseFromGetAnchorIdPojo.getRequestid();
				
				if(CommonUtil.isNotNull(responseFromGetAnchorIdPojo.getMessage()))
					homesIdDesc=responseFromGetAnchorIdPojo.getMessage();
				
				if(CommonUtil.isNotNull(responseFromGetAnchorIdPojo.getAnchorId()))
				 homesId=responseFromGetAnchorIdPojo.getAnchorId();
				log.info("homesId in createResponseJSONForGetAnchorId-->>" + homesId);
				
			}
			else{
				log.info("failure response in createResponseJSONForGetAnchorId error code is-->>" + responseFromGetAnchorIdPojo.getIsError());
                  responseFromGetAnchorIdPojo.getIsError();
				
				if(CommonUtil.isNotNull(responseFromGetAnchorIdPojo.getRequestid()))
				responseFromGetAnchorIdPojo.getRequestid();
				
				if(CommonUtil.isNotNull(responseFromGetAnchorIdPojo.getMessage()))
					homesIdDesc=responseFromGetAnchorIdPojo.getMessage();
				
			}
		}
		
		ClientDAO clientDAO = new ClientDAOImpl();
		//String tableName=clientDAO.fetchTableName(fileIdentifier);
		
		//clientDAO.updateHomeIdDetails(responseFromGetAnchorIdPojo,accountId,msisdn,fileIdentifier);
		result=clientDAO.updateHomeIdDetails(accountId,lob,fileIdentifier,homesId,homesIdDesc);
		log.info("Result after updateHomeIdDetails in createResponseJSONForGetAnchorId--->>"+result);
		
		log.info("END--->in createResponseJSONForGetAnchorId method of GetHomesIdClient");
		return responseFromGetAnchorIdPojo;
		
	}
}
