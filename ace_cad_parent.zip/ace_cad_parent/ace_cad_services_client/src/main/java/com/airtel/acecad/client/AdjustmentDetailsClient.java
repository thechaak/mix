package com.airtel.acecad.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.airtel.acecad.client.dao.ClientDAO;
import com.airtel.acecad.client.dao.ClientDAOImpl;
import com.airtel.acecad.client.dto.AdjPostDetails;
import com.airtel.acecad.client.json.adjustmentJson.AdjustmentRequestPojo;
import com.airtel.acecad.client.json.adjustmentJson.AdjustmentResponsePojo;
import com.airtel.acecad.client.json.adjustmentJson.Customer;
import com.airtel.acecad.client.json.adjustmentJson.CustomerAccount;
import com.airtel.acecad.client.json.adjustmentJson.CustomerBill;
import com.airtel.acecad.client.json.adjustmentJson.CustomerBillIdentification;
import com.airtel.acecad.client.json.adjustmentJson.CustomerPayment;
import com.airtel.acecad.client.json.adjustmentJson.DetailFault;
import com.airtel.acecad.client.json.adjustmentJson.EbmHeader;
import com.airtel.acecad.client.json.adjustmentJson.EbmHeader1;
import com.airtel.acecad.client.json.adjustmentJson.Fault;
import com.airtel.acecad.client.json.adjustmentJson.Identification;
import com.airtel.acecad.client.json.adjustmentJson.LogicalResource;
import com.airtel.acecad.client.json.adjustmentJson.LogicalResourceIdentification;
import com.airtel.acecad.client.json.adjustmentJson.PartyPayment;
import com.airtel.acecad.client.json.adjustmentJson.RequestDataArea;
import com.airtel.acecad.client.json.adjustmentJson.ResponseDataArea;
import com.airtel.acecad.client.json.adjustmentJson.ResponseTrackingRecord;
import com.airtel.acecad.client.json.adjustmentJson.SoaFault;
import com.airtel.acecad.client.json.adjustmentJson.Status;
import com.airtel.acecad.client.json.adjustmentJson.SyncBillingAdjustment;
import com.airtel.acecad.client.json.adjustmentJson.SyncBillingAdjustmentFault;
import com.airtel.acecad.client.json.adjustmentJson.SyncBillingAdjustmentReqMsg;
import com.airtel.acecad.client.json.adjustmentJson.SyncBillingAdjustmentResMsg;
import com.airtel.acecad.client.json.adjustmentJson.SyncBillingAdjustmentResponse;
import com.airtel.acecad.client.json.adjustmentJson.TrackingRecord;
import com.airtel.acecad.client.json.adjustmentJson.TrackingRecordIdentification;
import com.airtel.acecad.client.util.GenericConfiguration;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.CustomResponseErrorHandler;
import com.airtel.acecad.client.util.EncryDecrypUtility;
import com.airtel.acecad.client.util.GlobalConstants;

/////////////////////////////INT_418///////////////////////////////////////////
public class AdjustmentDetailsClient implements GlobalConstants {

	private static Logger log = LogManager.getLogger("serviceClientUI");
	/*
	 * @author :- Geeta Rajput-FOR Ajustment Posting(create) to FX
	 */
	public String postUpdateAdjustmentPostingToFX(AdjustmentRequestPojo requestPojo, AdjPostDetails adjPostDetails,
			String tableName,int jobId) throws Exception {

		log.info("START --> in postUpdateAdjustmentPostingToFX method of AdjustmentDetailsClient and transaction_no "
				+ adjPostDetails.getTransactionNo());
		SyncBillingAdjustmentResMsg syncBillingAdjustmentResMsg = null;
		Fault fault = null;
		String result = EMPTY_STRING;
		String status_code = EMPTY_STRING;

		ClientDAO clientDao = new ClientDAOImpl();
		String resultConectRead = EMPTY_STRING;
		int transaction_no = adjPostDetails.getTransactionNo();

		try {

			String clientURL = GenericConfiguration.getDescription("kenon.postUpdateAdjustmentPostingToFX.url");

			RestTemplate restTemplate = new RestTemplate();

			// ADDED FOR HANDLING TIMEOUT ERRORS

			restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
					.setConnectTimeout(Integer.parseInt(GenericConfiguration.getDescription("connect_time_out")));// 60000=
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
					.setReadTimeout(Integer.parseInt(GenericConfiguration.getDescription("read_time_out")));

			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
			restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
			restTemplate.setErrorHandler(new CustomResponseErrorHandler());
			HttpHeaders headers = new HttpHeaders();
            
			//Added by Ritu (EncryptDecrypt Password)
			String userpass = GenericConfiguration.getDescription("kenon.postPaymentToFX.userName") + ":"
					+ EncryDecrypUtility.decrypt(GenericConfiguration.getDescription("kenon.postPaymentToFX.password"));

			log.info("clientURL in postUpdateAdjustmentPostingToFX in AdjustmentDetailsClient-->" + clientURL
					+ " and transaction_no " + transaction_no);
			headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

			HttpEntity<AdjustmentRequestPojo> entity = new HttpEntity<AdjustmentRequestPojo>(requestPojo, headers);
			ResponseEntity<AdjustmentResponsePojo> responsePojo = null;
			try {
				log.info("requestPojo in postUpdateAdjustmentPostingToFX" + requestPojo + " and transaction_no "
						+ transaction_no);
				// Execute the httpMethod to given uri template,writing the
				// given request and returns the response as ResponseEntity
				responsePojo = restTemplate.exchange(clientURL, HttpMethod.POST, entity, AdjustmentResponsePojo.class);
				log.info("responsePojo in postUpdateAdjustmentPostingToFX in AdjustmentDetailsClient--->" + responsePojo
						+ " and transaction_no " + transaction_no);

				if (responsePojo != null) {
					if (HttpStatus.OK == responsePojo.getStatusCode()) {
						if (responsePojo.getBody().getSyncBillingAdjustmentResMsg() != null) {
							syncBillingAdjustmentResMsg = responsePojo.getBody().getSyncBillingAdjustmentResMsg();
							log.info("success--in postUpdateAdjustmentPostingToFX in AdjustmentDetailsClient--->>"
									+ responsePojo.getBody().getSyncBillingAdjustmentResMsg() + " and transaction_no "
									+ transaction_no);

						} else {
							status_code = responsePojo.getStatusCode().toString();
							fault = responsePojo.getBody().getFault();
							log.info(
									"faultResponsePojo in postUpdateAdjustmentPostingToFX in AdjustmentDetailsClient in http 200 ok-->>"
											+ fault + " and transaction_no " + transaction_no);
						}

					} else {
						status_code = responsePojo.getStatusCode().toString();
						fault = responsePojo.getBody().getFault();
						log.info("faultResponsePojo in postUpdateAdjustmentPostingToFX in AdjustmentDetailsClient-->>"
								+ fault + " and transaction_no " + transaction_no);
					}
					result = createResponseJSONForAdjustmentPostingToFX(syncBillingAdjustmentResMsg, fault,
							adjPostDetails, status_code,jobId);
					log.info("After createResponseJSONForAdjustmentPostingToFX Response in postUpdateAdjustmentPostingToFX in AdjustmentDetailsClient-->>" + result
							+ " and transaction_no " + transaction_no);

				} else {
					log.info(
							"IN method  postUpdateAdjustmentPostingToFX response pojo is null in AdjustmentDetailsClient and transaction_no "
									+ transaction_no);
				}
			} catch (Exception e) {
				log.info(
						"Got faulty code from the response of FX in postUpdateAdjustmentPostingToFX in AdjustmentDetailsClient and transaction_no "
								+ transaction_no);
				
				if (e.getCause().toString().contains(CONNECT_TEXT)) {

					resultConectRead = clientDao.updateConnectionReadResponse(transaction_no, tableName, CONNECT_TEXT);
					log.info("Got faulty code from the response CONNECT_TEXT of FX resultConectRead----->"
							+ resultConectRead + " and transaction_no " + transaction_no);
				}

				if (e.getCause().toString().contains(READ_TEXT)) {

					resultConectRead = clientDao.updateConnectionReadResponse(transaction_no, tableName, READ_TEXT);
					log.info("Got faulty code from the response READ_TEXT  of FX resultConectRead----->"
							+ resultConectRead + " and transaction_no " + transaction_no);

				}
			}

		} catch (Exception e) {
			log.info("exception in postUpdateAdjustmentPostingToFX in AdjustmentDetailsClient" + e);

			if (e.getCause().toString().contains(CONNECT_TEXT)) {

				resultConectRead = clientDao.updateConnectionReadResponse(transaction_no, tableName, CONNECT_TEXT);
				log.info("Got faulty code from the response CONNECT_TEXT of FX resultConectRead postUpdateAdjustmentPostingToFX- ---->"
						+ resultConectRead + " and transaction_no " + transaction_no);
			}

			if (e.getCause().toString().contains(READ_TEXT)) {

				resultConectRead = clientDao.updateConnectionReadResponse(transaction_no, tableName, READ_TEXT);
				log.info("Got faulty code from the response READ_TEXT  of FX resultConectRead postUpdateAdjustmentPostingToFX----->" + resultConectRead
						+ " and transaction_no " + transaction_no);

			}
		}
		log.info("END--->in postUpdateAdjustmentPostingToFX method of AdjustmentDetailsClient and transaction_no "
				+ transaction_no);
		return result;
	}

	/*
	 * @author :- Geeta Rajput--create request json for FOR Ajustment
	 * Posting(create) to FX
	 */
	public String createRequestJSONForAdjustmentPostingToFX(String accountId, String tableName,int job_id) throws Exception {

		log.info("START--->in createRequestJSONForAdjustmentPostingToFX method of AdjustmentDetailsClient");

		String result = EMPTY_STRING;
		int transactionNo = EMPTY_VALUE;
		List<AdjPostDetails> adjPostDetailsList = new ArrayList<AdjPostDetails>();
		AdjustmentDetailsClient adjustmentDetailsClient = new AdjustmentDetailsClient();
		ClientDAO clientDAO = new ClientDAOImpl();
		adjPostDetailsList = clientDAO.fetchAdjustmentPostDetails(accountId);

		log.info("adjPostDetailsList in createRequestJSONForAdjustmentPostingToFX in AdjustmentDetailsClient---->>"
				+ adjPostDetailsList);

		for (int i = 0; i < adjPostDetailsList.size(); i++) {

			AdjPostDetails adjPostDetails = new AdjPostDetails();
			adjPostDetails = adjPostDetailsList.get(i);

			SyncBillingAdjustmentReqMsg syncBillingAdjustmentReqMsg = new SyncBillingAdjustmentReqMsg();
			EbmHeader ebmHeader = new EbmHeader();
			ebmHeader.setLob(LOB);
			// ebmHeader.setConsumerName(ConsumerName);
			String consumerTransactionId = APS + adjPostDetails.getTransactionNo();
			log.info(
					"consumerTransactionId in createRequestJSONForAdjustmentPostingToFX----->" + consumerTransactionId);
			ebmHeader.setConsumerTransactionId(consumerTransactionId);
			ebmHeader.setCustomerMigrated(TRUE);
			ebmHeader.setConsumerName(ADJ_CREATE_CONSUMER_NAME);
			syncBillingAdjustmentReqMsg.setEbmHeader(ebmHeader);

			RequestDataArea dataArea = new RequestDataArea();
			SyncBillingAdjustment syncBillingAdjustment = new SyncBillingAdjustment();

			Customer customer = new Customer();

			CustomerAccount customerAccount = new CustomerAccount();
			Identification identification = new Identification();
			customerAccount.setIdentification(identification);
			identification.setId(accountId);

			customer.setCustomerAccount(customerAccount);
			syncBillingAdjustment.setCustomer(customer);

			CustomerPayment customerPayment = new CustomerPayment();

			CustomerBill customerBill = new CustomerBill();
			CustomerBillIdentification customerBillIdentification = new CustomerBillIdentification();
			customerBill.setIdentification(customerBillIdentification);
			customerBillIdentification.setId(adjPostDetails.getBillRefNo());
			customerBill.setBillRefResets(String.valueOf(adjPostDetails.getBillRefResets()));///

			customerPayment.setCustomerBill(customerBill);

			PartyPayment partyPayment = new PartyPayment();

			partyPayment.setPaymentDirection(ADJ_TYPE_CREATE);

			double d = adjPostDetails.getAmount();
			int adjAmount = (int) d;
			partyPayment.setAmount(String.valueOf(adjAmount));
			// partyPayment.setAmount("1908");
			log.info("adjAmount in createRequestJSONForAdjustmentPostingToFX--->>" + adjAmount);

			partyPayment.setTransCode(adjPostDetails.getTransCode());
			partyPayment.setTransSign(TRANS_SIGN_CREDIT);// hardcode to -1 and 1
															// (bhupesh told)
			// int
			// AdjReasonCode=Integer.parseInt(adjPostDetails.getAdjReasonCode());
			partyPayment.setReasonCode(adjPostDetails.getAdjReasonCode());
			// System.out.println("reason code--->>" +
			// adjPostDetails.getAdjReasonCode());
			// revRevCostCenter=??
			partyPayment.setRevRevCostCenter(REV_REV_COSTCENTER);// hardcode to
																	// 1 (malavi
																	// told)

		
			/*
			 * Changed by geeta(29-APRIL-2017 effective date from template and
			 * annotation(remarks) from template added)
			 */
			
			// Added by geeta -28-APRIL-2017
			/*String finalDate1=null;
			log.info("Effective date in createRequestJSONForAdjustmentPostingToFX-->> "+adjPostDetails.getEffectiveDate());
			if(adjPostDetails.getEffectiveDate()!=null){
				
				String[] finalDate=adjPostDetails.getEffectiveDate().split("T");
				String val=finalDate[1];
				//val1=val;
				val=val.replaceAll(":","");
				
				System.out.println(val);
				val=val.replaceAll("0","");
				System.out.println(val.length());
				
				
				if(val.length()==0)
				{
					
					finalDate1=finalDate[0]+"T23:59:59";
					
				}
				else{
					finalDate1=adjPostDetails.getEffectiveDate();
				}
			}
			log.info("final date-EffectiveDate in createRequestJSONForAdjustmentPostingToFX -->>"+finalDate1);*/
			
			//partyPayment.setEffectiveDate(finalDate1);
			partyPayment.setEffectiveDate(adjPostDetails.getEffectiveDate());
			
			if (CommonUtil.isNotNull(adjPostDetails.getAnnotation())) {
			String annotation=adjPostDetails.getAnnotation();
			if(annotation.length()>20){
			annotation=annotation.substring(0,20);
			}
				partyPayment.setRemarks(annotation);
			}
			customerPayment.setPartyPayment(partyPayment);
			syncBillingAdjustment.setCustomerPayment(customerPayment);

			TrackingRecord trackingRecord = new TrackingRecord();
			/*
			 * TrackingRecordIdentification trackingRecordIdentification = new
			 * TrackingRecordIdentification();
			 * trackingRecord.setIdentification(trackingRecordIdentification);
			 * trackingRecordIdentification.setId("2");
			 * 
			 * trackingRecord.setSystemId("123");
			 */
			trackingRecord.setUserId(adjPostDetails.getUserId());

			syncBillingAdjustment.setTrackingRecord(trackingRecord);

			// Commented by geeta(3-MAY-2017-Defect-32233)
			/*
			 * if (CommonUtil.isNotNull(adjPostDetails.getServiceExternalId()))
			 * { LogicalResource logicalResource = new LogicalResource();
			 * LogicalResourceIdentification logicalResourceIdentification = new
			 * LogicalResourceIdentification();
			 * logicalResource.setIdentification(logicalResourceIdentification);
			 * logicalResourceIdentification.setId(String.valueOf(adjPostDetails
			 * .getServiceExternalId()));
			 * 
			 * syncBillingAdjustment.setLogicalResource(logicalResource); }
			 */

			dataArea.setSyncBillingAdjustment(syncBillingAdjustment);

			syncBillingAdjustmentReqMsg.setDataArea(dataArea);

			AdjustmentRequestPojo adjustmentRequestPojo = new AdjustmentRequestPojo();

			adjustmentRequestPojo.setSyncBillingAdjustmentReqMsg(syncBillingAdjustmentReqMsg);

			//log.info(syncBillingAdjustmentReqMsg.toString() + "and account_no -->" + accountId);
			log.info("requestpojo  in createRequestJSONForAdjustmentPostingToFX---->>" + adjustmentRequestPojo
					+ "and account_no-->" + accountId);

			if (adjPostDetails.getTransactionNo() != 0) {
				transactionNo = adjPostDetails.getTransactionNo();
			}

			log.info("Before hitting the posting fx job_id for transaction no in INT---" + transactionNo
					+ " in createRequestJSONForAdjustmentPostingToFX");
			Object[] resultobj = clientDAO.updateJobId(tableName, transactionNo,null,job_id);
			log.info("After hitting the posting fx job_id jobId in createRequestJSONForAdjustmentPostingToFX result is:"
					+ resultobj[0] + "and job id is"+resultobj[1]+" and transaction_no " + transactionNo);
			if (RESULT_DB_SUCCESFUL.equalsIgnoreCase((String) resultobj[0])) {

				log.info(
						"Before postUpdateAdjustmentPostingToFX in createRequestJSONForAdjustmentPostingToFX and account_no-->"
								+ accountId + " and transaction_no " + transactionNo);

				result = adjustmentDetailsClient.postUpdateAdjustmentPostingToFX(adjustmentRequestPojo, adjPostDetails,
						tableName,(int)resultobj[1]);
				log.info(
						"After postUpdateAdjustmentPostingToFX in createRequestJSONForAdjustmentPostingToFX result------>"
								+ result + "and account_no-->" + accountId + " and transaction_no " + transactionNo);

			}
			log.info(
					"END----in createRequestJSONForAdjustmentPostingToFX method of AdjustmentDetailsClientand transaction_no "
							+ transactionNo);
		}
		return result;
	}

	/*
	 * @author :- Geeta Rajput--create response json for FOR Ajustment
	 * Posting(create) to FX for update Adjustment details Request
	 */
	public String createResponseJSONForAdjustmentPostingToFX(SyncBillingAdjustmentResMsg syncBillingAdjustmentResMsg,
			Fault fault, AdjPostDetails adjPostDetails, String statusCode,int jobId) throws Exception {

		log.info(
				"START----in createResponseJSONForAdjustmentPostingToFX method of AdjustmentDetailsClient and transaction_no :"
						+ adjPostDetails.getTransactionNo());

		String result = EMPTY_STRING;
		String faultDescription = EMPTY_STRING;
		String status_description = EMPTY_STRING;
		int trackingServId = EMPTY_VALUE;
		int trackingId = EMPTY_VALUE;
		int viewId = EMPTY_VALUE;
		int transaction_no = adjPostDetails.getTransactionNo();
		String annotation3=EMPTY_STRING;
		String annotation5=EMPTY_STRING;
		String faultTrace=EMPTY_STRING;
		

		if (syncBillingAdjustmentResMsg != null) {
			log.info(
					"In if loop when got success response from webservice in createResponseJSONForAdjustmentPostingToFX--418 INT and transaction_no-->>"
							+ transaction_no);

			EbmHeader1 ebmHeader = new EbmHeader1();
			if (ebmHeader != null) {
				ebmHeader = syncBillingAdjustmentResMsg.getEbmHeader();
				if (CommonUtil.isNotNull(ebmHeader.getConsumerTransactionId())) {
					ebmHeader.getConsumerTransactionId();
				}
			}

			ResponseDataArea responseDataArea = new ResponseDataArea();
			if (responseDataArea != null) {
				if (syncBillingAdjustmentResMsg.getDataArea() != null) {
					responseDataArea = syncBillingAdjustmentResMsg.getDataArea();
				}
			}
			SyncBillingAdjustmentResponse syncBillingAdjustmentResponse = new SyncBillingAdjustmentResponse();
			if (responseDataArea.getSyncBillingAdjustmentResponse() != null) {

				syncBillingAdjustmentResponse = responseDataArea.getSyncBillingAdjustmentResponse();
			}

			Status status = new Status();
			if (status != null) {
				status = syncBillingAdjustmentResponse.getStatus();
			}

			if (status != null) {
				if (CommonUtil.isNotNull(status.getStatusCode())) {
					String[] statusCodeArray = status.getStatusCode().split("-");
					statusCode = statusCodeArray[1] + "-" + statusCodeArray[2];
					log.info("status code in createResponseJSONForAdjustmentPostingToFX-->>" + statusCode
							+ "and transaction_no-->>" + transaction_no);
				}

				if (CommonUtil.isNotNull(status.getStatusCode())) {
					status_description = statusCode + ":" + status.getStatusDescription();

					log.info("status_description in createResponseJSONForAdjustmentPostingToFX--->>"
							+ status_description + "and transaction_no-->>" + transaction_no);
				}
			}

			ResponseTrackingRecord trackingRecord = new ResponseTrackingRecord();
			if (trackingRecord != null) {
				if (syncBillingAdjustmentResponse.getTrackingRecord() != null) {

					trackingRecord = syncBillingAdjustmentResponse.getTrackingRecord();
					if (CommonUtil.isNotNull(trackingRecord.getSystemId())) {
						trackingServId = Integer.parseInt(trackingRecord.getSystemId());
						log.info("tracking_serv_id in createResponseJSONForAdjustmentPostingToFX--->>" + trackingServId
								+ "and transaction_no-->>" + transaction_no);
					}
					TrackingRecordIdentification identification = new TrackingRecordIdentification();
					if (trackingRecord.getIdentification() != null) {
						identification = trackingRecord.getIdentification();
						if (CommonUtil.isNotNull(identification.getId())) {
							trackingId = Integer.parseInt(identification.getId());
							log.info("tracking_id- in createResponseJSONForAdjustmentPostingToFX-->>" + trackingId
									+ "and transaction_no-->>" + transaction_no);
						}
					}
				}
			}

			AdjustmentResponsePojo adjustmentResponsePojo = new AdjustmentResponsePojo();
			if (adjustmentResponsePojo.getSyncBillingAdjustmentResMsg() != null) {
				syncBillingAdjustmentResMsg = adjustmentResponsePojo.getSyncBillingAdjustmentResMsg();
			}
		} else if (fault != null) {
			log.info(
					"In else loop when got error response from webservice in in createResponseJSONForAdjustmentPostingToFX--319 InT");
			if (statusCode.contains(status_code_504) || statusCode.contains(status_code_500)) {
				String fault_value=fault.getFaultstring();
				if(fault_value.length()>999){
					fault_value=fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description= status_description.replace("'", "");
				//status_description = fault.getFaultstring();
				log.info("Status description is in in createResponseJSONForAdjustmentPostingToFX---> "
						+ status_description + "and transaction_no-->>" + transaction_no);
			} else if (statusCode.contains(status_code_502)) {
				String fault_value=fault.getFaultstring();
				if(fault_value.length()>999){
					fault_value=fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description= status_description.replace("'", "");
				//status_description = fault.getFaultstring();
				log.info("Status description is in in createResponseJSONForAdjustmentPostingToFX---> "
						+ status_description + "and transaction_no-->>" + transaction_no);

			} else if (statusCode.contains(status_code_400)) {
				String fault_value=fault.getFaultstring();
				if(fault_value.length()>999){
					fault_value=fault_value.substring(0, 1000);
				}
				status_description = fault_value;
				status_description= status_description.replace("'", "");
				//status_description = fault.getFaultstring();
				log.info("Status description is in createResponseJSONForAdjustmentPostingToFX---> " + status_description
						+ "and transaction_no-->>" + transaction_no);

			} else {
				DetailFault detail = fault.getDetail();
				SyncBillingAdjustmentFault syncBillingAdjustmentFault = detail.getSyncBillingAdjustmentFault();
				SoaFault soaFault = syncBillingAdjustmentFault.getSoaFault();
				if (soaFault != null) {
					// Added by geeta
					if (CommonUtil.isNotNull(soaFault.getSoaFaultCode())) {
						String[] soaFaultCodeArray = soaFault.getSoaFaultCode().split("-");
						statusCode = soaFaultCodeArray[1] + "-" + soaFaultCodeArray[2];
						log.info("soa fault status code in createResponseJSONForAdjustmentPostingToFX----->>>"
								+ statusCode + " and transaction_no-->>" + transaction_no);

					}

					if (CommonUtil.isNotNull(soaFault.getFaultDescription())) {
						String fault_value=soaFault.getFaultDescription();
						if(fault_value.length()>999){
							fault_value=fault_value.substring(0, 1000);
						}
						status_description = statusCode + ":" + fault_value;
						status_description= status_description.replace("'", "");
						//status_description = statusCode + ":" + soaFault.getFaultDescription();
						log.info("faultDescription in in createResponseJSONForAdjustmentPostingToFX---->"
								+ status_description + "and transaction_no-->>" + transaction_no);
					}
				}

			}
		}
		ClientDAO clientDAO = new ClientDAOImpl();
		String table_name = clientDAO.fetchTableName(FILE_IDENTIFIER_ADJ);
		log.info("trans no in method in createResponseJSONForAdjustmentPostingToFX---->"
				+ adjPostDetails.getTransactionNo()+" and job_id-->"+jobId);
		result = clientDAO.updateResponse(status_description, trackingId, trackingServId,
				adjPostDetails.getTransactionNo(), table_name, viewId,jobId,annotation3,annotation5,faultTrace);
		log.info("response-result in createResponseJSONForAdjustmentPostingToFX----->>>" + result
				+ " and transaction_no-->>" + transaction_no);
		log.info(
				"END----in in createResponseJSONForAdjustmentPostingToFX method of AdjustmentDetailsClient and transaction_no-->>"
						+ transaction_no);
		return result;

	}

	/*
	  public static void main(String[] args) throws Exception {
	  AdjustmentDetailsClient adjustmentDetailsClient = new
	  AdjustmentDetailsClient();
	 adjustmentDetailsClient.createRequestJSONForAdjustmentPostingToFX(
	  "101-100003937", "ADJ_APS"); }
	 */
}
