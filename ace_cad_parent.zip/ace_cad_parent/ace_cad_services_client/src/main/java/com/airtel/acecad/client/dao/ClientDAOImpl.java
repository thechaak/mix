package com.airtel.acecad.client.dao;

import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;


import com.airtel.acecad.client.dto.AdjPostDetails;
import com.airtel.acecad.client.dto.AdjReversalDetails;
import com.airtel.acecad.client.dto.BulkDetails;
import com.airtel.acecad.client.dto.CallBackDTO;
import com.airtel.acecad.client.dto.CreateUpdateNotesDetails;
import com.airtel.acecad.client.dto.DepositDetails;
import com.airtel.acecad.client.dto.DepositReversalDetails;
import com.airtel.acecad.client.dto.NrcDetails;
import com.airtel.acecad.client.dto.NrcReversalDetails;
import com.airtel.acecad.client.dto.PostPaymentToFXRequest;
import com.airtel.acecad.client.dto.RefundPostDetails;
import com.airtel.acecad.client.dto.ResponsePojoForHomes;
import com.airtel.acecad.client.dto.SRApprovalTaskCallbackDetails;
import com.airtel.acecad.client.json.CustomerAccSummaryV5.Address;
import com.airtel.acecad.client.util.AccountDetailsClientThread;
import com.airtel.acecad.client.util.AccountDetailsClientThread2;
import com.airtel.acecad.client.util.AnchorDetailsThread;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.CommonValidator;
import com.airtel.acecad.client.util.ConnectionUtil;
import com.airtel.acecad.client.util.GlobalConstants;
import com.airtel.acecad.client.util.HomesDetailsThread;

import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;

public class ClientDAOImpl implements ClientDAO, GlobalConstants {

	private static Logger log = LogManager.getLogger("serviceClientUI");

	/*
	 * /*
	 * 
	 * @author :- Tanu Goyal
	 */
	/*
	 * public List<PostPaymentToFXRequest> fetchPaymentPostDetails(String
	 * accountId, String recordType) throws Exception {
	 * 
	 * log.
	 * info("START--in fetchPaymentPostDetails in ClientDAOImpl and account_no is-->"
	 * + accountId); List<PostPaymentToFXRequest> postPaymentToFXRequestList =
	 * new ArrayList<>(); Connection con = null; PreparedStatement
	 * preparedStatement = null; ResultSet resultSet = null; String date =
	 * "to_char(PAYMENT_RECEIVED_DATE ,'YYYY-MM-DD\"" + "T" + "\"HH24:MI:SS')";
	 * String sydate = "to_char(SYSDATE ,'YYYY-MM-DD\"" + "T" +
	 * "\"HH24:MI:SS')";
	 * 
	 * log.info("date in fetchPaymentPostDetails--->" + date);
	 * 
	 * 
	 * TODO posting_retrial_attempts < 3 now mod(
	 * posting_retrial_attempts+1,3)!=0 now as new requirement as per fx posting
	 * even after 3rd attempt if user want ADDED ECSo on 24 JAN for ECS CHARGING
	 * 
	 * // mod(posting_retrial_attempts+1,3)!=0 to //
	 * mod(posting_retrial_attempts,3)!=0 on 7FEB String str =
	 * "SELECT INVOICE_NO,REF_NUMBER,BMF_TRANS_TYPE,USER_ID,CASE WHEN UPPER(PAYMENT_MODE)='ECS' THEN "
	 * + sydate+" else "+date +
	 * " end as PAYMENT_RECEIVED_DATE,PAYMENT_AMOUNT*100,ANNOTATION,RECEIPT_ID,POSTING_RETRIAL_ATTEMPTS,transaction_id,PAYMENT_MODE,SR_NUMBER,RECORD_TYPE,REMITTER_BRANCH,INCOMING_TRANSACTION_REF_NO,B2B_B2C_SEGMENT,BILL_REF_RESESTS FROM "
	 * + "(SELECT * FROM AIRTL_CUST_PAYMENT_DETAILS " + "where ACCT_EXT_ID= '" +
	 * accountId + "' and TRACKING_ID Is null and  TRACKING_ID_SERV is null" +
	 * " and (mod(posting_retrial_attempts,3)!=0 or posting_retrial_attempts = 0) and APS_FLAG='APS' and posting_status_fx in ('0')  AND UPPER(record_type) = UPPER('"
	 * + recordType +
	 * "')   AND UPPER(PAYMENT_MODE) IN ('CHEQUE' ,'OTHERS', 'NEFT','PT','ECS')  AND job_id is null ) "
	 * + "   ORDER BY posting_retrial_attempts ,RECORD_ID"; // order by added
	 * for just ordering // 0-not posted in fx,1 --posted successfully // due to
	 * system error like fx down
	 * 
	 * try { con = ConnectionUtil.getConnection();
	 * log.info("connection formed in fetchPaymentPostDetails--------->" + con +
	 * "and account_no is-->" + accountId); // con.setAutoCommit(false); } catch
	 * (Exception e) { log.info("Connection not established ", e); } try {
	 * 
	 * if (con != null) { con.setAutoCommit(false);
	 * log.info("query fetchPaymentPostDetails-->" + str +
	 * "and account_no is-->" + accountId); preparedStatement =
	 * con.prepareStatement(str); resultSet = preparedStatement.executeQuery();
	 * try { if (resultSet != null) { while (resultSet.next()) {
	 * PostPaymentToFXRequest postPayment = new PostPaymentToFXRequest();
	 * postPayment.setInvoiceNum(resultSet.getString(1));
	 * postPayment.setRefNum(resultSet.getString(2));
	 * postPayment.setBmfTransType(resultSet.getString(3));
	 * postPayment.setUserId(resultSet.getString(4));
	 * postPayment.setPaymentRecievedDate(resultSet.getString(5));
	 * postPayment.setPaymentAmount(resultSet.getString(6));
	 * postPayment.setAnnotation(resultSet.getString(7));
	 * postPayment.setChequeNumber(resultSet.getString(8));
	 * postPayment.setPostRetrialAttempts(resultSet.getString(9));
	 * postPayment.setTransactionId(resultSet.getString(10));
	 * postPayment.setPaymentMode(resultSet.getString(11));
	 * postPayment.setSrNumber(resultSet.getString(12)); // added on 1JAn
	 * postPayment.setRecordType(resultSet.getString(13));
	 * postPayment.setBankName(resultSet.getString(14));
	 * postPayment.setIncomingTransactionRefNo(resultSet.getString(15));
	 * postPayment.setB2bB2c(resultSet.getString(16));
	 * postPayment.setBillRefResets(resultSet.getString(17));
	 * postPaymentToFXRequestList.add(postPayment); } }
	 * 
	 * } catch (Exception e) { log.info("Query execution ", e); } finally { if
	 * (con != null) { try { resultSet.close(); preparedStatement.close();
	 * con.close(); } catch (Exception e) {
	 * log.info("Exception in the fetchPaymentPostDetails", e); } } }
	 * 
	 * }
	 * 
	 * } catch (Exception e) { log.info(e); }
	 * 
	 * log.info("postPaymentToFXRequestList  fetchPaymentPostDetails----" +
	 * postPaymentToFXRequestList + "and account_no is-->" + accountId); log.
	 * info("END--in fetchPaymentPostDetails in ClientDAOImpl and account_no is-->"
	 * + accountId); return postPaymentToFXRequestList; }
	 */

	public List<PostPaymentToFXRequest> fetchPaymentPostDetails(String accountId, String fileIdentifier)
			throws Exception {

		log.info("START--in fetchPaymentPostDetails in ClientDAOImpl and account_no is-->" + accountId);
		List<PostPaymentToFXRequest> postPaymentToFXRequestList = new ArrayList<>();
		Connection con = null;
		ResultSet resultSet = null;
		String status = null;
		CallableStatement callableStatement = null;
		String query = "{call PAYMENT_FETCH_APS(?,?,?,?)}";
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection formed in fetchPaymentPostDetails--------->" + con + "and account_no is-->"
					+ accountId);
			// con.setAutoCommit(false);
		} catch (Exception e) {
			log.info("Connection not established ", e);
		}
		try {
			callableStatement = con.prepareCall(query);
			callableStatement.setString(1, accountId);
			callableStatement.setString(2, fileIdentifier);
			callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(4, Types.VARCHAR);

			callableStatement.executeUpdate();
			resultSet = (ResultSet) callableStatement.getObject(3);
			status = callableStatement.getString(4);
			while (resultSet != null && resultSet.next()) {
				PostPaymentToFXRequest postPayment = new PostPaymentToFXRequest();
				postPayment.setInvoiceNumber(resultSet.getString("invoice_no"));
				postPayment.setRefNumber(resultSet.getString("ref_number"));
				postPayment.setPaymentCode(resultSet.getString("payment_code"));
				postPayment.setPaymentDate(resultSet.getString("payment_date"));
				postPayment.setPaymentAmount(resultSet.getString("payment_amount"));
				postPayment.setAnnotation(resultSet.getString("annotation"));
				postPayment.setNoOfHits(resultSet.getString("no_of_hit"));
				postPayment.setTransactionId(resultSet.getString("transaction_id"));
				postPayment.setBankName(resultSet.getString("bank_name"));
				postPayment.setB2bB2cSeg(resultSet.getString("b2b_b2c_segment"));
				postPayment.setBillRefReset(resultSet.getString("bill_ref_resets"));
				postPayment.setIncomingTransRefNumber(resultSet.getString("incoming_trans_ref_no"));
				postPayment.setUserId(resultSet.getString("user_id"));
				postPayment.setPaymentMode(resultSet.getString("payment_mode"));
				postPayment.setApsFlag(resultSet.getString("aps_flag"));
				postPayment.setLob(resultSet.getString("lob"));
				postPaymentToFXRequestList.add(postPayment);
			}
		} catch (Exception e) {
			log.info(e);
		}

		log.info("postPaymentToFXRequestList  fetchPaymentPostDetails----" + postPaymentToFXRequestList
				+ "and account_no is-->" + accountId);
		log.info("END--in fetchPaymentPostDetails in ClientDAOImpl and account_no is-->" + accountId);
		return postPaymentToFXRequestList;
	}

	/*
	 * @author :- Geeta Rajput--for deposit_aps
	 */
	@Override
	public List<DepositDetails> fetchDepositDetails(String accountId) throws Exception {

		log.info("START--->in fetchDepositDetails method of ClientDAOImpl and account_no is-->" + accountId);
		List<DepositDetails> depositDetailsList = new ArrayList<DepositDetails>();

		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		// for conversion timestamp to utc format 2016-10-13T20:45:04+05:30
		// 2016-09-27T11:44:36
		/*
		 * String received_date =
		 * "to_char(cast(DATE_RECEIVED as timestamp) at time zone 'UTC','YYYY-MM-DD"
		 * + "\"" + T + "\"HH24:MI:SSTZH:TZM') AS DATE_RECEIVED";
		 */

		String received_date = "to_char(TO_TIMESTAMP_TZ (TO_CHAR (DATE_RECEIVED, 'DD/MM/YYYY'),'DD/MM/YYYY HH24:MI:SS TZH:TZM'),'YYYY-MM-DD"
				+ "\"" + T + "\"HH24:MI:SSTZH:TZM') AS DATE_RECEIVED";

		String str = "SELECT TRANSACTION_NO,ADD_AMOUNT,DEPOSIT_TYPE," + received_date
				+ ",BANK_NAME,MODE_OF_PAYMENT,ANNOTATION1,CSR_NOTES,ANNOTATION4,CHEQUE_NO,MOBILE_NO,APS_FLAG,DERIVED_LOB FROM DEPOSIT_APS where ACCOUNT_EXTERNAL_ID='"
				+ accountId + "' and STATUS_CODE=" + INITIAL_STATUS_CODE_POSTFX
				+ " and JOB_ID IS NULL ORDER BY NO_OF_HIT,TRANSACTION_NO";

		log.info("QUERY in fetchDepositDetails++" + str.toString() + " and account_no is-->" + accountId);
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection fetchDepositDetails __________" + con);

		} catch (Exception e) {
			log.info("Connection not established fetchDepositDetails", e);
		}

		if (con != null) {
			try {
				con.setAutoCommit(false);
				preparedStatement = con.prepareStatement(str);
				rs = preparedStatement.executeQuery();
				try {
					if (rs != null) {
						while (rs.next()) {
							DepositDetails depositDetailDTO = new DepositDetails();
							depositDetailDTO.setTransactionNo(rs.getInt(1));
							// depositDetailDTO.setAddAmount(Double.parseDouble(rs.getString(2)));
							depositDetailDTO.setAddAmount(rs.getDouble(2));
							log.info("amount in fetchDepositDetails-->>" + rs.getString(2) + " and account_no is-->"
									+ accountId);
							depositDetailDTO.setDepositType(rs.getString(3));
							// depositDetailDTO.setCurrencyCode(rs.getString(4));
							depositDetailDTO.setDateReceived(rs.getString(4));
							depositDetailDTO.setBankName(rs.getString(5));
							depositDetailDTO.setModeOfPayment(rs.getString(6));
							depositDetailDTO.setAnnotation1(rs.getString(7));
							depositDetailDTO.setCsrNotes(rs.getString(8));
							depositDetailDTO.setAnnotation4(rs.getString(9));
							depositDetailDTO.setChequeNo(rs.getString(10));
							depositDetailDTO.setMobileNo(rs.getString(11));
							depositDetailDTO.setApsFlag(rs.getString(12));
							depositDetailDTO.setLob(rs.getString(13));
							
							depositDetailsList.add(depositDetailDTO);
						}
					}

				} catch (Exception e) {
					log.info("Query execution of fetchDepositDetails ", e);
				} finally {

					if (con != null) {
						try {
							con.commit();
							preparedStatement.close();
							rs.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in the fetchDepositDetails", e);
						}
					}

				}

			} catch (Exception e) {
				// TODO: handle exception
				log.info("Query execution of fetchDepositDetails ", e);
			}

		}
		log.info("list fetchDepositDetails-->>" + depositDetailsList + " and account_no is-->" + accountId);
		log.info("END--->in fetchDepositDetails method of ClientDAOImpl and account_no is-->" + accountId);
		return depositDetailsList;

	}

	/*
	 * @author :- Geeta Rajput--for deposit_aps
	 */
	@Override
	public List<AdjPostDetails> fetchAdjustmentPostDetails(String accountId) throws Exception {

		log.info("START--->in fetchAdjustmentPostDetails method of ClientDAOImpl and account_no is-->" + accountId);
		List<AdjPostDetails> adjPostDetailsList = new ArrayList<AdjPostDetails>();

		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		String date = "to_char(EFFECTIVE_DATE ,'YYYY-MM-DD\"" + "T" + "\"HH24:MI:SS') as EFFECTIVE_DATE";

		String str = "SELECT AMOUNT,ADJ_REASON_CODE,TRANS_CODE,BILL_REF_NO,USER_ID,SERVICE_EXTERNAL_ID,BILL_REF_RESETS,TRANSACTION_NO,"
				+ date + ",ANNOTATION FROM ADJ_APS where ACCOUNT_EXTERNAL_ID='"

				+ accountId + "' and STATUS_CODE=" + INITIAL_STATUS_CODE_POSTFX
				+ " and JOB_ID IS NULL ORDER BY NO_OF_HIT,TRANSACTION_NO";

		log.info("QUERY fetchAdjustmentPostDetails ++" + str.toString() + " and account_no is-->" + accountId);
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection fetchAdjustmentPostDetails __________" + con + " and account_no is-->" + accountId);

		} catch (Exception e) {
			log.info("Connection not established fetchAdjustmentPostDetails", e);
		}

		if (con != null) {
			try {
				con.setAutoCommit(false);
				preparedStatement = con.prepareStatement(str);

				rs = preparedStatement.executeQuery();
				try {
					if (rs != null) {
						while (rs.next()) {
							AdjPostDetails AdjPostDetailDTO = new AdjPostDetails();

							AdjPostDetailDTO.setAmount(rs.getDouble(1));
							log.info("amount in fetchAdjustmentPostDetails-->>" + rs.getString(2)
							+ " and account_no is-->" + accountId);
							AdjPostDetailDTO.setAdjReasonCode(rs.getString(2));
							AdjPostDetailDTO.setTransCode(rs.getString(3));
							AdjPostDetailDTO.setBillRefNo(rs.getString(4));
							AdjPostDetailDTO.setUserId(rs.getString(5));
							AdjPostDetailDTO.setServiceExternalId(rs.getString(6));
							AdjPostDetailDTO.setBillRefResets(rs.getInt(7));
							AdjPostDetailDTO.setTransactionNo(rs.getInt(8));
							AdjPostDetailDTO.setEffectiveDate(rs.getString(9));
							AdjPostDetailDTO.setAnnotation(rs.getString(10));
							adjPostDetailsList.add(AdjPostDetailDTO);
						}
					}

				} catch (Exception e) {
					log.info("Query execution of fetchAdjustmentPostDetails ", e);
				} finally {
					if (con != null) {
						try {
							con.commit();
							preparedStatement.close();
							rs.close();
							con.close();

						} catch (Exception e) {
							log.info("Exception in the fetchDepositDetails", e);
						}
					}
				}
			} catch (Exception e) {
				// TODO: handle exception
				log.info(e);
			}

		}
		log.info("list fetchAdjustmentPostDetails-->>" + adjPostDetailsList + " and account_no is-->" + accountId);
		log.info("END--->in fetchAdjustmentPostDetails	 method of ClientDAOImpl and account_no is-->" + accountId);
		return adjPostDetailsList;

	}

	/*
	 * @author :- Geeta Rajput --For NRC FOR failedPayment
	 */

	public List<NrcDetails> fetchNrcDetails(String accountId) throws Exception {

		log.info("START--->in fetchNrcDetails method of ClientDAOImpl and account_no is-->" + accountId);
		List<NrcDetails> nrcDetailsList = new ArrayList<NrcDetails>();

		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		String date = "to_char(EFFECTIVEDATE ,'YYYY-MM-DD\"" + "T" + "\"HH24:MI:SS') as EFFECTIVEDATE";

		String str = "SELECT TRANSACTION_NO,NRCAMOUNT,TYPEIDNRC,MOBILE_NO,SERVICE_EXTERNAL_ID_TYPE," + date
				+ ",ANNOTATION,APS_FLAG,user_id,JOB_ID FROM NRC_APS where ACCTNO='" + accountId

				+ "' and STATUS_CODE=" + INITIAL_STATUS_CODE_POSTFX
				+ " and JOB_ID IS NULL ORDER BY NO_OF_HIT,TRANSACTION_NO";

		log.info("QUERY fetchNrcDetails ++" + str.toString() + " and account_no is-->" + accountId);
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection fetchNrcDetails  __________" + con + " and account_no is-->" + accountId);

		} catch (Exception e) {
			log.info("Connection not established ", e);
		}

		if (con != null) {
			try {
				con.setAutoCommit(false);
				preparedStatement = con.prepareStatement(str);
				rs = preparedStatement.executeQuery();
				log.info("resultset fetchNrcDetails-->" + rs + " and account_no is-->" + accountId);
				try {
					if (rs != null) {
						while (rs.next()) {
							NrcDetails nrcDetailsDTO = new NrcDetails();
							nrcDetailsDTO.setTransactionNo(rs.getInt(1));
							// nrcDetailsDTO.setNrcAmount(Double.parseDouble(rs.getString(2)));
							nrcDetailsDTO.setNrcAmount(rs.getDouble(2));
							nrcDetailsDTO.setTypeIdNrc(rs.getInt(3));
							nrcDetailsDTO.setMobileNo(rs.getString(4));
							nrcDetailsDTO.setServiceExternalIdType(rs.getString(5));
							nrcDetailsDTO.setEffectiveDate(rs.getString(6));
							nrcDetailsDTO.setAnnotation(rs.getString(7));
							nrcDetailsDTO.setApsFlag(rs.getString(8));
							nrcDetailsDTO.setUserId(rs.getString(9));
							
							nrcDetailsList.add(nrcDetailsDTO);
						}
					}

				} catch (Exception e) {
					log.info("Query execution of fetchNrcDetails ", e);
				} finally {
					if (con != null) {
						try {
							con.commit();
							preparedStatement.close();
							rs.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in the fetchNrcDetails", e);
						}
					}
				}
			} catch (Exception e) {
				log.info("Exception in the fetchNrcDetails", e);
			}

		}
		log.info("list fetchNrcDetails-->>" + nrcDetailsList + " and account_no is-->" + accountId);
		log.info("END--->in fetchNrcDetails method of ClientDAOImpl and account_no is-->" + accountId);
		return nrcDetailsList;

	}

	/*
	 * @author :- Geeta Rajput--for RefundCustomerPayment --REFUND CREATE
	 */
	public List<RefundPostDetails> fetchRefundDetails(String accountId) throws Exception {

		log.info("START--->in fetchRefundDetails method of ClientDAOImpl and account_no is-->" + accountId);
		List<RefundPostDetails> refundPostDetailsList = new ArrayList<RefundPostDetails>();
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String date = "to_char(DATE_OF_REFUND ,'YYYY-MM-DD\"" + "T" + "\"HH24:MI:SS') as DATE_OF_REFUND";

		String str = "SELECT TRANSACTION_NO," + date
				+ ",REFUND_AMOUNT,REFUND_REASON_CODE,MODE_OF_REFUND,USER_ID,APS_FLAG,LOB,ADDRESS1,ADDRESS2,ADDRESS3,"
				+ "PAYEE_STATE,PAYEE_ZIP_CODE,SEGMENT"
				+ " FROM REFUND_PAYMENT_APS where ACCOUNT_NO='"
				+ accountId + "' and STATUS_CODE=" + INITIAL_STATUS_CODE_POSTFX
				+ " and JOB_ID IS NULL ORDER BY NO_OF_HIT,TRANSACTION_NO";

		log.info("QUERY fetchRefundDetails ++" + str + " and account_no is-->" + accountId);
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection fetchRefundDetails __________" + con + " and account_no is-->" + accountId);

		} catch (Exception e) {
			log.info("Connection not established ", e);
		}
		if (con != null) {
			try {
				con.setAutoCommit(false);
				preparedStatement = con.prepareStatement(str);
				rs = preparedStatement.executeQuery();
				try {
					if (rs != null) {
						while (rs.next()) {
							RefundPostDetails refundPostDetailsDTO = new RefundPostDetails();
							refundPostDetailsDTO.setTransactionNo(rs.getInt(1));
							refundPostDetailsDTO.setDateOfRefund(rs.getString(2));
							//refundPostDetailsDTO.setRefundAmount(Double.parseDouble(rs.getString(3)));
							refundPostDetailsDTO.setRefundAmount(rs.getDouble(3));
							refundPostDetailsDTO.setRefundReasonCode(rs.getString(4));
							refundPostDetailsDTO.setRefundTypeCode(rs.getString(5));
							refundPostDetailsDTO.setUserId(rs.getString(6));
							//refundPostDetailsDTO.setRefundType(rs.getString(7));
							refundPostDetailsDTO.setApsFalg(rs.getString(7));
							refundPostDetailsDTO.setLob(rs.getString(8));
							refundPostDetailsDTO.setAddress1(rs.getString(9));
							refundPostDetailsDTO.setAddress2(rs.getString(10));
							refundPostDetailsDTO.setAddress3(rs.getString(11));
							refundPostDetailsDTO.setPayeeState(rs.getString(12));
							refundPostDetailsDTO.setPayeeZipCode(rs.getString(13));
							refundPostDetailsDTO.setSegment(rs.getString(14));
							refundPostDetailsList.add(refundPostDetailsDTO);
						}
					}

				} catch (Exception e) {
					log.info("Query execution of fetchRefundDetails ", e);
				} finally {
					if (con != null) {
						try {
							con.commit();
							preparedStatement.close();
							rs.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in the fetchRefundDetails", e);
						}
					}
				}
			} catch (Exception e) {
				log.info("Exception in the fetchRefundDetails", e);
			}

		}
		log.info("list fetchRefundDetails-->>" + refundPostDetailsList + " and account_no is-->" + accountId);
		log.info("END--->in fetchRefundDetails method of ClientDAOImpl and account_no is-->" + accountId);
		return refundPostDetailsList;

	}

	/*
	 * @author :- Geeta Rajput--for RefundCustomerPayment --DEPOSIT RETURN
	 */
	public List<DepositReversalDetails> fetchDepositReversalDetails(String accountId) throws Exception {

		log.info("START--->in fetchRefundDetails method of ClientDAOImpl and account_no is-->" + accountId);
		List<DepositReversalDetails> depositReversalDetailsList = new ArrayList<DepositReversalDetails>();
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String date = "to_char(DATE_OF_REFUND ,'YYYY-MM-DD\"" + "T" + "\"HH:MI:SS') as DATE_OF_REFUND";
		String str = "SELECT TRANSACTION_NO,ORIG_TRACKING_ID,ORIG_TRACKING_ID_SERV,REFUND_REASON_CODE,REFUND_TYPE,SR_CATEGORY,SR_TRANSACTION_NO FROM DEPOSIT_REVERSAL_APS where ACCOUNT_EXTERNAL_ID='"
				+ accountId + "' and STATUS_CODE=" + INITIAL_STATUS_CODE_POSTFX
				+ " and JOB_ID IS NULL ORDER BY NO_OF_HIT,TRANSACTION_NO";

		log.info("QUERY fetchRefundDetails++" + str.toString() + " and account_no is-->" + accountId);
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection fetchRefundDetails __________" + con + " and account_no is-->" + accountId);

		} catch (Exception e) {
			log.info("Connection not established ", e);
		}

		if (con != null) {
			try {
				con.setAutoCommit(false);
				preparedStatement = con.prepareStatement(str);
				rs = preparedStatement.executeQuery();
				try {
					if (rs != null) {
						while (rs.next()) {
							DepositReversalDetails depositReversalDetailsDTO = new DepositReversalDetails();
							depositReversalDetailsDTO.setTransactionNo(rs.getInt(1));
							depositReversalDetailsDTO.setOrigTrackingId(rs.getString(2));
							depositReversalDetailsDTO.setOrigTrackinIdServ(rs.getString(3));
							depositReversalDetailsDTO.setRefundReasonCode(rs.getString(4));
							depositReversalDetailsDTO.setRefundType(rs.getString(5));
							log.info("refundtype in fetchDepositReversalDetails------>>" + rs.getString(5));
							depositReversalDetailsDTO.setSrCategory(rs.getString(6));
							depositReversalDetailsDTO.setSrTransactionNo(rs.getInt(7));
							depositReversalDetailsList.add(depositReversalDetailsDTO);
						}
					}
				} catch (Exception e) {
					log.info("Query execution of fetchDepositReversalDetails ", e);
				} finally {
					if (con != null) {
						try {
							con.commit();
							preparedStatement.close();
							rs.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in the fetchDepositReversalDetails", e);
						}
					}
				}
			} catch (Exception e) {
				log.info("Query execution of fetchDepositReversalDetails ", e);
			}

		}
		log.info("list fetchDepositReversalDetails-->>" + depositReversalDetailsList + " and account_no is-->"
				+ accountId);
		log.info("END--->in fetchDepositReversalDetails method of ClientDAOImpl and account_no is-->" + accountId);
		return depositReversalDetailsList;

	}

	/*
	 * @author :- Geeta Rajput --For NRC FOR failedPayment
	 */

	public List<NrcReversalDetails> fetchNrcReversalDetails(String accountId) throws Exception {

		log.info("START--->in fetchNrcReversalDetails method of ClientDAOImpl and account_no is-->" + accountId);
		List<NrcReversalDetails> nrcReversalDetailsList = new ArrayList<NrcReversalDetails>();

		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		String str = "SELECT TRANSACTION_NO,ORIG_VIEW_ID FROM NRC_REVERSAL_APS where ACCOUNT_NO='" + accountId
				+ "' and STATUS_CODE=" + INITIAL_STATUS_CODE_POSTFX
				+ " and JOB_ID IS NULL ORDER BY TRANSACTION_NO,NO_OF_HIT";

		log.info("QUERY in fetchNrcReversalDetails++" + str.toString() + " and account_no is-->" + accountId);
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection in fetchNrcReversalDetails __________" + con + " and account_no is-->" + accountId);

		} catch (Exception e) {
			log.info("Connection not established in fetchNrcReversalDetails", e);
		}
		if (con != null) {
			try {
				con.setAutoCommit(false);
				preparedStatement = con.prepareStatement(str);
				rs = preparedStatement.executeQuery();
				try {

					if (rs != null) {
						while (rs.next()) {
							NrcReversalDetails nrcReversalDetailsDTO = new NrcReversalDetails();
							nrcReversalDetailsDTO.setTransactionNo(rs.getInt(1));
							nrcReversalDetailsDTO.setOrigViewId(rs.getString(2));
							log.info(
									"Orig view id from nrc reversal in fetchNrcReversalDetails -->>" + rs.getString(2));
							nrcReversalDetailsList.add(nrcReversalDetailsDTO);
						}
					}

				} catch (Exception e) {
					log.info("Query execution of fetchNrcReversalDetails ", e);
				} finally {
					if (con != null) {
						try {
							con.commit();
							preparedStatement.close();
							rs.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in the fetchNrcReversalDetails", e);
						}
					}

				}
			} catch (Exception e) {
				log.info("Query execution of fetchNrcReversalDetails ", e);
			}

		}
		log.info("list in fetchNrcReversalDetails-->>" + nrcReversalDetailsList + " and account_no is-->" + accountId);
		log.info("END--->in fetchNrcReversalDetails method of ClientDAOImpl and account_no is-->" + accountId);
		return nrcReversalDetailsList;

	}

	//////////////////////////////// For NRC CHEQUE
	//////////////////////////////// BOUNCE///////////////////////////////////

	public List<NrcDetails> fetchNrcChequeBounceDetails(String accountId) throws Exception {

		log.info("START--->in fetchNrcChequeBounceDetails method of ClientDAOImpl and account_no is-->" + accountId);
		List<NrcDetails> nrcChequeBounceDetailsList = new ArrayList<NrcDetails>();

		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		// String date = "to_char(sysdate ,'YYYY-MM-DD\"" + "T" + "\"HH:MM:SS')
		// as EFFECTIVEDATE";
		// Add ref no(cheque no for NRC chq bounce kci)
		String str = "SELECT S_NO,NRC_AMOUNT,NRC_CODE,RETRIAL_ATTEMPTS,BOUNCE_REASON,REF_NUMBER ,transaction_id,lob,APS_FLAG FROM AIRTL_CHQ_BOUNCE_NRC_RECORDS where ACC_EXT_ID='"
				+ accountId

				+ "' and FX_STATUS=" + INITIAL_STATUS_CODE_CHEUQE
				+ " AND JOB_ID is null ORDER BY RETRIAL_ATTEMPTS,S_NO";

		log.info("QUERY fetchNrcChequeBounceDetails ++" + str.toString() + " and account_no is-->" + accountId);
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection fetchNrcChequeBounceDetails  __________" + con + " and account_no is-->" + accountId);

		} catch (Exception e) {
			log.info("Connection not established ", e);
		}

		if (con != null) {
			try {
				con.setAutoCommit(false);
				preparedStatement = con.prepareStatement(str);
				rs = preparedStatement.executeQuery();
				log.info("resultset in fetchNrcChequeBounceDetails-->" + rs + " and account_no is-->" + accountId);
				try {
					if (rs != null) {
						while (rs.next()) {
							NrcDetails nrcDetailsDTO = new NrcDetails();
							nrcDetailsDTO.setsNo(rs.getInt(1));
							nrcDetailsDTO.setNrcAmount(rs.getDouble(2));
							nrcDetailsDTO.setTypeIdNrc(rs.getInt(3));
							nrcDetailsDTO.setNoOfHit(rs.getInt(4));
							// nrcDetailsDTO.setEffectiveDate(rs.getString(4));
							nrcDetailsDTO.setAnnotation(rs.getString(5));
							nrcDetailsDTO.setRefNumber(rs.getString(6));
							nrcDetailsDTO.setTransactionNo(rs.getInt(7));
							nrcDetailsDTO.setLob(rs.getString(8));
							nrcDetailsDTO.setApsFlag(rs.getString(9));
							nrcChequeBounceDetailsList.add(nrcDetailsDTO);
						}
					}

				} catch (Exception e) {
					log.info("Query execution of fetchNrcChequeBounceDetails ", e);
				} finally {
					if (con != null) {
						try {
							con.commit();
							preparedStatement.close();
							rs.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in the fetchNrcReversalDetails", e);
						}
					}

				}
			} catch (Exception e) {
				log.info("Query execution of fetchNrcChequeBounceDetails ", e);
			}

		}
		log.info("list in fetchNrcChequeBounceDetails-->>" + nrcChequeBounceDetailsList + " and account_no is-->"
				+ accountId);
		log.info("END--->in fetchNrcChequeBounceDetails method of ClientDAOImpl and account_no is-->" + accountId);
		return nrcChequeBounceDetailsList;

	}

	/////////////////// For updating values in cheque bounce
	/////////////////// table///////////////////////////////////////

	public String updateResponseForNrcChequeBounce(String statusDescription, int trackingId, int trackingServId,
			NrcDetails nrcChequeBounceDetails, String tableName, int viewId, int jobId) throws Exception {

		log.info("START--in updateResponseForNrcChequeBounce in ClientDAOImpl----------- ");
		Connection con = null;
		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;
		int retrialAttempts = nrcChequeBounceDetails.getNoOfHit();
		PreparedStatement preparedStatement = null;
		String view_id = String.valueOf(viewId);

		/*
		 * log.info("ESB_WS_Response:" + jobId + ":APS_UPDATE_RESPONSE" +
		 * StatusDescription + "," + trackingId + "," + trackingServId + "," +
		 * nrcChequeBounceDetails.getTransactionNo() + "," + tableName + "," +
		 * viewID + "," + jobId + ",Response");
		 */

		if (trackingId != 0 && trackingServId != 0) {

			log.info("ESBWSResponse|" + jobId + "|" + nrcChequeBounceDetails.getTransactionNo() + "|" + tableName
					+ "|update " + tableName + " set VIEW_ID='" + view_id + "',FX_ERROR_DESCRIPTION='"
					+ statusDescription + "',FX_STATUS = " + SUCCESS_STATUS_CODE_CHEUQE
					+ ",FX_POSTED_DATE = sysdate where S_NO=" + nrcChequeBounceDetails.getTransactionNo() + ""
					+ " and APS_FLAG='APS' and ACC_EXT_ID='" + nrcChequeBounceDetails.getAcctNo() + "'");

			sql = "UPDATE " + tableName + " SET VIEW_ID='" + view_id + "',FX_ERROR_DESCRIPTION='" + statusDescription
					+ "',FX_STATUS = " + SUCCESS_STATUS_CODE_CHEUQE + ",FX_POSTED_DATE = sysdate where S_NO="
					+ nrcChequeBounceDetails.getTransactionNo() + "" + " and APS_FLAG='APS' and ACC_EXT_ID='"
					+ nrcChequeBounceDetails.getAcctNo() + "'";
		} else {

			log.info("no of hit of updateResponseForNrcChequeBounce---" + retrialAttempts);
			retrialAttempts = retrialAttempts + 1;
			// if(retrialAttempts<3){
			if (((retrialAttempts + 1) % 3) != 0) {

				log.info("ESBWSResponse|<" + jobId + ">|<" + nrcChequeBounceDetails.getTransactionNo() + ">|<"
						+ tableName + ">|update " + tableName + " SET FX_ERROR_DESCRIPTION='" + statusDescription
						+ "',FX_STATUS =" + INITIAL_STATUS_CODE_CHEUQE
						+ ",FX_POSTED_DATE=sysdate,JOB_ID=null,RETRIAL_ATTEMPTS=" + retrialAttempts + " "
						+ "where APS_FLAG='APS' and S_NO=" + nrcChequeBounceDetails.getTransactionNo() + "");

				sql = "UPDATE " + tableName + " SET FX_ERROR_DESCRIPTION='" + statusDescription + "',FX_STATUS ="
						+ INITIAL_STATUS_CODE_CHEUQE + ",FX_POSTED_DATE=sysdate,JOB_ID=null,RETRIAL_ATTEMPTS="
						+ retrialAttempts + " " + "where APS_FLAG='APS' and S_NO="
						+ nrcChequeBounceDetails.getTransactionNo() + "";
			} else {

				log.info("ESBWSResponse|<" + jobId + ">|<" + nrcChequeBounceDetails.getTransactionNo() + ">|<"
						+ tableName + ">|update " + tableName + " SET FX_ERROR_DESCRIPTION='" + statusDescription
						+ "',FX_POSTED_DATE = sysdate,JOB_ID=null,RETRIAL_ATTEMPTS=" + retrialAttempts + " "
						+ "where APS_FLAG='APS' and ACC_EXT_ID='" + nrcChequeBounceDetails.getAcctNo() + "' "
						+ "and S_NO=" + nrcChequeBounceDetails.getTransactionNo() + "");

				sql = "UPDATE " + tableName + " SET FX_ERROR_DESCRIPTION='" + statusDescription
						+ "',FX_POSTED_DATE = sysdate,JOB_ID=null,RETRIAL_ATTEMPTS=" + retrialAttempts + " "
						+ "where APS_FLAG='APS' and ACC_EXT_ID='" + nrcChequeBounceDetails.getAcctNo() + "' "
						+ "and S_NO=" + nrcChequeBounceDetails.getTransactionNo() + "";
			}
		}
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection formed in updateResponseForNrcChequeBounce--------->" + con);

		} catch (Exception e) {

			log.info("Connection not established in updateResponseForNrcChequeBounce ", e);
		}

		if (con != null) {
			log.info("query of updateResponseForNrcChequeBounce---" + sql);
			try {
				con.setAutoCommit(false);
				preparedStatement = con.prepareStatement(sql);
				int resultSet = preparedStatement.executeUpdate();
				try {
					if (resultSet > 0) {
						result = RESULT_DB_SUCCESFUL;
					} else {
						result = RESULT_DB_FAILURE;
					}
				} catch (Exception e) {
					log.info("Query execution updateResponseForNrcChequeBounce---->", e);
				} finally {
					if (con != null) {
						try {
							con.commit();
							preparedStatement.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in the updateResponseForNrcChequeBounce", e);
						}
					}
				}
			} catch (Exception e) {

				log.info("Exception in updateResponseForNrcChequeBounce-->", e);
			}

		}
		log.info("END--in updateResponseForNrcChequeBounce in ClientDAOImpl result ---" + result);
		return result;
	}

	/*
	 * @author :- Geeta Rajput --FOR SR_APPROVAL_TASK_CALLBACK
	 */
	/////////////////////// INT_366_1---->>FOR
	/////////////////////// SR_APPROVAL_TASK_CALLBACK//////////////////////

	public Object[] fetchSRApprovalTaskCallbackDetails(int srTransactionNo) throws Exception {

		log.info("START--->in fetchSRApprovalTaskCallbackDetails method of ClientDAOImpl");
		String procSuccess = null;
		Object[] obj = new Object[2];
		// SRApprovalTaskCallbackDetails callbackDetails = new
		// SRApprovalTaskCallbackDetails();
		SRApprovalTaskCallbackDetails srApprovalTaskcallbackDTO = new SRApprovalTaskCallbackDetails();
		srApprovalTaskcallbackDTO.setSr_transaction_no(srTransactionNo);
		Connection con = null;
		CallableStatement callableStatement = null;
		ResultSet rs = null;
		String result = EMPTY_STRING;

		// String str = "{call SIEBEL_CALLBACK_APS_1(?,?,?) }";
		String str = "{call SIEBEL_CALLBACK_APS(?,?,?) }";

		log.info("QUERY in fetchSRApprovalTaskCallbackDetails---->>+" + str.toString());
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection in fetchSRApprovalTaskCallbackDetails __________" + con);

		} catch (Exception e) {
			log.info("Connection not established in fetchSRApprovalTaskCallbackDetails", e);
		}
		if (con != null) {
			// callableStatement = con.prepareCall(str);
			try {
				con.setAutoCommit(false);
				callableStatement = con.prepareCall(str);

				callableStatement.setInt(1, srTransactionNo);
				callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
				callableStatement.registerOutParameter(3, Types.VARCHAR);

				callableStatement.executeUpdate();
				result = callableStatement.getString(3);
				// if (result.contains(SUCCESS)) {

				rs = (ResultSet) callableStatement.getObject(2);

				while (rs != null && rs.next()) {

					procSuccess = "SUCCESS";
					srApprovalTaskcallbackDTO.setSrNumber(rs.getString("sr_number"));
					log.info("srnumber in fetchSRApprovalTaskCallbackDetails------>>>" + rs.getString("sr_number"));
					srApprovalTaskcallbackDTO.setNoOfHit(rs.getInt("no_of_hit"));
					srApprovalTaskcallbackDTO.setStatus(rs.getString("status"));
					srApprovalTaskcallbackDTO.setReasonCode(rs.getString("reason_code"));
					srApprovalTaskcallbackDTO.setRefundAmount(rs.getString("refund_amount"));
					srApprovalTaskcallbackDTO.setChequeNo(rs.getString("cheque_no"));
					srApprovalTaskcallbackDTO.setDocketNo(rs.getString("docket_no"));
					srApprovalTaskcallbackDTO.setTransactionNo(rs.getString("transaction_no"));
					srApprovalTaskcallbackDTO.setChequeDate(rs.getString("cheque_date"));
					srApprovalTaskcallbackDTO.setBankAccountNo(rs.getString("bank_account_no"));
					srApprovalTaskcallbackDTO.setBankName(rs.getString("bank_name"));
					srApprovalTaskcallbackDTO.setIfsc(rs.getString("ifsc"));
					srApprovalTaskcallbackDTO.setNachLimit(rs.getInt("nach_limit"));
					// callbackDetailsDetailsList.add(srApprovalTaskcallbackDTO);
				}

				obj[0] = procSuccess;
				obj[1] = srApprovalTaskcallbackDTO;

			} catch (Exception e) {
				log.info("Query execution of fetchSRApprovalTaskCallbackDetails ", e);
			} finally {
				if (con != null) {
					try {
						con.commit();
						rs.close();
						callableStatement.close();
						con.close();
					} catch (Exception e) {
						log.info("Exception in the fetchSRApprovalTaskCallbackDetails", e);
					}
				}

			}
		}
		log.info("list in fetchSRApprovalTaskCallbackDetails-->>" + srApprovalTaskcallbackDTO);
		log.info("END--->in fetchSRApprovalTaskCallbackDetails method of ClientDAOImpl");
		return obj;

	}

	/////////////////////// update response for Seibel
	/////////////////////// callback////////////////////////////////////

	public String updateResponseForSeibelCallback(String statusCodeWeb, String StatusDescription,
			SRApprovalTaskCallbackDetails srApprovalTaskCallbackDetails, String statusCode, int jobId)
					throws Exception {

		log.info("START--in updateResponseForSeibelCallback in ClientDAOImpl ");
		Connection con = null;
		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;
		int srTransactionNo = srApprovalTaskCallbackDetails.getSr_transaction_no();

		PreparedStatement preparedStatement = null;
		int noOfHit = srApprovalTaskCallbackDetails.getNoOfHit();

		if (CommonUtil.isNotNull(statusCodeWeb) && statusCodeWeb.contains(STATUS_CODE_HTTP)
				&& statusCode.contains(STATUS_CODE_S)) {

			log.info("ESBWSResponse|" + jobId + "|" + srApprovalTaskCallbackDetails.getSr_transaction_no()
			+ "|SR_DETAILS_APS|update SR_DETAILS_APS SET SIEBEL_STATUS_DESCRIPTION='" + StatusDescription
			+ "',SIEBEL_PUSH_CODE=" + SUCCESS_STATUS_CODE_SIEBEL
			+ ",MODIFIED_DATE=sysdate,STATUS='Resolved,sent to Seibel' " + "where SR_TRANSACTION_NO="
			+ srApprovalTaskCallbackDetails.getSr_transaction_no() + " ");

			/*
			 * sql =
			 * "UPDATE SR_DETAILS_APS SET SIEBEL_STATUS_DESCRIPTION=?,SIEBEL_STATUS_CODE="
			 * + SUCCESS_STATUS_CODE_SIEBEL +
			 * ",MODIFIED_DATE=sysdate ,CHANGE_WHO='APS'" +
			 * "where SR_TRANSACTION_NO=" +
			 * srApprovalTaskCallbackDetails.getSr_transaction_no() + " ";
			 */

			sql = "UPDATE SR_DETAILS_APS SET SIEBEL_STATUS_DESCRIPTION=?,SIEBEL_PUSH_CODE=" + SUCCESS_STATUS_CODE_SIEBEL
					+ ",MODIFIED_DATE=sysdate,STATUS='Resolved,sent to Seibel' " + "where SR_TRANSACTION_NO="
					+ srApprovalTaskCallbackDetails.getSr_transaction_no() + " ";
		} else {

			log.info("no of hit of updateResponseForSeibelCallback--->" + noOfHit);
			// mod(posting_retrial_attempts+1,3)!=0
			// noOfHit = noOfHit + 1;
			// if (noOfHit < 3) {
			log.info("no of hit of StatusDescription--->" + StatusDescription);
			if (((noOfHit + 1) % 3) != 0) {

				noOfHit = noOfHit + 1;

				log.info("ESBWSResponse|<" + jobId + ">|<" + srApprovalTaskCallbackDetails.getSr_transaction_no()
				+ ">|<SR_DETAILS_APS>|update SR_DETAILS_APS SET SIEBEL_STATUS_DESCRIPTION='" + StatusDescription
				+ "',MODIFIED_DATE=sysdate,STATUS='Resolved,failed sending to Seibel',JOB_ID=null,no_of_hit="
				+ noOfHit + " " + "where SR_TRANSACTION_NO="
				+ srApprovalTaskCallbackDetails.getSr_transaction_no() + "");

				sql = "UPDATE SR_DETAILS_APS SET SIEBEL_STATUS_DESCRIPTION=?,MODIFIED_DATE=sysdate,STATUS='Resolved,failed sending to Seibel',JOB_ID=null,no_of_hit="
						+ noOfHit + " " + "where SR_TRANSACTION_NO="
						+ srApprovalTaskCallbackDetails.getSr_transaction_no() + "";
			} else {
				noOfHit = noOfHit + 1;

				log.info("ESBWSResponse|<" + jobId + ">|<" + srApprovalTaskCallbackDetails.getSr_transaction_no()
				+ ">|<SR_DETAILS_APS>|update SR_DETAILS_APS SET SIEBEL_STATUS_DESCRIPTION='" + StatusDescription
				+ "',SIEBEL_PUSH_CODE=" + FAILURE_STATUS_CODE_SIEBEL
				+ ",MODIFIED_DATE=sysdate,STATUS='Resolved,failed sending to Seibel',JOB_ID=null,no_of_hit="
				+ noOfHit + " " + "where SR_TRANSACTION_NO="
				+ srApprovalTaskCallbackDetails.getSr_transaction_no() + "");

				sql = "UPDATE SR_DETAILS_APS SET SIEBEL_STATUS_DESCRIPTION=?,SIEBEL_PUSH_CODE="
						+ FAILURE_STATUS_CODE_SIEBEL
						+ ",MODIFIED_DATE=sysdate,STATUS='Resolved,failed sending to Seibel',JOB_ID=null,no_of_hit="
						+ noOfHit + " " + "where SR_TRANSACTION_NO="
						+ srApprovalTaskCallbackDetails.getSr_transaction_no() + "";
			}
		}
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection formed in updateResponseForSeibelCallback--------->" + con);
			// con.setAutoCommit(false);
		} catch (Exception e) {

			log.info("Connection not established in updateResponseForSeibelCallback ", e);
		}

		if (con != null) {
			log.info("query of updateResponseForSeibelCallback---" + sql + " and sr_transaction_no--->>"
					+ srTransactionNo);
			try {
				con.setAutoCommit(false);
				preparedStatement = con.prepareStatement(sql);
				preparedStatement.setString(1, StatusDescription);
				int resultSet = preparedStatement.executeUpdate();
				try {
					if (resultSet > 0) {
						result = RESULT_DB_SUCCESFUL;
					} else {
						result = RESULT_DB_FAILURE;
					}
				} catch (Exception e) {
					log.info("Query execution updateResponseForSeibelCallback---->", e);
				} finally {
					if (con != null) {
						try {
							con.commit();
							preparedStatement.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in the updateResponseForSeibelCallback", e);
						}
					}

				}
			} catch (Exception e) {

				log.info("Exception in updateResponseForSeibelCallback-->", e);
			}

		}
		log.info("END--in updateResponseForSeibelCallback in ClientDAOImpl result ---" + result
				+ " and sr_transaction_no--->>" + srTransactionNo);
		return result;
	}

	// common for all
	public String updateResponse(String statusDescription, int trackingId, int trackingServId, int transactionNo,
			String tableName, int viewId, int jobId, String annotation3, String annotation5, String faultTrace)
					throws Exception {

		log.info("START--in updateResponse in ClientDAOImpl for transaction_no-->" + transactionNo
				+ " and table name--->" + tableName);
		log.info("tran no in updateResponse----->>>" + transactionNo + " and table name--->" + tableName);
		Connection con = null;
		CallableStatement callableStatement = null;

		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;

		log.info("ESBWSResponse|" + jobId + "|" + transactionNo + "|" + tableName + "|exec APS_UPDATE_RESPONSE('"
				+ statusDescription + "'," + trackingId + "," + trackingServId + "," + transactionNo + ",'" + tableName
				+ "'," + viewId + ",'" + annotation3 + "','" + annotation5 + "','" + faultTrace + "',:response)");

		sql = "{call APS_UPDATE_RESPONSE(?,?,?,?,?,?,?,?,?,?)}";

		try {

			try {
				con = ConnectionUtil.getConnection();
				con.setAutoCommit(false);

			} catch (Exception e) {
				log.info("Connection not established ", e);
			}
			if (con != null) {
				try {
					callableStatement = con.prepareCall(sql);
					callableStatement.setInt(1, trackingId);
					callableStatement.setInt(2, trackingServId);
					callableStatement.setString(3, statusDescription);
					callableStatement.setInt(4, transactionNo);
					callableStatement.setString(5, tableName);
					callableStatement.setInt(6, viewId);
					callableStatement.setString(7, annotation3);
					callableStatement.setString(8, annotation5);
					callableStatement.setString(9, faultTrace);

					callableStatement.registerOutParameter(10, Types.INTEGER);
					callableStatement.executeUpdate();
					int count = callableStatement.getInt(10);
					log.info("updated rows in updateResponse --->>" + count + " for transaction_no-->" + transactionNo
							+ " and table name--->" + tableName);
					if (count > 0) {
						result = RESULT_DB_SUCCESFUL;
					} else {
						result = RESULT_DB_FAILURE;
					}
				} catch (Exception e) {
					log.info("Exception in updateResponse  ", e);
				}
			}
		} catch (Exception e) {
			log.info("Exception in updateResponse  ", e);
		} finally {
			if (con != null) {
				try {
					con.commit();
					callableStatement.close();
					con.close();
				} catch (Exception e) {
					log.info("Exception in the updateResponse", e);
				}
			}

		}
		log.info("END--in updateResponse in ClientDAOImpl result --->>" + result + " for transaction_no-->"
				+ transactionNo + " and table name--->" + tableName);
		return result;
	}

	public String fetchTableName(String fileIdentifier) throws Exception {

		log.info("START--->in fetchTableName method of ClientDAOImpl and file_identifier is" + fileIdentifier);
		String tableName = EMPTY_STRING;
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String str = "SELECT DISTINCT TABLE_NAME FROM " + " FILE_IDENTIFIER_MST_APS where FILE_IDENTIFIER='"
				+ fileIdentifier + "'";

		log.info("QUERY in fetchTableName ++" + str.toString() + "and file_identifier is" + fileIdentifier);
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection in fetchTableName------>" + con + "and file_identifier is" + fileIdentifier);

		} catch (Exception e) {
			log.info("Connection not established ", e);
		}

		log.info("connection made...and file_identifier is" + fileIdentifier);
		if (con != null) {
			try {
				con.setAutoCommit(false);
				preparedStatement = con.prepareStatement(str);
				rs = preparedStatement.executeQuery();
				try {
					if (rs != null) {
						while (rs.next()) {
							tableName = rs.getString(1);
						}
					}

				} catch (Exception e) {
					log.info("Query execution of fetchTableName ", e);
				} finally {
					if (con != null) {
						try {
							con.commit();
							preparedStatement.close();
							rs.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in the fetchTableName", e);
						}
					}

				}
			} catch (Exception e) {
				log.info("Query execution of fetchTableName ", e);
			}

		}

		log.info("END--->in fetchTableName method of ClientDAOImpl tableName-->" + tableName + "and file_identifier is"
				+ fileIdentifier);
		return tableName;
	}

	/**
	 * This method is to derive record type of a given account NUmber.
	 * 
	 * @throws Exception
	 */
	public List deriveRecordType(String account_external_id) throws Exception {
		log.info("START--->in deriveRecordType method of ClientDAOImpl and account_no is:" + account_external_id);
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		List list = new ArrayList<>();
		String str = "SELECT  UPPER(record_type)  FROM AIRTL_CUST_PAYMENT_DETAILS WHERE ACCT_EXT_ID='"
				+ account_external_id
				+ "' and TRACKING_ID Is null and  TRACKING_ID_SERV is null and posting_status_fx in ('0') and (mod(posting_retrial_attempts,3)!=0 or  posting_retrial_attempts=0)";

		log.info("QUERY in fetchTableName ++" + str.toString() + "and account_no is:" + account_external_id);
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection in deriveRecordType------>" + con + "and account_no is:" + account_external_id);

		} catch (Exception e) {
			log.info("Connection not established  in deriveRecordType", e);
		}

		log.info("connection made...and account_no is:" + account_external_id);
		if (con != null) {
			try {
				con.setAutoCommit(false);
				preparedStatement = con.prepareStatement(str);
				rs = preparedStatement.executeQuery();
				try {
					if (rs != null) {
						while (rs.next()) {
							// PostPaymentToFXRequest postPaymentToFXRequest =
							// new PostPaymentToFXRequest();
							list.add(rs.getString(1));
							// postPaymentToFXRequestList.add(postPaymentToFXRequest);
						}
					}

				} catch (Exception e) {
					log.info("Query execution of deriveRecordType ", e);
				} finally {
					if (con != null) {
						try {
							con.commit();
							preparedStatement.close();
							rs.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in the deriveRecordType", e);
						}
					}

				}
			} catch (Exception e) {
				log.info("Query execution of deriveRecordType ", e);
			}

		}

		log.info("END--->in deriveRecordType method of ClientDAOImpl postPaymentToFXRequestList -->" + list
				+ "and account_no is:" + account_external_id);
		return list;
	}

	public Map getFixedThreadPool() {

		log.info("START----in getFixedThreadPool method of ClientDAOImpl");
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String fxthread = null;
		String fxDepenThraed = null;
		String siebelThread = null;
		Map map = null;
		try {

			String query = "SELECT UPPER(PARAMETER_NAME),PARAMETER_VALUE FROM SYSTEM_PARAMETERS_APS WHERE UPPER(PARAMETER_NAME) in ( 'FX_THREAD','FX_DEPENDENT_THREAD','SIEBEL_THREAD') ";
			try {
				con = ConnectionUtil.getConnection();
			} catch (Exception e) {
				log.info("Connection not established  in getFixedThreadPool", e);
			}

			if (con != null) {
				try {

					ps = con.prepareStatement(query);
					rs = ps.executeQuery();

					map = new HashMap();
					while (rs.next()) {

						map.put(rs.getString(1), rs.getString(2));

					}
					log.info(map);

					fxthread = (String) map.get("FX_THREAD");
					fxDepenThraed = (String) map.get("FX_DEPENDENT_THREAD");
					siebelThread = (String) map.get("SIEBEL_THREAD");
				} catch (Exception e) {
					log.info("Exception in the getFixedThreadPool-->", e);
				}

			}

		} catch (Exception e) {
			log.info("Exception in the getFixedThreadPool-->", e);
		} finally {

			if (con != null) {
				try {
					con.close();
					ps.close();
					rs.close();
				} catch (Exception e) {
					log.info("Exception in the getFixedThreadPool", e);
				}
			}

		}
		log.info("END----in getFixedThreadPool method of ClientDAOImpl");

		return map;
	}

	/**
	 * This method controls the execution.
	 * 
	 * @param apsFlag
	 * @param account_external_id
	 * @param service_multi_type
	 * @return String
	 */
	public String deriveApsFlagAndUpdate(String apsFlag, String account_external_id, String msisdn,
			String service_multi_type) {
		return null;
	}

	/**
	 * Description -
	 * 
	 * @return List of list data from query
	 */
	public Object[] callFXPostingDependent() {
		log.info("start callFXPostingDependent----->>>");
		Connection conn = null;
		List<List> list = null;
		int jobId = 0;
		Object[] obj = null;

		// PROC RENAMED ON 23 JAN
		final String procedureCall = "{call FX_POSTING_DEPENDENT_APS(?,?,?,?,?,?,?)}";
		try {
			try {
				conn = ConnectionUtil.getConnection();
			} catch (Exception e) {
				// TODO: handle exception
				log.info("Connection not established  in callFXPostingAPS1", e);
			}

			if (conn != null) {
				try {

					CallableStatement callableStatement = conn.prepareCall(procedureCall);
					callableStatement.registerOutParameter(1, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(2, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(3, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(4, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(5, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(6, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(7, Types.INTEGER);

					callableStatement.executeUpdate();
					// callableStatement.executeQuery();

					ARRAY array_accountExternalID = (ARRAY) callableStatement.getArray(1);
					ARRAY array_msisdn = (ARRAY) callableStatement.getArray(2);
					ARRAY array_serviceMultiType = (ARRAY) callableStatement.getArray(3);
					ARRAY array_serviceToUpdate = (ARRAY) callableStatement.getArray(4);
					ARRAY array_int632 = (ARRAY) callableStatement.getArray(5);
					ARRAY array_int619 = (ARRAY) callableStatement.getArray(6);
					jobId = callableStatement.getInt(7);
					log.info("JOBID-->> " + jobId);
					// System.out.println("array_accountExternalID-->>
					// "+array_accountExternalID.length());
					// log.info("array_accountExternalID-->>
					// "+array_apsFlag.length());
					list = new ArrayList<List>();

					if (array_serviceMultiType != null && array_serviceMultiType.length() > 0) {
						for (int x = 0; x < array_serviceMultiType.length(); x++) {

							List<String> resList = new ArrayList<String>();
							String[] accountExternalID = (String[]) array_accountExternalID.getArray();

							String[] msisdn = (String[]) array_msisdn.getArray();

							String[] serviceMultiType = (String[]) array_serviceMultiType.getArray();

							String[] serviceToUpdate = (String[]) array_serviceToUpdate.getArray();

							String[] valInt632 = (String[]) array_int632.getArray();
							String[] valInt619 = (String[]) array_int619.getArray();

							resList.add(accountExternalID[x]);
							resList.add(msisdn[x]);
							resList.add(serviceMultiType[x]);
							resList.add(serviceToUpdate[x]);
							resList.add(valInt632[x]);
							resList.add(valInt619[x]);
							list.add(resList);

						}
					}
					log.info(list);
					callableStatement.close();
				} catch (Exception e) {
					// TODO: handle exception
					log.info("callFXPostingAPS1--" + e);
				}

			}
			obj = new Object[2];
			obj[0] = list;
			obj[1] = jobId;
			// return list;
		} catch (Exception e) {
			log.info("callFXPostingAPS1--" + e);
		} finally {
			try {
				if (conn != null) {
					conn.close();

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				log.info("callFXPostingAPS1--" + e);
			}

		}
		log.info("end callFXPostingDependent----->>>");
		return obj;

	}

	/**
	 * Description -
	 * 
	 * @return List of list data from query
	 */
	public Object[] getFXPostingAPSDetails(String jobId, String level, String procType) {
		log.info("start callFXPostingAPS----->>>");
		Connection conn = null;
		List<List> list = null;
		Object[] obj = null;
		// int jobId = 0;
		final String procedureCall = "{call FX_SR_DETAILS_APS(?,?,?,?,?,?,?,?,?,?,?,?)}";
		try {
			try {
				conn = ConnectionUtil.getConnection();
			} catch (Exception e) {
				// TODO: handle exception
				log.info("callFXPostingAPS connection formation--" + e);
			}

			if (conn != null) {
				try {

					System.out.println("start calling fx posting");
					CallableStatement callableStatement = conn.prepareCall(procedureCall);
					callableStatement.registerOutParameter(1, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(2, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(3, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(4, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(5, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(6, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(7, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(8, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(9, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.setInt(10, Integer.valueOf(jobId));
					callableStatement.setString(11, level);
					callableStatement.setString(12, procType);

					// callableStatement.executeUpdate();
					callableStatement.executeQuery();

					ARRAY array_accountExternalID = (ARRAY) callableStatement.getArray(1);
					ARRAY array_msisdn = (ARRAY) callableStatement.getArray(2);
					ARRAY array_serviceMultiType = (ARRAY) callableStatement.getArray(3);
					ARRAY array_serviceToUpdate = (ARRAY) callableStatement.getArray(4);
					ARRAY array_int632 = (ARRAY) callableStatement.getArray(5);
					ARRAY array_int619 = (ARRAY) callableStatement.getArray(6);
					// jobId = callableStatement.getInt(7);
					log.info("JOBID-->> " + jobId);
					// System.out.println("array_accountExternalID-->>
					// "+array_accountExternalID.length());
					// log.info("array_accountExternalID-->>
					// "+array_apsFlag.length());
					list = new ArrayList<List>();
					System.out.println("array_serviceMultiType.length()--> " + array_serviceMultiType.length());
					if (array_serviceMultiType != null && array_serviceMultiType.length() > 0) {
						for (int x = 0; x < array_serviceMultiType.length(); x++) {

							List<String> resList = new ArrayList<String>();
							String[] accountExternalID = (String[]) array_accountExternalID.getArray();

							String[] msisdn = (String[]) array_msisdn.getArray();

							String[] serviceMultiType = (String[]) array_serviceMultiType.getArray();

							String[] serviceToUpdate = (String[]) array_serviceToUpdate.getArray();

							String[] valInt632 = (String[]) array_int632.getArray();
							String[] valInt619 = (String[]) array_int619.getArray();

							resList.add(accountExternalID[x]);
							resList.add(msisdn[x]);
							resList.add(serviceMultiType[x]);
							resList.add(serviceToUpdate[x]);
							resList.add(valInt632[x]);
							resList.add(valInt619[x]);
							list.add(resList);

						}
					}

					callableStatement.close();
				} catch (Exception e) {
					// TODO: handle exception
					log.info("callFXPostingAPS----" + e);
				}
			}
			obj = new Object[2];
			obj[0] = list;
			obj[1] = jobId;

			// return list;
		} catch (Exception e) {
			log.info("callFXPostingAPS----" + e);
		} finally {
			try {
				if (conn != null) {
					conn.close();

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				log.info("callFXPostingAPS----" + e);
			}

		}
		log.info("end callFXPostingAPS----->>>");
		return obj;

	}

	/**
	 * Description -
	 * 
	 * @return List of list data from query
	 */

	public Object[] getHomesDetails(String i_jobId, String level, String procType) {
		log.info("start getHomesDetails----->>>");

		Connection con = null;
		CallableStatement callableStatement = null;
		List<List> list = null;
		int jobId = 0;
		Object[] obj = null;
		jobId = Integer.valueOf(i_jobId);
		final String procedureCall = "{call FX_SR_DETAILS_APS(?,?,?,?,?,?,?,?,?,?,?,?)}";
		try {
			try {
				con = ConnectionUtil.getConnection();
				con.setAutoCommit(false);
				log.info("con in getHomesDetails========>" + con);
			} catch (Exception e) {
				log.info("Connection not established ", e);
			}
			if (con != null) {
				try {
					callableStatement = con.prepareCall(procedureCall);
					callableStatement.registerOutParameter(1, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(2, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(3, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(4, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(5, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(6, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(7, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(8, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(9, Types.ARRAY, "ARRAY_CHECK_TYPE");

					callableStatement.setInt(10, Integer.valueOf(jobId));
					callableStatement.setString(11, level);
					callableStatement.setString(12, procType);

					callableStatement.executeUpdate();
					// callableStatement.executeQuery();

					ARRAY array_homesId = (ARRAY) callableStatement.getArray(1);
					ARRAY array_accountNumber = (ARRAY) callableStatement.getArray(2);
					ARRAY array_lob = (ARRAY) callableStatement.getArray(3);
					ARRAY array_derivedAmount = (ARRAY) callableStatement.getArray(4);
					ARRAY array_transactionId = (ARRAY) callableStatement.getArray(5);
					ARRAY array_msisdn = (ARRAY) callableStatement.getArray(6);
					ARRAY array_serviceType = (ARRAY) callableStatement.getArray(7);
					ARRAY array_paymentDate = (ARRAY) callableStatement.getArray(8);
					ARRAY array_apsFlag = (ARRAY) callableStatement.getArray(9);
					log.info("JOB_ID getHomesDetails-->> " + jobId);

					list = new ArrayList<List>();
					log.info("array_serviceType.length()->" + array_serviceType.length());
					if (array_serviceType != null && array_serviceType.length() > 0) {
						for (int x = 0; x < array_serviceType.length(); x++) {
							List<String> resList = new ArrayList<String>();
							String[] homesId = (String[]) array_homesId.getArray();

							String[] accountNumber = (String[]) array_accountNumber.getArray();
							String[] lob = (String[]) array_lob.getArray();

							String[] derivedAmount = (String[]) array_derivedAmount.getArray();

							String[] transactionId = (String[]) array_transactionId.getArray();
							String[] msisdn = (String[]) array_msisdn.getArray();
							String[] serviceType = (String[]) array_serviceType.getArray();

							String[] paymentDate = (String[]) array_paymentDate.getArray();
							String[] apsFlag = (String[]) array_apsFlag.getArray();

							resList.add(homesId[x]);
							resList.add(accountNumber[x]);
							resList.add(lob[x]);
							resList.add(derivedAmount[x]);
							resList.add(transactionId[x]);
							resList.add(msisdn[x]);
							resList.add(serviceType[x]);
							resList.add(paymentDate[x]);
							resList.add(apsFlag[x]);

							log.info("resList->>" + resList);
							list.add(resList);
							log.info("list->>" + list);
						}
					}
					callableStatement.close();
				} catch (Exception e) {
					log.info("getHomesDetails--" + e);
				}
			}
			obj = new Object[2];
			obj[0] = list;
			obj[1] = i_jobId;
		} catch (Exception e) {
			log.info("Exception in updateResponse  ", e);
		} finally {
			if (con != null) {
				try {
					con.commit();
					callableStatement.close();
					con.close();
				} catch (Exception e) {
					log.info("Exception in the updateResponse", e);
				}
			}

		}

		return obj;
	}

	/*
	 * public static void main(String[] args) { ClientDAOImpl client = new
	 * ClientDAOImpl(); client.getHomesDetails("123", "1", "FX"); }
	 */

	/**
	 * Description -
	 * 
	 * @return List of list data from query
	 */
	public Object[] getAnchorDetails(String i_jobId, String level, String procType) {

		log.info("start getAnchorDetails----->>>");
		Connection conn = null;
		List<List> list = null;
		int jobId = 0;
		Object[] obj = null;
		jobId = Integer.valueOf(i_jobId);
		// PROC RENAMED ON 23 JAN
		final String procedureCall = "{call FX_SR_DETAILS_APS(?,?,?,?,?,?,?,?,?,?,?,?)}";
		try {
			try {
				conn = ConnectionUtil.getConnection();
				log.info("Connection received in getAnchorDetails=====>" + conn);
			} catch (Exception e) {

				log.info("Connection not established  in getAnchorDetails", e);
			}

			if (conn != null) {
				try {

					CallableStatement callableStatement = conn.prepareCall(procedureCall);
					callableStatement.registerOutParameter(1, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(2, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(3, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(4, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(5, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(6, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(7, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(8, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(9, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.setInt(10, Integer.valueOf(jobId));
					callableStatement.setString(11, level);
					callableStatement.setString(12, procType);

					callableStatement.executeUpdate();
					// callableStatement.executeQuery();

					ARRAY array_AccountNumber = (ARRAY) callableStatement.getArray(1);
					ARRAY array_lob = (ARRAY) callableStatement.getArray(2);
					ARRAY array_msisdn = (ARRAY) callableStatement.getArray(3);
					ARRAY array_service_type = (ARRAY) callableStatement.getArray(4);
					// jobId = callableStatement.getInt(3);
					System.out.println("JOB_ID getAnchorDetails-->> " + jobId);

					list = new ArrayList<List>();
					if (array_service_type != null && array_service_type.length() > 0) {
						for (int x = 0; x < array_service_type.length(); x++) {

							List<String> resList = new ArrayList<String>();
							String[] accountNumber = (String[]) array_AccountNumber.getArray();

							String[] lob = (String[]) array_lob.getArray();
							String[] serviceType = (String[]) array_service_type.getArray();
							String[] msisdn = (String[]) array_msisdn.getArray();

							resList.add(accountNumber[x]);
							resList.add(lob[x]);
							resList.add(msisdn[x]);
							resList.add(serviceType[x]);

							list.add(resList);

						}
					}

					callableStatement.close();
					conn.close();
					log.info("connection call status is:" + conn);

				} catch (Exception e) {
					log.info("getAnchorDetails--" + e);
				}

			}
			obj = new Object[2];
			obj[0] = list;
			obj[1] = i_jobId;
			// return list;
		} catch (Exception e) {
			log.info("getAnchorDetails--" + e);
		} /*
		 * finally { try { if (conn != null) { conn.close();
		 * log.info("in finally block connection status is:-"+conn);
		 * 
		 * } } catch (SQLException e) { log.info("getAnchorDetails--" + e);
		 * }
		 * 
		 * }
		 */
		log.info("end getAnchorDetails----->>>");
		return obj;

	}

	public void updateJobStatus(int text, String level) {

		log.info("tran no in updateJobStatus----->>>" + text + " level->" + level);
		Connection con = null;
		CallableStatement callableStatement = null;

		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;

		sql = "{call FX_UPDATE_JOBS_APS(?,?)}";

		try {

			try {
				con = ConnectionUtil.getConnection();

			} catch (Exception e) {
				log.info("Connection not established in updateJobStatus", e);
			}
			if (con != null) {

				callableStatement = con.prepareCall(sql);

				callableStatement.setInt(1, text);
				callableStatement.setString(2, level);

				callableStatement.executeUpdate();

			}
		} catch (Exception e) {
			log.info("Exception in updateJobStatus  ", e);
		} finally {

			if (con != null) {
				try {
					callableStatement.close();
					con.close();
				} catch (Exception e) {
					log.info("Exception in the updateJobStatus", e);
				}
			}

		}

	}

	public void updateAnchorHomesJobsStatus(int jobId, String level, String tableType) {

		log.info("tran no in updateJobStatus----->>>" + jobId + " level->" + level + " tableType->" + tableType);
		Connection con = null;
		CallableStatement callableStatement = null;

		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;

		sql = "{call UPDATE_ANCHOR_HOMES_JOBS(?,?,?)}";

		try {

			try {
				con = ConnectionUtil.getConnection();

			} catch (Exception e) {
				log.info("Connection not established in updateJobStatus", e);
			}
			if (con != null) {

				callableStatement = con.prepareCall(sql);

				callableStatement.setInt(1, jobId);
				callableStatement.setString(2, level);
				callableStatement.setString(3, tableType);

				callableStatement.executeUpdate();

			}
		} catch (Exception e) {
			log.info("Exception in updateJobStatus  ", e);
		} finally {

			if (con != null) {
				try {
					callableStatement.close();
					con.close();
				} catch (Exception e) {
					log.info("Exception in the updateJobStatus", e);
				}
			}

		}

	}

	/**
	 * Description -
	 * 
	 * @return List of list data from query
	 */
	public Object[] callFXPostingAPS2(String i_jobId, String level, String procType) {

		log.info("start callFXPostingAPS2----->>>");
		Connection conn = null;
		List<List> list = null;
		int jobId = 0;
		Object[] obj = null;
		jobId = Integer.valueOf(i_jobId);
		// PROC RENAMED ON 23 JAN
		final String procedureCall = "{call FX_SR_DETAILS_APS(?,?,?,?,?,?,?,?,?,?,?,?)}";
		try {
			try {
				conn = ConnectionUtil.getConnection();
			} catch (Exception e) {

				log.info("Connection not established  in callFXPostingAPS2", e);
			}

			if (conn != null) {
				try {
					CallableStatement callableStatement = conn.prepareCall(procedureCall);
					callableStatement.registerOutParameter(1, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(2, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(3, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(4, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(5, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(6, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(7, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(8, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(9, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.setInt(10, Integer.valueOf(jobId));
					callableStatement.setString(11, level);
					callableStatement.setString(12, procType);

					callableStatement.executeUpdate();
					// callableStatement.executeQuery();

					ARRAY array_srTransNumber = (ARRAY) callableStatement.getArray(1);
					ARRAY array_text = (ARRAY) callableStatement.getArray(2);
					// jobId = callableStatement.getInt(3);
					System.out.println("JOB_ID Siebel-->> " + jobId);

					list = new ArrayList<List>();
					if (array_srTransNumber != null && array_srTransNumber.length() > 0) {
						for (int x = 0; x < array_srTransNumber.length(); x++) {

							List<String> resList = new ArrayList<String>();
							String[] srTransID = (String[]) array_srTransNumber.getArray();

							String[] text = (String[]) array_text.getArray();

							resList.add(srTransID[x]);
							resList.add(text[x]);

							list.add(resList);

						}
					}

					callableStatement.close();
				} catch (Exception e) {
					log.info("callFXPostingAPS2--" + e);
				}

			}
			obj = new Object[2];
			obj[0] = list;
			obj[1] = jobId;
			// return list;
		} catch (Exception e) {
			log.info("callFXPostingAPS2--" + e);
		} finally {
			try {
				if (conn != null) {
					conn.close();

				}
			} catch (SQLException e) {
				log.info("callFXPostingAPS2--" + e);
			}

		}
		log.info("end callFXPostingAPS2----->>>");
		return obj;

	}

	public int getMinThread(int fxInputThread,int listThread){

		log.info("fxInputThread----->>>"+fxInputThread);
		log.info("listThread----->>>"+listThread);
		try{
			
				if(fxInputThread>listThread){
					return listThread;
				}
				else{
					return fxInputThread;
				}
			
		}
		catch(Exception e){
			log.info("error----->>>"+e);
		}
		return 20;
	}
	/**
	 * This method update the APS Flag for different tables in DB.
	 * 
	 * @throws InterruptedException
	 */
	public void updateAPSFlag(String i_jobId, String level, String fxThread, String siebelThread, String anchorThread,
			String homesThread) {

		log.info("START----in updateAPSFlag method of ClientDAOImpl");
		List<List> list = null;
		List<List> newList = null;
		// Map mapVal = null;
		// String fxthread = null;
		// String fxDepenThraed = null;
		// String siebelThread = null;
		ExecutorService execServ = null;
		ExecutorService execServ2 = null;
		ExecutorService execServ3 = null;

		ExecutorService execServAnchor = null;
		ExecutorService execServHomes = null;
		List<Future<String>> futures = null;
		int jobIDDependent = 0;
		String procType = null;
		// log.info("outide try block of updateAPSFlag");
		/// will get 4-parameters
		
		try {
			//Class.forName(GenericConfiguration.getDescription("driver_Name"));
			//Class.forName("oracle.jdbc.OracleDriver");
			DriverManager.registerDriver (new oracle.jdbc.OracleDriver());

		} catch (SQLException e) {
			log.info("Class.forName Exception----->",e);

		}
		catch (Exception e) {
			log.info("Class.forName other Exception----->",e);

		}
		
		try {
			log.info("i_jobId-->" + i_jobId + " level->" + level + " fxThread->" + fxThread + " siebelThread->"
					+ siebelThread + " anchorThread->>" + anchorThread + " homesThread->>" + homesThread);

			// getting fixed thread pool size from System parameters

			if (!CommonValidator.isNull(fxThread) && !"0".equals(fxThread)) {

				procType = "FX";
				log.info("start of FX job and procType-->>" + procType);
				if (!CommonValidator.isNull(fxThread)) {
					execServ = Executors.newFixedThreadPool(Integer.valueOf(fxThread));
				}
				log.info("fxthread-->> " + fxThread + " fxDepenThraed-->>5 siebelThread-->> " + siebelThread);

				List<AccountDetailsClientThread> list1 = new ArrayList<>();

				list = new ArrayList<List>();
				// Calling proc and getting result from query
				// changed to test on PT EN
				Object[] obj = getFXPostingAPSDetails(i_jobId, level, procType);

				list = (List<List>) obj[0];
				String jobId = (String) obj[1];
				log.info("JOB_ID IS-->> " + jobId);
				log.info("list IS-->> " + list);

				if (list != null && list.size() > 0) {
					/// adding here
					for (int i = 0; i < list.size(); i++) {

						String account_number = (String) list.get(i).get(0);
						String msisdn = (String) list.get(i).get(1);
						String multiService = (String) list.get(i).get(2);
						String serviceUpdate = (String) list.get(i).get(3);
						String valInt632 = (String) list.get(i).get(4);
						String valInt619 = (String) list.get(i).get(5);

						// deriveApsFlagAndUpdate(apsFlag, account_number,
						// msisdn,multiService);

						AccountDetailsClientThread accountDetailsClientThread = new AccountDetailsClientThread(
								account_number, msisdn, multiService, serviceUpdate, valInt632, valInt619,
								Integer.valueOf(jobId));
						list1.add(accountDetailsClientThread);

					}
					futures = execServ.invokeAll(list1);
				}

				execServ.shutdown();
				updateJobStatus(Integer.valueOf(jobId), level);

				// New Changes added 1 date 03march2017
				
			}
			if (!CommonValidator.isNull(siebelThread) && !"0".equals(siebelThread)) {
				procType = "SIEBEL";
				log.info("start JOB_ID IS jobIDSiebel and procType-->> " + procType + " siebelThread-->>" + siebelThread
						+ " i_jobId-->" + i_jobId);
				// Calling third thread service
				List<List> srTransList = new ArrayList<List>();
				List<AccountDetailsClientThread2> list3 = new ArrayList<>();

				if (!CommonValidator.isNull(siebelThread)) {
					execServ3 = Executors.newFixedThreadPool(Integer.valueOf(siebelThread));
				} else {
					execServ3 = Executors.newFixedThreadPool(5);
				}
				// Executors.defaultThreadFactory();
				Object[] objDep = callFXPostingAPS2(i_jobId, level, procType);
				srTransList = (List<List>) objDep[0];
				int jobIDSiebel = (int) objDep[1];
				log.info("JOB_ID IS jobIDSiebel-->> " + jobIDSiebel);
				log.info("Siebel data List-->> " + srTransList);

				if (srTransList != null && srTransList.size() > 0) {
					/// adding here
					for (int j = 0; j < srTransList.size(); j++) {

						String srTransNumber = (String) srTransList.get(j).get(0);
						String text = (String) srTransList.get(j).get(1);

						AccountDetailsClientThread2 accountDetailsClientThread2 = new AccountDetailsClientThread2(
								srTransNumber, text);
						list3.add(accountDetailsClientThread2);
					}
					futures = execServ3.invokeAll(list3);
				}

				// END New Changes added 3 03march2017

				execServ3.shutdown();
				updateJobStatus(jobIDSiebel, level);
				log.info("end of Siebel job-->>" + procType);
			}
			if (!CommonValidator.isNull(anchorThread) && !"0".equals(anchorThread)) {
				log.info("Start----in anchor Thread method of ClientDAOImpl");

				if (!CommonValidator.isNull(anchorThread)) {
					execServAnchor = Executors.newFixedThreadPool(Integer.valueOf(anchorThread));
				}
				log.info("anchorThread-->> " + anchorThread);

				List<AnchorDetailsThread> list1 = new ArrayList<>();

				list = new ArrayList<List>();
				// Calling proc and getting result from query
				// changed to test on PT EN
				log.info("Calling getAnchorDetails method");
				Object[] obj = getAnchorDetails(i_jobId, level, "ANCHOR");
				log.info("After Calling getAnchorDetails method");
				list = (List<List>) obj[0];
				String jobId = (String) obj[1];
				log.info("JOB_ID IS-->> " + jobId);
				log.info("list IS-->> " + list);

				if (list != null && list.size() > 0) {
					/// adding here
					for (int i = 0; i < list.size(); i++) {

						String account_number = (String) list.get(i).get(0);
						String lob = (String) list.get(i).get(1);
						String msisdn = (String) list.get(i).get(2);
						String serviceType = (String) list.get(i).get(3);

						AnchorDetailsThread anchorDetailsThread = new AnchorDetailsThread(account_number, lob, msisdn,
								serviceType, jobId);
						list1.add(anchorDetailsThread);

					}
					futures = execServAnchor.invokeAll(list1);
				}

				execServAnchor.shutdown();
				updateAnchorHomesJobsStatus(Integer.valueOf(jobId), level, "ANCHOR");

				log.info("END----in anchor Thread method of ClientDAOImpl");

			}
			if (!CommonValidator.isNull(homesThread) && !"0".equals(homesThread)) {
				log.info("Start----in homes thread method of ClientDAOImpl");

				if (!CommonValidator.isNull(homesThread)) {
					execServHomes = Executors.newFixedThreadPool(Integer.valueOf(homesThread));
				}
				log.info("homesThread-->> " + homesThread + " job_id=" + i_jobId + " level ->" + level);

				List<HomesDetailsThread> list1 = new ArrayList<>();

				list = new ArrayList<List>();
				// Calling proc and getting result from query
				// changed to test on PT EN
				Object[] obj = getHomesDetails(i_jobId, level, "HOMES");

				list = (List<List>) obj[0];
				String jobId = (String) obj[1];
				log.info("JOB_ID IS-->> " + jobId);
				log.info("list IS-->> " + list);

				if (list != null && list.size() > 0) {
					/// adding here
					for (int i = 0; i < list.size(); i++) {

						String homesId = (String) list.get(i).get(0);
						String accountNumber = (String) list.get(i).get(1);
						String lob = (String) list.get(i).get(2);

						String derivedAmount = (String) list.get(i).get(3);
						String transactionId = (String) list.get(i).get(4);
						String msisdn = (String) list.get(i).get(5);
						String serviceType = (String) list.get(i).get(6);
						String paymentDate = (String) list.get(i).get(7);
						String apsFlag = (String) list.get(i).get(8);

						HomesDetailsThread homesDetailsThread = new HomesDetailsThread(homesId, accountNumber, lob,
								derivedAmount, transactionId, msisdn, serviceType, jobId, paymentDate, apsFlag);
						list1.add(homesDetailsThread);

					}
					futures = execServHomes.invokeAll(list1);
				}

				execServHomes.shutdown();
				updateAnchorHomesJobsStatus(Integer.valueOf(jobId), level, "HOMES");

				log.info("END----in homes thread method of ClientDAOImpl");

			}
			log.info("END----in deriveApsFlagAndUpdate method of ClientDAOImpl");

		} catch (InterruptedException e) {

			log.info("error-->> ", e);
		}
		log.info("END----in updateAPSFlag method of ClientDAOImpl");
	}

	public void updateJobStatus(int text) {

		log.info("tran no in updateJobStatus----->>>" + text);
		Connection con = null;
		CallableStatement callableStatement = null;

		// String result = EMPTY_STRING;
		String sql = EMPTY_STRING;

		sql = "{call FX_UPDATE_JOB_STATUS_APS(?)}";

		try {

			try {
				con = ConnectionUtil.getConnection();

			} catch (Exception e) {
				log.info("Connection not established in updateJobStatus", e);
			}
			if (con != null) {

				callableStatement = con.prepareCall(sql);

				callableStatement.setInt(1, text);

				callableStatement.executeUpdate();

			}
		} catch (Exception e) {
			log.info("Exception in updateJobStatus  ", e);
		} finally {

			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					log.info("Exception in the updateJobStatus", e);
				}
			}

		}

	}

	/**
	 * Description -
	 * 
	 * @return List of list data from query
	 */
	public Object[] callFXPostingAPS2() {

		log.info("start callFXPostingAPS2----->>>");
		Connection conn = null;
		List<List> list = null;
		int jobId = 0;
		Object[] obj = null;

		// PROC RENAMED ON 23 JAN
		final String procedureCall = "{call FX_POSTING_SRTRANS_APS(?,?,?)}";
		try {
			try {
				conn = ConnectionUtil.getConnection();
			} catch (Exception e) {

				log.info("Connection not established  in callFXPostingAPS2", e);
			}

			if (conn != null) {
				try {
					CallableStatement callableStatement = conn.prepareCall(procedureCall);
					callableStatement.registerOutParameter(1, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(2, Types.ARRAY, "ARRAY_CHECK_TYPE");
					callableStatement.registerOutParameter(3, Types.INTEGER);

					callableStatement.executeUpdate();
					// callableStatement.executeQuery();

					ARRAY array_srTransNumber = (ARRAY) callableStatement.getArray(1);
					ARRAY array_text = (ARRAY) callableStatement.getArray(2);
					jobId = callableStatement.getInt(3);
					System.out.println("JOB_ID Siebel-->> " + jobId);

					list = new ArrayList<List>();
					if (array_srTransNumber != null && array_srTransNumber.length() > 0) {
						for (int x = 0; x < array_srTransNumber.length(); x++) {

							List<String> resList = new ArrayList<String>();
							String[] srTransID = (String[]) array_srTransNumber.getArray();

							String[] text = (String[]) array_text.getArray();

							resList.add(srTransID[x]);
							resList.add(text[x]);

							list.add(resList);

						}
					}
					log.info(list);
					callableStatement.close();
				} catch (Exception e) {
					log.info("callFXPostingAPS2--" + e);
				}

			}
			obj = new Object[2];
			obj[0] = list;
			obj[1] = jobId;
			// return list;
		} catch (Exception e) {
			log.info("callFXPostingAPS2--" + e);
		} finally {
			try {
				if (conn != null) {
					conn.close();

				}
			} catch (SQLException e) {
				log.info("callFXPostingAPS2--" + e);
			}

		}
		log.info("end callFXPostingAPS2----->>>");
		return obj;

	}

	////////////////////////////// For refund create and 632 interface
	////////////////////////////// /////////////////////////////////////

	public String fetchFormCustAccountSummary(String accountId, String fxOutstandingAmount, String mktCode,
			String givenName, String FamilyName,BulkDetails bulkDetails) throws Exception {

		log.info("Start: fetchFormCustAccountSummary in  ClientDAOImpl  and accountId--->" + accountId);

		// String procCall = "{call RESPONSE_APS1(?,?,?)}";
		// Renamed on 23 Jan
		String procCall = "{call UPDATE_REFUND_OUTSTANDING_APS(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
		Connection con = null;
		CallableStatement callableStatement = null;
		String result = EMPTY_STRING;
		log.info("full adress-->>"+bulkDetails.getFullAddress());
		/*String address=null;
		String state=null;
		String zipCode=null;
		String addressType=null;
		Address ad=new Address();
		
		if(bulkDetails.getAddress()!=null && bulkDetails.getAddress().size()>0){
			
			for(int i=0;i<bulkDetails.getAddress().size();i++){
				
				ad=bulkDetails.getAddress().get(i);
				addressType=ad.getAddressType();
				if("BillingAddress".equalsIgnoreCase(addressType)){
					
					address=ad.getAddressLine1()+" "+ad.getAddressLine2()+" "+ad.getAddressLine3()+" "+ad.getCity();
					
					state=ad.getState();
					zipCode=ad.getPincode();
				}
				
			}
		}
*/
		try {
			con = ConnectionUtil.getConnection();
		} catch (Exception e) {
			log.info("In fetchFormCustAccountSummary connection not made", e);
		}
		try {
			if (con != null) {
				try {
					con.setAutoCommit(false);
					log.info("Connection made for fetchFormCustAccountSummary method");
					callableStatement = con.prepareCall(procCall);
					callableStatement.setString(1, accountId);
					callableStatement.setString(2, fxOutstandingAmount);
					callableStatement.setString(3, mktCode);
					callableStatement.setString(4, givenName);
					callableStatement.setString(5, FamilyName);
					callableStatement.setString(6, bulkDetails.getFullAddress());
					callableStatement.setString(7, bulkDetails.getState());
					callableStatement.setString(8, bulkDetails.getZipCode());
					///set rest fields here

					callableStatement.setString(9, bulkDetails.getAlternateContactNumber());
					callableStatement.setString(10, bulkDetails.getB2b2c());
					callableStatement.setString(11, bulkDetails.getLob());
					callableStatement.setString(12, bulkDetails.getDelNO());
					callableStatement.setString(13, bulkDetails.getEmailId());
					
					callableStatement.registerOutParameter(14, Types.VARCHAR);

					callableStatement.executeUpdate();
					result = callableStatement.getString(14);
					if (result.contains(SUCCESS)) {
						result = SUCCESS;
						log.info("OutPut from fetchFormCustAccountSummary in ClientDAOImpl result--->>" + result
								+ " and accountId--->" + accountId);
					} else {
						result = FAILURE;
						log.info("OutPut from fetchFormCustAccountSummary in ClientDAOImpl result--->>" + result
								+ " and accountId--->" + accountId);
					}
				} catch (Exception e) {
					log.info("Exception in fetchFormCustAccountSummary ---", e);
				}

			}
		} catch (Exception e) {
			log.info("Exception in fetchFormCustAccountSummary ---", e);
		} finally {

			if (con != null) {
				try {
					callableStatement.close();
					con.close();
				} catch (Exception e) {
					log.info("Exception in fetchFormCustAccountSummary ---", e);
				}
			}

		}
		log.info("End: fetchFormCustAccountSummary in  ClientDAOImpl result---->" + result + " and accountId--->"
				+ accountId);
		return result;
	}

	/*
	 * @author :- Geeta Rajput--for Adjustment Reversal
	 */
	@Override
	public List<AdjReversalDetails> fetchAdjustmentReversalDetails(String accountId) throws Exception {

		log.info("START--->in fetchAdjustmentReversalDetails method of ClientDAOImpl and account_no is-->" + accountId);
		List<AdjReversalDetails> adjReversalDetailsList = new ArrayList<AdjReversalDetails>();

		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		String str = "SELECT ADJUSTMENT_REASON_CODE,ORIG_BILL_REF_NO,ORIG_BILL_REF_RESETS,ORIG_TRACKING_ID,ORIG_TRACKING_ID_SERV,USER_ID,TRANSACTION_NO FROM ADJ_REVERSAL_APS where ACCOUNT_EXTERNAL_ID='"
				+ accountId + "' and STATUS_CODE=" + INITIAL_STATUS_CODE_POSTFX
				+ " AND JOB_ID is null ORDER BY NO_OF_HIT,TRANSACTION_NO";

		log.info("QUERY fetchAdjustmentReversalDetails ++" + str.toString() + " and account_no is-->" + accountId);
		try {
			con = ConnectionUtil.getConnection();
			log.info(
					"connection fetchAdjustmentReversalDetails __________" + con + " and account_no is-->" + accountId);

		} catch (Exception e) {
			log.info("Connection not established fetchAdjustmentReversalDetails", e);
		}

		if (con != null) {
			con.setAutoCommit(false);
			preparedStatement = con.prepareStatement(str);

			rs = preparedStatement.executeQuery();
			try {
				if (rs != null) {
					while (rs.next()) {
						AdjReversalDetails adjReversalDetailDTO = new AdjReversalDetails();
						adjReversalDetailDTO.setAdjustmentReasonCode(rs.getString(1));
						adjReversalDetailDTO.setOrigBillRefNo(rs.getString(2));
						adjReversalDetailDTO.setOrigBillRefResets(rs.getInt(3));
						adjReversalDetailDTO.setOrigTrackingId(rs.getInt(4));
						adjReversalDetailDTO.setOrigTrackinIdServ(rs.getInt(5));
						adjReversalDetailDTO.setUserId(rs.getString(6));
						adjReversalDetailDTO.setTransactionNo(rs.getInt(7));
						adjReversalDetailsList.add(adjReversalDetailDTO);
					}
				}

			} catch (Exception e) {
				log.info("Query execution of fetchAdjustmentReversalDetails ", e);
			} finally {
				if (con != null) {
					try {
						con.commit();
						preparedStatement.close();
						rs.close();
						con.close();
					} catch (Exception e) {
						log.info("Exception in fetchAdjustmentReversalDetails ---", e);
					}
				}

			}
		}
		log.info("list fetchAdjustmentReversalDetails-->>" + adjReversalDetailsList + " and account_no is-->"
				+ accountId);
		log.info("END--->in fetchAdjustmentReversalDetails	 method of ClientDAOImpl and account_no is-->" + accountId);
		return adjReversalDetailsList;

	}

	/*
	 * @author :- Geeta Rajput-update Aps Flag in table
	 */
	public String updateStatusAfterCustAccSummary(String accountId) throws Exception {

		log.info("START--in updateStatusAfterCustAccSummary in ClientDAOImpl and account_no is-->" + accountId);
		Connection con = null;
		PreparedStatement preparedStatement = null;
		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;
		String sql1 = EMPTY_STRING;
		ResultSet rs = null;
		int transactionNo = EMPTY_VALUE;

		sql = "select TRANSACTION_NO from REFUND_PAYMENT_APS where STATUS_CODE=" + CUSTACCSUMM_INITIAL_CODE
				+ " and ACCOUNT_NO='" + accountId + "' ";
		log.info("query in updateStatusAfterCustAccSummary  in ClientDAOImpl-->" + sql + " and account_no is-->"
				+ accountId);
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection in method updateStatusAfterCustAccSummary __________" + con);

		} catch (Exception e) {
			log.info("Connection not established in method updateStatusAfterCustAccSummary ", e);
		}

		if (con != null) {

			try {
				con.setAutoCommit(false);
				preparedStatement = con.prepareStatement(sql);
				rs = preparedStatement.executeQuery();
				try {
					if (rs != null) {
						while (rs.next()) {
							transactionNo = rs.getInt(1);
							System.out.println(
									"transaction no in method updateStatusAfterCustAccSummary in ClientDAOImpl--->>"
											+ transactionNo);
						}
					}

				} catch (Exception e) {
					log.info("Query execution in method updateStatusAfterCustAccSummary ", e);
				}
			} catch (Exception e) {
				// TODO: handle exception
				log.info("Query execution in method updateStatusAfterCustAccSummary ", e);
			}

		}
		sql1 = "UPDATE REFUND_PAYMENT_APS SET STATUS_CODE=" + CUSTACCSUMM_ERROR_CODE + " where  ACCOUNT_NO='"
				+ accountId + "' and TRANSACTION_NO=" + transactionNo + "";
		log.info("query in method updateStatusAfterCustAccSummary-->" + sql1 + " and account_no is-->" + accountId);

		if (con != null) {
			try {
				con.setAutoCommit(false);
				preparedStatement = con.prepareStatement(sql1);
				int resultSet = 0;
				try {
					resultSet = preparedStatement.executeUpdate();
					log.info("resultset in method updateStatusAfterCustAccSummary in ClientDAOImpl----->>" + resultSet
							+ " and account_no is-->" + accountId);

				} catch (Exception e) {
					log.info("Query execution in method updateStatusAfterCustAccSummary", e);
				}

				try {
					if (resultSet > 0) {
						result = RESULT_DB_SUCCESFUL;
					} else {
						result = RESULT_DB_FAILURE;
					}
					con.commit();
				} catch (Exception e) {
					log.info("Query execution in method updateStatusAfterCustAccSummary-->>", e);
				} finally {
					if (con != null) {
						try {
							preparedStatement.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in updateStatusAfterCustAccSummary ---", e);
						}
					}
				}
			} catch (Exception e) {
				log.info("Exception in updateStatusAfterCustAccSummary ---", e);
			}

		}
		log.info("END--in updateStatusAfterCustAccSummary in ClientDAOImpl result --->>" + result
				+ " and account_no is-->" + accountId);
		return result;
	}

/*	public List<CreateUpdateNotesDetails> fetchUpdateNotesDetails(int sr_transaction_no) throws Exception {

		log.info("START--->in fetchUpdateNotesDetails method of ClientDAOImpl and sr_transaction_no is-->"
				+ sr_transaction_no);
		List<CreateUpdateNotesDetails> updateNotesDetailsList = new ArrayList<CreateUpdateNotesDetails>();

		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		String str = "SELECT SR_NUMBER,COMMENTS,CHANGE_WHO,SR_TRANSACTION_NO FROM SR_DETAILS_APS WHERE SR_TRANSACTION_NO= "
				+ sr_transaction_no + " AND SIEBEL_STATUS_CODE IN " + UPDATE_NOTES_STATUS_CODE
				+ " AND JOB_ID is null ORDER BY NO_OF_HIT,SR_TRANSACTION_NO";

		log.info("QUERY fetchUpdateNotesDetails ++" + str.toString() + "and sr_transaction_no is-->"
				+ sr_transaction_no);
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection fetchUpdateNotesDetails __________" + con + "and sr_transaction_no is-->"
					+ sr_transaction_no);

		} catch (Exception e) {
			log.info("Connection not established fetchUpdateNotesDetails", e);
		}

		if (con != null) {

			try {
				con.setAutoCommit(false);
				preparedStatement = con.prepareStatement(str);

				rs = preparedStatement.executeQuery();
				try {
					if (rs != null) {
						while (rs.next()) {
							CreateUpdateNotesDetails updateNotesDetailDTO = new CreateUpdateNotesDetails();
							updateNotesDetailDTO.setSrNumber(rs.getString(1));
							updateNotesDetailDTO.setComments(rs.getString(2));
							updateNotesDetailDTO.setUserId(rs.getString(3));
							updateNotesDetailDTO.setSrTransactionNo(rs.getInt(4));
							updateNotesDetailsList.add(updateNotesDetailDTO);
						}
					}

				} catch (Exception e) {
					log.info("Query execution of fetchUpdateNotesDetails ", e);
				} finally {
					if (con != null) {
						try {
							con.commit();
							preparedStatement.close();
							rs.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in fetchUpdateNotesDetails ---", e);
						}
					}

				}
			} catch (Exception e) {
				log.info("Query execution of fetchUpdateNotesDetails ", e);
			}

		}
		log.info("list fetchUpdateNotesDetails-->>" + updateNotesDetailsList + "and sr_transaction_no is-->"
				+ sr_transaction_no);
		log.info("END--->in fetchUpdateNotesDetails	 method of ClientDAOImpl and sr_transaction_no is-->"
				+ sr_transaction_no);
		return updateNotesDetailsList;

	}*/
	
	//Added new method for 226_F(Fetch proc)
	public Object[] fetchCreateUpdateNotesDetails(int srTransactionNo) throws Exception {

		log.info("START--->in fetchCreateUpdateNotesDetails method of ClientDAOImpl");
		String procSuccess = null;
		Object[] obj = new Object[2];
		// SRApprovalTaskCallbackDetails callbackDetails = new
		// SRApprovalTaskCallbackDetails();
		CreateUpdateNotesDetails createUpdateNotesDetailsDTO = new CreateUpdateNotesDetails();
		createUpdateNotesDetailsDTO.setSrTransactionNo(srTransactionNo);
		Connection con = null;
		CallableStatement callableStatement = null;
		ResultSet rs = null;
		String result = EMPTY_STRING;

		String str = "{call FETCH_CREATE_NOTES_DETAILS(?,?,?) }";

		log.info("QUERY in fetchCreateUpdateNotesDetails---->>+" + str.toString());
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection in fetchCreateUpdateNotesDetails __________" + con);

		} catch (Exception e) {
			log.info("Connection not established in fetchCreateUpdateNotesDetails", e);
		}
		if (con != null) {
			// callableStatement = con.prepareCall(str);
			try {
				con.setAutoCommit(false);
				callableStatement = con.prepareCall(str);

				callableStatement.setInt(1, srTransactionNo);
				callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
				callableStatement.registerOutParameter(3, Types.VARCHAR);

				callableStatement.executeUpdate();
				result = callableStatement.getString(3);
				// if (result.contains(SUCCESS)) {

				rs = (ResultSet) callableStatement.getObject(2);

				while (rs != null && rs.next()) {

					procSuccess = "SUCCESS";
					createUpdateNotesDetailsDTO.setSrNumber(rs.getString("sr_number"));
					createUpdateNotesDetailsDTO.setComments(rs.getString("comments"));
					createUpdateNotesDetailsDTO.setUserId(rs.getString("user_id"));
					createUpdateNotesDetailsDTO.setSrTransactionNo(rs.getInt("sr_transaction_no"));
					// callbackDetailsDetailsList.add(srApprovalTaskcallbackDTO);
				}

				obj[0] = procSuccess;
				obj[1] = createUpdateNotesDetailsDTO;

			} catch (Exception e) {
				log.info("Query execution of fetchSRApprovalTaskCallbackDetails ", e);
			} finally {
				if (con != null) {
					try {
						con.commit();
						rs.close();
						callableStatement.close();
						con.close();
					} catch (Exception e) {
						log.info("Exception in the fetchSRApprovalTaskCallbackDetails", e);
					}
				}

			}
		}
		log.info("list in fetchSRApprovalTaskCallbackDetails-->>" + createUpdateNotesDetailsDTO);
		log.info("END--->in fetchSRApprovalTaskCallbackDetails method of ClientDAOImpl");
		return obj;

	}
	
	 //ADDED NEW METHOD FOR UPDATE RESPONSE FROM 226_F--Geeta
		public String updateResponseForNotes(String statusDescription, int srTransactionNo,String fileIdentifier)
						throws Exception {

			log.info("START--in updateResponseForNotes in ClientDAOImpl for sr_transaction_no-->" + srTransactionNo);
			
			Connection con = null;
			CallableStatement callableStatement = null;

			String result = EMPTY_STRING;
			String sql = EMPTY_STRING;

			/*log.info("ESBWSResponse|" + jobId + "|" + transactionNo + "|" + tableName + "|exec APS_UPDATE_RESPONSE('"
					+ statusDescription + "'," + trackingId + "," + trackingServId + "," + transactionNo + ",'" + tableName
					+ "'," + viewId + ",'" + annotation3 + "','" + annotation5 + "','" + faultTrace + "',:response)");*/

			sql = "{call CREATE_NOTES_DETAILS_APS(?,?,?,?)}";

			try {

				try {
					con = ConnectionUtil.getConnection();
					con.setAutoCommit(false);

				} catch (Exception e) {
					log.info("Connection not established ", e);
				}
				if (con != null) {
					try {
						callableStatement = con.prepareCall(sql);
						callableStatement.setString(1, statusDescription);
						callableStatement.setInt(2, srTransactionNo);
						callableStatement.setString(3, fileIdentifier);
						callableStatement.registerOutParameter(4, Types.INTEGER);
						callableStatement.executeUpdate();
						int count = callableStatement.getInt(4);
						log.info("updated rows in updateResponseForNotes --->>" + count + " for srTransactionNo-->" + srTransactionNo);
						if (count > 0) {
							result = RESULT_DB_SUCCESFUL;
						} else {
							result = RESULT_DB_FAILURE;
						}
					} catch (Exception e) {
						log.info("Exception in updateResponseForNotes  ", e);
					}
				}
			} catch (Exception e) {
				log.info("Exception in updateResponseForNotes  ", e);
			} finally {
				if (con != null) {
					try {
						con.commit();
						callableStatement.close();
						con.close();
					} catch (Exception e) {
						log.info("Exception in the updateResponseForNotes", e);
					}
				}

			}
			log.info("END--in updateResponseForNotes in ClientDAOImpl result --->>" + result + " for srTransactionNo-->"
					+ srTransactionNo);
			return result;
		}

/*
	public String updateResponseForCreateUpdateNotes(String statusCodeWeb, String satus_description,
			int sr_transaction_no, CreateUpdateNotesDetails createUpdateNotesDetails, String statusCode, int jobId)
					throws Exception {

		log.info("START--in updateResponseForCreateUpdateNotes in ClientDAOImpl and sr_transaction_no is-->"
				+ sr_transaction_no);
		Connection con = null;
		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;
		PreparedStatement preparedStatement = null;

		if (CommonUtil.isNotNull(statusCodeWeb) && statusCodeWeb.contains(STATUS_CODE_HTTP)
				&& statusCode.contains(STATUS_CODE_S)) {
			// int code=Integer.parseInt(UPDATE_NOTES_INITIAL_STATUS_CODE);

			log.info("ESBWSResponse|" + jobId + "|" + createUpdateNotesDetails.getSrNumber()
			+ "|SR_DETAILS_APS|update SR_DETAILS_APS SET SIEBEL_STATUS_CODE=(CASE WHEN siebel_status_code ="
			+ VALID_INITIAL_STATUS_CODE + " THEN " + VALID_SUCCESS_STATUS_CODE + " ELSE "
			+ INVALID_SUCCESS_STATUS_CODE + " END),SIEBEL_STATUS_DESCRIPTION= '" + satus_description
			+ "' ,MODIFIED_DATE = sysdate,JOB_ID = null where SR_TRANSACTION_NO=" + sr_transaction_no + ""
			+ " and SR_NUMBER= '" + createUpdateNotesDetails.getSrNumber() + "' and SIEBEL_STATUS_CODE IN "
			+ UPDATE_NOTES_STATUS_CODE + "");

			sql = "UPDATE SR_DETAILS_APS SET SIEBEL_STATUS_CODE=(CASE WHEN siebel_status_code ="
					+ VALID_INITIAL_STATUS_CODE + " THEN " + VALID_SUCCESS_STATUS_CODE + " ELSE "
					+ INVALID_SUCCESS_STATUS_CODE + " END),SIEBEL_STATUS_DESCRIPTION= '" + satus_description
					+ "' ,MODIFIED_DATE = sysdate,JOB_ID = null where SR_TRANSACTION_NO=" + sr_transaction_no + ""
					+ " and SR_NUMBER= '" + createUpdateNotesDetails.getSrNumber() + "' and SIEBEL_STATUS_CODE IN "
					+ UPDATE_NOTES_STATUS_CODE + " ";

			
		}

		else {

			log.info("ESBWSResponse|<" + jobId + ">|<" + createUpdateNotesDetails.getSrNumber()
			+ ">|<SR_DETAILS_APS>|update SR_DETAILS_APS SET SIEBEL_STATUS_CODE=(CASE WHEN siebel_status_code ="
			+ VALID_INITIAL_STATUS_CODE + " THEN " + VALID_FAILURE_STATUS_CODE + " ELSE "
			+ INVALID_FAILURE_STATUS_CODE + " END),SIEBEL_STATUS_DESCRIPTION= '" + satus_description
			+ "' ,MODIFIED_DATE = sysdate,JOB_ID = null where SR_TRANSACTION_NO=" + sr_transaction_no + ""
			+ " and SR_NUMBER= '" + createUpdateNotesDetails.getSrNumber() + "' and SIEBEL_STATUS_CODE IN "
			+ UPDATE_NOTES_STATUS_CODE + " ");

			sql = "UPDATE SR_DETAILS_APS SET SIEBEL_STATUS_CODE=(CASE WHEN siebel_status_code ="
					+ VALID_INITIAL_STATUS_CODE + " THEN " + VALID_FAILURE_STATUS_CODE + " ELSE "
					+ INVALID_FAILURE_STATUS_CODE + " END),SIEBEL_STATUS_DESCRIPTION= '" + satus_description
					+ "' ,MODIFIED_DATE = sysdate,JOB_ID = null where SR_TRANSACTION_NO=" + sr_transaction_no + ""
					+ " and SR_NUMBER= '" + createUpdateNotesDetails.getSrNumber() + "' and SIEBEL_STATUS_CODE IN "
					+ UPDATE_NOTES_STATUS_CODE + " ";
		}
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection formed in updateResponseForCreateUpdateNotes--------->" + con
					+ "sr_transaction_no is-->" + sr_transaction_no);

		} catch (Exception e) {

			log.info("Connection not established in updateResponseForCreateUpdateNotes ", e);
		}

		if (con != null) {
			log.info("query of updateResponseForCreateUpdateNotes---" + sql + "sr_transaction_no is-->"
					+ sr_transaction_no);
			try {
				con.setAutoCommit(false);
				preparedStatement = con.prepareStatement(sql);
				int resultSet = preparedStatement.executeUpdate();
				try {
					if (resultSet > 0) {
						result = RESULT_DB_SUCCESFUL;
					} else {
						result = RESULT_DB_FAILURE;
					}
				} catch (Exception e) {
					log.info("Query execution updateResponseForCreateUpdateNotes---->", e);
				} finally {
					if (con != null) {
						try {
							con.commit();
							preparedStatement.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in updateResponseForCreateUpdateNotes ---", e);
						}
					}

				}
			} catch (Exception e) {

				log.info("Exception in updateResponseForCreateUpdateNotes-->", e);
			}

		}
		log.info("END--in updateResponseForCreateUpdateNotes in ClientDAOImpl result --->" + result
				+ "sr_transaction_no is-->" + sr_transaction_no);
		return result;
	}
	*/
	
	public Object[] updateJobId(String tableName, int transactionNo, String homes_job_id, int job_id) throws Exception {

		log.info("START--in updateJobId in ClientDAOImpl for transaction_no-->" + transactionNo + " and table name--->"
				+ tableName);
		Connection con = null;
		CallableStatement callableStatement = null;

		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;
		int jobId = EMPTY_VALUE;

		Object[] resultObj = new Object[2];

		sql = "{call CONCURRENCY_APS3(?,?,?,?,?)}";
		try {

			try {
				con = ConnectionUtil.getConnection();
				con.setAutoCommit(false);

			} catch (Exception e) {
				log.info("Connection not established ", e);
			}
			if (con != null) {
				try {
					callableStatement = con.prepareCall(sql);
					callableStatement.setInt(1, transactionNo);
					callableStatement.setString(2, tableName);
					callableStatement.setString(3, homes_job_id);
					callableStatement.setInt(5, job_id);
					callableStatement.registerOutParameter(4, Types.VARCHAR);
					// added by geeta for job_id changes
					callableStatement.registerOutParameter(5, Types.INTEGER);
					callableStatement.executeUpdate();
					result = callableStatement.getString(4);
					log.info("result in updateJobId from concurrency_aps :" + result);
					jobId = callableStatement.getInt(5);
					log.info("updated job_id in updateJobId from concurrency_aps :" + jobId);
					log.info("updated rows in updateJobId --->>" + result + " for transaction_no-->" + transactionNo
							+ " and table name--->" + tableName);

					resultObj[0] = result;
					resultObj[1] = jobId;

				} catch (Exception e) {
					log.info("Exception in updateJobId  ", e);
				}
			}
		} catch (Exception e) {
			log.info("Exception in updateJobId  ", e);
		} finally {
			if (con != null) {
				try {
					con.commit();
					callableStatement.close();
					con.close();
				} catch (Exception e) {
					log.info("Exception in updateJobId ---", e);
				}
			}

		}
		log.info("END--in updateJobId in ClientDAOImpl result --->>" + result + " for transaction_no-->" + transactionNo
				+ " and table name--->" + tableName);

		return resultObj;

	}

	public String updateConnectionReadResponse(int transactionNo, String tableName, String conectReadText)
			throws Exception {

		log.info("START--in updateConnectionReadResponse in ClientDAOImpl for transaction_no-->" + transactionNo
				+ " and table name--->" + tableName);
		log.info("tran no in updateConnectionReadResponse----->>>" + transactionNo + " and table name--->" + tableName);
		Connection con = null;
		CallableStatement callableStatement = null;

		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;

		sql = "{call CONNECT_READ_TIME_OUT_APS(?,?,?,?)}";

		try {

			try {
				con = ConnectionUtil.getConnection();
				con.setAutoCommit(false);

			} catch (Exception e) {
				log.info("Connection not established ", e);
			}
			if (con != null) {
				try {
					callableStatement = con.prepareCall(sql);
					callableStatement.setInt(1, transactionNo);
					callableStatement.setString(2, tableName);
					callableStatement.setString(3, conectReadText);

					callableStatement.registerOutParameter(4, Types.VARCHAR);
					callableStatement.executeUpdate();
					result = callableStatement.getString(4);
					log.info("updated rows in updateConnectionReadResponse --->>" + result + " for transaction_no-->"
							+ transactionNo + " and table name--->" + tableName);
				} catch (Exception e) {
					log.info("Exception in updateResponse  ", e);
				}
			}
		} catch (Exception e) {
			log.info("Exception in updateConnectionReadResponse  ", e);
		} finally {
			if (con != null) {
				try {
					con.commit();
					callableStatement.close();
					con.close();
				} catch (Exception e) {
					log.info("Exception in updateConnectionReadResponse ---", e);
				}
			}

		}
		log.info("END--in updateConnectionReadResponse in ClientDAOImpl result --->>" + result
				+ " for transaction_no-->" + transactionNo + " and table name--->" + tableName);
		return result;
	}

	public String updateHomeIdDetails(String accountId, String lob, String fileIdentifier, String homesId,
			String homesIdDesc) throws Exception {

		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;
		int resultSet = EMPTY_VALUE;

		log.info("homesId in updateHomeIdDetails----->>>" + homesId + "AND accountId-->" + accountId + " and"
				+ " fileIdentifier--->>" + fileIdentifier + " and homesIdDesc--->>" + homesIdDesc);

		Connection con = null;
		CallableStatement callableStatement = null;

		sql = "{call UPDATE_HOMES_SERVICE_TYPE(?,?,?,?,?,?)}";

		try {
			con = ConnectionUtil.getConnection();
			log.info("connection formed in updateHomeIdDetails--------->" + con);

		} catch (Exception e) {

			log.info("Connection not established in updateHomeIdDetails ", e);
		}
		if (con != null) {
			log.info("query of updateHomeIdDetails---" + sql);
			try {
				con.setAutoCommit(false);
				callableStatement = con.prepareCall(sql);
				callableStatement.setString(1, accountId);
				callableStatement.setString(2, lob);
				// callableStatement.setString(3, msisdn);
				callableStatement.setString(3, fileIdentifier);
				callableStatement.setString(4, homesId);
				callableStatement.setString(5, homesIdDesc);

				callableStatement.registerOutParameter(6, Types.VARCHAR);
				resultSet = callableStatement.executeUpdate();
				result = callableStatement.getString(6);
				try {
					if (resultSet > 0) {
						result = RESULT_DB_SUCCESFUL;
					} else {
						result = RESULT_DB_FAILURE;
					}
				} catch (Exception e) {
					log.info("Query execution updateHomeIdDetails---->", e);
				} finally {
					if (con != null) {
						try {
							con.commit();
							callableStatement.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in updateHomeIdDetails ---", e);
						}
					}

				}
			} catch (Exception e) {

				log.info("Exception in updateHomeIdDetails-->", e);
			}

		}
		log.info("END--in updateHomeIdDetails in ClientDAOImpl result --->" + result);
		return result;

	}

	/*
	 * public List<PaymentBreakupHomesDetails> fetchHomesBillingPayment(String
	 * accountId) throws Exception{
	 * 
	 * log.info("START--->in fetchHomesBillingPayment method of ClientDAOImpl");
	 * String procSuccess = null; Object[] obj = new Object[2];
	 * 
	 * List<PaymentBreakupHomesDetails> paymentBreakupHomesDetailsList=new
	 * ArrayList<PaymentBreakupHomesDetails>(); PaymentBreakupHomesDetails
	 * paymentBreakupHomesDTO=new PaymentBreakupHomesDetails();
	 * paymentBreakupHomesDTO.setAccountId(accountId); Connection con = null;
	 * CallableStatement callableStatement = null; ResultSet rs = null; String
	 * result = EMPTY_STRING;
	 * 
	 * String str = "{call PAYMENT_BREAKUP_FETCH_APS(?,?,?) }";
	 * 
	 * log.info("QUERY in fetchHomesBillingPayment---->>+" + str.toString());
	 * try { con = ConnectionUtil.getConnection();
	 * log.info("connection in fetchHomesBillingPayment __________" + con);
	 * 
	 * } catch (Exception e) {
	 * log.info("Connection not established in fetchHomesBillingPayment", e); }
	 * if (con != null) { // callableStatement = con.prepareCall(str); try {
	 * con.setAutoCommit(false); callableStatement = con.prepareCall(str);
	 * 
	 * callableStatement.setString(1, accountId);
	 * callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
	 * callableStatement.registerOutParameter(3, Types.VARCHAR);
	 * 
	 * callableStatement.executeUpdate(); result =
	 * callableStatement.getString(3); // if (result.contains(SUCCESS)) {
	 * 
	 * rs = (ResultSet) callableStatement.getObject(2);
	 * 
	 * while (rs != null && rs.next()) { log.info("here"); procSuccess =
	 * "SUCCESS"; paymentBreakupHomesDTO.setHomesId(rs.getString("HOMES_ID"));
	 * log.info("HOMES_ID in fetchHomesBillingPayment------>>>" +
	 * rs.getString("homes_id"));
	 * paymentBreakupHomesDTO.setLob(rs.getString("lob"));
	 * paymentBreakupHomesDTO.setAccountId(rs.getString("acct_ext_id"));
	 * paymentBreakupHomesDTO.setPaymentDate(rs.getString("payment_date"));
	 * paymentBreakupHomesDTO.setAmountPaid(rs.getDouble("payment_amount"));
	 * paymentBreakupHomesDTO.setTransactionId(rs.getString("transaction_id"));
	 * paymentBreakupHomesDTO.setApsFlag(rs.getString("aps_flag"));
	 * paymentBreakupHomesDTO.setSiListId("del_no");
	 * paymentBreakupHomesDetailsList.add(paymentBreakupHomesDTO); }
	 * 
	 * obj[0] = procSuccess; obj[1] = paymentBreakupHomesDetailsList;
	 * 
	 * } catch (Exception e) {
	 * log.info("Query execution of fetchHomesBillingPayment ", e); } finally {
	 * if (con != null) { try { con.commit(); rs.close();
	 * callableStatement.close(); con.close(); } catch (Exception e) {
	 * log.info("Exception in the fetchHomesBillingPayment", e); } }
	 * 
	 * } } log.info("list in fetchHomesBillingPayment-->>" +
	 * paymentBreakupHomesDTO);
	 * log.info("END--->in fetchHomesBillingPayment method of ClientDAOImpl");
	 * return paymentBreakupHomesDetailsList; }
	 */

	/*
	 * public static void main(String[] args) throws Exception { ClientDAOImpl
	 * clientDAOImpl=new ClientDAOImpl();
	 * clientDAOImpl.fetchHomesBillingPayment("919160099966"); }
	 */
	public String updateResponseForPaymentBreakupFetch(List<ResponsePojoForHomes> responsePojoList,
			String status_description, String transactionId, String accountNo, String lob, String aps_flag,
			String homesId) throws Exception {

		log.info("START--->in updateResponseForPaymentBreakupFetch method of ClientDAOImpl");

		Connection con = null;
		CallableStatement callableStatement = null;
		// Object array[]=listOfValues.toArray();
		String headerStatus = null;
		String errorCode = null, errorMessage = null;

		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;

		sql = "{call HOMES_PAYMENT_PKG.HOMES_PAYMENT_APS(?,?,?,?,?,?,?,?,?)}";
		// sql = "{call HOMES_PAYMENT_APS(?,?,?,?,?,?,?,?,?)}";
		log.info("sql query--->>" + sql);

		try {

			try {
				con = ConnectionUtil.getConnection();
				con.setAutoCommit(false);

			} catch (Exception e) {
				log.info("Connection not established in updateResponseForPaymentBreakupFetch", e);
			}
			if (con != null) {
				try {

					StructDescriptor structDescriptor1 = StructDescriptor.createDescriptor("HOMES_PAYMENT_OBJ", con);
					STRUCT[] structs = new STRUCT[responsePojoList.size()];
					log.info("responsePojoList size in updateResponseForPaymentBreakupFetch->> "
							+ responsePojoList.size());

					for (int i = 0; i < responsePojoList.size(); i++) {
						// BulkDetails
						// bulkDetailsObj=responsePojoList.get(i).getBulkObj();
						Object[] params = new Object[3];
						params[0] = responsePojoList.get(i).getAccountNo();
						params[1] = responsePojoList.get(i).getLob();
						params[2] = responsePojoList.get(i).getPaymentAmount();

						String homesValues = "";
						for (int z = 0; z < 3; z++) {
							homesValues += params[z] + "|";
						}
						log.info("Homes values in updateResponseForPaymentBreakupFetch:" + homesValues);

						STRUCT homesStruct = new STRUCT(structDescriptor1, con, params);
						structs[i] = homesStruct;
						/*
						 * homesStruct[0] = struct;
						 * 
						 * Object[] mainParams1 = new Object[1];
						 * mainParams1[0]=homesStruct[0];
						 * 
						 * STRUCT struct4 = new STRUCT(structDescriptor1, con,
						 * mainParams1); structs[i]=struct4;
						 */
					}

					ArrayDescriptor homeStructDesc = ArrayDescriptor.createDescriptor("HOMES_TAB_TYPE", con);
					ARRAY homeStructOracleArray = new ARRAY(homeStructDesc, con, structs);

					callableStatement = con.prepareCall(sql);

					callableStatement.setArray(1, homeStructOracleArray);
					callableStatement.setString(2, status_description);
					callableStatement.setString(3, transactionId);
					callableStatement.setString(4, accountNo);
					callableStatement.setString(5, lob);
					callableStatement.setString(6, aps_flag);
					callableStatement.setString(7, homesId);

					callableStatement.registerOutParameter(8, Types.VARCHAR);
					callableStatement.registerOutParameter(9, Types.VARCHAR);
					callableStatement.executeUpdate();

					errorCode = callableStatement.getString(8);
					errorMessage = callableStatement.getString(9);
					log.info(" updateResponseForPaymentBreakupFetch ERROR CODE IS" + errorCode);
					log.info("updateResponseForPaymentBreakupFetch error message is" + errorMessage);
					headerStatus = "SUCCESS";

				} catch (Exception e) {
					log.info("Exception in updateResponseForPaymentBreakupFetch  ", e);
				}
			}
		} catch (Exception e) {
			log.info("Exception in updateResponseForPaymentBreakupFetch  ", e);
		} finally {
			if (con != null) {
				try {
					con.commit();
					callableStatement.close();
					con.close();
				} catch (Exception e) {
					log.info("Exception in updateResponseForPaymentBreakupFetch ---", e);
				}
			}

		}
		log.info("END--in updateResponseForPaymentBreakupFetch in ClientDAOImpl result --->>" + result);
		return result;
	}

	public List<BulkDetails> fetchInvoiceDetails(String account_no) {

		log.info("START--in fetchInvoiceDetails in ClientDAOImpl");

		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;
		// String sql2=EMPTY_STRING;

		List<BulkDetails> bulkDetailsList = new ArrayList<BulkDetails>();

		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		/*sql = "SELECT TRANSACTION_ID,INVOICE_NO FROM MISC_VENDOR_FILES_RECORDS m WHERE m.ACCT_EXT_ID='" + account_no
				+ "' " + "AND m.FILE_IDENTIFIER='MIS' AND APS_FLAG='APS' AND DERIVED_INVOICE_NO IS NULL"
				+ " union all SELECT TRANSACTION_ID,INVOICE_NO FROM CHEQUE_VENDOR_FILES_RECORDS m WHERE m.ACCT_EXT_ID='"
				+ account_no + "' " + "AND m.FILE_IDENTIFIER='CHQ' AND APS_FLAG='APS' AND DERIVED_INVOICE_NO IS NULL"
				+ " UNION ALL SELECT TRANSACTION_ID,INVOICE_NO FROM NEFT_VENDOR_FILES_RECORDS m WHERE m.ACCT_EXT_ID='"
				+ account_no + "' " + "AND m.FILE_IDENTIFIER='EFT' AND APS_FLAG='APS' AND DERIVED_INVOICE_NO IS NULL";*/

		sql = "SELECT TRANSACTION_ID,INVOICE_NO FROM MISC_VENDOR_FILES_RECORDS m WHERE m.ACCT_EXT_ID='" + account_no
				+ "' AND m.FILE_IDENTIFIER='MIS' AND APS_FLAG='APS' AND DERIVED_B2B_B2C='B2B'"
				+ " union all SELECT TRANSACTION_ID,INVOICE_NO FROM CHEQUE_VENDOR_FILES_RECORDS c WHERE c.ACCT_EXT_ID='"
				+ account_no + "' AND c.FILE_IDENTIFIER='CHQ' AND APS_FLAG='APS' AND DERIVED_B2B_B2C='B2B'"
				+ " UNION ALL SELECT TRANSACTION_ID,INVOICE_NO FROM NEFT_VENDOR_FILES_RECORDS n WHERE n.ACCT_EXT_ID='"
				+ account_no + "' AND n.FILE_IDENTIFIER='EFT' AND APS_FLAG='APS' AND DERIVED_B2B_B2C='B2B'"
				+ " UNION ALL SELECT to_number(TRANSACTION_ID),INVOICE_NO FROM AIRTL_CUST_PAYMENT_DETAILS cpd where cpd.acct_ext_id='"
				+account_no+"' AND APS_FLAG='APS' AND POSTING_RETRIAL_ATTEMPTS=0 and "
						+ "POSTING_STATUS_FX=0 and BILL_REF_RESESTS is null and B2B_B2C_SEGMENT='B2B'"
						+ " and ACCOUNT_TYPE='CUSTOMER' AND PAYMENT_ADVICE_REQUEST_ID IS NOT NULL "
						+ " UNION ALL SELECT RECORD_ID,n.INPUT_INVOICE_NUMBER FROM ADVICE_VENDOR_FILES_RECORDS n WHERE "
						+ " n.ACCT_EXT_ID='"+ account_no + "' AND n.FILE_IDENTIFIER='PAFILE' AND APS_FLAG IN ('APS','CAD') "
						+ " AND n.DERIVED_SEGMENT_B2B_B2C='B2B' AND STATUS_CODE=1"
						+" union all  SELECT p.TRANSACTION_ID,p.INVOICE_NO from PT_VENDOR_FILES_RECORDS p"
						+" WHERE p.ACCT_EXT_ID= '"+account_no+"' and p.FILE_IDENTIFIER='' and p.APS_FLAG='APS'"
						+"AND p.DERIVED_B2B_B2C='B2B'"
						+" UNION ALL SELECT p.TRANSACTION_ID,BILL_REF_RESETS from AIRTL_SUSPENSE_ALC_RECORDS p "
						+" WHERE p.ACCT_EXT_ID= '"+account_no+"' and p.FILE_IDENTIFIER='SAL' and p.APS_FLAG='APS' "
						;

					

						

		log.info("QUERY fetchInvoiceDetails ++" + sql.toString() + " and account_no is-->" + account_no);
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection fetchInvoiceDetails __________" + con + " and account_no is-->" + account_no);

		} catch (Exception e) {
			log.info("Connection not established fetchInvoiceDetails", e);
		}

		if (con != null) {
			try {
				con.setAutoCommit(false);
				preparedStatement = con.prepareStatement(sql);

				rs = preparedStatement.executeQuery();
				try {
					if (rs != null) {
						while (rs.next()) {
							BulkDetails fileRecordsDTO = new BulkDetails();
							fileRecordsDTO.setTransactionId(rs.getString(1));
							fileRecordsDTO.setInvoiceNo(rs.getString(2));
							bulkDetailsList.add(fileRecordsDTO);
						}
					}

				} catch (Exception e) {
					log.info("Query execution of fetchInvoiceDetails ", e);
				} finally {
					if (con != null) {
						try {
							con.commit();
							preparedStatement.close();
							rs.close();
							con.close();

						} catch (Exception e) {
							log.info("Exception in the fetchInvoiceDetails", e);
						}
					}
				}
			} catch (Exception e) {
				// TODO: handle exception
				log.info(e);
			}

		}
		log.info("list fetchInvoiceDetails-->>" + bulkDetailsList + " and account_no is-->" + account_no);
		log.info("END--->in fetchInvoiceDetails	 method of ClientDAOImpl and account_no is-->" + account_no);
		return bulkDetailsList;

	}

	public String updateInvoiceDetails(String fileIdentifier, String acct_no, String invoice_no, String billRefResets,
			String transactionId, String statusDescription, String interfaceStatusFlag,String suspenseAmount) throws Exception {

		log.info("START--in updateInvoiceDetails in ClientDAOImpl ");
		Connection con = null;
		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;
		PreparedStatement preparedStatement = null;
		String tableName = null;

		if (fileIdentifier != null && fileIdentifier.contains("CHQ")) {
			tableName = "CHEQUE_VENDOR_FILES_RECORDS";
		} else if (fileIdentifier != null && fileIdentifier.contains("EFT")) {
			tableName = "NEFT_VENDOR_FILES_RECORDS";
		} else if (fileIdentifier != null && fileIdentifier.contains("MISC")) {
			tableName = "MISC_VENDOR_FILES_RECORDS";
		}else if (fileIdentifier != null && fileIdentifier.contains("CPD")) {
			tableName = "AIRTL_CUST_PAYMENT_DETAILS";
		}
		else if (fileIdentifier != null && (fileIdentifier.contains("PTSR")||fileIdentifier.contains("PTBULK"))) {
			tableName = "PT_VENDOR_FILES_RECORDS";
		}
		else if (fileIdentifier != null && fileIdentifier.contains("ADVICE_220")) {
			tableName = "ADVICE_VENDOR_FILES_RECORDS";
		}
		else if (fileIdentifier != null && fileIdentifier.contains("SAL_220")) {
			tableName = "AIRTL_SUSPENSE_ALC_RECORDS";
		}

		if (SUCCESS.equalsIgnoreCase(interfaceStatusFlag)) {

			if("AIRTL_CUST_PAYMENT_DETAILS".equalsIgnoreCase(tableName)){

				sql = "UPDATE " + tableName + " SET INVOICE_NO='" + invoice_no + "',BILL_REF_RESESTS="
						+ billRefResets + " " + ",CHANGE_DATE = sysdate ,"
						+ "FX_POSTING_ERROR_DESCRIPTION='" + statusDescription + "'" + " where TRANSACTION_ID=" + transactionId
						+ "";
			}else if("ADVICE_VENDOR_FILES_RECORDS".equalsIgnoreCase(tableName)){
				
				sql = "UPDATE ADVICE_VENDOR_FILES_RECORDS SET DERIVED_INVOICE_NUMBER='" + invoice_no + "',BILL_REF_RESETS=" + billRefResets + " ,MODIFIED_DATE = sysdate"
						+ ",int_status='INT_220_PASSED' where record_id=" + transactionId
						+ "";
				
			}
			
			else if(fileIdentifier.equalsIgnoreCase("SAL_220")){
				sql = "UPDATE " + tableName + " SET SUSPENSE_AMOUNT='" + suspenseAmount +
						"',MODIFIED_DATE = sysdate ,STATUS_CODE=" + INITIAL_STATUS_CODE_POSTFX
						+ "   where TRANSACTION_ID=" + transactionId
						+ "";
				
			}
			else{
				sql = "UPDATE " + tableName + " SET DERIVED_INVOICE_NO='" + invoice_no + "',BILL_REF_RESETS="
						+ billRefResets + " " + ",MODIFIED_DATE = sysdate ,STATUS_CODE=" + INITIAL_STATUS_CODE_POSTFX
						+ ",STATUS_DESCRIPTION='" + statusDescription + "'" + "   where TRANSACTION_ID=" + transactionId
						+ "";
			} 
		}else {

			if("AIRTL_CUST_PAYMENT_DETAILS".equalsIgnoreCase(tableName)){
				sql = "UPDATE " + tableName + " SET POSTING_STATUS_FX=" + CUSTACCSUMM_ERROR_CODE + ",FX_POSTING_ERROR_DESCRIPTION='"
						+ statusDescription + "' " + ",CHANGE_DATE = sysdate where TRANSACTION_ID=" + transactionId + "";
			}else if("ADVICE_VENDOR_FILES_RECORDS".equalsIgnoreCase(tableName)){
				
				sql = "UPDATE ADVICE_VENDOR_FILES_RECORDS SET MODIFIED_DATE = sysdate"
						+ ",int_status='INT_220_FAILED' where record_id=" + transactionId
						+ "";
				
			}
			else{
				sql = "UPDATE " + tableName + " SET STATUS_CODE='" + CUSTACCSUMM_ERROR_CODE + "',STATUS_DESCRIPTION='"
						+ statusDescription + "' " + ",MODIFIED_DATE = sysdate where TRANSACTION_ID=" + transactionId + "";
			}
		}
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection formed in updateInvoiceDetails--------->" + con);

		} catch (Exception e) {

			log.info("Connection not established in updateInvoiceDetails ", e);
		}

		if (con != null) {
			log.info("query of updateInvoiceDetails---" + sql);
			try {
				con.setAutoCommit(false);
				preparedStatement = con.prepareStatement(sql);
				int resultSet = preparedStatement.executeUpdate();
				try {
					if (resultSet > 0) {
						result = RESULT_DB_SUCCESFUL;
					} else {
						result = RESULT_DB_FAILURE;
					}
				} catch (Exception e) {
					log.info("Query execution updateInvoiceDetails---->", e);
				} finally {
					if (con != null) {
						try {
							con.commit();
							preparedStatement.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in the updateInvoiceDetails", e);
						}
					}
				}
			} catch (Exception e) {

				log.info("Exception in updateInvoiceDetails-->", e);
			}

		}
		log.info("END--in updateInvoiceDetails in ClientDAOImpl result ---" + result);
		return result;

	}
	public String updateFailureResponseFromHomes(String status_description, String transactionId,
			String backendErrorCode, String aps_flag) throws Exception {

		log.info("START--in updateFailureResponseFromHomes in ClientDAOImpl");
		String result = EMPTY_STRING;
		Connection con = null;
		String sql = EMPTY_STRING;
		CallableStatement callableStatement = null;
		String tableName = null;

		sql = "{call UPDATE_PAYBREAKUP_FAILURE_APS(?,?,?,?,?)}";
		try {

			try {
				con = ConnectionUtil.getConnection();
				con.setAutoCommit(false);

			} catch (Exception e) {
				log.info("Connection not established ", e);
			}

			if (con != null) {
				try {
					callableStatement = con.prepareCall(sql);
					callableStatement.setString(1, status_description);
					callableStatement.setString(2, transactionId);
					callableStatement.setString(3, backendErrorCode);
					callableStatement.setString(4, aps_flag);
					callableStatement.registerOutParameter(5, Types.INTEGER);
					callableStatement.executeUpdate();
					int count = callableStatement.getInt(5);
					log.info("updated rows in updateResponse --->>" + count + " for transactionId-->" + transactionId);
					if (count > 0) {
						result = RESULT_DB_SUCCESFUL;
					} else {
						result = RESULT_DB_FAILURE;
					}
				} catch (Exception e) {
					log.info("Exception in updateResponse  ", e);
				}
			}
		} catch (Exception e) {
			log.info("Exception in updateResponse  ", e);
		} finally {
			if (con != null) {
				try {
					con.commit();
					callableStatement.close();
					con.close();
				} catch (Exception e) {
					log.info("Exception in the updateResponse", e);
				}
			}

		}

		log.info("END--in updateFailureResponseFromHomes in ClientDAOImpl result --->" + result);
		return result;
	}

	public String updateResponseForRevHomes(String status_description, String transactionId, String tableName)
			throws Exception {

		log.info("START--in updateResponseForRevHomes in ClientDAOImpl");

		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;
		Connection con = null;
		PreparedStatement preparedStatement = null;

		String trim_transactionId = transactionId.substring(3);

		sql = "UPDATE " + tableName + " SET STATUS_DESCRIPTION='" + status_description
				+ "', HOMES_DATE=sysdate,status_code=0 where TRANSACTION_ID=" + Integer.parseInt(trim_transactionId) + " "
				+ "and homes_id is not null";

		try {
			con = ConnectionUtil.getConnection();
			log.info("connection formed in updateResponseForRevHomes--------->" + con);

		} catch (Exception e) {

			log.info("Connection not established in updateResponseForRevHomes ", e);
		}

		if (con != null) {
			log.info("query of updateResponseForRevHomes---" + sql);
			try {
				con.setAutoCommit(false);
				preparedStatement = con.prepareStatement(sql);
				int resultSet = preparedStatement.executeUpdate();
				try {
					if (resultSet > 0) {
						result = RESULT_DB_SUCCESFUL;
					} else {
						result = RESULT_DB_FAILURE;
					}
				} catch (Exception e) {
					log.info("Query execution updateResponseForRevHomes---->", e);
				} finally {
					if (con != null) {
						try {
							con.commit();
							preparedStatement.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in the updateResponseForRevHomes", e);
						}
					}
				}
			} catch (Exception e) {

				log.info("Exception in updateResponseForRevHomes-->", e);
			}
		}
		log.info("END--in updateResponseForRevHomes in ClientDAOImpl result ---" + result);
		return result;

	}
	
	 public List getCallBackDetails(int transactionId){

			log.info("START--->in getCallBackDetails INT_229F method of CustPaymentCallbackDetailsClient");

			CallBackDTO callBackDTO = new CallBackDTO();

			List<CallBackDTO> CallBackDTOList =new ArrayList<CallBackDTO>();
			Connection con = null;
			CallableStatement callableStatement = null;
			ResultSet rs = null;

			String str = "{call GET_CALLBACK_229F_DETAILS(?,?,?) }";

			log.info("QUERY in getCallBackDetails INT_229F---->>+" + str.toString());
			try {
				con = ConnectionUtil.getConnection();
				log.info("connection in getCallBackDetails INT_229F __________" + con);

			} catch (Exception e) {
				log.info("Connection not established in getCallBackDetails INT_229F", e);
			}
			if (con != null) {
				// callableStatement = con.prepareCall(str);
				try {
					con.setAutoCommit(false);
					callableStatement = con.prepareCall(str);

					callableStatement.setInt(1, transactionId);
					callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
					callableStatement.registerOutParameter(3, Types.VARCHAR);

					callableStatement.executeUpdate();
					String result = callableStatement.getString(3);

					rs = (ResultSet) callableStatement.getObject(2);

					while (rs != null && rs.next()) {

						callBackDTO.setSrNumber(rs.getString("SR_NUMBER"));
						callBackDTO.setCafNumber(rs.getString("CAF_NUMBER"));
						callBackDTO.setPostedDate(rs.getString("FX_DATE"));
						callBackDTO.setPostedTime(rs.getString("FX_TIME"));
						callBackDTO.setPaymentMode(rs.getString("PAYMENT_MODE"));
						callBackDTO.setRefNumber(rs.getString("REF_NUMBER"));
						callBackDTO.setStatus(rs.getString("STATUS"));
						callBackDTO.setTrackingId(rs.getString("TRACKING_ID"));//TRANSACTION_ID
						callBackDTO.setChannelId(rs.getString("CHANNEL_ID"));
							
						CallBackDTOList.add(callBackDTO);
					}

				} catch (Exception e) {
					log.info("Query execution of getCallBackDetails INT_229F ", e);
				} finally {
					if (con != null) {
						try {
							con.commit();
							rs.close();
							callableStatement.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in the getCallBackDetails INT_229F", e);
						}
					}

				}
			}
			log.info("END--->in getCallBackDetails INT_229F method of CustPaymentCallbackDetailsClient");
			return CallBackDTOList;

		}
	 public void updateCallBackResponse(String statusDesc,String statusCode,int transactionId){
		 
			log.info("START--in updateCallBackResponse in ClientDAOImpl----------- ");
			Connection con = null;
			String result = EMPTY_STRING;
			String sql = EMPTY_STRING;
			
			PreparedStatement preparedStatement = null;

			if (transactionId != 0 ) {

				log.info("statusDesc-->>"+statusDesc+" statusCode-->>"+statusCode+" transactionId->"+transactionId);

				sql = "INSERT INTO PAYMENT_CALLBACK_APS(STATUS_CODE,TRANSACTION_ID,STATUS_DESCRIPTION) VALUES(?,?,?)";
			} try{	
				con = ConnectionUtil.getConnection();
				log.info("connection formed in updateCallBackResponse--------->" + con);

			} catch (Exception e) {

				log.info("Connection not established in updateCallBackResponse ", e);
			}
				log.info("query of updateCallBackResponse---" + sql);
				try {
					con.setAutoCommit(false);
					preparedStatement = con.prepareStatement(sql);
					preparedStatement.setString(1, statusCode);
					preparedStatement.setInt(2, transactionId);
					preparedStatement.setString(3, statusDesc);
					preparedStatement.executeUpdate();
					
				} catch (Exception e) {

					log.info("Exception in updateCallBackResponse-->", e);
				}finally {
					if (con != null) {
						try {
							con.commit();
							preparedStatement.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in the updateCallBackResponse", e);
						}
					}
				}
			log.info("END--in updateCallBackResponse in ClientDAOImpl result ---" + result);
	 }
	 
	 	@Override
	public String insertFxLog(String statusCode,String trxnId,String reqJson,String respJson,String lob,String apsFlag,String identifier,String array1,String array2,String dataSet1,String dataSet2) {
		
	 	log.info("START--in updateCallBackResponse in ClientDAOImpl ");
		int status;
		String result="";
		Connection con = null;
		String query = "INSERT INTO APS_FX_LOG VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps = null;
		Clob requestClob =null;
		Clob responseClob =null;
		Clob arrayClob1 =null;
		Clob arrayClob2 =null;
		try{
			con = ConnectionUtil.getConnection();
			con.setAutoCommit(false);
			
			requestClob = con.createClob();
			responseClob=con.createClob();
			arrayClob1=con.createClob();
			arrayClob2 = con.createClob();
			requestClob.setString(1, reqJson);
			responseClob.setString(1, respJson);
			arrayClob1.setString(1, array1);
			arrayClob2.setString(1, array2);
			ps = con.prepareStatement(query);
			
			ps.setString(1, statusCode);
			ps.setString(2, trxnId);
			ps.setClob(3, requestClob);
			ps.setClob(4, responseClob);
			ps.setString(5, lob);
			ps.setString(6, apsFlag);
			ps.setString(7, identifier);
			ps.setClob(8, arrayClob1);
			ps.setClob(9, arrayClob2);
			ps.setTimestamp(10, new Timestamp(new Date().getTime()));
			ps.setString(11, dataSet1);
			ps.setString(12, dataSet2);
			
			status = ps.executeUpdate();
			if(status>0)
				result= RESULT_DB_SUCCESFUL;
			else
				result=RESULT_DB_FAILURE;

			
			
		}
		catch(Exception e){
			log.info("exception occur while insert data inn APS_FX_LOG Table===>"+e.getMessage());
		}
		finally{
			if(con !=null){
				try {
					con.commit();
					ps.close();
					con.close();
				} catch (SQLException e) {
					log.info("exception occur while insert data inn APS_FX_LOG Table===>"+e.getMessage());
				}
			
			}
		}
		log.info("END--in updateCallBackResponse in ClientDAOImpl ");
		return result;
	}

		@Override
		public String getCustomerBillingAccDetail(String transactionId) {
			String result="";
			Connection con = null;
			ResultSet rs =  null;
			PreparedStatement ps = null;
			String query = "SELECT m.INVOICE_NO FROM MISC_VENDOR_FILES_RECORDS m "
					+ "WHERE m.ACCT_EXT_ID IS NULL "
			        + "AND m.DEL_NO IS NULL AND m.TRANSACTION_ID=?";
			log.info("Query for getCustomerBillingAccDetail && transaction id ==>"+ transactionId+" <<==>>"+ query);
			try{
				con = ConnectionUtil.getConnection();
				con.setAutoCommit(false);
				ps = con.prepareStatement(query);
				ps.setString(1,transactionId);
				rs= ps.executeQuery();
				if(rs != null && rs.next()){
					result = rs.getString(1);
				}
				log.info("result from getCustomerBillingAccDetail with transaction id== >"+result);
			}
			catch(Exception e){
				log.info("Error while fetch getCustomerBillingAccDetail data==> "+e.getMessage());
				}
			finally{
				try{
				con.commit();
				if(rs != null)
					rs.close();
				if(ps != null)
					ps.close();
				if(con != null)
					con.close();
				}
				catch(Exception ee){
					log.info("Error occur while resources is close==="+ee.getMessage());
				}
			}
			return result;
		}

		

		public List<NrcDetails> fetchNrcDetailsByAccOrMob(String accountId,String mobile) throws Exception {

			log.info("START--->in fetchNrcDetails method of ClientDAOImpl and account_no is-->" + accountId);
			List<NrcDetails> nrcDetailsList = new ArrayList<NrcDetails>();

			Connection con = null;
			PreparedStatement preparedStatement = null;
			ResultSet rs = null;

			String queryCond ="";
			String date = "to_char(EFFECTIVEDATE ,'YYYY-MM-DD\"" + "T" + "\"HH24:MI:SS') as EFFECTIVEDATE";

			String str = "SELECT TRANSACTION_NO,NRCAMOUNT,TYPEIDNRC,MOBILE_NO,SERVICE_EXTERNAL_ID_TYPE," + date
					+ ",ANNOTATION,APS_FLAG,user_id,JOB_ID FROM NRC_APS where ACCTNO='" + accountId 
					+"' OR MOBILE_NO='"+mobile

					+ "' and STATUS_CODE=" + INITIAL_STATUS_CODE_POSTFX
					+ " and JOB_ID IS NULL ORDER BY NO_OF_HIT,TRANSACTION_NO";

			log.info("QUERY fetchNrcDetails ++" + str.toString() + " and account_no is-->" + accountId);
			try {
				con = ConnectionUtil.getConnection();
				log.info("connection fetchNrcDetails  __________" + con + " and account_no is-->" + accountId);

			} catch (Exception e) {
				log.info("Connection not established ", e);
			}

			if (con != null) {
				try {
					con.setAutoCommit(false);
					preparedStatement = con.prepareStatement(str);
					rs = preparedStatement.executeQuery();
					log.info("resultset fetchNrcDetails-->" + rs + " and account_no is-->" + accountId);
					try {
						if (rs != null) {
							while (rs.next()) {
								NrcDetails nrcDetailsDTO = new NrcDetails();
								nrcDetailsDTO.setTransactionNo(rs.getInt(1));
								// nrcDetailsDTO.setNrcAmount(Double.parseDouble(rs.getString(2)));
								nrcDetailsDTO.setNrcAmount(rs.getDouble(2));
								nrcDetailsDTO.setTypeIdNrc(rs.getInt(3));
								nrcDetailsDTO.setMobileNo(rs.getString(4));
								nrcDetailsDTO.setServiceExternalIdType(rs.getString(5));
								nrcDetailsDTO.setEffectiveDate(rs.getString(6));
								nrcDetailsDTO.setAnnotation(rs.getString(7));
								nrcDetailsDTO.setApsFlag(rs.getString(8));
								nrcDetailsDTO.setUserId(rs.getString(9));
								
								nrcDetailsList.add(nrcDetailsDTO);
							}
						}

					} catch (Exception e) {
						log.info("Query execution of fetchNrcDetails ", e);
					} finally {
						if (con != null) {
							try {
								con.commit();
								preparedStatement.close();
								rs.close();
								con.close();
							} catch (Exception e) {
								log.info("Exception in the fetchNrcDetails", e);
							}
						}
					}
				} catch (Exception e) {
					log.info("Exception in the fetchNrcDetails", e);
				}

			}
			log.info("list fetchNrcDetails-->>" + nrcDetailsList + " and account_no is-->" + accountId);
			log.info("END--->in fetchNrcDetails method of ClientDAOImpl and account_no is-->" + accountId);
			return nrcDetailsList;

		}

		//new method added for PT SR REVERSAL HOME
		@Override
		public String updateResponseForPTSRRevHomes(String statusDescription, String transactionId, String tableName)
				throws Exception {
			log.info("START--in updateResponseForPTSRRevHomes in ClientDAOImpl");

			String result = EMPTY_STRING;
			String sql = EMPTY_STRING;
			Connection con = null;
			CallableStatement callableStatement = null;
			String trim_transactionId = transactionId.substring(3);
			
			sql = "{call AIRTL_PAYMENT_TRANSFER_PKG.GetHomesPaymentTransferDetails(?,?,?,?,?,?,?,?,?)}";
			try {
				con = ConnectionUtil.getConnection();
				if(con!=null){
					con.setAutoCommit(false);
					callableStatement = con.prepareCall(sql);
					callableStatement.setString(1, tableName);
					callableStatement.setString(2, statusDescription);
					callableStatement.setString(3, transactionId);
					callableStatement.setString(4, null);
					callableStatement.setString(5, null);
					callableStatement.setString(6, null);
					callableStatement.setString(7, null);
					callableStatement.registerOutParameter(8, Types.VARCHAR);
					callableStatement.registerOutParameter(9, Types.VARCHAR);
					callableStatement.executeUpdate();
					result = callableStatement.getString(8);
					String erroeCode = callableStatement.getString(9);
					log.info("Result in updateResponseForPTSRRevHomes() is===> "+ result);
				}
				else{
					log.info("Connection is null inside updateResponseForPTSRRevHomes()");
				}
				
			}
			 catch (Exception e) {
					log.info("Connection not established in updateResponseForPTSRRevHomes ", e);
				}
			finally{
				if (con != null) {
					try {
						con.commit();
						callableStatement.close();
						con.close();
					} catch (Exception e) {
						log.info("Exception in updateResponseForPTSRRevHomes ---", e);
					}
				}
			}
			
			return result;
		}

		//new method added for PT SR APP HOME
		@Override
		public String updateResponseForPTSRAPPHomes(List<ResponsePojoForHomes> responsePojoList,
				String statusDescription, String transactionId, String accountId, String lob, String aps_Flag,
				String homesId,String tableName) throws Exception {
			
			log.info("START--in updateResponseForPTSRRevHomes in ClientDAOImpl");

			String result = EMPTY_STRING;
			String sql = EMPTY_STRING;
			Connection con = null;
			CallableStatement callableStatement = null;
			String trim_transactionId = transactionId.substring(3);
			
			sql = "{call AIRTL_PAYMENT_TRANSFER_PKG.GetHomesPaymentTransferDetails(?,?,?,?,?,?,?,?,?)}";
			try {
				con = ConnectionUtil.getConnection();
				if(con!=null){
					con.setAutoCommit(false);
					callableStatement = con.prepareCall(sql);
					callableStatement.setString(1, tableName);
					callableStatement.setString(2, statusDescription);
					callableStatement.setString(3, transactionId);
					callableStatement.setString(4, accountId);
					callableStatement.setString(5, lob);
					callableStatement.setString(6, aps_Flag);
					callableStatement.setString(7, homesId);
					callableStatement.registerOutParameter(8, Types.VARCHAR);
					callableStatement.registerOutParameter(9, Types.VARCHAR);
					callableStatement.executeUpdate();
					result = callableStatement.getString(8);
					String erroeCode = callableStatement.getString(9);
					log.info("Result in updateResponseForPTSRRevHomes() is===> "+ result +"and error code from db==>"+erroeCode);
				}
				else{
					log.info("Connection is null inside updateResponseForPTSRAPPHomes()");
				}
				
			}
			 catch (Exception e) {
					log.info("Connection not established in updateResponseForPTSRAPPHomes ", e);
				}
			finally{
				if (con != null) {
					try {
						con.commit();
						callableStatement.close();
						con.close();
					} catch (Exception e) {
						log.info("Exception in updateResponseForPTSRAPPHomes ---", e);
					}
				}
			}
			
			return result;
		}
		
		
		@Override
		public String getDepositTypeValue(String depositCode) {
			String result="";
			Connection con = null;
			ResultSet rs =  null;
			PreparedStatement ps = null;
			String query = "SELECT DEPOSIT_TYPE,DISPLAY_VALUE FROM DEPOSIT_TYPE_CODE_MST_APS WHERE DEPOSIT_TYPE=?";
			log.info("Query for getDepositTypeValue && DEPOSIT CODE VALUE  ==>"+ depositCode+" <<==>>"+ query);
			try{
				con = ConnectionUtil.getConnection();
				con.setAutoCommit(false);
				ps = con.prepareStatement(query);
				ps.setString(1,depositCode);
				rs= ps.executeQuery();
				if(rs != null && rs.next()){
					result = rs.getString(2);
				}
				log.info("result from getDepositTypeValue with  DEPOSIT CODE== >"+result);
			}
			catch(Exception e){
				log.info("Error while fetch getCustomerBillingAccDetail data==> "+e.getMessage());
				}
			finally{
				try{
				con.commit();
				if(rs != null)
					rs.close();
				if(ps != null)
					ps.close();
				if(con != null)
					con.close();
				}
				catch(Exception ee){
					log.info("Error occur while resources is close==="+ee.getMessage());
				}
			}
			return result;
		}
		public String getLobFromServerId(String serverId) {

			log.info(" Start:: getLobFromServerId server id "+serverId);
			Connection con = null;
			String lob=null;
			try {
				con = ConnectionUtil.getConnection();

				String query = "SELECT LOB FROM SERV_ID_LOB_MSTR WHERE STATUS='A' AND SERV_ID="+ serverId;
				PreparedStatement ps = con.prepareStatement(query);
				log.info("getLobFromServerId query-->>"+query);
				//ps.setString(1, accountNo);
				//ps.setString(2, errMsg);
				ResultSet rs=ps.executeQuery();

				if(rs!=null && rs.next()){
					lob=rs.getString(1);
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				log.info("Exception", e);
			} finally {
				try {
					if(con!=null){
						con.close();

					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					log.info("Exception", e);
				}

			}
			log.info(" END:: getLobFromServerId lob id "+lob);
			return lob;
		}
		
		
		public String headerProcValidation1(List<String> headersList, String fileType, String fileName) {
			/*
			 * try { test(headersList); } catch (Exception e1) { // TODO Auto-generated
			 * catch block e1.printStackTrace(); }
			 */
			log.info("START :in method headerProcValidation of FileUploadDaoImpl");

			final String query = "SELECT A.SL_NO, A.HEADER_TABLE" + 
					"    FROM FILE_COL_MST_APS A, FILE_IDENTIFIER_MST_APS B" + 
					"   WHERE     A.FILE_IDENTIFIER = B.FILE_IDENTIFIER" + 
					"         AND B.FILE_IDENTIFIER = ?" + 
					"ORDER BY A.SL_NO";
			Connection con = null;
			PreparedStatement ps = null;
			String headerStatus = null;
			ResultSet rs=null;
			String error_msg = null;
			int count=0;
			Map<String,String> fileTypeList = new LinkedHashMap<String,String>(); 
			try {

				try {
					con =ConnectionUtil.getConnection();// new JdbcTemplate(dataSource).getDataSource().getConnection();
					ps = con.prepareStatement(query);
					ps.setString(1, fileType);
					rs = ps.executeQuery();
					while(rs.next()){
						log.info("Inside while rs loop");
						fileTypeList.put(rs.getString(1), rs.getString(2));
					}
					int i=0;
					if(headersList.size()>0 && fileTypeList.size()>0) {
					if(fileTypeList.size()==headersList.size()) {
						for (Map.Entry<String, String> entry : fileTypeList.entrySet()) {
							System.out.println(entry.getKey() + " = " + entry.getValue());
							if(entry.getValue().toString().equalsIgnoreCase(headersList.get(i).toString())) {
								count++;
							}else {
								System.out.println(entry.getValue().toString());
								error_msg="HEADER FIELDS VALUES DOES NOT MATCH";
								System.out.println(headersList.get(i).toString());
							}
							i++;
						}
						
					}else {
						error_msg="HEADER COUNT DOES NOT MATCH";
					}
					
					}else {
						error_msg="INPUT VALUES CANNOT BE NULL";
					}
					if(count==fileTypeList.size()) {
						error_msg="SUCCESS";
					}
					
				} catch (Exception e) {
					
					log.info("Conection :: ", e);
				}




			} catch (Exception e) {
				log.info("Exception", e);
			} finally {
				try {
				if(con != null){
					con.close();
				}
				}catch(SQLException e) {
					log.info("Exception", e);
				}catch(Exception e) {
					log.info("Exception", e);
				}

			}		//log.info(error_msg);
			log.info("END :in method headerProcValidation of FileUploadDaoImpl error_msg"+error_msg);
			return error_msg;
		}

		
		public static void main(String[] args) {
			ClientDAOImpl d=new ClientDAOImpl();
			List<String> list = new ArrayList<String>();
			String fileType = "";
			String fileName = "";
			list.add("SR_NUMBER");
			list.add("FX_ACCT_NO");
			list.add("Lob");
			list.add("SR_SUBTYPE");
			list.add("MODE_OF_REFUND");
			list.add("Circle");
			list.add("AMOUNT");
			list.add("CUSTOMER_NAME");
			list.add("JV_NUMBER");
			list.add("CASE_ID_NUMBER");
			list.add("Comments");
			list.add("SR_MODE");
			list.add("PAYMENT_STATUS");
			list.add("OLD_SR_NO");
			list.add("CHEQUE_UTR_NO");
			list.add("CHEQUE_UTR_DATE");
			
			String header=d.headerProcValidation1(list, "IP_UPLOAD", "");
System.out.println(header);
		}
		
}
