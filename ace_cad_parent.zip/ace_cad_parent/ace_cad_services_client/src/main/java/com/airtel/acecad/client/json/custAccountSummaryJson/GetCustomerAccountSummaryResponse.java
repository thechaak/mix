package com.airtel.acecad.client.json.custAccountSummaryJson;

public class GetCustomerAccountSummaryResponse {

	private PartyAccount partyAccount;

    private Individual individual;

    private Status status;

    private LogicalResource logicalResource;

    private CustomerPayment customerPayment;

    private Service service;
    
    private String operationStatusCode;

    private ResponseCustomer customer;

    public PartyAccount getPartyAccount ()
    {
        return partyAccount;
    }

    public void setPartyAccount (PartyAccount partyAccount)
    {
        this.partyAccount = partyAccount;
    }

    public Individual getIndividual ()
    {
        return individual;
    }

    public void setIndividual (Individual individual)
    {
        this.individual = individual;
    }

    public Status getStatus ()
    {
        return status;
    }

    public void setStatus (Status status)
    {
        this.status = status;
    }

    public LogicalResource getLogicalResource ()
    {
        return logicalResource;
    }

    public void setLogicalResource (LogicalResource logicalResource)
    {
        this.logicalResource = logicalResource;
    }

    public CustomerPayment getCustomerPayment ()
    {
        return customerPayment;
    }

    public void setCustomerPayment (CustomerPayment customerPayment)
    {
        this.customerPayment = customerPayment;
    }

    public Service getService ()
    {
        return service;
    }

    public void setService (Service service)
    {
        this.service = service;
    }

    public String getOperationStatusCode() {
		return operationStatusCode;
	}

	public void setOperationStatusCode(String operationStatusCode) {
		this.operationStatusCode = operationStatusCode;
	}

	public ResponseCustomer getCustomer() {
		return customer;
	}

	public void setCustomer(ResponseCustomer customer) {
		this.customer = customer;
	}

	@Override
    public String toString()
    {
        return "{\"partyAccount\" : "+partyAccount+", \"individual\" : "+individual+", \"status\" : "+status+", \"logicalResource\" : \""+logicalResource+"\", \"customerPayment\" : "+customerPayment+", \"service\" : "+service+",\"operationStatusCode\" : \""+operationStatusCode+"\", \"customer\" : "+customer+"}";
    }
}
