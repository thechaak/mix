package com.airtel.acecad.client.json.custAccountSummaryJson;

public class Service {

	 private String inactiveDate;

	    private String activationDate;

	    public String getInactiveDate() {
			return inactiveDate;
		}

		public void setInactiveDate(String inactiveDate) {
			this.inactiveDate = inactiveDate;
		}

		public String getActivationDate ()
	    {
	        return activationDate;
	    }

	    public void setActivationDate (String activationDate)
	    {
	        this.activationDate = activationDate;
	    }

	    @Override
	    public String toString()
	    {
	        return "{\"inactiveDate\" : \""+inactiveDate+"\", \"activationDate\" : \""+activationDate+"\"}";
	    }
}
