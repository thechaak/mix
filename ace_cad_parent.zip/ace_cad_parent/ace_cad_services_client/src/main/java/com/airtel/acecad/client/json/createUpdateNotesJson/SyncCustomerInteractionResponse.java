package com.airtel.acecad.client.json.createUpdateNotesJson;

public class SyncCustomerInteractionResponse {

	 private Status status;

	    public Status getStatus ()
	    {
	        return status;
	    }

	    public void setStatus (Status status)
	    {
	        this.status = status;
	    }

	    @Override
	    public String toString()
	    {
	        return "{\"status\" : "+status+"}";
	    }
}
