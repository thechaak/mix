package com.airtel.acecad.client.json.adjustmentJson;

public class LogicalResource {

	private LogicalResourceIdentification identification;

   // private String type;

	public LogicalResourceIdentification getIdentification() {
		return identification;
	}

	public void setIdentification(LogicalResourceIdentification identification) {
		this.identification = identification;
	}


    @Override
    public String toString()
    {
        return "{\"identification\" : "+identification+"}";
    }
}
