package com.airtel.acecad.client.json.CustomerAccountSummaryJson;

public class AccCustomerBill {

	private ExternalIdentification[] externalIdentification;

    private BillPeriod billPeriod;

    public ExternalIdentification[] getExternalIdentification ()
    {
        return externalIdentification;
    }

    public void setExternalIdentification (ExternalIdentification[] externalIdentification)
    {
        this.externalIdentification = externalIdentification;
    }

    public BillPeriod getBillPeriod ()
    {
        return billPeriod;
    }

    public void setBillPeriod (BillPeriod billPeriod)
    {
        this.billPeriod = billPeriod;
    }

    @Override
    public String toString()
    {
        return "{\"externalIdentification\" : "+externalIdentification+", \"billPeriod\" : "+billPeriod+"}";
    }
}
