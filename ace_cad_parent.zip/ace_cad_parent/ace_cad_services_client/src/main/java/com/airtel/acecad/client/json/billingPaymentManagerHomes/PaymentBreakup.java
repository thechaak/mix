package com.airtel.acecad.client.json.billingPaymentManagerHomes;

public class PaymentBreakup {

	private String excessAmount;

    private String previousAdjustments;

    private String currentAmount;

    public String getExcessAmount() {
		return excessAmount;
	}

	public void setExcessAmount(String excessAmount) {
		this.excessAmount = excessAmount;
	}

	public String getPreviousAdjustments() {
		return previousAdjustments;
	}

	public void setPreviousAdjustments(String previousAdjustments) {
		this.previousAdjustments = previousAdjustments;
	}

	public String getCurrentAmount() {
		return currentAmount;
	}

	public void setCurrentAmount(String currentAmount) {
		this.currentAmount = currentAmount;
	}

	@Override
    public String toString()
    {
        return "{\"excessAmount\" : \""+excessAmount+"\", \"previousAdjustments\" : \""+previousAdjustments+"\", \"currentAmount\" : \""+currentAmount+"\"}";
    }
}
