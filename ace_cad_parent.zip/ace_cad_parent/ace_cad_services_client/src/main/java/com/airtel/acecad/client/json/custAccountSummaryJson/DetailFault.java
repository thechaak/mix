package com.airtel.acecad.client.json.custAccountSummaryJson;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY )
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DetailFault
{

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private  GetCustomerAccountSummaryFault  getCustomerAccountSummaryFault;
	
	
	
    public GetCustomerAccountSummaryFault getGetCustomerAccountSummaryFault() {
		return getCustomerAccountSummaryFault;
	}

	public void setGetCustomerAccountSummaryFault(GetCustomerAccountSummaryFault getCustomerAccountSummaryFault) {
		this.getCustomerAccountSummaryFault = getCustomerAccountSummaryFault;
	}

	@Override
    public String toString()
    {
        return "{\"getCustomerAccountSummaryFault\" : "+getCustomerAccountSummaryFault+"}";
    }
}