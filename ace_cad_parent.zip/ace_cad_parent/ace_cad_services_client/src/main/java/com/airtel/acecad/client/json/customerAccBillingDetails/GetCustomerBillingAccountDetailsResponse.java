package com.airtel.acecad.client.json.customerAccBillingDetails;

public class GetCustomerBillingAccountDetailsResponse {
	private Status status;

    private AccountSummary accountSummary;

    public Status getStatus ()
    {
        return status;
    }

    public void setStatus (Status status)
    {
        this.status = status;
    }

    public AccountSummary getAccountSummary ()
    {
        return accountSummary;
    }

    public void setAccountSummary (AccountSummary accountSummary)
    {
        this.accountSummary = accountSummary;
    }

	@Override
	public String toString() {
		return "GetCustomerBillingAccountDetailsResponse [status=" + status + ", accountSummary=" + accountSummary
				+ "]";
	}

   
}
