package com.airtel.acecad.client.dto;

import java.sql.Timestamp;
import java.util.Date;

public class AdjPostDetails {

	int transactionNo;
	int srTransactionNo;
	int fileId;
	String fileIdentifier;
	String srNumber;
	String srCategory;
	
	String accountExternalId;
	String effectiveDate;
//	int serviceExternalId;
	String serviceExternalId;
	
	double amount;
	String adjReasonCode;
	String transCode;
	String typeOfAdjustment;
	
	String source;
	String apsFlag;

	int serviceExternalIdType;
	int billRefResets;
	String billRefNo;
	String annotation;
	
	Timestamp createdDate;
	Timestamp modifiedDate;
	
	int targetTrackingId;
	int targettrackinIdServ;
	int statusCode;
	String statusDescription;
	int noOfHit;
	String userId;
	
	
	public String getServiceExternalId() {
		return serviceExternalId;
	}
	public void setServiceExternalId(String serviceExternalId) {
		this.serviceExternalId = serviceExternalId;
	}
	public int getTransactionNo() {
		return transactionNo;
	}
	public void setTransactionNo(int transactionNo) {
		this.transactionNo = transactionNo;
	}
	public int getSrTransactionNo() {
		return srTransactionNo;
	}
	public void setSrTransactionNo(int srTransactionNo) {
		this.srTransactionNo = srTransactionNo;
	}
	public int getFileId() {
		return fileId;
	}
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}
	public String getFileIdentifier() {
		return fileIdentifier;
	}
	public void setFileIdentifier(String fileIdentifier) {
		this.fileIdentifier = fileIdentifier;
	}
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getSrCategory() {
		return srCategory;
	}
	public void setSrCategory(String srCategory) {
		this.srCategory = srCategory;
	}
	
	public String getAccountExternalId() {
		return accountExternalId;
	}
	public void setAccountExternalId(String accountExternalId) {
		this.accountExternalId = accountExternalId;
	}
	
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	/*public int getServiceExternalId() {
		return serviceExternalId;
	}
	public void setServiceExternalId(int serviceExternalId) {
		this.serviceExternalId = serviceExternalId;
	}*/
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getAdjReasonCode() {
		return adjReasonCode;
	}
	public void setAdjReasonCode(String adjReasonCode) {
		this.adjReasonCode = adjReasonCode;
	}
	public String getTransCode() {
		return transCode;
	}
	public void setTransCode(String transCode) {
		this.transCode = transCode;
	}
	public String getTypeOfAdjustment() {
		return typeOfAdjustment;
	}
	public void setTypeOfAdjustment(String typeOfAdjustment) {
		this.typeOfAdjustment = typeOfAdjustment;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getApsFlag() {
		return apsFlag;
	}
	public void setApsFlag(String apsFlag) {
		this.apsFlag = apsFlag;
	}
	public int getServiceExternalIdType() {
		return serviceExternalIdType;
	}
	public void setServiceExternalIdType(int serviceExternalIdType) {
		this.serviceExternalIdType = serviceExternalIdType;
	}
	
	
	public void setBillRefResets(int billRefResets) {
		this.billRefResets = billRefResets;
	}
	public String getAnnotation() {
		return annotation;
	}
	public void setAnnotation(String annotation) {
		this.annotation = annotation;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public int getTargetTrackingId() {
		return targetTrackingId;
	}
	public void setTargetTrackingId(int targetTrackingId) {
		this.targetTrackingId = targetTrackingId;
	}
	public int getTargettrackinIdServ() {
		return targettrackinIdServ;
	}
	public void setTargettrackinIdServ(int targettrackinIdServ) {
		this.targettrackinIdServ = targettrackinIdServ;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	public int getNoOfHit() {
		return noOfHit;
	}
	public void setNoOfHit(int noOfHit) {
		this.noOfHit = noOfHit;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getBillRefResets() {
		return billRefResets;
	}
	public String getBillRefNo() {
		return billRefNo;
	}
	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}
	
}

