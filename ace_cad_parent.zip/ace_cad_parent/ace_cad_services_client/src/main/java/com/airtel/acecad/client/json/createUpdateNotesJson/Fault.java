package com.airtel.acecad.client.json.createUpdateNotesJson;

public class Fault {
	private DetailFault detail;

    private String faultcode;

    private String faultstring;
    

    public DetailFault getDetail ()
    {
        return detail;
    }

    public void setDetail (DetailFault detail)
    {
        this.detail = detail;
    }

    public String getFaultcode ()
    {
        return faultcode;
    }

    public void setFaultcode (String faultcode)
    {
        this.faultcode = faultcode;
    }

    public String getFaultstring ()
    {
        return faultstring;
    }

    public void setFaultstring (String faultstring)
    {
        this.faultstring = faultstring;
    }

    @Override
    public String toString()
    {
        return "{ \"faultcode\" : "+faultcode+", \"faultstring\" :"+faultstring+",\"detail\":"+detail+"}";
    }
}
