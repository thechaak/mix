package com.airtel.acecad.client.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.airtel.acecad.client.dto.BulkDetails;
import com.airtel.acecad.client.dto.PaymentReversalDetails;
import com.airtel.acecad.client.dto.PostPaymentToFXRequest;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.ConnectionUtil;
import com.airtel.acecad.client.util.GlobalConstants;

import oracle.jdbc.OracleTypes;

public class ReversalDaoImpl implements GlobalConstants, ReverseDao {

	private static Logger log = LogManager.getLogger("serviceClientUI");

	public String insertCustPayment(String accountNum) throws Exception {

		log.info("Start: insertCustPayment in  ReversalDaoImpl");
		String procCall = "{call REVERSAL_PAYMENT_CHECK_APS(?,?,?)}";
		Connection con = null;
		CallableStatement callableStatement = null;
		String errorCode = EMPTY_STRING;
		String errorMsg = EMPTY_STRING;
		String result = EMPTY_STRING;
		try {
			con = ConnectionUtil.getConnection();
			// con.setAutoCommit(false);
		} catch (Exception e) {
			log.info("In insertCustPayment connection not made", e);
		}
		try {
			if (con != null) {
				log.info("Connection made for insertCustPayment method");
				callableStatement = con.prepareCall(procCall);
				callableStatement.setString(1, accountNum);
				log.info("accountNum--" + accountNum);
				callableStatement.registerOutParameter(2, Types.VARCHAR);
				callableStatement.registerOutParameter(3, Types.VARCHAR);
				callableStatement.executeUpdate();
				errorCode = callableStatement.getString(2);
				log.info("OutPut from REVERSAL_PAYMENT_CHECK_APS in PaymentPostDaoImpl errorCode--- " + errorCode);
				errorMsg = callableStatement.getString(3);
				log.info("OutPut from REVERSAL_PAYMENT_CHECK_APS in PaymentPostDaoImpl errorMsg--- " + errorMsg);
				result = errorCode + ":" + errorMsg;
			}
		} catch (Exception e) {
			// TODO: handle exception
			log.info("Exception in insertCustPayment ---", e);
		} finally {
			callableStatement.close();
			con.close();
		}
		log.info("End: insertCustPayment in  ReversalDaoImpl result---->" + result);
		return result;
	}

	/* TO MERGED IN 315 RESPONSE AND TO BE REMOVED FROMN HERE */
	public String updatePaymentRevForApp(String chequeNo, BulkDetails postPaymentToFXRequest) throws Exception {

		log.info("START--in updatePaymentRevForApp in ClientDAOImpl----------- ");
		Connection con = null;
		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;
		PreparedStatement preparedStatement = null;

		log.info(" updatePaymentPostDetails----chequeNo-->" + chequeNo);

		sql = "UPDATE AIRTL_EPP_VENDOR_FILES_RECORDS SET REF_NUMBER = '" + chequeNo + "'  where ORIG_TRACKING_ID = '"
				+ postPaymentToFXRequest.getOrigTrackingServId() + "' "
				+ "and APS_FLAG = 'APS' and ORIG_TRACKING_ID_SERV = '" + postPaymentToFXRequest.getOrigTrackingServId()
				+ "'  and SOURCE_ID ='SR'";

		try {
			con = ConnectionUtil.getConnection();
			log.info("connection formed in updatePaymentRevForApp--------->" + con);

		} catch (Exception e) {

			log.info("Connection not established ", e);
		}

		if (con != null) {
			log.info("query of updatePaymentRevForApp---" + sql);
			try {
				con.setAutoCommit(false);
				preparedStatement = con.prepareStatement(sql);
				int resultSet = preparedStatement.executeUpdate();
				try {
					if (resultSet > 0) {
						result = RESULT_DB_SUCCESFUL;
					} else {
						result = RESULT_DB_FAILURE;
					}
				} catch (Exception e) {
					log.info("Query execution updatePaymentRevForApp---->", e);
				} finally {
					con.commit();
					preparedStatement.close();
					con.close();
				}
			} catch (Exception e) {

				log.info("Exception in updatePaymentRevForApp-->", e);
			}

		}
		log.info("END--in updatePaymentRevForApp in ClientDAOImpl result ---" + result);
		return result;
	}

	/********/
	public List<PostPaymentToFXRequest> fetchPaymenReversalDetails(String accountId, String recordType)
			throws Exception {

		log.info("START--in fetchPaymentReversalDetails in ReversalDAOImpl ");
		List<PostPaymentToFXRequest> paymentReversalToFXRequestList = new ArrayList<PostPaymentToFXRequest>();
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		// mod(posting_retrial_attempts+1,3)!=0 not posting_retrial_attempts<3
		// as per new requirement after 3 attempts user want to post to fx again
		// then also u need to do it
		// mod(posting_retrial_attempts+1,3) changed to
		// mod(posting_retrial_attempts,3) om 7 FEB
		String str = "SELECT PAYMENT_DETAILS_3,PAYMENT_ADVICE_REQUEST_ID,ORIG_TRACKING_ID,ORIG_TRACKING_ID_SERV,ANNOTATION,BMF_TRANS_TYPE,USER_ID,TRANSACTION_ID,POSTING_RETRIAL_ATTEMPTS,RECORD_TYPE,PAYMENT_MODE,SR_NUMBER FROM AIRTL_CUST_PAYMENT_DETAILS WHERE "
				+ "  APS_FLAG = 'APS' and ACCT_EXT_ID ='" + accountId
				+ "' and TRACKING_ID IS null and  TRACKING_ID_SERV is null and posting_status_fx in ('0') and (mod(posting_retrial_attempts,3)!=0 or posting_retrial_attempts = 0) and UPPER(record_type) =UPPER('"
				+ recordType + "')" + " AND job_id is null "
				+ " and (PAYMENT_ADVICE_REQUEST_ID is null or (PAYMENT_ADVICE_REQUEST_ID is not null and PAYMENT_DETAILS_3 in ('"
				+ INT_219_PASSED + "')))"
				+ " order by posting_retrial_attempts ,RECORD_ID"
				;
		// + "and (payment_mode is null or UPPER(payment_mode) in ('PT')) ";

		log.info("query in fetchPaymenReversalDetails----->>" + str);
		// 0-not posted in fx,1 --posted successfully
		// due to system error like fx down

		try {
			con = ConnectionUtil.getConnection();
			log.info("connection formed in fetchPaymentReversalDetails--------->" + con);

		} catch (Exception e) {
			log.info("Connection not established ", e);
		}
		if (con != null) {
			log.info("query fetchPaymentReversalDetails-->" + str);
			con.setAutoCommit(false);
			preparedStatement = con.prepareStatement(str);
			resultSet = preparedStatement.executeQuery();
			try {

				if (resultSet != null) {
					while (resultSet.next()) {

						PostPaymentToFXRequest postPaymentToFXRequest = new PostPaymentToFXRequest();
						/*postPaymentToFXRequest.setPaymentDetails3(resultSet.getString(1));
						postPaymentToFXRequest.setPaymenAdviceRequestID(resultSet.getString(2));

						postPaymentToFXRequest.setOrigTrackingId(resultSet.getString(3));
						postPaymentToFXRequest.setOrigTrackingIdServ(resultSet.getString(4));
						postPaymentToFXRequest.setAnnotation(resultSet.getString(5));
						postPaymentToFXRequest.setBmfTransType(resultSet.getString(6));
						postPaymentToFXRequest.setUserId(resultSet.getString(7));
						postPaymentToFXRequest.setTransactionId(resultSet.getString(8));
						postPaymentToFXRequest.setPostRetrialAttempts(resultSet.getString(9));
						postPaymentToFXRequest.setAcctExtId(accountId);
						// added on 1 Jan
						postPaymentToFXRequest.setRecordType(resultSet.getString(10));
						postPaymentToFXRequest.setPaymentMode(resultSet.getString(11));
						postPaymentToFXRequest.setSrNumber(resultSet.getString(12));*/
						paymentReversalToFXRequestList.add(postPaymentToFXRequest);
					}

				}

			} catch (Exception e) {
				log.info("Query execution ", e);
			} finally {
				resultSet.close();
				preparedStatement.close();
				con.close();
			}

		}
		log.info("postPaymentToFXRequestList  fetchPaymentPostDetails----" + paymentReversalToFXRequestList);
		log.info("END--in fetchPaymentReversalDetails in ClientDAOImpl ");
		return paymentReversalToFXRequestList;
	}

	/*
	 * @author :- Tanu Goyal
	 */

	public String updateResponseInt(String trackingId, String trackingServId, String faultDescription,
			PaymentReversalDetails paymentReversalDetails, int jobId,String fileIdentifier) throws Exception {
		log.info("Start--in updateResponseInt in ReversalDAOImpl result for transaction id --->"
				+ paymentReversalDetails.getTransactionId());
		
		log.info("trackingId->"+trackingId+" trackingServId->"
		+trackingServId+" faultDescription"+faultDescription+" paymentReversalDetails.getAcctExtId()-"+paymentReversalDetails.getAcctExtId());
		Connection con = null;
		String result = EMPTY_STRING;
		CallableStatement callableStatement = null;
		String paymentMode=EMPTY_STRING;
		String transferType=EMPTY_STRING;
		if(REVERSAL.equalsIgnoreCase(fileIdentifier)){
			paymentMode=REVERSAL;
			transferType=REVERSAL;
		}else if (REV.equalsIgnoreCase(fileIdentifier)){
			paymentMode="TRANSFER";
			transferType=REV;
		}else if ("ECS_315".equalsIgnoreCase(fileIdentifier)){
			paymentMode="ECS";
			transferType=REV;
		}
		else if("REFUND_315".equalsIgnoreCase(fileIdentifier)){
			paymentMode="REFUND";
			transferType=REVERSAL;
		}
		else if("SELFCARE_315".equalsIgnoreCase(fileIdentifier)){
			paymentMode="SELFCARE";
			transferType=REVERSAL;
		}	else if ("ADVICE_315".equalsIgnoreCase(fileIdentifier)){
			paymentMode="ADVICE_315";
			transferType="ADVICE_315";
		}
		
		log.info("Payment_mode in UPDATE_PAY_REV_RESPONSE_APS3 proc for reversal:::"+paymentMode);
		log.info("transferType in UPDATE_PAY_REV_RESPONSE_APS3 proc for reversal:::"+transferType);
		String procedureCall = "{call UPDATE_PAY_REV_RESPONSE_APS3(?,?,?,?,?,?,?,?)}";

		/*log.info("ESBWSResponse|" + jobId + "|" + paymentReversalDetails.getTransactionId() + "|"
				+ AIRTL_CUST_PAYMENT_DETAILS + "|exec UPDATE_PAY_REV_RESPONSE_APS('" + trackingId + "','" + trackingServId
				+ "','" + faultDescription + "', '" + paymentReversalDetails.getTransactionId() + "', '"
				+ paymentReversalDetails.getAcctExtId() + "', '" + paymentReversalDetails.getPaymentMode() + "' , '"
				+ paymentReversalDetails.getRecordType() + "'," + jobId + ",:response)");*/

		try {
			
			con = ConnectionUtil.getConnection();
			con.setAutoCommit(false);
			log.info("connection formed in updateResponseInt--------->" + con);

		} catch (Exception e) {

			log.info("Connection not established ", e);
		}

		if (con != null) {

			try {

				if (!CommonUtil.isNotNull(trackingId)) {
					trackingId = null;
				}
				if (!CommonUtil.isNotNull(trackingServId)) {
					trackingServId = null;
				}
				if (!CommonUtil.isNotNull(faultDescription)) {
					faultDescription = null;
				}
				if (!CommonUtil.isNotNull(paymentReversalDetails.getTransactionId())) {
					paymentReversalDetails.setTransactionId(null);
				}

				callableStatement = con.prepareCall(procedureCall);
				callableStatement.setString(1, trackingId);
				callableStatement.setString(2, trackingServId);
				//callableStatement.setString(3, "2502-F:no data record FDFDD ===");
				callableStatement.setString(3, faultDescription);
				callableStatement.setString(4, paymentReversalDetails.getTransactionId());
				callableStatement.setString(5, paymentReversalDetails.getAcctExtId());
				callableStatement.setString(6, paymentMode);
				callableStatement.setString(7, transferType);
				callableStatement.registerOutParameter(8, Types.VARCHAR);
				callableStatement.executeUpdate();
				result = callableStatement.getString(8);

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally{
				con.commit();
				if(callableStatement != null)
					callableStatement.close();
				if(con != null)
					con.close();
			}

		}

		log.info("END--in updateResponseInt in ReversalDAOImpl result ---" + result + " transaction id --->"
				+ paymentReversalDetails.getTransactionId());
		return result;
	}
	
	
	public String updateResponseForPaymentPosting(String trackingId, String trackingServId, String faultDescription,
			PostPaymentToFXRequest postPaymentToFXRequest, int jobId,String val,String tableName) throws Exception {
		log.info("END--in updateResponseForPaymentPosting in ReversalDAOImpl result for transaction id --->"
				+ postPaymentToFXRequest.getTransactionId());

		Connection con = null;
		String result = EMPTY_STRING;
		String transferType=EMPTY_STRING;
		CallableStatement callableStatement = null;
		
		if("TRANSFER".equalsIgnoreCase(postPaymentToFXRequest.getPaymentMode())){
			transferType="APP";
		}
		else if(val!=null && "ADVICE_313".equalsIgnoreCase(val)){
			postPaymentToFXRequest.setPaymentMode("ADVICE_313");
			transferType="ADVICE_313";
		}
		else{
			transferType="PAYMENT";
		}
		log.info("Payment_mode in UPDATE_PAY_REV_RESPONSE_APS3 proc for payment:::"+postPaymentToFXRequest.getPaymentMode());
		log.info("transferType in UPDATE_PAY_REV_RESPONSE_APS3 proc for payment:::"+transferType);
		
		String procedureCall = "{call UPDATE_PAY_REV_RESPONSE_APS3(?,?,?,?,?,?,?,?)}";

		log.info("ESBWSResponse|" + jobId + "|" + postPaymentToFXRequest.getTransactionId() + "|"
				+ tableName + "|exec UPDATE_PAY_REV_RESPONSE_APS('" + trackingId + "','" + trackingServId
				+ "','" + faultDescription + "', '" + postPaymentToFXRequest.getTransactionId() + "', '"
				+ postPaymentToFXRequest.getAcctExtId() + "', '" + postPaymentToFXRequest.getPaymentMode() + "' , '"
				+ transferType + "'," + jobId + ",:response)");

		try {
			con = ConnectionUtil.getConnection();
			log.info("connection formed in updateResponseForPaymentPosting--------->" + con);

		} catch (Exception e) {

			log.info("Connection not established ", e);
		}

		if (con != null) {

			try {
                  
				if (!CommonUtil.isNotNull(trackingId)) {
					trackingId = null;
				}
				if (!CommonUtil.isNotNull(trackingServId)) {
					trackingServId = null;
				}
				if (!CommonUtil.isNotNull(faultDescription)) {
					faultDescription = null;
				}
				if (!CommonUtil.isNotNull(postPaymentToFXRequest.getTransactionId())) {
					postPaymentToFXRequest.setTransactionId(null);
				}

				callableStatement = con.prepareCall(procedureCall);
				callableStatement.setString(1, trackingId);
				callableStatement.setString(2, trackingServId);
				callableStatement.setString(3, faultDescription);
				callableStatement.setString(4, postPaymentToFXRequest.getTransactionId());
				callableStatement.setString(5, postPaymentToFXRequest.getAcctExtId());
				callableStatement.setString(6, postPaymentToFXRequest.getPaymentMode());
				callableStatement.setString(7, transferType);
				callableStatement.registerOutParameter(8, Types.VARCHAR);
				callableStatement.executeUpdate();
				result = callableStatement.getString(8);

			} catch (SQLException e) {
				log.info("Error occur in updateResponseForPaymentPosting===>" +e.getMessage());
			}
			finally{
				if(callableStatement != null)
					callableStatement.close();
				if(con != null)
					con.close();
			}

		}

		log.info("END--in updateResponseForPaymentPosting in ReversalDAOImpl result ---" + result + " transaction id --->"
				+ postPaymentToFXRequest.getTransactionId());
		return result;
	}

	
	
	

	public List<BulkDetails> getreversalPaymentAdvice(String accountNo, String recordType) throws Exception {
		log.info("START--in getreversalPaymentAdvice in ClientDAOImpl accountNo" + accountNo);
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<BulkDetails> bulkList = new ArrayList<>();

		String str = "Select TRANSACTION_ID,PAYMENT_AMOUNT,ORIG_TRACKING_ID,ORIG_TRACKING_ID_SERV,file_id"
				+ " from AIRTL_CUST_PAYMENT_DETAILS  where ACCT_EXT_ID = '" + accountNo + "' and RECORD_TYPE='" + recordType
				+ "' and aps_flag='APS' and PAYMENT_ADVICE_REQUEST_ID is not null";

		try {
			con = ConnectionUtil.getConnection();
			log.info("connection formed in getreversalPaymentAdvic--------->" + con);

		} catch (Exception e) {
			log.info("Connection not established ", e);
		}
		if (con != null) {
			log.info("query getreversalPaymentAdvice-->" + str);
			con.setAutoCommit(false);
			preparedStatement = con.prepareStatement(str);
			resultSet = preparedStatement.executeQuery();
			try {

				if (resultSet != null) {
					while (resultSet.next()) {

						BulkDetails bulkdetails = new BulkDetails();

						bulkdetails.setRecordId(resultSet.getString(1));// here
																		// it is
																		// transaction
																		// id
						bulkdetails.setPaymentAmt(resultSet.getString(2));
						bulkdetails.setOrigTrackingId(resultSet.getString(3));
						bulkdetails.setOrigTrackingServId(resultSet.getString(4));
						bulkdetails.setFileID(resultSet.getString(5));
						bulkdetails.setAcctEXTID(accountNo);
						bulkList.add(bulkdetails);
					}
				}

			} catch (Exception e) {
				log.info("Query execution ", e);
			} finally {
				resultSet.close();
				preparedStatement.close();
				con.close();
			}
		}

		log.info("END--in getreversalPaymentAdvice in ClientDAOImpl ");
		return null;

	}


	public List<BulkDetails> getReversalAdviceDetails(String accountNo, String recordType) throws Exception {
		log.info("START--in getreversalPaymentAdvice in ClientDAOImpl accountNo" + accountNo);
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<BulkDetails> bulkList = new ArrayList<>();

		String str = "Select RECORD_ID,amount_in_inr,REV_ORIG_TRACKING_ID,REV_ORIG_TRACKING_ID_SERV,REV_FILE_ID "
				+ " from ADVICE_VENDOR_FILES_RECORDS  where ACCT_EXT_ID = '" + accountNo + "' and RECORD_TYPE='" + recordType
				+ "' and aps_flag in ('APS','CAD') and status_code=1";

		try {
			con = ConnectionUtil.getConnection();
			log.info("connection formed in getreversalPaymentAdvic--------->" + con);

		} catch (Exception e) {
			log.info("Connection not established ", e);
		}
		if (con != null) {
			log.info("query getreversalPaymentAdvice-->" + str);
			con.setAutoCommit(false);
			preparedStatement = con.prepareStatement(str);
			resultSet = preparedStatement.executeQuery();
			try {

				if (resultSet != null) {
					while (resultSet.next()) {

						BulkDetails bulkdetails = new BulkDetails();

						bulkdetails.setRecordId(resultSet.getString(1));// here
						// it is
						// transaction
						// id
						bulkdetails.setPaymentAmt(resultSet.getString(2));
						bulkdetails.setOrigTrackingId(resultSet.getString(3));
						bulkdetails.setOrigTrackingServId(resultSet.getString(4));
						bulkdetails.setFileID(resultSet.getString(5));
						bulkdetails.setAcctEXTID(accountNo);
						bulkList.add(bulkdetails);
					}
				}

			} catch (Exception e) {
				log.info("Query execution ", e);
			} finally {
				resultSet.close();
				preparedStatement.close();
				con.close();
			}
		}

		log.info("END--in getreversalPaymentAdvice in ClientDAOImpl ");
		return bulkList;

	}
	public String updateReversalDetails(String recordId,String status) throws Exception{

		log.info("START--in updateReversalDetails and record_id is-->" + recordId);
		List<PaymentReversalDetails> paymentRevDetailsList = new ArrayList<>();
		Connection con = null;
	
		CallableStatement callableStatement=null;
		String query="{call UPDATE_ADVICE_REVERSAL_DETAILS(?,?,?)}";
		try {
			con = ConnectionUtil.getConnection();
			log.info("connection formed in fetchPaymentRevDirDetails--------->" + con + "and account_no is-->"
					+ recordId);
			// con.setAutoCommit(false);
		} catch (Exception e) {
			log.info("Connection not established ", e);
		}
		try {
			callableStatement = con.prepareCall(query);
			callableStatement.setString(1, recordId);
			callableStatement.setString(2, status);
			callableStatement.registerOutParameter(3, Types.VARCHAR);

			callableStatement.executeUpdate();
			
			status=callableStatement.getString(3);
		
		} catch (Exception e) {
			log.info(e);
		}finally{
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				log.info("Exception in call method", e);
			}
		}

		
		log.info("END--in updateReversalDetails and status is-->" + status);
		return null;

	}

	public String updateAdviceRev(BulkDetails bulkObj) throws Exception {

		log.info("START--in updateAdviceRev in ClientDAOImpl----------- ");
		Connection con = null;
		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;
		PreparedStatement preparedStatement = null;

		log.info(" updatePaymentPostDetails----accountNo-->" + bulkObj.getAcctEXTID() + " TRANSACTION_ID = '"
				+ bulkObj.getRecordId());

		sql = "UPDATE airtl_cust_payment_details SET PAYMENT_DETAILS_3 = '" + bulkObj.getErrorMsg()
				+ "'  where ORIG_TRACKING_ID = '" + bulkObj.getOrigTrackingServId() + "' "
				+ "   and APS_FLAG = 'APS' and ORIG_TRACKING_ID_SERV = '" + bulkObj.getOrigTrackingServId()
				+ "'  and TRANSACTION_ID = '" + bulkObj.getRecordId() + "'  and file_id= '" + bulkObj.getFileID()
				+ "'  and ACCT_EXT_ID='" + bulkObj.getAcctEXTID() + "' ";

		try {
			con = ConnectionUtil.getConnection();
			log.info("connection formed in updateAdviceRev--------->" + con);

		} catch (Exception e) {

			log.info("Connection not established ", e);
		}

		if (con != null) {
			log.info("query of updateAdviceRev---" + sql);
			try {
				con.setAutoCommit(false);
				preparedStatement = con.prepareStatement(sql);
				int resultSet = preparedStatement.executeUpdate();
				try {
					if (resultSet > 0) {
						result = RESULT_DB_SUCCESFUL;
					} else {
						result = RESULT_DB_FAILURE;
					}
				} catch (Exception e) {
					log.info("Query execution updateAdviceRev---->", e);
				} finally {
					con.commit();
					preparedStatement.close();
					con.close();
				}
			} catch (Exception e) {

				log.info("Exception in updateAdviceRev-->", e);
			}

		}
		log.info("END--in updateAdviceRev in ClientDAOImpl result ---" + result);
		return result;
	}

	
	public List<PaymentReversalDetails> fetchPaymentRevDirDetails(String accountId,String fileIdentifier) throws Exception{
		
		log.info("START--in fetchPaymentRevDirDetails in ClientDAOImpl and account_no is-->" + accountId);
		List<PaymentReversalDetails> paymentRevDetailsList = new ArrayList<>();
		Connection con = null;
		ResultSet resultSet = null;
		String status=null;
		CallableStatement callableStatement=null;
		String query="{call PAYREV_FETCH_APS(?,?,?,?)}";
		try {
		con = ConnectionUtil.getConnection();
		log.info("connection formed in fetchPaymentRevDirDetails--------->" + con + "and account_no is-->"
		+ accountId);
		// con.setAutoCommit(false);
		} catch (Exception e) {
		log.info("Connection not established ", e);
		}
		try {
		callableStatement = con.prepareCall(query);
		callableStatement.setString(1, accountId);
		callableStatement.setString(2, fileIdentifier);
		callableStatement.registerOutParameter(3,OracleTypes.CURSOR);
		callableStatement.registerOutParameter(4, Types.VARCHAR);

		callableStatement.executeUpdate();
		resultSet = (ResultSet) callableStatement.getObject(3);
		status=callableStatement.getString(4);
		while(resultSet!=null && resultSet.next()){
			
		PaymentReversalDetails payRevDetails=new PaymentReversalDetails();	
		payRevDetails.setOrigTrackingId(resultSet.getString("orig_tracking_id"));
		payRevDetails.setSrNumber(resultSet.getString("sr_number"));
		payRevDetails.setAnnotation(resultSet.getString("annotation"));
		payRevDetails.setOrigTrackingIdServ(resultSet.getString("orig_tracking_id_serv"));
		payRevDetails.setPaymentCode(resultSet.getString("payment_code"));
		payRevDetails.setUserId(resultSet.getString("user_id"));
		payRevDetails.setNoOfHits(resultSet.getInt("no_of_hit"));
		payRevDetails.setTransactionId(resultSet.getString("transaction_id"));
		payRevDetails.setLobType(resultSet.getString("lob"));
		payRevDetails.setApsFlag(resultSet.getString("aps_flag"));
		payRevDetails.setB2b2c(resultSet.getString("b2b2c"));
		
		paymentRevDetailsList.add(payRevDetails);
		}
		} catch (Exception e) {
		log.info(e);
		}
		finally{
			if(resultSet != null)
				resultSet.close();
			if(callableStatement != null)
				callableStatement.close();
			if(con != null)
				con.close();
		}

		log.info("paymentRevDetailsList  fetchPaymentRevDirDetails----" + paymentRevDetailsList
		+ "and account_no is-->" + accountId);
		log.info("END--in fetchPaymentRevDirDetails in ClientDAOImpl and account_no is-->" + accountId);
		return paymentRevDetailsList;
	}

	 public String updateResonseCustomerBillingAccount(String invoiceNo,String transactionId,String faultDescription){
		 	Connection con = null;
			String result = EMPTY_STRING;
			CallableStatement callableStatement = null;
			
			
			log.info("Invoice No  in UPDATE_PAY_REV_RESPONSE_APS3 proc for fetchInvoiceNo:::"+invoiceNo);
			log.info("transaction id and fault description in UPDATE_PAY_REV_RESPONSE_APS3 proc for fetchInvoiceNo:::"+transactionId+" == "+ faultDescription);
			String procedureCall = "{call UPDATE_PAY_REV_RESPONSE_APS3(?,?,?,?,?,?,?,?)}";

			log.info("ESBWSResponse|" + null + "|" + transactionId + "|"
					+ AIRTL_CUST_PAYMENT_DETAILS + "|exec UPDATE_PAY_REV_RESPONSE_APS('" + null + "','" + null
					+ "','" + faultDescription + "', '" + transactionId+ "', '"
					+ null + "', '" +null + "' , '"
					+ "INVOICEDETAILS" + "'," +" PAYMENT "+ ",:response)");

			try {
				con = ConnectionUtil.getConnection();
				log.info("connection formed in updateResonseCustomerBillingAccount--------->" + con);

			} catch (Exception e) {
				log.info("Connection not established ", e);
			}

			if (con != null) {
                 
				try {
					  con.setAutoCommit(false);
					if (!CommonUtil.isNotNull(invoiceNo)) {
						invoiceNo = null;
					}
					if (!CommonUtil.isNotNull(faultDescription)) {
						faultDescription = null;
					}

					callableStatement = con.prepareCall(procedureCall);
					//callableStatement.setString(1, "1900");
					callableStatement.setString(1, invoiceNo);
					callableStatement.setString(2, null);
					//callableStatement.setString(3, "0000-S:Request 190001245 SUCCESSfullyyy");
					callableStatement.setString(3, faultDescription);
					callableStatement.setString(4, transactionId);
					callableStatement.setString(5, null);
					callableStatement.setString(6, "INVOICEDETAILS");
					callableStatement.setString(7, "PAYMENT");
					callableStatement.registerOutParameter(8, Types.VARCHAR);
					callableStatement.executeUpdate();
					result = callableStatement.getString(8);

				} catch (SQLException e) {
					log.info("Error while closing connection "+e.getMessage());
				}
				finally{
					
						try {
							con.commit();
							if(callableStatement != null)
								callableStatement.close();
							if(con != null)
								con.close();
						} catch (SQLException e) {
							log.info("Error while closing connection "+e.getMessage());
						}
				}

			}
			

			log.info("END--in updateResonseCustomerBillingAccount() in ReversalDAOImpl result ---" + result + " transaction id --->"
					+ transactionId);
		 return result;
		}

	 // added for payment transfer payment posting PTSR
     public String updateResponsePaymentTransferPayment(String trackingId, String trackingServId, String faultDescription,
 			PostPaymentToFXRequest postPaymentToFXRequest, int jobId,String transferType,String tableName ) throws Exception {
    	 Connection con = null;
 		String result = EMPTY_STRING;
 		CallableStatement callableStatement = null;
 		
 		log.info("Payment_mode in AIRTL_PAYMENT_TRANSFER_PKG.UpdateFXPostingDetails proc for payment:::"+postPaymentToFXRequest.getPaymentMode());
 		log.info("transferType in AIRTL_PAYMENT_TRANSFER_PKG.UpdateFXPostingDetails proc for payment:::"+transferType);
 		
 		String procedureCall = "{call AIRTL_PAYMENT_TRANSFER_PKG.UpdateFXPostingDetails(?,?,?,?,?,?,?,?)}";

 		log.info("ESBWSResponse|" + jobId + "|" + postPaymentToFXRequest.getTransactionId() + "|"
 				+ tableName + "|exec UpdateFXPostingDetails('" + trackingId + "','" + trackingServId
 				+ "','" + faultDescription + "', '" + postPaymentToFXRequest.getTransactionId() + "', '"
 				+ postPaymentToFXRequest.getAcctExtId() + "' , '"
 				+ postPaymentToFXRequest.getRecordType() + "'," + jobId + ",:response)");

 		try {
 			con = ConnectionUtil.getConnection();
 			log.info("connection formed in updateResponseForPaymentPosting--------->" + con);

 		} catch (Exception e) {

 			log.info("Connection not established ", e);
 		}

 		if (con != null) {

 			try {
                   
 				if (!CommonUtil.isNotNull(trackingId)) {
 					trackingId = null;
 				}
 				if (!CommonUtil.isNotNull(trackingServId)) {
 					trackingServId = null;
 				}
 				if (!CommonUtil.isNotNull(faultDescription)) {
 					faultDescription = null;
 				}
 				if (!CommonUtil.isNotNull(postPaymentToFXRequest.getTransactionId())) {
 					postPaymentToFXRequest.setTransactionId(null);
 				}

 				callableStatement = con.prepareCall(procedureCall);
 				callableStatement.setString(1, trackingId);
 				callableStatement.setString(2, trackingServId);
 				callableStatement.setString(3, faultDescription);
 				callableStatement.setString(4, postPaymentToFXRequest.getTransactionId());
 				callableStatement.setString(5, postPaymentToFXRequest.getAcctExtId());
 				callableStatement.setString(6, "");
 				callableStatement.setString(7, transferType);
 				callableStatement.registerOutParameter(8, Types.VARCHAR);
 				callableStatement.executeUpdate();
 				result = callableStatement.getString(8);

 			} catch (SQLException e) {
 				log.info("Error occur in updateResponsePaymentTransferPayRev===>" +e.getMessage());
 			}
 			finally{
 				if(callableStatement != null)
 					callableStatement.close();
 				if(con != null)
 					con.close();
 			}

 		}

 		log.info("END--in updateResponsePaymentTransferPayRev in ReversalDAOImpl result ---" + result + " transaction id --->"
 				+ postPaymentToFXRequest.getTransactionId());
 		return result;
    	 
     }
  // added for payment transfer reversal PTSR  
     public String updateResponsePaymentTransferRev(String trackingId, String trackingServId, String faultDescription,
    		 PaymentReversalDetails paymentReversalDetails, int jobId,String fileIdentifier ,String transferType ) throws Exception {
    	 log.info("Start--in updateResponsePaymentTransferRev in ReversalDAOImpl result for transaction id --->"
 				+ paymentReversalDetails.getTransactionId());
 		
 		log.info("trackingId->"+trackingId+" trackingServId->"
 		+trackingServId+" faultDescription"+faultDescription+" paymentReversalDetails.getAcctExtId()-"+paymentReversalDetails.getAcctExtId());
 		Connection con = null;
 		String result = EMPTY_STRING;
 		CallableStatement callableStatement = null;
 		String paymentMode=EMPTY_STRING;
 		
 		 if("PTSRREV_315".equalsIgnoreCase(fileIdentifier)){
 			paymentMode="";
 			transferType=REV;
 		}
 		
 		log.info("Payment_mode in AIRTL_PAYMENT_TRANSFER_PKG.UpdateFXPostingDetails proc for payment transfer reversal:::"+paymentMode);
 		log.info("transferType in  AIRTL_PAYMENT_TRANSFER_PKG.UpdateFXPostingDetails proc for payment transfer reversal:::"+transferType);
 		String procedureCall = "{call AIRTL_PAYMENT_TRANSFER_PKG.UpdateFXPostingDetails(?,?,?,?,?,?,?,?)}";

 		log.info("ESBWSResponse|" + jobId + "|" + paymentReversalDetails.getTransactionId() + "|"
 				+ AIRTL_CUST_PAYMENT_DETAILS + "|exec AIRTL_PAYMENT_TRANSFER_PKG.UpdateFXPostingDetails('" + trackingId + "','" + trackingServId
 				+ "','" + faultDescription + "', '" + paymentReversalDetails.getTransactionId() + "', '"
 				+ paymentReversalDetails.getAcctExtId() + "', '" +paymentMode + "' , '"
 				+ transferType + "'," + jobId + ",:response)");

 		try {
 			con = ConnectionUtil.getConnection();
 			log.info("connection formed in updateResponsePaymentTransferRev--------->" + con);

 		} catch (Exception e) {

 			log.info("Connection not established ", e);
 		}

 		if (con != null) {

 			try {

 				if (!CommonUtil.isNotNull(trackingId)) {
 					trackingId = null;
 				}
 				if (!CommonUtil.isNotNull(trackingServId)) {
 					trackingServId = null;
 				}
 				if (!CommonUtil.isNotNull(faultDescription)) {
 					faultDescription = null;
 				}
 				if (!CommonUtil.isNotNull(paymentReversalDetails.getTransactionId())) {
 					paymentReversalDetails.setTransactionId(null);
 				}

 				callableStatement = con.prepareCall(procedureCall);
 				callableStatement.setString(1, trackingId);
 				callableStatement.setString(2, trackingServId);
 				//callableStatement.setString(3, "2502-F:no data record FDFDD ===");
 				callableStatement.setString(3, faultDescription);
 				callableStatement.setString(4, paymentReversalDetails.getTransactionId());
 				callableStatement.setString(5, paymentReversalDetails.getAcctExtId());
 				callableStatement.setString(6, "");
 				callableStatement.setString(7, transferType);
 				callableStatement.registerOutParameter(8, Types.VARCHAR);
 				callableStatement.executeUpdate();
 				result = callableStatement.getString(8);

 			} catch (SQLException e) {
 				log.error("Error occur in updateResponsePaymentTransferRev()", e);
 				e.printStackTrace();
 			}
 			finally{
 				con.commit();
 				if(callableStatement != null)
 					callableStatement.close();
 				if(con != null)
 					con.close();
 			}

 		}

 		log.info("END--in updateResponseInt in ReversalDAOImpl result ---" + result + " transaction id --->"
 				+ paymentReversalDetails.getTransactionId());
 		return result;
      }
}
