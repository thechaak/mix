package com.airtel.acecad.client.common.json;

import com.airtel.acecad.client.json.depositJson.DepositFault;
import com.airtel.acecad.client.json.depositRefundJson.DepositRefundFault;
import com.airtel.acecad.client.json.invoicePaymentJson.PostPaymentFault;
import com.airtel.acecad.client.json.nrcJson.CreateCustomerBilliableComponentFault;
import com.airtel.acecad.client.json.refundJson.RefundCreateFault;
import com.airtel.acecad.client.json.adjustmentJson.SyncBillingAdjustmentFault;
import com.airtel.acecad.client.json.custAccountSummaryJson.GetCustomerAccountSummaryFault;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY )
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DetailFault
{
	@JsonInclude(JsonInclude.Include.NON_NULL)
    private DepositFault updateCustomerDepositFault;

    public DepositFault getUpdateCustomerDepositFault ()
    {
        return updateCustomerDepositFault;
    }

    public void setUpdateCustomerDepositFault (DepositFault updateCustomerDepositFault)
    {
        this.updateCustomerDepositFault = updateCustomerDepositFault;
    }
    
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private PostPaymentFault updateInvoicePaymentFault;

    public PostPaymentFault getUpdateInvoicePaymentFault ()
    {
        return updateInvoicePaymentFault;
    }

    public void setUpdateInvoicePaymentFault (PostPaymentFault updateInvoicePaymentFault)
    {
        this.updateInvoicePaymentFault = updateInvoicePaymentFault;
    }
    
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private SyncBillingAdjustmentFault syncBillingAdjustmentFault;

    public SyncBillingAdjustmentFault getSyncBillingAdjustmentFault ()
    {
        return syncBillingAdjustmentFault;
    }

    public void setSyncBillingAdjustmentFault (SyncBillingAdjustmentFault syncBillingAdjustmentFault)
    {
        this.syncBillingAdjustmentFault = syncBillingAdjustmentFault;
    }

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private CreateCustomerBilliableComponentFault createCustomerBilliableComponentFault;

	public CreateCustomerBilliableComponentFault getCreateCustomerBilliableComponentFault() {
		return createCustomerBilliableComponentFault;
	}

	public void setCreateCustomerBilliableComponentFault(
			CreateCustomerBilliableComponentFault createCustomerBilliableComponentFault) {
		this.createCustomerBilliableComponentFault = createCustomerBilliableComponentFault;
	}

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private RefundCreateFault refundCreateFault;
	
	public RefundCreateFault getRefundCreateFault() {
		return refundCreateFault;
	}

	public void setRefundCreateFault(RefundCreateFault refundCreateFault) {
		this.refundCreateFault = refundCreateFault;
	}
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private DepositRefundFault depositRefundFault;

	
	public DepositRefundFault getDepositRefundFault() {
		return depositRefundFault;
	}

	public void setDepositRefundFault(DepositRefundFault depositRefundFault) {
		this.depositRefundFault = depositRefundFault;
	}

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private  GetCustomerAccountSummaryFault  getCustomerAccountSummaryFault;
	
	
	
    public GetCustomerAccountSummaryFault getGetCustomerAccountSummaryFault() {
		return getCustomerAccountSummaryFault;
	}

	public void setGetCustomerAccountSummaryFault(GetCustomerAccountSummaryFault getCustomerAccountSummaryFault) {
		this.getCustomerAccountSummaryFault = getCustomerAccountSummaryFault;
	}

	@Override
    public String toString()
    {
        return "{\"updateCustomerDepositFault\" : "+updateCustomerDepositFault+",\"updateInvoicePaymentFault\":"+updateInvoicePaymentFault+","
        		+ "\"syncBillingAdjustmentFault\":"+syncBillingAdjustmentFault+",\"createCustomerBilliableComponentFault\":"
				+ createCustomerBilliableComponentFault + ",\"refundCreateFault\" : " + depositRefundFault +",\"depositRefundFault\" : " + refundCreateFault +",\"getCustomerAccountSummaryFault\" : "+getCustomerAccountSummaryFault+"}";
    }
}