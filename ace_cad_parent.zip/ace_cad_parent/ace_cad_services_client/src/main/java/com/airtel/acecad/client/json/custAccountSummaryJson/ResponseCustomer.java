package com.airtel.acecad.client.json.custAccountSummaryJson;

public class ResponseCustomer {

	 private String customerType;

	    private String customerClass;

	    private String VIPFlag;

	    private CustCustomerAccount customerAccount;

	    public String getCustomerType ()
	    {
	        return customerType;
	    }

	    public void setCustomerType (String customerType)
	    {
	        this.customerType = customerType;
	    }

	    public String getCustomerClass ()
	    {
	        return customerClass;
	    }

	    public void setCustomerClass (String customerClass)
	    {
	        this.customerClass = customerClass;
	    }

	    public String getVIPFlag ()
	    {
	        return VIPFlag;
	    }

	    public void setVIPFlag (String VIPFlag)
	    {
	        this.VIPFlag = VIPFlag;
	    }

	    public CustCustomerAccount getCustomerAccount() {
			return customerAccount;
		}

		public void setCustomerAccount(CustCustomerAccount customerAccount) {
			this.customerAccount = customerAccount;
		}

		@Override
	    public String toString()
	    {
	        return "{\"customerType\" : \""+customerType+"\", \"customerClass\" : \""+customerClass+"\", \"VIPFlag\" : \""+VIPFlag+"\", \"customerAccount\" : "+customerAccount+"}";
	    }
}
