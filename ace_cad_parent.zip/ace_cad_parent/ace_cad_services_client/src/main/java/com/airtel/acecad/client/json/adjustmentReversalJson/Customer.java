package com.airtel.acecad.client.json.adjustmentReversalJson;

public class Customer {

	 private CustomerAccount customerAccount;

	    public CustomerAccount getCustomerAccount ()
	    {
	        return customerAccount;
	    }

	    public void setCustomerAccount (CustomerAccount customerAccount)
	    {
	        this.customerAccount = customerAccount;
	    }

	    @Override
	    public String toString()
	    {
	        return "{\"customerAccount\" : "+customerAccount+"}";
	    }
}
