package com.airtel.acecad.client.json.adjustmentJson;

public class CustomerBill {

	 private String billRefResets;

	    private CustomerBillIdentification identification;

	    public String getBillRefResets ()
	    {
	        return billRefResets;
	    }

	    public void setBillRefResets (String billRefResets)
	    {
	        this.billRefResets = billRefResets;
	    }

	    public CustomerBillIdentification getIdentification ()
	    {
	        return identification;
	    }

	    public void setIdentification (CustomerBillIdentification identification)
	    {
	        this.identification = identification;
	    }

	    @Override
	    public String toString()
	    {
	        return "{\"billRefResets\" : \""+billRefResets+"\", \"identification\" : "+identification+"}";
	    }
}
