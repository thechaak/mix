package com.airtel.acecad.client.json.CustomerAccountSummaryJson;

public class AccCustomerPayment {

	 private AccCustomerBill customerBill;

	    private PartyPayment partyPayment;

		public AccCustomerBill getCustomerBill() {
			return customerBill;
		}

		public void setCustomerBill(AccCustomerBill customerBill) {
			this.customerBill = customerBill;
		}

		public PartyPayment getPartyPayment ()
	    {
	        return partyPayment;
	    }

	    public void setPartyPayment (PartyPayment partyPayment)
	    {
	        this.partyPayment = partyPayment;
	    }

	    @Override
	    public String toString()
	    {
	        return "{\"customerBill\" : "+customerBill+", \"partyPayment\" : "+partyPayment+"}";
	    }
}
