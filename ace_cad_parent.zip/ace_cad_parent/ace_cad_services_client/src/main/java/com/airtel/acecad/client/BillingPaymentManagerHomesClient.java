package com.airtel.acecad.client;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.airtel.acecad.client.dao.ClientDAO;
import com.airtel.acecad.client.dao.ClientDAOImpl;
import com.airtel.acecad.client.dto.PaymentBreakupHomesDetails;
import com.airtel.acecad.client.dto.ResponsePojoForHomes;
import com.airtel.acecad.client.json.billingPaymentManagerHomes.BundledServices;
import com.airtel.acecad.client.json.billingPaymentManagerHomes.OriginalServiceDetails;
import com.airtel.acecad.client.json.billingPaymentManagerHomes.PaymentBreakup;
import com.airtel.acecad.client.json.billingPaymentManagerHomes.Plan;
import com.airtel.acecad.client.json.billingPaymentManagerHomes.RequestPojo;
import com.airtel.acecad.client.json.billingPaymentManagerHomes.ResponsePojo;
import com.airtel.acecad.client.json.billingPaymentManagerHomes.SiList;
import com.airtel.acecad.client.json.billingPaymentManagerHomes.Status;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.CustomResponseErrorHandler;
import com.airtel.acecad.client.util.GenericConfiguration;
import com.airtel.acecad.client.util.GlobalConstants;

//////////////////////////Homes_interface_2///////////////////////////////////////////////////
public class BillingPaymentManagerHomesClient implements GlobalConstants {

	private static Logger log = LogManager.getLogger("serviceClientUI");

	public String createRequestForBillingPaymentHomes(String homesId, String accountId, String lob,
			String derivedAmount, String transactionId, String msisdn, String fileIdentifier, String paymentDate,
			String homes_job_id, String aps_flag) throws Exception {

		// pass homes id from gethomesid interface and call when homesid is not
		// null
		log.info(
				"START--->in createRequestForBillingPaymentHomes method of BillingPaymentManagerHomesClient and account_no--->>"
						+ accountId + " for transactionId-->>" + transactionId);

		String result = EMPTY_STRING;
		// String payment_date=EMPTY_STRING;
		String tableName = EMPTY_STRING;
		String trim_transactionId = EMPTY_STRING;
		String request_lob=EMPTY_STRING;

		BillingPaymentManagerHomesClient billingPaymentManagerHomesClient = new BillingPaymentManagerHomesClient();
		List<PaymentBreakupHomesDetails> paymentBreakupHomesDetailsList = new ArrayList<PaymentBreakupHomesDetails>();
		ClientDAO clientDAO = new ClientDAOImpl();
		/*
		 * String tableName=clientDAO.fetchTableName(fileIdentifier);
		 * 
		 * paymentBreakupHomesDetailsList=clientDAO.fetchHomesBillingPayment(
		 * accountId); for (int i = 0; i <
		 * paymentBreakupHomesDetailsList.size(); i++) {
		 * 
		 * PaymentBreakupHomesDetails paymentBreakupDetails = new
		 * PaymentBreakupHomesDetails(); paymentBreakupDetails =
		 * paymentBreakupHomesDetailsList.get(i);
		 */

		RequestPojo requestPojo = new RequestPojo();

		requestPojo.setHomesId(homesId);

		OriginalServiceDetails originalServiceDetails = new OriginalServiceDetails();

		if ("MOB".equalsIgnoreCase(lob)) {
			request_lob = "Mobility";
			originalServiceDetails.setLob(request_lob);
		}else if("BTS".equalsIgnoreCase(lob)){
			request_lob = "Telemedia";
			originalServiceDetails.setLob(request_lob);
		}else{
			originalServiceDetails.setLob(lob);
		}
		
		originalServiceDetails.setAccountId(accountId);
		originalServiceDetails.setRtn(msisdn);

		List<SiList> siList = new ArrayList<>();
		for (int j = 0; j < 1; j++) {
			SiList siList2 = new SiList();

			if (j == 0) {

				if (CommonUtil.isNotNull(msisdn)) {
					// siList2.setId("9205122733");
					siList2.setId(msisdn);
					siList2.setType("primary");
					siList2.setSubLob("mobility");
				} else {
					siList2.setId(null);
					siList2.setType(null);
					siList2.setSubLob(null);
				}
			}

			siList.add(siList2);
		}

		originalServiceDetails.setSiList(siList);
		requestPojo.setOriginalServiceDetails(originalServiceDetails);
		// NA for APS
		// requestPojo.setOnBoardingDate("04/01/2017");

		//String consumerTransactionId = APS + CommonUtil.randomMethod();
		requestPojo.setConsumerTransactionId(transactionId);
		// requestPojo.setConsumerTransactionId("TEST89895643rfdjduhf4f6e722");

		requestPojo.setConsumerName(APS);

		// date format in request 28/01/2018

		/*
		 * SimpleDateFormat format1 = new
		 * SimpleDateFormat("yyyy-mm-dd hh:mm:ss"); SimpleDateFormat format2 =
		 * new SimpleDateFormat("dd/MM/yyyy"); String date = paymentDate; try {
		 * Date dateNew = format1.parse(date); payment_date =
		 * format2.format(dateNew); System.out.println(payment_date); } catch
		 * (ParseException e) { e.printStackTrace(); }
		 */

		// requestPojo.setPaymentDate(paymentBreakupDetails.getPaymentDate());

		requestPojo.setPaymentDate(paymentDate);
		log.info("payment_date in createRequestForBillingPaymentHomes--->>" + requestPojo.getPaymentDate()
				+ " for transactionId-->>" + transactionId);

		requestPojo.setAmountPaid(derivedAmount);

		if (fileIdentifier != null && fileIdentifier.contains("CHQ")) {
			// if("CHQ".equalsIgnoreCase(fileIdentifier))
			requestPojo.setPaymentMode("CHEQUE");
			tableName = "CHEQUE_VENDOR_FILES_RECORDS";
		} else if (fileIdentifier != null && fileIdentifier.contains("EFT")) {
			requestPojo.setPaymentMode("EFT");
			tableName = "NEFT_VENDOR_FILES_RECORDS";
		} else if (fileIdentifier != null && fileIdentifier.contains("MISC")) {
			requestPojo.setPaymentMode("MISC");
			tableName = "MISC_VENDOR_FILES_RECORDS";
		}else if (fileIdentifier != null && fileIdentifier.contains("REV")) {
			requestPojo.setPaymentMode("REVERSAL");
			tableName = "REVERSAL_VENDOR_FILES_RECORDS";
		}else if(fileIdentifier != null && fileIdentifier.contains("PTFAPPHOMES")){
			requestPojo.setPaymentMode("APP");
			tableName = "PT_VENDOR_FILES_RECORDS";
		}
		else if(fileIdentifier != null && fileIdentifier.contains("PTFREVHOMES")){
			requestPojo.setPaymentMode("REV");
			tableName = "PT_VENDOR_FILES_RECORDS";
		}
		else if(fileIdentifier != null && fileIdentifier.contains("PTBULKAPPHOMES")){
			requestPojo.setPaymentMode("APP");
			tableName = "PT_VENDOR_FILES_RECORDS";
		}
		else if(fileIdentifier != null && fileIdentifier.contains("PTBULKREVHOMES")){
			requestPojo.setPaymentMode("REV");
			tableName = "PT_VENDOR_FILES_RECORDS";
		}
		else if(fileIdentifier != null && fileIdentifier.contains("PTF")){
			requestPojo.setPaymentMode("APP");
			tableName = "PT_VENDOR_FILES_RECORDS";
		}
		
		log.info("requestpojo in createRequestForBillingPaymentHomes--->>" + requestPojo + " for transactionId-->>"
				+ transactionId);

		trim_transactionId = transactionId.substring(3);
		log.info("transaction_id createRequestForBillingPaymentHomes---->>> " + transactionId + " and table name---->>>"
				+ tableName);
		Object[] resultobj = clientDAO.updateJobId(tableName, Integer.parseInt(trim_transactionId), homes_job_id, 0);
		log.info("After hitting the posting fx job_id jobId in createRequestForBillingPaymentHomes result is:"
				+ resultobj[0] + "and job id is" + resultobj[1] + " and TransactionId " + transactionId);

		if (RESULT_DB_SUCCESFUL.equalsIgnoreCase((String) resultobj[0])) {
			log.info(
					"Before calling postPaymentToFX method from createRequestForBillingPaymentHomes for transactionId-->>"
							+ transactionId);
			// result = invoicePaymentDetailsClient.postPaymentToFX(requestPojo,
			// postPaymentToFXRequest,(int)resultobj[1]);

			result = billingPaymentManagerHomesClient.postbillingPaymentManagerHomes(requestPojo, accountId, lob,
					homes_job_id, transactionId, fileIdentifier, derivedAmount, aps_flag, homesId,tableName);

			log.info("Result in createRequestForBillingPaymentHomes--->>" + result + "for transactionId-->>"
					+ transactionId);
		}

		log.info(
				"END--->in createRequestForBillingPaymentHomes method of BillingPaymentManagerHomesClient and account_no--->>"
						+ accountId + " for transactionId-->>" + transactionId);
		return result;

	}

	/*
	 * public static void main(String[] args) throws Exception {
	 * 
	 * BillingPaymentManagerHomesClient billingPaymentManagerHomesClient=new
	 * BillingPaymentManagerHomesClient();
	 * billingPaymentManagerHomesClient.createRequestForBillingPaymentHomes(
	 * "919160099966","CHQ");
	 * 
	 * }
	 */

	public String postbillingPaymentManagerHomes(RequestPojo requestPojo, String accountId, String lob,
			String homes_job_id, String transactionId, String fileIdentifier, String derivedAmount, String aps_flag,
			String homesId,String tableName) {
		log.info(
				"START--->in postbillingPaymentManagerHomes method of BillingPaymentManagerHomesClient and account_no--->>"
						+ accountId + " for transactionId-->>" + transactionId);

		String result = EMPTY_STRING;

		BillingPaymentManagerHomesClient bill = new BillingPaymentManagerHomesClient();

		String clientURL = GenericConfiguration.getDescription("kenon.postBillingPaymentHomes");
		log.info("clientURL in postbillingPaymentManagerHomes -->" + clientURL + " and transactionId : " + transactionId);

		RestTemplate restTemplate = new RestTemplate();

		restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());

		((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
				.setConnectTimeout(Integer.parseInt(GenericConfiguration.getDescription("connect_time_out")));// 60000=

		((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
				.setReadTimeout(Integer.parseInt(GenericConfiguration.getDescription("read_time_out")));

		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
		restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
		restTemplate.setErrorHandler(new CustomResponseErrorHandler());

		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		HttpEntity<RequestPojo> entity = new HttpEntity<RequestPojo>(requestPojo, headers);
		ResponseEntity<ResponsePojo> responsePojo = null;

		try {
			responsePojo = restTemplate.exchange(clientURL, HttpMethod.POST, entity, ResponsePojo.class);
			log.info("responsePojo in postbillingPaymentManagerHomes in BillingPaymentManagerHomesClient--->"
					+ responsePojo + " for transactionId-->>" + transactionId);

			if (responsePojo != null) {

				if (HttpStatus.OK == responsePojo.getStatusCode()) {

					if (responsePojo.getBody().getHomesId() != null) {
						String homedId = responsePojo.getBody().getHomesId();
					}
				}

				result = bill.createResponseForBillingPaymentManagerHomes(responsePojo.getBody(), accountId, lob,
						homes_job_id, transactionId, fileIdentifier, derivedAmount, aps_flag, homesId,tableName);
				log.info("result in postbillingPaymentManagerHomes in BillingPaymentManagerHomesClient--->" + result
						+ " for transactionId-->>" + transactionId);

			}
		} catch (Exception e) {
			log.info("Got faulty code from the response of FX postbillingPaymentManagerHomes", e);
		}
		log.info(
				"END--->in postbillingPaymentManagerHomes method of BillingPaymentManagerHomesClient for transactionId-->>"
						+ transactionId);
		return result;

	}

	public String createResponseForBillingPaymentManagerHomes(ResponsePojo responsePojo, String accountId, String lob,
			String homes_job_id, String transactionId, String fileIdentifier, String derivedAmount, String aps_flag,
			String homesId,String tableName) throws Exception {

		log.info(
				"START--->in createResponseForBillingPaymentManagerHomes method of BillingPaymentManagerHomesClient for transactionId-->>"
						+ transactionId);

		String result = EMPTY_STRING;
		//String total_payment_amount =EMPTY_STRING;
		double total_payment_amount =0.0;
		log.info("derived_amount before converting into double--->>"+derivedAmount);
		double derived_amount1=Double.valueOf(derivedAmount);
		String payment_amount=EMPTY_STRING;
		String status_description = EMPTY_STRING;
		String concatenated_amount = EMPTY_STRING;
		String backendErrorCode = EMPTY_STRING;
		ClientDAO clientDAO = new ClientDAOImpl();

		/*if ("MOB".equalsIgnoreCase(lob))
			lob = "Mobility";*/

		List<ResponsePojoForHomes> responsePojoList = new ArrayList<ResponsePojoForHomes>();
		ResponsePojoForHomes responsePojoForHomes = null;
		if (responsePojo != null) {
			if (CommonUtil.isNotNull(responsePojo.getHomesId())) {

				responsePojo.getHomesId();
				log.info("Homes Id in -->> " + responsePojo.getHomesId() + " for transactionId-->>" + transactionId);

				if (CommonUtil.isNotNull(responsePojo.getPaymentDate()))
					responsePojo.getPaymentDate();

				log.info("responsePojo.getPaymentDate() in -->> " + responsePojo.getPaymentDate());

				if (CommonUtil.isNotNull(responsePojo.getAmountPaid()))
					responsePojo.getAmountPaid();

				log.info("responsePojo.getAmountPaid() in -->> " + responsePojo.getAmountPaid());

				if (CommonUtil.isNotNull(responsePojo.getPostingDate()))
					responsePojo.getPostingDate();

				log.info("responsePojo.getPostingDate() in -->> " + responsePojo.getPostingDate());

				BundledServices[] bundledServices = new BundledServices[responsePojo.getBundledServices().length];

				bundledServices = responsePojo.getBundledServices();

				log.info("bundledServices.length-->> " + bundledServices.length + " for transactionId-->>"
						+ transactionId);

				if (bundledServices.length > 0) {

					/*----------------Start for loop---------------*/
					for (int i = 0; i < bundledServices.length; i++) {
						responsePojoForHomes = new ResponsePojoForHomes();
						log.info("bundledServices.length22-->> " + bundledServices.length);

						bundledServices[i].getLob();
						//log.info("bundledServices[i].getLob() in -->> " + bundledServices[i].getLob());
						responsePojoForHomes.setLob(bundledServices[i].getLob());
						log.info("bundledServices[i].getLob() in createResponseForBillingPaymentManagerHomes-->>"
								+ responsePojoForHomes.getLob() + " for transactionId-->>" + transactionId);

						bundledServices[i].getSublob();
						//log.info("bundledServices[i].getSublob() in -->> " + bundledServices[i].getSublob());

						SiList[] siList = new SiList[bundledServices[i].getSiList().length];

						siList = bundledServices[i].getSiList();
						if (siList.length > 0) {

							for (int j = 0; j < siList.length; j++) {

								siList[j].getId();

								siList[j].getType();
								siList[j].getSubLob();
							}
						}

						//log.info("bundledServices[i].getSiList() in -->> " + bundledServices[i].getSiList());

						Plan plan = new Plan();
						plan = bundledServices[i].getPlan();

						if (plan != null) {

							plan.getServicePlanName();
							plan.getServicePlanId();
							plan.getServicePlanType();
							plan.getCityName();
							plan.getCircleId();
							plan.getCircleName();
							plan.getPinCode();
							plan.getRenewalDate();
							plan.getCost();
						}

						bundledServices[i].getAccountId();
						log.info("bundledServices[i].getAccountId() in -->> " + bundledServices[i].getAccountId());

						responsePojoForHomes.setAccountNo(bundledServices[i].getAccountId());

						bundledServices[i].getRtn();
						//log.info("bundledServices[i].getRtn() in -->> " + bundledServices[i].getRtn());
						bundledServices[i].getPaymentStatus();
					/*	log.info("bundledServices[i].getPaymentStatus() in -->> "
								+ bundledServices[i].getPaymentStatus());*/
						bundledServices[i].getPaymentAmount();
					/*	log.info("bundledServices[i].getPaymentAmount() in -->> "
								+ bundledServices[i].getPaymentAmount());*/

							responsePojoForHomes
								.setPaymentAmount(Double.parseDouble(bundledServices[i].getPaymentAmount()));
						// sum
						total_payment_amount =total_payment_amount+ Double.valueOf(bundledServices[i].getPaymentAmount());
						
						log.info("total payment--->>>" + total_payment_amount + " for transactionId-->>"
								+ transactionId);

						concatenated_amount += bundledServices[i].getPaymentAmount() + "-";

						bundledServices[i].getBillingAmount();

						log.info("bundledServices[i].getBillingAmount() in -->> "
								+ bundledServices[i].getBillingAmount());

						PaymentBreakup paymentBreakup = new PaymentBreakup();

						paymentBreakup = bundledServices[i].getPaymentBreakup();

						if (paymentBreakup != null) {

							paymentBreakup.getPreviousAdjustments();
						/*	log.info("paymentBreakup.getPreviousAdjustments() in -->> "
									+ paymentBreakup.getPreviousAdjustments());*/
							paymentBreakup.getCurrentAmount();
						//	log.info("paymentBreakup.getCurrentAmount() in -->> " + paymentBreakup.getCurrentAmount());
							paymentBreakup.getExcessAmount();
						//	log.info("paymentBreakup.getExcessAmount() in -->> " + paymentBreakup.getExcessAmount());
						}

						responsePojoList.add(responsePojoForHomes);
					}
					/*----------------end for loop---------------*/
					log.info("concatenated_amount--->>" + concatenated_amount + " for transactionId-->>"
							+ transactionId);
				}

				Status status = new Status();
				status = responsePojo.getStatus();

				if (status != null) {
					if (CommonUtil.isNotNull(status.getStatusCode()))
						status.getStatusCode();
					log.info("status.getStatusCode() in -->> " + status.getStatusCode() + " for transactionId-->>"
							+ transactionId);

					if (CommonUtil.isNotNull(status.getStatusDescription()))
						status_description = status.getStatusDescription();
					log.info("status.getStatusDescription() in -->> " + status.getStatusDescription()
							+ " for transactionId-->>" + transactionId);

					if (CommonUtil.isNotNull(status.getBackendErrorCode()))
						status.getBackendErrorCode();
					log.info("status.getBackendErrorCode() in -->> " + status.getBackendErrorCode()
							+ " for transactionId-->>" + transactionId);
				}

				DecimalFormat decimalFormat = new DecimalFormat("0.00");
				payment_amount=decimalFormat.format(total_payment_amount);
				
				log.info("After rounding off total payment amount--->>"+payment_amount);
				log.info("Before matching total payment amount--->>"+Double.valueOf(payment_amount)+"and derived amount--->>>"+derived_amount1);
				if (derived_amount1==Double.valueOf(payment_amount))
				//if (total_payment_amount.equalsIgnoreCase(derivedAmount))
					status_description = status_description + ":VALID AMOUNT";
				else
					status_description = status_description + ":INVALID AMOUNT-" + concatenated_amount;
				log.info("status_description--->in createResponseForBillingPaymentManagerHomes : " + status_description
						+ " for transactionId-->>" + transactionId);

				log.info("homeslist(responsePojoList) size before calling update proc--->>" + responsePojoList.size());

				String acctlob_flag = EMPTY_STRING;
				for (int p = 0; p < responsePojoList.size(); p++) {

					log.info("account_no in responsePojoList before calling update proc--->>"
							+ responsePojoList.get(p).getAccountNo());
					
					if("Telemedia".equalsIgnoreCase(responsePojoList.get(p).getLob())){
						responsePojoList.get(p).setLob("BTS");
					}
					else if("Mobility".equalsIgnoreCase(responsePojoList.get(p).getLob())){
						responsePojoList.get(p).setLob("MOB");
					}

					if (accountId.equalsIgnoreCase(responsePojoList.get(p).getAccountNo())
							&& lob.equalsIgnoreCase(responsePojoList.get(p).getLob())) {
						acctlob_flag = TRUE;
					}
					log.info("lob in responsePojoList before calling update proc--->>"
							+ responsePojoList.get(p).getLob());
					
					
					log.info("amount in responsePojoList before calling update proc--->>"
							+ responsePojoList.get(p).getPaymentAmount());
				}

			if(!acctlob_flag.equalsIgnoreCase("true")){
					acctlob_flag="ACCOUNT AND LOB MISMATCH";
				}
				
				if ("ACCOUNT AND LOB MISMATCH".equalsIgnoreCase(acctlob_flag))
					status_description = acctlob_flag;

				log.info("status_description before calling update proc--->>" + status_description);
				log.info("transactionId before calling update proc--->>" + transactionId);
				log.info("accountId before calling update proc--->>" + accountId);
				log.info("lob before calling update proc--->>" + lob);
				log.info("aps_flag before calling update proc--->>" + aps_flag);
				log.info("homesId before calling update proc--->>" + homesId);

				if(fileIdentifier.equalsIgnoreCase("PTFAPPHOMES") || fileIdentifier.equalsIgnoreCase("PTBULKAPPHOMES")){
					log.info("if file_identifier is PTFAPPHOMES OR PTBULKAPPHOMES::::::::::");
					result =clientDAO.updateResponseForPTSRAPPHomes(responsePojoList, status_description, transactionId, accountId, lob, aps_flag, homesId,tableName);
				}
				else if(fileIdentifier.equalsIgnoreCase("PTFREVHOMES")|| fileIdentifier.equalsIgnoreCase("PTBULKREVHOMES")){
					log.info("if file_identifier is PTFREVHOMES OR PTBULKREVHOMES::::::::::");
					result =clientDAO.updateResponseForPTSRRevHomes(status_description,transactionId,tableName);
				}
				
				else if(fileIdentifier.contains("REV")){
					log.info("if file_identifier is REV::::::::::");
					result=clientDAO.updateResponseForRevHomes(status_description,transactionId,tableName);
				}
				else{
					log.info("if file_identifier is not REV::::::::::");
				result = clientDAO.updateResponseForPaymentBreakupFetch(responsePojoList, status_description,
						transactionId, accountId, lob, aps_flag, homesId);
				log.info(
						"result--->in createResponseForBillingPaymentManagerHomes method of BillingPaymentManagerHomesClient-->"
							+ result + " for transactionId-->>" + transactionId);
				}

			} else {
				log.info("If failure and 400 status code ");
				Status status = new Status();
				status = responsePojo.getStatus();

				if (status != null) {

					if (CommonUtil.isNotNull(status.getStatusCode()))
						status.getStatusCode();
					log.info("status.getStatusCode() in -->> " + status.getStatusCode() + " for transactionId-->>"
							+ transactionId);

					if (CommonUtil.isNotNull(status.getStatusDescription()))
						status_description = status.getStatusDescription();
					log.info("status.getStatusDescription() in -->> " + status.getStatusDescription()
							+ " for transactionId-->>" + transactionId);

					if (CommonUtil.isNotNull(status.getBackendErrorCode()))
						backendErrorCode = status.getBackendErrorCode();
					log.info("status.getBackendErrorCode() in -->> " + status.getBackendErrorCode()
							+ " for transactionId-->>" + transactionId);
				}

				log.info(
						"Failure before calling proc in createResponseForBillingPaymentManagerHomes in BillingPaymentManagerHomesClient for transactionId-->>"
								+ transactionId);
				result = clientDAO.updateFailureResponseFromHomes(status_description, transactionId, backendErrorCode,
						aps_flag);
				log.info(
						"Failure after calling proc in createResponseForBillingPaymentManagerHomes in BillingPaymentManagerHomesClient result->>"
								+ result + "for transction_id-->>" + transactionId);
			}
		} else {
			log.info(
					"in fault in createResponseForBillingPaymentManagerHomes in BillingPaymentManagerHomesClient for transactionId-->>"
							+ transactionId);
		}

		log.info(
				"END--->in createResponseForBillingPaymentManagerHomes method of BillingPaymentManagerHomesClient for transactionId-->>"
						+ transactionId);

		return result;

	}
	
}
