package com.airtel.acecad.client.json.createUpdateNotesJson;

public class ResponseDataArea {

	private SyncCustomerInteractionResponse syncCustomerInteractionResponse;

    public SyncCustomerInteractionResponse getSyncCustomerInteractionResponse ()
    {
        return syncCustomerInteractionResponse;
    }

    public void setSyncCustomerInteractionResponse (SyncCustomerInteractionResponse syncCustomerInteractionResponse)
    {
        this.syncCustomerInteractionResponse = syncCustomerInteractionResponse;
    }

	    @Override
	    public String toString()
	    {
	        return "{\"syncCustomerInteractionResponse\" : "+syncCustomerInteractionResponse+"}";
	    }
}
