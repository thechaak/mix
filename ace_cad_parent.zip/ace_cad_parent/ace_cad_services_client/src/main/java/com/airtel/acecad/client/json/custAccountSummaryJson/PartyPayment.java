package com.airtel.acecad.client.json.custAccountSummaryJson;

public class PartyPayment {

	private String paymentDate;

    private String mode;

    public String getPaymentDate ()
    {
        return paymentDate;
    }

    public void setPaymentDate (String paymentDate)
    {
        this.paymentDate = paymentDate;
    }

    public String getMode ()
    {
        return mode;
    }

    public void setMode (String mode)
    {
        this.mode = mode;
    }

    @Override
    public String toString()
    {
        return "{\"paymentDate\" : \""+paymentDate+"\", \"mode\" : \""+mode+"\"}";
    }
}
