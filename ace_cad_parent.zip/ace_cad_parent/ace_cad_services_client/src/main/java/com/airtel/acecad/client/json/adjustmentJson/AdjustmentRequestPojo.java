package com.airtel.acecad.client.json.adjustmentJson;

public class AdjustmentRequestPojo {

	 private SyncBillingAdjustmentReqMsg syncBillingAdjustmentReqMsg;

	    public SyncBillingAdjustmentReqMsg getSyncBillingAdjustmentReqMsg ()
	    {
	        return syncBillingAdjustmentReqMsg;
	    }

	    public void setSyncBillingAdjustmentReqMsg (SyncBillingAdjustmentReqMsg syncBillingAdjustmentReqMsg)
	    {
	        this.syncBillingAdjustmentReqMsg = syncBillingAdjustmentReqMsg;
	    }

	    @Override
	    public String toString()
	    {
	        return "{\"syncBillingAdjustmentReqMsg\" : "+syncBillingAdjustmentReqMsg+"}";
	    }
}
