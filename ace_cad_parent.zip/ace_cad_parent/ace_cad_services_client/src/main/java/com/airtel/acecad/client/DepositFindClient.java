package com.airtel.acecad.client;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.airtel.acecad.client.dao.ClientDAO;
import com.airtel.acecad.client.dao.ClientDAOImpl;
import com.airtel.acecad.client.dto.DepositDetails;
import com.airtel.acecad.client.dto.DepositFindDto;
import com.airtel.acecad.client.json.depositFind.Deposit;
import com.airtel.acecad.client.json.depositFind.DepositFindResponse;
import com.airtel.acecad.client.json.depositFind.GetDepositDetailsResponse;
import com.airtel.acecad.client.json.depositFind.SoaFault;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.CustomResponseErrorHandler;
import com.airtel.acecad.client.util.EncryDecrypUtility;
import com.airtel.acecad.client.util.GenericConfiguration;
import com.airtel.acecad.client.util.GlobalConstants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class DepositFindClient implements GlobalConstants{
	private static final Logger log = LogManager.getLogger("serviceClientUI");
	private static final ObjectMapper mapper= new ObjectMapper();
	
	public DepositFindDto  postToFXDepositFind(DepositDetails depositDetails){
		
		SoaFault fault = null;
		String result = EMPTY_STRING;
		String status_code = EMPTY_STRING;
		String exceptionMessage=null;
		boolean exceFlag=false;
		DepositFindDto resultData = new DepositFindDto();
		
		String fromDate="1990-01-01T23:59:59";
		String toDate ="";
		
		Date d= new  Date();
		Calendar c = Calendar.getInstance(); 
		c.setTime(d); 
		c.add(Calendar.DATE, 1);
		d = c.getTime();
		toDate= new SimpleDateFormat("yyyy-MM-dd").format(d);
		toDate+="T23:59:59";
		try {

			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			String clientURL ="";
			if((depositDetails.getAccountExternalId()!=null && !depositDetails.getAccountExternalId().equals("")) 
					&&(depositDetails.getMobileNo()!=null && !depositDetails.getMobileNo().equals(""))){
				clientURL = GenericConfiguration.getDescription("kenon.postDepositFindV5.url")
						+"domain=B2C&lob="+depositDetails.getLob()+"&subLob=Postpaid&consumerTransactionId=12312412423435e3243&consumerName=APS"
						+"&programmeName=EAIMigration&customerMigrated="+depositDetails.getIsMigrated()
						+"&paymentFromDate="+fromDate+"&paymentToDate="+toDate
						+ "&customeraccount="+depositDetails.getAccountExternalId()+"&type=MSISDN&msisdn="+depositDetails.getMobileNo();
				}
			 
			 if(depositDetails.getAccountExternalId()!=null && !depositDetails.getAccountExternalId().equals("")){
				clientURL = GenericConfiguration.getDescription("kenon.postDepositFindV5.url")
					+"domain=B2C&lob="+depositDetails.getLob()+"&subLob=Postpaid&consumerTransactionId=12312412423435e3243&consumerName=APS"
					+"&programmeName=EAIMigration&customerMigrated="+depositDetails.getIsMigrated()
					+"&paymentFromDate="+fromDate+"&paymentToDate="+toDate
					+ "&customeraccount="+depositDetails.getAccountExternalId()+"&type=MSISDN";
			}
			else if(depositDetails.getMobileNo()!=null && !depositDetails.getMobileNo().equals("")){
				clientURL = GenericConfiguration.getDescription("kenon.postDepositFindV5.url")
					+"domain=B2C&lob="+depositDetails.getLob()+"&subLob=Postpaid&consumerTransactionId=12312412423435e3243&consumerName=APS"
					+"&programmeName=EAIMigration&customerMigrated="+depositDetails.getIsMigrated()
					+"&paymentFromDate="+fromDate+"&paymentToDate="+toDate
					+ "&customeraccount=&type=MSISDN&msisdn="+depositDetails.getMobileNo();
			}
			log.info("clientURL in postToFXDepositFind  Deposit Find-->> "+clientURL);

			String userpass = GenericConfiguration.getDescription("kenon.postPaymentToFX.userName") + ":"
					+ EncryDecrypUtility.decrypt(GenericConfiguration.getDescription("kenon.postPaymentToFX.password"));


			headers.add("Authorization", "Basic " + Base64.encodeBase64String(userpass.getBytes()));
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);

			restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
		
	
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
					.setConnectTimeout(Integer.parseInt(GenericConfiguration.getDescription("connect_time_out")));
	
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
					.setReadTimeout(Integer.parseInt(GenericConfiguration.getDescription("read_time_out")));
	
			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
			restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
			restTemplate.setErrorHandler(new CustomResponseErrorHandler());
	
			
	
			HttpEntity<String> entity = new HttpEntity<>(headers);
			ResponseEntity<DepositFindResponse> responsePojo = null;
			responsePojo = restTemplate.exchange(clientURL, HttpMethod.GET, entity, DepositFindResponse.class);
			log.info("response  For Payment Find INT 219---" + mapper.writeValueAsString(responsePojo));
	
			if(responsePojo != null){

				if (HttpStatus.OK ==responsePojo.getStatusCode()) {
					if(responsePojo.getBody().getEbmHeader()!=null && responsePojo.getBody().getDataArea()!=null)
					{
						status_code = responsePojo.getStatusCode().toString();
						log.info("success --DepositFind Details---EBMHeader>>"+ mapper.writeValueAsString(responsePojo.getBody().getEbmHeader()));
						log.info("success --DepositFind Details---Data Area>>"+ mapper.writeValueAsString(responsePojo.getBody().getDataArea()));
					} else{
						status_code = responsePojo.getStatusCode().toString();
						System.out.println("status_code-->> "+status_code);
						fault = responsePojo.getBody().getSoaFault();
						log.info("DepositFind Details in DepositFind Details in http code is not 200-->>" + fault);
					}
				}
				else {

					status_code = responsePojo.getStatusCode().toString();
					System.out.println("status_code-->> "+status_code);
					fault = responsePojo.getBody().getSoaFault();
					log.info("paymentHistoryResponsePojo in updatePaymentHistoryDetails-->>" + fault);

				}
				log.info("Before updatePaymentHistoryDetails in PaymentHistoryDetailsClient ");
				
				resultData = createResponseJSONForFetchDepositFind(responsePojo, fault,
						status_code,clientURL,depositDetails);
				log.info("After updatePaymentHistoryDetails in PaymentHistoryDetailsClient result-->>"+resultData);

			}
			else{
				log.info("IN method  updatePaymentHistoryDetails response pojo is null" );
			}
		} catch (Exception e) {
			log.info("Got exception while processing Deposit Find ",e);
			log.info("Exception message for Deposit find==>"+e.getCause());
			
		}
		
		log.info("END----in updatePaymentHistoryDetails method of PaymentHistoryDetailsClient");
		

		return resultData;
	}

	private DepositFindDto createResponseJSONForFetchDepositFind(
			ResponseEntity<DepositFindResponse> responsePojo, SoaFault fault, String status_code, String clientURL,DepositDetails depositDetails) {
		List<DepositDetails> depositDetailsList = new ArrayList<>();
		DepositFindDto depositDto = new DepositFindDto();
		ClientDAO dao = new ClientDAOImpl();
		if(responsePojo!=null){
			if(responsePojo.getBody().getEbmHeader()!= null && responsePojo.getBody().getDataArea()!=null){
			log.info("in response create ebmheader data==>"+responsePojo.getBody().getEbmHeader().getConsumerTransactionId());	
				
			if(responsePojo.getBody().getDataArea().getGetDepositDetailsResponse()!=null){
				GetDepositDetailsResponse depositResponse=responsePojo.getBody().getDataArea().getGetDepositDetailsResponse();
				if(depositResponse.getDeposit()!=null){
					List<Deposit> depositList = depositResponse.getDeposit();
					for(Deposit deposit : depositList){
						DepositDetails depositData = new DepositDetails();
						if(deposit.getPartyPayment()!=null){
							if(CommonUtil.isNotNull(deposit.getPartyPayment().getAmount())){
								log.info("Payment in Deposit Find response==>"+
										deposit.getPartyPayment().getAmount());
								depositData.setAmount(deposit.getPartyPayment().getAmount());
							}
							
							if(CommonUtil.isNotNull(deposit.getPartyPayment().getPaymentDate())){
								log.info("Payment date in Deposit Find response==>"+
										deposit.getPartyPayment().getPaymentDate());
								depositData.setToDate(deposit.getPartyPayment().getPaymentDate());
								
							}
							
							if(CommonUtil.isNotNull(deposit.getPartyPayment().getPaymentDirection())){
								log.info("Payment Direction in Deposit Find response==>"+
										deposit.getPartyPayment().getPaymentDirection());
								 
								depositData.setDepositType(dao.getDepositTypeValue(deposit.getPartyPayment().getPaymentDirection()));
								//depositData.setDepositType(deposit.getPartyPayment().getPaymentDirection());
							}
							if(CommonUtil.isNotNull(deposit.getPartyPayment().getPostDate())){
								log.info("Post DAte in Deposit Find response==>"+
										deposit.getPartyPayment().getPostDate());
								depositData.setDateReceived(deposit.getPartyPayment().getPostDate());
							}
							
							if(CommonUtil.isNotNull(deposit.getPartyPayment().getPaymentMethod())){
								depositData.setModeOfPayment(deposit.getPartyPayment().getPaymentMethod());
								log.info("PaymentMethod in Deposit Find response==>"+
										deposit.getPartyPayment().getPaymentMethod());
								depositData.setModeOfPayment(deposit.getPartyPayment().getPaymentMethod());
							}
						}
						
						if(deposit.getTrackingRecord()!=null){
							if(deposit.getTrackingRecord().getIdentification()!=null){
								if(CommonUtil.isNotNull(deposit.getTrackingRecord().getIdentification().getId())){
									log.info("Tracking Id in Deposit Find response==>"+
											deposit.getTrackingRecord().getIdentification().getId());
									depositData.setTrackingId(Integer.parseInt(deposit.getTrackingRecord().getIdentification().getId()));
								}
							}
							if(CommonUtil.isNotNull(deposit.getTrackingRecord().getSystemId())){
								log.info("TrackingIdServ in Deposit Find response==>"+
										deposit.getTrackingRecord().getSystemId());
								depositData.setTrackinIdServ(Integer.parseInt(deposit.getTrackingRecord().getSystemId()));
								
							}
							
						}
						
						depositDetailsList.add(depositData);
					}
					depositDto.setDataList(depositDetailsList);
					depositDto.setDepositFindStatus("SUCCESS");
				}
			}
			}
			else if(responsePojo.getBody().getSoaFault()!=null){
				depositDto.setDepositFindStatus("FAILED");
				SoaFault soaFault=responsePojo.getBody().getSoaFault();
				log.info("createResponseForFX method  when ebmHeader is null from resonse===");
				String[] soaFaultCodeArray= null;
				String statusCode="";
				String fault_value="";
				if(CommonUtil.isNotNull( soaFault.getSoaFaultCode())){
					soaFaultCodeArray = soaFault.getSoaFaultCode().split("-");
				if(soaFaultCodeArray!=null)
				   statusCode = soaFaultCodeArray[1] + "-" + soaFaultCodeArray[2];
				}
				if(CommonUtil.isNotNull(soaFault.getFaultDescription())){
				   fault_value = soaFault.getFaultDescription();
				if (fault_value.length() > 999)
					fault_value = fault_value.substring(0, 1000);
				}

				String faultDescription ="Error->"+statusCode + " QI:" + fault_value;
				faultDescription= faultDescription.replace("'", "");
				log.info("Status description is in createResponseJSONForPaymentFind when error response from webservice---> " + faultDescription);
			
			}
			String status = responsePojo.getStatusCode().equals("200")? "SUCCESS" : "FAILED" ;
			String trxnID= (depositDetails.getAccountExternalId()!=null && depositDetails.getAccountExternalId().equalsIgnoreCase("")) ? depositDetails.getAccountExternalId() : depositDetails.getMobileNo();
			String apsFlag = (depositDetails.getIsMigrated()!=null && depositDetails.getIsMigrated().equalsIgnoreCase("") &&depositDetails.getIsMigrated().equalsIgnoreCase("true")) ? "APS" : "Legacy";
			try {
				dao.insertFxLog(status, trxnID, clientURL, mapper.writeValueAsString(responsePojo), depositDetails.getLob(), apsFlag, "219_B", null, null, null, null);
			} catch (JsonProcessingException e) {
				log.error("Exception in Deposit FindClient 219_B=="+e.getLocalizedMessage());
				e.printStackTrace();
			}
			
		}
		
		return depositDto;
	}
	
	
	public static void main(String[] args) {
		DepositDetails dd = new DepositDetails();
		dd.setAccountExternalId("1294327470");
		dd.setMobileNo("9998965343");
		new DepositFindClient().postToFXDepositFind(dd);
	}
}
