package com.airtel.acecad.client.dao;

import java.beans.Statement;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.airtel.acecad.client.dto.BulkDetails;
import com.airtel.acecad.client.dto.PostPaymentToFXRequest;
import com.airtel.acecad.client.util.AdviceDetails;
import com.airtel.acecad.client.util.CommonUtil;
import com.airtel.acecad.client.util.ConnectionUtil;
import com.airtel.acecad.client.util.GlobalConstants;

import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;

public class PaymentPostDaoImpl implements PaymentPostDao, GlobalConstants {

	private static Logger log = LogManager.getLogger("serviceClientUI");
	@Override
	public List<BulkDetails> getCustomerAccountsForFileId(String accountNo, String mobNo, String payment_mode,
			String transferType) throws Exception {

		log.info("Start:: getCustomerAccountsForFileId in PaymentPostDaoImpl");
		String procedureCall = "{call CUST_DUMMY_ACCOUNTS_PROC_APS(?,?,?,?,?,?,?)}";
		Connection con = null;
		ResultSet resultCustomerAccounts = null;
		CallableStatement callableStatement = null;
		List<BulkDetails> customerAccountsList = new ArrayList<BulkDetails>();

		if (STR_CHEQUE.equalsIgnoreCase(transferType) || STR_OTHERS.equalsIgnoreCase(transferType)) {
			transferType = PAYMENT;
		}
		/*
		 * if(STR_NEFT.equalsIgnoreCase(transferType)){
		 * 
		 * }
		 */

		try {
			con = ConnectionUtil.getConnection();
		} catch (Exception e) {
			log.info("In getCustomerAccountsForFileId connection not made", e);
		}
		if (con != null) {
			callableStatement = con.prepareCall(procedureCall);
			callableStatement.setString(1, accountNo);
			log.info("accountNo getCustomerAccountsForFileId--" + accountNo);
			// callableStatement.setString(2, null);
			callableStatement.setString(2, mobNo);
			log.info("mobNo getCustomerAccountsForFileId--" + mobNo);
			callableStatement.setString(3, payment_mode);
			log.info("paymentCode getCustomerAccountsForFileId--" + payment_mode);
			callableStatement.setString(4, transferType);
			log.info("transferType getCustomerAccountsForFileId--" + transferType);
			callableStatement.registerOutParameter(5, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(6, Types.VARCHAR);
			callableStatement.registerOutParameter(7, Types.VARCHAR);
			callableStatement.executeUpdate();
			resultCustomerAccounts = (ResultSet) callableStatement.getObject(5);
			try {
				if (resultCustomerAccounts != null) {
					while (resultCustomerAccounts.next()) {
						BulkDetails bulkDetailsObj = new BulkDetails();
						bulkDetailsObj.setAcctEXTID(resultCustomerAccounts.getString("ACCT_EXT_ID"));
						bulkDetailsObj.setAmountInr(resultCustomerAccounts.getString("AMOUNT_IN_INR"));
						bulkDetailsObj
								.setBankVirtualAcctNo(resultCustomerAccounts.getString("CUSTOMER_BANK_ACCOUNT_NO"));// checkwith
																													// ritu
						bulkDetailsObj.setChangeDate(resultCustomerAccounts.getString("CHANGE_DATE"));
						bulkDetailsObj.setChangeWho(resultCustomerAccounts.getString("CHANGE_WHO"));
						bulkDetailsObj.setChequeDate(resultCustomerAccounts.getString("CHEQUE_DATE"));
						bulkDetailsObj.setCircle(resultCustomerAccounts.getString("CIRCLE"));
						bulkDetailsObj.setCustomerName(resultCustomerAccounts.getString("RECEIVER_NAME"));
						bulkDetailsObj.setCustomerType(resultCustomerAccounts.getString("CUSTOMER_TYPE"));
						bulkDetailsObj.setDelNO(resultCustomerAccounts.getString("DEL_NO"));
						if (!payment_mode.equalsIgnoreCase("NEFT")) {
							bulkDetailsObj.setIfscCode(resultCustomerAccounts.getString("IFSC_CODE"));
						}
						bulkDetailsObj.setErrorReasonCode(resultCustomerAccounts.getString("ERROR_REASON_CODE"));
						bulkDetailsObj.setFileID(resultCustomerAccounts.getString("FILE_ID"));
						bulkDetailsObj.setTransferType(resultCustomerAccounts.getString("TRANSFER_TYPE"));
						if (!payment_mode.equalsIgnoreCase("NEFT") && !STAGING.equalsIgnoreCase(payment_mode)) {
							bulkDetailsObj.setsNo(resultCustomerAccounts.getString("S_NO"));
						}

						bulkDetailsObj.setIncomingTransactionNo(
								resultCustomerAccounts.getString("INCOMING_TRANSACTION_REF_NO"));
						bulkDetailsObj.setInvoiceNo(resultCustomerAccounts.getString("INVOICE_NO"));
						log.info("invoice no from EPP records-->>"+bulkDetailsObj.getInvoiceNo()+"for accountNo-->>"+ accountNo);
						if (!payment_mode.equalsIgnoreCase("NEFT")) {
							bulkDetailsObj.setOrderNo(resultCustomerAccounts.getString("ORDER_NUMBER"));
						}

						bulkDetailsObj.setPaymentAmt(resultCustomerAccounts.getString("PAYMENT_AMOUNT"));
						bulkDetailsObj.setPaymentDate(resultCustomerAccounts.getString("PAYMENT_RECEIVED_DATE"));// add
																													// in
																													// proc
																													// PAYMENT_RECEIVED_DATE

						bulkDetailsObj.setPaymentDetails1(resultCustomerAccounts.getString("PAYMENT_DETAILS_1"));
						bulkDetailsObj.setPaymentDetails2(resultCustomerAccounts.getString("PAYMENT_DETAILS_2"));
						bulkDetailsObj.setPaymentDetails3(resultCustomerAccounts.getString("PAYMENT_DETAILS_3"));
						bulkDetailsObj.setPaymentMode(resultCustomerAccounts.getString("PAYMENT_MODE"));
						bulkDetailsObj.setProductType(resultCustomerAccounts.getString("PRODUCT_TYPE"));
						bulkDetailsObj.setReceiverIfsc(resultCustomerAccounts.getString("RECEIVER_IFSC"));
						bulkDetailsObj.setPaymentCurrency(resultCustomerAccounts.getString("PAYMENT_CURRENCY"));
						bulkDetailsObj.setReceivingRbI1(resultCustomerAccounts.getString("RECEIVING_ACC_RBI1"));
						bulkDetailsObj.setChequeNo(resultCustomerAccounts.getString("REF_NUMBER"));
						bulkDetailsObj.setRefNo(resultCustomerAccounts.getString("REF_NO"));
						bulkDetailsObj.setRemitterAccNo(resultCustomerAccounts.getString("REMITTER_AC_NO"));
						bulkDetailsObj.setRemitterBranch(resultCustomerAccounts.getString("REMITTER_BRANCH"));
						bulkDetailsObj.setRemitterIfsc(resultCustomerAccounts.getString("REMITTER_IFSC"));
						if (payment_mode.equalsIgnoreCase("NEFT")) {
							bulkDetailsObj.setTransDate(resultCustomerAccounts.getString("INSERT_DATE"));
							bulkDetailsObj.setTransactionId("TRANSACTION_ID");
						}
						if (!payment_mode.equalsIgnoreCase("NEFT")) {
							bulkDetailsObj.setTransDate(resultCustomerAccounts.getString("TRANS_DATE"));
							bulkDetailsObj
									.setVendorTransactID(resultCustomerAccounts.getString("VENDOR_TRANSACTION_ID"));
							bulkDetailsObj.setSourceID(resultCustomerAccounts.getString("SOURCE_ID"));
						}

						bulkDetailsObj.setErrorCode(resultCustomerAccounts.getString("ERROR_REASON_CODE"));
						bulkDetailsObj.setDummyAccntNo(resultCustomerAccounts.getString("DUMMY_ACCT_NO"));
						bulkDetailsObj.setAccountType(resultCustomerAccounts.getString("ACCOUNT_TYPE"));
						bulkDetailsObj.setServiceType(resultCustomerAccounts.getString("FX_DUMMY_ACCT_LOB"));
						bulkDetailsObj.setLegalEntity(resultCustomerAccounts.getString("FX_DUMMY_LEGAL_ENTITY"));
						bulkDetailsObj.setValueType(resultCustomerAccounts.getString("FX_DUMMY_VALUE_TYPE"));
						bulkDetailsObj.setVipFlag(resultCustomerAccounts.getString("FX_DUMMY_VIP_FLAG"));
						bulkDetailsObj.setCustomerType(resultCustomerAccounts.getString("FX_DUMMY_CUSTOMER_TYPE"));
						bulkDetailsObj.setCustomerClass(resultCustomerAccounts.getString("FX_DUMMY_CUSTOMER_CLASS"));
						bulkDetailsObj.setB2b2c(resultCustomerAccounts.getString("DERIVED_SEGMENT_B2B_B2C"));
						bulkDetailsObj.setPaymentCode(resultCustomerAccounts.getString("DERIVED_PAYMENT_CODE"));
						bulkDetailsObj.setVendorTransactID(resultCustomerAccounts.getString("VENDOR_USER_ID"));
						/*
						 * // COMMENT WHEN GOING IN PROD
						 */
						// bulkDetailsObj.setVendorTransactID(userId);
						log.info("VENDOR_USER_ID---" + resultCustomerAccounts.getString("VENDOR_USER_ID"));
						bulkDetailsObj.setFxAcctNo(resultCustomerAccounts.getString("FX_ACCOUNT_NO"));
						bulkDetailsObj.setVendorId(resultCustomerAccounts.getString("VENDOR_ID"));
						// bulkDetailsObj.setSessionId(resultCustomerAccounts.getString("SESSION_ID"));
						// bulkDetailsObj.setUserId(resultCustomerAccounts.getString("USER_ID"));
						bulkDetailsObj.setRemarks(resultCustomerAccounts.getString("REMARKS"));
						// bulkDetailsObj.setTransferType(resultCustomerAccounts.getString("TRANSFER_TYPE"));
						bulkDetailsObj.setRecordId(resultCustomerAccounts.getString("RECORD_ID"));
						log.info("RECORD_ID getCustomerAccountsForFileId--------------->"
								+ bulkDetailsObj.getRecordId());
						bulkDetailsObj.setAnnotation(resultCustomerAccounts.getString("ANNOTATION"));
						bulkDetailsObj.setCustomerCurrency(resultCustomerAccounts.getString("FX_CUSTOMER_CURRENCY"));
						bulkDetailsObj.setExchangeRate(resultCustomerAccounts.getString("EXCHANGE_RATE"));
						bulkDetailsObj.setOrigTrackingId(resultCustomerAccounts.getString("ORIG_TRACKING_ID"));
						bulkDetailsObj.setOrigTrackingServId(resultCustomerAccounts.getString("ORIG_TRACKING_ID_SERV"));
						bulkDetailsObj.setCollectionManager(resultCustomerAccounts.getString("COL_MANAGER_NAME"));
						bulkDetailsObj.setTicketNo(resultCustomerAccounts.getString("TICKET_NO"));
						bulkDetailsObj.setFxTransferStatus(resultCustomerAccounts.getString("FX_TRANSFER_STATUS"));
						bulkDetailsObj.setRecordType(resultCustomerAccounts.getString("RECORD_TYPE"));
						bulkDetailsObj.setBillRefResets(resultCustomerAccounts.getString("BILL_REF_RESESTS"));
						bulkDetailsObj.setApsFlag(resultCustomerAccounts.getString("APS_FLAG"));
						if (!payment_mode.equalsIgnoreCase("NEFT")) {
							bulkDetailsObj.setSrNumber(resultCustomerAccounts.getString("SR_NUMBER"));
						}
						bulkDetailsObj.setMktCode(resultCustomerAccounts.getString("MKT_CODE"));
						bulkDetailsObj.setErrorInt623(resultCustomerAccounts.getString("INT_632_ERROR"));
						customerAccountsList.add(bulkDetailsObj);

					}
				}
			} catch (Exception e) {
				log.info("Exception while fetchinf from result set", e);

			} finally {

				if (con != null){
					try {
						con.close();
						resultCustomerAccounts.close();
						callableStatement.close();
					} catch (Exception e) {
						log.info("Exception in the getCustomerAccountsForFileId", e);
					}
				}
			}
		}

		log.info("End:: getCustomerAccountsForFileId in PaymentPostDaoImpl");
		return customerAccountsList;
	}

	

	public List<BulkDetails> getCustomerAccountsForAdvice(String accountNo) throws Exception {

		PreparedStatement preparedStatement = null;

		log.info("Start:: getCustomerAccountsForFileId in PaymentPostDaoImpl");
		String sql = "SELECT ACCT_EXT_ID, ACCOUNT_TYPE,DERIVED_SEGMENT_B2B_B2C,"
				+ "RECORD_ID,APS_FLAG FROM ADVICE_VENDOR_FILES_RECORDS "
				+ "WHERE STATUS_CODE=1 AND APS_FLAG IN ('APS','CAD') AND "
				+ "RECORD_TYPE='PAYMENT' AND INT_STATUS = 'INT 219 PASSED' AND ACCT_EXT_ID=+'" + accountNo + "'";
		Connection con = null;
		List<BulkDetails> customerAccountsList = new ArrayList<BulkDetails>();

	

		try {
			con = ConnectionUtil.getConnection();
		} catch (Exception e) {
			log.info("In getCustomerAccountsForFileId connection not made", e);
		}
		if (con != null) {
			preparedStatement = con.prepareStatement(sql);
			ResultSet resultSet = preparedStatement.executeQuery();
		
			try {
				if (resultSet != null) {
					while (resultSet.next()) {
						BulkDetails bulkDetailsObj = new BulkDetails();
						bulkDetailsObj.setAcctEXTID(resultSet.getString(1));
						bulkDetailsObj.setAccountType(resultSet.getString(2));
						bulkDetailsObj.setB2b2c(resultSet.getString(3));
						bulkDetailsObj.setTransactionId(resultSet.getString(4));
						bulkDetailsObj.setApsFlag(resultSet.getString(5));
						customerAccountsList.add(bulkDetailsObj);

					}
				}
			} catch (Exception e) {
				log.info("Exception while fetchinf from result set", e);

			} finally {

				if (con != null){
					try {
						con.close();
						preparedStatement.close();
					} catch (Exception e) {
						log.info("Exception in the getCustomerAccountsForFileId", e);
					}
				}
			}
		}

		log.info("End:: getCustomerAccountsForFileId in PaymentPostDaoImpl");
		return customerAccountsList;
	}

	
	
	
	@Override
	public List<BulkDetails> getApprovalFileIds() throws Exception {

		log.info("Start :getApprovalFileIds in PaymentPostDaoImpl ");

		List<BulkDetails> bulkResult = new ArrayList<BulkDetails>();
		String procedureCall = "{call APPROVAL_FILE_IDS_APS(?)}";
		CallableStatement callableStatement = null;
		Connection con = null;

		try {
			con = ConnectionUtil.getConnection();
			log.info("Connection formed ---" + con);
			// con.setAutoCommit(false);
		} catch (Exception e) {
			log.info("In getApprovalFileIds connection not made", e);
		}
		if (con != null) {
			callableStatement = con.prepareCall(procedureCall);
			callableStatement.registerOutParameter(1, OracleTypes.CURSOR);
			callableStatement.executeUpdate();
			ResultSet resultSet = (ResultSet) callableStatement.getObject(1);
			try {

				while (resultSet.next()) {
					BulkDetails bulkDetails = new BulkDetails();
					bulkDetails.setFileID(resultSet.getString("FILE_ID"));
					bulkDetails.setUserId(resultSet.getString("VENDOR_USERID"));
					bulkResult.add(bulkDetails);
				}
				log.info("payment list size" + bulkResult.size());
			} catch (Exception e) {
				log.info("Error in the resultset of getApprovalId", e);
			} finally {
				if (con != null){
					try {
						callableStatement.close();
						resultSet.close();
						con.close();
					} catch (Exception e) {
						log.info("Exception in the getApprovalFileIds", e);
					}
				}
				
				log.info(" SQL Exception occured while closing result set object of payment details ");
			}
		}
		log.info("End :getApprovalFileIds in PaymentPostDaoImpl ");
		return bulkResult;
	}

	public String liuProc(List<BulkDetails> customerAccountsRecords, String paymentMode, String apsFlag,
			String SRNumber) throws Exception {

		log.info("Start :liuProc in PaymentPostDaoImpl ");

		Connection con = null;
		// String procedureCall = "{call PAYMENT_LIU_POSTING_APS(?,?,?,?,?,?)}";
		String procedureCall = "{call PAYMENT_LIU_POSTING_APS(?,?,?,?,?,?)}";
		// String procedureCall = "{call
		// PAYMENT_LIU_POSTING_APS_1(?,?,?,?,?,?)}";
		String errorCode = EMPTY_STRING;
		String errorMsg = EMPTY_STRING;
		CallableStatement callableStatement = null;

		try {
			con = ConnectionUtil.getConnection();
			log.info("Connection formed liuProc ---" + con);
			// con.setAutoCommit(false);
		} catch (Exception e) {
			log.info("In getCustomerAccountsForFileId connection not made", e);
		}
		if (con != null) {
			try {
				log.info("Formation of Structure in LIUPRAOC METHOD");
				StructDescriptor structDescriptor = StructDescriptor.createDescriptor("PAYMENT_POSTING_OBJ", con);
				STRUCT[] structs = new STRUCT[customerAccountsRecords.size()];
				for (int index = 0; index < customerAccountsRecords.size(); index++) {
					BulkDetails bulkDetailsObj = customerAccountsRecords.get(index);

					// Object[] params = new Object[64];
					Object[] params = new Object[66];

					params[0] = bulkDetailsObj.getAcctEXTID();
					params[1] = bulkDetailsObj.getAmountInr();
					params[2] = bulkDetailsObj.getBankVirtualAcctNo();
					params[3] = bulkDetailsObj.getChangeDate();
					params[4] = bulkDetailsObj.getChangeWho();
					params[5] = bulkDetailsObj.getChequeDate();
					params[6] = bulkDetailsObj.getCircle();
					params[7] = bulkDetailsObj.getCustomerName();
					params[8] = bulkDetailsObj.getCustomerType();
					params[9] = bulkDetailsObj.getDelNO();
					params[10] = bulkDetailsObj.getErrorCode();
					params[11] = bulkDetailsObj.getFileID();
					params[12] = bulkDetailsObj.getsNo();
					params[13] = bulkDetailsObj.getIncomingTransactionNo();
					params[14] = bulkDetailsObj.getInvoiceNo();
					params[15] = bulkDetailsObj.getOrderNo();
					params[16] = bulkDetailsObj.getPaymentAmt();
					params[17] = bulkDetailsObj.getPaymentDate();
					params[18] = bulkDetailsObj.getPaymentDetails1();
					params[19] = bulkDetailsObj.getPaymentDetails2();
					params[20] = bulkDetailsObj.getPaymentDetails3();
					params[21] = bulkDetailsObj.getPaymentMode();
					params[22] = bulkDetailsObj.getProductType();
					params[23] = bulkDetailsObj.getReceiverIfsc();
					params[24] = bulkDetailsObj.getReceivingRbI1();
					params[25] = bulkDetailsObj.getRefNo();
					params[26] = bulkDetailsObj.getChequeNo();
					params[27] = bulkDetailsObj.getRemitterAccNo();
					params[28] = bulkDetailsObj.getRemitterBranch();
					params[29] = bulkDetailsObj.getRemitterIfsc();
					params[30] = bulkDetailsObj.getSourceID();
					params[31] = bulkDetailsObj.getTransDate();
					params[32] = bulkDetailsObj.getVendorTransactID();
					params[33] = bulkDetailsObj.getPaymentCurrency();
					params[34] = bulkDetailsObj.getExchangeRate();
					params[35] = bulkDetailsObj.getDummyAccntNo();
					params[36] = bulkDetailsObj.getAccountType();
					params[37] = bulkDetailsObj.getServiceType();
					params[38] = bulkDetailsObj.getLegalEntity();
					params[39] = bulkDetailsObj.getValueType();
					params[40] = bulkDetailsObj.getVipFlag();
					params[41] = bulkDetailsObj.getCustomerType();
					params[42] = bulkDetailsObj.getCustomerClass();
					params[43] = bulkDetailsObj.getB2b2c();
					params[44] = bulkDetailsObj.getPaymentCode();
					params[45] = bulkDetailsObj.getFxAcctNo();
					params[46] = bulkDetailsObj.getCustomerCurrency();
					params[47] = bulkDetailsObj.getVendorTransactID();
					params[48] = bulkDetailsObj.getVendorId();
					params[49] = bulkDetailsObj.getSessionId();
					params[50] = bulkDetailsObj.getUserId();
					params[51] = bulkDetailsObj.getRemarks();
					params[52] = bulkDetailsObj.getRecordId();
					params[53] = bulkDetailsObj.getTransferType();
					if (bulkDetailsObj.getPaymentMode().equalsIgnoreCase("PT")) {
						params[54] = bulkDetailsObj.getOrigTrackingId();
						params[55] = bulkDetailsObj.getOrigTrackingServId();
					} else {
						params[54] = bulkDetailsObj.getTrackingId();
						params[55] = bulkDetailsObj.getTrackingIdServ();
					}

					params[56] = bulkDetailsObj.getCollectionManager();
					params[57] = bulkDetailsObj.getTicketNo();
					params[58] = bulkDetailsObj.getFxStatus();
					params[59] = bulkDetailsObj.getTransferType();
					params[60] = bulkDetailsObj.getOrigBillRefResets();
					params[61] = bulkDetailsObj.getAnnotation();
					params[62] = bulkDetailsObj.getBillCompany();
					params[63] = bulkDetailsObj.getMktCode();

					params[64] = bulkDetailsObj.getRemitterName();
					params[65] = bulkDetailsObj.getReceiverName();
					STRUCT struct = new STRUCT(structDescriptor, con, params);
					structs[index] = struct;
				}
				log.info("length of struct in liu proc method" + structs.length);
				ArrayDescriptor desc = ArrayDescriptor.createDescriptor("PAYMENT_POSTING_TYPE", con);
				ARRAY oracleArray = new ARRAY(desc, con, structs);

				callableStatement = con.prepareCall(procedureCall);
				callableStatement.setArray(1, oracleArray);
				callableStatement.setString(2, paymentMode);
				log.info("paymentMode in liue proc--" + paymentMode);
				callableStatement.setString(3, apsFlag);
				log.info("apsFlag in liu proc--" + apsFlag);
				callableStatement.setString(4, SRNumber);
				log.info("srNumber in liu proc--" + SRNumber);
				// callableStatement.registerOutParameter(4, Types.VARCHAR);
				// callableStatement.registerOutParameter(5, Types.VARCHAR);
				callableStatement.registerOutParameter(5, Types.VARCHAR);
				callableStatement.registerOutParameter(6, Types.VARCHAR);
				callableStatement.executeUpdate();
				// errorCode = callableStatement.getString(4);
				// errorMsg = callableStatement.getString(5);
				errorCode = callableStatement.getString(5);
				errorMsg = callableStatement.getString(6);
				log.info("errorCod in liu proc----" + errorCode);
				log.info("errorMsg in liu proc----" + errorMsg);

				log.info("End :liuProc in PaymentPostDaoImpl ");

			} catch (Exception e) {
				// TODO: handle exception
			} finally {
				if (con != null){
					try {
						callableStatement.close();
						con.close();
					} catch (Exception e) {
						log.info("Exception in the liuCal", e);
					}
				}
				
			}

		}
		log.info("End :liuCal in PaymentPostDaoImpl ");
		return errorMsg;

	}

	public String paymentCodeCal(List<BulkDetails> customerAccountsRecords, String paymentMode, String apsFlag,
			String SRnumber) throws Exception {

		log.info("Start :paymentCodeCal in PaymentPostDaoImpl ");

		Connection con = null;
		// String procedureCall = "{call
		// PAY_CODE_CAL_TARANSFER_APS(?,?,?,?,?)}";
		// ADDED SR_NUMBER
		String procedureCall = "{call PAY_CODE_CAL_TARANSFER_APS(?,?,?,?,?,?)}";
		// String procedureCall = "{call
		// PAY_CODE_CAL_TARANSFER_APS_1(?,?,?,?,?,?)}";

		String errorCode = EMPTY_STRING;
		String errorMsg = EMPTY_STRING;
		CallableStatement callableStatement = null;

		try {
			con = ConnectionUtil.getConnection();
			log.info("Connection formed in paymentCodeCal" + con);
			// con.setAutoCommit(false);
		} catch (Exception e) {
			log.info("In getCustomerAccountsForFileId connection not made", e);
		}
		if (con != null) {
			String param_variables = "";
			try {
				log.info("Formation of Structure in paymentCodeCal METHOD");
				StructDescriptor structDescriptor = StructDescriptor.createDescriptor("PAYMENT_POSTING_OBJ", con);
				STRUCT[] structs = new STRUCT[customerAccountsRecords.size()];
				for (int index = 0; index < customerAccountsRecords.size(); index++) {
					BulkDetails bulkDetailsObj = customerAccountsRecords.get(index);

					// Object[] params = new Object[64];
					Object[] params = new Object[66];
					params[0] = bulkDetailsObj.getAcctEXTID();
					params[1] = bulkDetailsObj.getAmountInr();
					params[2] = bulkDetailsObj.getBankVirtualAcctNo();
					params[3] = bulkDetailsObj.getChangeDate();
					params[4] = bulkDetailsObj.getChangeWho();
					params[5] = bulkDetailsObj.getChequeDate();
					params[6] = bulkDetailsObj.getCircle();
					params[7] = bulkDetailsObj.getCustomerName();
					params[8] = bulkDetailsObj.getCustomerType();
					params[9] = bulkDetailsObj.getDelNO();
					params[10] = bulkDetailsObj.getErrorCode();
					params[11] = bulkDetailsObj.getFileID();
					params[12] = bulkDetailsObj.getsNo();
					params[13] = bulkDetailsObj.getIncomingTransactionNo();
					params[14] = bulkDetailsObj.getInvoiceNo();
					log.info(" bulkDetailsObj.getInvoiceNo()--" + bulkDetailsObj.getInvoiceNo());
					params[15] = bulkDetailsObj.getOrderNo();
					params[16] = bulkDetailsObj.getPaymentAmt();
					params[17] = bulkDetailsObj.getPaymentDate();
					params[18] = bulkDetailsObj.getPaymentDetails1();
					params[19] = bulkDetailsObj.getPaymentDetails2();
					params[20] = bulkDetailsObj.getPaymentDetails3();
					params[21] = bulkDetailsObj.getPaymentMode();
					params[22] = bulkDetailsObj.getProductType();
					params[23] = bulkDetailsObj.getReceiverIfsc();
					params[24] = bulkDetailsObj.getReceivingRbI1();
					params[25] = bulkDetailsObj.getRefNo();
					params[26] = bulkDetailsObj.getChequeNo();
					params[27] = bulkDetailsObj.getRemitterAccNo();
					params[28] = bulkDetailsObj.getRemitterBranch();
					params[29] = bulkDetailsObj.getRemitterIfsc();
					params[30] = bulkDetailsObj.getSourceID();
					params[31] = bulkDetailsObj.getTransDate();
					params[32] = bulkDetailsObj.getVendorTransactID();
					params[33] = bulkDetailsObj.getPaymentCurrency();
					params[34] = bulkDetailsObj.getExchangeRate();
					params[35] = bulkDetailsObj.getDummyAccntNo();
					params[36] = bulkDetailsObj.getAccountType();
					params[37] = bulkDetailsObj.getServiceType();
					params[38] = bulkDetailsObj.getLegalEntity();
					params[39] = bulkDetailsObj.getValueType();
					params[40] = bulkDetailsObj.getVipFlag();
					params[41] = bulkDetailsObj.getCustomerType();
					params[42] = bulkDetailsObj.getCustomerClass();
					params[43] = bulkDetailsObj.getB2b2c();
					params[44] = bulkDetailsObj.getPaymentCode();
					params[45] = bulkDetailsObj.getFxAcctNo();
					params[46] = bulkDetailsObj.getCustomerCurrency();
					params[47] = bulkDetailsObj.getVendorTransactID();
					params[48] = bulkDetailsObj.getVendorId();
					params[49] = bulkDetailsObj.getSessionId();
					params[50] = bulkDetailsObj.getUserId();
					params[51] = bulkDetailsObj.getRemarks();
					params[52] = bulkDetailsObj.getRecordId();
					params[53] = bulkDetailsObj.getTransferType();
					if (CommonUtil.isNotNull(bulkDetailsObj.getTrackingId())) {
						params[54] = bulkDetailsObj.getTrackingId();
					} else {
						params[54] = bulkDetailsObj.getOrigTrackingId();
					}
					if (CommonUtil.isNotNull(bulkDetailsObj.getTrackingIdServ())) {
						params[55] = bulkDetailsObj.getTrackingIdServ();
					} else {
						params[55] = bulkDetailsObj.getOrigTrackingServId();
					}

					params[56] = bulkDetailsObj.getCollectionManager();
					params[57] = bulkDetailsObj.getTicketNo();
					params[58] = bulkDetailsObj.getFxStatus();
					params[59] = bulkDetailsObj.getTransferType();
					params[60] = bulkDetailsObj.getOrigBillRefResets();
					params[61] = bulkDetailsObj.getAnnotation();
					params[62] = bulkDetailsObj.getBillCompany();
					params[63] = (bulkDetailsObj.getMktCode());
					if (bulkDetailsObj.getRemitterName() != null && !bulkDetailsObj.getRemitterName().isEmpty())
						params[64] = bulkDetailsObj.getRemitterName();
					else
						params[64] = null;
					if (bulkDetailsObj.getReceiverName() != null && !bulkDetailsObj.getReceiverName().isEmpty())
						params[65] = bulkDetailsObj.getReceiverName();
					else
						params[65] = null;

					STRUCT struct = new STRUCT(structDescriptor, con, params);
					// structs[index] = struct;
					structs[index] = struct;
					System.out.println(" structs[index]---" + structs[index]);
					for (int i = 0; i < 65; i++)
						param_variables = param_variables + params[i] + "!";
				}
				log.info("param_variables of struct in paymentCodeCal-->" + param_variables);
				log.info("length of struct in paymentCodeCal-->" + structs.length);
				ArrayDescriptor desc = ArrayDescriptor.createDescriptor("PAYMENT_POSTING_TYPE", con);
				ARRAY oracleArray = new ARRAY(desc, con, structs);

				callableStatement = con.prepareCall(procedureCall);
				callableStatement.setArray(1, oracleArray);
				callableStatement.setString(2, paymentMode);
				log.info("paymentMode in paymentCodeCal--" + paymentMode);
				callableStatement.setString(3, apsFlag);
				log.info("apsFlag in paymentCodeCal--" + apsFlag);
				callableStatement.setString(4, SRnumber);
				log.info("srNumber in paymentCodeCal--" + SRnumber);
				callableStatement.registerOutParameter(5, Types.VARCHAR);
				callableStatement.registerOutParameter(6, Types.VARCHAR);
				// callableStatement.registerOutParameter(4, Types.VARCHAR);
				// callableStatement.registerOutParameter(5, Types.VARCHAR);
				callableStatement.executeUpdate();
				// errorCode = callableStatement.getString(4);
				// log.info("OutPut from paymentCodeCal in PaymentPostDaoImpl
				// errorCode--- " + errorCode);
				// errorMsg = callableStatement.getString(5);
				errorCode = callableStatement.getString(5);
				log.info("OutPut from paymentCodeCal in PaymentPostDaoImpl errorCode--- " + errorCode);
				errorMsg = callableStatement.getString(6);
				log.info("OutPut from paymentCodeCal in PaymentPostDaoImpl errorMsg--- " + errorMsg);
				log.info("End :paymentCodeCal in PaymentPostDaoImpl ");

			} catch (Exception e) {
				log.info("Exception in paymentCodeCal", e);
			} finally {
				if (con != null){
					try {
						callableStatement.close();
						con.close();
					} catch (Exception e) {
						log.info("Exception in the paymentCodeCal", e);
					}
				}
				
			}

		}
		log.info("End :paymentCodeCal in PaymentPostDaoImpl ");
		return errorMsg;

	}

	public String calculateB2BB2C(List<BulkDetails> customerAccountsRecords, String paymentMode, String apsFlag,
			String SRNumber) throws Exception {

		log.info("Start :calculateB2BB2C in PaymentPostDaoImpl ");

		Connection con = null;
		// String procedureCall = "{call B2B_B2C_SEG_PROC_APS(?,?,?,?,?)}";
		// ADDED FOR SR_NUMBER
		String procedureCall = "{call B2B_B2C_SEG_PROC_APS(?,?,?,?,?,?)}";
		// String procedureCall = "{call B2B_B2C_SEG_PROC_APS_1(?,?,?,?,?,?)}";
		String errorCode = EMPTY_STRING;
		String errorMsg = EMPTY_STRING;
		CallableStatement callableStatement = null;

		try {
			con = ConnectionUtil.getConnection();
			// con.setAutoCommit(false);
		} catch (Exception e) {
			log.info("In getCustomerAccountsForFileId connection not made", e);
		}
		if (con != null) {
			try {
				log.info("Formation of Structure in calculateB2BB2C METHOD");
				StructDescriptor structDescriptor = StructDescriptor.createDescriptor("PAYMENT_POSTING_OBJ", con);
				STRUCT[] structs = new STRUCT[customerAccountsRecords.size()];
				for (int index = 0; index < customerAccountsRecords.size(); index++) {
					BulkDetails bulkDetailsObj = customerAccountsRecords.get(index);

					// Object[] params = new Object[64];
					Object[] params = new Object[66];
					params[0] = bulkDetailsObj.getAcctEXTID();
					params[1] = bulkDetailsObj.getAmountInr();
					params[2] = bulkDetailsObj.getBankVirtualAcctNo();
					params[3] = bulkDetailsObj.getChangeDate();
					params[4] = bulkDetailsObj.getChangeWho();
					params[5] = bulkDetailsObj.getChequeDate();
					params[6] = bulkDetailsObj.getCircle();
					params[7] = bulkDetailsObj.getCustomerName();
					params[8] = bulkDetailsObj.getCustomerType();
					params[9] = bulkDetailsObj.getDelNO();
					params[10] = bulkDetailsObj.getErrorCode();
					params[11] = bulkDetailsObj.getFileID();
					params[12] = bulkDetailsObj.getsNo();
					params[13] = bulkDetailsObj.getIncomingTransactionNo();
					params[14] = bulkDetailsObj.getInvoiceNo();
					params[15] = bulkDetailsObj.getOrderNo();
					params[16] = bulkDetailsObj.getPaymentAmt();
					params[17] = bulkDetailsObj.getPaymentDate();
					params[18] = bulkDetailsObj.getPaymentDetails1();
					params[19] = bulkDetailsObj.getPaymentDetails2();
					params[20] = bulkDetailsObj.getPaymentDetails3();
					params[21] = bulkDetailsObj.getPaymentMode();
					params[22] = bulkDetailsObj.getProductType();
					params[23] = bulkDetailsObj.getReceiverIfsc();
					params[24] = bulkDetailsObj.getReceivingRbI1();
					params[25] = bulkDetailsObj.getRefNo();
					params[26] = bulkDetailsObj.getChequeNo();
					params[27] = bulkDetailsObj.getRemitterAccNo();
					params[28] = bulkDetailsObj.getRemitterBranch();
					params[29] = bulkDetailsObj.getRemitterIfsc();
					params[30] = bulkDetailsObj.getSourceID();
					params[31] = bulkDetailsObj.getTransDate();
					params[32] = bulkDetailsObj.getVendorTransactID();
					params[33] = bulkDetailsObj.getPaymentCurrency();
					params[34] = bulkDetailsObj.getExchangeRate();
					params[35] = bulkDetailsObj.getDummyAccntNo();
					params[36] = bulkDetailsObj.getAccountType();
					params[37] = bulkDetailsObj.getServiceType();
					params[38] = bulkDetailsObj.getLegalEntity();
					params[39] = bulkDetailsObj.getValueType();
					params[40] = bulkDetailsObj.getVipFlag();
					params[41] = bulkDetailsObj.getCustomerType();
					params[42] = bulkDetailsObj.getCustomerClass();
					params[43] = bulkDetailsObj.getB2b2c();
					params[44] = bulkDetailsObj.getPaymentCode();
					params[45] = bulkDetailsObj.getFxAcctNo();
					params[46] = bulkDetailsObj.getCustomerCurrency();
					params[47] = bulkDetailsObj.getVendorTransactID();
					params[48] = bulkDetailsObj.getVendorId();
					params[49] = bulkDetailsObj.getSessionId();
					params[50] = bulkDetailsObj.getUserId();
					params[51] = bulkDetailsObj.getRemarks();
					params[52] = bulkDetailsObj.getRecordId();
					params[53] = bulkDetailsObj.getTransferType();
					if (CommonUtil.isNotNull(bulkDetailsObj.getTrackingId())) {
						params[54] = bulkDetailsObj.getTrackingId();
					} else {
						params[54] = bulkDetailsObj.getOrigTrackingId();
					}
					if (CommonUtil.isNotNull(bulkDetailsObj.getTrackingIdServ())) {
						params[55] = bulkDetailsObj.getTrackingIdServ();
					} else {
						params[55] = bulkDetailsObj.getOrigTrackingServId();
					}
					params[56] = bulkDetailsObj.getCollectionManager();
					params[57] = bulkDetailsObj.getTicketNo();
					params[58] = bulkDetailsObj.getFxStatus();
					params[59] = bulkDetailsObj.getTransferType();
					params[60] = bulkDetailsObj.getOrigBillRefResets();
					params[61] = bulkDetailsObj.getAnnotation();
					params[62] = bulkDetailsObj.getBillCompany();
					params[63] = bulkDetailsObj.getMktCode();
					params[64] = bulkDetailsObj.getRemitterName();
					params[65] = bulkDetailsObj.getReceiverName();
					STRUCT struct = new STRUCT(structDescriptor, con, params);
					structs[index] = struct;
				}
				log.info("length of struct in B2B seg proc" + structs.length);
				ArrayDescriptor desc = ArrayDescriptor.createDescriptor("PAYMENT_POSTING_TYPE", con);
				ARRAY oracleArray = new ARRAY(desc, con, structs);

				callableStatement = con.prepareCall(procedureCall);
				callableStatement.setArray(1, oracleArray);
				callableStatement.setString(2, paymentMode);
				log.info("paymentMode in calculateB2BB2C--" + paymentMode);
				callableStatement.setString(3, apsFlag);
				log.info("apsFlag in calculateB2BB2C--" + apsFlag);
				// callableStatement.registerOutParameter(4, Types.VARCHAR);
				// callableStatement.registerOutParameter(5, Types.VARCHAR);
				callableStatement.setString(4, SRNumber);
				log.info("srNumber in calculateB2BB2C--" + SRNumber);
				callableStatement.registerOutParameter(5, Types.VARCHAR);
				callableStatement.registerOutParameter(6, Types.VARCHAR);
				callableStatement.executeUpdate();
				errorCode = callableStatement.getString(5);
				log.info("OutPut from calculateB2BB2C in PaymentPostDaoImpl errorCode--- " + errorCode);
				errorMsg = callableStatement.getString(6);
				log.info("OutPut from calculateB2BB2C in PaymentPostDaoImpl errorMsg--- " + errorMsg);

			} catch (Exception e) {
				log.info("Exception in formation of Structure" + e.getMessage());
			} finally {
				if (con != null){
					try {
						callableStatement.close();
						con.close();
					} catch (Exception e) {
						log.info("Exception in the calculateB2BB2C", e);
					}
				}
				
			}

		}

		log.info("End :calculateB2BB2C in PaymentPostDaoImpl ");
		return errorMsg;
	}

	public String updateErrorDescription(BulkDetails fileRecords, String tableName) throws Exception {

		log.info("Start :updateErrorDescription in PaymentPostDaoImpl ");
		Connection con = null;
		String resultDB = EMPTY_STRING;
		String sql = EMPTY_STRING;
		PreparedStatement preparedStatement = null;
		String statusDescription="CANNOT CONNECT WITH ESB IN INT632";
		String readStatusDescription="CANNOTCONNECT WITH ESB IN INT_632,no response recieved";

		try {
			con = ConnectionUtil.getConnection();
		} catch (Exception e) {
			log.info("In updateErrorDescription connection not made", e);
		}

		if ("REFUND_PAYMENT_APS".equalsIgnoreCase(tableName)) {

			if (fileRecords.getErrorMsg().contains(CONNECT_TEXT)) {
				sql = "update REFUND_PAYMENT_APS set JOB_ID=-1, STATUS_DESCRIPTION = case when STATUS_DESCRIPTION like '" + CANNOT_CONNECT_WITH_ESB
						+ "' then STATUS_DESCRIPTION ||'.' else '"+statusDescription+"' end, MODIFIED_DATE=systimestamp where  ACCOUNT_NO= '"
						+ fileRecords.getAcctEXTID() + "' ";
			} else {
				sql = "update REFUND_PAYMENT_APS set JOB_ID=-1,STATUS_DESCRIPTION = case when STATUS_DESCRIPTION like '" + CANNOT_CONNECT_WITH_ESB
						+ "' then STATUS_DESCRIPTION ||'.' else '"+readStatusDescription+"' end, MODIFIED_DATE=systimestamp where  ACCOUNT_NO= '"
						+ fileRecords.getAcctEXTID() + "' ";
			}
		}
		if (con != null) {

			try {
				con.setAutoCommit(false);
				log.info("updateErrorDescription sql-->>  "+sql);
				System.out.println("updateErrorDescription sql-->>  "+sql);
				preparedStatement = con.prepareStatement(sql);
				int result = preparedStatement.executeUpdate();
				try {
					if (result > 0) {
						resultDB = RESULT_DB_SUCCESFUL;
					} else {
						resultDB = RESULT_DB_FAILURE;
					}
				} catch (Exception e) {
					log.info("Query execution updateErrorDescription---->", e);
				} finally {
					if (con != null){
						try {
							con.commit();
							preparedStatement.close();
							con.close();
						} catch (Exception e) {
							log.info("Exception in the updateErrorDescription", e);
						}
					}
					
				}

			} catch (Exception e) {
				log.info("Query execution updateErrorDescription---->", e);
			}

		}

		log.info("End :updateErrorDescription in PaymentPostDaoImpl ");

		return resultDB;
	}

	
	public String updateResponsePayment(BulkDetails fileRecords) throws Exception {
		log.info("END--in updateResponsePayment in PaymentDAOImpl result for record id id --->"
				+ fileRecords.getRecordId() +" orig tracking id ---"+fileRecords.getOrigTrackingId()+" file_id----"+ fileRecords.getFileID());

		Connection con = null;
		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;
		CallableStatement callableStatement = null;
//		String procedureCall = "{call UPDATE_PAYMENT_HIS_RES_APS(?,?,?,?,?,?)}";
		String procedureCall = "{call UPDATE_PAYMENT_HIS_SUMM_APS(?,?,?,?,?,?,?,?)}";
		try {
			con = ConnectionUtil.getConnection();
			
			log.info("connection formed in updateResponseInt--------->" + con);

		} catch (Exception e) {

			log.info("Connection not established ", e);
		}

		if (con != null) {

			try {

				callableStatement = con.prepareCall(procedureCall);
				callableStatement.setString(1, fileRecords.getOrigTrackingId());
				callableStatement.setString(2, fileRecords.getOrigTrackingServId());
				callableStatement.setInt(3, Integer.parseInt(fileRecords.getRecordId()));
				callableStatement.setString(4, fileRecords.getFileID());
//				callableStatement.setInt(5, Integer.parseInt(fileRecords.getPaymentAmt()));
				callableStatement.setString(5, (fileRecords.getPaymentAmt()));
				callableStatement.setString(6, fileRecords.getErrorMsg());
				callableStatement.setString(7, fileRecords.getPaymentMode());
				callableStatement.registerOutParameter(8, Types.VARCHAR);
				callableStatement.executeUpdate();
				result = callableStatement.getString(8);

			} catch (SQLException e) {
				log.info("Query execution updateResponsePayment---->", e);
			}

		}

		log.info("END--in updateResponsePayment in PaymentDAOImpl result ---" + result + " transaction id --->"
				+ fileRecords.getRecordId());
		return result;
	}
	
	public String updatePaymentAdvice(BulkDetails fileRecords) throws Exception {

		log.info("START--in updatePaymentAdvice in PaymentDAOImpl for transaction_no-->" + fileRecords.getRecordId());
		Connection con = null;
		CallableStatement callableStatement = null;

		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;

		sql = "{call PAYMENT_ADVICE_APS(?,?,?,?,?,?,?,?)}";

		try {

			try {
				con = ConnectionUtil.getConnection();
				con.setAutoCommit(false);

			} catch (Exception e) {
				log.info("Connection not established ", e);
			}
			if (con != null) {
				try {
					callableStatement = con.prepareCall(sql);
					callableStatement.setString(1, fileRecords.getRecordId());
					callableStatement.setString(2, fileRecords.getAcctEXTID());
					callableStatement.setString(3, fileRecords.getB2b2c());
					callableStatement.setString(4, fileRecords.getLegalEntity());
					callableStatement.setString(5, fileRecords.getInvoiceNo());
					callableStatement.setString(6, fileRecords.getBillRefResets());
					callableStatement.setString(7, fileRecords.getErrorMsg());
					callableStatement.registerOutParameter(8, Types.VARCHAR);
					callableStatement.executeUpdate();
					result = callableStatement.getString(8);
					log.info("updated rows in updatePaymentAdvice --->>" + result + " for transaction_no-->" + fileRecords.getRecordId());
				} catch (Exception e) {
					log.info("Exception in updatePaymentAdvice  ", e);
				}
			}
		} catch (Exception e) {
			log.info("Exception in updatePaymentAdvice  ", e);
		} finally {
			con.commit();
			callableStatement.close();
			con.close();
		}
		log.info("END--in updateConnectionReadResponse in PaymentDAOImpl result --->>" + result + " for transaction_no-->"
				+  fileRecords.getRecordId());
		return result;
	}
	
	public List<AdviceDetails> updatePaymentAdvice(String accountNo) throws Exception {

		log.info("START--in updatePaymentAdvice in PaymentDAOImpl for accountNo-->" + accountNo);
		Connection con = null;
		CallableStatement callableStatement = null;
		ResultSet emailDataResultset=null;

		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;
		List<AdviceDetails> emailList=new ArrayList<AdviceDetails>();

		sql = "{call UPDATE_ADVICE_TICKETS(?,?)}";

		try {

			try {
				con = ConnectionUtil.getConnection();
				con.setAutoCommit(false);

			} catch (Exception e) {
				log.info("Connection not established ", e);
			}
			if (con != null) {
				try {
					callableStatement = con.prepareCall(sql);
					callableStatement.setString(1, accountNo);
					callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
					callableStatement.executeUpdate();
					
					

					emailDataResultset = (ResultSet) callableStatement.getObject(2);

					if (emailDataResultset == null) 
					{
						log.info("email data result set is null ");
					}

					else
					{
						while (emailDataResultset.next()) 
						{
							AdviceDetails emailObj = new AdviceDetails();

							emailObj.setRequestId(Long.toString(emailDataResultset.getLong("I_REQUEST_ID")));
							emailObj.setOriginalFileName(emailDataResultset.getString("VC_UPLOADED_ORIGINAL_FILE_NAME"));
							emailObj.setPaymentMode(emailDataResultset.getString("VC_PAYMENT_MODE"));
							emailObj.setTotalAmount(emailDataResultset.getDouble("I_TOTAL_AMOUNT"));
							emailObj.setSuccessAmount(emailDataResultset.getDouble("SUCCESS_AMOUNT"));
							emailObj.setInprogessAmount(emailDataResultset.getDouble("INPROGRESS_AMOUNT"));
							emailObj.setFailureAmount(emailDataResultset.getDouble("FAILURE_AMOUNT"));
							emailObj.setTotalRecords(emailDataResultset.getInt("I_TOTAL_RECORDS")); 
							emailObj.setTotalSuccessRecords(emailDataResultset.getInt("I_TOTAL_SUCCESS_RECORDS"));
							emailObj.setTotalFailureRecords(emailDataResultset.getInt("I_TOTAL_FAILURE_RECORDS"));
							emailObj.setTotalInProgressRecords(emailDataResultset.getInt("I_TOTAL_INPROGRESS_RECORDS"));
							emailObj.setUploadedUserid(emailDataResultset.getString("VC_UPLOADED_USER_ID"));
							emailObj.setEmailId(emailDataResultset.getString("EMAILID"));
							emailObj.setStatusDescription(emailDataResultset.getString("STATUS_DESCRIPTION"));
							log.info("Reqeus Id!originalFilename!PaymentMode!TotalAmount!SuccessAmont!InprogressAmount!FailureAmount!TotalRecords!TotalSuccessRecords!TotalFailureRecords!TotalInprogressRecords!UploadedUserId!EmailId!StatsuDescription" );
							log.info(emailObj.getRequestId()+"!"+emailObj.getOriginalFileName()+"!"+emailObj.getPaymentMode()+"!"+emailObj.getTotalAmount()
							+"!"+emailObj.getSuccessAmount()+"!"+emailObj.getInprogessAmount()+"!"+emailObj.getFailureAmount()+"!"+emailObj.getTotalRecords()
							+"!"+emailObj.getTotalSuccessRecords()+"!"+emailObj.getTotalFailureRecords()+"!"+emailObj.getTotalInProgressRecords()
							+"!"+emailObj.getUploadedUserid()+"!"+emailObj.getEmailId()+"!"+emailObj.getStatusDescription());
							emailList.add(emailObj);
						}
					} 
					
					
					
					
					
					
				} catch (Exception e) {
					log.info("Exception in updatePaymentAdvice  ", e);
				}
			}
		} catch (Exception e) {
			log.info("Exception in updatePaymentAdvice  ", e);
		} finally {
			con.commit();
			callableStatement.close();
			con.close();
		}
		
		return emailList;
	}
	
	/*public String updatePaymentAdvice(String accountNo) throws Exception {

		log.info("START--in updatePaymentAdvice in PaymentDAOImpl for accountNo-->" + accountNo);
		Connection con = null;
		CallableStatement callableStatement = null;

		String result = EMPTY_STRING;
		String sql = EMPTY_STRING;

		sql = "{call UPDATE_ADVICE_TICKETS(?)}";

		try {

			try {
				con = ConnectionUtil.getConnection();
				con.setAutoCommit(false);

			} catch (Exception e) {
				log.info("Connection not established ", e);
			}
			if (con != null) {
				try {
					callableStatement = con.prepareCall(sql);
					callableStatement.setString(1, accountNo);
					
					callableStatement.executeUpdate();
				} catch (Exception e) {
					log.info("Exception in updatePaymentAdvice  ", e);
				}
			}
		} catch (Exception e) {
			log.info("Exception in updatePaymentAdvice  ", e);
		} finally {
			con.commit();
			callableStatement.close();
			con.close();
		}
		
		return result;
	}*/

}
