package com.airtel.acecad.client.json.CustomerAccountSummaryJson;

public class AccCustomer {
	
	private String riskSegment;

    private String customerType;

    private Individual individual;

    private String customerClass;

    private Address[] address;

   private AccCustomerPayment customerPayment;

   private AccCustomerAccount[] customerAccount;

    private String organizationType;
    

    public AccCustomerPayment getCustomerPayment() {
		return customerPayment;
	}

	public void setCustomerPayment(AccCustomerPayment customerPayment) {
		this.customerPayment = customerPayment;
	}

	public Address[] getAddress() {
		return address;
	}

	public void setAddress(Address[] address) {
		this.address = address;
	}

	public Individual getIndividual() {
		return individual;
	}

	public void setIndividual(Individual individual) {
		this.individual = individual;
	}

	public AccCustomerAccount[] getCustomerAccount() {
		return customerAccount;
	}

	public void setCustomerAccount(AccCustomerAccount[] customerAccount) {
		this.customerAccount = customerAccount;
	}

	public String getRiskSegment() {
		return riskSegment;
	}

	public void setRiskSegment(String riskSegment) {
		this.riskSegment = riskSegment;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public String getCustomerClass() {
		return customerClass;
	}

	public void setCustomerClass(String customerClass) {
		this.customerClass = customerClass;
	}

	public String getOrganizationType() {
		return organizationType;
	}

	public void setOrganizationType(String organizationType) {
		this.organizationType = organizationType;
	}
	
	@Override
    public String toString()
    {
        return "{\"riskSegment\" : \""+riskSegment+"\", \"organizationType\" : \""+organizationType+"\", \"customerType\" : \""+customerType+"\", \"customerClass\" : \""+customerClass+"\", \"individual\" : "+individual+", \"address\" : "+address+", \"customerPayment\" : "+customerPayment+", \"customerAccount\" : "+customerAccount+"}";
    }

}
