package com.airtel.acecad.client.json.adjustmentJson;

public class SoaFault {
	 private String soaFaultOriginator;

	    private String faultTrace;

	    private String faultDescription;

	    private String soaFaultCode;

	    private String soaTransactionID;

	    public String getSoaFaultOriginator ()
	    {
	        return soaFaultOriginator;
	    }

	    public void setSoaFaultOriginator (String soaFaultOriginator)
	    {
	        this.soaFaultOriginator = soaFaultOriginator;
	    }

	    public String getFaultTrace ()
	    {
	        return faultTrace;
	    }

	    public void setFaultTrace (String faultTrace)
	    {
	        this.faultTrace = faultTrace;
	    }

	    public String getFaultDescription ()
	    {
	        return faultDescription;
	    }

	    public void setFaultDescription (String faultDescription)
	    {
	        this.faultDescription = faultDescription;
	    }

	    public String getSoaFaultCode ()
	    {
	        return soaFaultCode;
	    }

	    public void setSoaFaultCode (String soaFaultCode)
	    {
	        this.soaFaultCode = soaFaultCode;
	    }

	    public String getSoaTransactionID ()
	    {
	        return soaTransactionID;
	    }

	    public void setSoaTransactionID (String soaTransactionID)
	    {
	        this.soaTransactionID = soaTransactionID;
	    }

	    @Override
	    public String toString()
	    {
	        return "{\"soaFaultOriginator\" : \""+soaFaultOriginator+"\", \"faultTrace\" : \""+faultTrace+"\", \"faultDescription\" : \""+faultDescription+"\", \"soaFaultCode\" : \""+soaFaultCode+"\", \"soaTransactionID\": \""+soaTransactionID+"\"}";
	    }
}
