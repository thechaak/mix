package com.airtel.acecad.client.json.adjustmentReversalJson;


public class SyncBillingAdjustment {

//	 private LogicalResource logicalResource;

	    private CustomerPayment customerPayment;

	    private TrackingRecord trackingRecord;

	    private Customer customer;


	    public CustomerPayment getCustomerPayment ()
	    {
	        return customerPayment;
	    }

	    public void setCustomerPayment (CustomerPayment customerPayment)
	    {
	        this.customerPayment = customerPayment;
	    }

	    public TrackingRecord getTrackingRecord ()
	    {
	        return trackingRecord;
	    }

	    public void setTrackingRecord (TrackingRecord trackingRecord)
	    {
	        this.trackingRecord = trackingRecord;
	    }

	    public Customer getCustomer ()
	    {
	        return customer;
	    }

	    public void setCustomer (Customer customer)
	    {
	        this.customer = customer;
	    }

	    @Override
	    public String toString()
	    {
	        return "{ \"customerPayment\" : "+customerPayment+", \"trackingRecord\" : "+trackingRecord+", \"customer\" : "+customer+"}";
	    }
}
