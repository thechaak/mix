package com.airtel.acecad.client.json.createUpdateNotesJson;

public class SyncCustomerInteraction {

	 private LogicalResource logicalResource;

	    private String operationType;

	    private TrackingRecord trackingRecord;

	    private BusinessInteraction businessInteraction;

	    public LogicalResource getLogicalResource ()
	    {
	        return logicalResource;
	    }

	    public void setLogicalResource (LogicalResource logicalResource)
	    {
	        this.logicalResource = logicalResource;
	    }

	    public String getOperationType ()
	    {
	        return operationType;
	    }

	    public void setOperationType (String operationType)
	    {
	        this.operationType = operationType;
	    }

	    public TrackingRecord getTrackingRecord ()
	    {
	        return trackingRecord;
	    }

	    public void setTrackingRecord (TrackingRecord trackingRecord)
	    {
	        this.trackingRecord = trackingRecord;
	    }

	    public BusinessInteraction getBusinessInteraction ()
	    {
	        return businessInteraction;
	    }

	    public void setBusinessInteraction (BusinessInteraction businessInteraction)
	    {
	        this.businessInteraction = businessInteraction;
	    }

	    @Override
	    public String toString()
	    {
	        return "{\"logicalResource\" : "+logicalResource+", \"operationType\" : \""+operationType+"\", \"trackingRecord\" : "+trackingRecord+", \"businessInteraction\" : "+businessInteraction+"}";
	    }
}
