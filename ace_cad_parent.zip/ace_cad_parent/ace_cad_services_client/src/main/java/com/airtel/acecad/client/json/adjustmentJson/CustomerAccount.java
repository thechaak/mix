package com.airtel.acecad.client.json.adjustmentJson;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class CustomerAccount
{
    private Identification identification;

    public Identification getIdentification ()
    {
        return identification;
    }

    public void setIdentification (Identification identification)
    {
        this.identification = identification;
    }

    @Override
    public String toString()
    {
        return "{\"identification\":"+identification+"}";
    }
}