package com.airtel.acecad.client.json.adjustmentReversalJson;

public class LogicalResourceIdentification {

	private String id;
	

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Override
    public String toString()
    {
        return "{\"id\" : \""+id+"\"}";
    }
}
