package com.airtel.acecad.client.dao;

import java.util.List;

import com.airtel.acecad.client.dto.BulkDetails;
import com.airtel.acecad.client.util.AdviceDetails;

public interface PaymentPostDao {

	public List<BulkDetails> getCustomerAccountsForFileId(String accountNo,String mobNo,String paymentMode,String transferType)throws Exception;
	public List<BulkDetails> getApprovalFileIds() throws Exception;
	/*public String paymentCodeCal(List<BulkDetails> customerAccountsRecords, String paymentMode, String apsFlag,String srNumber) throws Exception;
	public String liuProc(List<BulkDetails> customerAccountsRecords, String paymentMode, String apsFlag,String srNumber) throws Exception;
	public String calculateB2BB2C(List<BulkDetails> customerAccountsRecords, String paymentMode, String apsFlag,String srNumber) throws Exception;
	*/
	public String paymentCodeCal(List<BulkDetails> customerAccountsRecords, String paymentMode, String apsFlag,String SRnumber) throws Exception;
	public String liuProc(List<BulkDetails> customerAccountsRecords, String paymentMode, String apsFlag,String SRnumber) throws Exception;
	public String calculateB2BB2C(List<BulkDetails> customerAccountsRecords, String paymentMode, String apsFlag,String SRnumber) throws Exception;
	
	//Commented by geeta for include timeout in case of refund (INT_632)
	//public String updateErrorDescription (BulkDetails fileRecords) throws Exception;
	public String updateErrorDescription (BulkDetails fileRecords,String tableName) throws Exception;
	public String updateResponsePayment(BulkDetails fileRecords) throws Exception;
	
	public String updatePaymentAdvice(BulkDetails fileRecords) throws Exception;
	public List<BulkDetails> getCustomerAccountsForAdvice(String accountNo) throws Exception;
	public List<AdviceDetails> updatePaymentAdvice(String accountNo) throws Exception;
	
}
