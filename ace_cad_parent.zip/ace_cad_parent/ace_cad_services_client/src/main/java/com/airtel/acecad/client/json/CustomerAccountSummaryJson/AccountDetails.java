package com.airtel.acecad.client.json.CustomerAccountSummaryJson;

public class AccountDetails {

	private AccCustomer customer;

	public AccCustomer getCustomer() {
		return customer;
	}

	public void setCustomer(AccCustomer customer) {
		this.customer = customer;
	}

	@Override
    public String toString()
    {
        return "{\"customer\" : "+customer+"}";
    }
}
