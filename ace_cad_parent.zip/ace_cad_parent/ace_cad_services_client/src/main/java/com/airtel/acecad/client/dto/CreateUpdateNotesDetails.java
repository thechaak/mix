package com.airtel.acecad.client.dto;

public class CreateUpdateNotesDetails {

	String srNumber;
	String comments;
	String userId;
	int srTransactionNo;

	public String getSrNumber() {
		return srNumber;
	}

	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getUserId() {
		return userId;
	}

	public int getSrTransactionNo() {
		return srTransactionNo;
	}

	public void setSrTransactionNo(int srTransactionNo) {
		this.srTransactionNo = srTransactionNo;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
	
}
