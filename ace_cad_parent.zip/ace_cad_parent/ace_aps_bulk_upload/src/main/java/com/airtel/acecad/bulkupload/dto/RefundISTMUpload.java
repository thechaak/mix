package com.airtel.acecad.bulkupload.dto;

import java.util.Date;

public class RefundISTMUpload {

	private long fileId;
	private String sNo;
	private String type;
	private String subType;
	private String IISOrderNo;
	private String internalAcct;
	private String childAcct;
	private String paymentDetails;
	private String paymentAmt;
	private Date paymentDate;
	private String bankName;
	private String airtlBankAcct;
	private String paymentAdv;
	private String mCancellation;
	private String refAmount;
	private String modeOfRefund;
	private String customerName;
	private String contactNo;
	private String address;
	private String beneficiaryAcctNo;
	private String ifscCode;
	private String remarks;
	private String srNumber;
	private String accountNo;
    private String printLocation;
    private String mobileNo;
    private String paymentMode;
    private String gateway;
    private String dthTrxnId;
    private String circle;
    private String pincode;
    private String email;
    private String orgTrackingID;
    private String orgTrackingIDServ;
    
    
    
	
	public String getOrgTrackingID() {
		return orgTrackingID;
	}

	public void setOrgTrackingID(String orgTrackingID) {
		this.orgTrackingID = orgTrackingID;
	}

	public String getOrgTrackingIDServ() {
		return orgTrackingIDServ;
	}

	public void setOrgTrackingIDServ(String orgTrackingIDServ) {
		this.orgTrackingIDServ = orgTrackingIDServ;
	}

	public String getCircle() {
		return circle;
	}

	public void setCircle(String circle) {
		this.circle = circle;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDthTrxnId() {
		return dthTrxnId;
	}

	public void setDthTrxnId(String dthTrxnId) {
		this.dthTrxnId = dthTrxnId;
	}

	public String getsNo() {
		return sNo;
	}

	public void setsNo(String sNo) {
		this.sNo = sNo;
	}

	public long getFileId() {
		return fileId;
	}

	public void setFileId(long fileId) {
		this.fileId = fileId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getIISOrderNo() {
		return IISOrderNo;
	}

	public void setIISOrderNo(String iISOrderNo) {
		IISOrderNo = iISOrderNo;
	}

	public String getInternalAcct() {
		return internalAcct;
	}

	public void setInternalAcct(String internalAcct) {
		this.internalAcct = internalAcct;
	}

	public String getChildAcct() {
		return childAcct;
	}

	public void setChildAcct(String childAcct) {
		this.childAcct = childAcct;
	}

	public String getPaymentDetails() {
		return paymentDetails;
	}

	public void setPaymentDetails(String paymentDetails) {
		this.paymentDetails = paymentDetails;
	}

	public String getPaymentAmt() {
		return paymentAmt;
	}

	public void setPaymentAmt(String paymentAmt) {
		this.paymentAmt = paymentAmt;
	}

	
	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getAirtlBankAcct() {
		return airtlBankAcct;
	}

	public void setAirtlBankAcct(String airtlBankAcct) {
		this.airtlBankAcct = airtlBankAcct;
	}

	public String getPaymentAdv() {
		return paymentAdv;
	}

	public void setPaymentAdv(String paymentAdv) {
		this.paymentAdv = paymentAdv;
	}

	
	public String getmCancellation() {
		return mCancellation;
	}

	public void setmCancellation(String mCancellation) {
		this.mCancellation = mCancellation;
	}

	public String getRefAmount() {
		return refAmount;
	}

	public void setRefAmount(String refAmount) {
		this.refAmount = refAmount;
	}

	public String getModeOfRefund() {
		return modeOfRefund;
	}

	public void setModeOfRefund(String modeOfRefund) {
		this.modeOfRefund = modeOfRefund;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBeneficiaryAcctNo() {
		return beneficiaryAcctNo;
	}

	public void setBeneficiaryAcctNo(String beneficiaryAcctNo) {
		this.beneficiaryAcctNo = beneficiaryAcctNo;
	}

	
	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getSrNumber() {
		return srNumber;
	}

	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getPrintLocation() {
		return printLocation;
	}

	public void setPrintLocation(String printLocation) {
		this.printLocation = printLocation;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getGateway() {
		return gateway;
	}

	public void setGateway(String gateway) {
		this.gateway = gateway;
	}


}
