package com.airtel.acecad.bulkupload.controller;

public class SubClass extends SuperClass {
	
	public SubClass(){
		System.out.println("In Sub class Constructor");
	}
	public int run(){
		System.out.println("In run method of sub");
		return 1;
	}
	
	public static void main(String args[]){
		SuperClass super1 = new SubClass();
		super1.run();
		super1.abc();
		System.out.println("*************************");
		
		SubClass sub1 = new SubClass();
		sub1.run();
		sub1.abc();
	}
	
	
}
