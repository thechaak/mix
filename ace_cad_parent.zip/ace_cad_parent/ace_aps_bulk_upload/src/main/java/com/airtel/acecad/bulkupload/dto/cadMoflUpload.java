package com.airtel.acecad.bulkupload.dto;

import java.util.Date;

public class cadMoflUpload {

	private int waiverTxNo;
	private int waiverTicketNo;
	private String lob;
	private String circle;
	private String accountExternalId;
	private String amount;
	private String mobilelId;
	private String billRefNo;
	private String segment;
	private String typeOfAdjustment;
	private String adjDescription;
	private int adjTransCode;
	private String appName;
	private String appLevel;
	private String adjReasonDet;
	private String type;
	private String subType;
	private String subSubType;
	private String product;
	private String typeOfWaiver;
	private int wacAdjReasonCode;
	private String wacReasonDet;
	private String wacException;
	private String wacStatus;
	private String wacRejReason;
	private String wacRmdamount;
	private String wacRemarks;
	private String cadStatus;
	private String cadRejectionReason;
	private String cadRemarks;
	private String vipFlag;
	private String customerClassification;
	private String customerType;
	private String valueType;
	private String finalSegment ;
	private String waiverInvoicePercentage;
	private int ageOnNetwork;
	private String billRefResets;
	private String invoiceDate;
	private String totalInvoiceAmt;
	private String invoiceOutstandingAmt;
	private String customerName;
	private String uploadedUserId;
	private String uploadedUserName;
	private Date wacReachTime;
	private String ticketUploadTime;
	private String typeOfPeriod;
	private Date cadReachTime;
	private String issueRectified;
	
	
	
	public String getSubSubType() {
		return subSubType;
	}
	public void setSubSubType(String subSubType) {
		this.subSubType = subSubType;
	}
	public String getVipFlag() {
		return vipFlag;
	}
	public void setVipFlag(String vipFlag) {
		this.vipFlag = vipFlag;
	}
	public String getCustomerClassification() {
		return customerClassification;
	}
	public void setCustomerClassification(String customerClassification) {
		this.customerClassification = customerClassification;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getValueType() {
		return valueType;
	}
	public void setValueType(String valueType) {
		this.valueType = valueType;
	}
	public String getFinalSegment() {
		return finalSegment;
	}
	public void setFinalSegment(String finalSegment) {
		this.finalSegment = finalSegment;
	}
	public String getWaiverInvoicePercentage() {
		return waiverInvoicePercentage;
	}
	public void setWaiverInvoicePercentage(String waiverInvoicePercentage) {
		this.waiverInvoicePercentage = waiverInvoicePercentage;
	}
	public int getAgeOnNetwork() {
		return ageOnNetwork;
	}
	public void setAgeOnNetwork(int ageOnNetwork) {
		this.ageOnNetwork = ageOnNetwork;
	}
	public String getBillRefResets() {
		return billRefResets;
	}
	public void setBillRefResets(String billRefResets) {
		this.billRefResets = billRefResets;
	}
	public String getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public String getTotalInvoiceAmt() {
		return totalInvoiceAmt;
	}
	public void setTotalInvoiceAmt(String totalInvoiceAmt) {
		this.totalInvoiceAmt = totalInvoiceAmt;
	}
	public String getInvoiceOutstandingAmt() {
		return invoiceOutstandingAmt;
	}
	public void setInvoiceOutstandingAmt(String invoiceOutstandingAmt) {
		this.invoiceOutstandingAmt = invoiceOutstandingAmt;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getUploadedUserId() {
		return uploadedUserId;
	}
	public void setUploadedUserId(String uploadedUserId) {
		this.uploadedUserId = uploadedUserId;
	}
	public String getUploadedUserName() {
		return uploadedUserName;
	}
	public void setUploadedUserName(String uploadedUserName) {
		this.uploadedUserName = uploadedUserName;
	}
	public Date getWacReachTime() {
		return wacReachTime;
	}
	public void setWacReachTime(Date wacReachTime) {
		this.wacReachTime = wacReachTime;
	}
	public String getTicketUploadTime() {
		return ticketUploadTime;
	}
	public void setTicketUploadTime(String ticketUploadTime) {
		this.ticketUploadTime = ticketUploadTime;
	}
	public String getTypeOfPeriod() {
		return typeOfPeriod;
	}
	public void setTypeOfPeriod(String typeOfPeriod) {
		this.typeOfPeriod = typeOfPeriod;
	}
	public Date getCadReachTime() {
		return cadReachTime;
	}
	public void setCadReachTime(Date cadReachTime) {
		this.cadReachTime = cadReachTime;
	}
	public String getIssueRectified() {
		return issueRectified;
	}
	public void setIssueRectified(String issueRectified) {
		this.issueRectified = issueRectified;
	}
	public int getWaiverTxNo() {
		return waiverTxNo;
	}
	public void setWaiverTxNo(int waiverTxNo) {
		this.waiverTxNo = waiverTxNo;
	}
	public int getWaiverTicketNo() {
		return waiverTicketNo;
	}
	public void setWaiverTicketNo(int waiverTicketNo) {
		this.waiverTicketNo = waiverTicketNo;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getAccountExternalId() {
		return accountExternalId;
	}
	public void setAccountExternalId(String accountExternalId) {
		this.accountExternalId = accountExternalId;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getMobilelId() {
		return mobilelId;
	}
	public void setMobilelId(String mobilelId) {
		this.mobilelId = mobilelId;
	}
	public String getBillRefNo() {
		return billRefNo;
	}
	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}
	public String getSegment() {
		return segment;
	}
	public void setSegment(String segment) {
		this.segment = segment;
	}
	public String getTypeOfAdjustment() {
		return typeOfAdjustment;
	}
	public void setTypeOfAdjustment(String typeOfAdjustment) {
		this.typeOfAdjustment = typeOfAdjustment;
	}
	public String getAdjDescription() {
		return adjDescription;
	}
	public void setAdjDescription(String adjDescription) {
		this.adjDescription = adjDescription;
	}
	public int getAdjTransCode() {
		return adjTransCode;
	}
	public void setAdjTransCode(int adjTransCode) {
		this.adjTransCode = adjTransCode;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getAppLevel() {
		return appLevel;
	}
	public void setAppLevel(String appLevel) {
		this.appLevel = appLevel;
	}
	public String getAdjReasonDet() {
		return adjReasonDet;
	}
	public void setAdjReasonDet(String adjReasonDet) {
		this.adjReasonDet = adjReasonDet;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getTypeOfWaiver() {
		return typeOfWaiver;
	}
	public void setTypeOfWaiver(String typeOfWaiver) {
		this.typeOfWaiver = typeOfWaiver;
	}
	public int getWacAdjReasonCode() {
		return wacAdjReasonCode;
	}
	public void setWacAdjReasonCode(int wacAdjReasonCode) {
		this.wacAdjReasonCode = wacAdjReasonCode;
	}
	public String getWacReasonDet() {
		return wacReasonDet;
	}
	public void setWacReasonDet(String wacReasonDet) {
		this.wacReasonDet = wacReasonDet;
	}
	public String getWacException() {
		return wacException;
	}
	public void setWacException(String wacException) {
		this.wacException = wacException;
	}
	public String getWacStatus() {
		return wacStatus;
	}
	public void setWacStatus(String wacStatus) {
		this.wacStatus = wacStatus;
	}
	public String getWacRejReason() {
		return wacRejReason;
	}
	public void setWacRejReason(String wacRejReason) {
		this.wacRejReason = wacRejReason;
	}
	public String getWacRmdamount() {
		return wacRmdamount;
	}
	public void setWacRmdamount(String wacRmdamount) {
		this.wacRmdamount = wacRmdamount;
	}
	public String getWacRemarks() {
		return wacRemarks;
	}
	public void setWacRemarks(String wacRemarks) {
		this.wacRemarks = wacRemarks;
	}
	public String getCadStatus() {
		return cadStatus;
	}
	public void setCadStatus(String cadStatus) {
		this.cadStatus = cadStatus;
	}
	public String getCadRejectionReason() {
		return cadRejectionReason;
	}
	public void setCadRejectionReason(String cadRejectionReason) {
		this.cadRejectionReason = cadRejectionReason;
	}
	public String getCadRemarks() {
		return cadRemarks;
	}
	public void setCadRemarks(String cadRemarks) {
		this.cadRemarks = cadRemarks;
	}
	
	
}
