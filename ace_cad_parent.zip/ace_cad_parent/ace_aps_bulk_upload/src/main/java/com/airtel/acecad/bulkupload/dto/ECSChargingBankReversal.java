package com.airtel.acecad.bulkupload.dto;

import java.util.Date;

public class ECSChargingBankReversal {
 String accountNo;
 long mobileNo;
 String custName;
 String billCycle;
 Date debitD;
 double totalDue;
 String circle;
 int mktCode;
 String status;
 String airtelMobileFixedLine;
 String bankName;
 String micr;
 long bankAccountNumber;
 String accountHolderName;
 String umrnNo;
 String clearingHouse;
 String vpnReferenceNo;
 String clientCode;
 String depositSlipNo;
 String depRef;
 String mode;
 String dbStatus;
 String hotScan;
 Date settlementDate;
 String bdPaidStatus;
 String reason;
 long txnId;
 Date reportedDate;
 
 

public Date getDebitD() {
	return debitD;
}
public void setDebitD(Date debitD) {
	this.debitD = debitD;
}

public String getAccountNo() {
	return accountNo;
}
public void setAccountNo(String accountNo) {
	this.accountNo = accountNo;
}
public long getMobileNo() {
	return mobileNo;
}
public void setMobileNo(long mobileNo) {
	this.mobileNo = mobileNo;
}
public String getCustName() {
	return custName;
}
public void setCustName(String custName) {
	this.custName = custName;
}
public String getBillCycle() {
	return billCycle;
}
public void setBillCycle(String billCycle) {
	this.billCycle = billCycle;
}


public double getTotalDue() {
	return totalDue;
}
public void setTotalDue(double totalDue) {
	this.totalDue = totalDue;
}
public String getCircle() {
	return circle;
}
public void setCircle(String circle) {
	this.circle = circle;
}
public int getMktCode() {
	return mktCode;
}
public void setMktCode(int mktCode) {
	this.mktCode = mktCode;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}

public String getAirtelMobileFixedLine() {
	return airtelMobileFixedLine;
}
public void setAirtelMobileFixedLine(String airtelMobileFixedLine) {
	this.airtelMobileFixedLine = airtelMobileFixedLine;
}
public String getBankName() {
	return bankName;
}
public void setBankName(String bankName) {
	this.bankName = bankName;
}
public String getMicr() {
	return micr;
}
public void setMicr(String micr) {
	this.micr = micr;
}

public long getBankAccountNumber() {
	return bankAccountNumber;
}
public void setBankAccountNumber(long bankAccountNumber) {
	this.bankAccountNumber = bankAccountNumber;
}
public String getAccountHolderName() {
	return accountHolderName;
}
public void setAccountHolderName(String accountHolderName) {
	this.accountHolderName = accountHolderName;
}
public String getUmrnNo() {
	return umrnNo;
}
public void setUmrnNo(String umrnNo) {
	this.umrnNo = umrnNo;
}
public String getClearingHouse() {
	return clearingHouse;
}
public void setClearingHouse(String clearingHouse) {
	this.clearingHouse = clearingHouse;
}
public String getVpnReferenceNo() {
	return vpnReferenceNo;
}
public void setVpnReferenceNo(String vpnReferenceNo) {
	this.vpnReferenceNo = vpnReferenceNo;
}
public String getClientCode() {
	return clientCode;
}
public void setClientCode(String clientCode) {
	this.clientCode = clientCode;
}
public String getDepositSlipNo() {
	return depositSlipNo;
}
public void setDepositSlipNo(String depositSlipNo) {
	this.depositSlipNo = depositSlipNo;
}
public String getDepRef() {
	return depRef;
}
public void setDepRef(String depRef) {
	this.depRef = depRef;
}
public String getMode() {
	return mode;
}
public void setMode(String mode) {
	this.mode = mode;
}
public String getDbStatus() {
	return dbStatus;
}
public void setDbStatus(String dbStatus) {
	this.dbStatus = dbStatus;
}
public String getHotScan() {
	return hotScan;
}
public void setHotScan(String hotScan) {
	this.hotScan = hotScan;
}
public Date getSettlementDate() {
	return settlementDate;
}
public void setSettlementDate(Date settlementDate) {
	this.settlementDate = settlementDate;
}
public String getBdPaidStatus() {
	return bdPaidStatus;
}
public void setBdPaidStatus(String bdPaidStatus) {
	this.bdPaidStatus = bdPaidStatus;
}
public String getReason() {
	return reason;
}
public void setReason(String reason) {
	this.reason = reason;
}
public long getTxnId() {
	return txnId;
}
public void setTxnId(long txnId) {
	this.txnId = txnId;
}
public Date getReportedDate() {
	return reportedDate;
}
public void setReportedDate(Date reportedDate) {
	this.reportedDate = reportedDate;
}
 
}
