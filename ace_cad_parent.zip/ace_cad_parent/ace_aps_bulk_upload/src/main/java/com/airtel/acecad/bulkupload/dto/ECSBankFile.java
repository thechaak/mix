package com.airtel.acecad.bulkupload.dto;

public class ECSBankFile {
String srNumber;
String srTransactionNumber;
String accountNumber;
int statusCode;
String statusDescription;
public int getStatusCode() {
	return statusCode;
}
public void setStatusCode(int statusCode) {
	this.statusCode = statusCode;
}
public String getStatusDescription() {
	return statusDescription;
}
public void setStatusDescription(String statusDescription) {
	this.statusDescription = statusDescription;
}
public String getSrNumber() {
	return srNumber;
}
public void setSrNumber(String srNumber) {
	this.srNumber = srNumber;
}
public String getSrTransactionNumber() {
	return srTransactionNumber;
}
public void setSrTransactionNumber(String srTransactionNumber) {
	this.srTransactionNumber = srTransactionNumber;
}
public String getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(String accountNumber) {
	this.accountNumber = accountNumber;
}


}
