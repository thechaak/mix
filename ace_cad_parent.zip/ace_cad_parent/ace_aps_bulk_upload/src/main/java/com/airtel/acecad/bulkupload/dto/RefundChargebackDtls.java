package com.airtel.acecad.bulkupload.dto;

import java.util.Date;

public class RefundChargebackDtls {
	String amount;
	String srNumber;
	String createDate;
	String circle;
	String msisdn;
	String payRevDesc;
	String accountNum;
	String payRevType;
	String orgTracId;
	String orgTracIdServ;
	String revTracId;
	String revTracIdServ;
	String postTracId;
	String postTracIdServ;
	String bankName;
	String chqNumber;
	String billRefNum;
	String billRefNumResets;
	String comments;
	String srTransNo;
	String arcNum;
	String arcSystem;
	Date arcDate;
	String arcStatus;
	String arcRejectionReason;
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getPayRevDesc() {
		return payRevDesc;
	}
	public void setPayRevDesc(String payRevDesc) {
		this.payRevDesc = payRevDesc;
	}
	
	public String getAccountNum() {
		return accountNum;
	}
	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}
	public String getPayRevType() {
		return payRevType;
	}
	public void setPayRevType(String payRevType) {
		this.payRevType = payRevType;
	}
	public String getOrgTracId() {
		return orgTracId;
	}
	public void setOrgTracId(String orgTracId) {
		this.orgTracId = orgTracId;
	}
	public String getOrgTracIdServ() {
		return orgTracIdServ;
	}
	public void setOrgTracIdServ(String orgTracIdServ) {
		this.orgTracIdServ = orgTracIdServ;
	}
	public String getRevTracId() {
		return revTracId;
	}
	public void setRevTracId(String revTracId) {
		this.revTracId = revTracId;
	}
	public String getRevTracIdServ() {
		return revTracIdServ;
	}
	public void setRevTracIdServ(String revTracIdServ) {
		this.revTracIdServ = revTracIdServ;
	}
	public String getPostTracId() {
		return postTracId;
	}
	public void setPostTracId(String postTracId) {
		this.postTracId = postTracId;
	}
	public String getPostTracIdServ() {
		return postTracIdServ;
	}
	public void setPostTracIdServ(String postTracIdServ) {
		this.postTracIdServ = postTracIdServ;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getChqNumber() {
		return chqNumber;
	}
	public void setChqNumber(String chqNumber) {
		this.chqNumber = chqNumber;
	}
	public String getBillRefNum() {
		return billRefNum;
	}
	public void setBillRefNum(String billRefNum) {
		this.billRefNum = billRefNum;
	}
	public String getBillRefNumResets() {
		return billRefNumResets;
	}
	public void setBillRefNumResets(String billRefNumResets) {
		this.billRefNumResets = billRefNumResets;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getSrTransNo() {
		return srTransNo;
	}
	public void setSrTransNo(String srTransNo) {
		this.srTransNo = srTransNo;
	}
	public String getArcNum() {
		return arcNum;
	}
	public void setArcNum(String arcNum) {
		this.arcNum = arcNum;
	}
	public String getArcSystem() {
		return arcSystem;
	}
	public void setArcSystem(String arcSystem) {
		this.arcSystem = arcSystem;
	}
	public Date getArcDate() {
		return arcDate;
	}
	public void setArcDate(Date arcDate) {
		this.arcDate = arcDate;
	}
	public String getArcStatus() {
		return arcStatus;
	}
	public void setArcStatus(String arcStatus) {
		this.arcStatus = arcStatus;
	}
	public String getArcRejectionReason() {
		return arcRejectionReason;
	}
	public void setArcRejectionReason(String arcRejectionReason) {
		this.arcRejectionReason = arcRejectionReason;
	}
	
	


}
