package com.airtel.acecad.bulkupload.dto;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ChequeBounceDetails {

	int fileId;
	int serialNo;
	String bankAccountNumner;
	String retuenReceivedDate;
	long chqAmount;
	String chequeNo;
	Date chequeDate;
	String bankName;
	String returnReason;
	String createdDate;	
	String modifiedDate;
	String trackingId;
	String trackinIdServ;
	String statusCode;
	String statusDescription;
	String sentFxFlag;
	String noOfHit;
	String userId;
	List<ChequeBounceDetails> chequeDetails=new ArrayList<>();
	public List<ChequeBounceDetails> getChequeDetails() {
		return chequeDetails;
	}
	public void setChequeDetails(List<ChequeBounceDetails> chequeDetails) {
		this.chequeDetails = chequeDetails;
	}
	public int getFileId() {
		return fileId;
	}
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}
	public int getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}
	public String getBankAccountNumner() {
		return bankAccountNumner;
	}
	public void setBankAccountNumner(String bankAccountNumner) {
		this.bankAccountNumner = bankAccountNumner;
	}
	
	public String getRetuenReceivedDate() {
		return retuenReceivedDate;
	}
	public void setRetuenReceivedDate(String retuenReceivedDate) {
		this.retuenReceivedDate = retuenReceivedDate;
	}
	public long getChqAmount() {
		return chqAmount;
	}
	public void setChqAmount(long chqAmount) {
		this.chqAmount = chqAmount;
	}
	public String getChequeNo() {
		return chequeNo;
	}
	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}
	public Date getChequeDate() {
		return chequeDate;
	}
	public void setChequeDate(Date chequeDate) {
		this.chequeDate = chequeDate;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getReturnReason() {
		return returnReason;
	}
	public void setReturnReason(String returnReason) {
		this.returnReason = returnReason;
	}

	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	public String getTrackinIdServ() {
		return trackinIdServ;
	}
	public void setTrackinIdServ(String trackinIdServ) {
		this.trackinIdServ = trackinIdServ;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	public String getSentFxFlag() {
		return sentFxFlag;
	}
	public void setSentFxFlag(String sentFxFlag) {
		this.sentFxFlag = sentFxFlag;
	}
	public String getNoOfHit() {
		return noOfHit;
	}
	public void setNoOfHit(String noOfHit) {
		this.noOfHit = noOfHit;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
}