package com.airtel.acecad.bulkupload.dto;

import java.util.Date;

public class LTCDetails {
	String customerTanNo;
	String legalEntity;
	String financialYear;
    String quarter;
    Double ltcPercentage;
    Double amt;
    String customerName;
    String airtelTanNo;
    String ltcCertificateNo;
    Date ltcCertificateDate;
    String section;
    Date effectiveTo;
    Date effectiveFrom;
    
	public Date getEffectiveTo() {
		return effectiveTo;
	}
	public void setEffectiveTo(Date effectiveTo) {
		this.effectiveTo = effectiveTo;
	}
	public Date getEffectiveFrom() {
		return effectiveFrom;
	}
	public void setEffectiveFrom(Date effectiveFrom) {
		this.effectiveFrom = effectiveFrom;
	}
	public String getCustomerTanNo() {
		return customerTanNo;
	}
	public void setCustomerTanNo(String customerTanNo) {
		this.customerTanNo = customerTanNo;
	}
	
	public String getLegalEntity() {
		return legalEntity;
	}
	public void setLegalEntity(String legalEntity) {
		this.legalEntity = legalEntity;
	}
	public String getFinancialYear() {
		return financialYear;
	}
	public void setFinancialYear(String financialYear) {
		this.financialYear = financialYear;
	}
	public String getQuarter() {
		return quarter;
	}
	public void setQuarter(String quarter) {
		this.quarter = quarter;
	}
	public Double getLtcPercentage() {
		return ltcPercentage;
	}
	public void setLtcPercentage(Double ltcPercentage) {
		this.ltcPercentage = ltcPercentage;
	}
	public Double getAmt() {
		return amt;
	}
	public void setAmt(Double amt) {
		this.amt = amt;
	}
	/*public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}*/
	public String getAirtelTanNo() {
		return airtelTanNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public void setAirtelTanNo(String airtelTanNo) {
		this.airtelTanNo = airtelTanNo;
	}
	public String getLtcCertificateNo() {
		return ltcCertificateNo;
	}
	public void setLtcCertificateNo(String ltcCertificateNo) {
		this.ltcCertificateNo = ltcCertificateNo;
	}
	public Date getLtcCertificateDate() {
		return ltcCertificateDate;
	}
	public void setLtcCertificateDate(Date ltcCertificateDate) {
		this.ltcCertificateDate = ltcCertificateDate;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
}
