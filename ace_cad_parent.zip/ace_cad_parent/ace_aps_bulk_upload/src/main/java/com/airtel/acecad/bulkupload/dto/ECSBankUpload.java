package com.airtel.acecad.bulkupload.dto;


import java.util.Date;

public class ECSBankUpload {
int slNo; 

String dateOfReceipt;
String location;
int mktCode;
String circle;
String accountNumber;
String mobileNo;
String customerName;
String bankName;
String micr;
String bankAccountNumber;
String accountHolderName;
String accountType;
String bdValidInvalidStatus;
String bdReason;
long sscAccountId;
String status;
String airtelName;
String clientValidInvalidStatus;
String clientReason;
String mode;
String urmnNumber;
String nachRegStatus;
String destinationBankReason;
String activationDate;
String fileNumber;
double amount;
int circleCode;
String npciUploadDate;
String fixedLineOrMobility;
String srNumber;
String interimStatus;
String intriemRejectionReason;

public String getIntriemRejectionReason() {
	return intriemRejectionReason;
}
public void setIntriemRejectionReason(String intriemRejectionReason) {
	this.intriemRejectionReason = intriemRejectionReason;
}
public String getInterimStatus() {
	return interimStatus;
}
public void setInterimStatus(String interimStatus) {
	this.interimStatus = interimStatus;
}
String srTransactionNumber;
String fileId;
String errorDescription;
int statusCode;
String sentToCieble;


public String getFileId() {
	return fileId;
}
public void setFileId(String fileId) {
	this.fileId = fileId;
}
public String getErrorDescription() {
	return errorDescription;
}
public void setErrorDescription(String errorDescription) {
	this.errorDescription = errorDescription;
}
public int getStatusCode() {
	return statusCode;
}
public void setStatusCode(int statusCode) {
	this.statusCode = statusCode;
}
public String getSentToCieble() {
	return sentToCieble;
}
public void setSentToCieble(String sentToCieble) {
	this.sentToCieble = sentToCieble;
}
public String getSrNumber() {
	return srNumber;
}
public void setSrNumber(String srNumber) {
	this.srNumber = srNumber;
}
public String getSrTransactionNumber() {
	return srTransactionNumber;
}
public void setSrTransactionNumber(String srTransactionNumber) {
	this.srTransactionNumber = srTransactionNumber;
}
public int getSlNo() {
	return slNo;
}
public void setSlNo(int slNo) {
	this.slNo = slNo;
}

public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public int getMktCode() {
	return mktCode;
}
public void setMktCode(int mktCode) {
	this.mktCode = mktCode;
}
public String getCircle() {
	return circle;
}
public void setCircle(String circle) {
	this.circle = circle;
}

public String getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(String accountNumber) {
	this.accountNumber = accountNumber;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getBankName() {
	return bankName;
}
public void setBankName(String bankName) {
	this.bankName = bankName;
}
public String getMicr() {
	return micr;
}
public void setMicr(String micr) {
	this.micr = micr;
}
public String getBankAccountNumber() {
	return bankAccountNumber;
}
public void setBankAccountNumber(String bankAccountNumber) {
	this.bankAccountNumber = bankAccountNumber;
}
public String getAccountHolderName() {
	return accountHolderName;
}
public void setAccountHolderName(String accountHolderName) {
	this.accountHolderName = accountHolderName;
}
public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}
public String getBdValidInvalidStatus() {
	return bdValidInvalidStatus;
}
public void setBdValidInvalidStatus(String bdValidInvalidStatus) {
	this.bdValidInvalidStatus = bdValidInvalidStatus;
}
public String getBdReason() {
	return bdReason;
}
public void setBdReason(String bdReason) {
	this.bdReason = bdReason;
}
public long getSscAccountId() {
	return sscAccountId;
}
public void setSscAccountId(long sscAccountId) {
	this.sscAccountId = sscAccountId;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getAirtelName() {
	return airtelName;
}
public void setAirtelName(String airtelName) {
	this.airtelName = airtelName;
}
public String getClientValidInvalidStatus() {
	return clientValidInvalidStatus;
}
public void setClientValidInvalidStatus(String clientValidInvalidStatus) {
	this.clientValidInvalidStatus = clientValidInvalidStatus;
}
public String getClientReason() {
	return clientReason;
}
public void setClientReason(String clientReason) {
	this.clientReason = clientReason;
}
public String getMode() {
	return mode;
}
public void setMode(String mode) {
	this.mode = mode;
}
public String getUrmnNumber() {
	return urmnNumber;
}
public void setUrmnNumber(String urmnNumber) {
	this.urmnNumber = urmnNumber;
}
public String getNachRegStatus() {
	return nachRegStatus;
}
public void setNachRegStatus(String nachRegStatus) {
	this.nachRegStatus = nachRegStatus;
}
public String getDestinationBankReason() {
	return destinationBankReason;
}
public void setDestinationBankReason(String destinationBankReason) {
	this.destinationBankReason = destinationBankReason;
}

public String getFileNumber() {
	return fileNumber;
}
public void setFileNumber(String fileNumber) {
	this.fileNumber = fileNumber;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
public int getCircleCode() {
	return circleCode;
}
public void setCircleCode(int circleCode) {
	this.circleCode = circleCode;
}

public String getDateOfReceipt() {
	return dateOfReceipt;
}
public void setDateOfReceipt(String dateOfReceipt) {
	this.dateOfReceipt = dateOfReceipt;
}
public String getActivationDate() {
	return activationDate;
}
public void setActivationDate(String activationDate) {
	this.activationDate = activationDate;
}
public String getNpciUploadDate() {
	return npciUploadDate;
}
public void setNpciUploadDate(String npciUploadDate) {
	this.npciUploadDate = npciUploadDate;
}
public String getFixedLineOrMobility() {
	return fixedLineOrMobility;
}
public void setFixedLineOrMobility(String fixedLineOrMobility) {
	this.fixedLineOrMobility = fixedLineOrMobility;
}

}
