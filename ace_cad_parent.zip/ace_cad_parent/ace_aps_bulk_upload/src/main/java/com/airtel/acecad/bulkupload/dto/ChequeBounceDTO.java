package com.airtel.acecad.bulkupload.dto;

import java.sql.Timestamp;
import java.util.Date;

public class ChequeBounceDTO {
	
	
	int fileId;
	int sNo;
	Date paymentDate;
	String refNumber;
	Date chequeDate;
	String bankName;
	Double paymentAmount;
	String bankVirtualAccountNumber;
	String bounceReason;
	
	Timestamp createdDate;
	Timestamp modifiedDate;

	
	public int getFileId() {
		return fileId;
	}
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}
	public int getsNo() {
		return sNo;
	}
	public void setsNo(int sNo) {
		this.sNo = sNo;
	}
	public Date getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}
	public String getRefNumber() {
		return refNumber;
	}
	public void setRefNumber(String refNumber) {
		this.refNumber = refNumber;
	}
	public Date getChequeDate() {
		return chequeDate;
	}
	public void setChequeDate(Date chequeDate) {
		this.chequeDate = chequeDate;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public Double getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(Double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public String getBankVirtualAccountNumber() {
		return bankVirtualAccountNumber;
	}
	public void setBankVirtualAccountNumber(String bankVirtualAccountNumber) {
		this.bankVirtualAccountNumber = bankVirtualAccountNumber;
	}
	public String getBounceReason() {
		return bounceReason;
	}
	public void setBounceReason(String bounceReason) {
		this.bounceReason = bounceReason;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
}
