package com.airtel.acecad.bulkupload.util;


import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.StringTokenizer;
import java.util.regex.Pattern;


public class CommonValidator {


	/**
	 * @description - This method will return true when input string is null or empty. 
	 * @param value
	 * @return boolean
	 */

	public static boolean isNull(String value) {

		return (value == null || value.isEmpty() || value=="");

	}

	public static String dateCheckPaymentCheck(String dateToValidate, String minDay, 
			String maxDay, String dateFromat,String fileIdentifier){


		SimpleDateFormat sdf;

		if(isNull(dateToValidate)){
			return "false";
		}
		if(isNull(dateFromat)){
			dateFromat="dd-MM-yyyy";
		}
		dateFromat=dateFromat.toLowerCase();
		String newDateFormat=null;
		try {

			if(isNull(minDay) && isNull(maxDay)){

				newDateFormat=dateFromat.replace('m', 'M');
				sdf = new SimpleDateFormat(newDateFormat);
				sdf.setLenient(false);


				Date date1 = sdf.parse(dateToValidate);
				Date systemDate = new Date();
				// Date sysDate = sdf.parse("2010-01-31");
				Date sysDate = sdf.parse(sdf.format(systemDate));

				System.out.println("date1 : " + sdf.format(date1));
				System.out.println("sysDate : " + sdf.format(sysDate));
				/*
		if (date1.compareTo(sysDate) > 0) {
		System.out.println("Date1 is after Sysdate");
		return false;
		} 
		else*/
				return "true";

			}
			else{

				newDateFormat=dateFromat.replace('m', 'M');
				System.out.println("newDateFormat-->> "+newDateFormat);
				SimpleDateFormat dateFormat = new SimpleDateFormat(newDateFormat);
				dateFormat.setLenient(false);
				Date sysDate = new Date();
				int count=0;
				int count1=0;

				Date userDate = null;
				Date systemDate = null;

				if (!CommonValidator.isNull(dateToValidate) && !CommonValidator.isNull(dateFromat)) {
					if(!isNull(minDay) || !isNull(maxDay)){

						userDate = dateFormat.parse(dateToValidate);
						systemDate = dateFormat.parse(dateFormat.format(sysDate));


						if(isNull(minDay) && !isNull(maxDay)){

							System.out.println("Inside Max Days");
							long add = userDate.getTime() - systemDate.getTime();
							long addDays = add / (24 * 60 * 60 * 1000);
							System.out.println(addDays + " days ");
							if (Long.valueOf(addDays) <= Long.valueOf(maxDay)) {
								return "true";
							}
							else{
								if(Long.valueOf(maxDay)==0L){
									return "should not be greater than sysdate";
								}
								else{
									return "should not be greater than "+maxDay+" Days";
								}
							}

						}
						if(isNull(maxDay) && !isNull(minDay)){

							if (systemDate.getTime() > userDate.getTime()) {

								System.out.println("Inside Min Days");
								long diff = systemDate.getTime() - userDate.getTime();

								long diffDays = diff / (24 * 60 * 60 * 1000);
								System.out.println(diffDays + " days ");
								if (Long.valueOf(diffDays) <= Long.valueOf(minDay)) {
									return "true";
								}
								else{
									return "should not be less than "+minDay+" Days";
								}
							}
							else if(userDate.getTime() == systemDate.getTime()){
								System.out.println("Inside equal Days");
								return "true";

							}
							else 
								return "true";

						}
						if(!isNull(minDay) && !isNull(maxDay)){
							int x=Integer.valueOf(minDay)+Integer.valueOf(maxDay);

							if(x>=0){

								if (!isNull(minDay)) {

									System.out.println("Inside Min Days");
									long diff = systemDate.getTime() - userDate.getTime();

									long diffDays = diff / (24 * 60 * 60 * 1000);
									System.out.println(diffDays + " days ");

									if (Long.valueOf(diffDays) <= Long.valueOf(minDay)) {
										count=1;
									}
									else{
										return "should not be less than "+minDay+" Days";
									}
								} if (!isNull(maxDay)) {
									System.out.println("Inside Max Days");
									long add = userDate.getTime() - systemDate.getTime();
									long addDays = add / (24 * 60 * 60 * 1000);
									System.out.println(addDays + " days ");
									if (Long.valueOf(addDays) <= Long.valueOf(maxDay)) {
										count1=1;
									}
									else if(Long.valueOf(maxDay)==0L){
										return "should not be greater than sysdate";
									}
									else{
										return "should not be greater than "+maxDay+" Days";
									}
								}
								if(count1==1 && count==1){
									return "true";
								}

								else {
									System.out.println("Inside equal Days");
									if (userDate.getTime() == systemDate.getTime()) {
										return "true";
									}
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			return "false";
		}
		return "false";


	}
	public static boolean validateTimeStamp(String inputString)
	{ 
	    SimpleDateFormat format = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	    try{
	       format.parse(inputString);
	       return true;
	    }
	    catch(ParseException e)
	    {
	    	SimpleDateFormat format1 = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm");
		    try{
		       format1.parse(inputString);
		       return true;
		    }
		    catch(ParseException e1)
		    {
		    	return false;
		    }
	    }
	}


	//to check input string length
	/**
	 * @description - To check input string length
	 * @param value
	 * @param length
	 * @return boolean
	 */

	public static boolean checkStringLength(String value, String minLength,String maxLength,List newlist){
		int count = 0;
		if(newlist!=null && newlist.size()>0 && newlist.contains(value)){
			count++;

		}
		if(newlist == null || newlist.size() == 0){
			if(!CommonValidator.isNull(value) && minLength == null && maxLength !=  null){

				if(value.length()<=Integer.parseInt(maxLength)){
					count++;
				}

			}
			if(!CommonValidator.isNull(value) && minLength!= null && maxLength ==null){

				if(value.length()>=Integer.parseInt(minLength)){
					count++;
				}

			}

			if(!CommonValidator.isNull(value) && minLength!= null  && maxLength!= null 
					&& value.length()>=Integer.parseInt(minLength) && value.length()<=Integer.parseInt(maxLength)){


				count++;
			}
		}
		if(minLength== null && maxLength ==null && (newlist==null || newlist.size() == 0)){
			count++;
		}


		if(count == 0){
			return false;
		}
		else{
			return true;
		}

	}
	public static String getStringBeforeDecimal(String value){

		CharSequence dot=".";
		String subStr=null;
		String sub1=null;

		try {
			if(!CommonValidator.isNull(value) && value.contains(dot)){

				int strNew=value.indexOf('.');
				subStr=value.substring(0, strNew);
				sub1=value.substring(strNew+1, value.length());
				Long.parseLong(subStr);
				Long.parseLong(sub1);
				long val=Long.valueOf(sub1);

				if(val==0){
					return subStr;
				}
				else
					return value;

			}
			else		
				return value;
		} catch (NumberFormatException e) {

			return value;
		}
	}
	/*	public static boolean dateCheck(String dateToValidate, String minDay, String maxDay, String dateFromat) {
		try {
			if(!isNull(dateToValidate) && !isNull(dateFromat) && isNull(minDay) && isNull(maxDay)){
				String datevalue=dateToValidate+" 00:00:00.00";

				String dateform=dateFromat+" HH:mm:ss.SS";
				//System.out.println(dateform);
				DateFormat dateFormat = new SimpleDateFormat(dateform);
				Date sysDate = new Date();

				Date userDate = null;
				Date systemDate = null;
				userDate = dateFormat.parse(datevalue);
				systemDate = dateFormat.parse(dateFormat.format(sysDate));

				if(userDate.getTime()>systemDate.getTime()){
					return false;
				}
			}

		} catch (ParseException e1) {
			return false;
		}
		return true;
	}
	 */
	public static boolean dateCheck(String dateToValidate, String minDay, String maxDay, String dateFromat,String fileIdentifier){


		SimpleDateFormat sdf;


		if(isNull(dateToValidate)){
			return false;
		}
		if(isNull(dateFromat)){
			dateFromat="dd-MM-yyyy";
		}
		dateFromat=dateFromat.toLowerCase();
		String newDateFormat=null;
		try {

			if(isNull(minDay) && isNull(maxDay)){

				newDateFormat=dateFromat.replace('m', 'M');
				sdf = new SimpleDateFormat(newDateFormat);
				sdf.setLenient(false);


				Date date1 = sdf.parse(dateToValidate);
				Date systemDate = new Date();
				// Date sysDate = sdf.parse("2010-01-31");
				Date sysDate = sdf.parse(sdf.format(systemDate));

				System.out.println("date1 : " + sdf.format(date1));
				System.out.println("sysDate : " + sdf.format(sysDate));
				/*
				if (date1.compareTo(sysDate) > 0) {
					System.out.println("Date1 is after Sysdate");
					return false;
				} 
				else*/
				return true;

			}
			else{

				newDateFormat=dateFromat.replace('m', 'M');
				System.out.println("newDateFormat-->> "+newDateFormat);
				SimpleDateFormat dateFormat = new SimpleDateFormat(newDateFormat);
				dateFormat.setLenient(false);
				Date sysDate = new Date();
				int count=0;
				int count1=0;

				Date userDate = null;
				Date systemDate = null;

				if (!CommonValidator.isNull(dateToValidate) && !CommonValidator.isNull(dateFromat)) {
					if(!isNull(minDay) || !isNull(maxDay)){

						userDate = dateFormat.parse(dateToValidate);
						systemDate = dateFormat.parse(dateFormat.format(sysDate));


						if(isNull(minDay) && !isNull(maxDay)){

							System.out.println("Inside Max Days");
							long add = userDate.getTime() - systemDate.getTime();
							long addDays = add / (24 * 60 * 60 * 1000);
							System.out.println(addDays + " days ");
							if (Long.valueOf(addDays) <= Long.valueOf(maxDay)) {
								return true;
							}

						}
						if(isNull(maxDay) && !isNull(minDay)){

							if (systemDate.getTime() > userDate.getTime()) {

								System.out.println("Inside Min Days");
								long diff = systemDate.getTime() - userDate.getTime();

								long diffDays = diff / (24 * 60 * 60 * 1000);
								System.out.println(diffDays + " days ");
								if (Long.valueOf(diffDays) <= Long.valueOf(minDay)) {
									return true;
								}
							}
							else if(userDate.getTime() == systemDate.getTime()){
								System.out.println("Inside equal Days");
								return true;

							}
							else 
								return true;

						}
						if(!isNull(minDay) && !isNull(maxDay)){
							int x=Integer.valueOf(minDay)+Integer.valueOf(maxDay);

							if(x>=0){

								if (!isNull(minDay)) {

									System.out.println("Inside Min Days");
									long diff = systemDate.getTime() - userDate.getTime();

									long diffDays = diff / (24 * 60 * 60 * 1000);
									System.out.println(diffDays + " days ");

									if (Long.valueOf(diffDays) <= Long.valueOf(minDay)) {
										count=1;
									}
								} if (!isNull(maxDay)) {
									System.out.println("Inside Max Days");
									long add = userDate.getTime() - systemDate.getTime();
									long addDays = add / (24 * 60 * 60 * 1000);
									System.out.println(addDays + " days ");
									if (Long.valueOf(addDays) <= Long.valueOf(maxDay)) {
										count1=1;
									}
								}
								if(count1==1 && count==1){
									return true;
								}

								else {
									System.out.println("Inside equal Days");
									if (userDate.getTime() == systemDate.getTime()) {
										return true;
									}
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			return false;
		}
		return false;


		//return true;
	}
	/*public static boolean checkInteger(String value,String minRange,String maxRange,List<Integer> newlist){

		int count = 0;
		if(!CommonValidator.isNull(value) && newlist!=null && newlist.size()>0 && newlist.contains(value)){
			count++;

		}
		if(!CommonValidator.isNull(value) && newlist!=null && newlist.size()>0 && newlist.contains(value)){

			return true;

		}
		 
		if(newlist == null || newlist.size() == 0){
			if(!CommonValidator.isNull(value) ){

				int longVal=Integer.valueOf(value);


				if(!CommonValidator.isNull(minRange) && !CommonValidator.isNull(maxRange) && 
						longVal >= Integer.valueOf(minRange) && longVal <= Integer.valueOf(maxRange)){

					count++;


				}
				if(CommonValidator.isNull(maxRange) && !CommonValidator.isNull(minRange) && longVal >= Integer.valueOf(minRange)){

					count++;
				}
				if(CommonValidator.isNull(minRange) && !CommonValidator.isNull(maxRange) && longVal <= Integer.valueOf(maxRange)){

					count++;
				}

				if(CommonValidator.isNull(minRange)  && CommonValidator.isNull(maxRange) ){

					count++;
				}

			}
		}

		if(count == 0){
			return false;
		}
		else{
			return true;
		}
	}

	public static boolean checkLong(String value,String minRange,String maxRange,List<Long> newlist){


		if(!CommonValidator.isNull(value) && newlist!=null && newlist.size()>0 && newlist.contains(value)){

			return true;

		}

		if(!CommonValidator.isNull(value) && Pattern.matches("\\d*", value)){

			long longVal=Long.valueOf(value);


			if(!CommonValidator.isNull(minRange) && !CommonValidator.isNull(maxRange) && 
					longVal >= Integer.valueOf(minRange) && longVal <= Integer.valueOf(maxRange)){

				return true;


			}
			if(CommonValidator.isNull(maxRange) && !CommonValidator.isNull(minRange) && longVal >= Integer.valueOf(minRange)){

				return true;
			}
			if(CommonValidator.isNull(minRange) && !CommonValidator.isNull(maxRange) && longVal <= Integer.valueOf(maxRange)){

				return true;
			}

			if(CommonValidator.isNull(minRange)  && CommonValidator.isNull(maxRange) ){

				return true;
			}

		}


		return false;
	}*/

	
public static boolean checkInteger(String value,String minRange,String maxRange,List<Integer> newlist){
		
		int count = 0;
		if(!CommonValidator.isNull(value) && newlist!=null && newlist.size()>0 && newlist.contains(value)){
			count++;

		}
		/*if(!CommonValidator.isNull(value) && newlist!=null && newlist.size()>0 && newlist.contains(value)){

			return true;

		}
		 */
		if(newlist == null || newlist.size() == 0){
			
			if(!CommonValidator.isNull(value) ){

				int longVal=Integer.valueOf(value);


				if(!CommonValidator.isNull(minRange) && !CommonValidator.isNull(maxRange) && 
						longVal >= Integer.valueOf(minRange) && longVal <= Integer.valueOf(maxRange)){

					count++;


				}
				if(CommonValidator.isNull(maxRange) && !CommonValidator.isNull(minRange) && longVal >= Integer.valueOf(minRange)){

					count++;
				}
				if(CommonValidator.isNull(minRange) && !CommonValidator.isNull(maxRange) && longVal <= Integer.valueOf(maxRange)){

					count++;
				}

				if(CommonValidator.isNull(minRange)  && CommonValidator.isNull(maxRange) ){

					count++;
				}

			}
		}

		if(count == 0){
			return false;
		}
		else{
			return true;
		}
		
	}
	
	
	 public static boolean checkLong(String value,String minRange,String maxRange,List<Long> newlist){
			
			int count = 0;
			if(!CommonValidator.isNull(value) && newlist!=null && newlist.size()>0 && newlist.contains(value)){
				count++;

			}
			/*if(!CommonValidator.isNull(value) && newlist!=null && newlist.size()>0 && newlist.contains(value)){

				return true;

			}
			 */
			if(newlist == null || newlist.size() == 0){
				
				if(!CommonValidator.isNull(value) ){

					Long longVal=Long.valueOf(value);


					if(!CommonValidator.isNull(minRange) && !CommonValidator.isNull(maxRange) && 
							longVal >= Long.valueOf(minRange) && longVal <= Long.valueOf(maxRange)){

						count++;


					}
					if(CommonValidator.isNull(maxRange) && !CommonValidator.isNull(minRange) && longVal >= Long.valueOf(minRange)){

						count++;
					}
					if(CommonValidator.isNull(minRange) && !CommonValidator.isNull(maxRange) && longVal <= Long.valueOf(maxRange)){

						count++;
					}

					if(CommonValidator.isNull(minRange)  && CommonValidator.isNull(maxRange) ){

						count++;
					}

				}
			}

			if(count == 0){
				return false;
			}
			else{
				return true;
			}
			
		}



	/**
	 * @description  For double Mobile number validations Mainly
	 * @param numDouble
	 * @param minValue
	 * @param maxValue
	 * @return true or false
	 */
	public static boolean isValidMobileNumber(String numDouble, String minValue, String maxValue, List newlist) {
		//System.out.println("mob"+numDouble+minValue+maxValue);
		try {

			double d = Double.parseDouble(numDouble);
			long number=(long) d;
			//System.out.println(number);
			String value=Long.toString(number);

			if(newlist!=null && newlist.size()>0 && newlist.contains(value)){
				return true;

			}
			System.out.println("here"+Long.valueOf(value)+Long.parseLong(minValue));
			if(!CommonValidator.isNull(value) && Long.valueOf(value)>=Long.parseLong(minValue) && Long.valueOf(value)<=Long.parseLong(maxValue) ){
				System.out.println("here");
				return true;
			}
			else
				return false;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	public static boolean isNumberDouble(String doubleVal,String minRange,String maxRange,List newlist){
		//System.out.println(doubleVal + " "+minRange +" "+maxRange );
		try {


			if(!CommonValidator.isNull(doubleVal)){

				if(newlist!=null && newlist.size()>0 && newlist.contains(doubleVal)){
					return true;

				}

				Double.parseDouble(doubleVal);
				double num=Double.valueOf(doubleVal);

				DecimalFormat df1=new DecimalFormat("#0");
				//checking the decimal points only two digits are allowed after decimal place
				DecimalFormat df2=new DecimalFormat("#0.0");

				String str1=df1.format(num*100);
				Double d1=Double.parseDouble(str1);
				String str2=df2.format(num*100);
				Double d2=Double.parseDouble(str2);

				if (d1.equals(d2) ){

					//System.out.println("success "+str1 + " " + str2);

					if(!CommonValidator.isNull(minRange) && !CommonValidator.isNull(maxRange)){

						Double.parseDouble(minRange);
						Double.parseDouble(maxRange);

						double minNumber=Double.valueOf(minRange);
						double maxNumber=Double.valueOf(maxRange);
						int retMinVal=Double.compare(minNumber, num);
						int retMaxVal=Double.compare(maxNumber, num);

						if(retMinVal<=0 && retMaxVal>=0){

							return true;
						}

					}
					if(!CommonValidator.isNull(minRange) && CommonValidator.isNull(maxRange)){

						Double.parseDouble(minRange);
						double minNumber=Double.valueOf(minRange);

						int retMinVal=Double.compare(minNumber, num);


						if(retMinVal<=0){

							return true;
						}

					}
					if(!CommonValidator.isNull(maxRange) && CommonValidator.isNull(minRange)){

						Double.parseDouble(maxRange);
						double maxNumber=Double.valueOf(maxRange);

						int retMaxVal=Double.compare(maxNumber, num);

						if(retMaxVal>=0){

							return true;
						}
					}

					if(CommonValidator.isNull(minRange)  && CommonValidator.isNull(maxRange) ){

						return true;
					}

				}
			} 
		}catch (NumberFormatException e) {

			return false;
		}

		return false;

	}

	/**
	 * @description - String with characters only ,No special character and No digits are allowed
	 * @param value
	 * @param minLength
	 * @param maxLength
	 * @param newlist
	 * @return boolean value
	 */
	public static boolean stringCharacterCheck(String value,String minLength, String maxLength, List newlist){

		try {
			if (!CommonValidator.isNull(value) && newlist != null && newlist.size() > 0 && newlist.contains(value)) {

				return true;

			}

			if (!CommonValidator.isNull(value) && Pattern.matches("^[a-zA-Z\\s]*$", value)) {

				if (!CommonValidator.isNull(minLength) && !CommonValidator.isNull(maxLength)
						&& value.length() >= Integer.valueOf(minLength) && value.length() <= Integer.valueOf(maxLength)) {

					return true;

				}
				if (CommonValidator.isNull(minLength) && !CommonValidator.isNull(maxLength)
						&& value.length() <= Integer.valueOf(maxLength)) {
					return true;
				}
				if (CommonValidator.isNull(maxLength) && !CommonValidator.isNull(minLength)
						&& value.length() >= Integer.valueOf(minLength)) {

					return true;
				}

				if (CommonValidator.isNull(minLength) && CommonValidator.isNull(maxLength)) {

					return true;
				}

			}

			return false;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	//only characters allowed from Geeta
	/**
	 * @description - String with digits only ,No special character and No characters are allowed
	 * @param value
	 * @param minLength
	 * @param maxLength
	 * @param newlist
	 * @return
	 */
	public static boolean stringIntegersCheck(String value, String minLength, String maxLength, List newlist) {

		try {
			if (!CommonValidator.isNull(value) && newlist != null && newlist.size() > 0 && newlist.contains(value)) {

				return true;

			}

			if (!CommonValidator.isNull(value) && Pattern.matches("\\d*", value)) {

				if (!CommonValidator.isNull(minLength) && !CommonValidator.isNull(maxLength)
						&& value.length() >= Integer.valueOf(minLength) && value.length() <= Integer.valueOf(maxLength)) {

					return true;

				}
				if (CommonValidator.isNull(minLength) && !CommonValidator.isNull(maxLength)
						&& value.length() <= Integer.valueOf(maxLength)) {
					return true;
				}
				if (CommonValidator.isNull(maxLength) && !CommonValidator.isNull(minLength)
						&& value.length() >= Integer.valueOf(minLength)) {

					return true;
				}

				if (CommonValidator.isNull(minLength) && CommonValidator.isNull(maxLength)) {

					return true;
				}

			}

			return false;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	/**
	 * @description - String without special Character Alphanumeric
	 * @param value
	 * @return boolean
	 */
	public static boolean stringWithoutSepcialChar(String value,String minLength,String maxLength,List newList){

		value=value.replaceAll("\\s+", "");
		if(!CommonValidator.isNull(value)){

			return Pattern.matches("\\w*", value);

		}
		else 
			return false;

	}

	public static void main(String[] args) {
		//String dateToValidate="20-12-2017";
		//String dateFromat="dd-MM-yyyy";
		//CommonValidator.dateCheck(dateToValidate, "", "", dateFromat, "BRECS");
		
		
		String dateRegex="[0-9][0-9][\\/][0-9][0-9][\\/][0-9]{4}";
		String dateString="10/04/2018";
		if(!(dateString.matches(dateRegex)))
		{
			System.out.println("hello");
		}
		System.out.println("hello"+dateString.length());
		//boolean value=stringWithoutSepcialChar("geeta!js234");
		//System.out.println(value);

	}
	public static boolean checkIFSCCode(String ifscCode){

		if(!CommonValidator.isNull(ifscCode)){
			return Pattern.matches("[A-Z|a-z]{4}[0][\\d]{6}$", ifscCode);
		}
		else 
			return false;
	}
	/**
	 * @description - String with characters only ,No special character and No digits are allowed
	 * @param value
	 * @return boolean
	 */
	public static boolean characterStringCheck(String value){

		return Pattern.matches("[A-Z|a-z]{1,}", value);
	}


	/**
	 * @description - only Date validation no time stamp
	 * @param dateToValidate
	 * @param dateFromat
	 * @return boolean
	 * @throws ParseException 
	 */

	public static List getListFromCommaSeparatedString(String commaSeparated){
		List<String> list=new ArrayList<String>();
		list = null;
		if(commaSeparated!=null){
			commaSeparated = commaSeparated.trim();
			commaSeparated=commaSeparated.toUpperCase();
			//String[] animalsArray = commaSeparated.split("\\s*, \\s*");
			String[] animalsArray = commaSeparated.split(",");
			String[] animalsArray1=new String[animalsArray.length];
			for(int i=0;i<animalsArray.length;i++){

				animalsArray1[i]=animalsArray[i].trim();
			}

			list=new ArrayList<String>();
			for(int i=0;i<animalsArray1.length;i++){
				list.add(animalsArray1[i]);

			}


		}
		return list;
	}

	public static boolean dateCheck(String dateToValidate,String dateFromat){


		int monthIndex=0;
		int dayIndex=0;
		int yearIndex=0;

		if(dateFromat.length()==10 || dateFromat.equalsIgnoreCase("ddmmyyyy") 
				|| dateFromat.equalsIgnoreCase("mmddyyyy") || dateFromat.equalsIgnoreCase("yyyymmdd")
				|| dateFromat.equalsIgnoreCase("yyyyddmm")){

			for(int i=0;i<dateFromat.length();i++){

				if(dateFromat.charAt(i)=='m' || dateFromat.charAt(i)=='M'){

					monthIndex=i;
					break;
				}

			}
			for(int i=0;i<dateFromat.length();i++){

				if(dateFromat.charAt(i)=='d' || dateFromat.charAt(i)=='D'){

					dayIndex=i;
					break;
				}

			}
			for(int i=0;i<dateFromat.length();i++){

				if(dateFromat.charAt(i)=='y' || dateFromat.charAt(i)=='Y'){

					yearIndex=i;
					break;
				}

			}

			//fetching day
			String day=dateToValidate.substring(dayIndex, dayIndex+2);
			//System.out.println("day-->>"+day);
			//fetch month
			String month=dateToValidate.substring(monthIndex,monthIndex+2);
			//System.out.println("month-->>"+month);
			//fetching year
			String year=dateToValidate.substring(yearIndex, yearIndex+4);
			//System.out.println("year-->>"+year);

			if(Long.valueOf(month)<0 || Long.valueOf(month)>12){
				//System.out.println("incorrect month value");
				return false;
			}

			if(Long.valueOf(day)<0 || Long.valueOf(day)>31){
				//System.out.println("incorrect day value");
				return false;
			}


			if (day.equals("31") &&
					(month.equals("4") || month .equals("6") || month.equals("9") ||
							month.equals("11") || month.equals("04") || month .equals("06") ||
							month.equals("09"))) {
				return false; // only 1,3,5,7,8,10,12 has 31 days
			} else if (month.equals("2") || month.equals("02")) {
				//leap year
				if(Long.valueOf(year) % 4==0){
					if(day.equals("30") || day.equals("31")){
						return false;
					}else{
						return true;
					}
				}else{
					if(day.equals("29")||day.equals("30")||day.equals("31")){
						return false;
					}else{
						return true;
					}
				}
			}else{
				return true;
			}



		}
		else 
		{
			//System.out.println("Invalid date pattern");
			return false;
		}


	}


	public static boolean isLong(String value) {
		try {
			Long.parseLong(value);
		} catch (Exception e) {
			return false;
		}
		return true;
	}
	public static boolean isDouble(String value){

		try {
			Double.parseDouble(value);
		} catch (Exception e) {
			return false;
		}
		return true;

	}


	/**
	 * This method validates the given time stamp in String format ,format should be "yyyy-MM-dd HH:mm:ss"
	 * @param timestamp
	 * @return boolean value
	 */

	public static boolean isTimeStampValid(String timestamp) {
		//(Considering that formal will be yyyy-MM-dd HH:mm:ss )
		//Tokenize string and separate date and time
		boolean time = false;
		try {
			//Tokenize string and separate date and time
			StringTokenizer st = new StringTokenizer(timestamp, " ");

			if (st.countTokens() != 2) {
				return false;
			}

			String[] dateAndTime = new String[2];

			int i = 0;
			while (st.hasMoreTokens()) {
				dateAndTime[i] = st.nextToken();
				i++;
			}

			String timeToken = dateAndTime[1];

			StringTokenizer timeTokens = new StringTokenizer(timeToken, ":");
			if (timeTokens.countTokens() != 3) {
				return false;
			}

			String[] timeAt = new String[4];
			int j = 0;
			while (timeTokens.hasMoreTokens()) {
				timeAt[j] = timeTokens.nextToken();
				j++;
			}
			try {
				int HH = Integer.valueOf(timeAt[0].toString());
				int mm = Integer.valueOf(timeAt[1].toString());
				float ss = Float.valueOf(timeAt[2].toString());


				if (HH < 60 && HH >= 0 && mm < 60 && mm >= 0 && ss < 60 && ss >= 0) {
					time = true;
				} else {
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			//Got Date
			String dateToken = dateAndTime[0];//st.nextToken();

			//Tokenize separated date and separate year-month-day
			StringTokenizer dateTokens = new StringTokenizer(dateToken, "-");
			if (dateTokens.countTokens() != 3) {
				return false;
			}
			String[] tokenAt = new String[3];

			//This will give token string array with year month and day value.
			int k = 0;
			while (dateTokens.hasMoreTokens()) {
				tokenAt[k] = dateTokens.nextToken();
				k++;
			}

			//Now try to create new date with got value of date
			int dayInt = Integer.parseInt(tokenAt[2]);
			int monthInt = Integer.parseInt(tokenAt[1]);
			int yearInt = Integer.parseInt(tokenAt[0]);
			Calendar cal = new GregorianCalendar();
			cal.setLenient(false);
			cal.set(yearInt, monthInt - 1, dayInt);
			cal.getTime();//If not able to create date it will throw error



		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		//Here we ll check for correct format is provided else it ll return false
		try {
			Pattern p = Pattern.compile("^\\d{4}[-]?\\d{1,2}[-]?\\d{1,2} \\d{1,2}:\\d{1,2}:\\d{1,2}$");//[.]?\\d{1,6}$");
			if (p.matcher(timestamp).matches()) {
			} else {
				return false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		String value=timestamp;
		int hour=value.indexOf(':');
		String hourValue=value.substring(hour-2, hour);
		String minuteValue=value.substring(hour+1, hour+3);
		String secValue=value.substring(hour+4, hour+6);
		//System.out.println("value-->>"+hour+" hourValue  "+hourValue+"minuteValue "+minuteValue +" secValue "+secValue);
		//Cross checking with simple date format to get correct time stamp only
		if(Integer.parseInt(hourValue)>23 || Integer.parseInt(minuteValue)>59 || Integer.parseInt(secValue)>59){

			return false;
		}
		SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			format.parse(timestamp);
			//return true;

			if (time) {
				return true;
			} else {
				return false;
			}
		} catch (ParseException e) {
			e.printStackTrace();
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}
	/**
	 * @description - To get the system date
	 * @param format
	 * @return
	 */
	public static String getSystemDate(String format){
		DateFormat dateFormat = new SimpleDateFormat(format);
		Date date = new Date();
		String currentDate=dateFormat.format(date);
		//System.out.println(dateFormat.format(date));
		return currentDate;

	}

	/**
	 * @description 	
	 * @param value
	 * @return boolean
	 *//*

//to check number only digits are allowed //format is like (10,2)

	public static boolean checkNumber(String value,Long minRange,Long maxRange,List newlist){

		if(newlist!=null && newlist.size()>0 && newlist.contains(value)){
			return true;

		}
		if(!CommonValidator.isNull(value) && Pattern.matches("\\d*", value)){

			long longVal=Long.valueOf(value);
			if(minRange!=null && minRange < 1){
				return false;

			}
			if(minRange!=null && maxRange!=null && longVal >= minRange && longVal <= maxRange){

				return true;
			}
			if(minRange!=null && maxRange==null && longVal >= minRange){

				return true;
			}
			if(minRange==null && maxRange!=null && longVal <= maxRange){

				return true;
			}
			if(minRange==null && maxRange==null){

				return true;
			}
			else
				return false;

		}
		return false;

	}

	public static boolean checkDouble(String value,int decimalDigit){

		String newValue=null;
		System.out.println("decimalDigit "+decimalDigit);

		try {
			Double doub=Double.parseDouble(value);
			System.out.println("doub length-> "+doub);
			value=String.valueOf(doub);

			System.out.println("value length-> "+value);
			int index=value.indexOf(".");
			if(index>=0 && !CommonValidator.isNull(value)){

				System.out.println("Index-> "+index);
				newValue=value.substring(index+1, value.length());
				System.out.println("newvalue-->> "+newValue);
				value=value.substring(0, index);
				if(newValue.length()==decimalDigit){
					return true;
				}

			}

		} catch (NumberFormatException e) {
			return false;
		}
		return false;


	}*/
	// String without special Character Alphanumeric
	/**
	 * Reading from CSV File and copying into xls file and NEW xls file will also get created
	 * @param csvFileName
	 * @param xlsFileName
	 * @return 
	 * @throws IOException
	 *//*
	public void csv2XlsFileConversion(String csvFileName,String xlsFileName) throws IOException{

		Workbook wb = new HSSFWorkbook();
        CreationHelper helper = wb.getCreationHelper();
        Sheet sheet = wb.createSheet("new sheet");

        CSVReader reader = new CSVReader(new FileReader("C:/Users/a1famhst/Desktop/FL_insurance_samplee.csv"));
        String[] line;
        int r = 0;
        while ((line = reader.readNext()) != null) {
            Row row = sheet.createRow((short) r++);

            for (int i = 0; i < line.length; i++)
                row.createCell(i)
                   .setCellValue(helper.createRichTextString(line[i]));
        }

        // Write the output to a file
        FileOutputStream fileOut = new FileOutputStream("C:/Users/a1famhst/Desktop/workbook.xls");
        wb.write(fileOut);
        fileOut.close();
        reader.close();

	}*/

	public void dateConversion(String valueofdate){
		//  String input = "Thu Jun 18 20:56:02 EDT 2009";
		// SimpleDateFormat parser = new SimpleDateFormat("EEE MMM d HH:mm:ss zzz yyyy");
		// Date date = parser.parse(input);
		//  SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		//  String formattedDate = formatter.format(date);
		Date value=null;
		String[] formatStrings = {"dd-MMM-yyyy", "MM/dd/yyyy", "yyyy/MM/dd"};
		// ...
		//  String dateString="MM/dd/yyyy";
		for (String formatString : formatStrings)
		{
			try
			{
				value= new SimpleDateFormat(formatString).parse(valueofdate);
			}
			catch (ParseException e) {}
		}
		//System.out.println("---->>"+value);

	}

	public static boolean stringNumber(String value, String minLength, String maxLength) {

		System.out.println("iNSIDE number COMMON vALIDATOR-->> "+value);

		int index=-2;
		index=value.indexOf("-");
		if(index==0){
			System.out.println(value);
			value=value.substring(1, value.length());
			System.out.println(value);
		}


		if (Pattern.matches("\\d*", value)) {

			if (!CommonValidator.isNull(minLength) && !CommonValidator.isNull(maxLength)
					&& value.length() >= Integer.valueOf(minLength) && value.length() <= Integer.valueOf(maxLength)) {

				return true;

			}
			if (CommonValidator.isNull(minLength) && !CommonValidator.isNull(maxLength)
					&& value.length() <= Integer.valueOf(maxLength)) {
				return true;
			}
			if (CommonValidator.isNull(maxLength) && !CommonValidator.isNull(minLength)
					&& value.length() >= Integer.valueOf(minLength)) {

				return true;
			}

			if (CommonValidator.isNull(minLength) && CommonValidator.isNull(maxLength)) {

				return true;
			}

		}

		return false;

	}


}


