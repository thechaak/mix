package com.airtel.acecad.bulkupload.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.servlet.http.HttpSession;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import com.airtel.acecad.bulkupload.dao.FileUploadDao;
import com.airtel.acecad.bulkupload.dao.FileUploadDaoImpl;
import com.airtel.acecad.bulkupload.uploadfile.ExcelReader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
/*import org.apache.log4j.Logger;
import org.apache.logging.log4j.LogManager;*/
 /*
  * @Author : Shaleen Agarwal
  * */
public class BulkUtilValidations {

	public HttpSession session;
	//private static Logger log = Logger.getLogger(BulkUtilValidations.class);
	private static Logger log = LogManager.getLogger("apsbulkUploadLog");
	
	public static String validateUploadedFile(String filename) {
		
		log.info("START : method validateUploadedFile of BulkUtilValidations");
		String extension = filename.substring(filename.lastIndexOf(".") + 1, filename.length());
		String excel = "xls";
		String excelx = "xlsx";
		String csv = "csv";
		if (extension.equalsIgnoreCase(excel)) {
			log.info("END : method validateUploadedFile of BulkUtilValidations");
			return excel;
		} else if (extension.equalsIgnoreCase(excelx)) {
			log.info("END : method validateUploadedFile of BulkUtilValidations");
			return excelx;
		}else if(extension.equalsIgnoreCase(csv)){
			return csv;
		} else{
			log.info("END : method validateUploadedFile of BulkUtilValidations");
			return extension;
		}	
		
	}
	public static int sum (List<Integer> list) {
	    int sum = 0;
	    for (int i: list) {
	        sum += i;
	    }
	    return sum;
	}
	
	
	  public static void main(String[] args) {
	      String sampleString = "101,203,405";
	      String[] stringArray = sampleString.split(",");
	      int[] intArray = new int[stringArray.length];
	      for (int i = 0; i < stringArray.length; i++) {
	         String numberAsString = stringArray[i];
	         intArray[i] = Integer.parseInt(numberAsString);
	      }
	      System.out.println("Number of integers: " + intArray.length);
	      System.out.println("The integers are:");
	      for (int number : intArray) {
	         System.out.println(number);
	      }
	   }

}