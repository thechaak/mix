package com.airtel.acecad.bulkupload.dto;

import java.sql.Timestamp;
import java.util.Date;

public class NeftPaymentDetails {

	
	int fileId;
	String utrNo;
	String incomingTransactionRefNo;
	Date valueDate;
	Double amount;
	String receivingAccRBI1;
	
	String receivingAccRcvdFromRBI2;
	String validPrefixReceived;
	String validLengthReceived;
	String validRemitterIdReceived;
	String validRemitterAccountReceived;
	String fundsCredited;
	String receivingAccNo;
	String receivingName;
	String receivingAccType;
	String gl;
	String receiverIfsc;
	String uploadTime;
	String status;
	String remitterAccNo;
	String remitterBranch;
	String remitterName;
	String remitterAccType;
	String remitterIfsc;
	String refNo;
	String productType;
	String paymentDetails1;
	String paymentDetails2;
	String paymentDetails3;
	Double actualAmountReceived;
    String paymentExchangeRate;
    String paymentCurrency;
	Timestamp createdDate;
	Timestamp modifiedDate;
	String trackingId;
	String trackinIdServ;
	String statusCode;
	String statusDescription;
	String sentFxFlag;
	String noOfHit;
	String userId;
	public int getFileId() {
		return fileId;
	}
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}
	public String getUtrNo() {
		return utrNo;
	}
	public String getReceivingAccRBI1() {
		return receivingAccRBI1;
	}
	public void setReceivingAccRBI1(String receivingAccRBI1) {
		this.receivingAccRBI1 = receivingAccRBI1;
	}
	public void setUtrNo(String utrNo) {
		this.utrNo = utrNo;
	}
	public String getIncomingTransactionRefNo() {
		return incomingTransactionRefNo;
	}
	public void setIncomingTransactionRefNo(String incomingTransactionRefNo) {
		this.incomingTransactionRefNo = incomingTransactionRefNo;
	}
	public Date getValueDate() {
		return valueDate;
	}
	public void setValueDate(Date valueDate) {
		this.valueDate = valueDate;
	}
	
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getReceivingAccRcvdFromRBI2() {
		return receivingAccRcvdFromRBI2;
	}
	public void setReceivingAccRcvdFromRBI2(String receivingAccRcvdFromRBI2) {
		this.receivingAccRcvdFromRBI2 = receivingAccRcvdFromRBI2;
	}
	public String getValidPrefixReceived() {
		return validPrefixReceived;
	}
	public void setValidPrefixReceived(String validPrefixReceived) {
		this.validPrefixReceived = validPrefixReceived;
	}
	public String getValidLengthReceived() {
		return validLengthReceived;
	}
	public void setValidLengthReceived(String validLengthReceived) {
		this.validLengthReceived = validLengthReceived;
	}
	public String getValidRemitterIdReceived() {
		return validRemitterIdReceived;
	}
	public void setValidRemitterIdReceived(String validRemitterIdReceived) {
		this.validRemitterIdReceived = validRemitterIdReceived;
	}
	public String getValidRemitterAccountReceived() {
		return validRemitterAccountReceived;
	}
	public void setValidRemitterAccountReceived(String validRemitterAccountReceived) {
		this.validRemitterAccountReceived = validRemitterAccountReceived;
	}
	public String getFundsCredited() {
		return fundsCredited;
	}
	public void setFundsCredited(String fundsCredited) {
		this.fundsCredited = fundsCredited;
	}
	public String getReceivingAccNo() {
		return receivingAccNo;
	}
	public void setReceivingAccNo(String receivingAccNo) {
		this.receivingAccNo = receivingAccNo;
	}
	public String getReceivingName() {
		return receivingName;
	}
	public void setReceivingName(String receivingName) {
		this.receivingName = receivingName;
	}
	public String getReceivingAccType() {
		return receivingAccType;
	}
	public void setReceivingAccType(String receivingAccType) {
		this.receivingAccType = receivingAccType;
	}
	public String getGl() {
		return gl;
	}
	public void setGl(String gl) {
		this.gl = gl;
	}
	public String getReceiverIfsc() {
		return receiverIfsc;
	}
	public void setReceiverIfsc(String receiverIfsc) {
		this.receiverIfsc = receiverIfsc;
	}
	public String getUploadTime() {
		return uploadTime;
	}
	public void setUploadTime(String uploadTime) {
		this.uploadTime = uploadTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemitterAccNo() {
		return remitterAccNo;
	}
	public void setRemitterAccNo(String remitterAccNo) {
		this.remitterAccNo = remitterAccNo;
	}
	public String getRemitterBranch() {
		return remitterBranch;
	}
	public void setRemitterBranch(String remitterBranch) {
		this.remitterBranch = remitterBranch;
	}
	public String getRemitterName() {
		return remitterName;
	}
	public void setRemitterName(String remitterName) {
		this.remitterName = remitterName;
	}
	public String getRemitterAccType() {
		return remitterAccType;
	}
	public void setRemitterAccType(String remitterAccType) {
		this.remitterAccType = remitterAccType;
	}
	public String getRemitterIfsc() {
		return remitterIfsc;
	}
	public void setRemitterIfsc(String remitterIfsc) {
		this.remitterIfsc = remitterIfsc;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getPaymentDetails1() {
		return paymentDetails1;
	}
	public void setPaymentDetails1(String paymentDetails1) {
		this.paymentDetails1 = paymentDetails1;
	}
	public String getPaymentDetails2() {
		return paymentDetails2;
	}
	public void setPaymentDetails2(String paymentDetails2) {
		this.paymentDetails2 = paymentDetails2;
	}
	public String getPaymentDetails3() {
		return paymentDetails3;
	}
	public void setPaymentDetails3(String paymentDetails3) {
		this.paymentDetails3 = paymentDetails3;
	}
	
	public Double getActualAmountReceived() {
		return actualAmountReceived;
	}
	public void setActualAmountReceived(Double actualAmountReceived) {
		this.actualAmountReceived = actualAmountReceived;
	}
	public String getPaymentExchangeRate() {
		return paymentExchangeRate;
	}
	public void setPaymentExchangeRate(String paymentExchangeRate) {
		this.paymentExchangeRate = paymentExchangeRate;
	}
	public String getPaymentCurrency() {
		return paymentCurrency;
	}
	public void setPaymentCurrency(String paymentCurrency) {
		this.paymentCurrency = paymentCurrency;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	public String getTrackinIdServ() {
		return trackinIdServ;
	}
	public void setTrackinIdServ(String trackinIdServ) {
		this.trackinIdServ = trackinIdServ;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	public String getSentFxFlag() {
		return sentFxFlag;
	}
	public void setSentFxFlag(String sentFxFlag) {
		this.sentFxFlag = sentFxFlag;
	}
	public String getNoOfHit() {
		return noOfHit;
	}
	public void setNoOfHit(String noOfHit) {
		this.noOfHit = noOfHit;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
}
