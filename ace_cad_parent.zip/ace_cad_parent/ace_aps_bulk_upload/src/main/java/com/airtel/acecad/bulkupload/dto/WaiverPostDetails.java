package com.airtel.acecad.bulkupload.dto;

import java.util.Date;

public class WaiverPostDetails {
	
	private String product;
	private String issueRectified;
	private String adjReasonDet;
	private String subType;
	private String type;
	private String typeOfAdjustment;
	private String appLevel;
	private String appName;
	private String adjDescription;
	private String adjReasonCode;
	private int adjTransCode;
	
	private String amount;
	private String billRefNo;
	private String mobilelId;
	private String accountExternalId;
	private String segment;
	private String circle;
	private String lob;
	private String subSubType;
	private String typeOfWaiver;
	private String finalApprover;
	private String annotation;
	private String processIdentifier;
	
	private int standardReasonCode;
	private int lsiNo;
	
	private String chargeIdentifier;
	private Date anntToDate;
	private Date anntFromDate;
	
	private String taxamount;
	private String aeisamount;
	
	private String serviceExtIdType;
	private Date effectiveDate;
	private String billRefResets;
	private String trackingId;
	private String trackingIdServ;	
	private String waiverDesc;
	
	private String source;
	private String refNo;
	private String slno;
	private String remarks1;
	private String remarks2;
	
	/*
	 * private String modifiedDate; private String createdDate; private String
	 * statusCode; private String userId;
	 */
	
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public String getSlno() {
		return slno;
	}
	public void setSlno(String slno) {
		this.slno = slno;
	}
	public String getRemarks1() {
		return remarks1;
	}
	public void setRemarks1(String remarks1) {
		this.remarks1 = remarks1;
	}
	public String getRemarks2() {
		return remarks2;
	}
	public void setRemarks2(String remarks2) {
		this.remarks2 = remarks2;
	}
	public String getServiceExtIdType() {
		return serviceExtIdType;
	}
	public void setServiceExtIdType(String serviceExtIdType) {
		this.serviceExtIdType = serviceExtIdType;
	}
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getBillRefResets() {
		return billRefResets;
	}
	public void setBillRefResets(String billRefResets) {
		this.billRefResets = billRefResets;
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	public String getTrackingIdServ() {
		return trackingIdServ;
	}
	public void setTrackingIdServ(String trackingIdServ) {
		this.trackingIdServ = trackingIdServ;
	}
	public String getWaiverDesc() {
		return waiverDesc;
	}
	public void setWaiverDesc(String waiverDesc) {
		this.waiverDesc = waiverDesc;
	}
	public int getAdjTransCode() {
		return adjTransCode;
	}
	public String getSubSubType() {
		return subSubType;
	}
	public void setSubSubType(String subSubType) {
		this.subSubType = subSubType;
	}
	public void setAdjTransCode(int adjTransCode) {
		this.adjTransCode = adjTransCode;
	}
	
	public String getTypeOfWaiver() {
		return typeOfWaiver;
	}
	public void setTypeOfWaiver(String typeOfWaiver) {
		this.typeOfWaiver = typeOfWaiver;
	}
	public String getFinalApprover() {
		return finalApprover;
	}
	public void setFinalApprover(String finalApprover) {
		this.finalApprover = finalApprover;
	}
	public String getAnnotation() {
		return annotation;
	}
	public void setAnnotation(String annotation) {
		this.annotation = annotation;
	}
	public String getProcessIdentifier() {
		return processIdentifier;
	}
	public void setProcessIdentifier(String processIdentifier) {
		this.processIdentifier = processIdentifier;
	}
	public int getStandardReasonCode() {
		return standardReasonCode;
	}
	public void setStandardReasonCode(int standardReasonCode) {
		this.standardReasonCode = standardReasonCode;
	}
	public int getLsiNo() {
		return lsiNo;
	}
	public void setLsiNo(int lsiNo) {
		this.lsiNo = lsiNo;
	}
	public String getChargeIdentifier() {
		return chargeIdentifier;
	}
	public void setChargeIdentifier(String chargeIdentifier) {
		this.chargeIdentifier = chargeIdentifier;
	}
	public Date getAnntToDate() {
		return anntToDate;
	}
	public void setAnntToDate(Date anntToDate) {
		this.anntToDate = anntToDate;
	}
	public Date getAnntFromDate() {
		return anntFromDate;
	}
	public void setAnntFromDate(Date anntFromDate) {
		this.anntFromDate = anntFromDate;
	}
	public String getTaxamount() {
		return taxamount;
	}
	public void setTaxamount(String taxamount) {
		this.taxamount = taxamount;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getIssueRectified() {
		return issueRectified;
	}
	public void setIssueRectified(String issueRectified) {
		this.issueRectified = issueRectified;
	}
	public String getAdjReasonDet() {
		return adjReasonDet;
	}
	public void setAdjReasonDet(String adjReasonDet) {
		this.adjReasonDet = adjReasonDet;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTypeOfAdjustment() {
		return typeOfAdjustment;
	}
	public void setTypeOfAdjustment(String typeOfAdjustment) {
		this.typeOfAdjustment = typeOfAdjustment;
	}
	public String getAppLevel() {
		return appLevel;
	}
	public void setAppLevel(String appLevel) {
		this.appLevel = appLevel;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getAdjDescription() {
		return adjDescription;
	}
	public void setAdjDescription(String adjDescription) {
		this.adjDescription = adjDescription;
	}
	public String getAdjReasonCode() {
		return adjReasonCode;
	}
	public void setAdjReasonCode(String adjReasonCode) {
		this.adjReasonCode = adjReasonCode;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getBillRefNo() {
		return billRefNo;
	}
	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}
	public String getMobilelId() {
		return mobilelId;
	}
	public void setMobilelId(String mobilelId) {
		this.mobilelId = mobilelId;
	}
	public String getAccountExternalId() {
		return accountExternalId;
	}
	public void setAccountExternalId(String accountExternalId) {
		this.accountExternalId = accountExternalId;
	}
	public String getSegment() {
		return segment;
	}
	public void setSegment(String segment) {
		this.segment = segment;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getAeisamount() {
		return aeisamount;
	}
	public void setAeisamount(String aeisamount) {
		this.aeisamount = aeisamount;
	}
	
	

}
