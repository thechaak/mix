package com.airtel.acecad.bulkupload.dto;

import java.util.Date;

public class wacAeisUpload {

	private int waiverTxNo;										
	private int waiverTicketNo;
	private String lob;
	private String circle;
	private String accountExternalId;
	private String aeisAmount;
	private String taxamount;
	private String billRefNo;
	private Date anntFromDate;
	private Date anntToDate;
	private String chargeIdentifier;
	private int adjTransCode;
	private int lsiNo;
	private String standardReasonCode;
	private String adjReasonDet;
	private String processIdentifier;
	private String annotation;
	private String finalApprover;
	private String typeOfWaiver;
	private int wacAdjReasonCode;
	private String wacReasonDet;
	private String wacStatus;
	private String wacRejReason;
	private String wacRmdamount;
	private String wacRemarks;
	private String vipFlag;
	private String customerClassification;
	private String customerType;
	private String valueType;
	private String finalSegment;
	private String waiverInvoicePercentage;
	private int ageOnNetwork;
	private String billRefResets;
	private String invoiceDate;
	private String totalInvoiceAmt;
	private String invoiceOutstandingAmt;
	private String customerName;
	private String uploadedUserId;
	private String uploadedUserName;
	private Date wacReachTime;
	private Date ticketUploadTime;
	private String typeOfPeriod;
	
	
	public String getVipFlag() {
		return vipFlag;
	}
	public void setVipFlag(String vipFlag) {
		this.vipFlag = vipFlag;
	}
	public String getCustomerClassification() {
		return customerClassification;
	}
	public void setCustomerClassification(String customerClassification) {
		this.customerClassification = customerClassification;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getValueType() {
		return valueType;
	}
	public void setValueType(String valueType) {
		this.valueType = valueType;
	}
	public String getFinalSegment() {
		return finalSegment;
	}
	public void setFinalSegment(String finalSegment) {
		this.finalSegment = finalSegment;
	}
	public String getWaiverInvoicePercentage() {
		return waiverInvoicePercentage;
	}
	public void setWaiverInvoicePercentage(String waiverInvoicePercentage) {
		this.waiverInvoicePercentage = waiverInvoicePercentage;
	}
	public int getAgeOnNetwork() {
		return ageOnNetwork;
	}
	public void setAgeOnNetwork(int ageOnNetwork) {
		this.ageOnNetwork = ageOnNetwork;
	}
	public String getBillRefResets() {
		return billRefResets;
	}
	public void setBillRefResets(String billRefResets) {
		this.billRefResets = billRefResets;
	}
	public String getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public String getTotalInvoiceAmt() {
		return totalInvoiceAmt;
	}
	public void setTotalInvoiceAmt(String totalInvoiceAmt) {
		this.totalInvoiceAmt = totalInvoiceAmt;
	}
	public String getInvoiceOutstandingAmt() {
		return invoiceOutstandingAmt;
	}
	public void setInvoiceOutstandingAmt(String invoiceOutstandingAmt) {
		this.invoiceOutstandingAmt = invoiceOutstandingAmt;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getUploadedUserId() {
		return uploadedUserId;
	}
	public void setUploadedUserId(String uploadedUserId) {
		this.uploadedUserId = uploadedUserId;
	}
	public String getUploadedUserName() {
		return uploadedUserName;
	}
	public void setUploadedUserName(String uploadedUserName) {
		this.uploadedUserName = uploadedUserName;
	}
	public Date getWacReachTime() {
		return wacReachTime;
	}
	public void setWacReachTime(Date wacReachTime) {
		this.wacReachTime = wacReachTime;
	}
	public Date getTicketUploadTime() {
		return ticketUploadTime;
	}
	public void setTicketUploadTime(Date ticketUploadTime) {
		this.ticketUploadTime = ticketUploadTime;
	}
	public String getTypeOfPeriod() {
		return typeOfPeriod;
	}
	public void setTypeOfPeriod(String typeOfPeriod) {
		this.typeOfPeriod = typeOfPeriod;
	}
	public int getWaiverTxNo() {
		return waiverTxNo;
	}
	public void setWaiverTxNo(int waiverTxNo) {
		this.waiverTxNo = waiverTxNo;
	}
	public int getWaiverTicketNo() {
		return waiverTicketNo;
	}
	public void setWaiverTicketNo(int waiverTicketNo) {
		this.waiverTicketNo = waiverTicketNo;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getAccountExternalId() {
		return accountExternalId;
	}
	public void setAccountExternalId(String accountExternalId) {
		this.accountExternalId = accountExternalId;
	}
	public String getAeisAmount() {
		return aeisAmount;
	}
	public void setAeisAmount(String aeisAmount) {
		this.aeisAmount = aeisAmount;
	}
	public String getTaxamount() {
		return taxamount;
	}
	public void setTaxamount(String taxamount) {
		this.taxamount = taxamount;
	}
	public String getBillRefNo() {
		return billRefNo;
	}
	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}
	public Date getAnntFromDate() {
		return anntFromDate;
	}
	public void setAnntFromDate(Date anntFromDate) {
		this.anntFromDate = anntFromDate;
	}
	public Date getAnntToDate() {
		return anntToDate;
	}
	public void setAnntToDate(Date anntToDate) {
		this.anntToDate = anntToDate;
	}
	public String getChargeIdentifier() {
		return chargeIdentifier;
	}
	public void setChargeIdentifier(String chargeIdentifier) {
		this.chargeIdentifier = chargeIdentifier;
	}
	public int getAdjTransCode() {
		return adjTransCode;
	}
	public void setAdjTransCode(int adjTransCode) {
		this.adjTransCode = adjTransCode;
	}
	public int getLsiNo() {
		return lsiNo;
	}
	public void setLsiNo(int lsiNo) {
		this.lsiNo = lsiNo;
	}
	public String getStandardReasonCode() {
		return standardReasonCode;
	}
	public void setStandardReasonCode(String standardReasonCode) {
		this.standardReasonCode = standardReasonCode;
	}
	public String getAdjReasonDet() {
		return adjReasonDet;
	}
	public void setAdjReasonDet(String adjReasonDet) {
		this.adjReasonDet = adjReasonDet;
	}
	public String getProcessIdentifier() {
		return processIdentifier;
	}
	public void setProcessIdentifier(String processIdentifier) {
		this.processIdentifier = processIdentifier;
	}
	public String getAnnotation() {
		return annotation;
	}
	public void setAnnotation(String annotation) {
		this.annotation = annotation;
	}
	public String getFinalApprover() {
		return finalApprover;
	}
	public void setFinalApprover(String finalApprover) {
		this.finalApprover = finalApprover;
	}
	public String getTypeOfWaiver() {
		return typeOfWaiver;
	}
	public void setTypeOfWaiver(String typeOfWaiver) {
		this.typeOfWaiver = typeOfWaiver;
	}
	public int getWacAdjReasonCode() {
		return wacAdjReasonCode;
	}
	public void setWacAdjReasonCode(int wacAdjReasonCode) {
		this.wacAdjReasonCode = wacAdjReasonCode;
	}
	public String getWacReasonDet() {
		return wacReasonDet;
	}
	public void setWacReasonDet(String wacReasonDet) {
		this.wacReasonDet = wacReasonDet;
	}
	public String getWacStatus() {
		return wacStatus;
	}
	public void setWacStatus(String wacStatus) {
		this.wacStatus = wacStatus;
	}
	public String getWacRejReason() {
		return wacRejReason;
	}
	public void setWacRejReason(String wacRejReason) {
		this.wacRejReason = wacRejReason;
	}
	public String getWacRmdamount() {
		return wacRmdamount;
	}
	public void setWacRmdamount(String wacRmdamount) {
		this.wacRmdamount = wacRmdamount;
	}
	public String getWacRemarks() {
		return wacRemarks;
	}
	public void setWacRemarks(String wacRemarks) {
		this.wacRemarks = wacRemarks;
	}
	
	
}
