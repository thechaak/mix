package com.airtel.acecad.bulkupload.dto;

public class ECSChargingReversalStatus {
int count;
int transactionNumber;
public int getCount() {
	return count;
}
public void setCount(int count) {
	this.count = count;
}
public int getTransactionNumber() {
	return transactionNumber;
}
public void setTransactionNumber(int transactionNumber) {
	this.transactionNumber = transactionNumber;
}
}
