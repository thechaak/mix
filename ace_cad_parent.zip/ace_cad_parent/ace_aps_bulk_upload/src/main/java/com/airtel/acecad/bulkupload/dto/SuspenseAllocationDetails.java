package com.airtel.acecad.bulkupload.dto;

public class SuspenseAllocationDetails {
	private String acctExtId;
	private double amountToAllocate;
	private String billRefNo;
	private String billRefResets;
	private String lob;
	private String comments;
	public String getAcctExtId() {
		return acctExtId;
	}
	public void setAcctExtId(String acctExtId) {
		this.acctExtId = acctExtId;
	}
	
	public double getAmountToAllocate() {
		return amountToAllocate;
	}
	public void setAmountToAllocate(double amountToAllocate) {
		this.amountToAllocate = amountToAllocate;
	}
	public String getBillRefNo() {
		return billRefNo;
	}
	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}
	public String getBillRefResets() {
		return billRefResets;
	}
	public void setBillRefResets(String billRefResets) {
		this.billRefResets = billRefResets;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	

}
