package com.airtel.acecad.bulkupload.dto;

import java.util.HashMap;
import java.util.List;



public class FileStatusDTO {
List<FileStatusAPS> fileStatusList;
List<AESVendorFileRecords> aesVendorStatusList;

private int totalResults; 
private int resultPerPage;
private int totalPages;
private HashMap<String,Integer> reasons = new HashMap<>();
public HashMap<String, Integer> getReasons() {
	return reasons;
}
public void setReasons(HashMap<String, Integer> reasons) {
	this.reasons = reasons;
}
public int getTotalPages() {
	return totalPages;
}
public void setTotalPages(int totalPages) {
	this.totalPages = totalPages;
}
public List<FileStatusAPS> getFileStatusList() {
	return fileStatusList;
}
public void setFileStatusList(List<FileStatusAPS> fileStatusList) {
	this.fileStatusList = fileStatusList;
}
public int getTotalResults() {
	return totalResults;
}
public void setTotalResults(int totalResults) {
	this.totalResults = totalResults;
}
public int getResultPerPage() {
	return resultPerPage;
}
public void setResultPerPage(int resultPerPage) {
	this.resultPerPage = resultPerPage;
}

public List<AESVendorFileRecords> getAesVendorStatusList() {
	return aesVendorStatusList;
}
public void setAesVendorStatusList(List<AESVendorFileRecords> aesVendorStatusList) {
	this.aesVendorStatusList = aesVendorStatusList;
}


}
