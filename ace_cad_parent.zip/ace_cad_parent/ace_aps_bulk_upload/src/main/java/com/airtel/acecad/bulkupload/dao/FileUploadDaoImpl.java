package com.airtel.acecad.bulkupload.dao;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.airtel.acecad.bulkupload.dto.ChequeBounceDetails;
import com.airtel.acecad.bulkupload.dto.ECSBankFile;
import com.airtel.acecad.bulkupload.dto.ECSChargingReversalStatus;
import com.airtel.acecad.bulkupload.dto.FileColMstAps;
import com.airtel.acecad.bulkupload.dto.FileIdentifierMstAps;
import com.airtel.acecad.bulkupload.dto.FileStatusAPS;
import com.airtel.acecad.bulkupload.dto.FileStatusDTO;
import com.airtel.acecad.bulkupload.dto.PaymentTransferDetails;
import com.airtel.acecad.bulkupload.dto.ResponseOfInsert;
import com.airtel.acecad.bulkupload.util.BulkUtilValidations;
import com.airtel.acecad.bulkupload.util.CommonValidator;
import com.airtel.acecad.bulkupload.util.GlobalConstants;
import com.airtel.acecad.bulkupload.util.NamedParameterStatement;

import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
/*
 * @author :- Shaleen Agarwal
 */
@Repository
public class FileUploadDaoImpl implements GlobalConstants, FileUploadDao {

	private static Logger log = LogManager.getLogger("apsbulkUploadLog");
	@Autowired
	DataSource dataSource;
	@Autowired
	private PlatformTransactionManager transactionManager;
	@Autowired
	PaymentTransferDetails paymentDetails;
	@Autowired
	ChequeBounceDetails chequeBounceDetails;

	public FileUploadDaoImpl(DataSource dataSource) {
		this.dataSource = dataSource;
		setTransactionManager(transactionManager);
	}

	public FileUploadDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	public void setTransactionManager(
			PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}


	public List<String> getStatusList() throws SQLException{
		Connection con = null;
		ResultSet rs=null;
		con = new JdbcTemplate(dataSource).getDataSource().getConnection();
		List<String> statusList = new ArrayList<>();
		String query = "select distinct STATUS_MEANING from STATUS_MASTER_TABLE_APS where status_meaning IN('In Progress','Approval Pending','Failed','Success','Approved','Rejected','Partial Success')";
		PreparedStatement ps = con.prepareStatement(query);
		rs = ps.executeQuery();
		while(rs.next()){
			statusList.add(rs.getString(1));
		}
		log.info(query);
		if(con!=null){
			ps.close();
			rs.close();
			con.close();
		}
		return statusList;
	}
	public FileStatusDTO searchFileAPS(String fileId, String fileName, String fromDate, String endDate, String status,int page,String viewName,String fileIdentifier,String olmId) throws Exception{
		Connection con = null;
		DecimalFormat dfa = new DecimalFormat("#");
		dfa.setMaximumFractionDigits(8);
		ResultSet rs=null;
		List<FileStatusAPS> fileStatusApsList = new ArrayList<>();
		int recordsPerPage =10;
		con = new JdbcTemplate(dataSource).getDataSource().getConnection();
		FileStatusDTO fileStatusDTO = new FileStatusDTO();
		int reasoncode;String reason;
		HashMap<String,Integer> reasons = new HashMap<>();
		String rejectionReason="SELECT REASON_CODE,REASON FROM REJECTION_REASON_APS order by reason";
		PreparedStatement pst = con.prepareStatement(rejectionReason);
		ResultSet resultSets4 = pst.executeQuery();
		while(resultSets4 != null && resultSets4.next()) {
			reasoncode =  resultSets4.getInt(1);
			reason = resultSets4.getString(2);
			reasons.put(reason,reasoncode);
		}
		fileStatusDTO.setReasons(reasons);
		pst.close();
		resultSets4.close();

		String dateCondition;
		if(endDate == null || endDate.equals("")){
			Date date = new Date();
			DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			endDate = formatter.format(date);
		}
		if(fromDate == null || fromDate.equals("")){
			dateCondition = " AND TRUNC(f.process_date)  <=  to_date('"+endDate+"','dd/MM/yyyy')";
		}
		else{
			dateCondition = " AND TRUNC(f.process_date)  BETWEEN to_date('"+fromDate+"','dd/MM/yyyy') AND to_date('"+endDate+"','dd/MM/yyyy')";
		}
		String countQuery,dataQuery;
		if(viewName.equalsIgnoreCase("viewFileAPS")){
			countQuery ="select count(*) from (select  f.file_id,f.file_identifier,f.file_path,f.sum_of_amount,f.total_records,f.invalid_count,f.source,f.user_name,f.status,f.error_reason,f.process_date,f.pending_approval_level,f.is_worklist_compliant,s.status_meaning,UPPER(u.user_name),RowNum r from FILE_STATUS_APS f LEFT OUTER JOIN STATUS_MASTER_TABLE_APS s on f.status = s.status_code LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_name) where (f.status>=0 or f.status IN(-12,-13,-14,-15,-6)) AND f.file_identifier IN('ADJ','CNR','DNR','DPP','RDJ','RDP','REF','SNR','RNH','PNH')  and UPPER(f.user_name) like '%"+olmId+"%' and f.file_id like '%"+fileId+"%' and UPPER(f.file_path) like '%"+fileName+"%' and UPPER(f.file_identifier) like '%"+fileIdentifier+"%' and s.status_meaning like '%"+status+"%' "+dateCondition+"  order by f.file_id desc )";
			dataQuery = "select * from (select q.*,RowNum r  from (select  f.file_id,f.file_identifier,f.file_path,f.sum_of_amount,f.total_records,f.invalid_count,f.source,f.user_name,f.status,f.error_reason,f.process_date,f.pending_approval_level,f.is_worklist_compliant,s.status_meaning,UPPER(u.user_name) from FILE_STATUS_APS f LEFT OUTER JOIN STATUS_MASTER_TABLE_APS s on f.status = s.status_code LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_name) where (f.status>=0 or f.status IN(-12,-13,-14,-15,-6)) AND f.file_identifier IN('ADJ','CNR','DNR','DPP','RDJ','RDP','REF','SNR','RNH','PNH') and UPPER(f.user_name) like '%"+olmId+"%' and f.file_id like '%"+fileId+"%' and UPPER(f.file_path) like '%"+fileName+"%' and UPPER(f.file_identifier) like '%"+fileIdentifier+"%' and s.status_meaning like '%"+status+"%' "+dateCondition+"  order by f.file_id desc)q )where r  between "+(((page-1)*recordsPerPage)+1) +" AND "+(page*recordsPerPage);
		}else{
			countQuery ="select count(*) from (select   f.file_id,f.file_identifier,f.file_path,f.sum_of_amount,f.total_records,f.invalid_count,f.source,f.user_name,f.status,f.error_reason,f.process_date,f.pending_approval_level,f.is_worklist_compliant,s.status_meaning,UPPER(u.user_name),RowNum r from FILE_STATUS_APS f LEFT OUTER JOIN STATUS_MASTER_TABLE_APS s on f.status = s.status_code LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_name) where (f.status>=1 and f.status <=4) AND f.source <> 'SFTP' AND f.file_identifier IN('ADJ','CNR','DNR','DPP','RDJ','RDP','REF','SNR','RNH','PNH') and UPPER(f.user_name) like '%"+olmId+"%' and f.file_id like '%"+fileId+"%' and UPPER(f.file_path) like '%"+fileName+"%' and UPPER(f.file_identifier) like '%"+fileIdentifier+"%' and s.status_meaning like '%"+status+"%' "+dateCondition+"  order by f.file_id desc )";
			dataQuery = "select * from (select q.*,RowNum r  from (select  f.file_id,f.file_identifier,f.file_path,f.sum_of_amount,f.total_records,f.invalid_count,f.source,f.user_name,f.status,f.error_reason,f.process_date,f.pending_approval_level,f.is_worklist_compliant,s.status_meaning,UPPER(u.user_name) from FILE_STATUS_APS f LEFT OUTER JOIN STATUS_MASTER_TABLE_APS s on f.status = s.status_code LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_name) where (f.status>=1 and f.status <=4) AND f.source <> 'SFTP' AND f.file_identifier IN('ADJ','CNR','DNR','DPP','RDJ','RDP','REF','SNR','RNH','PNH') and UPPER(f.user_name) like '%"+olmId+"%' and f.file_id like '%"+fileId+"%' and UPPER(f.file_path) like '%"+fileName+"%' and UPPER(f.file_identifier) like '%"+fileIdentifier+"%' and s.status_meaning like '%"+status+"%' "+dateCondition+"  order by f.file_id)q )where r  between "+(((page-1)*recordsPerPage)+1) +" AND "+(page*recordsPerPage);
		}
		PreparedStatement psTotalRecords = con.prepareStatement(countQuery);
		log.info(dataQuery);
		log.info(countQuery);
		ResultSet rsTotalRecords = psTotalRecords.executeQuery();
		int totalRecords = 0;
		if(rsTotalRecords.next()){
			totalRecords = rsTotalRecords.getInt(1);
		}
		psTotalRecords.close();
		rsTotalRecords.close();
		log.info("Total Records are "+totalRecords);
		int totalPages;
		if(totalRecords%recordsPerPage ==0){
			totalPages = totalRecords/recordsPerPage;
		}else{
			totalPages = (totalRecords/recordsPerPage)+1;
		}
		log.info("here is searchfile totalPages " + totalPages+" page is "+page);
		fileStatusDTO.setTotalPages(totalPages);
		fileStatusDTO.setTotalResults(totalRecords);

		PreparedStatement ps = con.prepareStatement(dataQuery);
		rs = ps.executeQuery();
		while(rs.next()){
			FileStatusAPS fileStatusAps = new FileStatusAPS();
			fileStatusAps.setFileId(rs.getInt(1));
			fileStatusAps.setFileIdentifier(rs.getString(2));
			String fileNameQuery = rs.getString(3);
			fileStatusAps.setFilePath(fileNameQuery.substring(fileNameQuery.lastIndexOf("/")+1, fileNameQuery.length()));
			String fileNameFinal = fileNameQuery.substring(fileNameQuery.lastIndexOf("/")+1, fileNameQuery.length());
			log.info("Final name is "+fileNameFinal);
			String marketCode="";
			try{
				marketCode = fileNameFinal.substring(0, 3);
			}catch(Exception e){

			}
			String circle = getCircleFromMarketCode(marketCode);
			fileStatusAps.setCircle(circle);


			fileStatusAps.setSumOfAmount(String.valueOf(dfa.format((Double.parseDouble(String.valueOf(rs.getLong(4))))/100)));
			fileStatusAps.setTotalRecords(rs.getInt(5));
			fileStatusAps.setInvalidCount(rs.getInt(6));
			fileStatusAps.setSource(rs.getString(7));
			fileStatusAps.setOlmId(rs.getString(8));
			fileStatusAps.setStatus(rs.getInt(9));
			fileStatusAps.setStatusDescription(rs.getString(10));
			String date =rs.getString(11);
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
			Date startDate = df.parse(date);
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm");
			String parsedDate = formatter.format(startDate);
			fileStatusAps.setProcessDate(parsedDate);
			fileStatusAps.setPendingApprovalLevel(rs.getInt(12));
			fileStatusAps.setIsWorkListCompliant(rs.getString(13));
			fileStatusAps.setStatusMessage(rs.getString(14));
			fileStatusAps.setFirstLastName(rs.getString(15));
			fileStatusApsList.add(fileStatusAps);
		}
		fileStatusDTO.setFileStatusList(fileStatusApsList);
		fileStatusDTO.setResultPerPage(fileStatusApsList.size());
		if(con != null){
			ps.close();
			rs.close();
			con.close();
		}
		return fileStatusDTO;

	}


	public String validatexlsxFile(Workbook workbook,String fileType,String fileName) 
	{
		log.info("START : method validatexlsxFile of BulkUtilValidations");
		int colSize;

		List<String> headersList=new ArrayList<String>();
		org.apache.poi.ss.usermodel.Sheet  sheet = workbook.getSheetAt(0);
		Iterator<Row> rowIterator = sheet.iterator();
		Row row = (Row) rowIterator.next();
		colSize =  row.getPhysicalNumberOfCells();
		for (int j = row.getFirstCellNum(); j <colSize; j++){
			if (row.getCell(j) != null) {
				headersList.add(row.getCell(j).getStringCellValue().toUpperCase().trim().replaceAll("\n", ""));
			}
		}

		log.info("Header List is : "+headersList.size() +"and "+ fileType);
		for(int i=0;i<headersList.size();i++) {
		log.info("Header List is :"+headersList.get(i));
		}
		String headerStatus = headerProcValidation(headersList,fileType,fileName);
		log.info("END :method validatexlsxFile  of BulkUtilValidations");
		return headerStatus;
	}

	public boolean checkCircle(String filePath,String fileIde){

		log.info("START : in method checkCircle method of FileUploadDaoImpl");
		String fileName=filePath.substring(filePath.lastIndexOf("/")+1);
		String cir = fileName.substring(0, 3);
		log.info("filename is :"+fileName+" and circle code is : "+cir);
		NamedParameterStatement namedParameter = null;
		Connection con = null;
		ResultSet rs=null;
		StringBuffer sb =null;
		List list=new ArrayList<>();
		list.add("NRC");
		list.add("DRV");
		list.add("ADP");
		list.add("ADR");
		list.add("DEP");
		list.add("SLN");
		list.add("MIC");
		list.add("REV");

		if(list.contains(fileIde.toUpperCase())){
			sb = new StringBuffer("select * FROM cp_circle_aps where market_code = '"+cir+"' and UPPER(STATUS) = 'ACTIVE'");
		}

		else{	
			sb = new StringBuffer("select * FROM circle_aps where market_code = '"+cir+"' and UPPER(STATUS) = 'ACTIVE'");
		}
		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("connection __________" + con);
		} catch (Exception e) {
			//log.info(e);
			log.info("ConnRection not established ", e);
		}

		log.info("connection made...");
		boolean status = false;
		if (con != null) {
			try {
				namedParameter = new NamedParameterStatement(con, sb.toString());
				rs = namedParameter.executeQuery();
				try {
					if(rs!=null){
						if (rs.next()) {
							status = true;
						}
						else{
							status = false;
						}
					}
				} catch (Exception e) {
					log.info(e);

				}
				finally{
					con.commit();
					namedParameter.close();
					rs.close();
					con.close();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();

			}
		}
		log.info("END : in method checkCircle method of FileUploadDaoImpl");
		return status;
	}
	public int duplicateFileName(String fileName,int tot_rows, double sum,Date date,List list,String fileIde){

		log.info("START : in method duplicateFileName method of FileUploadDaoImpl filename->>"+fileName +" file ide->"+fileIde);
		PreparedStatement namedParameter = null;
		Connection con = null;
		ResultSet rs=null;
		int count = 0;
		int error = 0;
		StringBuffer sb =null;
		fileName = fileName.substring(fileName.lastIndexOf("/")+1);
		fileName = fileName.substring(0, fileName.lastIndexOf("."));
		if(list.contains(fileIde)){
			sb = new StringBuffer("SELECT COUNT(*) FROM PAYMENT_STATUS_APS WHERE ORIGINAL_FILE_NAME LIKE '%"+fileName+"%' ");
		}
		/*else if(fileIde.equals("AESADV") || fileIde.equals("AESDP") || fileIde.equals("AESDUMMY") )
		{
			sb = new StringBuffer("SELECT COUNT(*) FROM ADVICE_REQUEST_STATUS_APS WHERE ORIGINAL_FILE_NAME LIKE '%"+fileName+"%' ");
		}*/
		
		else if(fileIde.equals("AESDUMMY") /*|| fileIde.equals("REF_ISTM") ||  fileIde.equals("REF_DTH") ||  fileIde.equals("REF_TM")*/) // for wac and cad add lob
		{
			sb = new StringBuffer("SELECT COUNT(*) FROM ADVICE_REQUEST_STATUS_APS WHERE ORIGINAL_FILE_NAME LIKE '%"+fileName+"%' ");
		}
		else{
			sb = new StringBuffer("select count(*) from FILE_STATUS_APS ");
			sb.append("WHERE file_path like '%"+fileName+"%'  and (status >= 0 or status in(-12,-13,-14,-15))");
		}
		/*and SUM_OF_AMOUNT = :sum and TOTAL_RECORDS = :tot_rows and PROCESS_DATE = :date*/
		log.info("QUERY of duplicateFileName method in FileUploadDaoImpl " + sb.toString());


		try {

			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("connection __________" + con);
		} catch (Exception e) {
			//			log.info(e);
			log.info("Connection is not established in duplicateFileName method ", e);
		}
		try {
			log.info("connection made...");

			if (con != null) {

				namedParameter = con.prepareStatement(sb.toString());
				/*namedParameter.setDouble("sum", sum);
				namedParameter.setInt("tot_rows", tot_rows);
				namedParameter.setDate("date", date);*/


				rs = namedParameter.executeQuery();

				try {
					if(rs!=null){
						while (rs.next()) {
							count = rs.getInt(1);
						}
					}
					log.info("Count of duplicate row in FILE_STATUS_APS in duplicateFileName method: "+count);
				} catch (Exception e) {
					log.info(e);

				}

			}
		} catch (Exception e) {
			log.info(e);
		} finally {
			try {
				con.commit();
				rs.close();
				namedParameter.close();
				con.close();

			} catch (SQLException e) {
				log.info(e);
			}
		}
		log.info("END : In duplicateFileName method of FileUploadDaoImpl");
		if("SAL".equalsIgnoreCase(fileIde)){
			count=0;
		}
		if(count == 0)
			error= 0;
		else 
			error=  count;
		return error;
	}

	public void insertIntoErrorLog(int fildId,String fileName,String errorReason,String user){

		log.info("START :In method insertIntoErrorLog of FileUploadDaoImpl");

		Connection con = null;
		PreparedStatement preparedStatement = null;

		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("connection made...");

			StringBuffer sb = new StringBuffer(
					"Insert into ERROR_FILE_LOG_APS(FILE_ID,FILE_PATH,ERROR_DESCRIPTION,VENDOR_ID,LOG_TIME) values(?,?,?,?,?)");
			Date date = new Date();
			java.sql.Timestamp timeStamp = new Timestamp(date.getTime());
			/*java.sql.Date sqlDate = new java.sql.Date(date);*/

			preparedStatement = con.prepareStatement(sb.toString());
			preparedStatement.setInt(1, fildId);
			preparedStatement.setString(2, fileName);
			preparedStatement.setString(3, errorReason);
			preparedStatement.setString(4, user);
			preparedStatement.setTimestamp(5,timeStamp);

			preparedStatement.executeQuery();

		} catch (SQLException e) {
			log.info(e);

		} finally {

			try {
				con.commit();
				preparedStatement.close();
				con.close();
			} catch (SQLException e) {
				log.info(e);
			}

		}
		log.info("END : In method insertIntoErrorLog of FileUploadDaoImpl");
	}

	public int getTransactionNumber(String sequenceName) throws Exception {

		log.info("START :In method getTransactionNumber of FileUploadDaoImpl");

		log.info("Transaction Number is In method getTransactionNumber : "+sequenceName);
		String transaction_no = EMPTY_STRING;
		NamedParameterStatement namedParameter = null;
		Connection con = null;
		ResultSet rs =null;
		String query = "SELECT "+sequenceName +".NEXTVAL AS NUM FROM DUAL";
		StringBuffer sb = new StringBuffer(query);
		log.info("QUERY In method getTransactionNumber: " + sb.toString());

		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("connection __________" + con);
		} catch (Exception e) {
			log.info(e);
		}

		log.info("connection made In method getTransactionNumber...");

		if (con != null) {

			namedParameter = new NamedParameterStatement(con, sb.toString());
			rs = namedParameter.executeQuery();

			try {
				if(rs!=null){
					if (rs.next()) {
						transaction_no = rs.getString(1);
					}
				}
			} catch (Exception e) {
				log.info(e);
			} finally {
				con.commit();
				namedParameter.close();
				rs.close();
				con.close();
			}

		}
		log.info("END--->In method getTransactionNumber of FileUploadDaoImpl");
		return Integer.parseInt(transaction_no);
	}
	public String getFileId() throws Exception {

		log.info("START--->In getFileId method of FileUploadDaoImpl");
		String file_id = EMPTY_STRING;
		NamedParameterStatement namedParameter = null;
		Connection con = null;
		ResultSet rs=null;
		StringBuffer sb = new StringBuffer("SELECT APS_FILE_ID_SEQ.NEXTVAL AS NUM FROM DUAL");
		log.info("QUERY in getFileId method : " + sb.toString());

		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("connection  in getFileId method" + con);
		} catch (Exception e) {
			log.info(e);
		}

		log.info("connection made in getFileId method...");

		if (con != null) {

			namedParameter = new NamedParameterStatement(con, sb.toString());
			rs = namedParameter.executeQuery();

			try {
				if(rs!=null){
					if (rs.next()) {
						file_id = rs.getString(1);
					}
				}
			} catch (Exception e) {
				log.info(e);
			} finally {
				con.commit();
				namedParameter.close();
				rs.close();
				con.close();
			}

		}

		log.info("file_id in getFileId method-->>" + file_id);
		log.info("END--->In method getFileId of FileUploadDaoImpl");
		return file_id;

	}
	public String getPaymentFileId() throws Exception {

		log.info("START--->In getFileId method of FileUploadDaoImpl");
		String file_id = EMPTY_STRING;
		NamedParameterStatement namedParameter = null;
		Connection con = null;
		ResultSet rs=null;
		//uncomment this later
		//StringBuffer sb = new StringBuffer("SELECT PAYMENT_SEQ.NEXTVAL AS NUM FROM DUAL");
		StringBuffer sb = new StringBuffer("SELECT FILE_ID_SEQ.NEXTVAL AS NUM FROM DUAL");
		log.info("QUERY in getFileId method : " + sb.toString());

		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("connection  in getFileId method" + con);
		} catch (Exception e) {
			log.info(e);
		}

		log.info("connection made in getFileId method...");

		if (con != null) {

			namedParameter = new NamedParameterStatement(con, sb.toString());
			rs = namedParameter.executeQuery();

			try {
				if(rs!=null){
					if (rs.next()) {
						file_id = rs.getString(1);
					}
				}
			} catch (Exception e) {
				log.info(e);
			} finally {
				con.commit();
				namedParameter.close();
				rs.close();
				con.close();
			}

		}

		log.info("file_id in getFileId method-->>" + file_id);
		log.info("END--->In method getFileId of FileUploadDaoImpl");
		return file_id;

	}

	public String getPaymentAdviceFileId(String fileIdef) throws Exception {

		log.info("START--->In getPaymentAdviceFileId method of FileUploadDaoImpl");
		String file_id = EMPTY_STRING;
		NamedParameterStatement namedParameter = null;
		Connection con = null;
		ResultSet rs = null;
		StringBuffer sb =null;
		// uncomment this later
		// StringBuffer sb = new StringBuffer("SELECT PAYMENT_SEQ.NEXTVAL AS NUM
		// FROM DUAL");
		if("PAFILE".equalsIgnoreCase(fileIdef) || "PAB".equalsIgnoreCase(fileIdef)) //Added by Ritu on 13th Aug
		{
			sb = new StringBuffer("SELECT PAYMENT_ADVICE_REQUEST_ID_SEQ.NEXTVAL AS NUM FROM DUAL");
		}
		else if("WMF".equalsIgnoreCase(fileIdef) || "WAI".equalsIgnoreCase(fileIdef)){
			sb = new StringBuffer("SELECT WAIVER_REQ_SEQ.NEXTVAL AS NUM FROM DUAL");
		}
		else if("WMT".equalsIgnoreCase(fileIdef) || "WIS".equalsIgnoreCase(fileIdef)){
			sb = new StringBuffer("SELECT WAIVER_REQ_SEQ.NEXTVAL AS NUM FROM DUAL");
		}
		else if("CMT".equalsIgnoreCase(fileIdef) || "CIS".equalsIgnoreCase(fileIdef)){
			sb = new StringBuffer("SELECT WAIVER_REQ_SEQ.NEXTVAL AS NUM FROM DUAL");
		}
		else if("BWM".equalsIgnoreCase(fileIdef) || "BWI".equalsIgnoreCase(fileIdef)){
			sb = new StringBuffer("SELECT WAIVER_REQ_SEQ.NEXTVAL AS NUM FROM DUAL");
		}
		else if("SAL".equalsIgnoreCase(fileIdef)){
			sb = new StringBuffer("SELECT SAL_REQUEST_ID_SEQ.NEXTVAL AS NUM FROM DUAL");
		}
		else if("PTF".equalsIgnoreCase(fileIdef)){
			sb = new StringBuffer("SELECT PTF_REQUEST_ID_SEQ.NEXTVAL AS NUM FROM DUAL");
		}
		else if("TDS".equalsIgnoreCase(fileIdef)){
			sb = new StringBuffer("SELECT TDS_REQUEST_ID.NEXTVAL AS NUM FROM DUAL");//GIVE TDS SEQ HERE
		}
		else if("REF_CISTM".equalsIgnoreCase(fileIdef) || "REF_DISTM".equalsIgnoreCase(fileIdef) || "REF_DTH".equalsIgnoreCase(fileIdef) || "REF_TM".equalsIgnoreCase(fileIdef) || "REF_TMP".equalsIgnoreCase(fileIdef)){
			sb = new StringBuffer("SELECT REFISTM_REQUEST_ID_SEQ.NEXTVAL AS NUM FROM DUAL");//GIVE TDS SEQ HERE
		}
		else{
			sb = new StringBuffer("SELECT AES_ADVICE_REQUEST_ID_SEQ.NEXTVAL AS NUM FROM DUAL");
		}
		log.info("QUERY in getFileId method : " + sb.toString());

		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("connection  in getFileId method" + con);
		} catch (Exception e) {
			log.info(e);
		}

		log.info("connection made in getFileId method...");

		if (con != null) {

			namedParameter = new NamedParameterStatement(con, sb.toString());
			rs = namedParameter.executeQuery();

			try {
				if (rs != null) {
					if (rs.next()) {
						file_id = rs.getString(1);
					}
				}
			} catch (Exception e) {
				log.info(e);
			} finally {
				con.commit();
				namedParameter.close();
				rs.close();
				con.close();
			}

		}

		log.info("file_id in getFileId method-->>" + file_id);
		log.info("END--->In method getPaymentAdviceFileId of FileUploadDaoImpl");
		return file_id;

	}

	public List<ECSBankFile> getAccountNumberListForECSBankFile() throws SQLException {
		log.info("START--->In accountNumberListForECSBankFile method of FileUploadDaoImpl");
		List<ECSBankFile> accountNumberList = new ArrayList<>();
		NamedParameterStatement namedParameter = null;
		Connection con = null;
		ResultSet rs=null;
		StringBuffer sb = new StringBuffer("select Sr_number,Sr_transaction_no,billing_account_number,status_code,status from SR_Details_aps where SR_Category='ECS Registration' and is_worklist_compliant ='Y'");
		log.info("QUERY in getFileId method : " + sb.toString());

		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("connection  in getFileId method__________" + con);
		} catch (Exception e) {
			log.info(e);
		}

		log.info("connection made in getFileId method...");

		if (con != null) {

			namedParameter = new NamedParameterStatement(con, sb.toString());
			rs = namedParameter.executeQuery();

			try {
				if(rs!=null){
					while(rs.next()) {
						ECSBankFile ecs = new ECSBankFile();
						ecs.setSrNumber(rs.getString(1));
						ecs.setSrTransactionNumber(rs.getString(2));
						ecs.setAccountNumber(rs.getString(3));
						ecs.setStatusCode(rs.getInt(4));
						ecs.setStatusDescription(rs.getString(5));
						accountNumberList.add(ecs);
					}
				}
			} catch (Exception e) {
				log.info(e);
			} finally {
				con.commit();
				namedParameter.close();
				rs.close();
				con.close();
			}
		}
		log.info("file_id in accountNumberListForECSBankFile method-->>" + accountNumberList);
		log.info("END--->In method accountNumberListForECSBankFile of FileUploadDaoImpl");
		return accountNumberList;
	}
	/*
	 * @author :- Shaleen Agarwal
	 */

	/*public String getAPSFLAG(int accountNumber){

		log.info("START--->In method getAPSFLAG of FileUploadDaoImpl");

		//log.info("In get APs FLag");
		String aps_flag = "",
	    date = null;
		NamedParameterStatement namedParameter = null;
		ResultSet rs= null;
		java.sql.Date sqlDate = null;
		Date newDate = null;
		Connection con = null;
		String dateSb = "select PARAMETER_VALUE from SYSTEM_PARAMETERS_APS where PARAMETER_NAME='DATE_INSERT'";

		log.info("QUERY in method getAPSFLAG  : " + dateSb.toString());

		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			namedParameter = new  NamedParameterStatement(con, dateSb);
			rs = namedParameter.executeQuery();
			if(rs!=null){
			if (rs.next()) {
				date = rs.getString(1);
			}
			}
			//log.info("Date is >>>>>>>>>>> "+date);

			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");


			if(date != null){
				newDate = (Date) formatter.parse(date);
				sqlDate = new java.sql.Date(newDate.getTime());
			}
			StringBuffer sb = new StringBuffer("SELECT APS_FLAG from NDS_ACCOUNTS_APS where ACCOUNT_NO = '"+accountNumber +"' and NDS_DATE >= to_date('"+sqlDate+"','yyyy-mm-dd')");
			namedParameter = new NamedParameterStatement(con, sb.toString());
			//namedParameter.setDate("DATE_INSERT", sqlDate);
			log.info("Query is in method getAPSFLAG : "+sb);
			rs = namedParameter.executeQuery();
			if(rs!=null){
			if (rs.next()) {
				aps_flag = rs.getString(1);
			}
			}
		} catch (Exception e) {
			log.info(e);
		}
		finally {
			try {
				con.commit();
				namedParameter.close();
				if(rs!=null ){
					rs.close();

				}
				if(con!=null ){
					con.close();
				}
			} catch (SQLException e) {
				log.info(e);
			}

		}
		log.info("END--->in method getAPSFLAG of FileUploadDaoImpl");
		return aps_flag;
	}
	 */

	public String getAPSFLAG(String accountNumber) {
		log.info("START:In getAPSFLAG method of FileUploadDaoImpl ");
		Connection con = null;
		CallableStatement callableStatement = null;
		String aps = "";
		try {
			if (accountNumber !=null) {
				try {
					con = new JdbcTemplate(dataSource).getDataSource().getConnection();
					con.setAutoCommit(false);
				} catch (Exception e) {
					log.info("Conection :: ", e);
				}
				String procStr = "{call GET_APS_FLAG(?,?,?)}";
				callableStatement = con.prepareCall(procStr);
				callableStatement.setString(1, accountNumber);
				callableStatement.registerOutParameter(2, Types.VARCHAR);
				callableStatement.registerOutParameter(3, Types.VARCHAR);
				callableStatement.executeQuery();
				try {
					String response = callableStatement.getString(2);
					if (response != null && !response.isEmpty()) {
						aps = response;
					}
				} catch (Exception e) {
					log.info("Exception  response fetched from nds", e);
					return aps;
				}

			}
		} catch (Exception e) {
			log.info("Exception", e);
		} finally {

			try {
				callableStatement.close();
				con.close();
			} catch (Exception e) {
				log.info("Exception", e);
			}
		}

		log.info("END:getApsFlag aps-->>>  " + aps);
		//log.info("APS flag---------->>"+aps);
		return aps;
	}

	private ECSChargingReversalStatus updateECSChargingFX(String accountNumber,String debitDate, String bankDescription, String bankRejectionReason,int transactionNo)throws Exception{
		log.info("start :updateECSChargingFX method");
		log.info("accountNumber-->>"+accountNumber+" debitDate-->>"+debitDate+" bankDescription-->>"+bankDescription+" bankRejectionReason-->>"+bankRejectionReason+" transactionNo-->"+transactionNo);
		Connection con = null;
		ECSChargingReversalStatus ecsCharging = new ECSChargingReversalStatus();
		int transactionNumber = 0;
		con = new JdbcTemplate(dataSource).getDataSource().getConnection();
		String selectCount = "select count(*) from ecs_charging_aps where trunc(DEBIT_DATE) = to_date( replace('"+debitDate+"','IST'),'DY MON DD HH24:MI:SS YYYY') and account_external_id ='"+accountNumber+"'";
		log.info("selectCount-->>"+selectCount);
		String selectStatusQuery = "select payment_description,transaction_no from ecs_charging_aps where trunc(DEBIT_DATE) = to_date( replace('"+debitDate+"','IST'),'DY MON DD HH24:MI:SS YYYY') and account_external_id ='"+accountNumber+"'";
		log.info("selectStatusQuery-->>"+selectStatusQuery);
		PreparedStatement psCount = con.prepareStatement(selectCount);
		ResultSet rsCount = psCount.executeQuery();
		int count = 0 ;
		while(rsCount.next()){
			count = rsCount.getInt(1);
		}

		PreparedStatement ps = con.prepareStatement(selectStatusQuery);
		ResultSet rs = ps.executeQuery();
		PreparedStatement preparedStatement = null;
		String paymentDescription = "";
		String updateCondition="";
		log.info("count-->>"+count);
		if(count == 1){
			if(rs.next()){
				paymentDescription = rs.getString(1);
				if(bankDescription.equalsIgnoreCase("FAILED") && paymentDescription.equalsIgnoreCase("Sent to FX") ){
					String selectReasonQuery = "select nrc_reason from AIRTL_REV_NRC_CODE_MASTER where UPPER(bounce_reason) = '"+bankRejectionReason.toUpperCase()+"' and upper(lob)='MOB'";
					PreparedStatement psReason = con.prepareStatement(selectReasonQuery);
					ResultSet rsReason = psReason.executeQuery();
					String finNon="",nrcReason="Not Applicable" ;
					if(rsReason.next()){
						finNon = rsReason.getString(1);
					}
					if(finNon.equalsIgnoreCase("FINANCIAL REASON")){
						nrcReason ="In Progress";
					}
					psReason.close();
					rsReason.close();
					updateCondition = " ,reversal_description = 'In Progress' , NRC_STATUS_DESCRIPTION = '"+nrcReason+"'";
					transactionNumber = rs.getInt(2);
				}else if(bankDescription.equalsIgnoreCase("PAID") && (paymentDescription.equalsIgnoreCase("Not Applicable") )){
					transactionNumber = rs.getInt(2);
					updateCondition = " ,payment_description = 'In Progress'";
					transactionNumber = rs.getInt(2);
				}else if(bankDescription.equalsIgnoreCase("FAILED") && paymentDescription.equalsIgnoreCase("SUCCESS")){
					String selectReasonQuery = "select nrc_reason from AIRTL_REV_NRC_CODE_MASTER where UPPER(bounce_reason) = '"+bankRejectionReason.toUpperCase()+"' and upper(lob)='MOB'";
					PreparedStatement psReason = con.prepareStatement(selectReasonQuery);
					ResultSet rsReason = psReason.executeQuery();
					String finNon="",nrcReason="Not Applicable" ;
					if(rsReason.next()){
						finNon = rsReason.getString(1);
					}
					if(finNon.equalsIgnoreCase("FINANCIAL REASON")){
						nrcReason ="In Progress";
					}
					psReason.close();
					rsReason.close();
					transactionNumber = rs.getInt(2);
					updateCondition = " ,reversal_description = 'In Progress' , NRC_STATUS_DESCRIPTION = '"+nrcReason+"'";
				}else if(bankDescription.equalsIgnoreCase("FAILED") && (paymentDescription.equalsIgnoreCase("Not Applicable") ||paymentDescription.equalsIgnoreCase("FAILURE") ||paymentDescription.equalsIgnoreCase("FAILED"))){
					String selectReasonQuery = "select nrc_reason from AIRTL_REV_NRC_CODE_MASTER where UPPER(bounce_reason) = '"+bankRejectionReason.toUpperCase()+"' and upper(lob)='MOB'";
					PreparedStatement psReason = con.prepareStatement(selectReasonQuery);
					ResultSet rsReason = psReason.executeQuery();
					String finNon="",nrcReason="Not Applicable" ;
					if(rsReason.next()){
						finNon = rsReason.getString(1);
					}
					if(finNon.equalsIgnoreCase("FINANCIAL REASON")){
						nrcReason ="In Progress";
					}
					psReason.close();
					rsReason.close();
					transactionNumber = rs.getInt(2);
					updateCondition = " , NRC_STATUS_DESCRIPTION = '"+nrcReason+"'";
				}
			}
			String query = "update ecs_charging_aps set bank_description = '"+bankDescription+"' , bank_rejection_reason='"+bankRejectionReason+"', bank_transaction_no = "+transactionNo+updateCondition+" where trunc(DEBIT_DATE) =  to_date( replace('"+debitDate+"','IST'),'DY MON DD HH24:MI:SS YYYY') and account_external_id ='"+accountNumber+"' and bank_description = 'Awaiting Bank Response'";
			log.info("update Query is "+query);
			preparedStatement = con.prepareStatement(query);
			preparedStatement.executeUpdate();
		}



		if(con != null){
			con.commit();
			psCount.close();
			rsCount.close();
			ps.close();
			rs.close();
			if(preparedStatement != null){
				preparedStatement.close();
			}
			con.close();
		}
		ecsCharging.setCount(count);
		ecsCharging.setTransactionNumber(transactionNumber);
		log.info("end :updateECSChargingFX method");
		return ecsCharging;
	}

	@Override
	public ResponseOfInsert insertIntoDynamicTable(int file_Id, List detailsList, FileIdentifierMstAps fileId,
			List<FileColMstAps> fileColMstList, String source, String userId,String advPaymentMode) throws Exception {


		log.info("START :In method insertIntoDynamicTable of FileUploadDaoImpl");
		log.info("file_Id->"+file_Id+" source->>"+source+" userId->"+userId);
		List<ECSBankFile> accountNumberList = new ArrayList<>();
		ResponseOfInsert res = new ResponseOfInsert();
		Connection con = null;
		HashMap<String,List<String>> transactionNumberToUpdate = new HashMap<>();
		try {

			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("connection in method insertIntoDynamicTable __________" + con);
		} catch (Exception e) {
			log.info(e);
		}
		int transaction_No = 0 ;
		log.info("connection made in method insertIntoDynamicTable...");
		PreparedStatement preparedStatement = null;
		String classN = "com.airtel.acecad.bulkupload.dto." + fileId.getBeanObject();
		Class className = Class.forName(classN);
		String result = EMPTY_STRING;
		int countRows =0;
		String file_id = EMPTY_STRING;
		int no_of_records = 0;
		String advaccount=null;
		// Date sysDate = new Date();
		StringBuffer sb = new StringBuffer("Insert into ");
		if("PAFILE".equalsIgnoreCase(fileId.getFileIdentifier()) || "PAB".equalsIgnoreCase(fileId.getFileIdentifier())){
			sb.append(fileId.getTableName() + "(I_REQUEST_ID,RECORD_TYPE,PAYMENT_MODE,");
		}
		else if("AESDP".equalsIgnoreCase(fileId.getFileIdentifier()) || "AESADV".equalsIgnoreCase(fileId.getFileIdentifier())||"TDS".equalsIgnoreCase(fileId.getFileIdentifier())){
			sb.append(fileId.getTableName() + "(TICKET_ID,");
		}
		else{
			sb.append(fileId.getTableName() + "(FILE_ID,");
		}
		for (FileColMstAps fileCol : fileColMstList) {
			sb.append(fileCol.getColumnName());
			sb.append(",");

		}
		if(fileId.getFileIdentifier().equals("BNECS") || fileId.getFileIdentifier().equals("ISECS")){
			sb.append("sr_transaction_no_ecs,sr_number_ecs,sentToCieble,TRANSACTION_NO,status_code_ecs");
			accountNumberList = getAccountNumberListForECSBankFile();
			System.out.println("In Bank Upload File Account Number List Size is "+accountNumberList.size());
		}

		else if(fileId.getFileIdentifier().equals("AWB_UPLOAD") || fileId.getFileIdentifier().equals("AWB_RTO_UPLOAD")
				|| fileId.getFileIdentifier().equals("REF_MODE_UPLOAD") || fileId.getFileIdentifier().equals("RRC_MODE_UPLOAD")
				||fileId.getFileIdentifier().equals("IP_UPLOAD") || fileId.getFileIdentifier().equals("CB_TRANS_UPLOAD")
				|| fileId.getFileIdentifier().equals("CB_DECISION_UPLOAD")) {
			sb.append("user_id,source,TRANSACTION_NO,File_identifier,CREATED_DATE,MODIFIED_DATE");			
		}else if("PAFILE".equalsIgnoreCase(fileId.getFileIdentifier()) || "PAB".equalsIgnoreCase(fileId.getFileIdentifier())) {
			sb.append("status_code,user_id,source,RECORD_ID,File_identifier,CREATED_DATE,MODIFIED_DATE");
		}else if("AESDP".equalsIgnoreCase(fileId.getFileIdentifier()) || "AESDUMMY".equalsIgnoreCase(fileId.getFileIdentifier()) || "AESADV".equalsIgnoreCase(fileId.getFileIdentifier())||"TDS".equalsIgnoreCase(fileId.getFileIdentifier()) ) {
			sb.append("status_code,REQUEST_RAISED_BY,source,TRANSACTION_ID,File_identifier,ticket_date,change_date");
		} /*
			 * else if("WMF".equalsIgnoreCase(fileId.getFileIdentifier()) ||
			 * "WAI".equalsIgnoreCase(fileId.getFileIdentifier())) { sb.append(//
			 * "status_code,USER_ID,SOURCE,TRANSACTION_NO,File_identifier,CREATED_DATE,MODIFIED_DATE,"
			 * "ADJ_TRANS_CODE,ADJ_DESCRIPTION,TYPE_OF_ADJUSTMENT,TYPE_OF_WAIVER,SUB_TYPE,ADJ_REASON_DETAILS"
			 * ); }
			 */

		else if("PTF".equalsIgnoreCase(fileId.getFileIdentifier())) {
			sb.append("status_code,CHANGE_WHO,source,TRANSACTION_ID,File_identifier,INSERT_DATE,MODIFIED_DATE");
		}
	else if("SAL".equalsIgnoreCase(fileId.getFileIdentifier()) || "REF_CISTM".equalsIgnoreCase(fileId.getFileIdentifier()) || "REF_DISTM".equalsIgnoreCase(fileId.getFileIdentifier())
			|| "REF_DTH".equalsIgnoreCase(fileId.getFileIdentifier()) || "REF_TM".equalsIgnoreCase(fileId.getFileIdentifier()) || "REF_TMP".equalsIgnoreCase(fileId.getFileIdentifier())) {
			sb.append("status_code,CHANGE_WHO,source,TRANSACTION_ID,File_identifier,INSERT_DATE,MODIFIED_DATE");
			//(TRANSACTION_ID,INSERT_DATE,FILE_ID,CHANGE_WHO,FILE_IDENTIFIER,SOURCE")
		}


		else {
			sb.append("status_code,user_id,source,TRANSACTION_NO,File_identifier,CREATED_DATE,MODIFIED_DATE");
		}

		sb.append(") " + "values (");
		if("PAFILE".equalsIgnoreCase(fileId.getFileIdentifier()) || "PAB".equalsIgnoreCase(fileId.getFileIdentifier())) //Added by Ritu on 13th Aug 2020
		{

			//String data = BeanUtils.getProperty((Object) className.newInstance(), "targetFXAccountNumber");
			//System.out.println("data-->>"+data);

			sb.append("?,'PAYMENT','"+advPaymentMode+"',");
		}
		else{
			sb.append("?,");
		}
		for (FileColMstAps fileCol : fileColMstList) {
			sb.append("?,");
		}
		System.out.println("File Identifier is "+fileId.getFileIdentifier());
		if(fileId.getFileIdentifier().equals("BNECS") || fileId.getFileIdentifier().equals("ISECS")){
			sb.append("?,?,?,?,?");
		}
		else if(fileId.getFileIdentifier().equals("AWB_UPLOAD") || fileId.getFileIdentifier().equals("AWB_RTO_UPLOAD")
				|| fileId.getFileIdentifier().equals("REF_MODE_UPLOAD") || fileId.getFileIdentifier().equals("RRC_MODE_UPLOAD")
				||fileId.getFileIdentifier().equals("IP_UPLOAD") || fileId.getFileIdentifier().equals("CB_TRANS_UPLOAD")
				|| fileId.getFileIdentifier().equals("CB_DECISION_UPLOAD")) {
			sb.append("?,?,?,?,?,?");			
		}
		/*
		 * else if("WMF".equalsIgnoreCase(fileId.getFileIdentifier()) ||
		 * "WAI".equalsIgnoreCase(fileId.getFileIdentifier())) {
		 * sb.append("?,?,?,?,?,?"); }
		 */
		else {
			sb.append("?,?,?,?,?,?,?");
		}
		/*
		 * if("PAB".equalsIgnoreCase(fileId.getFileIdentifier())) { sb.append("?,?,?");
		 * }
		 */

		sb.append(")");
		int accountNumber = 0;
		//log.info("Query is "+sb);
		log.info("Query in method insertIntoDynamicTable :" + sb.toString());
		if (con != null) {
			preparedStatement = con.prepareStatement(sb.toString());
			List<Integer> transactionNumberList = new ArrayList<>();
			Iterator iter = detailsList.iterator();
			while (iter.hasNext()) {
				Object clsInstance = (Object) className.newInstance();
				clsInstance = iter.next();
				try {

					preparedStatement.setInt(1, file_Id);

					int counter = 2;
					for (FileColMstAps fileCol : fileColMstList) {
						String dataType = fileCol.getDataType();

						if (dataType.equals("INTEGER")) {
							int dataInt = 0 ;
							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());

							if(data ==  null){
								data = "0";
							}
							dataInt = Integer.parseInt(data);
							preparedStatement.setInt(counter, dataInt);
							if(fileCol.getColumnName().equalsIgnoreCase("ACCOUNT_EXTERNAL_ID") || fileCol.getColumnName().equalsIgnoreCase("ACCOUNT_NO")){
								//log.info(fileCol.getClassAttributeName() + data + " "+dataInt);
								accountNumber = dataInt;
							}

						} else if (dataType.equals("STRING")) {



							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());
							
							if(data!=null && data!=""){

								data=data.trim();
								data=data.replace("\n","");
								data=data.replace("&", "");
								data=data.replace("||", "");

							}
							
							preparedStatement.setString(counter, data);


						} 
						else if (dataType.equals("ACCOUNTSTR")) {



							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());
							
							
							preparedStatement.setString(counter, data);


						} 
						
						else if (dataType.equals("TANSTR")) {



							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());
							
							
							preparedStatement.setString(counter, data);


						} 
						else if(dataType.equals("EXCHANGERATE")){
							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());
							if (data != null) {
								Double dataDouble = Double.parseDouble(data);
								log.info("setting double value-->>" + dataDouble);
								preparedStatement.setDouble(counter, dataDouble);
							} else
								preparedStatement.setNull(counter, java.sql.Types.DOUBLE);

						}
						
						else if (dataType.equals("DOUBLE")) {
							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());
							double dataDouble=0.0;
							if(data!=null){
							 dataDouble = Double.parseDouble(data);
							}
							
							preparedStatement.setDouble(counter, dataDouble);
						} else if (dataType.equals("DATE")) {
							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());

							DateFormat formatter = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy");
							//DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
							Date date = null;
							java.sql.Date sqlDate = null;
							if(data != null){
								date = (Date) formatter.parse(data);
								sqlDate = new java.sql.Date(date.getTime());
							}

							preparedStatement.setDate(counter, sqlDate);
						} else if (dataType.equals("LONG")) {
							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());
							if(data==null){
								preparedStatement.setNull(counter, java.sql.Types.LONGVARCHAR);
							}else{
								Long dataLong = Long.parseLong(data);
								preparedStatement.setLong(counter, dataLong);
							}
						} else if (dataType.equals("RESTRICTEDSTRING")) {
							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());
							preparedStatement.setString(counter, data);
						} else if (dataType.equals("NOSPSTRING")) {
							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());
							preparedStatement.setString(counter, data);
						}
						// Added by geeta
						else if (dataType.equals("ALPHANUMERIC")) {
							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());
							preparedStatement.setString(counter, data);
						}

						counter++;
					}

					if(!fileId.getFileIdentifier().equalsIgnoreCase("BNECS") && !fileId.getFileIdentifier().equalsIgnoreCase("ISECS") ){

						System.out.println("in NOT BNECS  new loop method......");

						if(!fileId.getFileIdentifier().equals("AWB_UPLOAD") && !fileId.getFileIdentifier().equals("AWB_RTO_UPLOAD")
								&& !fileId.getFileIdentifier().equals("REF_MODE_UPLOAD") && !fileId.getFileIdentifier().equals("RRC_MODE_UPLOAD")
								&& !fileId.getFileIdentifier().equals("IP_UPLOAD") && !fileId.getFileIdentifier().equals("CB_TRANS_UPLOAD")
								&& !fileId.getFileIdentifier().equals("CB_DECISION_UPLOAD")) {

							System.out.println("in not equal to refund identifier loop..........................");


							preparedStatement.setInt(counter, STATUS_CODE_FOR_INSERT);
							counter++;
						}
						System.out.println("in refund new loop method......");


						preparedStatement.setString(counter, userId);
						counter++;
						preparedStatement.setString(counter, source);
						counter++;
						transaction_No = getTransactionNumber(fileId.getSequenceName());

						System.out.println("after transaction no...-->>"+transaction_No);

						preparedStatement.setInt(counter, transaction_No);
						counter++;
						/*String aps_flag = getAPSFLAG(String.valueOf(accountNumber));
						preparedStatement.setString(counter, aps_flag);
						counter++;*/
						preparedStatement.setString(counter, fileId.getFileIdentifier());
						counter++;
						preparedStatement.setTimestamp(counter, new Timestamp(new Date().getTime()));
						counter++;
						preparedStatement.setTimestamp(counter, new Timestamp(new Date().getTime()));
					}

					if(fileId.getFileIdentifier().equals("BNECS")){
						String data = BeanUtils.getProperty(clsInstance, "accountNumber");
						String nachLimit = BeanUtils.getProperty(clsInstance, "amount");
						String appRejStatus = BeanUtils.getProperty(clsInstance,"nachRegStatus");
						String reason = BeanUtils.getProperty(clsInstance, "destinationBankReason");
						List<String> reasonNach = new ArrayList<>();
						if(reason == null){
							reason ="";
						}
						//long dataLong = Long.parseLong(data);

						for(ECSBankFile ecs : accountNumberList){
							if(ecs.getStatusDescription() == null){
								ecs.setStatusDescription("");
							}
							if(ecs.getAccountNumber().equalsIgnoreCase(data) && !ecs.getStatusDescription().equalsIgnoreCase("Approval Pending")){
								preparedStatement.setString(counter, ecs.getSrTransactionNumber());
								counter++;
								preparedStatement.setString(counter, ecs.getSrNumber());
								counter++;
								preparedStatement.setString(counter, "N");
								counter++;
								transaction_No = getTransactionNumber(fileId.getSequenceName());
								preparedStatement.setInt(counter, transaction_No);
								counter++;
								preparedStatement.setInt(counter, STATUS_CODE_FOR_INSERT);
								countRows++;
								reasonNach.add(nachLimit);
								if(!appRejStatus.equalsIgnoreCase("Registered")){
									reasonNach.add(reason);
								}else{
									reasonNach.add("");
								}
								transactionNumberToUpdate.put(ecs.getSrTransactionNumber(),reasonNach);
								preparedStatement.addBatch();
							}
						}
					}else if(fileId.getFileIdentifier().equals("ISECS")){
						String appRejStatus = BeanUtils.getProperty(clsInstance,"formInvalidStatus");
						String reason = BeanUtils.getProperty(clsInstance, "reasonInvalid");
						List<String> reasonNach = new ArrayList<>();
						if(reason == null){
							reason ="";
						}
						String data = BeanUtils.getProperty(clsInstance, "accountNumber");
						String nachLimit = BeanUtils.getProperty(clsInstance, "amount");
						//long dataLong = Long.parseLong(data);

						for(ECSBankFile ecs : accountNumberList){
							if(ecs.getStatusDescription() == null){
								ecs.setStatusDescription("");
							}
							if(ecs.getAccountNumber().equalsIgnoreCase(data) && ecs.getStatusDescription().equalsIgnoreCase("upload Pending")){
								preparedStatement.setString(counter, ecs.getSrTransactionNumber());
								counter++;
								preparedStatement.setString(counter, ecs.getSrNumber());
								counter++;
								preparedStatement.setString(counter, "N");
								counter++;
								transaction_No = getTransactionNumber(fileId.getSequenceName());
								preparedStatement.setInt(counter, transaction_No);
								counter++;
								preparedStatement.setInt(counter, STATUS_CODE_FOR_INSERT);
								countRows++;
								reasonNach.add(nachLimit);
								if(!appRejStatus.equalsIgnoreCase("valid")){
									if(CommonValidator.isNull(reason)){
										reasonNach.add("Interm Record validation failed");
									}
									else
										reasonNach.add(reason);
								}else{
									if(CommonValidator.isNull(reason)){
										reasonNach.add("Interm Record validated");
									}
									else
										reasonNach.add(reason);
								}
								transactionNumberToUpdate.put(ecs.getSrTransactionNumber(),reasonNach);
								preparedStatement.addBatch();
							}
						}
					}else if(fileId.getFileIdentifier().equals("BRECS")){
						String accountN = BeanUtils.getProperty(clsInstance, "accountNo");
						String debitDate = BeanUtils.getProperty(clsInstance, "debitD");
						String bankDescription = BeanUtils.getProperty(clsInstance, "bdPaidStatus");
						String bankRejectionReason = BeanUtils.getProperty(clsInstance, "reason");
						ECSChargingReversalStatus ecsCharging = new ECSChargingReversalStatus();
						ecsCharging = updateECSChargingFX(accountN, debitDate, bankDescription,bankRejectionReason,transaction_No);

						if(ecsCharging.getCount() == 1){
							countRows++;
							preparedStatement.addBatch();
							if(ecsCharging.getTransactionNumber() != 0){
								transactionNumberList.add(ecsCharging.getTransactionNumber());
							}

						}
					}
					else{
						countRows++;
						preparedStatement.addBatch();
					}

				} catch (Exception e) {
					e.printStackTrace();
					log.error(e);
				}
			}
			try {
				preparedStatement.executeBatch();
				con.commit();
				if(fileId.getFileIdentifier().equals("BRECS")){
					if(transactionNumberList.size()>0){
						ecsChargingProc(0,transactionNumberList);
					}

				}
				res.setCountRows(String.valueOf(countRows));
				res.setTransactionNumberToUpdate(transactionNumberToUpdate);

				System.out.println("in try block....--->>>>");
			} catch (Exception e) {
				log.info(e);
				e.printStackTrace();
				res.setErrorReason("Data Failure Issue while Uploading");
			} finally {
				con.commit();
				preparedStatement.close();
				con.close();
			}

		}
		log.info("END : In method insertIntoDynamicTable of FileUploadDaoImpl");
		return res;
	}


	////APS3 METHOD ADDED FOR DATA INSERT INTO TABLES
	@Override
	public ResponseOfInsert insertIntoPaymentsTable(int file_Id, List detailsList, FileIdentifierMstAps fileId,
			List<FileColMstAps> fileColMstList,String source,String userId) throws Exception {

		log.info("START :In method insertIntoPaymentsTable of FileUploadDaoImpl file_Id-->>"+file_Id);
		ResponseOfInsert res = new ResponseOfInsert();
		Connection con = null;
		int sCount=0;
		HashMap<String,List<String>> transactionNumberToUpdate = new HashMap<>();
		try {

			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("connection in method insertIntoDynamicTable __________" + con);
		} catch (Exception e) {
			log.info(e);
		}
		log.info("connection made in method insertIntoDynamicTable...");
		PreparedStatement preparedStatement = null;
		String classN = "com.airtel.acecad.bulkupload.dto." + fileId.getBeanObject();
		Class className = Class.forName(classN);

		int countRows =0;
		int counter =0;

		// Date sysDate = new Date();
		StringBuffer sb = new StringBuffer("Insert into ");

		sb.append(fileId.getTableName() + "(TRANSACTION_ID,INSERT_DATE,FILE_ID,CHANGE_WHO,FILE_IDENTIFIER,SOURCE");//TO BE MADE GENERIC
		//}
		for (FileColMstAps fileCol : fileColMstList) {

			sb.append(",");
			sb.append(fileCol.getColumnName());


		}

		sb.append(") " + "values (");

		sb.append(fileId.getSequenceName()+".NEXTVAL,sysdate,?,?,?,?");//fetching sequence from the table
		//	}
		for (FileColMstAps fileCol : fileColMstList) {
			sb.append(",?");
		}

		sb.append(")");

		//log.info("Query is "+sb);
		log.info("Query in method insertIntoPaymentsTable :" + sb.toString());
		if (con != null) {
			preparedStatement = con.prepareStatement(sb.toString());

			Iterator iter = detailsList.iterator();
			while (iter.hasNext()) {
				Object clsInstance = (Object) className.newInstance();
				clsInstance = iter.next();
				try {

					preparedStatement.setString(1, String.valueOf(file_Id));
					preparedStatement.setString(2, userId);
					preparedStatement.setString(3, fileId.getFileIdentifier());
					preparedStatement.setString(4, "UI");
					sCount=sCount+1;

					counter = 5;

					for (FileColMstAps fileCol : fileColMstList) {
						String dataType = fileCol.getDataType();

						if (dataType.equals("INTEGER")) {
							int dataInt = 0 ;
							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());

							if(data ==  null){
								data = "0";
							}
							if("S_NO".equalsIgnoreCase(fileCol.getColumnName())){
								preparedStatement.setInt(counter, sCount);
							}
							else{
								dataInt = Integer.parseInt(data);
								preparedStatement.setInt(counter, dataInt);
							}
						} else if (dataType.equals("STRING")) {
							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());
							//TRIMMING AND REMOVING SPECIAL CHARACTERS
							if(data!=null && data!=""){

								data=data.trim();
								data=data.replace("\n","");
								data=data.replace("&", "");
								data=data.replace("||", "");

								if("REMITTER_BRANCH".equalsIgnoreCase(fileCol.getColumnName())){

									if(data.length()>20 ){
										data=data.substring(0, 20);
										data=data.trim();//added on 5thSep
									}
								}
							}
							preparedStatement.setString(counter, data);
						} 
						
						else if (dataType.equals("ACCOUNTSTR")) {
							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());
							
							preparedStatement.setString(counter, data);
						}
						else if (dataType.equals("DOUBLE")) {
							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());

							log.info("setting double value-->>" +data);
							if(data!=null){
								Double dataDouble = Double.parseDouble(data);
								log.info("setting double value-->>" +dataDouble);
								preparedStatement.setDouble(counter, dataDouble);
							}
							else
								preparedStatement.setNull(counter, java.sql.Types.DOUBLE);
						} else if (dataType.equals("DATE")) {
							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());

							DateFormat formatter = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy");
							//DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
							Date date = null;
							java.sql.Date sqlDate = null;
							if(data != null){
								date = (Date) formatter.parse(data);
								sqlDate = new java.sql.Date(date.getTime());
							}

							preparedStatement.setDate(counter, sqlDate);
						} else if (dataType.equals("LONG")) {
							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());
							Long dataLong = Long.parseLong(data);
							preparedStatement.setLong(counter, dataLong);
						} else if (dataType.equals("RESTRICTEDSTRING")) {
							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());
							preparedStatement.setString(counter, data);
						}
						else if (dataType.equals("NOSPSTRING")) {
							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());
							preparedStatement.setString(counter, data);
						}
						else if(dataType.equals("EXCHANGERATE")){
							log.info("Inside Exchange Rate setting");
							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());
							if (data != null) {
								
								log.info("setting double value-->>" + Double.parseDouble(data));
								preparedStatement.setDouble(counter, Double.parseDouble(data));
							} else
								preparedStatement.setNull(counter, java.sql.Types.DOUBLE);

						}
						// Added by geeta
						else if (dataType.equals("ALPHANUMERIC")) {
							String data = BeanUtils.getProperty(clsInstance, fileCol.getClassAttributeName());
							preparedStatement.setString(counter, data);
						}

						counter++;
					}

					countRows++;
					preparedStatement.addBatch();


				} catch (Exception e) {
					e.printStackTrace();
					log.error(e);
				}
			}
			try {
				preparedStatement.executeBatch();
				con.commit();

				res.setCountRows(String.valueOf(countRows));

				res.setTransactionNumberToUpdate(transactionNumberToUpdate);


			} catch (Exception e) {
				e.printStackTrace();
				log.info(e);

				res.setErrorReason("Data Failure Issue while Uploading");
			} finally {
				con.commit();
				preparedStatement.close();
				con.close();
			}

		}
		log.info("END : In method insertIntoPaymentsTable of FileUploadDaoImpl");
		return res;
	}

	private String ecsChargingProc(int fileId,List<Integer> transactionNumberList) {

		log.info("START :in method ecsChargingProc of FileUploadDaoImpl");

		final String procedureCall = "{call ECS_INSERT_EPP_CUST_APS(?,?)}";
		Connection connection = null;
		CallableStatement callableStatement = null;
		String error_msg = null;
		try {
			connection = new JdbcTemplate(dataSource).getDataSource().getConnection();
			connection.setAutoCommit(false);
			ArrayDescriptor des = ArrayDescriptor.createDescriptor("ARRAY_CHECK_TYPE", connection);
			if(transactionNumberList == null){
				transactionNumberList = new ArrayList<>();
			}
			Object[] array = transactionNumberList.toArray();
			ARRAY array_to_pass = new ARRAY(des, connection, array);
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setArray(1, array_to_pass);
			callableStatement.setInt(2, fileId);
			callableStatement.executeUpdate();

		} catch (SQLException e) {
			log.info(e);

		} finally {

			if (connection != null)
				try {
					connection.commit();
					callableStatement.close();
					connection.close();
				} catch (SQLException e) {
					log.info(e);
				}
		}
		//System.out.println(error_msg);
		log.info("END :in method ecsChargingProc of FileUploadDaoImpl");
		return error_msg;
	}

	public boolean updateTransactionNumberStatus(HashMap<String,List<String>> transactionNumberToUpdate,String status) throws Exception{
		log.info("START : method updateSRDetailsApsStatus of FileUploadDaoImpl");
		Connection con = null;
		PreparedStatement preparedStatement = null;
		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("connection made...");
			StringBuffer sb = null;
			String val = "0";
			for(String s:transactionNumberToUpdate.keySet()){
				if(transactionNumberToUpdate.get(s)== null || transactionNumberToUpdate.get(s).get(0).equalsIgnoreCase("") || transactionNumberToUpdate.get(s).get(0) == ""){
					val="0";
				}else{
					val = transactionNumberToUpdate.get(s).get(0);
				}
				String state = transactionNumberToUpdate.get(s).get(1);

				String addStatusUpdate="";
				if(state != null && ( !state.equalsIgnoreCase(""))){
					addStatusUpdate = " , REJECTION_REASON_CODE = '"+state+"'"; //changed on 21thAug
				}
				//sb = new StringBuffer("update sr_Details_aps set status = '"+status+"' " +addStatusUpdate+" , nach_limit = case when nvl("+val+",0)>0 then "+(Double.parseDouble(val)*100)+" else nach_limit end  where Sr_category = 'ECS Registration' and sr_transaction_no = "+s);

				sb = new StringBuffer("update sr_Details_aps set status = '"+status+"' " +addStatusUpdate+"  where Sr_category = 'ECS Registration' and sr_transaction_no = "+s);

				preparedStatement = con.prepareStatement(sb.toString());
				preparedStatement.executeUpdate();
			}
			System.out.println("Query to update Transaction Number is "+sb.toString());

		} catch (Exception e) {
			log.info(e);


		} finally {

			try {
				con.commit();
				preparedStatement.close();
				con.close();
			} catch (Exception e) {
				log.info(e);
			}

		}
		log.info("END : method insertIntoFileStatus of FileUploadDaoImpl");
		return true;
	}


	public void updateDetailsStatus(String file_id,String addStatusUpdate) throws Exception{
		log.info("START : method updateSRDetailsApsStatus of FileUploadDaoImpl");
		Connection con = null;
		PreparedStatement preparedStatement = null;
		CallableStatement callableStatement = null;
		StringBuffer sb = null;
		final String procedureCall = "{call AIRTL_RECORD_REJECTION_DETAILS(?,?,?,?)}";
		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("connection made...");

            String query = "update airtl_suspense_alc_records set status_code=-1 ,STATUS_DESCRIPTION='"+addStatusUpdate+"'  where file_id = "+file_id;
			sb = new StringBuffer("update PAYMENT_STATUS_APS set status = -1 ,ERROR_REASON='"+addStatusUpdate+"'  where file_id = "+file_id);
			System.out.println("Query to update Transaction Number is "+sb.toString());

		   callableStatement = con.prepareCall(procedureCall);
		   callableStatement.setInt(1, Integer.parseInt(file_id));
		   callableStatement.setString(2,addStatusUpdate );
		   callableStatement.registerOutParameter(3, Types.VARCHAR); 
		   callableStatement.registerOutParameter(4, Types.VARCHAR);
		   callableStatement.executeUpdate();
			//preparedStatement = con.prepareStatement(sb.toString());
			//preparedStatement.executeUpdate();
		   log.info("updateDetailsStatus() in fileuploadDao===>");
           

		}
		catch (Exception e) {
			log.info(e);


		} finally {

			try {
				con.commit();
				//preparedStatement.close();
				callableStatement.close();
				con.close();
			} catch (Exception e) {
				log.info(e);
			}

		}
		log.info("END : method insertIntoFileStatus of FileUploadDaoImpl");

	}

	public String validateUTRStatus(List<String> utrSet,List<String> rbiAcct, String file_id
			,String paymentMode,List<String> IncValList) {
		log.info("start :in method validateUTRStatus of FileUploadDaoImpl file_id" + file_id+" paymentMode->"+paymentMode);
		
		final String procedureCall = "{call PAYMENT_ADVICE_PKG.validateUTRStatus(?,?,?,?,?,?,?)}";
		Connection connection = null;
		CallableStatement callableStatement = null;
		String error_msg = null;
		try {
			connection = new JdbcTemplate(dataSource).getDataSource().getConnection();
			connection.setAutoCommit(false);
			ArrayDescriptor des = ArrayDescriptor.createDescriptor("ARRAY_CHECK_TYPE", connection);
			Object[] arrayUtr = utrSet.toArray();
			Object[] arrayRbi = rbiAcct.toArray();
			Object[] arrayInc = IncValList.toArray();
			ARRAY array_to_pass_utr = new ARRAY(des, connection, arrayUtr);
			ARRAY array_to_pass_rbi = new ARRAY(des, connection, arrayRbi);
			ARRAY array_to_pass_Inc = new ARRAY(des, connection, arrayInc);
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setString(1, file_id);
			callableStatement.setArray(2, array_to_pass_utr);
			callableStatement.setArray(3, array_to_pass_rbi);
			callableStatement.setString(4, paymentMode);
			//ADED NEW
			callableStatement.setArray(5, array_to_pass_Inc);
			
			callableStatement.registerOutParameter(6, Types.VARCHAR);
			callableStatement.registerOutParameter(7, Types.VARCHAR);
			callableStatement.executeUpdate();

			error_msg = callableStatement.getString(6)+","+callableStatement.getString(7);
		} catch (SQLException e) {
			log.info(e);

		} finally {

			if (connection != null)
				try {
					connection.commit();
					callableStatement.close();
					connection.close();
				} catch (SQLException e) {
					log.info(e);
				}
		}
		// log.info(error_msg);
		log.info("END :in method validateUTRStatus of FileUploadDaoImpl error_msg" + error_msg);
		return error_msg;
	}

	public String insertIntoFileStatus(int file_Id, String fileIdentifier, String fileName, Double sum, int tot_rows,
			String source, String user, int status, String errorReason,  int invalidCount, Date date,String batch,List<String> list) {

		log.info("START : method insertIntoFileStatus of FileUploadDaoImpl fileIdentifier-->>"+fileIdentifier);
		System.out.println("START : method insertIntoFileStatus of FileUploadDaoImpl fileIdentifier-->>"+fileIdentifier);
		//log.info("REACHING FILE STATUS");

		Connection con = null;
		date=new java.util.Date();
		PreparedStatement preparedStatement = null;
		StringBuffer sb=null;
		String insertStatus="SUCCESS";

		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("file_id is : "+file_Id);
			log.info("connection made...");

			// for unix replace file_path by file_Name
			/*if("SAL".equalsIgnoreCase(fileIdentifier.toUpperCase())){
				sb = new StringBuffer(
						"Insert into AIRTL_SUSPENSE_ALC_STATUS(File_Id,File_Identifier,ORIGINAL_FILE_NAME,Sum_of_Amount,Total_Records,Invalid_Count,source,UPLOADED_BY,status,Error_Reason,UPLOADED_DATE,pending_approval_level,is_worklist_compliant,batch) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

			}*/
			if(list.contains(fileIdentifier.toUpperCase()) 
					|| "RNH".equalsIgnoreCase(fileIdentifier.toUpperCase())
					|| "PNH".equalsIgnoreCase(fileIdentifier.toUpperCase())){
				
				if("RNH".equalsIgnoreCase(fileIdentifier.toUpperCase()) 
						|| "PNH".equalsIgnoreCase(fileIdentifier.toUpperCase())){
					fileName = fileName.substring(fileName.lastIndexOf("/") + 1, fileName.length());
				}
				
				sb = new StringBuffer(
						"Insert into payment_status_aps(File_Id,File_Identifier,ORIGINAL_FILE_NAME,Sum_of_Amount,Total_Records,Invalid_Count,source,user_name,status,Error_Reason,Process_Date,pending_approval_level,is_worklist_compliant,batch) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			} else if(!"PAFILE".equalsIgnoreCase(fileIdentifier.toUpperCase()) || !"PAB".equalsIgnoreCase(fileIdentifier.toUpperCase()) ||"MIC".equalsIgnoreCase(fileIdentifier.toUpperCase())||"REV".equalsIgnoreCase(fileIdentifier.toUpperCase())) {
				sb = new StringBuffer(
						"Insert into file_status_aps(File_Id,File_Identifier,File_Path,Sum_of_Amount,Total_Records,Invalid_Count,source,user_name,status,Error_Reason,Process_Date,pending_approval_level,is_worklist_compliant,batch) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

			}
			preparedStatement = con.prepareStatement(sb.toString());
			preparedStatement.setInt(1, file_Id);
			preparedStatement.setString(2, fileIdentifier);
			preparedStatement.setString(3, fileName);
			preparedStatement.setDouble(4, sum);
			preparedStatement.setInt(5, tot_rows);
			preparedStatement.setInt(6, invalidCount);
			preparedStatement.setString(7, source);
			preparedStatement.setString(8, user);
			preparedStatement.setInt(9, status);
			preparedStatement.setString(10, errorReason);
			preparedStatement.setTimestamp(11, java.sql.Timestamp.valueOf(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(date.getTime())));
			preparedStatement.setInt(12,1);
			preparedStatement.setString(13, "Y");
			preparedStatement.setString(14, batch);
			//log.info(preparedStatement.toString());
			preparedStatement.executeQuery();

		} catch (Exception e) {
			e.printStackTrace();
			log.info(e);
		
			insertStatus="InsertFailure--"+e.toString();
			
			if(insertStatus.contains("ORA-00001: unique constraint"))
			{
			   log.info("Duplicate File ORA-00001:unique constraint =====>"+insertStatus);	
			   insertStatus ="Duplicate File Uploaded";
			}
			
			log.info("Failure Msg while uploading=====>"+insertStatus);

		} finally {

			try {
				con.commit();
				preparedStatement.close();
				con.close();
			} catch (Exception e) {
				e.printStackTrace();
				log.info(e);
			}

		}
		log.info("END : method insertIntoFileStatus of FileUploadDaoImpl");
		return insertStatus;
	} 
	
	

	public void insertIntoPaymentAdviceStatus(int file_Id, String fileIdentifier, String fileName, Double sum,
			int tot_rows, String paymentMode, String user, int status, String errorReason, int invalidCount, Date date,
			String processType, List<String> list) {

		log.info("START : method insertIntoFileStatus of FileUploadDaoImpl fileIdentifier-->>" + fileIdentifier);
		// log.info("REACHING FILE STATUS");

		Connection con = null;
		date = new java.util.Date();
		PreparedStatement preparedStatement = null;
		StringBuffer sb = null;

		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("file_id is : " + file_Id);
			log.info("connection made...");

			if("NEFT BANK STATEMENT".equalsIgnoreCase(paymentMode)){
				paymentMode="NEFT";
			}
			if(user!=null){
				user=user.toUpperCase();
			}
			// for unix replace file_path by file_Name

			sb = new StringBuffer(
					"Insert into ADVICE_REQUEST_STATUS_APS(I_REQUEST_ID,FILE_IDENTIFIER,USER_ID,ORIGINAL_FILE_NAME,TOTAL_RECORDS,STATUS_CODE,TOTAL_AMOUNT,VALID_COUNT,PROCESS_TYPE,UPLOADED_DATE,PAYMENT_MODE,AMOUNT_IN_INR) values(?,?,?,?,?,?,?,?,?,SYSDATE,?,?)");

			preparedStatement = con.prepareStatement(sb.toString());
			preparedStatement.setInt(1, file_Id);
			preparedStatement.setString(2, fileIdentifier);
			preparedStatement.setString(3, user);
			preparedStatement.setString(4, fileName);
			preparedStatement.setInt(5, tot_rows);
			preparedStatement.setInt(6, 1);
			preparedStatement.setDouble(7, sum);
			preparedStatement.setInt(8, tot_rows);
			preparedStatement.setString(9, processType);
			//preparedStatement.setTimestamp(10,
				//	java.sql.Timestamp.valueOf(new SimpleDateFormat("yyyy-MM-dd hh24:mm:ss").format(date.getTime())));
			preparedStatement.setString(10, paymentMode);
			preparedStatement.setDouble(11, sum);
			preparedStatement.executeQuery();

		} catch (Exception e) {
			e.printStackTrace();
			log.info(e);

		} finally {

			try {
				con.commit();
				preparedStatement.close();
				con.close();
			} catch (Exception e) {
				e.printStackTrace();
				log.info(e);
			}

		}
		log.info("END : method insertIntoFileStatus of FileUploadDaoImpl");
	}
	


	// added by ajit on 30 JAN
	public boolean checkPaymentCircle(String cir) {

		PreparedStatement prepareStatement = null;
		Connection con = null;
		ResultSet rs=null;

		StringBuffer sb = new StringBuffer("select * FROM circle_aps where market_code = '"+cir+"' and UPPER(STATUS) = 'ACTIVE'");

		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
		} catch (Exception e) {
			//log.info(e);
		}

		boolean status = false;
		if (con != null) {
			try {
				prepareStatement = con.prepareStatement(sb.toString());
				rs = prepareStatement.executeQuery();
				try {
					if(rs!=null){
						if (rs.next()) {
							status = true;
						}
						else{
							status = false;
						}
					}
				} catch (Exception e) {

					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					log.error(errors);
				}
				finally{
					con.commit();
					prepareStatement.close();
					rs.close();
					con.close();
				}
			} catch (SQLException e1) {
				StringWriter errors= new StringWriter();
				e1.printStackTrace(new PrintWriter(errors));
				log.error(errors);

			}
		}
		return status;
	}

	public void insertIntoPaymentStatus(int file_Id, String fileIdentifier, String fileName, double sum, int tot_rows,
			String source, String user, int status, String errorReason,  int invalidCount, Date date,String batch) {
		log.info("START insertIntoPaymentStatus");
		/*	TransactionDefinition def = new DefaultTransactionDefinition();
	    TransactionStatus status = transactionManager.getTransaction(def);
	    fileObj.setTransactionManager(transactionManager);
	    fileObj.setTransactionDef(def);
	    fileObj.setTransaction(status);*/
		final String procedureCall = "{call PAYMENT_FILE_DETAILS_INSERT(?,?,?,?,?,?,?,?,?,?,?,?,?)}";
		Connection connection = null;
		CallableStatement callableStatement=null;

		try {

			// Get Connection instance from dataSource
			//	System.out.println("connect"+ "ion:" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			//fileObj.setConnection(connection);
			connection.setAutoCommit(false);
			callableStatement = connection
					.prepareCall(procedureCall);

			callableStatement.setString(1, user);
			callableStatement.setString(2, null);
			callableStatement.setString(3, fileName);

			callableStatement.setString(4, user+fileName);//fileObj.getFinalFileName()
			callableStatement.setInt(5, tot_rows);

			callableStatement.setDouble(6,sum);
			callableStatement.setString(7,"PAYMENT");//fileObj.getFileTYpe()
			callableStatement.setString(8,fileIdentifier);//fileObj.getPaymentMode());
			callableStatement.setString(9, source);//fileObj.getMode());

			callableStatement.setString(10, String.valueOf(file_Id));
			callableStatement.registerOutParameter(11, Types.VARCHAR);
			callableStatement.registerOutParameter(12, Types.VARCHAR);
			callableStatement.registerOutParameter(13, Types.VARCHAR);

			callableStatement.executeUpdate();

			//fileObj.setFileID( callableStatement.getString(10));
			log.info("STATUS is-->>"+callableStatement.getString(11));
			log.info("ERROR_MSG id is-->>"+callableStatement.getString(13));
			log.info("ERROR_CODE id is-->>"+callableStatement.getString(12));
			//fileObj.setTrStatus("true");


		} catch (SQLException e) {
			//transactionManager.rollback(status);
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			log.error(errors);
			// fileObj.setTrStatus("false");	

		} 

		finally
		{
			if(callableStatement!=null)
			{
				try {
					callableStatement.close();

					connection.close();
				} catch (SQLException e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					log.error(errors);

				}
			}
		}
		log.info("END insertIntoPaymentStatus");
	}
	/*	
	public void insertIntoPaymentStatus(int file_Id, String fileIdentifier, String fileName, double sum, int tot_rows,
			String source, String user, int status, String errorReason,  int invalidCount, Date date,String batch) {

		log.info("START : method insertIntoFileStatus of FileUploadDaoImpl");
		//log.info("REACHING FILE STATUS");
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		Connection con = null;
		date=new java.util.Date();
		PreparedStatement preparedStatement = null;
		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("file_id is : "+file_Id);
			log.info("connection made...");

			// for unix replace file_path by file_Name
			StringBuffer sb = new StringBuffer(
					"Insert into PAYMENT_FILES_STATUS(File_Id,File_Identifier,File_Path,Sum_of_Amount,Total_Records,Invalid_Count,source,user_name,status,Error_Reason,Process_Date,pending_approval_level,is_worklist_compliant,batch) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

			preparedStatement = con.prepareStatement(sb.toString());
			preparedStatement.setInt(1, file_Id);
			preparedStatement.setString(2, fileIdentifier);
			preparedStatement.setString(3, fileName);
			preparedStatement.setDouble(4, sum);
			preparedStatement.setInt(5, tot_rows);
			preparedStatement.setInt(6, invalidCount);
			preparedStatement.setString(7, source);
			preparedStatement.setString(8, user);
			preparedStatement.setInt(9, status);
			preparedStatement.setString(10, errorReason);
			preparedStatement.setTimestamp(11, java.sql.Timestamp.valueOf(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(date.getTime())));
			preparedStatement.setInt(12,1);
			preparedStatement.setString(13, "Y");
			preparedStatement.setString(14, batch);
			//log.info(preparedStatement.toString());
			preparedStatement.executeQuery();

		} catch (Exception e) {
			log.info(e);


		} finally {

			try {
				con.commit();
				preparedStatement.close();
				con.close();
			} catch (Exception e) {
				log.info(e);
			}

		}
		log.info("END : method insertIntoFileStatus of FileUploadDaoImpl");
	}

	 */
	/*
	 * @author :- Shaleen Agarwal
	 */
	public List<FileColMstAps> readFileColMstApsData(String fileIdentifier) throws Exception {

		log.info("END : in method readFileColMstApsData of FileUploadDaoImpl");
		NamedParameterStatement namedParameter = null;
		Connection con = null;
		ResultSet rs= null;
		int count = 0;

		StringBuffer sb = new StringBuffer("select * FROM FILE_COL_MST_APS ");
		sb.append("WHERE FILE_IDENTIFIER = :fileIdentifier order by sl_no");
		log.info("QUERY ++ " + sb.toString());
		List<FileColMstAps> masterColList = new ArrayList<FileColMstAps>();
		try {

			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("connection __________" + con);
		} catch (Exception e) {
			//			log.info(e);
			log.info("Connection not established ", e);
		}
		try {
			log.info("connection made...");

			if (con != null) {

				namedParameter = new NamedParameterStatement(con, sb.toString());
				namedParameter.setString("fileIdentifier", fileIdentifier);

				rs = namedParameter.executeQuery();

				try {

					while (rs.next()) {
						FileColMstAps fileColMstAps = new FileColMstAps();

						fileColMstAps.setFileIdentifier(rs.getString(2));
						fileColMstAps.setColumnName(rs.getString(3));
						fileColMstAps.setClassAttributeName(rs.getString(4));
						fileColMstAps.setDataType(rs.getString(5));
						fileColMstAps.setRequired(rs.getString(6));
						fileColMstAps.setFormat(rs.getString(7));
						fileColMstAps.setRangeOfValues(rs.getString(8));
						fileColMstAps.setMaxValue(rs.getString(9));
						fileColMstAps.setMinValue(rs.getString(10));
						fileColMstAps.setColumnHeader(rs.getString(11));
						masterColList.add(fileColMstAps);
						count++;
					}
					log.info("count of row from FileColMstAps-->" + count);
				} catch (Exception e) {
					log.info(e);

				}

			}
		} catch (Exception e) {
			//			log.info(e);
		} finally {
			con.commit();
			namedParameter.close();
			rs.close();
			con.close();
		}
		log.info("END :in method readFileColMstApsData of FileUploadDaoImpl");
		return masterColList;

	}
	public String updateStatusCode(int fileId,String tableName,String userId,String fileIde){

		log.info("START :in method updateStatusCode of FileUploadDaoImpl fileIde->"+fileIde+" userId->"+userId);
		String status=null;
		final String procedureCall = "{call UPDATE_STATUS_CODE_APS(?,?,?,?,?,?,?)}";
		Connection connection = null;
		CallableStatement callableStatement = null;

		try {
			connection = new JdbcTemplate(dataSource).getDataSource().getConnection();
			connection.setAutoCommit(false);
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setInt(1, fileId);
			callableStatement.setString(2, tableName);
			callableStatement.setString(3, userId);
			callableStatement.setString(4, fileIde);
			callableStatement.registerOutParameter(5, Types.VARCHAR);
			callableStatement.registerOutParameter(6, Types.VARCHAR);
			callableStatement.registerOutParameter(7, Types.VARCHAR);
			callableStatement.executeUpdate();

			log.info("-->>"+callableStatement.getString(5));
			log.info("-->>"+callableStatement.getString(6));
			log.info("-->>"+callableStatement.getString(7));
			status=callableStatement.getString(5);
		} catch (SQLException e) {
			//log.error(e);
			log.info("updateStatusCode() errore ==>"+e.getMessage());
			status="Data Failure Issue while Uploading";

		} finally {

			if (connection != null)
				try {
					connection.commit();
					callableStatement.close();
					connection.close();
				} catch (SQLException e) {
					log.info(e);
				}
			log.info("END :in method updateStatusCode of FileUploadDaoImpl");
		}
		return status;
	}

	/*
	 * @author :- Shaleen Agarwal
	 */
	public FileIdentifierMstAps readFileIdentifierFromMst(String fileIdentifier) throws Exception {

		log.info("START :in method readFileIdentifierFromMst of FileUploadDaoImpl");
		FileIdentifierMstAps fileIdentifierMstAps = null;
		NamedParameterStatement namedParameter = null;
		Connection con = null;
		ResultSet rs = null;
		int count = 0;
		StringBuffer sb = new StringBuffer("select file_identifier,table_name,bean_object,amount_col,record_Count,record_sum,sequence_name FROM FILE_IDENTIFIER_MST_APS where FILE_IDENTIFIER ='"+fileIdentifier+"'");


		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("connection __________" + con);
		} catch (Exception e) {
			//log.info(e);
			log.info("Connection not established ", e);
		}

		log.info("connection made...");

		if (con != null) {
			namedParameter = new NamedParameterStatement(con, sb.toString());
			rs = namedParameter.executeQuery();
			try {
				while (rs.next()) {
					fileIdentifierMstAps = new FileIdentifierMstAps();
					fileIdentifierMstAps.setFileIdentifier(rs.getString(1));
					fileIdentifierMstAps.setTableName(rs.getString(2));
					fileIdentifierMstAps.setBeanObject(rs.getString(3));
					fileIdentifierMstAps.setAmountCol(rs.getInt(4));
					fileIdentifierMstAps.setRecordCount(rs.getInt(5));
					fileIdentifierMstAps.setRecordSum(rs.getLong(6));
					fileIdentifierMstAps.setSequenceName(rs.getString(7));
					count++;
				}
			} catch (Exception e) {
				log.info(e);

			}
			finally{
				con.commit();
				rs.close();
				namedParameter.close();
				con.close();
			}
		}


		log.info("END : in method readFileIdentifierFromMst  of FileUploadDaoImpl");
		return fileIdentifierMstAps;

	}


	public HashMap<String, String> readFileTypeList() throws Exception {

		log.info("START :in method readFileIdentifierFromMst of FileUploadDaoImpl");
		NamedParameterStatement namedParameter = null;
		Connection con = null;
		ResultSet rs = null;
		StringBuffer sb = new StringBuffer("select file_identifier,File_Type  from file_identifier_mst_aps where file_identifier IN('DPP','RDP','ADJ','CNR','DNR','RDJ','REF','SNR','RRC','RNH','PNH','CAC','CAN')");
		//StringBuffer sb = new StringBuffer("select file_identifier,File_Type  from file_identifier_mst_aps where file_identifier IN('DPP','RDP','ADJ','CNR','DNR','RDJ','REF','SNR','CHQ','EFT','MIS','DIR','REVCHQ','PTF','NONBANK')");

		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("connection __________" + con);
		} catch (Exception e) {
			//log.info(e);
			log.info("Connection not established ", e);
		}
		log.info("connection made...");
		HashMap<String,String> fileTypeList = new HashMap<String,String>();
		if (con != null) {
			namedParameter = new NamedParameterStatement(con, sb.toString());
			rs = namedParameter.executeQuery();
			try {
				while (rs.next()) {
					fileTypeList.put(rs.getString(1), rs.getString(2));
				}
			} catch (Exception e) {
				log.info(e);

			}
			finally{
				con.commit();
				rs.close();
				namedParameter.close();
				con.close();
			}
		}


		log.info("END : in method readFileIdentifierFromMst  of FileUploadDaoImpl");
		return fileTypeList;

	}

	public HashMap<String, String> readFileTypeListCP() throws Exception {

		log.info("START :in method readFileIdentifierFromMst of FileUploadDaoImpl");
		NamedParameterStatement namedParameter = null;
		Connection con = null;
		ResultSet rs = null;
		StringBuffer sb = new StringBuffer("select file_identifier,File_Type  from file_identifier_mst_aps where file_identifier IN('MIC','REV','SLN','NRC','ADP','ADR','DRV')");
		//StringBuffer sb = new StringBuffer("select file_identifier,File_Type  from file_identifier_mst_aps where file_identifier IN('DPP','RDP','ADJ','CNR','DNR','RDJ','REF','SNR','CHQ','EFT','MIS','DIR','REVCHQ','PTF','NONBANK')");

		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("connection __________" + con);
		} catch (Exception e) {
			//log.info(e);
			log.info("Connection not established ", e);
		}
		log.info("connection made...");
		HashMap<String,String> fileTypeList = new HashMap<String,String>();
		if (con != null) {
			namedParameter = new NamedParameterStatement(con, sb.toString());
			rs = namedParameter.executeQuery();
			try {
				while (rs.next()) {
					fileTypeList.put(rs.getString(1), rs.getString(2));
				}
			} catch (Exception e) {
				log.info(e);

			}
			finally{
				con.commit();
				rs.close();
				namedParameter.close();
				con.close();
			}
		}


		log.info("END : in method readFileIdentifierFromMst  of FileUploadDaoImpl");
		return fileTypeList;

	}

	/*
	 * @author :- Shaleen Agarwal
	 */

	public void test(List<String> testList)throws Exception{
		System.out.println("Reaching test");
		Connection connection = null;
		connection = new JdbcTemplate(dataSource).getDataSource().getConnection();
		PreparedStatement ps = connection.prepareStatement("select header_table from file_col_mst_aps where file_identifier ='ISECS' order by SL_NO");
		ResultSet rs = ps.executeQuery();
		int i = 0;
		while(rs.next()){
			String str = rs.getString(1).toUpperCase().trim().replaceAll("\n", "");
			System.out.println(str.toUpperCase().trim() + ">>>"+testList.get(i));
			if(str.equals(testList.get(i))){
				i++;
			}else{
				break;
			}
		}
	}
	@Override
	public String headerProcValidation1(List<String> headersList, String fileType, String fileName) {
		try {
			test(headersList);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		log.info("START :in method headerProcValidation of FileUploadDaoImpl");

		final String procedureCall = "{call FILE_VALIDATIONS_APS(?,?,?,?,?)}";
		Connection connection = null;
		CallableStatement callableStatement = null;
		String headerStatus = null;
		String error_msg = null;
		try {
			connection = new JdbcTemplate(dataSource).getDataSource().getConnection();
			connection.setAutoCommit(false);
			ArrayDescriptor des = ArrayDescriptor.createDescriptor("HEADER_CHECK_TYPE", connection);
			log.info("before arraylist");
			Object[] array = headersList.toArray();
			log.info("array: "+array);
			ARRAY array_to_pass = new ARRAY(des, connection, array);
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setString(1, fileType);
			callableStatement.setArray(2, array_to_pass);
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.registerOutParameter(5, Types.VARCHAR);
			callableStatement.executeUpdate();
			headerStatus = callableStatement.getString(3);

			error_msg = callableStatement.getString(4);
		} catch (SQLException e) {
			log.info(e);

		}catch (Exception e) {
			log.info(e);
		} finally {

			if (connection != null)
				try {
					//connection.commit();
					callableStatement.close();
					connection.close();
				}catch (SQLException e) {
					log.info(e);
				} catch (Exception e) {
					log.info(e);
				}
		}
		//log.info(error_msg);
		log.info("END :in method headerProcValidation of FileUploadDaoImpl error_msg"+error_msg);
		return error_msg;
	}
	@Override
	public String headerProcValidation(List<String> headersList, String fileType, String fileName) {
		try {
			test(headersList);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		log.info("START :in method headerProcValidation of FileUploadDaoImpl");

		final String query = "SELECT A.SL_NO, A.HEADER_TABLE" + 
				"    FROM FILE_COL_MST_APS A, FILE_IDENTIFIER_MST_APS B" + 
				"   WHERE     A.FILE_IDENTIFIER = B.FILE_IDENTIFIER" + 
				"         AND B.FILE_IDENTIFIER = ?" + 
				"ORDER BY A.SL_NO";
		Connection con = null;
		PreparedStatement ps = null;
		String headerStatus = null;
		ResultSet rs=null;
		String error_msg = null;
		int count=0;
		Map<String,String> fileTypeList = new LinkedHashMap<String,String>(); 
		try {

			try {
				con = new JdbcTemplate(dataSource).getDataSource().getConnection();
				ps = con.prepareStatement(query);
				ps.setString(1, fileType);
				rs = ps.executeQuery();
				while(rs.next()){
					log.info("Inside while rs loop");
					fileTypeList.put(rs.getString(1), rs.getString(2));
				}
				int i=0;
				log.info("headersList.size(): "+headersList.size());
				log.info("fileTypeList.size() :"+fileTypeList.size());
				if(headersList.size()>0 && fileTypeList.size()>0) {
				if(fileTypeList.size()==headersList.size()) {
					for (Map.Entry<String, String> entry : fileTypeList.entrySet()) {
						System.out.println(entry.getKey() + " = " + entry.getValue());
						if(entry.getValue().toString().equalsIgnoreCase(headersList.get(i).toString())) {
							count++;
						}else {
							
							error_msg="HEADER FIELDS VALUES DOES NOT MATCH";
							log.info("error_msg: "+error_msg);
						}
						i++;
					}
					
				}else {
					error_msg="HEADER COUNT DOES NOT MATCH";
					log.info("error_msg: "+error_msg);
				}
				
				}else {
					error_msg="INPUT VALUES CANNOT BE NULL";
					log.info("error_msg: "+error_msg);
				}
				if(count==fileTypeList.size()) {
					log.info("header matched"+ count);
					error_msg="SUCCESS";
				}
				
			} catch (Exception e) {
				
				log.info("Conection :: ", e);
			}




		} catch (Exception e) {
			log.info("Exception", e);
		} finally {
			try {
			if(con != null){
				con.close();
			}
			}catch(SQLException e) {
				log.info("Exception", e);
			}catch(Exception e) {
				log.info("Exception", e);
			}

		}		//log.info(error_msg);
		log.info("END :in method headerProcValidation of FileUploadDaoImpl error_msg"+error_msg);
		return error_msg;
	}
	
	
	
	/*
	 * @author :- Shaleen Agarwal
	 */

	public String approveFile(List<String> checkedFileIDList,List<String> checkedReasonList,List<String> checkedRemarkList,String user,String action) throws Exception{
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		String status = null;
		Connection conn=null;
		log.info("Hello Buddy");
		List<String> emptyList = new ArrayList<>();
		final String procedureCall = "{call FILE_UPLOAD_APPROVE_APS(?,?,?,?,?,?)}";
		try {
			conn = jdbcTemplate.getDataSource().getConnection();
			ArrayDescriptor des = ArrayDescriptor.createDescriptor("ARRAY_CHECK_TYPE", conn);
			Object[] arraySR = checkedFileIDList.toArray();
			Object[] arrayRemarks = checkedRemarkList.toArray();
			Object[] arrayReasons = checkedReasonList.toArray();
			ARRAY array_to_pass_file = new ARRAY(des, conn, arraySR);
			ARRAY array_to_pass_reason = new ARRAY(des, conn, arrayReasons);
			ARRAY array_to_pass_remarks = new ARRAY(des, conn, arrayRemarks);
			CallableStatement callableStatement = conn.prepareCall(procedureCall);
			callableStatement.setArray(1, array_to_pass_file);
			callableStatement.setString(2, action);
			callableStatement.setString(3,user );
			callableStatement.setArray(4, array_to_pass_remarks);
			callableStatement.setArray(5, array_to_pass_reason);
			callableStatement.registerOutParameter(6, Types.VARCHAR);
			callableStatement.executeUpdate();
			status = callableStatement.getString(6);
			log.info("status in approve proc "+status);
			callableStatement.close();
		} catch (Exception e) {
			log.error(e);
		}finally{
			conn.commit();
			conn.close();
		}
		return status;
	}


	public String getCircleFromMarketCode(String marketCode)throws Exception{

		log.info("START:In getCircleFromMarketCode method of FileUploadDaoImpl "+marketCode);
		Connection con = null;
		String circle = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String query;
		query = "select circle from circle_Aps where market_code="+marketCode;
		try {

			try {
				con = new JdbcTemplate(dataSource).getDataSource().getConnection();
				ps = con.prepareStatement(query);
				rs = ps.executeQuery();
				while(rs.next()){
					circle = rs.getString(1);
				}
				if(circle == null){
					circle="";
				}
			} catch (Exception e) {
				circle="";
				log.info("Conection :: ", e);
			}




		} catch (Exception e) {
			log.info("Exception", e);
		} finally {
			if(con != null){
				con.close();
			}

		}
		log.info("Market code is "+marketCode+" and circle is "+circle);
		log.info("getCircleFromMarketCode aps-->>>  " + circle);


		return circle;

	}
	public FileStatusDTO getFileStatusAPS(int page){
		DecimalFormat dfa = new DecimalFormat("#");
		dfa.setMaximumFractionDigits(8);
		log.info("START : in getFileStatusAPS");
		List<FileStatusAPS> fileStatusApsList = new ArrayList<>();
		FileStatusDTO fileStatusDTO = new FileStatusDTO();
		NamedParameterStatement namedParameter = null;
		int totalRecords=0;
		int totalPages =0,recordsPerPage=10;
		String totRecordsQuery = "select count(*) from (select  f.*,RowNum r from FILE_STATUS_APS f where (f.status>=0 or f.status IN(-12,-13,-14,-15,-6)) AND f.file_identifier IN('ADJ','CNR','DNR','DPP','RDJ','RDP','REF','SNR','RRC','RNH','PNH')) ";
		Connection conn = null;
		FileStatusDTO workflowDTO = new FileStatusDTO();
		try{
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			log.info("connect" + "ion:" + dataSource.getConnection());
			conn = jdbcTemplate.getDataSource().getConnection();
			PreparedStatement psTotalRecords = conn.prepareStatement(totRecordsQuery);
			ResultSet rsTotalRecords = psTotalRecords.executeQuery();
			if(rsTotalRecords.next()){
				totalRecords = rsTotalRecords.getInt(1);
			}
			psTotalRecords.close();
			rsTotalRecords.close();
			if(totalRecords%recordsPerPage ==0){
				totalPages = totalRecords/recordsPerPage;
			}else{
				totalPages = (totalRecords/recordsPerPage)+1;
			}
			log.info("Total Pages are "+totalPages);

			fileStatusDTO.setTotalPages(totalPages);
			fileStatusDTO.setTotalResults(totalRecords);
			ResultSet rs= null;
			int count = 0;
			StringBuffer sb = new StringBuffer("select * from (select q.*,RowNum r  from (select  f.file_id,f.file_identifier,f.file_path,f.sum_of_amount,f.total_records,f.invalid_count,f.source,f.user_name,f.status,f.error_reason,f.process_date,f.pending_approval_level,f.is_worklist_compliant,s.status_meaning,UPPER(u.user_name) from FILE_STATUS_APS f LEFT OUTER JOIN STATUS_MASTER_TABLE_APS s on f.status = s.status_code LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_name) where (f.status>=0 or f.status IN(-12,-13,-14,-15,-6)) AND f.file_identifier IN('ADJ','CNR','DNR','DPP','RDJ','RDP','REF','SNR','RRC','RNH','PNH','CAC','CAN') order by f.file_id desc)q ) where r  between "+(((page-1)*recordsPerPage)+1) +" AND "+(page*recordsPerPage));
			log.info(sb);
			try {

				conn = new JdbcTemplate(dataSource).getDataSource().getConnection();
				conn.setAutoCommit(false);
			} catch (Exception e) {

			}
			try {

				if (conn != null) {

					namedParameter = new NamedParameterStatement(conn, sb.toString());
					rs = namedParameter.executeQuery();

					try {

						while (rs.next()) {
							FileStatusAPS fileStatusAps = new FileStatusAPS();
							int fileId = rs.getInt(1);
							fileStatusAps.setFileId(fileId);
							fileStatusAps.setFileIdentifier(rs.getString(2));
							String fileName = rs.getString(3);
							String fileNameFinal = fileName.substring(fileName.lastIndexOf("/")+1, fileName.length());
							String marketCode = fileNameFinal.substring(0, 3);
							String circle = getCircleFromMarketCode(marketCode);
							fileStatusAps.setCircle(circle);
							fileStatusAps.setFilePath(fileNameFinal);
							fileStatusAps.setSumOfAmount(String.valueOf(dfa.format((Double.parseDouble(String.valueOf(rs.getLong(4))))/100)));
							fileStatusAps.setTotalRecords(rs.getInt(5));
							fileStatusAps.setInvalidCount(rs.getInt(6));
							fileStatusAps.setSource(rs.getString(7));
							fileStatusAps.setOlmId(rs.getString(8));
							fileStatusAps.setStatus(rs.getInt(9));
							fileStatusAps.setStatusDescription(rs.getString(10));
							String date =rs.getString(11);
							DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
							Date startDate = df.parse(date);
							SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm");
							String parsedDate = formatter.format(startDate);
							fileStatusAps.setProcessDate(parsedDate);
							fileStatusAps.setPendingApprovalLevel(rs.getInt(12));
							fileStatusAps.setIsWorkListCompliant(rs.getString(13));
							fileStatusAps.setStatusMessage(rs.getString(14));
							fileStatusAps.setFirstLastName(rs.getString(15));
							fileStatusApsList.add(fileStatusAps);
							fileStatusDTO.setFileStatusList(fileStatusApsList);
							count++;
						}
						log.info("count of row from FileStatusAPS-->" + count);
					} catch (Exception e) {
						log.info(e);

					}

				}
			} catch (Exception e) {

			} finally {
				try{
					conn.commit();
					namedParameter.close();
					rs.close();
					conn.close();
				}catch(Exception e){
					log.error(e);
				}
			}
			log.info("END :in method readFileColMstApsData of FileUploadDaoImpl");

		}catch(Exception e){
			log.error(e);
		}
		fileStatusDTO.setResultPerPage(fileStatusApsList.size());
		return fileStatusDTO;
	}
	public FileStatusDTO getFileStatusAPSForApprove(int page){
		DecimalFormat dfa = new DecimalFormat("#");
		dfa.setMaximumFractionDigits(8);
		log.info("START : in getFileStatusAPS");
		List<FileStatusAPS> fileStatusApsList = new ArrayList<>();
		FileStatusDTO fileStatusDTO = new FileStatusDTO();
		NamedParameterStatement namedParameter = null;
		int totalRecords=0;
		int totalPages =0,recordsPerPage=10;
		String totRecordsQuery = "select count(*) from (select  f.*,RowNum r from FILE_STATUS_APS f where (f.status>=1 and f.status<=4) AND f.source <> 'SFTP' AND f.file_identifier IN('ADJ','CNR','DNR','DPP','RDJ','RDP','REF','SNR','RNH','PNH','CAC','CAN')) ";
		log.info(totRecordsQuery);
		Connection conn = null;

		try{
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			log.info("connect" + "ion:" + dataSource.getConnection());
			conn = jdbcTemplate.getDataSource().getConnection();

			int reasoncode;String reason;
			HashMap<String,Integer> reasons = new HashMap<>();
			String rejectionReason="SELECT REASON_CODE,REASON FROM REJECTION_REASON_APS order by reason";
			PreparedStatement pst = conn.prepareStatement(rejectionReason);
			ResultSet resultSets4 = pst.executeQuery();
			while(resultSets4 != null && resultSets4.next()) {
				reasoncode =  resultSets4.getInt(1);
				reason = resultSets4.getString(2);
				reasons.put(reason,reasoncode);
			}
			fileStatusDTO.setReasons(reasons);
			pst.close();
			resultSets4.close();


			PreparedStatement psTotalRecords = conn.prepareStatement(totRecordsQuery);
			ResultSet rsTotalRecords = psTotalRecords.executeQuery();
			if(rsTotalRecords.next()){
				totalRecords = rsTotalRecords.getInt(1);
			}
			psTotalRecords.close();
			rsTotalRecords.close();
			if(totalRecords%recordsPerPage ==0){
				totalPages = totalRecords/recordsPerPage;
			}else{
				totalPages = (totalRecords/recordsPerPage)+1;
			}
			log.info("Total Pages are "+totalPages);

			fileStatusDTO.setTotalPages(totalPages);
			fileStatusDTO.setTotalResults(totalRecords);
			ResultSet rs= null;
			int count = 0;
			StringBuffer sb = new StringBuffer("select * from (select q.*,RowNum r from (select  f.file_id,f.file_identifier,f.file_path,f.sum_of_amount,f.total_records,f.invalid_count,f.source,f.user_name,f.status,f.error_reason,f.process_date,f.pending_approval_level,f.is_worklist_compliant,s.status_meaning,UPPER(u.user_name) from FILE_STATUS_APS f LEFT OUTER JOIN STATUS_MASTER_TABLE_APS s on f.status = s.status_code LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_name) where (f.status>=1 and f.status<=4) AND f.source <> 'SFTP' AND f.file_identifier IN('ADJ','CNR','DNR','DPP','RDJ','RDP','REF','SNR','RNH','PNH') order by f.file_id)q) where r  between "+(((page-1)*recordsPerPage)+1) +" AND "+(page*recordsPerPage));
			log.info(sb);
			try {

				conn = new JdbcTemplate(dataSource).getDataSource().getConnection();
				conn.setAutoCommit(false);
			} catch (Exception e) {

			}
			try {

				if (conn != null) {

					namedParameter = new NamedParameterStatement(conn, sb.toString());
					rs = namedParameter.executeQuery();

					try {

						while (rs.next()) {
							FileStatusAPS fileStatusAps = new FileStatusAPS();
							fileStatusAps.setFileId(rs.getInt(1));
							fileStatusAps.setFileIdentifier(rs.getString(2));
							String fileName = rs.getString(3);
							fileStatusAps.setFilePath(fileName.substring(fileName.lastIndexOf("/")+1, fileName.length()));
							String fileNameFinal = fileName.substring(fileName.lastIndexOf("/")+1, fileName.length());
							String marketCode = fileNameFinal.substring(0, 3);
							String circle = getCircleFromMarketCode(marketCode);
							fileStatusAps.setCircle(circle);
							fileStatusAps.setSumOfAmount(String.valueOf(dfa.format((Double.parseDouble(String.valueOf(rs.getLong(4))))/100)));
							fileStatusAps.setTotalRecords(rs.getInt(5));
							fileStatusAps.setInvalidCount(rs.getInt(6));
							fileStatusAps.setSource(rs.getString(7));
							fileStatusAps.setOlmId(rs.getString(8));
							fileStatusAps.setStatus(rs.getInt(9));
							fileStatusAps.setStatusDescription(rs.getString(10));
							String date =rs.getString(11);
							DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
							Date startDate = df.parse(date);
							SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm");
							String parsedDate = formatter.format(startDate);
							fileStatusAps.setProcessDate(parsedDate);
							fileStatusAps.setPendingApprovalLevel(rs.getInt(12));
							fileStatusAps.setIsWorkListCompliant(rs.getString(13));
							fileStatusAps.setStatusMessage(rs.getString(14));
							fileStatusAps.setFirstLastName(rs.getString(15));
							fileStatusApsList.add(fileStatusAps);

							count++;
						}
						log.info("count of row from FileStatusAPS-->" + count);
					} catch (Exception e) {
						log.info(e);

					}

				}
			} catch (Exception e) {

			} finally {
				try{
					conn.commit();
					namedParameter.close();
					rs.close();
					conn.close();
				}catch(Exception e){
					log.error(e);
				}
			}
			log.info("END :in method readFileColMstApsData of FileUploadDaoImpl");

		}catch(Exception e){
			log.error(e);
		}
		fileStatusDTO.setFileStatusList(fileStatusApsList);
		fileStatusDTO.setResultPerPage(fileStatusApsList.size());
		return fileStatusDTO;
	}

	@Override
	public String duplicateProc(int fileId, String fileIdentifier) {

		log.info("START :in method duplicateProc of FileUploadDaoImpl file_identifier->>"+fileIdentifier);

		String procedureCall="{call DUPLICATE_RECORDS_APS(?,?,?,?)}";
		if(fileIdentifier.equalsIgnoreCase("BNECS") || fileIdentifier.equalsIgnoreCase("ISECS")){
			procedureCall = "{call DUPLICATE_RECORDS_BANK_APS(?,?,?,?)}";
		}



		Connection connection = null;
		CallableStatement callableStatement=null;
		String invalidCount = null;
		int count=0;
		String error_msg = null;
		try {

			// Get Connection instance from dataSource

			connection = new JdbcTemplate(dataSource).getDataSource().getConnection();
			connection.setAutoCommit(false);
			callableStatement = connection.prepareCall(procedureCall);

			callableStatement.setInt(1, fileId);

			callableStatement.setString(2, fileIdentifier);

			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.registerOutParameter(4, Types.VARCHAR);

			callableStatement.executeUpdate();

			invalidCount = callableStatement.getString(3);
			error_msg = callableStatement.getString(4);

			log.info("Invalid in duplicateProc-->>" + invalidCount);
			log.info("Invalid in duplicateProc error_msg-->>" + error_msg);
			/*if(invalidCount != null){
				count = Integer.parseInt(invalidCount);
			}else{
				count =0;
			}*/
		} catch (SQLException e) {
			log.info(e);

		} finally {

			if (connection != null)
				try {
					connection.commit();
					callableStatement.close();
					connection.close();
				} catch (SQLException e) {
					log.info(e);
				}
		}


		log.info("END :in method duplicateProc of FileUploadDaoImpl");
		//return count;
		return invalidCount;
	}
	public String approveFileCP(List<String> checkedFileIDList,List<String> checkedReasonList,List<String> checkedRemarkList,String user,String action) throws Exception{
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		String status = null;
		Connection conn=null;
		log.info("Hello Buddy");
		List<String> emptyList = new ArrayList<>();
		final String procedureCall = "{call CP_FILE_UPLOAD_APPROVE(?,?,?,?,?,?)}";
		try {
			conn = jdbcTemplate.getDataSource().getConnection();
			ArrayDescriptor des = ArrayDescriptor.createDescriptor("ARRAY_CHECK_TYPE", conn);
			Object[] arraySR = checkedFileIDList.toArray();
			Object[] arrayRemarks = checkedRemarkList.toArray();
			Object[] arrayReasons = checkedReasonList.toArray();
			ARRAY array_to_pass_file = new ARRAY(des, conn, arraySR);
			ARRAY array_to_pass_reason = new ARRAY(des, conn, arrayReasons);
			ARRAY array_to_pass_remarks = new ARRAY(des, conn, arrayRemarks);
			CallableStatement callableStatement = conn.prepareCall(procedureCall);
			callableStatement.setArray(1, array_to_pass_file);
			callableStatement.setString(2, action);
			callableStatement.setString(3,user );
			callableStatement.setArray(4, array_to_pass_remarks);
			callableStatement.setArray(5, array_to_pass_reason);
			callableStatement.registerOutParameter(6, Types.VARCHAR);
			callableStatement.executeUpdate();
			status = callableStatement.getString(6);
			log.info("status in approve proc "+status);
			callableStatement.close();
		} catch (Exception e) {
			log.error(e);
		}finally{
			conn.commit();
			conn.close();
		}
		return status;
	}


	@Override
	public PaymentTransferDetails getpaymentWorkflow() throws Exception {
		String paymentQuery=null;
		Connection con = null;
		String totRecords=null;
		int totalPages =0;
		int countRecords=0;
		int recordsPerPage=10;
		List<PaymentTransferDetails> paymentTransfer=new ArrayList<>();
		try{
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			totRecords="select count(*) from (select P.USERID,p.TYPE,p.TRACKINGID,p.TRACKINGIDSERV,p.TRANSDATE,p.ACCOUNT_NO,p.AMOUNT,p.ANNOTATION,p.CHEQUE_NO,p.COLLECTIONMANAGERNAME,p.CREATEDATE,P.MODIFIEDATE,p.FILE_ID,p.INVOICE_NO,P.LOB,p.NO_OF_HIT,P.ORIGTRACKINGID,P.ORIGTRACKINGIDSERV,p.SENTFXFLAG,P.STATUSCODE,p.TICKETNO,p.STATUSDESCRIPTION from PAYMENT_TRANSER p)";
			paymentQuery="select P.USERID,p.TYPE,p.TRACKINGID,p.TRACKINGIDSERV,p.TRANSDATE,p.ACCOUNT_NO,p.AMOUNT,p.ANNOTATION,p.CHEQUE_NO,p.COLLECTIONMANAGERNAME,p.CREATEDATE,P.MODIFIEDATE,p.FILE_ID,p.INVOICE_NO,P.LOB,p.NO_OF_HIT,P.ORIGTRACKINGID,P.ORIGTRACKINGIDSERV,p.SENTFXFLAG,P.STATUSCODE,p.TICKETNO,p.STATUSDESCRIPTION from PAYMENT_TRANSER p";
			con = jdbcTemplate.getDataSource().getConnection();
			PreparedStatement records=con.prepareStatement(paymentQuery);
			ResultSet rst=records.executeQuery();
			PreparedStatement psTotalRecords = con.prepareStatement(totRecords);
			ResultSet rs = psTotalRecords.executeQuery();

			while (rs!=null && rs.next()) {
				countRecords=rs.getInt(1);

			}
			while(rst!=null && rst.next()){
				paymentDetails=new PaymentTransferDetails();
				paymentDetails.setUserId(rst.getString(1));
				paymentDetails.setType(rst.getString(2));
				paymentDetails.setTrackingId(rst.getString(3));
				paymentDetails.setTrackinIdServ(rst.getString(4));
				String dates=rst.getString(5);
				DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
				Date transDate = df.parse(dates);
				SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy kk:mm");
				String parsedTransDate = formatter.format(transDate);
				paymentDetails.setTransDate(parsedTransDate);
				paymentDetails.setAccountNo(rst.getString(6));
				paymentDetails.setAmount(rst.getLong(7));
				paymentDetails.setAnnoation(rst.getString(8));
				paymentDetails.setChequeNo(rst.getString(9));
				paymentDetails.setCollectionManagerName(rst.getString(10));
				String crDate=rst.getString(11);
				DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
				Date createDate = df1.parse(crDate);
				SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				String parsedCreateDate = formatter1.format(createDate);
				paymentDetails.setCreatedDate(parsedCreateDate);
				paymentDetails.setFileId(rst.getInt(13));
				paymentDetails.setInvoiceNo(rst.getString(14));
				paymentDetails.setLob(rst.getString(15));
				paymentDetails.setNoOfHit(rst.getString(16));
				paymentDetails.setOrigTrackingId(rst.getString(17));
				paymentDetails.setOrigTrackinIdServ(rst.getString(18));
				paymentDetails.setSentFxFlag(rst.getString(19));
				paymentDetails.setStatusCode(rst.getString(20));
				paymentDetails.setTicketNo(rst.getString(21));
				paymentDetails.setStatusDescription(rst.getString(22));
				paymentTransfer.add(paymentDetails);

				System.out.println("paymentTransfer list is:"+paymentTransfer+"and payment list is--->>>"+paymentDetails);

			}

			if(countRecords%recordsPerPage ==0){
				totalPages = countRecords/recordsPerPage;
			}else{
				totalPages = (countRecords/recordsPerPage)+1;
			}
			rs.close();
			rst.close();
			if (con != null && !con.isClosed()) {
				con.close();
			}
		}

		catch (SQLException e) {
			throw new RuntimeException(e);
		}
		paymentDetails.setPaymentTransfer(paymentTransfer);
		paymentDetails.setRecordCount(countRecords);
		paymentDetails.setTotalPages(totalPages);

		return paymentDetails;
	}
	@Override
	public PaymentTransferDetails getsearchpaymentWorkflow(String amount,String accountNo) throws Exception {
		String paymentQuery=null;
		Connection con = null;
		String totRecords=null;
		int totalPages =0;
		int countRecords=0;
		int recordsPerPage=10;
		List<PaymentTransferDetails> paymentTransfer=new ArrayList<>();
		try{
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			totRecords="select count(*) from (select P.USERID,p.TYPE,p.TRACKINGID,p.TRACKINGIDSERV,p.TRANSDATE,p.ACCOUNT_NO,p.AMOUNT,p.ANNOTATION,p.CHEQUE_NO,p.COLLECTIONMANAGERNAME,p.CREATEDATE,P.MODIFIEDATE,p.FILE_ID,p.INVOICE_NO,P.LOB,p.NO_OF_HIT,P.ORIGTRACKINGID,P.ORIGTRACKINGIDSERV,p.SENTFXFLAG,P.STATUSCODE,p.TICKETNO,p.STATUSDESCRIPTION from PAYMENT_TRANSER p where p.amount='"+amount+"' and p.ACCOUNT_NO='"+accountNo+"')";
			paymentQuery="select P.USERID,p.TYPE,p.TRACKINGID,p.TRACKINGIDSERV,p.TRANSDATE,p.ACCOUNT_NO,p.AMOUNT,p.ANNOTATION,p.CHEQUE_NO,p.COLLECTIONMANAGERNAME,p.CREATEDATE,P.MODIFIEDATE,p.FILE_ID,p.INVOICE_NO,P.LOB,p.NO_OF_HIT,P.ORIGTRACKINGID,P.ORIGTRACKINGIDSERV,p.SENTFXFLAG,P.STATUSCODE,p.TICKETNO,p.STATUSDESCRIPTION from PAYMENT_TRANSER p where p.amount='"+amount+"' and p.ACCOUNT_NO='"+accountNo+"'";
			con = jdbcTemplate.getDataSource().getConnection();
			PreparedStatement records=con.prepareStatement(paymentQuery);
			ResultSet rst=records.executeQuery();
			PreparedStatement psTotalRecords = con.prepareStatement(totRecords);
			ResultSet rs = psTotalRecords.executeQuery();

			while (rs!=null && rs.next()) {
				countRecords=rs.getInt(1);

			}
			while(rst!=null && rst.next()){
				paymentDetails=new PaymentTransferDetails();
				paymentDetails.setUserId(rst.getString(1));
				paymentDetails.setType(rst.getString(2));
				paymentDetails.setTrackingId(rst.getString(3));
				paymentDetails.setTrackinIdServ(rst.getString(4));
				String dates=rst.getString(5);
				DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
				Date transDate = df.parse(dates);
				SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy kk:mm");
				String parsedTransDate = formatter.format(transDate);
				paymentDetails.setTransDate(parsedTransDate);
				paymentDetails.setAccountNo(rst.getString(6));
				paymentDetails.setAmount(rst.getLong(7));
				paymentDetails.setAnnoation(rst.getString(8));
				paymentDetails.setChequeNo(rst.getString(9));
				paymentDetails.setCollectionManagerName(rst.getString(10));
				String crDate=rst.getString(11);
				DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
				Date createDate = df1.parse(crDate);
				SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				String parsedCreateDate = formatter1.format(createDate);
				paymentDetails.setCreatedDate(parsedCreateDate);
				paymentDetails.setFileId(rst.getInt(13));
				paymentDetails.setInvoiceNo(rst.getString(14));
				paymentDetails.setLob(rst.getString(15));
				paymentDetails.setNoOfHit(rst.getString(16));
				paymentDetails.setOrigTrackingId(rst.getString(17));
				paymentDetails.setOrigTrackinIdServ(rst.getString(18));
				paymentDetails.setSentFxFlag(rst.getString(19));
				paymentDetails.setStatusCode(rst.getString(20));
				paymentDetails.setTicketNo(rst.getString(21));
				paymentDetails.setStatusDescription(rst.getString(22));
				paymentTransfer.add(paymentDetails);

				System.out.println("paymentTransfer list is:"+paymentTransfer+"and payment list is--->>>"+paymentDetails);

			}
			if(countRecords%recordsPerPage ==0){
				totalPages = countRecords/recordsPerPage;
			}else{
				totalPages = (countRecords/recordsPerPage)+1;
			}
			rs.close();
			if (con != null && !con.isClosed()) {
				con.close();
			}
		}
		catch (SQLException e) {
			throw new RuntimeException(e);
		}
		paymentDetails.setPaymentTransfer(paymentTransfer);
		paymentDetails.setRecordCount(countRecords);
		paymentDetails.setTotalPages(totalPages);
		return paymentDetails;
	}

	@Override
	public PaymentTransferDetails getpaymentApproveWorkflow() throws Exception {

		System.out.println("in approve method");

		return paymentDetails;

	}



	@Override
	public ChequeBounceDetails getAesChequeDetails() throws Exception {
		String paymentQuery=null;
		Connection con = null;

		List<ChequeBounceDetails> chequeDetails=new ArrayList<>();
		try{
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			paymentQuery="select a.FILE_ID,a.BANK_ACCOUNT_NUMBER,a.CHEQUE_AMOUNT,a.CHEQUE_NO,a.CREATED_DATE,a.MODIFIED_DATE,a.RETURN_RECEIVED_DATE,a.STATUS_DESCRIPTION,a.TRACKING_ID,a.TRACKING_ID_SER,a.USER_ID from AESCHEQUE a";
			con = jdbcTemplate.getDataSource().getConnection();
			PreparedStatement psTotalRecords = con.prepareStatement(paymentQuery);
			ResultSet rs = psTotalRecords.executeQuery();
			while(rs!=null && rs.next()){
				chequeBounceDetails=new ChequeBounceDetails();
				chequeBounceDetails.setFileId(rs.getInt(1));
				chequeBounceDetails.setBankAccountNumner(rs.getString(2));
				chequeBounceDetails.setChqAmount(rs.getLong(3));
				chequeBounceDetails.setChequeNo(rs.getString(4));
				String crDate=rs.getString(5);
				DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
				Date createDate = df1.parse(crDate);
				SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				String parsedCreateDate = formatter1.format(createDate);
				chequeBounceDetails.setCreatedDate(parsedCreateDate);

				String modifiedDate=rs.getString(6);
				DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
				Date modDtae = df.parse(modifiedDate);
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				String parsedModDate = formatter.format(modDtae);
				chequeBounceDetails.setModifiedDate(parsedModDate);

				String returnDate=rs.getString(7);
				DateFormat dform = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
				Date retDate = dform.parse(returnDate);
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				String parsedReturnDate = format.format(retDate);
				chequeBounceDetails.setRetuenReceivedDate(parsedReturnDate);
				chequeBounceDetails.setStatusDescription(rs.getString(8));
				chequeBounceDetails.setTrackingId(rs.getString(9));
				chequeBounceDetails.setTrackinIdServ(rs.getString(10));
				chequeBounceDetails.setUserId(rs.getString(11));
				chequeDetails.add(chequeBounceDetails);

				System.out.println("paymentTransfer list is:"+chequeDetails+"and payment list is--->>>"+chequeBounceDetails);

			}
			rs.close();
			if (con != null && !con.isClosed()) {
				con.close();
			}
		}
		catch (SQLException e) {
			throw new RuntimeException(e);
		}
		chequeBounceDetails.setChequeDetails(chequeDetails);

		return chequeBounceDetails;
	}


	@Override
	public ChequeBounceDetails getSearchAesCheque(String chequeNo,String accountNo) throws Exception {
		String paymentQuery=null;
		Connection con = null;

		List<ChequeBounceDetails> chequeDetails=new ArrayList<>();
		try{
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			paymentQuery="select a.FILE_ID,a.BANK_ACCOUNT_NUMBER,a.CHEQUE_AMOUNT,a.CHEQUE_NO,a.CREATED_DATE,a.MODIFIED_DATE,a.RETURN_RECEIVED_DATE,a.STATUS_DESCRIPTION,a.TRACKING_ID,a.TRACKING_ID_SER,a.USER_ID from AESCHEQUE a where a.CHEQUE_NO='"+chequeNo+"' and a.BANK_ACCOUNT_NUMBER='"+accountNo+"'";
			con = jdbcTemplate.getDataSource().getConnection();
			PreparedStatement psTotalRecords = con.prepareStatement(paymentQuery);
			ResultSet rs = psTotalRecords.executeQuery();
			while(rs!=null && rs.next()){
				chequeBounceDetails=new ChequeBounceDetails();
				chequeBounceDetails.setFileId(rs.getInt(1));
				chequeBounceDetails.setBankAccountNumner(rs.getString(2));
				chequeBounceDetails.setChqAmount(rs.getLong(3));
				chequeBounceDetails.setChequeNo(rs.getString(4));
				String crDate=rs.getString(5);
				DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
				Date createDate = df1.parse(crDate);
				SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				String parsedCreateDate = formatter1.format(createDate);
				chequeBounceDetails.setCreatedDate(parsedCreateDate);

				String modifiedDate=rs.getString(6);
				DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
				Date modDtae = df.parse(modifiedDate);
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				String parsedModDate = formatter.format(modDtae);
				chequeBounceDetails.setModifiedDate(parsedModDate);

				String returnDate=rs.getString(7);
				DateFormat dform = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
				Date retDate = dform.parse(returnDate);
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				String parsedReturnDate = format.format(retDate);
				chequeBounceDetails.setRetuenReceivedDate(parsedReturnDate);
				chequeBounceDetails.setStatusDescription(rs.getString(8));
				chequeBounceDetails.setTrackingId(rs.getString(9));
				chequeBounceDetails.setTrackinIdServ(rs.getString(10));
				chequeBounceDetails.setUserId(rs.getString(11));
				chequeDetails.add(chequeBounceDetails);

				System.out.println("paymentTransfer list is:"+chequeDetails+"and payment list is--->>>"+chequeBounceDetails);

			}
			rs.close();
			if (con != null && !con.isClosed()) {
				con.close();
			}
		}
		catch (SQLException e) {
			throw new RuntimeException(e);
		}
		chequeBounceDetails.setChequeDetails(chequeDetails);

		return chequeBounceDetails;
	}


	@Override
	public ChequeBounceDetails getAesApproveWorkflow() throws Exception {

		System.out.println("in approve method");

		return chequeBounceDetails;

	}


	@Override
	public PaymentTransferDetails paymentTransferAmount(String amount,String account) throws Exception{
		String sampleString = amount;
		String message="";
		int a=100;
		System.out.println("amount values "+sampleString);
		String[] stringArray = sampleString.split(",");
		int[] intArray = new int[stringArray.length];
		for (int i = 0; i < stringArray.length; i++) {
			String numberAsString = stringArray[i];
			if(numberAsString.equalsIgnoreCase("")||numberAsString==null){
				System.out.println("got null or empty value");
			}
			else{
				intArray[i] = Integer.parseInt(numberAsString);
			}
		}
		System.out.println("Number of integers: " + intArray.length);
		System.out.println("The integers are:");


		List<Integer> intList = new ArrayList<Integer>();
		for (Integer i : intArray)
		{intList.add(i);
		}
		System.out.println("list in t values"+intList);
		int sum = BulkUtilValidations.sum(intList);
		System.out.println("after sum values are"+sum);
		if(a>sum){

			message="Actual amount is greater then sum of inputs of amount that you have provided";
			System.out.println("value after addition");

		}
		String paymentAccount = account; 
		String[] arrayAccount = paymentAccount.split(",");
		ArrayList<String> listAccount = new ArrayList<>(Arrays.asList(arrayAccount));
		System.out.println("account no is:"+listAccount);

		paymentDetails.setSum(sum);
		return paymentDetails;
	}

	public FileStatusDTO getFileStatusCI(int page){
		DecimalFormat dfa = new DecimalFormat("#");
		dfa.setMaximumFractionDigits(8);
		log.info("START : in getFileStatusAPS");
		List<FileStatusAPS> fileStatusApsList = new ArrayList<>();
		FileStatusDTO fileStatusDTO = new FileStatusDTO();
		NamedParameterStatement namedParameter = null;
		int totalRecords=0;
		int totalPages =0,recordsPerPage=10;
		String totRecordsQuery = "select count(*) from (select  f.*,RowNum r from FILE_STATUS_APS f where (f.status>=0 or f.status IN(-12,-13,-14,-15,-6)) AND f.file_identifier IN('MIC','REV','SLN','NRC','ADP','ADR','DRV')) ";
		Connection conn = null;
		FileStatusDTO workflowDTO = new FileStatusDTO();
		try{
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			log.info("connect" + "ion:" + dataSource.getConnection());
			conn = jdbcTemplate.getDataSource().getConnection();
			PreparedStatement psTotalRecords = conn.prepareStatement(totRecordsQuery);
			ResultSet rsTotalRecords = psTotalRecords.executeQuery();
			if(rsTotalRecords.next()){
				totalRecords = rsTotalRecords.getInt(1);
			}
			psTotalRecords.close();
			rsTotalRecords.close();
			if(totalRecords%recordsPerPage ==0){
				totalPages = totalRecords/recordsPerPage;
			}else{
				totalPages = (totalRecords/recordsPerPage)+1;
			}
			log.info("Total Pages are "+totalPages);

			fileStatusDTO.setTotalPages(totalPages);
			fileStatusDTO.setTotalResults(totalRecords);
			ResultSet rs= null;
			int count = 0;
			StringBuffer sb = new StringBuffer("select * from (select q.*,RowNum r  from (select  f.file_id,f.file_identifier,f.file_path,f.sum_of_amount,f.total_records,f.invalid_count,f.source,f.user_name,f.status,f.error_reason,f.process_date,f.pending_approval_level,f.is_worklist_compliant,s.status_meaning,UPPER(u.user_name) from FILE_STATUS_APS f LEFT OUTER JOIN STATUS_MASTER_TABLE_APS s on f.status = s.status_code LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_name) where (f.status>=0 or f.status IN(-12,-13,-14,-15,-6)) AND f.file_identifier IN('MIC','REV','SLN','NRC','ADP','ADR','DRV') order by f.file_id desc)q ) where r  between "+(((page-1)*recordsPerPage)+1) +" AND "+(page*recordsPerPage));
			log.info(sb);
			try {

				conn = new JdbcTemplate(dataSource).getDataSource().getConnection();
				conn.setAutoCommit(false);
			} catch (Exception e) {

			}
			try {

				if (conn != null) {

					namedParameter = new NamedParameterStatement(conn, sb.toString());
					rs = namedParameter.executeQuery();

					try {

						while (rs.next()) {
							FileStatusAPS fileStatusAps = new FileStatusAPS();
							int fileId = rs.getInt(1);
							fileStatusAps.setFileId(fileId);
							fileStatusAps.setFileIdentifier(rs.getString(2));
							String fileName = rs.getString(3);
							String fileNameFinal = fileName.substring(fileName.lastIndexOf("/")+1, fileName.length());
							String marketCode = fileNameFinal.substring(0, 3);
							String circle = getCircleFromMarketCode(marketCode);
							fileStatusAps.setCircle(circle);
							fileStatusAps.setFilePath(fileNameFinal);
							if("MIC".equalsIgnoreCase(rs.getString(2))||"REV".equalsIgnoreCase(rs.getString(2))){
								fileStatusAps.setSumOfAmount(String.valueOf(rs.getLong(4)));
							}
							else{
							fileStatusAps.setSumOfAmount(String.valueOf(dfa.format((Double.parseDouble(String.valueOf(rs.getLong(4))))/100)));
							}
							fileStatusAps.setTotalRecords(rs.getInt(5));
							fileStatusAps.setInvalidCount(rs.getInt(6));
							fileStatusAps.setSource(rs.getString(7));
							fileStatusAps.setOlmId(rs.getString(8));
							fileStatusAps.setStatus(rs.getInt(9));
							fileStatusAps.setStatusDescription(rs.getString(10));
							String date =rs.getString(11);
							DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
							Date startDate = df.parse(date);
							SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm");
							String parsedDate = formatter.format(startDate);
							fileStatusAps.setProcessDate(parsedDate);
							fileStatusAps.setPendingApprovalLevel(rs.getInt(12));
							fileStatusAps.setIsWorkListCompliant(rs.getString(13));
							fileStatusAps.setStatusMessage(rs.getString(14));
							fileStatusAps.setFirstLastName(rs.getString(15));
							fileStatusApsList.add(fileStatusAps);
							fileStatusDTO.setFileStatusList(fileStatusApsList);
							count++;
						}
						log.info("count of row from FileStatusAPS-->" + count);
					} catch (Exception e) {
						log.info(e);

					}

				}
			} catch (Exception e) {

			} finally {
				try{
					conn.commit();
					namedParameter.close();
					rs.close();
					conn.close();
				}catch(Exception e){
					log.error(e);
				}
			}
			log.info("END :in method readFileColMstApsData of FileUploadDaoImpl");

		}catch(Exception e){
			log.error(e);
		}
		fileStatusDTO.setResultPerPage(fileStatusApsList.size());
		return fileStatusDTO;
	}
	public FileStatusDTO getFileStatusCiForApprove(int page){
		DecimalFormat dfa = new DecimalFormat("#");
		dfa.setMaximumFractionDigits(8);
		log.info("START : in getFileStatusAPS");
		List<FileStatusAPS> fileStatusApsList = new ArrayList<>();
		FileStatusDTO fileStatusDTO = new FileStatusDTO();
		NamedParameterStatement namedParameter = null;
		int totalRecords=0;
		int totalPages =0,recordsPerPage=10;
		String totRecordsQuery = "select count(*) from (select  f.*,RowNum r from FILE_STATUS_APS f where (f.status>=1 and f.status<=4) AND f.source <> 'SFTP' AND f.file_identifier IN('MIC','REV','SLN','NRC','ADP','ADR','DEP','DRV')) ";
		log.info(totRecordsQuery);
		Connection conn = null;

		try{
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			log.info("connect" + "ion:" + dataSource.getConnection());
			conn = jdbcTemplate.getDataSource().getConnection();

			int reasoncode;String reason;
			HashMap<String,Integer> reasons = new HashMap<>();
			String rejectionReason="SELECT REASON_CODE,REASON FROM REJECTION_REASON_APS order by reason";
			PreparedStatement pst = conn.prepareStatement(rejectionReason);
			ResultSet resultSets4 = pst.executeQuery();
			while(resultSets4 != null && resultSets4.next()) {
				reasoncode =  resultSets4.getInt(1);
				reason = resultSets4.getString(2);
				reasons.put(reason,reasoncode);
			}
			fileStatusDTO.setReasons(reasons);
			pst.close();
			resultSets4.close();


			PreparedStatement psTotalRecords = conn.prepareStatement(totRecordsQuery);
			ResultSet rsTotalRecords = psTotalRecords.executeQuery();
			if(rsTotalRecords.next()){
				totalRecords = rsTotalRecords.getInt(1);
			}
			psTotalRecords.close();
			rsTotalRecords.close();
			if(totalRecords%recordsPerPage ==0){
				totalPages = totalRecords/recordsPerPage;
			}else{
				totalPages = (totalRecords/recordsPerPage)+1;
			}
			log.info("Total Pages are "+totalPages);

			fileStatusDTO.setTotalPages(totalPages);
			fileStatusDTO.setTotalResults(totalRecords);
			ResultSet rs= null;
			int count = 0;
			StringBuffer sb = new StringBuffer("select * from (select q.*,RowNum r from (select  f.file_id,f.file_identifier,f.file_path,f.sum_of_amount,f.total_records,f.invalid_count,f.source,f.user_name,f.status,f.error_reason,f.process_date,f.pending_approval_level,f.is_worklist_compliant,s.status_meaning,UPPER(u.user_name) from FILE_STATUS_APS f LEFT OUTER JOIN STATUS_MASTER_TABLE_APS s on f.status = s.status_code LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_name) where (f.status>=1 and f.status<=4) AND f.source <> 'SFTP' AND f.file_identifier IN('MIC','REV','SLN','NRC','ADP','ADR','DEP','DRV') order by f.file_id)q) where r  between "+(((page-1)*recordsPerPage)+1) +" AND "+(page*recordsPerPage));
			log.info(sb);
			try {

				conn = new JdbcTemplate(dataSource).getDataSource().getConnection();
				conn.setAutoCommit(false);
			} catch (Exception e) {

			}
			try {

				if (conn != null) {

					namedParameter = new NamedParameterStatement(conn, sb.toString());
					rs = namedParameter.executeQuery();

					try {

						while (rs.next()) {
							FileStatusAPS fileStatusAps = new FileStatusAPS();
							fileStatusAps.setFileId(rs.getInt(1));
							fileStatusAps.setFileIdentifier(rs.getString(2));
							String fileName = rs.getString(3);
							fileStatusAps.setFilePath(fileName.substring(fileName.lastIndexOf("/")+1, fileName.length()));
							String fileNameFinal = fileName.substring(fileName.lastIndexOf("/")+1, fileName.length());
							String marketCode = fileNameFinal.substring(0, 3);
							String circle = getCircleFromMarketCode(marketCode);
							fileStatusAps.setCircle(circle);
							fileStatusAps.setSumOfAmount(String.valueOf(dfa.format((Double.parseDouble(String.valueOf(rs.getLong(4))))/100)));
							fileStatusAps.setTotalRecords(rs.getInt(5));
							fileStatusAps.setInvalidCount(rs.getInt(6));
							fileStatusAps.setSource(rs.getString(7));
							fileStatusAps.setOlmId(rs.getString(8));
							fileStatusAps.setStatus(rs.getInt(9));
							fileStatusAps.setStatusDescription(rs.getString(10));
							String date =rs.getString(11);
							DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
							Date startDate = df.parse(date);
							SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm");
							String parsedDate = formatter.format(startDate);
							fileStatusAps.setProcessDate(parsedDate);
							fileStatusAps.setPendingApprovalLevel(rs.getInt(12));
							fileStatusAps.setIsWorkListCompliant(rs.getString(13));
							fileStatusAps.setStatusMessage(rs.getString(14));
							fileStatusAps.setFirstLastName(rs.getString(15));
							fileStatusApsList.add(fileStatusAps);

							count++;
						}
						log.info("count of row from FileStatusAPS-->" + count);
					} catch (Exception e) {
						log.info(e);

					}

				}
			} catch (Exception e) {

			} finally {
				try{
					conn.commit();
					namedParameter.close();
					rs.close();
					conn.close();
				}catch(Exception e){
					log.error(e);
				}
			}
			log.info("END :in method readFileColMstApsData of FileUploadDaoImpl");

		}catch(Exception e){
			log.error(e);
		}
		fileStatusDTO.setFileStatusList(fileStatusApsList);
		fileStatusDTO.setResultPerPage(fileStatusApsList.size());
		return fileStatusDTO;
	}


	public FileStatusDTO searchFileCi(String fileId, String fileName, String fromDate, String endDate, String status,int page,String viewName,String fileIdentifier,String olmId) throws Exception{
		Connection con = null;
		DecimalFormat dfa = new DecimalFormat("#");
		dfa.setMaximumFractionDigits(8);
		ResultSet rs=null;
		List<FileStatusAPS> fileStatusApsList = new ArrayList<>();
		int recordsPerPage =10;
		con = new JdbcTemplate(dataSource).getDataSource().getConnection();
		FileStatusDTO fileStatusDTO = new FileStatusDTO();
		int reasoncode;String reason;
		HashMap<String,Integer> reasons = new HashMap<>();
		String rejectionReason="SELECT REASON_CODE,REASON FROM REJECTION_REASON_APS order by reason";
		PreparedStatement pst = con.prepareStatement(rejectionReason);
		ResultSet resultSets4 = pst.executeQuery();
		while(resultSets4 != null && resultSets4.next()) {
			reasoncode =  resultSets4.getInt(1);
			reason = resultSets4.getString(2);
			reasons.put(reason,reasoncode);
		}
		fileStatusDTO.setReasons(reasons);
		pst.close();
		resultSets4.close();

		String dateCondition;
		if(endDate == null || endDate.equals("")){
			Date date = new Date();
			DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			endDate = formatter.format(date);
		}
		if(fromDate == null || fromDate.equals("")){
			dateCondition = " AND TRUNC(f.process_date)  <=  to_date('"+endDate+"','dd/MM/yyyy')";
		}
		else{
			dateCondition = " AND TRUNC(f.process_date)  BETWEEN to_date('"+fromDate+"','dd/MM/yyyy') AND to_date('"+endDate+"','dd/MM/yyyy')";
		}
		String countQuery,dataQuery;
		if(viewName.equalsIgnoreCase("viewFileCI")){
			countQuery ="select count(*) from (select  f.file_id,f.file_identifier,f.file_path,f.sum_of_amount,f.total_records,f.invalid_count,f.source,f.user_name,f.status,f.error_reason,f.process_date,f.pending_approval_level,f.is_worklist_compliant,s.status_meaning,UPPER(u.user_name),RowNum r from FILE_STATUS_APS f LEFT OUTER JOIN STATUS_MASTER_TABLE_APS s on f.status = s.status_code LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_name) where (f.status>=0 or f.status IN(-12,-13,-14,-15,-6)) AND f.file_identifier IN ('MIC','REV','SLN','NRC','ADP','ADR','DRV')  and UPPER(f.user_name) like '%"+olmId+"%' and f.file_id like '%"+fileId+"%' and UPPER(f.file_path) like '%"+fileName+"%' and UPPER(f.file_identifier) like '%"+fileIdentifier+"%' and s.status_meaning like '%"+status+"%' "+dateCondition+"  order by f.file_id desc )";
			dataQuery = "select * from (select q.*,RowNum r  from (select  f.file_id,f.file_identifier,f.file_path,f.sum_of_amount,f.total_records,f.invalid_count,f.source,f.user_name,f.status,f.error_reason,f.process_date,f.pending_approval_level,f.is_worklist_compliant,s.status_meaning,UPPER(u.user_name) from FILE_STATUS_APS f LEFT OUTER JOIN STATUS_MASTER_TABLE_APS s on f.status = s.status_code LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_name) where (f.status>=0 or f.status IN(-12,-13,-14,-15,-6)) AND f.file_identifier IN ('MIC','REV','SLN','NRC','ADP','ADR','DRV') and UPPER(f.user_name) like '%"+olmId+"%' and f.file_id like '%"+fileId+"%' and UPPER(f.file_path) like '%"+fileName+"%' and UPPER(f.file_identifier) like '%"+fileIdentifier+"%' and s.status_meaning like '%"+status+"%' "+dateCondition+"  order by f.file_id desc)q )where r  between "+(((page-1)*recordsPerPage)+1) +" AND "+(page*recordsPerPage);
		}else{
			countQuery ="select count(*) from (select   f.file_id,f.file_identifier,f.file_path,f.sum_of_amount,f.total_records,f.invalid_count,f.source,f.user_name,f.status,f.error_reason,f.process_date,f.pending_approval_level,f.is_worklist_compliant,s.status_meaning,UPPER(u.user_name),RowNum r from FILE_STATUS_APS f LEFT OUTER JOIN STATUS_MASTER_TABLE_APS s on f.status = s.status_code LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_name) where (f.status>=1 and f.status <=4) AND f.source <> 'SFTP' AND f.file_identifier IN ('MIC','REV','SLN','NRC','ADP','ADR','DRV') and UPPER(f.user_name) like '%"+olmId+"%' and f.file_id like '%"+fileId+"%' and UPPER(f.file_path) like '%"+fileName+"%' and UPPER(f.file_identifier) like '%"+fileIdentifier+"%' and s.status_meaning like '%"+status+"%' "+dateCondition+"  order by f.file_id desc )";
			dataQuery = "select * from (select q.*,RowNum r  from (select  f.file_id,f.file_identifier,f.file_path,f.sum_of_amount,f.total_records,f.invalid_count,f.source,f.user_name,f.status,f.error_reason,f.process_date,f.pending_approval_level,f.is_worklist_compliant,s.status_meaning,UPPER(u.user_name) from FILE_STATUS_APS f LEFT OUTER JOIN STATUS_MASTER_TABLE_APS s on f.status = s.status_code LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_name) where (f.status>=1 and f.status <=4) AND f.source <> 'SFTP' AND f.file_identifier IN('MIC','REV','SLN','NRC','ADP','ADR','DRV') and UPPER(f.user_name) like '%"+olmId+"%' and f.file_id like '%"+fileId+"%' and UPPER(f.file_path) like '%"+fileName+"%' and UPPER(f.file_identifier) like '%"+fileIdentifier+"%' and s.status_meaning like '%"+status+"%' "+dateCondition+"  order by f.file_id)q )where r  between "+(((page-1)*recordsPerPage)+1) +" AND "+(page*recordsPerPage);
		}
		PreparedStatement psTotalRecords = con.prepareStatement(countQuery);
		log.info(dataQuery);
		log.info(countQuery);
		ResultSet rsTotalRecords = psTotalRecords.executeQuery();
		int totalRecords = 0;
		if(rsTotalRecords.next()){
			totalRecords = rsTotalRecords.getInt(1);
		}
		psTotalRecords.close();
		rsTotalRecords.close();
		log.info("Total Records are "+totalRecords);
		int totalPages;
		if(totalRecords%recordsPerPage ==0){
			totalPages = totalRecords/recordsPerPage;
		}else{
			totalPages = (totalRecords/recordsPerPage)+1;
		}
		log.info("here is searchfile totalPages " + totalPages+" page is "+page);
		fileStatusDTO.setTotalPages(totalPages);
		fileStatusDTO.setTotalResults(totalRecords);

		PreparedStatement ps = con.prepareStatement(dataQuery);
		rs = ps.executeQuery();
		while(rs.next()){
			FileStatusAPS fileStatusAps = new FileStatusAPS();
			fileStatusAps.setFileId(rs.getInt(1));
			fileStatusAps.setFileIdentifier(rs.getString(2));
			String fileNameQuery = rs.getString(3);
			fileStatusAps.setFilePath(fileNameQuery.substring(fileNameQuery.lastIndexOf("/")+1, fileNameQuery.length()));
			String fileNameFinal = fileNameQuery.substring(fileNameQuery.lastIndexOf("/")+1, fileNameQuery.length());
			log.info("Final name is "+fileNameFinal);
			String marketCode="";
			try{
				marketCode = fileNameFinal.substring(0, 3);
			}catch(Exception e){

			}
			String circle = getCircleFromMarketCode(marketCode);
			fileStatusAps.setCircle(circle);

         if("REV".equalsIgnoreCase(rs.getString(2))||"MIC".equalsIgnoreCase(rs.getString(2))){
			fileStatusAps.setSumOfAmount((String.valueOf(rs.getLong(4))));
          }
       else{
    	   fileStatusAps.setSumOfAmount(String.valueOf(dfa.format((Double.parseDouble(String.valueOf(rs.getLong(4))))/100)));
         }
			fileStatusAps.setTotalRecords(rs.getInt(5));
			fileStatusAps.setInvalidCount(rs.getInt(6));
			fileStatusAps.setSource(rs.getString(7));
			fileStatusAps.setOlmId(rs.getString(8));
			fileStatusAps.setStatus(rs.getInt(9));
			fileStatusAps.setStatusDescription(rs.getString(10));
			String date =rs.getString(11);
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
			Date startDate = df.parse(date);
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm");
			String parsedDate = formatter.format(startDate);
			fileStatusAps.setProcessDate(parsedDate);
			fileStatusAps.setPendingApprovalLevel(rs.getInt(12));
			fileStatusAps.setIsWorkListCompliant(rs.getString(13));
			fileStatusAps.setStatusMessage(rs.getString(14));
			fileStatusAps.setFirstLastName(rs.getString(15));
			fileStatusApsList.add(fileStatusAps);
		}
		fileStatusDTO.setFileStatusList(fileStatusApsList);
		fileStatusDTO.setResultPerPage(fileStatusApsList.size());
		if(con != null){
			ps.close();
			rs.close();
			con.close();
		}
		return fileStatusDTO;

	}

	public FileStatusDTO getFileStatusCIForApprove(int page){
		DecimalFormat dfa = new DecimalFormat("#");
		dfa.setMaximumFractionDigits(8);
		log.info("START : in getFileStatusAPS");
		List<FileStatusAPS> fileStatusApsList = new ArrayList<>();
		FileStatusDTO fileStatusDTO = new FileStatusDTO();
		NamedParameterStatement namedParameter = null;
		int totalRecords=0;
		int totalPages =0,recordsPerPage=10;
		String totRecordsQuery = "select count(*) from (select  f.*,RowNum r from FILE_STATUS_APS f where (f.status>=1 and f.status<=4) AND f.source <> 'SFTP' AND f.file_identifier IN('ADJ','CNR','DNR','DPP','RDJ','RDP','REF','SNR')) ";
		log.info(totRecordsQuery);
		Connection conn = null;

		try{
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			log.info("connect" + "ion:" + dataSource.getConnection());
			conn = jdbcTemplate.getDataSource().getConnection();

			int reasoncode;String reason;
			HashMap<String,Integer> reasons = new HashMap<>();
			String rejectionReason="SELECT REASON_CODE,REASON FROM REJECTION_REASON_APS order by reason";
			PreparedStatement pst = conn.prepareStatement(rejectionReason);
			ResultSet resultSets4 = pst.executeQuery();
			while(resultSets4 != null && resultSets4.next()) {
				reasoncode =  resultSets4.getInt(1);
				reason = resultSets4.getString(2);
				reasons.put(reason,reasoncode);
			}
			fileStatusDTO.setReasons(reasons);
			pst.close();
			resultSets4.close();


			PreparedStatement psTotalRecords = conn.prepareStatement(totRecordsQuery);
			ResultSet rsTotalRecords = psTotalRecords.executeQuery();
			if(rsTotalRecords.next()){
				totalRecords = rsTotalRecords.getInt(1);
			}
			psTotalRecords.close();
			rsTotalRecords.close();
			if(totalRecords%recordsPerPage ==0){
				totalPages = totalRecords/recordsPerPage;
			}else{
				totalPages = (totalRecords/recordsPerPage)+1;
			}
			log.info("Total Pages are "+totalPages);

			fileStatusDTO.setTotalPages(totalPages);
			fileStatusDTO.setTotalResults(totalRecords);
			ResultSet rs= null;
			int count = 0;
			StringBuffer sb = new StringBuffer("select * from (select q.*,RowNum r from (select  f.file_id,f.file_identifier,f.file_path,f.sum_of_amount,f.total_records,f.invalid_count,f.source,f.user_name,f.status,f.error_reason,f.process_date,f.pending_approval_level,f.is_worklist_compliant,s.status_meaning,UPPER(u.user_name) from FILE_STATUS_APS f LEFT OUTER JOIN STATUS_MASTER_TABLE_APS s on f.status = s.status_code LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_name) where (f.status>=1 and f.status<=4) AND f.source <> 'SFTP' AND f.file_identifier IN('ADJ','CNR','DNR','DPP','RDJ','RDP','REF','SNR') order by f.file_id)q) where r  between "+(((page-1)*recordsPerPage)+1) +" AND "+(page*recordsPerPage));
			log.info(sb);
			try {

				conn = new JdbcTemplate(dataSource).getDataSource().getConnection();
				conn.setAutoCommit(false);
			} catch (Exception e) {

			}
			try {

				if (conn != null) {

					namedParameter = new NamedParameterStatement(conn, sb.toString());
					rs = namedParameter.executeQuery();

					try {

						while (rs.next()) {
							FileStatusAPS fileStatusAps = new FileStatusAPS();
							fileStatusAps.setFileId(rs.getInt(1));
							fileStatusAps.setFileIdentifier(rs.getString(2));
							String fileName = rs.getString(3);
							fileStatusAps.setFilePath(fileName.substring(fileName.lastIndexOf("/")+1, fileName.length()));
							String fileNameFinal = fileName.substring(fileName.lastIndexOf("/")+1, fileName.length());
							String marketCode = fileNameFinal.substring(0, 3);
							String circle = getCircleFromMarketCode(marketCode);
							fileStatusAps.setCircle(circle);
							fileStatusAps.setSumOfAmount(String.valueOf(dfa.format((Double.parseDouble(String.valueOf(rs.getLong(4))))/100)));
							fileStatusAps.setTotalRecords(rs.getInt(5));
							fileStatusAps.setInvalidCount(rs.getInt(6));
							fileStatusAps.setSource(rs.getString(7));
							fileStatusAps.setOlmId(rs.getString(8));
							fileStatusAps.setStatus(rs.getInt(9));
							fileStatusAps.setStatusDescription(rs.getString(10));
							String date =rs.getString(11);
							DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
							Date startDate = df.parse(date);
							SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm");
							String parsedDate = formatter.format(startDate);
							fileStatusAps.setProcessDate(parsedDate);
							fileStatusAps.setPendingApprovalLevel(rs.getInt(12));
							fileStatusAps.setIsWorkListCompliant(rs.getString(13));
							fileStatusAps.setStatusMessage(rs.getString(14));
							fileStatusAps.setFirstLastName(rs.getString(15));
							fileStatusApsList.add(fileStatusAps);

							count++;
						}
						log.info("count of row from FileStatusAPS-->" + count);
					} catch (Exception e) {
						log.info(e);

					}

				}
			} catch (Exception e) {

			} finally {
				try{
					conn.commit();
					namedParameter.close();
					rs.close();
					conn.close();
				}catch(Exception e){
					log.error(e);
				}
			}
			log.info("END :in method readFileColMstApsData of FileUploadDaoImpl");

		}catch(Exception e){
			log.error(e);
		}
		fileStatusDTO.setFileStatusList(fileStatusApsList);
		fileStatusDTO.setResultPerPage(fileStatusApsList.size());
		return fileStatusDTO;
	}
	
	public String validateAESadvUTRStatus(Set<String> utrSet, String file_id,String paymentMode) {

		final String procedureCall = "{call AIRTL_AES_PAYMENT_DETAILS_PKG.validateUTRStatus(?,?,?,?)}";
		Connection connection = null;
		CallableStatement callableStatement = null;
		String error_msg = null;
		try {
			connection = new JdbcTemplate(dataSource).getDataSource().getConnection();
			connection.setAutoCommit(false);
			ArrayDescriptor des = ArrayDescriptor.createDescriptor("ARRAY_CHECK_TYPE", connection);
			Object[] array = utrSet.toArray();
			ARRAY array_to_pass = new ARRAY(des, connection, array);
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setString(1, file_id);
			callableStatement.setArray(2, array_to_pass);
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.executeUpdate();

			error_msg = callableStatement.getString(3)+","+callableStatement.getString(4);
		} catch (SQLException e) {
			log.info(e);

		} finally {

			if (connection != null)
				try {
					connection.commit();
					callableStatement.close();
					connection.close();
				} catch (SQLException e) {
					log.info(e);
				}
		}
		// log.info(error_msg);
		log.info("END :in method headerProcValidation of FileUploadDaoImpl error_msg for AES Cheque Advice" + error_msg);
		return error_msg;
	}
	
	public String validatetTanStatus(Set<String> utrSet, String file_id,String paymentMode) {

		final String procedureCall = "{call validateTANStatus(?,?,?,?)}";
		Connection connection = null;
		CallableStatement callableStatement = null;
		String error_msg = null;
		try {
			connection = new JdbcTemplate(dataSource).getDataSource().getConnection();
			connection.setAutoCommit(false);
			ArrayDescriptor des = ArrayDescriptor.createDescriptor("ARRAY_CHECK_TYPE", connection);
			Object[] array = utrSet.toArray();
			ARRAY array_to_pass = new ARRAY(des, connection, array);
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setString(1, file_id);
			callableStatement.setArray(2, array_to_pass);
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.executeUpdate();

			error_msg = callableStatement.getString(3)+","+callableStatement.getString(4);
		} catch (SQLException e) {
			log.info(e);

		} finally {

			if (connection != null)
				try {
					connection.commit();
					callableStatement.close();
					connection.close();
				} catch (SQLException e) {
					log.info(e);
				}
		}
		// log.info(error_msg);
		log.info("END :in method  of FileUploadDaoImpl error_msg for TDS" + error_msg);
		return error_msg;
	}

	@Override
	public String updateSALStatusIntoAdviceStatus(String fileId) {
		final String procedureCall = "{call SUSPENSE_ADVICE_STATUS_UPDATE(?,?,?)}";
		Connection connection = null;
		CallableStatement callableStatement = null;
		String error_msg = null;
		try {
			connection = new JdbcTemplate(dataSource).getDataSource().getConnection();
			connection.setAutoCommit(false);
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setString(1, fileId);
			callableStatement.registerOutParameter(2, Types.VARCHAR);
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.executeUpdate();

			error_msg = callableStatement.getString(2)+","+callableStatement.getString(3);
		} catch (SQLException e) {
			log.info(e);

		} finally {

			if (connection != null)
				try {
					connection.commit();
					callableStatement.close();
					connection.close();
				} catch (SQLException e) {
					log.info(e);
				}
		}
		// log.info(error_msg);
		log.info("END :in method updateSALStatusIntoAdviceStatus of FileUploadDaoImpl error_msg for Suspense allocation status update Advice" + error_msg);
		return error_msg;
	}
	
		public void insertIntoPaymentAdviceStatusError(int file_Id, String fileIdentifier, String fileName, Double sum,
			int tot_rows, String paymentMode, String user, int status, String errorReason, int invalidCount, Date date,
			String processType, List<String> list) {

		log.info("START : method insertIntoFileStatus of FileUploadDaoImpl fileIdentifier-->>" + fileIdentifier);
		// log.info("REACHING FILE STATUS");

		Connection con = null;
		date = new java.util.Date();
		PreparedStatement preparedStatement = null;
		StringBuffer sb = null;

		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("file_id is : " + file_Id);
			log.info("connection made...");

			if("NEFT BANK STATEMENT".equalsIgnoreCase(paymentMode)){
				paymentMode="NEFT";
			}

			// for unix replace file_path by file_Name

			sb = new StringBuffer(
					"Insert into ADVICE_REQUEST_STATUS_APS(I_REQUEST_ID,FILE_IDENTIFIER,USER_ID,ORIGINAL_FILE_NAME,TOTAL_RECORDS,STATUS_CODE,TOTAL_AMOUNT,VALID_COUNT,PROCESS_TYPE,UPLOADED_DATE,PAYMENT_MODE,AMOUNT_IN_INR,ERROR_REASON,STATUS_DESCRIPTION) values(?,?,?,?,?,?,?,?,?,SYSDATE,?,?,?,?)");

			preparedStatement = con.prepareStatement(sb.toString());
			preparedStatement.setInt(1, file_Id);
			preparedStatement.setString(2, fileIdentifier);
			preparedStatement.setString(3, user);
			preparedStatement.setString(4, fileName);
			preparedStatement.setInt(5, tot_rows);
			preparedStatement.setInt(6, status);
			preparedStatement.setDouble(7, sum);
			preparedStatement.setInt(8, tot_rows);
			preparedStatement.setString(9, processType);
			//preparedStatement.setTimestamp(10,
				//	java.sql.Timestamp.valueOf(new SimpleDateFormat("yyyy-MM-dd hh24:mm:ss").format(date.getTime())));
			preparedStatement.setString(10, paymentMode);
			preparedStatement.setDouble(11, sum);
			preparedStatement.setString(12, errorReason);
			preparedStatement.setString(13, errorReason);
			preparedStatement.executeQuery();

		} catch (Exception e) {
			e.printStackTrace();
			log.info(e);

		} finally {

			try {
				con.commit();
				preparedStatement.close();
				con.close();
			} catch (Exception e) {
				e.printStackTrace();
				log.info(e);
			}

		}
		log.info("END : method insertIntoFileStatus of FileUploadDaoImpl");
	}

		
		public void updateTDSAdviceFailure(String fileId,String fileIdentifier,String errorReason)throws Exception{

			String status="";
			Connection conn = null;
			String updateAdviceVendor="";
			int count=0;
			String updateAdviceRequest="";
			ResultSet rs=null;
			String query = "select count(*) from ADVICE_REQUEST_STATUS_APS where i_request_id = '"+fileId+"'";
			try{
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				log.info("connect" + "ion:" + dataSource.getConnection());
				conn = jdbcTemplate.getDataSource().getConnection();
				log.info("Checking file inserted in ADVICE_REQUEST_STATUS_APS");
				PreparedStatement ps = conn.prepareStatement(query);
				rs = ps.executeQuery();
				while(rs.next()){
					count=rs.getInt(1);
				}
				log.info("count: "+count);
				if(count>0) {
				log.info("Updating ADVICE_REQUEST_STATUS_APS for  error");
					updateAdviceRequest="UPDATE ADVICE_REQUEST_STATUS_APS SET status_code = -3, error_reason = '"+errorReason+"' WHERE i_request_id = '"+fileId+"' and FILE_IDENTIFIER='"+fileIdentifier+"'";
					PreparedStatement ps1 = conn.prepareStatement(updateAdviceRequest);
					ps1.executeUpdate();
					
					status="Success";
					conn.commit();
					log.info("Updated ADVICE_REQUEST_STATUS_APS for  error");

					if (conn != null && !conn.isClosed()) {
					conn.close();
					}
				}
			}
			catch (SQLException e) {
				throw new RuntimeException(e);
			
			}
			
		}
		
		
		public String updateAdviceFailure(String fileId,String fileIdentifier)throws Exception{

			String status="";
			Connection conn = null;
			String updateAdviceVendor="";
			String updateAdviceRequest="";

			try{
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				log.info("connect" + "ion:" + dataSource.getConnection());
				conn = jdbcTemplate.getDataSource().getConnection();

				if("PAFILE".equalsIgnoreCase(fileIdentifier) || "PAB".equalsIgnoreCase(fileIdentifier))
				{
					updateAdviceVendor="UPDATE ADVICE_VENDOR_FILES_RECORDS SET status_code = -9, error_reason_code = 'Data Failure issue' WHERE i_request_id = '"+fileId+"' and FILE_IDENTIFIER='"+fileIdentifier+"'";
				}
				
				if("AESADV".equalsIgnoreCase(fileIdentifier))
				{
					updateAdviceVendor="UPDATE AES_ADVICE_DP_FILES_RECORDS SET status_code = -9, STATUS_DESCRIPTION = 'Data Failure issue' WHERE TICKET_ID = '"+fileId+"' and FILE_IDENTIFIER='"+fileIdentifier+"'";
				}
				
				log.info("Query for UTR Mismatch==>"+updateAdviceVendor);
					PreparedStatement ps = conn.prepareStatement(updateAdviceVendor);
					ps.executeUpdate();
					
					updateAdviceRequest="UPDATE ADVICE_REQUEST_STATUS_APS SET status_code = -11, error_reason = 'Data Failure Issue' WHERE i_request_id = '"+fileId+"' and FILE_IDENTIFIER='"+fileIdentifier+"'";
					PreparedStatement ps1 = conn.prepareStatement(updateAdviceRequest);
					ps1.executeUpdate();
					
					status="Success";
					conn.commit();


				if (conn != null && !conn.isClosed()) {
					conn.close();
					
				}
			}
			catch (SQLException e) {
				throw new RuntimeException(e);
			
			}
			return status;
		}
		
		public String getProcessType(String fileIdentifier,String pType) {
			
			log.info("START ::Hello inside getProcessType method ");

			Connection conn = null;
			String processType="";
			PreparedStatement ps=null;
			ResultSet rs=null;
			try{
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				conn = jdbcTemplate.getDataSource().getConnection();
			}
			catch(Exception e)
			{
				log.info("getProcessType list DB exception "+e);	
			}
			
			try{
				if(conn!=null)
				{
					String qurey="select a.PROCESS_TYPE from ADJ_UPLOAD_TYPE_MASTER a where upper(a.FILE_IDENTIFIER)=? and upper(a.TYPE)=?";
					ps = conn.prepareStatement(qurey);
					ps.setString(1, fileIdentifier);
					ps.setString(2, pType);
					
					rs=ps.executeQuery();
					while(rs.next())
					{
						processType=rs.getString("PROCESS_TYPE");
					}
					
				}
			}
			catch(Exception e)
			{
			log.info("Adj type list DB exception "+e);	
			}
			finally
			{
				try{
					rs.close();
					ps.close();
					conn.close();
				}
				catch(Exception e)
				{
				log.info("Adj type list DB exception "+e);	
				}
			}
					
			
			return  processType;
		}

		
		public void updateWaiverDetails(String supportFile,String fileId,String processType) {

			log.info("Updating updateWaiverDetails for support file Details");
			PreparedStatement ps =null;
			ResultSet fileNameResultSet=null;
			Connection conn=null;

			try 
			{
				log.info("updateWaiverDetails-> supportFile->"+supportFile+" fileId->"+fileId);

				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				conn = jdbcTemplate.getDataSource().getConnection();

				final String procedureCall = "update ADVICE_REQUEST_STATUS_APS set SUPPORT_FILE_NAME=?, PROCESS_TYPE=? where I_REQUEST_ID=?";//"update payment_status_aps set support_file=? where file_id=?";

				ps = conn.prepareCall(procedureCall);
				ps.setString(1, supportFile);
				ps.setString(2, processType);
				ps.setString(3, fileId);
				ps.executeUpdate();


			}catch (Exception e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				log.error(errors);
			}
			finally{
				if(fileNameResultSet!=null){
					try {
						fileNameResultSet.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						log.error(errors);
					}
				}


				if(conn!=null){
					try {
						conn.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						log.error(errors);
					}

				}
			}
			log.info("END updateWaiverDetails");
		}
		
		public static void main(String[] args) {
			FileUploadDaoImpl d=new FileUploadDaoImpl();
			List<String> list = new ArrayList<String>();
			String fileType = "";
			String fileName = "";
			list.add("WAIVERTXNO");
			list.add("WAIVERTICKETNO");
			list.add("LOB");
			list.add("CIRCLE");
			list.add("ACCOUNTEXTERNALID");
			list.add("AMOUNT");
			list.add("TAXAMOUNT");
			list.add("BILLREFNO");
			list.add("ANNTFROMDATE");
			list.add("ANNTTODATE");
			list.add("CHARGEIDENTIFIER");
			list.add("ADJTRANSCODE");
			list.add("LSINO");
			list.add("STANDARDREASONCODE");
			list.add("ADJREASONDET");
			list.add("PROCESSIDENTIFIER");
			list.add("ANNOTATION");
			list.add("FINALAPPROVER");
			list.add("SOURCE");
			list.add("TYPE");
			list.add("REFNO");
			list.add("SLNO");
			list.add("REMARKS1");
			list.add("REMARKS2");
			list.add("VIPFLAG");
			list.add("CUSTOMERCLASSIFICATION");
			list.add("CUSTOMERTYPE");
			list.add("VALUETYPE");
			list.add("FINALSEGMENT");
			list.add("WAIVERINVOICEPERCENTAGE");
			list.add("AGEONNETWORK");
			list.add("BILLREFRESETS");
			list.add("INVOICEDATE");
			list.add("TOTALINVOICEAMT");
			list.add("INVOICEOUTSTANDINGAMT");
			list.add("CUSTOMERNAME");
			list.add("UPLOADEDUSERID");
			list.add("TICKETUPLOADTIME");
			list.add("TYPEOFPERIOD");
			list.add("UPLOADEDUSERNAME");
			list.add("TYPEOFWAIVER");
			list.add("WACADJREASONCODE");
			list.add("WACREASONDET");
			list.add("WACSTATUS");
			list.add("WACREJREASON");
			list.add("WACREACHTIME");
			list.add("WACRECOMMENDEDAMOUNT");
			list.add("WACREMARKS");
			list.add("CADREACHTIME");
			list.add("CADSTATUS");
			list.add("CADREJECTIONREASON");
			list.add("CADREMARKS");
			String header=d.headerProcValidation1(list, "CIS", "");

		}
		
		
		
}
