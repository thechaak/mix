package com.airtel.acecad.bulkupload.dto;

import java.sql.Timestamp;

public class AdjReversalDetails {

	int transactionNo;
	int srTransactionNo;
	int fileId;
	String fileIdentifier;
	String srNumber;
	String srCategory;
	int billRefResets;
	
	String accountExternalId;
	int origTrackingId;
	int origTrackinIdServ;
	String adjustmentReasonCode;
	
	String source;
	String apsFalg;
	
	String geocode;
	String origBillRefNo;
	
	String origTransCode;
	
	Timestamp createdDate;
	Timestamp modifiedDate;
	int origBillRefResets;
	public int getBillRefResets() {
		return billRefResets;
	}
	public void setBillRefResets(int billRefResets) {
		this.billRefResets = billRefResets;
	}
	public int getOrigBillRefResets() {
		return origBillRefResets;
	}
	public void setOrigBillRefResets(int origBillRefResets) {
		this.origBillRefResets = origBillRefResets;
	}
	int trackingId;
	int trackinIdServ;
	int statusCode;
	String statusDescription;
	int noOfHit;
	String userId;
	public int getTransactionNo() {
		return transactionNo;
	}
	public void setTransactionNo(int transactionNo) {
		this.transactionNo = transactionNo;
	}
	public int getSrTransactionNo() {
		return srTransactionNo;
	}
	public void setSrTransactionNo(int srTransactionNo) {
		this.srTransactionNo = srTransactionNo;
	}
	public int getFileId() {
		return fileId;
	}
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}
	public String getFileIdentifier() {
		return fileIdentifier;
	}
	public void setFileIdentifier(String fileIdentifier) {
		this.fileIdentifier = fileIdentifier;
	}
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getSrCategory() {
		return srCategory;
	}
	public void setSrCategory(String srCategory) {
		this.srCategory = srCategory;
	}
	
	
	
	public String getAccountExternalId() {
		return accountExternalId;
	}
	public void setAccountExternalId(String accountExternalId) {
		this.accountExternalId = accountExternalId;
	}
	public int getOrigTrackingId() {
		return origTrackingId;
	}
	public void setOrigTrackingId(int origTrackingId) {
		this.origTrackingId = origTrackingId;
	}
	public int getOrigTrackinIdServ() {
		return origTrackinIdServ;
	}
	public void setOrigTrackinIdServ(int origTrackinIdServ) {
		this.origTrackinIdServ = origTrackinIdServ;
	}
	public String getAdjustmentReasonCode() {
		return adjustmentReasonCode;
	}
	public void setAdjustmentReasonCode(String adjustmentReasonCode) {
		this.adjustmentReasonCode = adjustmentReasonCode;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getApsFalg() {
		return apsFalg;
	}
	public void setApsFalg(String apsFalg) {
		this.apsFalg = apsFalg;
	}
	public String getGeocode() {
		return geocode;
	}
	public void setGeocode(String geocode) {
		this.geocode = geocode;
	}
	public String getOrigBillRefNo() {
		return origBillRefNo;
	}
	public void setOrigBillRefNo(String origBillRefNo) {
		this.origBillRefNo = origBillRefNo;
	}
	public String getOrigTransCode() {
		return origTransCode;
	}
	public void setOrigTransCode(String origTransCode) {
		this.origTransCode = origTransCode;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public int getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(int trackingId) {
		this.trackingId = trackingId;
	}
	public int getTrackinIdServ() {
		return trackinIdServ;
	}
	public void setTrackinIdServ(int trackinIdServ) {
		this.trackinIdServ = trackinIdServ;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	public int getNoOfHit() {
		return noOfHit;
	}
	public void setNoOfHit(int noOfHit) {
		this.noOfHit = noOfHit;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
}
