package com.airtel.acecad.bulkupload.dto;

import java.util.Date;

public class CBTrans {
	String transactionType;
	String beneficiaryCode;
	Number instrumentAmount;
	String paymentDetails1;
	String paymentDetails2;
	String beneficiaryAccount;
	String ifscCode;
	String utrChequeNumber;
	Date chequeDateTxnDate;
	String paymentStatus;
	String rejectionReason;
	String comments;
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getBeneficiaryCode() {
		return beneficiaryCode;
	}
	public void setBeneficiaryCode(String beneficiaryCode) {
		this.beneficiaryCode = beneficiaryCode;
	}
	public Number getInstrumentAmount() {
		return instrumentAmount;
	}
	public void setInstrumentAmount(Number instrumentAmount) {
		this.instrumentAmount = instrumentAmount;
	}
	public String getPaymentDetails1() {
		return paymentDetails1;
	}
	public void setPaymentDetails1(String paymentDetails1) {
		this.paymentDetails1 = paymentDetails1;
	}
	public String getPaymentDetails2() {
		return paymentDetails2;
	}
	public void setPaymentDetails2(String paymentDetails2) {
		this.paymentDetails2 = paymentDetails2;
	}
	public String getBeneficiaryAccount() {
		return beneficiaryAccount;
	}
	public void setBeneficiaryAccount(String beneficiaryAccount) {
		this.beneficiaryAccount = beneficiaryAccount;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getUtrChequeNumber() {
		return utrChequeNumber;
	}
	public void setUtrChequeNumber(String utrChequeNumber) {
		this.utrChequeNumber = utrChequeNumber;
	}
	public Date getChequeDateTxnDate() {
		return chequeDateTxnDate;
	}
	public void setChequeDateTxnDate(Date chequeDateTxnDate) {
		this.chequeDateTxnDate = chequeDateTxnDate;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public String getRejectionReason() {
		return rejectionReason;
	}
	public void setRejectionReason(String rejectionReason) {
		this.rejectionReason = rejectionReason;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}

}
