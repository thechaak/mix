package com.airtel.acecad.bulkupload.uploadfile;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
/*
 * author : Shaleen Agarwal
 * 
 * */
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.support.MultipartFilter;

import com.airtel.acecad.bulkupload.dao.FileUploadDao;
import com.airtel.acecad.bulkupload.dto.FileColMstAps;
import com.airtel.acecad.bulkupload.dto.FileIdentifierMstAps;
import com.airtel.acecad.bulkupload.dto.FileUploadResult;
import com.airtel.acecad.bulkupload.dto.ResponseOfInsert;
import com.airtel.acecad.bulkupload.util.BulkUtilValidations;
import com.airtel.acecad.bulkupload.util.CommonValidator;
import com.airtel.acecad.bulkupload.util.GlobalConstants;

import au.com.bytecode.opencsv.CSVReader;

public class ExcelReader implements GlobalConstants {

	@Autowired
	FileUploadDao fileUploadDao;
//	private static Logger log = LogManager.getLogger(ExcelReader.class);
	private static Logger log = LogManager.getLogger("apsbulkUploadLog");

	static Properties props = null;
	static {
		try {
			props = new Properties();
			InputStream inStream = ExcelReader.class.getResourceAsStream("/errorMessages.properties");

			(props).load(inStream);
		} catch (IOException e) {
		}
	}

	public Object readExcelFileData(String classAttribute, String data, Object clsInstance) {
		log.info("START : In method readExcelFileData of ExcelReader");

		log.info("END : in method readExcelFileData of ExcelReader");
		return clsInstance;
	}

	public static boolean isValidMobileNumber(String mob, long minValue, long maxValue) {
		log.info("START : method isValidMobileNumber of ExcelReader");
		Double d = Double.parseDouble(mob);
		DecimalFormat df = new DecimalFormat("#");
		long number = Long.parseLong(df.format(d));
		String value = Long.toString(number);

		if (!CommonValidator.isNull(value) && number >= minValue && number <= maxValue) {
			log.info("END : method isValidMobileNumber of ExcelReader");
			return true;
		} else {
			log.info("END : method isValidMobileNumber of ExcelReader");
			return false;
		}
	}

	public static String csv2XlsFileConversion(String csvFileName) throws IOException {

		log.info("START : In method csv2XlsFileConversion of ExcelReader");

		String xlsFileName = null;
		String p = "://";
		csvFileName = csvFileName.replace("\\", "/");
		String path = (csvFileName.split("//"))[0] + (csvFileName.split("//"))[1];
		path = path.replace(":", p);
		String csvFile = (csvFileName.split("//"))[2].split("\\.")[0];
		log.info("Before csv2XlsFileConversion CSV file name is " + csvFile);
		xlsFileName = path + "//" + csvFile + ".xls";

		Workbook wb = new HSSFWorkbook();
		CreationHelper helper = wb.getCreationHelper();
		Sheet sheet = wb.createSheet("new sheet");

		CSVReader reader = new CSVReader(new FileReader(csvFileName));
		String[] line;
		int r = 0;
		while ((line = reader.readNext()) != null) {
			Row row = sheet.createRow((short) r++);

			for (int i = 0; i < line.length; i++)
				row.createCell(i).setCellValue(helper.createRichTextString(line[i]));
		}

		// Write the output to a file
		FileOutputStream fileOut = new FileOutputStream(xlsFileName);
		wb.write(fileOut);
		fileOut.close();
		reader.close();

		log.info("END : In method csv2XlsFileConversion of ExcelReader");
		return xlsFileName;
	}

	public FileUploadResult readFromExcelfile(String fileName, String fileIde, String source, String user, String batch,
			InputStream inputStream, String validateFile, HashMap<String, String> bankAccountNumberAndRefNumberMap,
			Object[] obj) throws Exception {

		String rejectionReason = "";
		String file_Id = null;
		List<String> list = new ArrayList<String>();
		list.add("CHQ");
		list.add("EFT");
		list.add("MIS");
		list.add("REVCHQ");
		list.add("DIR");
		// 1-Apr-2019
		// list.add("PTF");
		list.add("NONBANK");
		// list.add("SAL");
		// list.add("PNH");
		// list.add("RHO");

		String insStatus = "";

		log.info("File Name in readFromExcelfile " + fileName);
		log.info("START : In method readFromExcelfile of ExcelReader");
		FileUploadResult fileUpload = new FileUploadResult();
		String errorReason = EMPTY_STRING;
		int status_code = INITIAL_STATUS_CODE;
		boolean status = true;
		Set<String> utrSet = new HashSet<String>();
		String supportFile = null;
		String pType = "";
		if ("WMF".equalsIgnoreCase(fileIde.toUpperCase()) || "WAI".equalsIgnoreCase(fileIde.toUpperCase())
				|| "BWM".equalsIgnoreCase(fileIde.toUpperCase()) || "BWI".equalsIgnoreCase(fileIde.toUpperCase())) {
			String filename[] = fileName.split("\\|");
			if (filename.length == 3) {
				fileName = filename[0];
				pType = filename[1];
				supportFile = filename[2];
			} else {
				fileName = filename[0];
				pType = filename[1];
			}
		}

		// for payment file validations
		if (list.contains(fileIde.toUpperCase()) || "RNH".equalsIgnoreCase(fileIde.toUpperCase())
				|| "PNH".equalsIgnoreCase(fileIde.toUpperCase())) {

			file_Id = fileUploadDao.getPaymentFileId();
			if ("RNH".equalsIgnoreCase(fileIde.toUpperCase()) || "PNH".equalsIgnoreCase(fileIde.toUpperCase())) {
				fileName = fileName.replace("\\", "/");
			}
			// validating file name to be added final added on 30JAN 18
			// status=validatingFileName(fileName,fileIde);
			if (status == false) {

				errorReason = props.getProperty("invalidFileName");
				log.info("Status in method readFromExcelfile--->>" + errorReason);
				log.info("Status in method readFromExcelfile--->>" + errorReason);
				status_code = INVALID_FILENAME;
				status = false;
			}
		} else if ("PAFILE".equalsIgnoreCase(fileIde.toUpperCase()) || "SAL".equalsIgnoreCase(fileIde.toUpperCase())
				|| "AESDP".equalsIgnoreCase(fileIde.toUpperCase()) || "PAB".equalsIgnoreCase(fileIde.toUpperCase())
				|| "AESADV".equalsIgnoreCase(fileIde.toUpperCase())
				|| "AESDUMMY".equalsIgnoreCase(fileIde.toUpperCase()) || "PTF".equalsIgnoreCase(fileIde.toUpperCase())
				|| "TDS".equalsIgnoreCase(fileIde.toUpperCase()) || "REF_CISTM".equalsIgnoreCase(fileIde.toUpperCase())
				|| "REF_DISTM".equalsIgnoreCase(fileIde.toUpperCase())
				|| "REF_DTH".equalsIgnoreCase(fileIde.toUpperCase()) || "REF_TM".equalsIgnoreCase(fileIde.toUpperCase())
				|| "REF_TMP".equalsIgnoreCase(fileIde.toUpperCase()) || "WMF".equalsIgnoreCase(fileIde.toUpperCase())
				|| "WAI".equalsIgnoreCase(fileIde.toUpperCase()) || "BWM".equalsIgnoreCase(fileIde.toUpperCase())
				|| "BWI".equalsIgnoreCase(fileIde.toUpperCase())) {
			file_Id = fileUploadDao.getPaymentAdviceFileId(fileIde);
			log.info("Payment Advice Request id->" + file_Id);
		} else {// for bulk upload file validations

			fileName = fileName.replace("\\", "/");
			file_Id = fileUploadDao.getFileId();
		}
		fileUpload.setFileId(file_Id);
		log.info("In readFromExcelfile File Id is " + file_Id);
		/* Validations */
		String isFileValid = BulkUtilValidations.validateUploadedFile(fileName);
		if (isFileValid.equalsIgnoreCase("xls")) {
			log.info(props.getProperty("validxls"));
		} else if (isFileValid.equalsIgnoreCase("xlsx")) {
			log.info(props.getProperty("validxlsx"));
		} else {
			errorReason = props.getProperty("invalidExtension");
			log.info("Status in method readFromExcelfile--->>" + errorReason);
			log.info("Status in method readFromExcelfile--->>" + errorReason);
			status_code = INVALID_FILE_EXTENSION;
			status = false;
		}

		if (validateFile.equalsIgnoreCase("Bulk")) {
			if (status == true) {
				log.info(fileName);
				String file = fileName.substring(fileName.lastIndexOf("/") + 1);
				log.info("For checking length " + file);

				file = file.substring(file.lastIndexOf("/") + 1, file.lastIndexOf("."));
				log.info("File name is " + file);
				if (file.length() > 16) {
					status = false;
					errorReason = props.getProperty("invalidFileNameLength");
					status_code = INVALID_LENGTH_FILE_NAME;
				}
			}

			if (status == true) {
				boolean st1 = fileUploadDao.checkCircle(fileName, fileIde);
				if (st1 == false) {
					errorReason = props.getProperty("circleInvalid");
					log.info("Status in method readFromExcelfile--->>" + errorReason);
					log.info("Status in method readFromExcelfile--->>" + errorReason);
					status_code = INVALID_CIRCLE;
					status = false;
				}
			}
		}
		int fileExtension = 0;
		List<FileColMstAps> fileColMstList = new ArrayList<FileColMstAps>();
		FileIdentifierMstAps fileId = new FileIdentifierMstAps();
		Double sum = 0.0;
		// Setting file identifier in fileId as getting null pointer exception in case
		// of status=false as file_identifier not getting set in fileId
		fileId.setFileIdentifier(fileIde);
		log.info("FileIdentifier==>" + fileId.getFileIdentifier());

		if (status == true) {

			fileId = fileUploadDao.readFileIdentifierFromMst(fileIde);
			if (fileId != null) {

				fileExtension++;
			} else {
				fileId = new FileIdentifierMstAps();
				fileId.setFileIdentifier(fileIde);
			}

			if (fileExtension == 0) {
				errorReason = props.getProperty("invalidIdentifier");
				log.info("Status in method readFromExcelfile--->>" + errorReason);
				log.info("Status  in method readFromExcelfile--->>" + errorReason);
				status_code = INVALID_FILE_IDENTIFIER;
				status = false;
			}
		}
		if (validateFile.equalsIgnoreCase("Bulk")) {
			if (status == true) {
				log.info(fileName);

				String file = fileName.substring(fileName.lastIndexOf("/") + 1);
				log.info("For checking date " + file);
				String date = file.substring(6, 12);
				log.info(date);
				boolean st = CommonValidator.dateCheck(date, "", "0", "yyMMdd", "ABC");
				log.info("status for date check is " + st);
				if (st == true) {
					status = true;
				} else {
					errorReason = props.getProperty("invalidDateInFileName");
					status_code = INVALID_DATE_IN_FILENAME;
					status = false;
				}

			}

			if (status == true) {
				log.info(fileName);
				String file = fileName.substring(fileName.lastIndexOf("/") + 1);
				log.info("For Last Four Digits " + file);
				String digit = file.substring(12, 16);
				log.info(digit);
				if (digit.matches("[0-9]+") && digit.length() == 4) {

					log.info("In if block");
					status = true;
				} else {
					errorReason = props.getProperty("invalidFileName");
					status_code = INVALID_FILENAME;
					status = false;
				}
			}
		}

		Workbook workbook = null;
		int tot_rows = 0;
		Sheet sheet = null;
		short tot_cols = 0;
		Row row = null;
		String sheetName;
		int stCounter = 0;
		if (status == true) {
			log.info("File name is in method readFromExcelfile " + fileName);

			try {
				if (fileName.toLowerCase().endsWith("xlsx")) {
					workbook = new XSSFWorkbook(inputStream);

				} else if (fileName.toLowerCase().endsWith("xls")) {
					workbook = new HSSFWorkbook(inputStream);
				}

			} catch (Exception e) {
				errorReason = props.getProperty("invalidFile");
				log.info("Status in method readFromExcelfile-->>" + errorReason);
				log.info("Status--->>" + errorReason);
				status_code = CORUPTED_FILE;
				status = false;
			}

			if (status == true) {
				sheetName = workbook.getSheetName(0);
				sheet = workbook.getSheet(sheetName);

				tot_rows = sheet.getLastRowNum();
				log.info("Total Number of rows " + tot_rows);
				if (tot_rows < 1) {
					errorReason = props.getProperty("noRows");
					log.info("Status in method readFromExcelfile-->>" + errorReason);
					log.info("Status--->>" + errorReason);
					status_code = NO_RECORDS;
					status = false;
				}
			}
			if (status == true) {
				if ((tot_rows) > fileId.getRecordCount()) {
					errorReason = props.getProperty("invalidNoOfRows");
					log.info("Status in method readFromExcelfile-->>" + errorReason);
					log.info("Status--->>" + errorReason);
					status_code = RECORDS_GREATER_THAN_SPECIFIEDVALUE;
					status = false;

				}
			}
			if (status == true) {

				try {
					tot_cols = sheet.getRow(0).getLastCellNum();// change this
					// line not
					// allowing
					// empty rows

				} catch (Exception e) {
					stCounter = 4;
					tot_cols = sheet.getRow(3).getLastCellNum();
				}
				fileColMstList = fileUploadDao.readFileColMstApsData(fileId.getFileIdentifier());
			}
		}
		String statusHeader = null;
		if (status == true) {
			statusHeader = fileUploadDao.validatexlsxFile(workbook, fileId.getFileIdentifier(), fileName);
			if (statusHeader.equals("SUCCESS")) {
				// errorReason = props.getProperty("success");
				log.info("Status in method readFromExcelfile--->>" + errorReason);
				log.info("Status in method readFromExcelfile--->>" + errorReason);

			} else {
				errorReason = statusHeader;
				status_code = INVALID_HEADERLIST;
				log.info("Status in method readFromExcelfile--->>" + errorReason);
				log.info("Status in method readFromExcelfile--->>" + errorReason);
				status = false;
			}
		}

		List<Object> detailsList = new ArrayList<Object>();
		if (status == true) {
			try {

				// log.info("after dao method execution" +
				// fileColMstList.size());
				if (status) {

					String classN = props.getProperty("packageName") + fileId.getBeanObject();
					Class className = Class.forName(classN);
					FileColMstAps fileColMstAps = new FileColMstAps();
					String advUtrSet = null;
					int count = 0;
					log.info("tot_rows--->>>>" + tot_rows);
					log.info("stCounter-->>" + stCounter);
					outerLoop: for (int row_counter = stCounter; row_counter <= tot_rows; row_counter++) {

						try {
							row = sheet.getRow(row_counter);
						} catch (Exception e) {
							e.printStackTrace();
							log.error(e);
						}
						// log.info("class name is with package name :
						// "+className);
						Object clsInstance = (Object) className.newInstance();
						if (row == null) {
							break outerLoop;
						}
						int isEmptyRow = 0;
						for (int k = 0; k <= row.getLastCellNum() - 1; k++) {
							Cell cellCheck = row.getCell(k);
							if (cellCheck != null && cellCheck.getCellType() != Cell.CELL_TYPE_BLANK) {
								isEmptyRow++;
							}
						}
						if (isEmptyRow == 0) {
							break outerLoop;
						}
						// log.info(clsInstance+"clsInstanceobject");
						if (row != null) {
							if (row.getRowNum() >= 1) {
								count++;
								log.info("tot_cols--->>>>" + tot_cols);
								for (int col_counter = 0; col_counter < tot_cols; col_counter++) {
									log.info("col_counter--->>>>" + col_counter);

									fileColMstAps = fileColMstList.get(col_counter);
									Cell cell1 = row.getCell(col_counter);
									String intValue1 = new DataFormatter().formatCellValue(cell1);
									if (cell1 != null && intValue1 != null && !intValue1.equalsIgnoreCase("")) {
										try {

											if ((fileColMstAps.getDataType().equals("DOUBLE"))) {

												try {
													boolean st = true;
													Cell cell = row.getCell(col_counter);
													if (cell.getCellType() == cell.CELL_TYPE_NUMERIC) {
														cell.setCellType(cell.CELL_TYPE_STRING);
													}
													String intValue = cell.getStringCellValue();
													// logger.info("cell.getNumericCellValue()-->>>"+cell.getNumericCellValue());
													log.info("Double intValue-->>" + intValue);

													// String intValue =
													// cell.getStringCellValue();
													Double.parseDouble(intValue);
													log.info("intValue-->>>" + intValue);

													/********************************
													 * MIS & CHQ START
													 ***************************************/
													if (("CHQ".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
															&& col_counter == 13)
															|| ("MIS"
																	.equalsIgnoreCase(fileColMstAps.getFileIdentifier())
																	&& col_counter == 13)) {
														String paymentCurr = row.getCell(12).toString();
														String exchangeRate = row.getCell(13).toString();

														log.info("Fetching paymentCurr when uploading CHQ  file -->>"
																+ paymentCurr);
														if ("INR".equalsIgnoreCase(paymentCurr)
																&& !("1".equalsIgnoreCase(exchangeRate))) {
															// FINAL_MODE
															errorReason = fileColMstAps.getColumnHeader()
																	+ " Only 1 is allowed as Exchange rate in "
																	+ row_counter;
															log.info("Status in method readFromExcelfile--->>"
																	+ errorReason);
															status = false;
															status_code = MANDATORY_COLUMN_NULL;
															break outerLoop;
														}
													}

													st = CommonValidator.isNumberDouble(intValue,
															fileColMstAps.getMinValue(), fileColMstAps.getMaxValue(),
															null);
													if (st == false) {
														errorReason = fileColMstAps.getColumnName() + " "
																+ props.getProperty("FieldInvalid") + " " + row_counter;
														status = false;
														break outerLoop;
													}
													log.info("fileColMstAps.getClassAttributeName()-->>>"
															+ fileColMstAps.getClassAttributeName());
													// logger.info("Double.parseDouble(row.getCell(col_counter).toString())-->>>"+Double.parseDouble(row.getCell(col_counter).toString()));
													BeanUtils.setProperty(clsInstance,
															fileColMstAps.getClassAttributeName(),
															Double.parseDouble(intValue));// clsInstance
													log.info("Get Data from Bean Object->>" + BeanUtils.getProperty(
															clsInstance, fileColMstAps.getClassAttributeName()));// clsInstance
												} catch (Exception e) {
													errorReason = fileColMstAps.getColumnName() + " "
															+ props.getProperty("FieldInvalid") + " " + row_counter;
													log.info("Status in method readFromExcelfile--->>" + errorReason);
													status = false;
													break outerLoop;
												}
											}

											else if (fileColMstAps.getDataType().equals("EXCHANGERATE")) {

												String exchangerateregex = "[0-9][0-9]?[0-9]?[0-9]?+(\\.[0-9]?[0-9]?[0-9]?[0-9]?[0-9]?[0-9]?)?";
												Cell cell = row.getCell(col_counter);

												if (cell.getCellType() == cell.CELL_TYPE_NUMERIC) {
													cell.setCellType(cell.CELL_TYPE_STRING);
												}
												String intValue = cell.getStringCellValue();

												// String intValue = new DataFormatter().formatCellValue(cell);
												// st = CommonValidator.checkLong(intValue, fileColMstAps.getMinValue(),
												// fileColMstAps.getMaxValue(), null);
												log.info("Exchange Rate->>" + intValue);
												if (!intValue.matches(exchangerateregex)) {
													errorReason = " Exchange rate should be only number with defined format in row "
															+ row_counter;
													// errorReason = fileColMstAps.getColumnName()+ " "+
													// props.getProperty("FieldInvalid")+" "+row_counter;
													log.info("Status in method readFromExcelfile--->>" + errorReason);
													status = false;
													break outerLoop;
												}
												BeanUtils.setProperty(clsInstance,
														fileColMstAps.getClassAttributeName(), intValue);
											}

											else if ((fileColMstAps.getDataType().equals("LONG"))) {
												try {
													boolean st = true;
													Cell cell = row.getCell(col_counter);
													String intValue = new DataFormatter().formatCellValue(cell);
													Long.valueOf(intValue);
													st = CommonValidator.checkLong(intValue,
															fileColMstAps.getMinValue(), fileColMstAps.getMaxValue(),
															null);

													if (st == false) {
														errorReason = fileColMstAps.getColumnName() + " "
																+ props.getProperty("FieldInvalid") + " " + row_counter;
														log.info("Status in method readFromExcelfile--->>"
																+ errorReason);
														status = false;
														break outerLoop;
													}
													BeanUtils.setProperty(clsInstance,
															fileColMstAps.getClassAttributeName(),
															Long.parseLong(intValue));
												} catch (Exception e) {
													errorReason = fileColMstAps.getColumnName() + " "
															+ props.getProperty("FieldInvalid") + " " + row_counter;
													log.info("Status in method readFromExcelfile--->>" + errorReason);
													status = false;
													break outerLoop;
												}
											} else if ((fileColMstAps.getDataType().equals("INTEGER"))) {
												try {
													boolean st = true;
													Cell cell = row.getCell(col_counter);
													String intValue = new DataFormatter().formatCellValue(cell);
													// log.info(intValue+ " "+ fileColMstAps.getMinValue()+" "+
													// fileColMstAps.getMaxValue());
													String s = fileColMstAps.getRangeOfValues();
													List<Integer> sList = CommonValidator
															.getListFromCommaSeparatedString(s);
													st = CommonValidator.checkInteger(intValue,
															fileColMstAps.getMinValue(), fileColMstAps.getMaxValue(),
															sList);
													// log.info(st);
													if (st == false) {
														errorReason = fileColMstAps.getColumnName() + " "
																+ props.getProperty("FieldInvalid") + " " + row_counter;
														log.info("Status in method readFromExcelfile--->>"
																+ errorReason);
														status = false;
														break outerLoop;
													}
													// log.info(">>"+fileColMstAps.getClassAttributeName()+Integer.parseInt(intValue));
													BeanUtils.setProperty(clsInstance,
															fileColMstAps.getClassAttributeName(),
															Integer.parseInt(intValue));
												} catch (Exception e) {
													errorReason = fileColMstAps.getColumnName() + " "
															+ props.getProperty("FieldInvalid") + " " + row_counter;
													log.info("Status in method readFromExcelfile--->>" + errorReason);
													status = false;
													break outerLoop;
												}
											} else if ((fileColMstAps.getDataType().equals("RESTRICTEDSTRING"))) {
												boolean st = true;
												Cell cell = row.getCell(col_counter);
												String intValue = new DataFormatter().formatCellValue(cell);
												// log.info("intValue"+intValue);
												char[] chars = intValue.toCharArray();
												for (char c : chars) {
													if (Character.isLetter(c) || c == ' ' || c == '.') {

													} else {
														st = false;
														break;
													}
												}

												// log.info("In restricted "+st);
												if (st == false) {
													errorReason = fileColMstAps.getColumnName() + " "
															+ props.getProperty("FieldInvalid") + " " + row_counter;
													log.info("Status in method readFromExcelfile--->>" + errorReason);
													status = false;
													break outerLoop;
												}
												// log.info(">>"+fileColMstAps.getClassAttributeName()+Integer.parseInt(intValue));
												BeanUtils.setProperty(clsInstance,
														fileColMstAps.getClassAttributeName(), (intValue));
											}
											// For cheque no
											else if ((fileColMstAps.getDataType().equals("NOSPSTRING"))) {
												log.info("in NOSPSTRING  in method readFromExcelfile");
												boolean st = true;
												Cell cell = row.getCell(col_counter);
												String intValue = new DataFormatter().formatCellValue(cell);
												// log.info(intValue);

												st = CommonValidator.stringIntegersCheck(intValue,
														fileColMstAps.getMinValue(), fileColMstAps.getMaxValue(), null);
												// log.info(st);
												if (st == false) {
													errorReason = fileColMstAps.getColumnName() + " "
															+ props.getProperty("FieldInvalid") + " " + row_counter;
													log.info("Status in method readFromExcelfile--->>" + errorReason);
													status = false;
													break outerLoop;
												}
												BeanUtils.setProperty(clsInstance,
														fileColMstAps.getClassAttributeName(), (intValue));
											}

											else if ((fileColMstAps.getDataType().equals("STRING"))) {
												Cell cell = row.getCell(col_counter);
												cell.setCellType(Cell.CELL_TYPE_STRING);

												String format = fileColMstAps.getFormat();

												if ("PTF".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
														&& (col_counter == 3)) {

													if ("UTR_NO".equalsIgnoreCase(fileColMstAps.getColumnName())
															&& (row.getCell(col_counter) != null
																	&& row.getCell(2) != null)) {

														errorReason = "Either UTR No or Chq No is Mandatory field in row "
																+ row_counter;
														log.info("Status in method readFromExcelfile--->>"
																+ errorReason);
														status = false;
														status_code = MANDATORY_COLUMN_NULL;
														break outerLoop;
													}
												}

												/********************************
												 * RRC START
												 ***************************************/

												if ("RRC".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
														&& col_counter == 2) {
													String reSRMode = row.getCell(13).toString();
													String finalMode = row.getCell(2).toString();

													log.info("Fetching ReSRMode when uploading reissue IFSC file -->>"
															+ reSRMode);
													if ("RECOURIER".equalsIgnoreCase(reSRMode)
															&& !("CHEQUE".equalsIgnoreCase(finalMode))) {
														// FINAL_MODE
														errorReason = fileColMstAps.getColumnHeader()
																+ " Only cheque is allowed as RE_SR_MODE is Recourier in row "
																+ row_counter;
														log.info("Status in method readFromExcelfile--->>"
																+ errorReason);
														status = false;
														status_code = MANDATORY_COLUMN_NULL;
														break outerLoop;
													}
												}

												if ("RRC_MODE_UPLOAD".equalsIgnoreCase(
														fileColMstAps.getFileIdentifier()) && col_counter == 18) {
													String reSRMode = row.getCell(15).toString();
													String finalMode = row.getCell(18).toString();

													log.info("Fetching ReSRMode when uploading reissue IFSC file -->>"
															+ reSRMode);
													if ("RECOURIER".equalsIgnoreCase(reSRMode)
															&& !("CHEQUE".equalsIgnoreCase(finalMode))) {
														// FINAL_MODE
														errorReason = fileColMstAps.getColumnHeader()
																+ " Only cheque is allowed as RE_SR_MODE is Recourier in row "
																+ row_counter;
														log.info("Status in method readFromExcelfile--->>"
																+ errorReason);
														status = false;
														status_code = MANDATORY_COLUMN_NULL;
														break outerLoop;
													}
												}
												// ******************************************RRC
												// END********************************************

												if (fileColMstAps.getClassAttributeName().contains("mobile")
														&& !"DEL_NO".equalsIgnoreCase(fileColMstAps.getColumnName())) {
													boolean st = true;

													st = isValidMobileNumber(cell.toString(),
															Long.parseLong(fileColMstAps.getMinValue()),
															Long.parseLong(fileColMstAps.getMaxValue()));
													if (st == false) {
														errorReason = props.getProperty("mobileInvalid") + " "
																+ row_counter;
														log.info("Status in method readFromExcelfile--->>"
																+ errorReason);
														status = false;
														break outerLoop;
													}

												} else if ("UTR_CHQ_NUMBER"
														.equalsIgnoreCase(fileColMstAps.getColumnName())
														&& "PAFILE".equalsIgnoreCase(fileIde.toUpperCase())) {

													utrSet.add(cell.toString().toUpperCase());
												} // Added on 2 Aug 2020 for PAB
												else if ("UTR_CHQ_NUMBER"
														.equalsIgnoreCase(fileColMstAps.getColumnName())
														&& "PAB".equalsIgnoreCase(fileIde.toUpperCase())) {

													utrSet.add(cell.toString().toUpperCase());
												} // addition ends

												else if ("CHEQUE_NO".equalsIgnoreCase(fileColMstAps.getColumnName())
														&& "AESADV".equalsIgnoreCase(fileIde.toUpperCase())) {
													advUtrSet = cell.toString();
												}

												else if ("DEPOSIT_SLIP_NO"
														.equalsIgnoreCase(fileColMstAps.getColumnName())
														&& "AESADV".equalsIgnoreCase(fileIde.toUpperCase())) {
													advUtrSet = advUtrSet + "|" + cell.toString();
												}

												else if ("INVOICE_ALLOCATION_AMOUNT"
														.equalsIgnoreCase(fileColMstAps.getColumnName())
														&& "AESADV".equalsIgnoreCase(fileIde.toUpperCase())) {
													advUtrSet = advUtrSet + "|" + cell.toString();
													log.info("advUtrSet==>" + advUtrSet);
												}
												/*
												 * else
												 * if("CUSTOMER_TAN_NO".equalsIgnoreCase(fileColMstAps.getColumnName())
												 * && "TDS".equalsIgnoreCase(fileIde.toUpperCase()) ){ advUtrSet
												 * =cell.toString() ; }
												 */
												else if ("FINANCIAL_YEAR"
														.equalsIgnoreCase(fileColMstAps.getColumnName())
														&& "TDS".equalsIgnoreCase(fileIde.toUpperCase())) {
													advUtrSet = advUtrSet + "|" + cell.toString();
												}

												/*
												 * else if("QUARTER".equalsIgnoreCase(fileColMstAps.getColumnName()) &&
												 * "TDS".equalsIgnoreCase(fileIde.toUpperCase()) ){//bypassed quater
												 * //advUtrSet = advUtrSet + "|" + cell.toString() ;
												 * 
												 * log.info("advUtrSet==>"+advUtrSet); }
												 */
												/*
												 * else
												 * if("INVOICE_NUMBER".equalsIgnoreCase(fileColMstAps.getColumnName())
												 * && "TDS".equalsIgnoreCase(fileIde.toUpperCase()) ){ String
												 * invoice_number =cell.toString() ; if(invoice_number.length())
												 * 
												 * log.info("advUtrSet==>"+advUtrSet); }
												 */
												else {

													boolean st = true;
													String s = fileColMstAps.getRangeOfValues();
													List<String> sList = CommonValidator
															.getListFromCommaSeparatedString(s);
													st = CommonValidator.checkStringLength(
															cell.toString().toUpperCase().trim(),
															fileColMstAps.getMinValue(), fileColMstAps.getMaxValue(),
															sList);

													if (st == false) {
														errorReason = fileColMstAps.getColumnHeader() + " "
																+ props.getProperty("FieldInvalid") + " " + row_counter;
														log.info("Status in method readFromExcelfile--->>"
																+ errorReason);
														status = false;
														break outerLoop;
													}

												}

												if (format != null && "UPPERCASE".equalsIgnoreCase(format)) {
													BeanUtils.setProperty(clsInstance,
															fileColMstAps.getClassAttributeName(), cell.toString()
																	.replaceAll("\\u00a0", "").trim().toUpperCase());
												} else {
													BeanUtils.setProperty(clsInstance,
															fileColMstAps.getClassAttributeName(),
															cell.toString().replaceAll("\\u00a0", "").trim());
												}
											}

											else if ((fileColMstAps.getDataType().equals("ACCOUNTSTR"))) {

												Cell cell = row.getCell(col_counter);
												cell.setCellType(Cell.CELL_TYPE_STRING);

												boolean st = true;
												String s = fileColMstAps.getRangeOfValues();
												List<String> sList = CommonValidator.getListFromCommaSeparatedString(s);
												st = CommonValidator.checkStringLength(
														cell.toString().toUpperCase().trim(),
														fileColMstAps.getMinValue(), fileColMstAps.getMaxValue(),
														sList);

												if (st == false) {
													errorReason = fileColMstAps.getColumnHeader() + " "
															+ props.getProperty("FieldInvalid") + " " + row_counter;
													log.info("Status in method readFromExcelfile--->>" + errorReason);
													status = false;
													break outerLoop;
												}
												BeanUtils.setProperty(clsInstance,
														fileColMstAps.getClassAttributeName(),
														cell.toString().replaceAll("\\u00a0", "").trim()
																.replaceAll("[^a-zA-Z0-9-:~_]", "X"));

											}

											else if (fileColMstAps.getDataType().equals("TANSTR")) {

												String sts = "true";
												String regEx = "[A-Z]{4}[0-9]{5}[A-Z]{1}";
												String dataStr = row.getCell(col_counter).toString();
												if (dataStr != null && !dataStr.equals("") && !dataStr.matches(regEx)) {
													errorReason = "In " + fileColMstAps.getColumnHeader()
															+ ", TAN Number Should be AAAA55555A Formate in row "
															+ row_counter;
													log.info("Status in method readFromExcelfile--->>" + errorReason);
													status = false;
													break outerLoop;
												}
												if ("CUSTOMER_TAN_NO".equalsIgnoreCase(fileColMstAps.getColumnName())
														&& "TDS".equalsIgnoreCase(fileIde.toUpperCase())) {
													advUtrSet = dataStr;
												}
												BeanUtils.setProperty(clsInstance,
														fileColMstAps.getClassAttributeName(), dataStr.trim());

											} else if ((fileColMstAps.getDataType().equals("DATE"))) {
												// log.info("--->>"+row.getCell(col_counter).toString());

												// DateFormat formatter = new
												// SimpleDateFormat("dd-MMM-yy");

												if (list.contains(fileIde.toUpperCase())
														|| "RNH".equalsIgnoreCase(fileIde.toUpperCase())
														|| "PNH".equalsIgnoreCase(fileIde.toUpperCase())
														|| "MIC".equalsIgnoreCase(fileIde.toUpperCase())
														|| "REV".equalsIgnoreCase(fileIde.toUpperCase())
														|| "PTF".equalsIgnoreCase(fileIde.toUpperCase())) {
													try {
														String st = "true";
														String dateRegex = "[0-9][0-9][\\/][0-9][0-9][\\/][0-9]{4}";
														// date = new
														// SimpleDateFormat("MM/dd/yyyy").parse(row2.getCell(j).getStringCellValue());
														// java.sql.Date sqlDate13 = new
														// java.sql.Date(row2.getCell(j).getDateCellValue().getTime());
														String dateString = row.getCell(col_counter).toString();
														log.info("dateString----------->>>>>" + dateString);
														if (dateString.length() > 10
																|| !(dateString.matches(dateRegex))) {
															errorReason = "In " + fileColMstAps.getColumnHeader()
																	+ ", Date Format should be valid(MM/DD/YYYY) in row "
																	+ row_counter;
															log.info("Status in method readFromExcelfile--->>"
																	+ errorReason);
															status = false;
															break outerLoop;
														}
														SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
														Date date = sdf.parse(dateString);
														java.sql.Date sqlDate13 = new java.sql.Date(date.getTime());
														// bd.setPaymentDate(sqlDate13);

														String subString2 = dateString.substring(0, 2);

														String subString3 = dateString.substring(3, 5);
														boolean status1 = true;
														boolean status2 = true;

														if (Integer.parseInt(subString2) > 12
																|| Integer.parseInt(subString2) < 1)
															status1 = false;
														if (Integer.parseInt(subString3) > 31
																|| Integer.parseInt(subString3) < 1)
															status2 = false;
														if (!(status1 && status2)) {
															errorReason = "In " + fileColMstAps.getColumnHeader()
																	+ ", Date Format should be valid(MM/DD/YYYY) in row "
																	+ row_counter;
															log.info("Status in method readFromExcelfile--->>"
																	+ errorReason);
															status = false;
															break outerLoop;
														}
														st = CommonValidator.dateCheckPaymentCheck(dateString,
																fileColMstAps.getMinValue(),
																fileColMstAps.getMaxValue(), fileColMstAps.getFormat(),
																null);
														log.info("dateString--->>" + dateString + " st-->>>" + st);
														if (st.equalsIgnoreCase("false")) {
															errorReason = "In " + fileColMstAps.getColumnHeader()
																	+ ", Date is not valid in Row " + row_counter;
															log.info("Status in method readFromExcelfile--->>"
																	+ errorReason);
															status = false;
															break outerLoop;
														}
														if (!st.equalsIgnoreCase("false")
																&& !st.equalsIgnoreCase("true")) {
															errorReason = "In " + fileColMstAps.getColumnHeader() + ", "
																	+ st + " in Row " + row_counter;
															log.info("Status in method readFromExcelfile--->>"
																	+ errorReason);
															status = false;
															break outerLoop;
														}
														BeanUtils.setProperty(clsInstance,
																fileColMstAps.getClassAttributeName(), date);
													} catch (Exception ex) {
														ex.printStackTrace();
														errorReason = "In " + fileColMstAps.getColumnHeader()
																+ ", Date Format should be valid(MM/DD/YYYY) in row "
																+ row_counter;
														log.info("Status in method readFromExcelfile--->>"
																+ errorReason);
														status = false;
														break outerLoop;
													}
												}

												// DateFormat formatter = new
												// SimpleDateFormat("MM/dd/yyyy");
												else {

													log.info("Date is before parsing in method readFromExcelfile : "
															+ row.getCell(col_counter).toString());
													Date date = null;
													String dateString;
													Date intValue = null;
													boolean st = true;
													String date1 = null;
													if (row.getCell(col_counter).toString() != null) {
														// date = (Date)
														// formatter.parse(row.getCell(col_counter).toString());
														// parsing date in any
														// date type

														String[] formatStrings = { fileColMstAps.getFormat() };
														// ...
														Cell cell = row.getCell(col_counter);

														/* String dateString=row.getCell(col_counter).toString(); */
														// log.info(fileColMstAps.getFormat()+dateString);
														for (String formatString : formatStrings) {
															try {

																try {
																	intValue = cell.getDateCellValue();
																	log.info("Date:" + intValue);
																	date1 = new SimpleDateFormat(formatString)
																			.format(intValue);
																	log.info("Date1:" + date1);
																	date = new SimpleDateFormat(formatString)
																			.parse(date1);
																	log.info("date:" + date);
																	st = CommonValidator.dateCheck(date1,
																			fileColMstAps.getMinValue(),
																			fileColMstAps.getMaxValue(),
																			fileColMstAps.getFormat(), fileIde);
																} catch (Exception e) {
																	dateString = row.getCell(col_counter).toString();
																	date = new SimpleDateFormat(formatString)
																			.parse(dateString);
																	st = CommonValidator.dateCheck(dateString,
																			fileColMstAps.getMinValue(),
																			fileColMstAps.getMaxValue(),
																			fileColMstAps.getFormat(), fileIde);
																}
															} catch (ParseException e) {
																errorReason = fileColMstAps.getColumnHeader() + " "
																		+ props.getProperty("FieldInvalid") + " "
																		+ row_counter;
																log.info("Status in method readFromExcelfile--->>"
																		+ errorReason);
																status = false;
																break outerLoop;
															}
														}
														/*
														 * boolean st = CommonValidator.dateCheck(dateString, "", "",
														 * fileColMstAps.getFormat());
														 */
														// log.info("ST is "+st+" and date is "+date);
														if (st == false) {
															errorReason = "In " + fileColMstAps.getColumnHeader()
																	+ ", Date is not valid in row " + row_counter;
															log.info("Status in method readFromExcelfile--->>"
																	+ errorReason);
															status = false;
															break outerLoop;
														}
														// log.info(st);
														log.info(
																"in readFromExcelfile after dateconversion date is -->>"
																		+ date);
													}
													BeanUtils.setProperty(clsInstance,
															fileColMstAps.getClassAttributeName(), date);
												}
											}
											// Added by geeta
											else if ((fileColMstAps.getDataType().equals("ALPHANUMERIC"))) {
												log.info("in ALPHANUMERIC  in method readFromExcelfile");
												boolean st = true;
												Cell cell = row.getCell(col_counter);
												String intValue = new DataFormatter().formatCellValue(cell);
												// log.info(intValue);

												st = CommonValidator.stringWithoutSepcialChar(intValue,
														fileColMstAps.getMinValue(), fileColMstAps.getMaxValue(), null);
												// log.info(st);
												if (st == false) {
													errorReason = fileColMstAps.getColumnName() + " "
															+ props.getProperty("FieldInvalid") + " " + row_counter;
													log.info("Status in method readFromExcelfile--->>" + errorReason);
													status = false;
													break outerLoop;
												}
												BeanUtils.setProperty(clsInstance,
														fileColMstAps.getClassAttributeName(), (intValue));
											}

										} catch (Exception e) {
											errorReason = fileColMstAps.getColumnHeader() + " "
													+ props.getProperty("invalidDatatype") + row_counter;
											log.info("Status in method readFromExcelfile--->>" + errorReason);
											status_code = INVALID_DATATYPE;
											status = false;
											log.error(e);
											e.printStackTrace();
											break outerLoop;
										}

									}

									else if (fileColMstAps.getRequired().equals("O")
											&& (row.getCell(col_counter) == null
													|| row.getCell(col_counter).getStringCellValue().equals("")))

									{
										String columnName = fileColMstAps.getColumnName();
										// Cell cell = row.getCell(col_counter);
										System.out.println("Fetching column name from DB in null-->>" + columnName);
										log.info("Fetching column name from DB in null-->>" + columnName);
										System.out.println("Fetching column name fileColMstAps.getFileIdentifier() -->>"
												+ fileColMstAps.getFileIdentifier());

										if ("PTF".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& (col_counter == 3)) {
											log.info("row.getCell(2)->" + row.getCell(2) + " row.getCell(col_counter)->"
													+ row.getCell(col_counter));
											if ("UTR_NO".equalsIgnoreCase(fileColMstAps.getColumnName())
													&& (row.getCell(col_counter) == null && row.getCell(2) == null)) {

												errorReason = "Either UTR No or Chq No is Mandatory field in row "
														+ row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}
										if ("REF_MODE_UPLOAD".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& (col_counter == 13 || col_counter == 14)) {
											String refundMode = row.getCell(12).toString();
											log.info("Fetching RefundMode when uploading refund IFSC file -->>"
													+ refundMode);
											if ("NEFT".equalsIgnoreCase(refundMode) && (row.getCell(col_counter) == null
													|| intValue1 == null || intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}
										if ("REF_MODE_UPLOAD".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& col_counter == 15) {
											// cell = row.getCell(13);
											String refundMode1 = row.getCell(12).toString();
											log.info("Fetching RefundMode when uploading refund IFSC file -->>"
													+ refundMode1);
											if ("REJECTED".equalsIgnoreCase(refundMode1)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}
										if ("REF_MODE_UPLOAD".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& (col_counter == 18 || col_counter == 19 || col_counter == 20)
												&& row.getCell(18) != null) {
											// cell = row.getCell(13);
											String addressChange = row.getCell(17).toString();
											log.info("Fetching AddressChange when uploading refund IFSC file -->>"
													+ addressChange);
											if ("Y".equalsIgnoreCase(addressChange) && (row.getCell(col_counter) == null
													|| intValue1 == null || intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										if ("WIS".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& col_counter == 38) {
											// cell = row.getCell(13);
											String wac_status = row.getCell(39).toString();
											log.info("Fetching wac_status when uploading Wac IES file -->>"
													+ wac_status);
											if ("NOT RECOMMENDED".equalsIgnoreCase(wac_status)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {
												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}
										if ("WMT".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& col_counter == 40) {
											// cell = row.getCell(13);
											String wac_status = row.getCell(41).toString();
											log.info("Fetching wac_status when uploading Wac IES file -->>"
													+ wac_status);
											if ("NOT RECOMMENDED".equalsIgnoreCase(wac_status)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {
												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										if ("CIS".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& col_counter == 49) { // cell = row.getCell(13);
											String cad_status = row.getCell(50).toString();
											log.info("Fetching cad_status when uploading CAD AIES file -->>"
													+ cad_status);
											if ("NOT APPROVED".equalsIgnoreCase(cad_status)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {
												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}
										if ("CMT".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& col_counter == 45) { // cell = row.getCell(13);
											String cad_status = row.getCell(46).toString();
											log.info("Fetching cad_status when uploading CAD MO/FL file -->>"
													+ cad_status);
											if ("NOT APPROVED".equalsIgnoreCase(cad_status)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {
												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										if ("RRC_MODE_UPLOAD".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& col_counter == 16) {
											String reSRMode = row.getCell(15).toString();
											log.info("Fetching ReSRMode when uploading reissue IFSC file -->>"
													+ reSRMode);
											if ("REISSUE".equalsIgnoreCase(reSRMode)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}
										if ("RRC_MODE_UPLOAD".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& col_counter == 16) {
											String reSRMode1 = row.getCell(15).toString();
											log.info("Fetching ReSRMode when uploading reissue IFSC file -->>"
													+ reSRMode1);
											if ("REISSUE".equalsIgnoreCase(reSRMode1)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										if ("RRC_MODE_UPLOAD".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& (col_counter == 19 || col_counter == 20)) {
											String refundMode = row.getCell(18).toString();
											log.info("Fetching RefundMode when uploading reissue IFSC file -->>"
													+ refundMode);
											if ("NEFT".equalsIgnoreCase(refundMode) && (row.getCell(col_counter) == null
													|| intValue1 == null || intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}
										if ("RRC_MODE_UPLOAD".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& col_counter == 21) {
											// cell = row.getCell(13);
											String refundMode1 = row.getCell(18).toString();
											log.info("Fetching RefundMode when uploading reissue IFSC file -->>"
													+ refundMode1);
											if ("REJECTED".equalsIgnoreCase(refundMode1)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}
										if ("RRC_MODE_UPLOAD".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& (col_counter == 24 || col_counter == 25 || col_counter == 26)
												&& row.getCell(23) != null) {
											// cell = row.getCell(13);
											String addressChange = row.getCell(23).toString();
											log.info("Fetching Addresschange when uploading reissue IFSC file -->>"
													+ addressChange);
											if ("Y".equalsIgnoreCase(addressChange) && (row.getCell(col_counter) == null
													|| intValue1 == null || intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}
										if ("CB_TRANS_UPLOAD".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& col_counter == 9) {
											// cell = row.getCell(13);
											String transactiontype = row.getCell(0).toString();
											log.info("Fetching Transactiontype when uploading cb_trans file -->>"
													+ transactiontype);
											if (("N".equalsIgnoreCase(transactiontype)
													|| "I".equalsIgnoreCase(transactiontype)
													|| "R".equalsIgnoreCase(transactiontype))
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}
										if ("CB_TRANS_UPLOAD".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& col_counter == 10) {
											// cell = row.getCell(13);
											String transactiontype = row.getCell(0).toString();
											if ("N".equalsIgnoreCase(transactiontype)
													|| "I".equalsIgnoreCase(transactiontype)
													|| "R".equalsIgnoreCase(transactiontype)) {
												rejectionReason = row.getCell(9).toString();
											}
											log.info("Fetching RejectionReason when uploading cb_trans file -->>"
													+ rejectionReason);
											if (("N".equalsIgnoreCase(transactiontype)
													|| "I".equalsIgnoreCase(transactiontype)
													|| "R".equalsIgnoreCase(transactiontype))
													&& "R".equalsIgnoreCase(rejectionReason)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										if ("AWB_RTO_UPLOAD".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& col_counter == 19) {
											// cell = row.getCell(13);
											String deliveryStatus = row.getCell(17).toString();
											// String RejectionReason=row.getCell(10).toString();
											log.info("Fetching DeliveryStatus when uploading AWB_RTO file -->>"
													+ deliveryStatus);
											if ("RTO".equalsIgnoreCase(deliveryStatus)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										if ("REF".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& (col_counter == 5 || col_counter == 6)) {
											// cell = row.getCell(13);
											String modeofRefund = row.getCell(4).toString();
											// String RejectionReason=row.getCell(10).toString();
											log.info("Fetching ModeofRefund when uploading Refund file -->>"
													+ modeofRefund);
											if ("NEFT".equalsIgnoreCase(modeofRefund)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										if ("REF".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& (col_counter == 7)) {
											// cell = row.getCell(13);
											String modeofRefund = row.getCell(4).toString();
											// String RejectionReason=row.getCell(10).toString();
											log.info("Fetching ModeofRefund when uploading Refund file -->>"
													+ modeofRefund);
											if ("CHEQUE".equalsIgnoreCase(modeofRefund)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										if ("RRC".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& (col_counter == 3 || col_counter == 4)) {
											// cell = row.getCell(13);
											String modeofRefund = row.getCell(2).toString();
											// String RejectionReason=row.getCell(10).toString();
											log.info("Fetching ModeofRefund when uploading Reissue file -->>"
													+ modeofRefund);
											if ("NEFT".equalsIgnoreCase(modeofRefund)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										if ("RRC".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& (col_counter == 7 || col_counter == 10 || col_counter == 11)) {
											// cell = row.getCell(13);
											String modeofRefund = row.getCell(2).toString();
											// String RejectionReason=row.getCell(10).toString();
											log.info("Fetching ModeofRefund when uploading Reissue file -->>"
													+ modeofRefund);
											if ("CHEQUE".equalsIgnoreCase(modeofRefund)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										if ("RRC".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& col_counter == 14) {
											// cell = row.getCell(13);
											String reSrMode = row.getCell(13).toString();
											// String RejectionReason=row.getCell(10).toString();
											log.info("Fetching ModeofRefund when uploading Reissue file -->>"
													+ reSrMode);
											if ("REISSUE".equalsIgnoreCase(reSrMode)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										if ("RRC".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& col_counter == 14) {
											// cell = row.getCell(13);
											String reSrMode = row.getCell(13).toString();
											// String RejectionReason=row.getCell(10).toString();
											log.info("Fetching ModeofRefund when uploading Reissue file -->>"
													+ reSrMode);
											if ("REISSUE".equalsIgnoreCase(reSrMode)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										if ("CB_DECISION_UPLOAD".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& col_counter == 11) {
											// cell = row.getCell(13);
											String cbPaymentStatus = row.getCell(10).toString();
											// String RejectionReason=row.getCell(10).toString();
											log.info("Fetching ModeofRefund when uploading Reissue file -->>"
													+ cbPaymentStatus);
											if ("PAID".equalsIgnoreCase(cbPaymentStatus)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										if ("REF_CISTM".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& (col_counter == 6 || col_counter == 7 || col_counter == 8)) {
											String refundMode = row.getCell(5).toString();
											log.info("Fetching ModeofRefund when uploading REF_ISTM file -->>"
													+ refundMode);

											if ("CHEQUE".equalsIgnoreCase(refundMode)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										if ("REF_CISTM".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& (col_counter == 9 || col_counter == 10)) {
											String refundMode = row.getCell(5).toString();
											log.info("Fetching ModeofRefund when uploading REF_ISTM file -->>"
													+ refundMode);

											if ("NEFT".equalsIgnoreCase(refundMode) && (row.getCell(col_counter) == null
													|| intValue1 == null || intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										if ("REF_DISTM".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& (col_counter == 8 || col_counter == 9 || col_counter == 10)) {
											String refundMode = row.getCell(7).toString();
											log.info("Fetching ModeofRefund when uploading REF_ISTM file -->>"
													+ refundMode);

											if ("CHEQUE".equalsIgnoreCase(refundMode)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										if ("REF_DISTM".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& (col_counter == 11 || col_counter == 12)) {
											String refundMode = row.getCell(7).toString();
											log.info("Fetching ModeofRefund when uploading REF_ISTM file -->>"
													+ refundMode);

											if ("NEFT".equalsIgnoreCase(refundMode) && (row.getCell(col_counter) == null
													|| intValue1 == null || intValue1.equalsIgnoreCase(""))) {

												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter;
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										if ("REF_DTH".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& (col_counter == 13 || col_counter == 14 || col_counter == 15)) {
											String refundMode = row.getCell(7).toString();
											log.info("Fetching ModeofRefund when uploading REF_DTH file -->>"
													+ refundMode);

											if ("ONLINE".equalsIgnoreCase(refundMode)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {
												System.out.println("In Online refund mode REF_DTH file -->>"
														+ row.getCell(col_counter));
												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter
														+ "for ONLINE";
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										if ("REF_DTH".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& (col_counter == 8 || col_counter == 2 || col_counter == 9
														|| col_counter == 10)) {
											String refundMode = row.getCell(7).toString();
											log.info("Fetching ModeofRefund when uploading REF_DTH file -->>"
													+ refundMode);

											if ("CHEQUE".equalsIgnoreCase(refundMode)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {
												System.out.println("In CHEQUE refund mode REF_DTH file -->>"
														+ row.getCell(col_counter));
												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter
														+ " FOR CHEQUE";
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										if ("REF_DTH".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												&& (col_counter == 11 || col_counter == 12)) {
											String refundMode = row.getCell(7).toString();
											log.info("Fetching ModeofRefund when uploading REF_ISTM file -->>"
													+ refundMode);

											if ("NEFT".equalsIgnoreCase(refundMode) && (row.getCell(col_counter) == null
													|| intValue1 == null || intValue1.equalsIgnoreCase(""))) {
												System.out.println("In NEFT refund mode REF_DTH file -->>"
														+ row.getCell(col_counter));
												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter
														+ " FOR NEFT";
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										if (("REF_TM".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												|| "REF_TMP".equalsIgnoreCase(fileColMstAps.getFileIdentifier()))
												&& (col_counter == 10 || col_counter == 11)) {// 8,9
											String refundMode = row.getCell(4).toString();
											log.info("Fetching ModeofRefund when uploading REF_TM file -->>"
													+ refundMode);
											System.out.println("REFUND_MODE---->>" + " AND FILE_IDENTIFIER--->>"
													+ fileColMstAps.getFileIdentifier() + " AND FOR COL COUNTER--->>"
													+ col_counter);
											if ("NEFT".equalsIgnoreCase(refundMode) && (row.getCell(col_counter) == null
													|| intValue1 == null || intValue1.equalsIgnoreCase(""))) {

												System.out.println("In NEFT refund mode REF_TM file -->>"
														+ row.getCell(col_counter));
												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter
														+ " FOR NEFT";
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										// System.out.println("REFUND_MODE---->>"+row.getCell(6).toString()+" AND
										// FILE_IDENTIFIER--->>"+fileColMstAps.getFileIdentifier()+ " AND FOR COL
										// COUNTER--->>"+col_counter);
										if (("REF_TM".equalsIgnoreCase(fileColMstAps.getFileIdentifier())
												|| "REF_TMP".equalsIgnoreCase(fileColMstAps.getFileIdentifier()))
												&& (col_counter == 7 || col_counter == 8 || col_counter == 9)) {// 7

											String refundMode = row.getCell(4).toString();
											log.info("Fetching ModeofRefund when uploading REF_ISTM file -->>"
													+ refundMode);

											if ("CHEQUE".equalsIgnoreCase(refundMode)
													&& (row.getCell(col_counter) == null || intValue1 == null
															|| intValue1.equalsIgnoreCase(""))) {
												System.out.println("In CHEQUE refund mode REF_TM file -->>"
														+ row.getCell(col_counter));
												errorReason = fileColMstAps.getColumnHeader() + " "
														+ props.getProperty("mandatoryFieldNull") + row_counter
														+ " FOR CHEQUE";
												log.info("Status in method readFromExcelfile--->>" + errorReason);
												status = false;
												status_code = MANDATORY_COLUMN_NULL;
												break outerLoop;
											}
										}

										clsInstance = readExcelFileData(fileColMstAps.getClassAttributeName(), "",
												clsInstance);

										/*
										 * commmented for Refund changes else if
										 * (fileColMstAps.getRequired().equals("O") && row.getCell(col_counter) == null)
										 * {
										 * 
										 * 
										 * /////to be added here (fileColMstAps.getDataType().equals( "STRING"))
										 * 
										 * String columnName=fileColMstAps.getColumnName(); Cell cell =
										 * row.getCell(col_counter); log. info("Fetching column name from DB -->>"
										 * +columnName); log.
										 * info("Fetching column name fileColMstAps.getFileIdentifier() -->>"
										 * +fileColMstAps.getFileIdentifier()); if("REF".equalsIgnoreCase(fileColMstAps.
										 * getFileIdentifier()) && "ADDRESS1".equalsIgnoreCase(columnName)){
										 * 
										 * cell = row.getCell(4); String RefundMode=cell.toString(); log.
										 * info("Fetching RefundMode when uploading refund file -->>" +RefundMode);
										 * if("CHEQUE".equalsIgnoreCase(RefundMode) && (row.getCell(col_counter) == null
										 * || intValue1 == null || intValue1.equalsIgnoreCase(""))){
										 * 
										 * errorReason = fileColMstAps.getColumnHeader()+" "+props
										 * .getProperty("mandatoryFieldNull") +row_counter; log.
										 * info("Status in method readFromExcelfile--->>" +errorReason); status = false;
										 * status_code = MANDATORY_COLUMN_NULL; break outerLoop;
										 * 
										 * }
										 * 
										 * } ///added end
										 * 
										 * clsInstance = readExcelFileData(fileColMstAps. getClassAttributeName(), "",
										 * clsInstance);
										 * 
										 * 
										 * 
										 * }
										 */
									} else if (fileColMstAps.getRequired().equals("M")
											&& (row.getCell(col_counter) == null || intValue1 == null
													|| intValue1.equalsIgnoreCase(""))) {

										errorReason = fileColMstAps.getColumnHeader() + " "
												+ props.getProperty("mandatoryFieldNull") + row_counter;
										log.info("Status in method readFromExcelfile--->>" + errorReason);
										status = false;
										status_code = MANDATORY_COLUMN_NULL;
										break outerLoop;
									}
									if (fileId.getAmountCol() - 1 == col_counter) {
										Cell cell = row.getCell(col_counter);
										if (cell.getCellType() == cell.CELL_TYPE_NUMERIC) {
											cell.setCellType(cell.CELL_TYPE_STRING);
										}
										// String intValue = new DataFormatter().formatCellValue(cell);
										log.info("Inside Sum block->>" + cell.getStringCellValue());
										sum = sum + Double.parseDouble(cell.getStringCellValue());

									}

								}
								detailsList.add(clsInstance);
							}

						}

						log.info("In readFromExcelfile record sum is " + sum);
						if (status == true) {
							if (sum > fileId.getRecordSum()) {
								errorReason = props.getProperty("invalidSum");
								log.info("Status in method readFromExcelfile--->>" + errorReason);
								status_code = SUM_GREATER_THAN_SPECIFIEDVALUE;
								status = false;
							}
						}
						// Adding AESAdvice Utr set for each row
						if ("AESADV".equalsIgnoreCase(fileIde.toUpperCase()) && (advUtrSet != null)) {
							log.info("advUtrSet==>" + advUtrSet);
							utrSet.add(advUtrSet.toUpperCase());
							advUtrSet = "";
							log.info("utrSet after adding unique key for AESADV===>" + utrSet);
						}
						if ("TDS".equalsIgnoreCase(fileIde.toUpperCase()) && (advUtrSet != null)) {
							log.info("advUtrSet==>" + advUtrSet);
							utrSet.add(advUtrSet.toUpperCase());
							advUtrSet = "";
							log.info("utrSet after adding unique key for TDS===>" + utrSet);
						}
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
				log.info(e);
			}
		}
		tot_rows = tot_rows - stCounter;
		Date date;
		String dateInString = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
		log.info(dateInString);
		date = new SimpleDateFormat("yyyy-MM-dd").parse(dateInString);
		log.info("Date is ---------- " + date);
		if (status == true) {
			log.info("file_identifier---------for ISTM>>" + fileId.getFileIdentifier());

			/*
			 * Changed to bypass duplicate check Proc in Refund files
			 * 
			 * int count = fileUploadDao.duplicateFileName(fileName,tot_rows,
			 * sum,date,list,fileId.getFileIdentifier()); if(count>0){ status= false;
			 * errorReason = props.getProperty("duplicateFileName");
			 * log.info("Status in method readFromExcelfile--->>"+errorReason); status_code
			 * = DUPLICATE_FILE_NAME; }
			 * 
			 * 
			 */

			if (fileId.getFileIdentifier().equalsIgnoreCase("AWB_UPLOAD")
					|| fileId.getFileIdentifier().equalsIgnoreCase("AWB_RTO_UPLOAD")
					|| fileId.getFileIdentifier().equalsIgnoreCase("IP_UPLOAD")
					|| fileId.getFileIdentifier().equalsIgnoreCase("REF_MODE_UPLOAD")
					|| fileId.getFileIdentifier().equalsIgnoreCase("RRC_MODE_UPLOAD")
					|| fileId.getFileIdentifier().equalsIgnoreCase("CB_TRANS_UPLOAD")
					|| fileId.getFileIdentifier().equalsIgnoreCase("CB_DECISION_UPLOAD")) {

			}

			// else if(fileId.getFileIdentifier().equalsIgnoreCase("AESADV") ||
			// fileId.getFileIdentifier().equalsIgnoreCase("AESDP") ||
			// fileId.getFileIdentifier().equalsIgnoreCase("AESDUMMY") )
			else if (fileId.getFileIdentifier().equalsIgnoreCase("AESDUMMY")) {// wac and cad enter lob
				int count1 = fileUploadDao.duplicateFileName(fileName, tot_rows, sum, date, list,
						fileId.getFileIdentifier());
				if (count1 > 0) {
					status = false;
					errorReason = props.getProperty("duplicateFileName");
					log.info("Status in method readFromExcelfile--->>" + errorReason);
					status_code = DUPLICATE_FILE_NAME;

				}
			}

			else {

				log.info("file_identifier---------for ISTM>>" + fileId.getFileIdentifier());
				int count = fileUploadDao.duplicateFileName(fileName, tot_rows, sum, date, list,
						fileId.getFileIdentifier());
				if (count > 0) {
					status = false;
					errorReason = props.getProperty("duplicateFileName");
					log.info("Status in method readFromExcelfile--->>" + errorReason);
					status_code = DUPLICATE_FILE_NAME;
				}
			}
		}
		// int invalidCount = 0;
		String invalidCount = "0";

		ResponseOfInsert res = new ResponseOfInsert();
		if (status == true) {
			log.info("file_Id-->> " + file_Id + " detailsList-->> " + detailsList + " fileId--> " + fileId);
			log.info("fileColMstList-> " + fileColMstList + " source-->> " + source + " user--> " + user);
			// aps3 changes create insert table
			log.info("ADDING TO UPLOAD CHEQUE PAYMENT FILE->>" + fileId.getFileIdentifier() + " source-->> " + source
					+ " user--> " + user);
			list.add("MIC");
			list.add("REV");
			list.add("PNH");
			list.add("RNH");

			if (list.contains(fileIde.toUpperCase())) {

				res = fileUploadDao.insertIntoPaymentsTable(Integer.parseInt(file_Id), detailsList, fileId,
						fileColMstList, source, user);

			} else {
				log.info("Inside else part ");
				res = fileUploadDao.insertIntoDynamicTable(Integer.parseInt(file_Id), detailsList, fileId,
						fileColMstList, source, user, validateFile);
			}
			list.remove("MIC");
			list.remove("REV");
			list.remove("RNH");
			list.remove("PNH");

			if ("Data Failure Issue while Uploading".equalsIgnoreCase(res.getErrorReason())) {

				status = false;
				errorReason = "Data Failure Issue while Uploading";
			} else if ((Integer.parseInt(res.getCountRows())) <= 0) {

				status = false;
				errorReason = "Data Failure Issue while empty Uploading";
			}

			/*
			 * else if ("REF_ISTM".equalsIgnoreCase(fileIde.toUpperCase()) ||
			 * "REF_DTH".equalsIgnoreCase(fileIde.toUpperCase()) ||
			 * "REF_TM".equalsIgnoreCase(fileIde.toUpperCase()) ||
			 * "REF_TMP".equalsIgnoreCase(fileIde.toUpperCase())) invalidCount =
			 * fileUploadDao.duplicateProc(Integer.parseInt(file_Id),
			 * fileId.getFileIdentifier());
			 */else
				invalidCount = fileUploadDao.duplicateProc(Integer.parseInt(file_Id), fileId.getFileIdentifier());

		}

		if (invalidCount == null) {

			errorReason = "ERROR WHILE UPLOADING FILE";
			status = false;
			status_code = DUPLICATE_ROWS;
		} else if (!"0".equalsIgnoreCase(invalidCount) && status == true) {
			status = false;
			// added for duplicate row number
			System.out.println("Adding Duplicate Row Number-->> " + invalidCount);

			/*
			 * Changed to handled Refund File Modes
			 * if(fileId.getFileIdentifier().equalsIgnoreCase("BNECS") ||
			 * fileId.getFileIdentifier().equalsIgnoreCase("ISECS") ||
			 * fileId.getFileIdentifier().equalsIgnoreCase("BRECS"){
			 */

			if (fileId.getFileIdentifier().equalsIgnoreCase("BNECS")
					|| fileId.getFileIdentifier().equalsIgnoreCase("ISECS")
					|| fileId.getFileIdentifier().equalsIgnoreCase("BRECS")
					|| fileId.getFileIdentifier().equalsIgnoreCase("AWB_UPLOAD")
					|| fileId.getFileIdentifier().equalsIgnoreCase("AWB_RTO_UPLOAD")
					|| fileId.getFileIdentifier().equalsIgnoreCase("IP_UPLOAD")
					|| fileId.getFileIdentifier().equalsIgnoreCase("REF_MODE_UPLOAD")
					|| fileId.getFileIdentifier().equalsIgnoreCase("RRC_MODE_UPLOAD")
					|| fileId.getFileIdentifier().equalsIgnoreCase("CB_TRANS_UPLOAD")
					|| fileId.getFileIdentifier().equalsIgnoreCase("CB_DECISION_UPLOAD")) {

				errorReason = "Duplicate Rows are present in File Record.";
			} else if (fileId.getFileIdentifier().equalsIgnoreCase("TAN")
					|| fileId.getFileIdentifier().equalsIgnoreCase("LTC")) {
				errorReason = "Duplicate Rows are present in File.Please cross check File Records";
			}
			/*
			 * else if(fileId.getFileIdentifier().equalsIgnoreCase("LTC") ) { errorReason =
			 * "Duplicate Rows are present in File Record.Please cross check with CUST_TAN_NO,SECTION,FYN_YEAR,EFFECTIVE_TO"
			 * ; }
			 */
			else {
				errorReason = "Duplicate Rows are present in File Record. Account Number is " + invalidCount;

			}
			log.info("Status in method readFromExcelfile--->>" + errorReason);
			log.info("Status in method readFromExcelfile--->>" + errorReason);
			status_code = DUPLICATE_ROWS;

			if ("SAL".equalsIgnoreCase(fileIde.toUpperCase()) || "REF_CISTM".equalsIgnoreCase(fileIde.toUpperCase())
					|| "REF_DISTM".equalsIgnoreCase(fileIde.toUpperCase())
					|| "REF_DTH".equalsIgnoreCase(fileIde.toUpperCase())
					|| "REF_TM".equalsIgnoreCase(fileIde.toUpperCase())
					|| "REF_TMP".equalsIgnoreCase(fileIde.toUpperCase())
					|| "WMF".equalsIgnoreCase(fileIde.toUpperCase()) || "WAI".equalsIgnoreCase(fileIde.toUpperCase())
					|| "BWM".equalsIgnoreCase(fileIde.toUpperCase()) || "BWI".equalsIgnoreCase(fileIde.toUpperCase())) {
				fileUploadDao.insertIntoPaymentAdviceStatusError(Integer.parseInt(file_Id), fileId.getFileIdentifier(),
						fileName, sum, Integer.parseInt(res.getCountRows()), validateFile, user, status_code,
						errorReason, 0, date, batch, list);

			}
		} else if ("0".equalsIgnoreCase(invalidCount) && status == true) {
			if (res.getTransactionNumberToUpdate() != null && res.getTransactionNumberToUpdate().size() > 0) {
				if (fileId.getFileIdentifier().equals("BNECS")) {
					fileUploadDao.updateTransactionNumberStatus(res.getTransactionNumberToUpdate(), "Approval Pending");
				}
				if (fileId.getFileIdentifier().equals("ISECS")) {
					fileUploadDao.updateTransactionNumberStatus(res.getTransactionNumberToUpdate(),
							"Bank File Upload Pending");
				}
			}
			if (res.getCountRows() == null || res.getCountRows() == "") {
				res.setCountRows("0");
			}
			errorReason = res.getCountRows() + " " + props.getProperty("recordSuccessInsertion") + " with File ID "
					+ Integer.parseInt(file_Id) + ".";
			log.info("Status in method readFromExcelfile--->>" + errorReason);
			log.info("Status in method readFromExcelfile--->>" + errorReason);

			status_code = STATUS_CODE_FOR_INSERT;
			if ("PAFILE".equalsIgnoreCase(fileIde.toUpperCase())) {
				fileUploadDao.insertIntoPaymentAdviceStatus(Integer.parseInt(file_Id), fileId.getFileIdentifier(),
						fileName, sum, Integer.parseInt(res.getCountRows()), validateFile, user, STATUS_CODE_FOR_INSERT,
						errorReason, 0, date, batch, list);

				// validating UTR status to be added in excel reader
				boolean cartFlag = false;
				int v_count = 0;
				List<String> IncValList = new ArrayList<String>();
				List<String> utrNolist = new ArrayList<String>();
				List<String> rbiAcctList = new ArrayList<String>();// incomingTransNoAndRefNumberMap

				utrNolist = (List<String>) obj[0];
				rbiAcctList = (List<String>) obj[1];
				IncValList = (List<String>) obj[2];

				log.info("step1  utrNolist->>" + utrNolist + " rbiAcctList-->>" + rbiAcctList + " IncValList>>"
						+ IncValList);

				Iterator itr = bankAccountNumberAndRefNumberMap.keySet().iterator();

				Set<String> cartUtrSet = new HashSet<String>();
				while (itr.hasNext()) {
					// System.out.println("map val-->>"+itr.next());
					cartUtrSet.add(String.valueOf(itr.next()).toUpperCase());

				}
				log.info(" step 2 utrSet->>" + utrSet + "cartFlag-->>" + cartFlag + " cartUtrSet->" + cartUtrSet
						+ " v_count->" + v_count);

				if (utrSet.size() != cartUtrSet.size()) {
					errorReason = "UTR's added in the Cart are not matching with UTR's in File.Please validate and upload again";
					status = false;
					status_code = FILE_FAILURE;
				}
				// adding inc values
				for (String incNo : IncValList) {
					// System.out.println("map val-->>"+itr.next());
					cartUtrSet.add(incNo);

				}

				if (!cartUtrSet.containsAll(utrSet)) {

					v_count = 1;
				}
				if (v_count == 0) {
					cartFlag = true;
				}

				log.info(" step 2 utrSet->>" + utrSet + "cartFlag-->>" + cartFlag + " cartUtrSet->" + cartUtrSet
						+ " v_count->" + v_count);

				if (!cartFlag) {
					errorReason = "UTR's added in the Cart are not matching with UTR's in File.Please validate and upload again";
					status = false;
					status_code = FILE_FAILURE;

					log.info("");
					String statusFromUpdate = fileUploadDao.updateAdviceFailure(file_Id, "PAFILE");

				}

				log.info("utrNolist->>" + utrNolist + " rbiAcctList-->>" + rbiAcctList + " IncValList>>" + IncValList);

				if (status) {
					String val = fileUploadDao.validateUTRStatus(utrNolist, rbiAcctList, file_Id, validateFile
					// new added
							, IncValList);
					// Commented by Ritu as failure case need not have to go for updateStatusCode
					// proc
					// insStatus="SUCCESS";
					log.info("utrSet Result->>" + val);
					String[] val1 = val.split(",");
					log.info("utrSet Result->>" + val1[0]);
					if ("FAILURE".equalsIgnoreCase(val1[0])) {
						errorReason = val1[1];
						status = false;
						status_code = FILE_FAILURE;

					} else {
						insStatus = "SUCCESS";
					}
				}
			} else if ("AESDP".equalsIgnoreCase(fileIde.toUpperCase())
					|| "AESADV".equalsIgnoreCase(fileIde.toUpperCase())
					|| "AESDUMMY".equalsIgnoreCase(fileIde.toUpperCase())
					|| "SAL".equalsIgnoreCase(fileIde.toUpperCase()) || "PTF".equalsIgnoreCase(fileIde.toUpperCase())
					|| "TDS".equalsIgnoreCase(fileIde.toUpperCase())
					|| "REF_DISTM".equalsIgnoreCase(fileIde.toUpperCase())
					|| "REF_CISTM".equalsIgnoreCase(fileIde.toUpperCase())
					|| "REF_DTH".equalsIgnoreCase(fileIde.toUpperCase())
					|| "REF_TM".equalsIgnoreCase(fileIde.toUpperCase())
					|| "REF_TMP".equalsIgnoreCase(fileIde.toUpperCase())
					|| "PAB".equalsIgnoreCase(fileIde.toUpperCase()) || "WAI".equalsIgnoreCase(fileIde.toUpperCase())
					|| "WMF".equalsIgnoreCase(fileIde.toUpperCase()) 
				    || "BWM".equalsIgnoreCase(fileIde.toUpperCase())
					|| "BWI".equalsIgnoreCase(fileIde.toUpperCase())) // Added PAB by Ritu on 13th Aug 2020
			{
				fileUploadDao.insertIntoPaymentAdviceStatus(Integer.parseInt(file_Id), fileId.getFileIdentifier(),
						fileName, sum, Integer.parseInt(res.getCountRows()), validateFile, user, STATUS_CODE_FOR_INSERT,
						errorReason, 0, date, batch, list);
				// validating UTR status need to be done for AESADV
				Set<String> cartUtrSet = null;
				if (!"AESADV".equalsIgnoreCase(fileIde.toUpperCase()))
					insStatus = "SUCCESS";
				if ("AESADV".equalsIgnoreCase(fileIde.toUpperCase())) {
					boolean cartFlag = false;
					Iterator itr = bankAccountNumberAndRefNumberMap.keySet().iterator();
					cartUtrSet = new HashSet<String>();
					String ref = null;
					while (itr.hasNext()) {
						ref = String.valueOf(bankAccountNumberAndRefNumberMap.get(itr.next())).toUpperCase();

						cartUtrSet.add(ref);

					}

					cartFlag = utrSet.equals(cartUtrSet);
					log.info("utrSet->>" + utrSet + "cartFlag-->>" + cartFlag + " cartUtrSet->" + cartUtrSet);
					if (utrSet.size() != cartUtrSet.size()) {
						errorReason = "UTR's added in the Cart are not matching with UTR's in File.Please validate and upload again";
						status = false;
						status_code = FILE_FAILURE;
					}
					if (!cartFlag) {
						errorReason = "UTR's added in the Cart are not matching with UTR's in File.Please validate and upload again";
						status = false;
						status_code = FILE_FAILURE;

						log.info("cartFlag value not matching in AESADV");
						String statusFromUpdate = fileUploadDao.updateAdviceFailure(file_Id, "AESADV");
					}
					if (status) {
						String val = fileUploadDao.validateAESadvUTRStatus(utrSet, file_Id, validateFile);
						// insStatus="SUCCESS";
						log.info("utrSet Result->>" + val);
						String[] val1 = val.split(",");
						log.info("utrSet Result->>" + val1[0]);
						if ("FAILURE".equalsIgnoreCase(val1[0])) {
							errorReason = val1[1];
							status = false;
							status_code = FILE_FAILURE;

						} else {
							insStatus = "SUCCESS";
						}

					}
				}
				if ("TDS".equalsIgnoreCase(fileIde.toUpperCase()) && batch.contains("NONDECLAREDTDS")) {
					boolean cartFlag = false;
					Iterator itr = bankAccountNumberAndRefNumberMap.keySet().iterator();
					cartUtrSet = new HashSet<String>();
					String ref = null;
					while (itr.hasNext()) {
						ref = String.valueOf(bankAccountNumberAndRefNumberMap.get(itr.next())).toUpperCase();

						cartUtrSet.add(ref);

					}

					cartFlag = utrSet.equals(cartUtrSet);
					log.info("utrSet->>" + utrSet + "cartFlag-->>" + cartFlag + " cartUtrSet->" + cartUtrSet);
					if (utrSet.size() != cartUtrSet.size()) {
						errorReason = "Data added in the Cart are not matching with CUST_TAN|FY in File.Please validate and upload again";
						status = false;
						status_code = FILE_FAILURE;
					}
					if (!cartFlag) {
						errorReason = "Data added in the Cart are not matching with CUST_TAN|FY in File.Please validate and upload again";
						status = false;
						status_code = FILE_FAILURE;
					}

					/*
					 * if(status){ String
					 * val=fileUploadDao.validateAESadvUTRStatus(utrSet,file_Id,validateFile);
					 * 
					 * log.info("utrSet Result->>"+val); String [] val1=val.split(",");
					 * log.info("utrSet Result->>"+val1[0]);
					 * if("FAILURE".equalsIgnoreCase(val1[0])){ errorReason=val1[1]; status=false;
					 * status_code = FILE_FAILURE;
					 * 
					 * } }
					 */
				}

				if (("WMF".equalsIgnoreCase(fileIde.toUpperCase())) || ("WAI".equalsIgnoreCase(fileIde.toUpperCase()))
						|| ("BWM".equalsIgnoreCase(fileIde.toUpperCase()))
						|| ("BWI".equalsIgnoreCase(fileIde.toUpperCase()))
				/*
				 * ("CMT".equalsIgnoreCase(fileIde.toUpperCase())) ||
				 * ("CIS".equalsIgnoreCase(fileIde.toUpperCase()))
				 */ ) {
					log.info("Waiver Updating Process Type");
					String processType = fileUploadDao.getProcessType(fileIde.toUpperCase(), pType);
					log.info("Waiver Process Type: " + processType + "SupportFile" + supportFile + "pType: " + pType);
					fileUploadDao.updateWaiverDetails(supportFile, file_Id, processType);
					log.info("Waiver Process Type Successfully inserted");
				}

			}

			else {
				/*
				 * fileUploadDao.insertIntoFileStatus(Integer.parseInt(file_Id),
				 * fileId.getFileIdentifier(), fileName, sum,
				 * Integer.parseInt(res.getCountRows()), source, user,STATUS_CODE_FOR_INSERT,
				 * errorReason, 0, date,batch,list);
				 */
				insStatus = fileUploadDao.insertIntoFileStatus(Integer.parseInt(file_Id), fileId.getFileIdentifier(),
						fileName, sum, Integer.parseInt(res.getCountRows()), source, user, STATUS_CODE_FOR_INSERT,
						errorReason, 0, date, batch, list);

				if (insStatus.equalsIgnoreCase("SUCCESS")) {
					status = true;
					log.info("error reason is in after inserting values into payment/file_status_aps table : "
							+ insStatus);
				} else {
					status = false;
					errorReason = insStatus;
					status_code = FILE_FAILURE;

					log.info("error reason is in after inserting values into payment/file_status_aps table : "
							+ insStatus);

				}

			}

			// if(status){
			if (insStatus.equalsIgnoreCase("SUCCESS")) {
				log.info("Calling updateStatusCode");
				String v_status = fileUploadDao.updateStatusCode(Integer.parseInt(file_Id), fileId.getTableName(), user,
						fileId.getFileIdentifier());

				if (v_status != null && list.contains(fileIde.toUpperCase())) {
					errorReason = v_status;
					// status=false;
					fileUploadDao.updateDetailsStatus(file_Id, errorReason);
				}
				if (v_status != null && "PAFILE".equalsIgnoreCase(fileIde.toUpperCase())) {
					errorReason = v_status;
					// status=false;

				}
				if (v_status != null && "PAB".equalsIgnoreCase(fileIde.toUpperCase())) {
					errorReason = v_status;
					// status=false;

				}

				if (v_status != null && "PNH".equalsIgnoreCase(fileIde.toUpperCase())
						|| v_status != null && "RNH".equalsIgnoreCase(fileIde.toUpperCase())) {
					errorReason = v_status;
					// status=false;
					fileUploadDao.updateDetailsStatus(file_Id, errorReason);

				}
				if (v_status != null && ("TDS".equalsIgnoreCase(fileIde.toUpperCase()))) {
					errorReason = v_status;
					// status=false;
					fileUploadDao.updateTDSAdviceFailure(file_Id, fileIde.toUpperCase(), errorReason);

				}
				if (v_status != null && ("CNR".equalsIgnoreCase(fileIde.toUpperCase())
					|| "DPP".equalsIgnoreCase(fileIde.toUpperCase())
					|| "RDP".equalsIgnoreCase(fileIde.toUpperCase())
					|| "DNR".equalsIgnoreCase(fileIde.toUpperCase())
					|| "ADJ".equalsIgnoreCase(fileIde.toUpperCase())
					|| "RDJ".equalsIgnoreCase(fileIde.toUpperCase())
					|| "SNR".equalsIgnoreCase(fileIde.toUpperCase())
					|| "SAL".equalsIgnoreCase(fileIde.toUpperCase())
						)) {
					errorReason = v_status;
				
				}
				if (v_status != null && (("WMF".equalsIgnoreCase(fileIde.toUpperCase()))
						|| ("WAI".equalsIgnoreCase(fileIde.toUpperCase()))
						|| ("WMT".equalsIgnoreCase(fileIde.toUpperCase()))
						|| ("WIS".equalsIgnoreCase(fileIde.toUpperCase()))
						|| ("CMT".equalsIgnoreCase(fileIde.toUpperCase()))
						|| ("CIS".equalsIgnoreCase(fileIde.toUpperCase()))
						|| ("BWM".equalsIgnoreCase(fileIde.toUpperCase()))
						|| ("BWI".equalsIgnoreCase(fileIde.toUpperCase())))) {
					errorReason = v_status;
					// status=false;
					// fileUploadDao.updateTDSAdviceFailure(file_Id, fileIde.toUpperCase(),
					// errorReason);

				}
				if (v_status != null && (("AESADV".equalsIgnoreCase(fileIde.toUpperCase()))
						|| ("AESDP".equalsIgnoreCase(fileIde.toUpperCase()))
						|| ("AESDUMMY".equalsIgnoreCase(fileIde.toUpperCase()))
						|| ("PTF".equalsIgnoreCase(fileIde.toUpperCase()))
						|| ("LTC".equalsIgnoreCase(fileIde.toUpperCase()))
						|| ("TAN".equalsIgnoreCase(fileIde.toUpperCase())))) {
					errorReason = v_status;

				}

			}

		}

		if (status == false) {

			if (res.getCountRows() != null) {
				tot_rows = Integer.parseInt(res.getCountRows());
			} else {
				tot_rows = 0;
			}
			status_code = FILE_FAILURE;
			if ((!"PAFILE".equalsIgnoreCase(fileId.getFileIdentifier()))
					&& (!"AESADV".equalsIgnoreCase(fileId.getFileIdentifier()))
					&& (!"AESDP".equalsIgnoreCase(fileId.getFileIdentifier()))
					&& (!"AESDUMMY".equalsIgnoreCase(fileId.getFileIdentifier()))
					&& (!"SAL".equalsIgnoreCase(fileId.getFileIdentifier()))
					&& (!"PTF".equalsIgnoreCase(fileId.getFileIdentifier()))
					&& (!"TDS".equalsIgnoreCase(fileId.getFileIdentifier()))
					&& (!"PAB".equalsIgnoreCase(fileId.getFileIdentifier()))
					&& (!"REF_DISTM".equalsIgnoreCase(fileId.getFileIdentifier()))
					&& (!"REF_CISTM".equalsIgnoreCase(fileId.getFileIdentifier()))
					&& (!"REF_DTH".equalsIgnoreCase(fileId.getFileIdentifier()))
					&& (!"REF_TM".equalsIgnoreCase(fileId.getFileIdentifier()))
					&& (!"REF_TMP".equalsIgnoreCase(fileId.getFileIdentifier()))
					&& (!"WMF".equalsIgnoreCase(fileIde.toUpperCase()))
					&& (!"WAI".equalsIgnoreCase(fileIde.toUpperCase()))
					&& (!"BWM".equalsIgnoreCase(fileIde.toUpperCase()))
					&& (!"BWI".equalsIgnoreCase(fileIde.toUpperCase()))
			/*
			 * && (!"PNH".equalsIgnoreCase(fileId.getFileIdentifier())) &&
			 * (!"RNH".equalsIgnoreCase(fileId.getFileIdentifier()))
			 */
			) {
				// Commented as duplicate insert is being called
				try {
					insStatus = fileUploadDao.insertIntoFileStatus(Integer.parseInt(file_Id),
							fileId.getFileIdentifier(), fileName, 0.0, tot_rows, source, user, status_code, errorReason,
							0, date, batch, list);
					if (insStatus.equalsIgnoreCase("SUCCESS")) {
						status = true;
						log.info("error reason is in after inserting values into payment/file_status_aps table : "
								+ insStatus);
					} else {
						status = false;
						errorReason = insStatus;
						status_code = FILE_FAILURE;

						log.info("error reason is in after inserting values into payment/file_status_aps table : "
								+ insStatus);

					}

					fileUploadDao.insertIntoErrorLog(Integer.parseInt(file_Id), fileName, errorReason, user);
				} catch (Exception e) {
					status = false;
					errorReason = "DATA FAILURE ISSUE";
					status_code = FILE_FAILURE;
					e.printStackTrace();
					log.info("exception accured  inserting values into payment/file_status_aps table : " + insStatus);
				}
			}

			if ("TDS".equalsIgnoreCase(fileIde.toUpperCase())
			/*
			 * || ("WMF".equalsIgnoreCase(fileIde.toUpperCase())) ||
			 * ("WAI".equalsIgnoreCase(fileIde.toUpperCase())) ||
			 * ("WMT".equalsIgnoreCase(fileIde.toUpperCase())) ||
			 * ("WIS".equalsIgnoreCase(fileIde.toUpperCase())) ||
			 * ("CMT".equalsIgnoreCase(fileIde.toUpperCase())) ||
			 * ("CIS".equalsIgnoreCase(fileIde.toUpperCase()))
			 */

			) {
				// status=false;
				/*
				 * fileUploadDao.insertIntoPaymentAdviceStatus(Integer.parseInt(file_Id),
				 * fileId.getFileIdentifier(), fileName, sum,
				 * Integer.parseInt(res.getCountRows()), validateFile,
				 * user,STATUS_CODE_FOR_INSERT, errorReason, 0, date,batch,list);
				 */
				fileUploadDao.updateTDSAdviceFailure(file_Id, fileIde.toUpperCase(), errorReason);
			}

		}
		log.info("error reason is in method readFromExcelfile : " + errorReason);
		log.info("Status in method readFromExcelfile--->>" + status_code);
		log.info("END :in method readFromExcelfile of ExcelReader ");
		fileUpload.setStatusDescription(errorReason);
		fileUpload.setStatus(status_code);
		return fileUpload;
	}

	public boolean validatingFileName(String fileName, String fileIdentifier) {

		log.info("start:::file name in file identifier->" + fileIdentifier);
		// Cheque file name validation
		boolean val = true;
		if ("CHEQUE".equalsIgnoreCase(fileIdentifier)) {

			log.info("Inside file identifier CHEQUE");
			if (fileName.length() >= 22) {

				String subString2 = fileName.substring(10, 12);// Date Check
				// fields
				String subString3 = fileName.substring(12, 14);// Date Check
				// fields

				boolean status1 = true;
				boolean status2 = true;
				boolean status = false;

				String circleString = fileName.substring(0, 3);

				boolean circleStatus = fileUploadDao.checkPaymentCircle(circleString);
				if (circleStatus) {
					status = true;
				}
				try {
					if (Integer.parseInt(subString2) > 12 || Integer.parseInt(subString2) < 1)
						status1 = false;
					if (Integer.parseInt(subString3) > 31 || Integer.parseInt(subString3) < 1)
						status2 = false;
				} catch (Exception e) {
					log.info("invalid file name" + fileName);
					// modelAndViewObj.addObject("error",
					// "File Name format - XXX_PMT_YYMMDD_CHQ_NNNN.xls.Please
					// Correct the Name and upload again!");
					val = false;
				}
				if (fileName.matches(
						"^[0-9]{3}[_][P][M][T][_][0-9]{2}[0-1][0-9][0-3][0-9][_][A-Za-z0-9]{3}[_][0-9]{4}[.][x][l][s][x]?")
						&& status1 && status2 && status) {
					log.info("Valid file name" + fileName);
					val = true;
				} else {
					log.info("invalid file name" + fileName);
					val = false;
				}
			} else {
				log.info("invalid file name" + fileName);
				val = false;

			}
		}
		if ("NEFT".equalsIgnoreCase(fileIdentifier)) {

			String circleString = fileName.substring(0, 3);
			boolean status = false;
			boolean circleStatus = fileUploadDao.checkPaymentCircle(circleString);
			if (circleStatus) {
				status = true;
			}
			if (fileName.length() >= 22) {
				// Added by APS Team
				String subString2 = fileName.substring(10, 12);
				String subString3 = fileName.substring(12, 14);
				boolean status1 = true;
				boolean status2 = true;
				try {
					if (Integer.parseInt(subString2) > 12 || Integer.parseInt(subString2) < 1)
						status1 = false;
					if (Integer.parseInt(subString3) > 31 || Integer.parseInt(subString3) < 1)
						status2 = false;
				} catch (Exception e) {
					// modelAndViewObj.addObject("error",
					// "File Name format - XXX_PMT_YYMMDD_EFT_NNNN.xls,Please
					// Correct the Name and upload again");
					val = false;
				}
				if (fileName.matches(
						"^[0-9]{3}[_][P][M][T][_][0-9]{2}[0-1][0-9][0-3][0-9][_][A-Za-z0-9]{3}[_][0-9]{4}[.][x][l][s][x]?")
						&& status1 && status2 && status) {
					System.out.println("valid file name");
					val = true;
				} else {
					val = false;
				}
			} else {
				val = false;
			}

		}
		if ("MISC".equalsIgnoreCase(fileIdentifier)) {

			String circleString = fileName.substring(0, 3);
			boolean status = false;
			boolean circleStatus = fileUploadDao.checkPaymentCircle(circleString);
			if (circleStatus) {
				status = true;
			}
			if (fileName.length() >= 22) {

				String subString2 = fileName.substring(10, 12);
				String subString3 = fileName.substring(12, 14);
				boolean status1 = true;
				boolean status2 = true;
				try {
					if (Integer.parseInt(subString2) > 12 || Integer.parseInt(subString2) < 1)
						status1 = false;
					if (Integer.parseInt(subString3) > 31 || Integer.parseInt(subString3) < 1)
						status2 = false;
				} catch (Exception e) {

					// modelAndViewObj.addObject("error",
					// "File Name format - XXX_PMT_YYMMDD_MIS_NNNN.xls,Please
					// Correct the Name and upload again");
					val = false;

				}
				if (fileName.matches(
						"^[0-9]{3}[_][P][M][T][_][0-9]{2}[0-1][0-9][0-3][0-9][_][A-Za-z0-9]{3}[_][0-9]{4}[.][x][l][s][x]?")
						&& status1 && status2 && status) {
					System.out.println("valid file name");
					val = true;
				} else {
					val = false;
				}
			} else {
				val = false;
			}
		}
		if ("REVERSAL".equalsIgnoreCase(fileIdentifier)) {

			String circleString = fileName.substring(0, 3);
			boolean status = false;
			boolean circleStatus = fileUploadDao.checkPaymentCircle(circleString);
			if (circleStatus) {
				status = true;
			}
			if (fileName.length() >= 22) {
				System.out.println("INSIDE ONE");

				String subString2 = fileName.substring(10, 12);
				String subString3 = fileName.substring(12, 14);
				boolean status1 = true;
				boolean status2 = true;
				try {
					if (Integer.parseInt(subString2) > 12 || Integer.parseInt(subString2) < 1)
						status1 = false;
					if (Integer.parseInt(subString3) > 31 || Integer.parseInt(subString3) < 1)
						status2 = false;
				} catch (Exception e) {
					// modelAndViewObj.addObject("error",
					// "File Name format - XXX_REV_YYMMDD_ABC_NNNN.xls,Please
					// Correct the Name and upload again");
					val = false;
				}
				if (fileName.matches(
						"^[0-9]{3}[_][R][E][V][_][0-9]{2}[0-1][0-9][0-3][0-9][_][A-Za-z0-9]{3}[_][0-9]{4}[.][x][l][s][x]?")
						&& status1 && status2 && status) {
					System.out.println("valid file name");
					val = true;
				} else {

					val = false;
				}
			} else {

				val = false;
			}

		}
		log.info("end:::Returning status in file name-->" + val);
		return val;

	}

	
	  public static void main(String[] args) throws Exception {
			
			  /*String fileName="ac|aa|"; String x[]=fileName.split("\\|"); String a="";
			  String b=""; String c=""; System.out.println(x.length);
			  //System.out.println(x); //System.out.println(x[0]); if(x.length>2) {
			  System.out.println("1 if"); a=x[0]; b=x[1]; c=x[2]; System.out.println(a);
			  System.out.println(b); System.out.println(c); }else {
			  System.out.println("1 else"); a=x[0]; b=x[1]; System.out.println(a);
			  System.out.println(b); System.out.println(c); }*/
			  
			  ExcelReader excel=new ExcelReader();
			  InputStream inputStream = null; 
			  String filename="C:\\Users\\Danyboy007\\Desktop\\IP_UPLOAD.xls";
			  File file = new File(filename);
			  inputStream = new FileInputStream(file);
			  
			  excel.readFromExcelfile(filename,"IP_UPLOAD", "UI", "XX","",inputStream,"Refup",null,null);
			  
			  
			 
	  
	  
	  }
	 


}
