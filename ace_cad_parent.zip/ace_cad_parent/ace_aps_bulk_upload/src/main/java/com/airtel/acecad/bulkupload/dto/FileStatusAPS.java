package com.airtel.acecad.bulkupload.dto;

public class FileStatusAPS {
String batch;
int noOfHits;
String statusDescription;
int srNumber;
int srTransactionNo;
String modifiedDate;
String isWorkListCompliant;
int pendingApprovalLevel;
String processDate;
String errorReason;
int status;
int validCount;
int invalidCount;
int totalRecords;
String sumOfAmount;
String filePath;
String firstLastName;
String fileIdentifier;
int fileId;
String circle;
String source;
String olmId;
String statusMessage;
String isExist;
String isExistCtrl;
String isExistError;
String isExistFX;


public String getIsExistFX() {
	return isExistFX;
}
public void setIsExistFX(String isExistFX) {
	this.isExistFX = isExistFX;
}
public String getFirstLastName() {
	return firstLastName;
}
public void setFirstLastName(String firstLastName) {
	this.firstLastName = firstLastName;
}
public String getCircle() {
	return circle;
}
public void setCircle(String circle) {
	this.circle = circle;
}
public String getIsExistError() {
	return isExistError;
}
public void setIsExistError(String isExistError) {
	this.isExistError = isExistError;
}
public String getIsExistCtrl() {
	return isExistCtrl;
}
public void setIsExistCtrl(String isExistCtrl) {
	this.isExistCtrl = isExistCtrl;
}
public String getIsExist() {
	return isExist;
}
public void setIsExist(String isExist) {
	this.isExist = isExist;
}
public String getStatusMessage() {
	return statusMessage;
}
public void setStatusMessage(String statusMessage) {
	this.statusMessage = statusMessage;
}

public String getOlmId() {
	return olmId;
}
public void setOlmId(String olmId) {
	this.olmId = olmId;
}
public String getSource() {
	return source;
}
public void setSource(String source) {
	this.source = source;
}
public String getBatch() {
	return batch;
}
public void setBatch(String batch) {
	this.batch = batch;
}
public int getNoOfHits() {
	return noOfHits;
}
public void setNoOfHits(int noOfHits) {
	this.noOfHits = noOfHits;
}
public String getStatusDescription() {
	return statusDescription;
}
public void setStatusDescription(String statusDescription) {
	this.statusDescription = statusDescription;
}
public int getSrNumber() {
	return srNumber;
}
public void setSrNumber(int srNumber) {
	this.srNumber = srNumber;
}
public int getSrTransactionNo() {
	return srTransactionNo;
}
public void setSrTransactionNo(int srTransactionNo) {
	this.srTransactionNo = srTransactionNo;
}
public String getModifiedDate() {
	return modifiedDate;
}
public void setModifiedDate(String modifiedDate) {
	this.modifiedDate = modifiedDate;
}
public String getIsWorkListCompliant() {
	return isWorkListCompliant;
}
public void setIsWorkListCompliant(String isWorkListCompliant) {
	this.isWorkListCompliant = isWorkListCompliant;
}
public int getPendingApprovalLevel() {
	return pendingApprovalLevel;
}
public void setPendingApprovalLevel(int pendingApprovalLevel) {
	this.pendingApprovalLevel = pendingApprovalLevel;
}
public String getProcessDate() {
	return processDate;
}
public void setProcessDate(String processDate) {
	this.processDate = processDate;
}
public String getErrorReason() {
	return errorReason;
}
public void setErrorReason(String errorReason) {
	this.errorReason = errorReason;
}
public int getStatus() {
	return status;
}
public void setStatus(int status) {
	this.status = status;
}
public int getValidCount() {
	return validCount;
}
public void setValidCount(int validCount) {
	this.validCount = validCount;
}
public int getInvalidCount() {
	return invalidCount;
}
public void setInvalidCount(int invalidCount) {
	this.invalidCount = invalidCount;
}
public int getTotalRecords() {
	return totalRecords;
}
public void setTotalRecords(int totalRecords) {
	this.totalRecords = totalRecords;
}


public String getSumOfAmount() {
	return sumOfAmount;
}
public void setSumOfAmount(String sumOfAmount) {
	this.sumOfAmount = sumOfAmount;
}
public String getFilePath() {
	return filePath;
}
public void setFilePath(String filePath) {
	this.filePath = filePath;
}
public String getFileIdentifier() {
	return fileIdentifier;
}
public void setFileIdentifier(String fileIdentifier) {
	this.fileIdentifier = fileIdentifier;
}
public int getFileId() {
	return fileId;
}
public void setFileId(int fileId) {
	this.fileId = fileId;
}


}
