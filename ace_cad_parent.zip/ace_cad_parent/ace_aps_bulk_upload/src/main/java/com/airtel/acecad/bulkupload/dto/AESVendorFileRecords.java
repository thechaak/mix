package com.airtel.acecad.bulkupload.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AESVendorFileRecords {
 String receiverName;
 int buCode;
 String accountNo;
 String bankCurrency;
 Date dummyDate;
 String remitterName;
 String depositSlipNo;
 String bankRefNo;
 String otherRefNo;
 Double debitAmount;
 Double creditAmount;
 String paymentMode;
 String uniCode;
 Date segregationDate;
 String childAcctExtId;
 String annotation;
 String chequeNo;
 String glCode;
 String bankName;
 int circle;
 String lob;
 Double amount;
 
 //Variable used to be displayed on screen
 int totalResults; 
 int resultPerPage;
 int totalPages;
 String errorMsg;
 int currentPage;
 String searchUserId;
 String searchFileId;
 String searchFromDate;
 String searchEndDate;
 String postingStatusDesc;
 String postingTrackingId;
 String postingTrackingIdServ;
 String reversalTrackingId;
 String reversalTrackingIdServ;
 String reversalStatusDesc;
 //Variable to be displayed on Screen
 
 String file_id;
 String transaction_id;
 String file_name;
 int total_records;
 String file_upload_date;
 String uploadedUserName;
 String derived_lob;

 
 List<AESVendorFileRecords> aesBulkStatementDetailList = new ArrayList<AESVendorFileRecords>();
 
public String getReceiverName() {
	return receiverName;
}
public void setReceiverName(String receiverName) {
	this.receiverName = receiverName;
}
public int getBuCode() {
	return buCode;
}
public void setBuCode(int buCode) {
	this.buCode = buCode;
}
public String getAccountNo() {
	return accountNo;
}
public void setAccountNo(String accountNo) {
	this.accountNo = accountNo;
}
public String getBankCurrency() {
	return bankCurrency;
}
public void setBankCurrency(String bankCurrency) {
	this.bankCurrency = bankCurrency;
}
public Date getDummyDate() {
	return dummyDate;
}
public void setDummyDate(Date dummyDate) {
	this.dummyDate = dummyDate;
}
public String getRemitterName() {
	return remitterName;
}
public void setRemitterName(String remitterName) {
	this.remitterName = remitterName;
}
public String getDepositSlipNo() {
	return depositSlipNo;
}
public void setDepositSlipNo(String depositSlipNo) {
	this.depositSlipNo = depositSlipNo;
}
public String getBankRefNo() {
	return bankRefNo;
}
public void setBankRefNo(String bankRefNo) {
	this.bankRefNo = bankRefNo;
}
public String getOtherRefNo() {
	return otherRefNo;
}
public void setOtherRefNo(String otherRefNo) {
	this.otherRefNo = otherRefNo;
}
public Double getDebitAmount() {
	return debitAmount;
}
public void setDebitAmount(Double debitAmount) {
	this.debitAmount = debitAmount;
}
public Double getCreditAmount() {
	return creditAmount;
}
public void setCreditAmount(Double creditAmount) {
	this.creditAmount = creditAmount;
}
public String getPaymentMode() {
	return paymentMode;
}
public void setPaymentMode(String paymentMode) {
	this.paymentMode = paymentMode;
}
public String getUniCode() {
	return uniCode;
}
public void setUniCode(String uniCode) {
	this.uniCode = uniCode;
}
public Date getSegregationDate() {
	return segregationDate;
}
public void setSegregationDate(Date segregationDate) {
	this.segregationDate = segregationDate;
}
public String getChildAcctExtId() {
	return childAcctExtId;
}
public void setChildAcctExtId(String childAcctExtId) {
	this.childAcctExtId = childAcctExtId;
}
public String getAnnotation() {
	return annotation;
}
public void setAnnotation(String annotation) {
	this.annotation = annotation;
}
public String getChequeNo() {
	return chequeNo;
}
public void setChequeNo(String chequeNo) {
	this.chequeNo = chequeNo;
}
public String getGlCode() {
	return glCode;
}
public void setGlCode(String glCode) {
	this.glCode = glCode;
}
public String getBankName() {
	return bankName;
}
public void setBankName(String bankName) {
	this.bankName = bankName;
}
public int getCircle() {
	return circle;
}
public void setCircle(int circle) {
	this.circle = circle;
}
public String getLob() {
	return lob;
}
public void setLob(String lob) {
	this.lob = lob;
}
public Double getAmount() {
	return amount;
}
public void setAmount(Double amount) {
	this.amount = amount;
}
public int getTotalResults() {
	return totalResults;
}
public void setTotalResults(int totalResults) {
	this.totalResults = totalResults;
}
public int getResultPerPage() {
	return resultPerPage;
}
public void setResultPerPage(int resultPerPage) {
	this.resultPerPage = resultPerPage;
}
public int getTotalPages() {
	return totalPages;
}
public void setTotalPages(int totalPages) {
	this.totalPages = totalPages;
}
public String getErrorMsg() {
	return errorMsg;
}
public void setErrorMsg(String errorMsg) {
	this.errorMsg = errorMsg;
}
public int getCurrentPage() {
	return currentPage;
}
public void setCurrentPage(int currentPage) {
	this.currentPage = currentPage;
}
public List<AESVendorFileRecords> getAesBulkStatementDetailList() {
	return aesBulkStatementDetailList;
}
public void setAesBulkStatementDetailList(List<AESVendorFileRecords> aesBulkStatementDetailList) {
	this.aesBulkStatementDetailList = aesBulkStatementDetailList;
}
public String getSearchUserId() {
	return searchUserId;
}
public void setSearchUserId(String searchUserId) {
	this.searchUserId = searchUserId;
}
public String getSearchFileId() {
	return searchFileId;
}
public void setSearchFileId(String searchFileId) {
	this.searchFileId = searchFileId;
}
public String getSearchFromDate() {
	return searchFromDate;
}
public void setSearchFromDate(String searchFromDate) {
	this.searchFromDate = searchFromDate;
}
public String getSearchEndDate() {
	return searchEndDate;
}
public void setSearchEndDate(String searchEndDate) {
	this.searchEndDate = searchEndDate;
}
public String getPostingStatusDesc() {
	return postingStatusDesc;
}
public void setPostingStatusDesc(String postingStatusDesc) {
	this.postingStatusDesc = postingStatusDesc;
}
public String getPostingTrackingId() {
	return postingTrackingId;
}
public void setPostingTrackingId(String postingTrackingId) {
	this.postingTrackingId = postingTrackingId;
}
public String getPostingTrackingIdServ() {
	return postingTrackingIdServ;
}
public void setPostingTrackingIdServ(String postingTrackingIdServ) {
	this.postingTrackingIdServ = postingTrackingIdServ;
}
public String getReversalTrackingId() {
	return reversalTrackingId;
}
public void setReversalTrackingId(String reversalTrackingId) {
	this.reversalTrackingId = reversalTrackingId;
}
public String getReversalTrackingIdServ() {
	return reversalTrackingIdServ;
}
public void setReversalTrackingIdServ(String reversalTrackingIdServ) {
	this.reversalTrackingIdServ = reversalTrackingIdServ;
}
public String getFile_id() {
	return file_id;
}
public void setFile_id(String file_id) {
	this.file_id = file_id;
}
public String getTransaction_id() {
	return transaction_id;
}
public void setTransaction_id(String transaction_id) {
	this.transaction_id = transaction_id;
}
public String getFile_name() {
	return file_name;
}
public void setFile_name(String file_name) {
	this.file_name = file_name;
}
public int getTotal_records() {
	return total_records;
}
public void setTotal_records(int total_records) {
	this.total_records = total_records;
}
public String getFile_upload_date() {
	return file_upload_date;
}
public void setFile_upload_date(String file_upload_date) {
	this.file_upload_date = file_upload_date;
}
public String getUploadedUserName() {
	return uploadedUserName;
}
public void setUploadedUserName(String uploadedUserName) {
	this.uploadedUserName = uploadedUserName;
}
public String getDerived_lob() {
	return derived_lob;
}
public void setDerived_lob(String derived_lob) {
	this.derived_lob = derived_lob;
}
public String getReversalStatusDesc() {
	return reversalStatusDesc;
}
public void setReversalStatusDesc(String reversalStatusDesc) {
	this.reversalStatusDesc = reversalStatusDesc;
}
 }
