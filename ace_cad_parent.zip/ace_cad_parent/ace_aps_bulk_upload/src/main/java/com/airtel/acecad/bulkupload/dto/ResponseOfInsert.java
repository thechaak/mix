package com.airtel.acecad.bulkupload.dto;

import java.util.HashMap;
import java.util.List;

public class ResponseOfInsert {

	String errorReason;
	String countRows;
	HashMap<String,List<String>> transactionNumberToUpdate;
	public String getErrorReason() {
		return errorReason;
	}
	public void setErrorReason(String errorReason) {
		this.errorReason = errorReason;
	}
	public String getCountRows() {
		return countRows;
	}
	public void setCountRows(String countRows) {
		this.countRows = countRows;
	}
	public HashMap<String, List<String>> getTransactionNumberToUpdate() {
		return transactionNumberToUpdate;
	}
	public void setTransactionNumberToUpdate(HashMap<String, List<String>> transactionNumberToUpdate) {
		this.transactionNumberToUpdate = transactionNumberToUpdate;
	}
	
	
}
