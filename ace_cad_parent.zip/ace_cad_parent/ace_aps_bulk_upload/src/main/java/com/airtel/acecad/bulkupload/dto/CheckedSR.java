package com.airtel.acecad.bulkupload.dto;

import java.util.List;

public class CheckedSR {
	
}
