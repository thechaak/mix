package com.airtel.acecad.bulkupload.dto;

public class CAFCorrection {
	private String cafNumber1;
	private String cafNumber2;
	public String getCafNumber1() {
		return cafNumber1;
	}
	public void setCafNumber1(String cafNumber1) {
		this.cafNumber1 = cafNumber1;
	}
	public String getCafNumber2() {
		return cafNumber2;
	}
	public void setCafNumber2(String cafNumber2) {
		this.cafNumber2 = cafNumber2;
	}
}
