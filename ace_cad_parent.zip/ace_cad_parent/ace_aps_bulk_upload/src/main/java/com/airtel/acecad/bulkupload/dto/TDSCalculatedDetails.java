package com.airtel.acecad.bulkupload.dto;

import java.util.Date;

public class TDSCalculatedDetails {
	
	String lob;
	//String circle;
	//String customerName;
	String accountNumber;
	String invoiceNumber;
	//Date invoiceDate;
   //Double invoiceAmt;
   Double tdsAmt;
	Double tdsPercentage;
	//Double tdsAmountDeducted;
	String customerTanNo;
	//String customerPanNo;
	String tdsCertificateNo;
	String financialYear;
	String quarter;
	//String collectionManagerName;
	String section;
	String remarks;
	String legalEntity;
	
	public String getLegalEntity() {
		return legalEntity;
	}
	public void setLegalEntity(String legalEntity) {
		this.legalEntity = legalEntity;
	}
	public Double getTdsAmt() {
		return tdsAmt;
	}
	public void setTdsAmt(Double tdsAmt) {
		this.tdsAmt = tdsAmt;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	/*public Date getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}*/
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	/*public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}*/
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	/*public Double getInvoiceAmt() {
		return invoiceAmt;
	}
	public void setInvoiceAmt(Double invoiceAmt) {
		this.invoiceAmt = invoiceAmt;
	}*/
	public Double getTdsPercentage() {
		return tdsPercentage;
	}
	public void setTdsPercentage(Double tdsPercentage) {
		this.tdsPercentage = tdsPercentage;
	}
	/*public Double getTdsAmountDeducted() {
		return tdsAmountDeducted;
	}
	public void setTdsAmountDeducted(Double tdsAmountDeducted) {
		this.tdsAmountDeducted = tdsAmountDeducted;
	}*/
	public String getCustomerTanNo() {
		return customerTanNo;
	}
	public void setCustomerTanNo(String customerTanNo) {
		this.customerTanNo = customerTanNo;
	}
	/*public String getCustomerPanNo() {
		return customerPanNo;
	}
	public void setCustomerPanNo(String customerPanNo) {
		this.customerPanNo = customerPanNo;
	}*/
	public String getTdsCertificateNo() {
		return tdsCertificateNo;
	}
	public void setTdsCertificateNo(String tdsCertificateNo) {
		this.tdsCertificateNo = tdsCertificateNo;
	}
	public String getFinancialYear() {
		return financialYear;
	}
	public void setFinancialYear(String financialYear) {
		this.financialYear = financialYear;
	}
	public String getQuarter() {
		return quarter;
	}
	public void setQuarter(String quarter) {
		this.quarter = quarter;
	}
	/*public String getCollectionManagerName() {
		return collectionManagerName;
	}
	public void setCollectionManagerName(String collectionManagerName) {
		this.collectionManagerName = collectionManagerName;
	}
*/
}
