package com.airtel.acecad.bulkupload.dto;

import java.util.Date;

public class IFSCMode {
String circle;
	public String getCircle() {
	return circle;
}
public void setCircle(String circle) {
	this.circle = circle;
}
	String srNumber;
	String accountNo;
	String lob;
	String subType;
	String customerName;
	int alternateNumber;
	String emailId;
	String billingAddress;
	String payeeState;
	int payeeZipCode;
	double refundAmount;
	String parentSrNumber;
	String oldChequeNo;
	Date oldChequeDate;
	String reSrMode;
	String paymentStatus;
	String reasonForStopPayment;
	String finalMode;
	String ifscCode;
	String bankAccountNumber;
	String rejectionReason;
	String comments;
	String addressChange;
	String correctedAddress;
	String correctedState;
	String correctedPincode;
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getAlternateNumber() {
		return alternateNumber;
	}
	public void setAlternateNumber(int alternateNumber) {
		this.alternateNumber = alternateNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getBillingAddress() {
		return billingAddress;
	}
	public void setBillingAddress(String billingAddress) {
		this.billingAddress = billingAddress;
	}
	public String getPayeeState() {
		return payeeState;
	}
	public void setPayeeState(String payeeState) {
		this.payeeState = payeeState;
	}
	public int getPayeeZipCode() {
		return payeeZipCode;
	}
	public void setPayeeZipCode(int payeeZipCode) {
		this.payeeZipCode = payeeZipCode;
	}
	public double getRefundAmount() {
		return refundAmount;
	}
	public void setRefundAmount(double refundAmount) {
		this.refundAmount = refundAmount;
	}
	public String getParentSrNumber() {
		return parentSrNumber;
	}
	public void setParentSrNumber(String parentSrNumber) {
		this.parentSrNumber = parentSrNumber;
	}
	public String getOldChequeNo() {
		return oldChequeNo;
	}
	public void setOldChequeNo(String oldChequeNo) {
		this.oldChequeNo = oldChequeNo;
	}
	public Date getOldChequeDate() {
		return oldChequeDate;
	}
	public void setOldChequeDate(Date oldChequeDate) {
		this.oldChequeDate = oldChequeDate;
	}
	public String getReSrMode() {
		return reSrMode;
	}
	public void setReSrMode(String reSrMode) {
		this.reSrMode = reSrMode;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public String getReasonForStopPayment() {
		return reasonForStopPayment;
	}
	public void setReasonForStopPayment(String reasonForStopPayment) {
		this.reasonForStopPayment = reasonForStopPayment;
	}
	public String getFinalMode() {
		return finalMode;
	}
	public void setFinalMode(String finalMode) {
		this.finalMode = finalMode;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getBankAccountNumber() {
		return bankAccountNumber;
	}
	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}
	public String getRejectionReason() {
		return rejectionReason;
	}
	public void setRejectionReason(String rejectionReason) {
		this.rejectionReason = rejectionReason;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getAddressChange() {
		return addressChange;
	}
	public void setAddressChange(String addressChange) {
		this.addressChange = addressChange;
	}
	public String getCorrectedAddress() {
		return correctedAddress;
	}
	public void setCorrectedAddress(String correctedAddress) {
		this.correctedAddress = correctedAddress;
	}
	public String getCorrectedState() {
		return correctedState;
	}
	public void setCorrectedState(String correctedState) {
		this.correctedState = correctedState;
	}
	public String getCorrectedPincode() {
		return correctedPincode;
	}
	public void setCorrectedPincode(String correctedPincode) {
		this.correctedPincode = correctedPincode;
	}

}
