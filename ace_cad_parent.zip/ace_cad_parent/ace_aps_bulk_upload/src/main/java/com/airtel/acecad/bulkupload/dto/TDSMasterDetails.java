package com.airtel.acecad.bulkupload.dto;

public class TDSMasterDetails {

	String customerTanNo;
	String quarter;
	String financialYear;
	Double totalAmt;
	Double totalAmountConsumed;
	String customerName;
	String legalEntity;
	String airtelTanNo;
	public String getCustomerTanNo() {
		return customerTanNo;
	}
	public void setCustomerTanNo(String customerTanNo) {
		this.customerTanNo = customerTanNo;
	}
	public String getQuarter() {
		return quarter;
	}
	public void setQuarter(String quarter) {
		this.quarter = quarter;
	}
	public String getFinancialYear() {
		return financialYear;
	}
	public void setFinancialYear(String financialYear) {
		this.financialYear = financialYear;
	}
	public Double getTotalAmt() {
		return totalAmt;
	}
	public void setTotalAmt(Double totalAmt) {
		this.totalAmt = totalAmt;
	}
	public Double getTotalAmountConsumed() {
		return totalAmountConsumed;
	}
	public void setTotalAmountConsumed(Double totalAmountConsumed) {
		this.totalAmountConsumed = totalAmountConsumed;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public String getLegalEntity() {
		return legalEntity;
	}
	public void setLegalEntity(String legalEntity) {
		this.legalEntity = legalEntity;
	}
	public String getAirtelTanNo() {
		return airtelTanNo;
	}
	public void setAirtelTanNo(String airtelTanNo) {
		this.airtelTanNo = airtelTanNo;
	}
}
