package com.airtel.acecad.bulkupload.dto;

import java.sql.Timestamp;
import java.util.Date;

public class PaymentTransferDTO {

	int fileId;
	String transferType;
	Date transDate;
	String paymentMode;
	String lob;
	String accountNo;
	String invoiceNo;
	Double amount;
	String chequeNo;
	String origTrackingId;
	String origTrackinIdServ;
	String collectionManagerName;
	String ticketNo;
	String annotation;
	Timestamp createdDate;
	Timestamp modifiedDate;
	String trackingId;
	String trackingIdServ;
	String statusCode;
	String statusDescription;
	String sentFxFlag;
	String noOfHit;
	String userId;
	String utrNo;
	String billRefNo;
	int billRefResets;
	String paymentPostDate;
	
	
	public String getUtrNo() {
		return utrNo;
	}
	public void setUtrNo(String utrNo) {
		this.utrNo = utrNo;
	}
	public String getBillRefNo() {
		return billRefNo;
	}
	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}
	public int getBillRefResets() {
		return billRefResets;
	}
	public void setBillRefResets(int billRefResets) {
		this.billRefResets = billRefResets;
	}
	public int getFileId() {
		return fileId;
	}
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}
	
	public Date getTransDate() {
		return transDate;
	}
	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getChequeNo() {
		return chequeNo;
	}
	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}
	public String getOrigTrackingId() {
		return origTrackingId;
	}
	public void setOrigTrackingId(String origTrackingId) {
		this.origTrackingId = origTrackingId;
	}
	public String getOrigTrackinIdServ() {
		return origTrackinIdServ;
	}
	public void setOrigTrackinIdServ(String origTrackinIdServ) {
		this.origTrackinIdServ = origTrackinIdServ;
	}
	public String getCollectionManagerName() {
		return collectionManagerName;
	}
	public void setCollectionManagerName(String collectionManagerName) {
		this.collectionManagerName = collectionManagerName;
	}
	public String getTicketNo() {
		return ticketNo;
	}
	public void setTicketNo(String ticketNo) {
		this.ticketNo = ticketNo;
	}
	public String getAnnotation() {
		return annotation;
	}
	public void setAnnotation(String annotation) {
		this.annotation = annotation;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	public String getTrackingIdServ() {
		return trackingIdServ;
	}
	public void setTrackingIdServ(String trackingIdServ) {
		this.trackingIdServ = trackingIdServ;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	public String getSentFxFlag() {
		return sentFxFlag;
	}
	public void setSentFxFlag(String sentFxFlag) {
		this.sentFxFlag = sentFxFlag;
	}
	public String getNoOfHit() {
		return noOfHit;
	}
	public void setNoOfHit(String noOfHit) {
		this.noOfHit = noOfHit;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getTransferType() {
		return transferType;
	}
	public void setTransferType(String transferType) {
		this.transferType = transferType;
	}
	public String getPaymentPostDate() {
		return paymentPostDate;
	}
	public void setPaymentPostDate(String paymentPostDate) {
		this.paymentPostDate = paymentPostDate;
	}
	
	
	
}
