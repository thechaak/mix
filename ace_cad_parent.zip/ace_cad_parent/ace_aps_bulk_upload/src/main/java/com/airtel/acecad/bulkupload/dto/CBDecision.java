package com.airtel.acecad.bulkupload.dto;

import java.util.Date;

public class CBDecision {
	
	String	srNumber;
	String	accountNo;
	String	lob;
	String	circle;
	Double	refundAmount;
	String	customerName;
	String	oldSrNo;
	String	chequeUtrNo;
	Date	chequeUtrDate;
	String	cbPaymentStatus;
	String	comments;
	String reasonPaid;
	public String getReasonPaid() {
		return reasonPaid;
	}
	public void setReasonPaid(String reasonPaid) {
		this.reasonPaid = reasonPaid;
	}
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public Double getRefundAmount() {
		return refundAmount;
	}
	public void setRefundAmount(Double refundAmount) {
		this.refundAmount = refundAmount;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getOldSrNo() {
		return oldSrNo;
	}
	public void setOldSrNo(String oldSrNo) {
		this.oldSrNo = oldSrNo;
	}
	public String getChequeUtrNo() {
		return chequeUtrNo;
	}
	public void setChequeUtrNo(String chequeUtrNo) {
		this.chequeUtrNo = chequeUtrNo;
	}
	public Date getChequeUtrDate() {
		return chequeUtrDate;
	}
	public void setChequeUtrDate(Date chequeUtrDate) {
		this.chequeUtrDate = chequeUtrDate;
	}
	public String getCbPaymentStatus() {
		return cbPaymentStatus;
	}
	public void setCbPaymentStatus(String cbPaymentStatus) {
		this.cbPaymentStatus = cbPaymentStatus;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}



}
