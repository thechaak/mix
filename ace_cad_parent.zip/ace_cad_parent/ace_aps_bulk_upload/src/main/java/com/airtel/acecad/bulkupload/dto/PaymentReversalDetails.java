package com.airtel.acecad.bulkupload.dto;

import java.sql.Timestamp;
import java.util.Date;

public class PaymentReversalDetails {

	int fileId;
	String accountNo;
	String origTrackingId;
	String origTrackinIdServ;
	String paymentCode;
	Date reversalDate;
	String annotation;
	String srNumber;
	Timestamp createdDate;
	Timestamp modifiedDate;
	String trackingId;
	String trackinIdServ;
	String statusCode;
	String statusDescription;
	String sentFxFlag;
	String noOfHit;
	String userId;
	public int getFileId() {
		return fileId;
	}
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getOrigTrackingId() {
		return origTrackingId;
	}
	public void setOrigTrackingId(String origTrackingId) {
		this.origTrackingId = origTrackingId;
	}
	public String getOrigTrackinIdServ() {
		return origTrackinIdServ;
	}
	public void setOrigTrackinIdServ(String origTrackinIdServ) {
		this.origTrackinIdServ = origTrackinIdServ;
	}
	public String getPaymentCode() {
		return paymentCode;
	}
	public void setPaymentCode(String paymentCode) {
		this.paymentCode = paymentCode;
	}
	public Date getReversalDate() {
		return reversalDate;
	}
	public void setReversalDate(Date reversalDate) {
		this.reversalDate = reversalDate;
	}
	public String getAnnotation() {
		return annotation;
	}
	public void setAnnotation(String annotation) {
		this.annotation = annotation;
	}
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	public String getTrackinIdServ() {
		return trackinIdServ;
	}
	public void setTrackinIdServ(String trackinIdServ) {
		this.trackinIdServ = trackinIdServ;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	public String getSentFxFlag() {
		return sentFxFlag;
	}
	public void setSentFxFlag(String sentFxFlag) {
		this.sentFxFlag = sentFxFlag;
	}
	public String getNoOfHit() {
		return noOfHit;
	}
	public void setNoOfHit(String noOfHit) {
		this.noOfHit = noOfHit;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
}
