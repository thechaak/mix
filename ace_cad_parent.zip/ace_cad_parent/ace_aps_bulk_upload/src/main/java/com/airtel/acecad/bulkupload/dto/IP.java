package com.airtel.acecad.bulkupload.dto;

import java.util.Date;

public class IP {
	String srNumber;
	String accountNo;
	String lob;
	String srSubType;
	String modeOfRefund;
	String circle;
	Double refundAmount;
	String customerName;
	String jvNumber;
	String caseIdNumber;
	String comments;
	String srMode;
	String paymentStatus;
	String oldSrNo;
	String chequeUtrNo;
	Date chequeUtrDate;
	
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getSrSubType() {
		return srSubType;
	}
	public void setSrSubType(String srSubType) {
		this.srSubType = srSubType;
	}
	public String getModeOfRefund() {
		return modeOfRefund;
	}
	public void setModeOfRefund(String modeOfRefund) {
		this.modeOfRefund = modeOfRefund;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public Double getRefundAmount() {
		return refundAmount;
	}
	public void setRefundAmount(Double refundAmount) {
		this.refundAmount = refundAmount;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getJvNumber() {
		return jvNumber;
	}
	public void setJvNumber(String jvNumber) {
		this.jvNumber = jvNumber;
	}
	public String getCaseIdNumber() {
		return caseIdNumber;
	}
	public void setCaseIdNumber(String caseIdNumber) {
		this.caseIdNumber = caseIdNumber;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getSrMode() {
		return srMode;
	}
	public void setSrMode(String srMode) {
		this.srMode = srMode;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public String getOldSrNo() {
		return oldSrNo;
	}
	public void setOldSrNo(String oldSrNo) {
		this.oldSrNo = oldSrNo;
	}
	public String getChequeUtrNo() {
		return chequeUtrNo;
	}
	public void setChequeUtrNo(String chequeUtrNo) {
		this.chequeUtrNo = chequeUtrNo;
	}
	public Date getChequeUtrDate() {
		return chequeUtrDate;
	}
	public void setChequeUtrDate(Date chequeUtrDate) {
		this.chequeUtrDate = chequeUtrDate;
	}

}
