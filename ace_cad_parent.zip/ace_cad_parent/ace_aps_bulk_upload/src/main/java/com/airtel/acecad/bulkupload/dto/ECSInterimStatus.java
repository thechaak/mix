package com.airtel.acecad.bulkupload.dto;

import java.util.Date;

public class ECSInterimStatus {
	String srNumber;
	String srTransactionNumber;
	String fileId;
	String errorDescription;
	String statusCode;
	
	
	String slNo; 
	String dateOfReceipt;
	String location;
	String mktCode;
	String circle;
	String accountNumber;
	String msisdn;
	String customerName;
	String bankName;
	String micr;
	String bankAccountNumber;
	String accountHolderName;
	String accountType;
	String formInvalidStatus;
	String reasonInvalid;
	String sscAccountId;
	String status;
	String airtelName;
	String clientValidInvalidStatus;
	String clientReason;
	String mode;
	String urmnNumber;
	String regStatus;
	String reasonNotReg;
	Date activationDate;
	String fileNumber;
	double amount;
	String circleCode;
	Date npciUploadDate;
	String subClient;
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getSrTransactionNumber() {
		return srTransactionNumber;
	}
	public void setSrTransactionNumber(String srTransactionNumber) {
		this.srTransactionNumber = srTransactionNumber;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getErrorDescription() {
		return errorDescription;
	}
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getSlNo() {
		return slNo;
	}
	public void setSlNo(String slNo) {
		this.slNo = slNo;
	}
	public String getDateOfReceipt() {
		return dateOfReceipt;
	}
	public void setDateOfReceipt(String dateOfReceipt) {
		this.dateOfReceipt = dateOfReceipt;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getMktCode() {
		return mktCode;
	}
	public void setMktCode(String mktCode) {
		this.mktCode = mktCode;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getMicr() {
		return micr;
	}
	public void setMicr(String micr) {
		this.micr = micr;
	}
	public String getBankAccountNumber() {
		return bankAccountNumber;
	}
	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getFormInvalidStatus() {
		return formInvalidStatus;
	}
	public void setFormInvalidStatus(String formInvalidStatus) {
		this.formInvalidStatus = formInvalidStatus;
	}
	public String getReasonInvalid() {
		return reasonInvalid;
	}
	public void setReasonInvalid(String reasonInvalid) {
		this.reasonInvalid = reasonInvalid;
	}
	public String getSscAccountId() {
		return sscAccountId;
	}
	public void setSscAccountId(String sscAccountId) {
		this.sscAccountId = sscAccountId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getAirtelName() {
		return airtelName;
	}
	public void setAirtelName(String airtelName) {
		this.airtelName = airtelName;
	}
	public String getClientValidInvalidStatus() {
		return clientValidInvalidStatus;
	}
	public void setClientValidInvalidStatus(String clientValidInvalidStatus) {
		this.clientValidInvalidStatus = clientValidInvalidStatus;
	}
	public String getClientReason() {
		return clientReason;
	}
	public void setClientReason(String clientReason) {
		this.clientReason = clientReason;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getUrmnNumber() {
		return urmnNumber;
	}
	public void setUrmnNumber(String urmnNumber) {
		this.urmnNumber = urmnNumber;
	}
	public String getRegStatus() {
		return regStatus;
	}
	public void setRegStatus(String regStatus) {
		this.regStatus = regStatus;
	}
	public String getReasonNotReg() {
		return reasonNotReg;
	}
	public void setReasonNotReg(String reasonNotReg) {
		this.reasonNotReg = reasonNotReg;
	}
	public Date getActivationDate() {
		return activationDate;
	}
	public void setActivationDate(Date activationDate) {
		this.activationDate = activationDate;
	}
	public String getFileNumber() {
		return fileNumber;
	}
	public void setFileNumber(String fileNumber) {
		this.fileNumber = fileNumber;
	}
	
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getCircleCode() {
		return circleCode;
	}
	public void setCircleCode(String circleCode) {
		this.circleCode = circleCode;
	}
	public Date getNpciUploadDate() {
		return npciUploadDate;
	}
	public void setNpciUploadDate(Date npciUploadDate) {
		this.npciUploadDate = npciUploadDate;
	}
	public String getSubClient() {
		return subClient;
	}
	public void setSubClient(String subClient) {
		this.subClient = subClient;
	}
	
	
	
	

}
