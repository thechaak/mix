package com.airtel.acecad.bulkupload.controller;

public class SuperClass {
	
	public SuperClass() {
		System.out.println("Super Class Constructor");
	}
	
	public int run(){
		System.out.println("In run method of Super");
		return 1;
	}
	
	
	protected void abc(){
		System.out.println("In abc of super");
	}
	
}
