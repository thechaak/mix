package com.airtel.acecad.bulkupload.dto;

import java.util.Date;

public class wacMoflUpload {

	private int waiverTicketNo;
	private String lob;
	private String	circle;
	private String accountExternalId;
	private String amount;
	private String mobilelId;
	private String billRefNo;
	private String segment;
	private String typeOfAdjustment;
	private String adjDescription;
	private int adjTransCode;
	private String appName;
	private String appLevel;
	private String adjReasonDet;
	private String type;
	private String subType;
	private String subSubType;
	private String product;
	private String issueRectified;
	private String vipFlag;	
	private String customerClassification;
	private String customerType;	
	private String valueType;	
	private String finalSegment; 
	private String waiverInvoicePercentage;	
	private int ageOnNetwork;
	private String billRefResets;
	private String invoiceDate;		
	private String invoiceOutstandingAmt;	
	private String totalInvoiceAmt;	
	private String customerName;	
	private String uploadedUserId;
	private String uploadedUserName;
	private String wacReachTime;
	private Date ticketUploadTime;	
	private String typeOfPeriod;			
	private String typeOfWaiver;
	private String wacAdjReasonCode;
	private String wacReasonDet;
	private String wacException;
	private String wacStatus;
	private String wacRejReason;
	private String wacAmount;
	private String wacRemarks;
	private int waiverTxNo;
	
	
	public String getBillRefResets() {
		return billRefResets;
	}
	public void setBillRefResets(String billRefResets) {
		this.billRefResets = billRefResets;
	}
	public String getSubSubType() {
		return subSubType;
	}
	public void setSubSubType(String subSubType) {
		this.subSubType = subSubType;
	}
	public String getTypeOfPeriod() {
		return typeOfPeriod;
	}
	public void setTypeOfPeriod(String typeOfPeriod) {
		this.typeOfPeriod = typeOfPeriod;
	}
	public Date getTicketUploadTime() {
		return ticketUploadTime;
	}
	public void setTicketUploadTime(Date ticketUploadTime) {
		this.ticketUploadTime = ticketUploadTime;
	}
	public String getWacReachTime() {
		return wacReachTime;
	}
	public void setWacReachTime(String wacReachTime) {
		this.wacReachTime = wacReachTime;
	}
	public String getUploadedUserName() {
		return uploadedUserName;
	}
	public void setUploadedUserName(String uploadedUserName) {
		this.uploadedUserName = uploadedUserName;
	}
	public String getUploadedUserId() {
		return uploadedUserId;
	}
	public void setUploadedUserId(String uploadedUserId) {
		this.uploadedUserId = uploadedUserId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getInvoiceOutstandingAmt() {
		return invoiceOutstandingAmt;
	}
	public void setInvoiceOutstandingAmt(String invoiceOutstandingAmt) {
		this.invoiceOutstandingAmt = invoiceOutstandingAmt;
	}
	public String getTotalInvoiceAmt() {
		return totalInvoiceAmt;
	}
	public void setTotalInvoiceAmt(String totalInvoiceAmt) {
		this.totalInvoiceAmt = totalInvoiceAmt;
	}
	public String getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public int getAgeOnNetwork() {
		return ageOnNetwork;
	}
	public void setAgeOnNetwork(int ageOnNetwork) {
		this.ageOnNetwork = ageOnNetwork;
	}
	public String getWaiverInvoicePercentage() {
		return waiverInvoicePercentage;
	}
	public void setWaiverInvoicePercentage(String waiverInvoicePercentage) {
		this.waiverInvoicePercentage = waiverInvoicePercentage;
	}
	public String getFinalSegment() {
		return finalSegment;
	}
	public void setFinalSegment(String finalSegment) {
		this.finalSegment = finalSegment;
	}
	public String getValueType() {
		return valueType;
	}
	public void setValueType(String valueType) {
		this.valueType = valueType;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getCustomerClassification() {
		return customerClassification;
	}
	public void setCustomerClassification(String customerClassification) {
		this.customerClassification = customerClassification;
	}
	public String getVipFlag() {
		return vipFlag;
	}
	public void setVipFlag(String vipFlag) {
		this.vipFlag = vipFlag;
	}
	public int getWaiverTicketNo() {
		return waiverTicketNo;
	}
	public void setWaiverTicketNo(int waiverTicketNo) {
		this.waiverTicketNo = waiverTicketNo;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getAccountExternalId() {
		return accountExternalId;
	}
	public void setAccountExternalId(String accountExternalId) {
		this.accountExternalId = accountExternalId;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getMobilelId() {
		return mobilelId;
	}
	public void setMobilelId(String mobilelId) {
		this.mobilelId = mobilelId;
	}
	public String getBillRefNo() {
		return billRefNo;
	}
	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}
	public String getSegment() {
		return segment;
	}
	public void setSegment(String segment) {
		this.segment = segment;
	}
	public String getTypeOfAdjustment() {
		return typeOfAdjustment;
	}
	public void setTypeOfAdjustment(String typeOfAdjustment) {
		this.typeOfAdjustment = typeOfAdjustment;
	}
	public String getAdjDescription() {
		return adjDescription;
	}
	public void setAdjDescription(String adjDescription) {
		this.adjDescription = adjDescription;
	}
	public int getAdjTransCode() {
		return adjTransCode;
	}
	public void setAdjTransCode(int adjTransCode) {
		this.adjTransCode = adjTransCode;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getAppLevel() {
		return appLevel;
	}
	public void setAppLevel(String appLevel) {
		this.appLevel = appLevel;
	}
	public String getAdjReasonDet() {
		return adjReasonDet;
	}
	public void setAdjReasonDet(String adjReasonDet) {
		this.adjReasonDet = adjReasonDet;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getIssueRectified() {
		return issueRectified;
	}
	public void setIssueRectified(String issueRectified) {
		this.issueRectified = issueRectified;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getTypeOfWaiver() {
		return typeOfWaiver;
	}
	public void setTypeOfWaiver(String typeOfWaiver) {
		this.typeOfWaiver = typeOfWaiver;
	}
	public String getWacAdjReasonCode() {
		return wacAdjReasonCode;
	}
	public void setWacAdjReasonCode(String wacAdjReasonCode) {
		this.wacAdjReasonCode = wacAdjReasonCode;
	}
	public String getWacReasonDet() {
		return wacReasonDet;
	}
	public void setWacReasonDet(String wacReasonDet) {
		this.wacReasonDet = wacReasonDet;
	}
	public String getWacException() {
		return wacException;
	}
	public void setWacException(String wacException) {
		this.wacException = wacException;
	}
	public String getWacStatus() {
		return wacStatus;
	}
	public void setWacStatus(String wacStatus) {
		this.wacStatus = wacStatus;
	}
	public String getWacRejReason() {
		return wacRejReason;
	}
	public void setWacRejReason(String wacRejReason) {
		this.wacRejReason = wacRejReason;
	}
	public String getWacAmount() {
		return wacAmount;
	}
	public void setWacAmount(String wacAmount) {
		this.wacAmount = wacAmount;
	}
	public String getWacRemarks() {
		return wacRemarks;
	}
	public void setWacRemarks(String wacRemarks) {
		this.wacRemarks = wacRemarks;
	}
	public int getWaiverTxNo() {
		return waiverTxNo;
	}
	public void setWaiverTxNo(int waiverTxNo) {
		this.waiverTxNo = waiverTxNo;
	}
	
	
	
	
	
}
