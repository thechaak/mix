package com.airtel.acecad.bulkupload.util;

public class CommonUtil {

	public static boolean isNotNull(String str){
		
		boolean checkNull = false;
		
		if(str != null && !str.isEmpty()){
			checkNull=true;
		}else {
			checkNull = false;
		}
	return checkNull;
		
	}
	
	
}
