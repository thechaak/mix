package com.airtel.acecad.bulkupload.dto;

import java.sql.Timestamp;

public class NrcReversalDetails {

	int transactionNo;
	int srTransactionNo;
	int fileId;
	String fileIdentifier;
	String srNumber;
	String srCategory;
	
	String accountNo;
	Long origViewId;

	String source;
	String apsFalg;
	
	Timestamp createdDate;
	Timestamp modifiedDate;
	
	int trackingId;
	int trackinIdServ;
	int viewId;
	int statusCode;
	String statusDescription;
	int noOfHit;
	String userId;
	
	public int getTransactionNo() {
		return transactionNo;
	}
	public void setTransactionNo(int transactionNo) {
		this.transactionNo = transactionNo;
	}
	public int getSrTransactionNo() {
		return srTransactionNo;
	}
	public void setSrTransactionNo(int srTransactionNo) {
		this.srTransactionNo = srTransactionNo;
	}
	public int getFileId() {
		return fileId;
	}
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}
	public String getFileIdentifier() {
		return fileIdentifier;
	}
	public void setFileIdentifier(String fileIdentifier) {
		this.fileIdentifier = fileIdentifier;
	}
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getSrCategory() {
		return srCategory;
	}
	public void setSrCategory(String srCategory) {
		this.srCategory = srCategory;
	}

	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	
	public Long getOrigViewId() {
		return origViewId;
	}
	public void setOrigViewId(Long origViewId) {
		this.origViewId = origViewId;
	}
	public int getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(int trackingId) {
		this.trackingId = trackingId;
	}
	public int getTrackinIdServ() {
		return trackinIdServ;
	}
	public void setTrackinIdServ(int trackinIdServ) {
		this.trackinIdServ = trackinIdServ;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getApsFalg() {
		return apsFalg;
	}
	public void setApsFalg(String apsFalg) {
		this.apsFalg = apsFalg;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public int getViewId() {
		return viewId;
	}
	public void setViewId(int viewId) {
		this.viewId = viewId;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	public int getNoOfHit() {
		return noOfHit;
	}
	public void setNoOfHit(int noOfHit) {
		this.noOfHit = noOfHit;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
}
