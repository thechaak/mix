package com.airtel.acecad.bulkupload.dao;

import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.poi.ss.usermodel.Workbook;

import com.airtel.acecad.bulkupload.dto.ChequeBounceDetails;
import com.airtel.acecad.bulkupload.dto.FileColMstAps;
import com.airtel.acecad.bulkupload.dto.FileIdentifierMstAps;
import com.airtel.acecad.bulkupload.dto.FileStatusAPS;
import com.airtel.acecad.bulkupload.dto.FileStatusDTO;
import com.airtel.acecad.bulkupload.dto.PaymentTransferDetails;
import com.airtel.acecad.bulkupload.dto.ResponseOfInsert;

public interface FileUploadDao {
	public String getAPSFLAG(String accountNumber);
	public String updateStatusCode(int fileId,String tableName,String userId,String fileIde);
	public int duplicateFileName(String fileName,int tot_rows, double sum,Date date,List list,String fileIde);
    public String insertIntoFileStatus(int file_Id,String fileIdentifier,String fileName,Double sum,int tot_rows,String source, String user, int status,String errorReason,int invalidCount,Date date,String batch,List<String> list);
//	public void insertIntoFileStatus(int file_Id,String fileIdentifier,String fileName,Double sum,int tot_rows,String source, String user, int status,String errorReason,int invalidCount,Date date,String batch,List<String> list);
	public ResponseOfInsert insertIntoDynamicTable(int file_Id,List detailsList,FileIdentifierMstAps fileId, List<FileColMstAps> fileColMstList,String source,String userId,String advPaymentMode) throws Exception;
	public String getFileId() throws Exception;
	public int getTransactionNumber(String sequenceName) throws Exception;
	String headerProcValidation(List<String> headersList,String fileType,String fileName);
	public List<FileColMstAps> readFileColMstApsData(String fileIdentifier) throws Exception;
	public FileIdentifierMstAps readFileIdentifierFromMst(String fileIdentifier)  throws Exception;
	
	//public int duplicateProc(int fileId,String fileIdentifier);
	public String duplicateProc(int fileId, String fileIdentifier);
	public void insertIntoErrorLog(int fildId,String fileName,String errorReason,String user);
	public boolean checkCircle(String fileName,String fileIde);
	public String validatexlsxFile(Workbook workbook, String fileIdentifier, String fileName);
	public FileStatusDTO getFileStatusAPS(int page);
	public FileStatusDTO getFileStatusAPSForApprove(int page);
	public List<String> getStatusList() throws SQLException;
	public FileStatusDTO searchFileAPS(String trim, String trim2, String fromDate, String endDate, String status,int page,String viewName,String fileIdentifier,String olmID)throws Exception;
	public String approveFile(List<String> checkedFileList, List<String> checkedReasonList,List<String> checkedRemarkList, String userId, String action) throws Exception;
	public boolean updateTransactionNumberStatus(HashMap<String,List<String>> transactionNumberToUpdate,String fileIdentifier) throws Exception;
	public HashMap<String, String> readFileTypeList() throws Exception;
	//PAYMENTS METHODS
	public boolean checkPaymentCircle(String cir);
	public String getPaymentFileId() throws Exception;
	public void insertIntoPaymentStatus(int file_Id,String fileIdentifier,String fileName,double sum,int tot_rows,String source, String user, int status,String errorReason,int invalidCount,Date date,String batch);
	public ResponseOfInsert insertIntoPaymentsTable(int file_Id,List detailsList,FileIdentifierMstAps fileId, List<FileColMstAps> fileColMstList,String source,String userId) throws Exception;
	public PaymentTransferDetails getpaymentWorkflow() throws Exception;

	public PaymentTransferDetails getsearchpaymentWorkflow(String amount,String accountNo) throws Exception ;
	public PaymentTransferDetails getpaymentApproveWorkflow() throws Exception ;
	public ChequeBounceDetails getAesChequeDetails() throws Exception;
	public ChequeBounceDetails getSearchAesCheque(String chequeNo,String accountNo) throws Exception;
	public ChequeBounceDetails getAesApproveWorkflow() throws Exception;
	PaymentTransferDetails paymentTransferAmount(String amount, String account) throws Exception;
	public void updateDetailsStatus(String file_id,String addStatusUpdate) throws Exception;
	
	//advice
	public String getPaymentAdviceFileId(String fileIdef) throws Exception;
	
	public void insertIntoPaymentAdviceStatus(int file_Id, String fileIdentifier, String fileName, Double sum, int tot_rows,
			String source, String user, int status, String errorReason,  int invalidCount, Date date,String processType,List<String> list) ;
	public String validateUTRStatus(List<String> utrSet,List<String> rbiAcct, String file_id
			,String paymentMode,List<String> IncValList);
	
	//Channnel Partner
	public FileStatusDTO getFileStatusCI(int page);
	public FileStatusDTO getFileStatusCiForApprove(int page);
	public FileStatusDTO searchFileCi(String fileId, String fileName, String fromDate, String endDate, String status,int page,String viewName,String fileIdentifier,String olmId) throws Exception;
	public HashMap<String, String> readFileTypeListCP() throws Exception;
	public String approveFileCP(List<String> checkedFileList, List<String> checkedReasonList,List<String> checkedRemarkList, String userId, String action) throws Exception;

	//AESCheque Advice
	public String validateAESadvUTRStatus(Set<String> utrSet, String file_id,String paymentMode);
	//for error insert record in advice status table for suspense allocation
	public void insertIntoPaymentAdviceStatusError(int file_Id, String fileIdentifier, String fileName, Double sum,
			int tot_rows, String paymentMode, String user, int status, String errorReason, int invalidCount, Date date,
			String processType, List<String> list);
	
	  public String updateSALStatusIntoAdviceStatus(String fileId);
	  public String updateAdviceFailure(String fileId,String fileIdentifier)throws Exception;
	public String validatetTanStatus(Set<String> utrSet, String file_Id, String validateFile);
	public void updateTDSAdviceFailure(String file_Id, String upperCase, String errorReason) throws Exception;
	public String getProcessType(String fileIdentifier,String pType);
	public void updateWaiverDetails(String supportFile, String file_Id, String processType);
	public String headerProcValidation1(List<String> headersList, String fileType, String fileName);
}
