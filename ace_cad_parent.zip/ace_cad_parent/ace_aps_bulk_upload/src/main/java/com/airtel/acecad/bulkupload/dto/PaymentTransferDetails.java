package com.airtel.acecad.bulkupload.dto;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PaymentTransferDetails implements Serializable {

	int fileId;
	String type;
	String transDate;
	String paymentMode;
	String lob;
	String accountNo;
	String invoiceNo;
	long amount;
	String chequeNo;
	String origTrackingId;
	String origTrackinIdServ;
	String collectionManagerName;
	String ticketNo;
	String annoation;
	String createdDate;
	String modifiedDate;
	String trackingId;
	String trackinIdServ;
	String statusCode;
	String statusDescription;
	String sentFxFlag;
	String noOfHit;
	String userId;
	int recordCount;
	int totalPages;
	int sum;
	public int getSum() {
		return sum;
	}
	public void setSum(int sum) {
		this.sum = sum;
	}
	public int getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	public int getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}
	List<PaymentTransferDetails> paymentTransfer=new ArrayList<>();
	
	public List<PaymentTransferDetails> getPaymentTransfer() {
		return paymentTransfer;
	}
	public void setPaymentTransfer(List<PaymentTransferDetails> paymentTransfer) {
		this.paymentTransfer = paymentTransfer;
	}
	public int getFileId() {
		return fileId;
	}
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}

	public String getTransDate() {
		return transDate;
	}
	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	public String getChequeNo() {
		return chequeNo;
	}
	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}
	public String getOrigTrackingId() {
		return origTrackingId;
	}
	public void setOrigTrackingId(String origTrackingId) {
		this.origTrackingId = origTrackingId;
	}
	public String getOrigTrackinIdServ() {
		return origTrackinIdServ;
	}
	public void setOrigTrackinIdServ(String origTrackinIdServ) {
		this.origTrackinIdServ = origTrackinIdServ;
	}
	public String getCollectionManagerName() {
		return collectionManagerName;
	}
	public void setCollectionManagerName(String collectionManagerName) {
		this.collectionManagerName = collectionManagerName;
	}
	public String getTicketNo() {
		return ticketNo;
	}
	public void setTicketNo(String ticketNo) {
		this.ticketNo = ticketNo;
	}
	public String getAnnoation() {
		return annoation;
	}
	public void setAnnoation(String annoation) {
		this.annoation = annoation;
	}

	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	public String getTrackinIdServ() {
		return trackinIdServ;
	}
	public void setTrackinIdServ(String trackinIdServ) {
		this.trackinIdServ = trackinIdServ;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	public String getSentFxFlag() {
		return sentFxFlag;
	}
	public void setSentFxFlag(String sentFxFlag) {
		this.sentFxFlag = sentFxFlag;
	}
	public String getNoOfHit() {
		return noOfHit;
	}
	public void setNoOfHit(String noOfHit) {
		this.noOfHit = noOfHit;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
}