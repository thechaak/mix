package com.airtel.acecad.bulkupload.dto;

public class FileColMstAps {
	
	String slNo;
	String fileIdentifier;
	String columnName;
	String dataType;
	String classAttributeName;
	String required;
	String rangeOfValues;
	String minValue;
	String maxValue;
	String format;
	String columnHeader;
	public String getColumnHeader() {
		return columnHeader;
	}
	public void setColumnHeader(String columnHeader) {
		this.columnHeader = columnHeader;
	}
	public String getFormat() {
		return format;
	}
	public void setFormat(String format) {
		this.format = format;
	}
	public String getClassAttributeName() {
		return classAttributeName;
	}
	public void setClassAttributeName(String classAttributeName) {
		this.classAttributeName = classAttributeName;
	}
	public String getSlNo() {
		return slNo;
	}
	public void setSlNo(String slNo) {
		this.slNo = slNo;
	}
	public String getFileIdentifier() {
		return fileIdentifier;
	}
	public void setFileIdentifier(String fileIdentifier) {
		this.fileIdentifier = fileIdentifier;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public String getRequired() {
		return required;
	}
	public void setRequired(String required) {
		this.required = required;
	}
	public String getRangeOfValues() {
		return rangeOfValues;
	}
	public void setRangeOfValues(String rangeOfValues) {
		this.rangeOfValues = rangeOfValues;
	}
	public String getMinValue() {
		return minValue;
	}
	public void setMinValue(String minValue) {
		this.minValue = minValue;
	}
	public String getMaxValue() {
		return maxValue;
	}
	public void setMaxValue(String maxValue) {
		this.maxValue = maxValue;
	}

	
}
