package com.airtel.acecad.bulkupload.dto;

import java.util.Date;

public class AWB {
	String srNumber;
	String accountNo;
	String lob;
	String srSubType;
	Number msisdn;
	Number alternateContactNo;
	String customerName;
	String address;
	String email;
	String chequeUtrNo;
	Date chequeUtrDate;
	Number refundAmount;
	String addressChange;
	String awbNo;
	String courierAgencyName;
	String awbDate;
	String comments;
	String deliveryStatus;
	Date deliveryDate;
	String rtoReason;
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getSrSubType() {
		return srSubType;
	}
	public void setSrSubType(String srSubType) {
		this.srSubType = srSubType;
	}
	public Number getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(Number msisdn) {
		this.msisdn = msisdn;
	}
	public Number getAlternateContactNo() {
		return alternateContactNo;
	}
	public void setAlternateContactNo(Number alternateContactNo) {
		this.alternateContactNo = alternateContactNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getChequeUtrNo() {
		return chequeUtrNo;
	}
	public void setChequeUtrNo(String chequeUtrNo) {
		this.chequeUtrNo = chequeUtrNo;
	}
	public Date getChequeUtrDate() {
		return chequeUtrDate;
	}
	public void setChequeUtrDate(Date chequeUtrDate) {
		this.chequeUtrDate = chequeUtrDate;
	}
	public Number getRefundAmount() {
		return refundAmount;
	}
	public void setRefundAmount(Number refundAmount) {
		this.refundAmount = refundAmount;
	}
	public String getAddressChange() {
		return addressChange;
	}
	public void setAddressChange(String addressChange) {
		this.addressChange = addressChange;
	}
	public String getAwbNo() {
		return awbNo;
	}
	public void setAwbNo(String awbNo) {
		this.awbNo = awbNo;
	}
	public String getCourierAgencyName() {
		return courierAgencyName;
	}
	public void setCourierAgencyName(String courierAgencyName) {
		this.courierAgencyName = courierAgencyName;
	}
	public String getAwbDate() {
		return awbDate;
	}
	public void setAwbDate(String awbDate) {
		this.awbDate = awbDate;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	public Date getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public String getRtoReason() {
		return rtoReason;
	}
	public void setRtoReason(String rtoReason) {
		this.rtoReason = rtoReason;
	}

}
