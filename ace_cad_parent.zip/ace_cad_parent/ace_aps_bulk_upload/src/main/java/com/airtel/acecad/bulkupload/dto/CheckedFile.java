package com.airtel.acecad.bulkupload.dto;

import java.util.List;

public class CheckedFile {
	private List<String> checkedFileList;
	private List<String> checkedRemarkList;
	private List<String> checkedReasonList;
	public List<String> getCheckedFileList() {
		return checkedFileList;
	}
	public void setCheckedFileList(List<String> checkedFileList) {
		this.checkedFileList = checkedFileList;
	}
	public List<String> getCheckedRemarkList() {
		return checkedRemarkList;
	}
	public void setCheckedRemarkList(List<String> checkedRemarkList) {
		this.checkedRemarkList = checkedRemarkList;
	}
	public List<String> getCheckedReasonList() {
		return checkedReasonList;
	}
	public void setCheckedReasonList(List<String> checkedReasonList) {
		this.checkedReasonList = checkedReasonList;
	}

}
