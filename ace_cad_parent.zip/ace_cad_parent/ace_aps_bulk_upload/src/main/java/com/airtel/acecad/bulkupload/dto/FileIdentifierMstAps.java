package com.airtel.acecad.bulkupload.dto;
import java.sql.Date;

public class FileIdentifierMstAps {
	String slNo;
	String fileIdentifier;
	String tableName;
	String beanObject;
	String source;
	int amountCol;
	int recordCount;
	long recordSum;
	String reversalObject;
	String status;
	String errorReason;
	String userId;
	Date createdDate;
	Date modifiedDate;
	String sequenceName;
	public String getSequenceName() {
		return sequenceName;
	}
	public void setSequenceName(String sequenceName) {
		this.sequenceName = sequenceName;
	}
	public String getSlNo() {
		return slNo;
	}
	public void setSlNo(String slNo) {
		this.slNo = slNo;
	}
	public String getFileIdentifier() {
		return fileIdentifier;
	}
	public void setFileIdentifier(String fileIdentifier) {
		this.fileIdentifier = fileIdentifier;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getBeanObject() {
		return beanObject;
	}
	public void setBeanObject(String beanObject) {
		this.beanObject = beanObject;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public int getAmountCol() {
		return amountCol;
	}
	public void setAmountCol(int amountCol) {
		this.amountCol = amountCol;
	}
	public int getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}
	
	public long getRecordSum() {
		return recordSum;
	}
	public void setRecordSum(long recordSum) {
		this.recordSum = recordSum;
	}
	public String getReversalObject() {
		return reversalObject;
	}
	public void setReversalObject(String reversalObject) {
		this.reversalObject = reversalObject;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getErrorReason() {
		return errorReason;
	}
	public void setErrorReason(String errorReason) {
		this.errorReason = errorReason;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	
}
