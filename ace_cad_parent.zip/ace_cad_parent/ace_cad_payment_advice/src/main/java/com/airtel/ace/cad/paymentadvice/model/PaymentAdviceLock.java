/**
 * 
 */
package com.airtel.ace.cad.paymentadvice.model;
  
/**
 * @author 587111
 *
 */
public class PaymentAdviceLock {
	
	private String lockAcuiredBy;
	private String referenceNum;
	private String lockStartTime;
	private String lockEndTime;
	private String lockStatus;
	private String errorCode;
	private String errorMessage;
	public String getLockAcuiredBy() {
		return lockAcuiredBy;
	}
	public void setLockAcuiredBy(String lockAcuiredBy) {
		this.lockAcuiredBy = lockAcuiredBy;
	}
	public String getReferenceNum() {
		return referenceNum;
	}
	public void setReferenceNum(String referenceNum) {
		this.referenceNum = referenceNum;
	}
	public String getLockStartTime() {
		return lockStartTime;
	}
	public void setLockStartTime(String lockStartTime) {
		this.lockStartTime = lockStartTime;
	}
	public String getLockEndTime() {
		return lockEndTime;
	}
	public void setLockEndTime(String lockEndTime) {
		this.lockEndTime = lockEndTime;
	}
	public String getLockStatus() {
		return lockStatus;
	}
	public void setLockStatus(String lockStatus) {
		this.lockStatus = lockStatus;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

}
