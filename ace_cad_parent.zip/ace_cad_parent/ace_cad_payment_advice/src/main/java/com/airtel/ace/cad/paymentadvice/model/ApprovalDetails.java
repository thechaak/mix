package com.airtel.ace.cad.paymentadvice.model;
 
import java.sql.Date;
import java.util.HashMap;
import java.util.List;

   


public class ApprovalDetails {

	
	private long requestID;
	private String processType;
	private String uploadedOLMId;
	private String uploadedName;
	private String approvedOLMId;
	private String approvedName;
	private String sourceLOB;
	private String destinationLOB;
	private String paymentMode;
	private String uploadedCircle;
	private int totalRecords;
	private Double totalAmount;
	private String paymentCurrency;
	private Double amountInINR;
	private String uploadedDate;
	private String bankAccountNumber;
	private String supportedFile;
	private String changeWho;
	private Date changeDate;
	private int totalTargetAccounts;
	private int totalSuccessRecords;
	private int totalFailureRecords;
	private String remarks;
	private int status;
	private List<String> modeOfPaymentList;
	private List<String> paymentAdviceProcessList;
	private HashMap<Integer, List<ApprovalDetails>> ApprovalDetailsHashMap;
	private int pageNumber;
	private String approvalStatus;
	private String fileName;
	private String rejectReason;
	private String errorCode;
	private String errorMessage;
	private String customerType;
	private int totalPages;
	private List<String> reqIdList;
	private List<ApprovalDetails> utrDetailsList;
	private String circle;
	private Double newExchangeRate;
    private Double oldExchangeRate;
     
    private Double tdsAmount;
    private Double paymentAmount;
    private String utrNumber;
    private int orig_tracking_id;
    private String fxAccountNumber;
    private String invoiceNumber;
    private String tanNumber;
    private int recordId;   
    private String b2b_b2c;
    private String requestStatus;
  private int invalidRecordCount;
  private String sessionId;
  private String source_reversal_currency;
  private String fx_customer_currency;
  private String notes;
  private String dropDownRejectReason;
  private String downloadStatus;
  private String incomingTransactionRefNumber;
  private Date paymentReceivedDate;
  private String legalEntity;
  private String receiverName;
  private String remitterName;
  private String refNo;
  private String paymentDetails1;
  private String paymentDetails2;
  private String targetFxAccountNumber;
  private String customerName;
  private String invoiceAllocationAmount;
  private Date chequeDate;
  private String bankName;
  private String aproveRejectEmailId;
  private String sourceCircle;
  private String destinationCircle;
  private String fromDate;
  private String toDate;
  private List<Circle> circlesAllowed;
  private String percentChange;
  private String roleId;
  private double revExchangeRate;
  private double reversalAmt;
  private String currencyFileType;
  private String subsidiary;
  private String fundCurrency;
  private String dummyAcctCurrency;

 
  public String getFundCurrency() {
	return fundCurrency;
}
public void setFundCurrency(String fundCurrency) {
	this.fundCurrency = fundCurrency;
}
public String getDummyAcctCurrency() {
	return dummyAcctCurrency;
}
public void setDummyAcctCurrency(String dummyAcctCurrency) {
	this.dummyAcctCurrency = dummyAcctCurrency;
}
public String getCurrencyFileType() {
	return currencyFileType;
}
public void setCurrencyFileType(String currencyFileType) {
	this.currencyFileType = currencyFileType;
}
public double getRevExchangeRate() {
	return revExchangeRate;
}
public void setRevExchangeRate(double revExchangeRate) {
	this.revExchangeRate = revExchangeRate;
}
public double getReversalAmt() {
	return reversalAmt;
}
public void setReversalAmt(double reversalAmt) {
	this.reversalAmt = reversalAmt;
}
public String getRoleId() {
	return roleId;
}
public void setRoleId(String roleId) {
	this.roleId = roleId;
}
public String getPercentChange() {
	return percentChange;
}
public void setPercentChange(String percentChange) {
	this.percentChange = percentChange;
}
private String supportFile;
  private String customerEmailId;
    
  private String approvalTime;
  
	
 	public String getApprovalTime() {
 	return approvalTime;
 }
 public void setApprovalTime(String approvalTime) {
 	this.approvalTime = approvalTime;
 }

	public String getRequestStatus() {
	return requestStatus;
}
public String getSupportFile() {
		return supportFile;
	}
	public void setSupportFile(String supportFile) {
		this.supportFile = supportFile;
	}
public void setRequestStatus(String requestStatus) {
	this.requestStatus = requestStatus;
}
	public int getInvalidRecordCount() {
	return invalidRecordCount;
}
public void setInvalidRecordCount(int invalidRecordCount) {
	this.invalidRecordCount = invalidRecordCount;
}
	public String getB2b_b2c() {
		return b2b_b2c;
	}
	public void setB2b_b2c(String b2b_b2c) {
		this.b2b_b2c = b2b_b2c;
	}
	/*
	
	INPUT_REMARKS*/
	
	public String getProcessType() {
		return processType;
	}
	public void setProcessType(String processType) {
		this.processType = processType;
	}
	public String getUploadedOLMId() {
		return uploadedOLMId;
	}
	public void setUploadedOLMId(String uploadedOLMId) {
		this.uploadedOLMId = uploadedOLMId;
	}
	public String getUploadedName() {
		return uploadedName;
	}
	public void setUploadedName(String uploadedName) {
		this.uploadedName = uploadedName;
	}
	public String getApprovedOLMId() {
		return approvedOLMId;
	}
	public void setApprovedOLMId(String approvedOLMId) {
		this.approvedOLMId = approvedOLMId;
	}
	public String getApprovedName() {
		return approvedName;
	}
	public void setApprovedName(String approvedName) {
		this.approvedName = approvedName;
	}
	public String getSourceLOB() {
		return sourceLOB;
	}
	public void setSourceLOB(String sourceLOB) {
		this.sourceLOB = sourceLOB;
	}
	public String getDestinationLOB() {
		return destinationLOB;
	}
	public void setDestinationLOB(String destinationLOB) {
		this.destinationLOB = destinationLOB;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getUploadedCircle() {
		return uploadedCircle;
	}
	public void setUploadedCircle(String uploadedCircle) {
		this.uploadedCircle = uploadedCircle;
	}
	public int getTotalRecords() {
		return totalRecords;
	}
	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}
	
	public String getPaymentCurrency() {
		return paymentCurrency;
	}
	public void setPaymentCurrency(String paymentCurrency) {
		this.paymentCurrency = paymentCurrency;
	}
	
	
	public String getBankAccountNumber() {
		return bankAccountNumber;
	}
	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}
	public String getSupportedFile() {
		return supportedFile;
	}
	public void setSupportedFile(String supportedFile) {
		this.supportedFile = supportedFile;
	}
	public String getChangeWho() {
		return changeWho;
	}
	public void setChangeWho(String changeWho) {
		this.changeWho = changeWho;
	}
	public Date getChangeDate() {
		return changeDate;
	}
	public void setChangeDate(Date changeDate) {
		this.changeDate = changeDate;
	}
	public int getTotalTargetAccounts() {
		return totalTargetAccounts;
	}
	public void setTotalTargetAccounts(int totalTargetAccounts) {
		this.totalTargetAccounts = totalTargetAccounts;
	}
	public int getTotalSuccessRecords() {
		return totalSuccessRecords;
	}
	public void setTotalSuccessRecords(int totalSuccessRecords) {
		this.totalSuccessRecords = totalSuccessRecords;
	}
	public int getTotalFailureRecords() {
		return totalFailureRecords;
	}
	public void setTotalFailureRecords(int totalFailureRecords) {
		this.totalFailureRecords = totalFailureRecords;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public List<String> getModeOfPaymentList() {
		return modeOfPaymentList;
	}
	public void setModeOfPaymentList(List<String> modeOfPaymentList) {
		this.modeOfPaymentList = modeOfPaymentList;
	}
	public List<String> getPaymentAdviceProcessList() {
		return paymentAdviceProcessList;
	}
	public void setPaymentAdviceProcessList(List<String> paymentAdviceProcessList) {
		this.paymentAdviceProcessList = paymentAdviceProcessList;
	}
	public int getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}
	public String getApprovalStatus() {
		return approvalStatus;
	}
	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getRejectReason() {
		return rejectReason;
	}
	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public HashMap<Integer, List<ApprovalDetails>> getApprovalDetailsHashMap() {
		return ApprovalDetailsHashMap;
	}
	public void setApprovalDetailsHashMap(HashMap<Integer, List<ApprovalDetails>> approvalDetailsHashMap) {
		ApprovalDetailsHashMap = approvalDetailsHashMap;
	}
	public int getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	public List<String> getReqIdList() {
		return reqIdList;
	}
	public void setReqIdList(List<String> reqIdList) {
		this.reqIdList = reqIdList;
	}
	public List<ApprovalDetails> getUtrDetailsList() {
		return utrDetailsList;
	}
	public void setUtrDetailsList(List<ApprovalDetails> utrDetailsList) {
		this.utrDetailsList = utrDetailsList;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	
	
		
	public int getOrig_tracking_id() {
		return orig_tracking_id;
	}
	public void setOrig_tracking_id(int orig_tracking_id) {
		this.orig_tracking_id = orig_tracking_id;
	}
	public String getUtrNumber() {
		return utrNumber;
	}
	public void setUtrNumber(String utrNumber) {
		this.utrNumber = utrNumber;
	}
	public String getFxAccountNumber() {
		return fxAccountNumber;
	}
	public void setFxAccountNumber(String fxAccountNumber) {
		this.fxAccountNumber = fxAccountNumber;
	}
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public String getTanNumber() {
		return tanNumber;
	}
	public void setTanNumber(String tanNumber) {
		this.tanNumber = tanNumber;
	}
	public int getRecordId() {
		return recordId;
	}
	public void setRecordId(int recordId) {
		this.recordId = recordId;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public String getSource_reversal_currency() {
		return source_reversal_currency;
	}
	public void setSource_reversal_currency(String source_reversal_currency) {
		this.source_reversal_currency = source_reversal_currency;
	}
	public String getFx_customer_currency() {
		return fx_customer_currency;
	}
	public void setFx_customer_currency(String fx_customer_currency) {
		this.fx_customer_currency = fx_customer_currency;
	}
	public Double getNewExchangeRate() {
		return newExchangeRate;
	}
	public void setNewExchangeRate(Double newExchangeRate) {
		this.newExchangeRate = newExchangeRate;
	}
	public Double getOldExchangeRate() {
		return oldExchangeRate;
	}
	public void setOldExchangeRate(Double oldExchangeRate) {
		this.oldExchangeRate = oldExchangeRate;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getDropDownRejectReason() {
		return dropDownRejectReason;
	}
	public void setDropDownRejectReason(String dropDownRejectReason) {
		this.dropDownRejectReason = dropDownRejectReason;
	}
	public String getDownloadStatus() {
		return downloadStatus;
	}
	public void setDownloadStatus(String downloadStatus) {
		this.downloadStatus = downloadStatus;
	}
	public String getIncomingTransactionRefNumber() {
		return incomingTransactionRefNumber;
	}
	public void setIncomingTransactionRefNumber(
			String incomingTransactionRefNumber) {
		this.incomingTransactionRefNumber = incomingTransactionRefNumber;
	}
	
	public String getLegalEntity() {
		return legalEntity;
	}
	public void setLegalEntity(String legalEntity) {
		this.legalEntity = legalEntity;
	}
	public String getReceiverName() {
		return receiverName;
	}
	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}
	public String getRemitterName() {
		return remitterName;
	}
	public void setRemitterName(String remitterName) {
		this.remitterName = remitterName;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public String getPaymentDetails1() {
		return paymentDetails1;
	}
	public void setPaymentDetails1(String paymentDetails1) {
		this.paymentDetails1 = paymentDetails1;
	}
	public String getPaymentDetails2() {
		return paymentDetails2;
	}
	public void setPaymentDetails2(String paymentDetails2) {
		this.paymentDetails2 = paymentDetails2;
	}
	public String getTargetFxAccountNumber() {
		return targetFxAccountNumber;
	}
	public void setTargetFxAccountNumber(String targetFxAccountNumber) {
		this.targetFxAccountNumber = targetFxAccountNumber;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getInvoiceAllocationAmount() {
		return invoiceAllocationAmount;
	}
	public void setInvoiceAllocationAmount(String invoiceAllocationAmount) {
		this.invoiceAllocationAmount = invoiceAllocationAmount;
	}

	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public long getRequestID() {
		return requestID;
	}
	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}
	public Date getChequeDate() {
		return chequeDate;
	}
	public void setChequeDate(Date chequeDate) {
		this.chequeDate = chequeDate;
	}
	public Date getPaymentReceivedDate() {
		return paymentReceivedDate;
	}
	public void setPaymentReceivedDate(Date paymentReceivedDate) {
		this.paymentReceivedDate = paymentReceivedDate;
	}
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getAproveRejectEmailId() {
		return aproveRejectEmailId;
	}
	public void setAproveRejectEmailId(String aproveRejectEmailId) {
		this.aproveRejectEmailId = aproveRejectEmailId;
	}
	public Double getAmountInINR() {
		return amountInINR;
	}
	public void setAmountInINR(Double amountInINR) {
		this.amountInINR = amountInINR;
	}
	public String getSourceCircle() {
		return sourceCircle;
	}
	public void setSourceCircle(String sourceCircle) {
		this.sourceCircle = sourceCircle;
	}
	public String getDestinationCircle() {
		return destinationCircle;
	}
	public void setDestinationCircle(String destinationCircle) {
		this.destinationCircle = destinationCircle;
	}
	public String getUploadedDate() {
		return uploadedDate;
	}
	public void setUploadedDate(String uploadedDate) {
		this.uploadedDate = uploadedDate;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public Double getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(Double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public Double getTdsAmount() {
		return tdsAmount;
	}
	public void setTdsAmount(Double tdsAmount) {
		this.tdsAmount = tdsAmount;
	}
	public List<Circle> getCirclesAllowed() {
		return circlesAllowed;
	}
	public void setCirclesAllowed(List<Circle> circlesAllowed) {
		this.circlesAllowed = circlesAllowed;
	}
	public String getCustomerEmailId() {
		return customerEmailId;
	}
	public void setCustomerEmailId(String customerEmailId) {
		this.customerEmailId = customerEmailId;
	}
	public String getSubsidiary() {
		return subsidiary;
	}
	public void setSubsidiary(String subsidiary) {
		this.subsidiary = subsidiary;
	}
		
}
