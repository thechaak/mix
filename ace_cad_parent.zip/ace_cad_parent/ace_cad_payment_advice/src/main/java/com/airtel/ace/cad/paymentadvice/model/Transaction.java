/**
 * 
 */
package com.airtel.ace.cad.paymentadvice.model;

import java.sql.Connection;
   
/**
 * @author 587111
 *
 */
public class Transaction {
	
	private Connection dataBaseConnection;
	private boolean isTransSuccess;
	private String errorCode;
	private String errorMessage;
	public Connection getDataBaseConnection() {
		return dataBaseConnection;
	}

	public void setDataBaseConnection(Connection dataBaseConnection) {
		this.dataBaseConnection = dataBaseConnection;
	}

	public boolean isTransSuccess() {
		return isTransSuccess;
	}

	public void setTransSuccess(boolean isTransSuccess) {
		this.isTransSuccess = isTransSuccess;
	}
	

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}
