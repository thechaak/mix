package com.airtel.ace.cad.aesadvice.model;

import java.util.ArrayList;
import java.util.List;

public class AESFileDetails {
	private String batch;
	private int noOfHits;
	private String statusDescription;
	private int srNumber;
	private int srTransactionNo;
	private String modifiedDate;
	private String isWorkListCompliant;
	private int pendingApprovalLevel;
	private String processDate;
	private String errorReason;
	private int status;
	private int validCount;
	private int invalidCount;
	private int totalRecords;
	private String sumOfAmount;
	private String filePath;
	private String firstLastName;
	private String fileIdentifier;
	//private int fileId;
	private String fileId;
	private String fileName;
	private String searchFromDate;
	private String searchEndDate;
	private String circle;
	private String source;
	private String olmId;
	private String statusMessage;
	private String isExist;
	private String isExistCtrl;
	private String isExistError;
	private String isExistFX;
	
	private int totalResults; 
	private int resultPerPage;
	private int totalPages;
	private int currentPage;	
	private String errorMsg;
	private String attachedFile;
	private String checkBoxEnable;
	private String rejectReason;
	private String rejectReasonDropDown;
	
	List<AESFileDetails> aesChqWorkFlowDetailsList = new ArrayList<AESFileDetails>();
	private List<String>checkedRemarkList ;
	private List<String>checkedAESChqApprovalList;
    
	
		
	public String getRejectReasonDropDown() {
		return rejectReasonDropDown;
	}
	public void setRejectReasonDropDown(String rejectReasonDropDown) {
		this.rejectReasonDropDown = rejectReasonDropDown;
	}
	public String getRejectReason() {
		return rejectReason;
	}
	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}
	public List<AESFileDetails> getAesChqWorkFlowDetailsList() {
		return aesChqWorkFlowDetailsList;
	}
	public void setAesChqWorkFlowDetailsList(List<AESFileDetails> aesChqWorkFlowDetailsList) {
		this.aesChqWorkFlowDetailsList = aesChqWorkFlowDetailsList;
	}	
	
	public List<String> getCheckedRemarkList() {
		return checkedRemarkList;
	}
	public void setCheckedRemarkList(List<String> checkedRemarkList) {
		this.checkedRemarkList = checkedRemarkList;
	}
	public List<String> getCheckedAESChqApprovalList() {
		return checkedAESChqApprovalList;
	}
	public void setCheckedAESChqApprovalList(List<String> checkedAESChqApprovalList) {
		this.checkedAESChqApprovalList = checkedAESChqApprovalList;
	}
	public String getCheckBoxEnable() {
		return checkBoxEnable;
	}
	public void setCheckBoxEnable(String checkBoxEnable) {
		this.checkBoxEnable = checkBoxEnable;
	}
	public String getAttachedFile() {
		return attachedFile;
	}
	public void setAttachedFile(String attachedFile) {
		this.attachedFile = attachedFile;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getSearchFromDate() {
		return searchFromDate;
	}
	public void setSearchFromDate(String searchFromDate) {
		this.searchFromDate = searchFromDate;
	}
	public String getSearchEndDate() {
		return searchEndDate;
	}
	public void setSearchEndDate(String searchEndDate) {
		this.searchEndDate = searchEndDate;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public int getTotalResults() {
		return totalResults;
	}
	public void setTotalResults(int totalResults) {
		this.totalResults = totalResults;
	}
	public int getResultPerPage() {
		return resultPerPage;
	}
	public void setResultPerPage(int resultPerPage) {
		this.resultPerPage = resultPerPage;
	}
	public int getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public String getBatch() {
		return batch;
	}
	public void setBatch(String batch) {
		this.batch = batch;
	}
	public int getNoOfHits() {
		return noOfHits;
	}
	public void setNoOfHits(int noOfHits) {
		this.noOfHits = noOfHits;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	public int getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(int srNumber) {
		this.srNumber = srNumber;
	}
	public int getSrTransactionNo() {
		return srTransactionNo;
	}
	public void setSrTransactionNo(int srTransactionNo) {
		this.srTransactionNo = srTransactionNo;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getIsWorkListCompliant() {
		return isWorkListCompliant;
	}
	public void setIsWorkListCompliant(String isWorkListCompliant) {
		this.isWorkListCompliant = isWorkListCompliant;
	}
	public int getPendingApprovalLevel() {
		return pendingApprovalLevel;
	}
	public void setPendingApprovalLevel(int pendingApprovalLevel) {
		this.pendingApprovalLevel = pendingApprovalLevel;
	}
	public String getProcessDate() {
		return processDate;
	}
	public void setProcessDate(String processDate) {
		this.processDate = processDate;
	}
	public String getErrorReason() {
		return errorReason;
	}
	public void setErrorReason(String errorReason) {
		this.errorReason = errorReason;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public int getValidCount() {
		return validCount;
	}
	public void setValidCount(int validCount) {
		this.validCount = validCount;
	}
	public int getInvalidCount() {
		return invalidCount;
	}
	public void setInvalidCount(int invalidCount) {
		this.invalidCount = invalidCount;
	}
	public int getTotalRecords() {
		return totalRecords;
	}
	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}
	public String getSumOfAmount() {
		return sumOfAmount;
	}
	public void setSumOfAmount(String sumOfAmount) {
		this.sumOfAmount = sumOfAmount;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getFirstLastName() {
		return firstLastName;
	}
	public void setFirstLastName(String firstLastName) {
		this.firstLastName = firstLastName;
	}
	public String getFileIdentifier() {
		return fileIdentifier;
	}
	public void setFileIdentifier(String fileIdentifier) {
		this.fileIdentifier = fileIdentifier;
	}
	/*public int getFileId() {
		return fileId;
	}
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}*/
	
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getOlmId() {
		return olmId;
	}
	public void setOlmId(String olmId) {
		this.olmId = olmId;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public String getIsExist() {
		return isExist;
	}
	public void setIsExist(String isExist) {
		this.isExist = isExist;
	}
	public String getIsExistCtrl() {
		return isExistCtrl;
	}
	public void setIsExistCtrl(String isExistCtrl) {
		this.isExistCtrl = isExistCtrl;
	}
	public String getIsExistError() {
		return isExistError;
	}
	public void setIsExistError(String isExistError) {
		this.isExistError = isExistError;
	}
	public String getIsExistFX() {
		return isExistFX;
	}
	public void setIsExistFX(String isExistFX) {
		this.isExistFX = isExistFX;
	}

}
