/**
 * 
 */
package com.airtel.ace.cad.paymentadvice.model;
   
/**
 * @author 587111
 *
 */
public class PaymentType {

	private String paymentType;
	private boolean isActive;
	private boolean isPaymentAdviceAllowed;
	

	public String getPaymentType() {
		return paymentType;
	}


	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}


	public boolean isActive() {
		return isActive;
	}


	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}


	public boolean isPaymentAdviceAllowed() {
		return isPaymentAdviceAllowed;
	}


	public void setPaymentAdviceAllowed(boolean isPaymentAdviceAllowed) {
		this.isPaymentAdviceAllowed = isPaymentAdviceAllowed;
	}

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
