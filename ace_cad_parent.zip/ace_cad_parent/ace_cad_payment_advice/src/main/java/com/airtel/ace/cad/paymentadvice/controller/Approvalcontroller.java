package com.airtel.ace.cad.paymentadvice.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;








import org.apache.logging.log4j.LogManager;
//import org.apache.log4j.Logger;
import org.apache.logging.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.airtel.ace.cad.paymentadvice.dao.ApprovalDAO;
import com.airtel.ace.cad.paymentadvice.model.ApprovalDetails;
import com.airtel.ace.cad.paymentadvice.model.Circle;
//import com.acecad.paymentAdviceApproval.model.UserRole;
import com.airtel.ace.cad.paymentadvice.model.VendorDetails;
import com.airtel.acecad.UtilityJar.ActivityLog;
import com.airtel.acecad.model.EMailContent;
import com.airtel.acecad.model.EmailAttachment;
import com.airtel.acecad.model.SmtpMailContent;
import com.airtel.acecad.utility.SmtpUtility;

@Controller
public class Approvalcontroller {
	private String homePath=System.getenv("ACE_CAD_HOME"); 
	ApprovalDetails approvalDetailsObj=new ApprovalDetails();
	HttpSession session;
	@Value("${LDAP_DOMAIN}")
	private String LDAP_DOMAIN;

	@Value("${LDAP_URL}")
	private String LDAP_URL;

	@Value("${PAYMENT_ADVICE_HOME}")
	private String downloadpath;

	@Autowired
	ApprovalDAO approvaldao;
	@Autowired
	ActivityLog activityDao;
	/*@Autowired
	VendorDetails vendorDetailsObj;
*/
	@Autowired
	ActivityLog activityLog;
	private static Logger logger = LogManager.getLogger("paymentAdviceApprovalLogger");
	private static String paymentAdviceHomePath = System.getenv("PAYMENT_ADVICE_HOME");


	
	@RequestMapping(value = "/ApprovalsDefaultPage")
	public ModelAndView showApprovalDetails(ModelMap model,HttpServletRequest request, HttpServletResponse response)

	{
		ModelAndView modelAndViewObj = new ModelAndView();
		/*ApprovalDetails approvalDetailsObj=new ApprovalDetails();*/

	  try
		{
			logger.info("Entered into show appprovals default page @controller");
			session = request.getSession(true);
			String userId = session.getAttribute("userid").toString();
			String role = session.getAttribute("user_role_id").toString();
			
			//	logger.info("Entered in to else condition to check pagination");
			int pageNumber = 1;
			int totalPages=1;
		
			approvalDetailsObj.setPageNumber(pageNumber);
			approvalDetailsObj.setPaymentMode(null);
			approvalDetailsObj.setProcessType(null);
			approvalDetailsObj.setUploadedOLMId(null);
			approvalDetailsObj.setCircle(null);
			approvalDetailsObj.setRequestID(0);
			approvalDetailsObj.setFromDate(null);
			approvalDetailsObj.setToDate(null);
			approvalDetailsObj.setRoleId(role);
			//SNo=activityDao.insertActivityLog(0,"CAD_ADMIN","Searching For LIU Records With The Given Details",null,null);
			//logger.info("First activity is");
			logger.info("advice mode Of payment in controller Role ID->>>"+role);

			List<String> modeOfPaymentList=approvaldao.getModeOfPayment();
			if(modeOfPaymentList==null)
			{
				modelAndViewObj.addObject("error", "Problem with Backend System");
				//modelAndViewObj.setViewName("PAApprovals");
				if("2".equalsIgnoreCase(role) )
					modelAndViewObj.setViewName("PAApprovals");
				else

					modelAndViewObj.setViewName("ExchangeAdviceApproval");
				return modelAndViewObj;
			}

			List<Circle> circleList=approvaldao.getCirclesList();
			if(circleList==null)
			{
				modelAndViewObj.addObject("error", "Problem with Backend System");
				//modelAndViewObj.setViewName("PAApprovals");
				if("2".equalsIgnoreCase(role))
					modelAndViewObj.setViewName("PAApprovals");
				else
					modelAndViewObj.setViewName("ExchangeAdviceApproval");
				return modelAndViewObj;
			}

			logger.info("modeOfPayment List" +modeOfPaymentList.size()+","+modeOfPaymentList.get(1)+","+modeOfPaymentList.get(2) );
			logger.info("payment advice process list in controller" );

			List<String> paymentAdviceProcessList=approvaldao.getPaymentAdviceProcessList();
			if(paymentAdviceProcessList==null)
			{
				modelAndViewObj.addObject("error", "Problem with Backend System");
				//modelAndViewObj.setViewName("PAApprovals");
				if("2".equalsIgnoreCase(role) )
					modelAndViewObj.setViewName("PAApprovals");
				else
					modelAndViewObj.setViewName("ExchangeAdviceApproval");
				return modelAndViewObj;
			}

			List<String> rejectReasonList=approvaldao.getRejectReasons();
			if(rejectReasonList==null)
			{
				modelAndViewObj.addObject("error", "Problem with Backend System");
				if("2".equalsIgnoreCase(role) )
					modelAndViewObj.setViewName("PAApprovals");
				else
					modelAndViewObj.setViewName("ExchangeAdviceApproval");
				//modelAndViewObj.setViewName("PAApprovals");
				return modelAndViewObj;
			}


			logger.info("payment advice process list size" +paymentAdviceProcessList.size());
			logger.info("all details in controller");

			HashMap<Integer, List<ApprovalDetails>> ApprovalDetailsMap = approvaldao.getApprovalDetails(pageNumber,approvalDetailsObj);
			String errorMsg=approvalDetailsObj.getErrorMessage();

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESSFULLY COMPLETED"))
				{
					errorMsg="";
				}
				else if(errorMsg.equalsIgnoreCase("FILES WITH SPECIFIED SEARCH CRITERIA NOT FOUND"))
				{
					errorMsg="No Pending Approvals to View.Please search with other criteria";
				}
				else
					errorMsg="No Records Found..";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(ApprovalDetailsMap==null)
			{

				errorMsg="Problem with Backend System while retrieving data";
				modelAndViewObj.addObject("errorMap", errorMsg);
				modelAndViewObj.addObject("modeOfPayList", modeOfPaymentList);
				modelAndViewObj.addObject("payAdviceProcessList", paymentAdviceProcessList);
				modelAndViewObj.addObject("rejectReasonList", rejectReasonList);
				modelAndViewObj.addObject("circleList", circleList);
				modelAndViewObj.addObject("approvalDetailsJspObj", approvalDetailsObj);
				// modelAndViewObj.addObject("changeRate", approvalDetailsObj.getPercentChange());
				// System.out.println("percent exchange rate------->>>>>>>"+approvalDetailsObj.getPercentChange());
				if("2".equalsIgnoreCase(role) )
					modelAndViewObj.setViewName("PAApprovals");
				else
					modelAndViewObj.setViewName("ExchangeAdviceApproval");
				//modelAndViewObj.setViewName("PAApprovals");
				return modelAndViewObj;
			}


			logger.info("hashmap key 0 size" +ApprovalDetailsMap.isEmpty());
			Set s=ApprovalDetailsMap.keySet();
			int size=0;
			Iterator i=s.iterator();
			while(i.hasNext())
			{
				List<ApprovalDetails> a=ApprovalDetailsMap.get(i.next());
				size=a.size();
				// logger.info("hashmap values"+a.get(0).getRequestID());
			}
			logger.info("page number is :"  +pageNumber);
			modelAndViewObj.addObject("size",size);
			modelAndViewObj.addObject("key", totalPages);
			modelAndViewObj.addObject("error", "");
			modelAndViewObj.addObject("errorMap", errorMsg);

			modelAndViewObj.addObject("ApprovalDetailsMapObj", ApprovalDetailsMap);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("modeOfPayList", modeOfPaymentList);
			modelAndViewObj.addObject("payAdviceProcessList", paymentAdviceProcessList);
			modelAndViewObj.addObject("rejectReasonList", rejectReasonList);
			modelAndViewObj.addObject("circleList", circleList);
			modelAndViewObj.addObject("approvalDetailsJspObj", approvalDetailsObj);


			logger.info("Model view page is:"+modelAndViewObj.getViewName());
			logger.info("Context is"+request.getContextPath());
			logger.info("Executed default page @controller");
			if("2".equalsIgnoreCase(role) )
				modelAndViewObj.setViewName("PAApprovals");
			else
				modelAndViewObj.setViewName("ExchangeAdviceApproval");
			//modelAndViewObj.setViewName("PAApprovals");

			//return modelAndViewObj;
	}
		catch (Exception e) {
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		return modelAndViewObj;
	}

	
	@RequestMapping(value = "/ApprovalsDetailsWithPgtn")
	public ModelAndView ApprovalsDetailsWithPgtn(ModelMap model,HttpServletRequest request, HttpServletResponse response)

	{
		ModelAndView modelAndViewObj = new ModelAndView();
		

	  try
		{
			session = request.getSession(true);
			String userId = session.getAttribute("userid").toString();
			String role = session.getAttribute("user_role_id").toString();
			logger.info("Entered into show appprovals pagination@controller");



			int pageNumber =  Integer.parseInt(request.getParameter("pageNum"));
			String paymentMode=request.getParameter("paymentMode");
			logger.info("paymode is....." +paymentMode);

			approvalDetailsObj.setPageNumber(pageNumber);
			approvalDetailsObj.setPaymentMode(null);
			approvalDetailsObj.setProcessType(null);
			approvalDetailsObj.setUploadedOLMId(null);
			approvalDetailsObj.setCircle(null);
			approvalDetailsObj.setRequestID(0);
			approvalDetailsObj.setFromDate(null);
			approvalDetailsObj.setToDate(null);
			approvalDetailsObj.setRoleId(role);
			//SNo=activityDao.insertActivityLog(0,"CAD_ADMIN","Searching For LIU Records With The Given Details",null,null);
			//logger.info("First activity is");
			logger.info("mode Of payment wiht pagination in controller");

			List<String> modeOfPaymentList=approvaldao.getModeOfPayment();
			if(modeOfPaymentList==null)
			{
				modelAndViewObj.addObject("error", "Data Base Issues..Retry..");
				if("2".equalsIgnoreCase(role) )
					modelAndViewObj.setViewName("PAApprovals");
				else
					modelAndViewObj.setViewName("ExchangeAdviceApproval");
			//	modelAndViewObj.setViewName("PAApprovals");
				return modelAndViewObj;
			}


			List<Circle> circleList=approvaldao.getCirclesList();
			if(circleList==null)
			{
				modelAndViewObj.addObject("error", "Data Base Issues..Retry..");
				if("2".equalsIgnoreCase(role) )
					modelAndViewObj.setViewName("PAApprovals");
				else
					modelAndViewObj.setViewName("ExchangeAdviceApproval");
				//modelAndViewObj.setViewName("PAApprovals");
				return modelAndViewObj;
			}

			logger.info("payment advice process list in controller" );

			List<String> paymentAdviceProcessList=approvaldao.getPaymentAdviceProcessList();
			if(paymentAdviceProcessList==null)
			{
				modelAndViewObj.addObject("error", "Data Base Issues..Retry..");
				if("2".equalsIgnoreCase(role) )
					modelAndViewObj.setViewName("PAApprovals");
				else
					modelAndViewObj.setViewName("ExchangeAdviceApproval");
				//modelAndViewObj.setViewName("PAApprovals");
				return modelAndViewObj;
			}

			List<String> rejectReasonList=approvaldao.getRejectReasons();  
			if(rejectReasonList==null)
			{
				modelAndViewObj.addObject("error", "Data Base Issues..Retry..");
				if("2".equalsIgnoreCase(role) )
					modelAndViewObj.setViewName("PAApprovals");
				else
					modelAndViewObj.setViewName("ExchangeAdviceApproval");
				//modelAndViewObj.setViewName("PAApprovals");
				return modelAndViewObj;
			}



			logger.info("payment advice process list size" +paymentAdviceProcessList.size());
			logger.info("all details in controller");


			HashMap<Integer, List<ApprovalDetails>> ApprovalDetailsMap = approvaldao.getApprovalDetailsWithPgtn(pageNumber, approvalDetailsObj);
			String errorMsg=approvalDetailsObj.getErrorMessage();

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESSFULLY COMPLETED"))
				{
					errorMsg="";
				}
				else if(errorMsg.equalsIgnoreCase("FILES WITH SPECIFIED SEARCH CRITERIA NOT FOUND"))
				{
					errorMsg="No Pending Approvals to View.Please search with other criteria";
				}
				else
					errorMsg="No Records Found..";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(ApprovalDetailsMap==null)
			{

				errorMsg="Problem with Backend System while retrieving data";
				modelAndViewObj.addObject("errorMap", errorMsg);
				modelAndViewObj.addObject("modeOfPayList", modeOfPaymentList);
				modelAndViewObj.addObject("payAdviceProcessList", paymentAdviceProcessList);
				modelAndViewObj.addObject("rejectReasonList", rejectReasonList);
				modelAndViewObj.addObject("circleList", circleList);
				modelAndViewObj.addObject("approvalDetailsJspObj", approvalDetailsObj);
				if("2".equalsIgnoreCase(role) )
					modelAndViewObj.setViewName("PAApprovals");
				else
					modelAndViewObj.setViewName("ExchangeAdviceApproval");
				//modelAndViewObj.setViewName("PAApprovals");
				return modelAndViewObj;
			}


			/* List<String> errorMsg=approvaldao.getModeOfPayment();
	          if(errorMsg!=null)
	          {
				    modelAndViewObj.addObject("errorMsg", errorMsg);
				    modelAndViewObj.setViewName("PAApprovals");
				    return modelAndViewObj;
	          }
			  */
			  
			  
			  
			 	Set mapSet = (Set) ApprovalDetailsMap.entrySet();
			 	logger.info("length is" +ApprovalDetailsMap.size()); 
			 	int totalPages=0;
			  //Create iterator on Set 
			                Iterator mapIterator = mapSet.iterator();
			                
			 while (mapIterator.hasNext()) 
			                               {
			                        Map.Entry<Integer,List<ApprovalDetails>> mapEntry = (Map.Entry<Integer,List<ApprovalDetails>>) mapIterator.next();
			                        // getKey Method of HashMap access a key of map
			                          totalPages=mapEntry.getKey();      
			                }
			                
		    modelAndViewObj.addObject("key", totalPages);
			logger.info("key is " +totalPages);
			logger.info("page number is :"  +pageNumber);
			modelAndViewObj.addObject("ApprovalDetailsMapObj", ApprovalDetailsMap);
			modelAndViewObj.addObject("currentPage", pageNumber);
			 modelAndViewObj.addObject("error", "");
			 modelAndViewObj.addObject("errorMap", errorMsg);
			modelAndViewObj.addObject("modeOfPayList", modeOfPaymentList);
			modelAndViewObj.addObject("payAdviceProcessList", paymentAdviceProcessList);
			modelAndViewObj.addObject("rejectReasonList", rejectReasonList);
			modelAndViewObj.addObject("circleList", circleList);
			modelAndViewObj.addObject("approvalDetailsJspObj", approvalDetailsObj);
			
			logger.info("Model view page is:"+modelAndViewObj.getViewName());
			logger.info("Context is"+request.getContextPath()); 
			logger.info("Executed default page @controller");
			//modelAndViewObj.setViewName("PAApprovals");

			if("2".equalsIgnoreCase(role) )
				modelAndViewObj.setViewName("PAApprovals");
			else
				modelAndViewObj.setViewName("ExchangeAdviceApproval");
			//return modelAndViewObj;
	}
		catch (Exception e) {
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		return modelAndViewObj;
	}
	
	
	
	@RequestMapping(value = "/SearchApprovals")
	public ModelAndView SearchApprovals(ModelMap model,HttpServletRequest request, HttpServletResponse response)
	

	{
		ModelAndView modelAndViewObj = new ModelAndView();
		

	  try
		{
			logger.info("Entered into show appprovals search@controller");
			session = request.getSession(true);
			String userId = session.getAttribute("userid").toString();
			String role = session.getAttribute("user_role_id").toString();


			int pageNumber =  1;
			
			String uploadeOLMId=request.getParameter("uploadedUser");
			String paymentMode=request.getParameter("paymentMode");
			String processType=request.getParameter("processType");
			String ticketId=request.getParameter("ticketId");
			String circle=request.getParameter("circle");
			String fromDate=request.getParameter("fromDateId");
			String toDate=request.getParameter("toDateId");
			
			logger.info("uploaded user is:" +uploadeOLMId );
			logger.info("paymode is....." +paymentMode);
			logger.info("process type is...." +processType);
			logger.info("ticket id is..." +ticketId);
			logger.info("cirlce is..." +circle);
			logger.info("from date is..."+fromDate);
			logger.info("to date is..."+toDate);
			
			//ticket id
			if(ticketId.equalsIgnoreCase("") || ticketId==null)
			{
				approvalDetailsObj.setRequestID(0);
			}
			else{
				approvalDetailsObj.setRequestID(Long.parseLong(ticketId));
			}
		    //circle
			if(circle.equalsIgnoreCase("Select"))
			{
				approvalDetailsObj.setCircle(null);
			}
			else{
				approvalDetailsObj.setCircle(circle);
			}
			
			//from date
			if(fromDate=="" || fromDate==null)
			{
				approvalDetailsObj.setFromDate(null);
			}
			else{
				approvalDetailsObj.setFromDate(fromDate);
			}
		    //to date
			if(toDate=="" || toDate==null)

			{
				approvalDetailsObj.setToDate(null);
			}
			else{
				approvalDetailsObj.setToDate(toDate);
			}
			//OLM Id
			if(uploadeOLMId=="" || uploadeOLMId==null)
			{
				approvalDetailsObj.setUploadedOLMId(null);
			}
			else{
				approvalDetailsObj.setUploadedOLMId(uploadeOLMId);
			}
		    //payment mode
			if(paymentMode.equalsIgnoreCase("Select"))
			{
				approvalDetailsObj.setPaymentMode(null);
			}
			else{
				approvalDetailsObj.setPaymentMode(paymentMode);
			}
			//process type
			if(processType.equalsIgnoreCase("Select"))
			{
				approvalDetailsObj.setProcessType(null);
			}
			else{
				approvalDetailsObj.setProcessType(processType);
			}
			approvalDetailsObj.setRoleId(role);




			logger.info("uploaded OLM id after set" +approvalDetailsObj.getUploadedOLMId());
			logger.info("paymemt mode after set "+approvalDetailsObj.getPaymentMode());
			logger.info("process type after set "+approvalDetailsObj.getProcessType());
            logger.info("circle after set is" +approvalDetailsObj.getCircle());
            logger.info("from date after set is" +approvalDetailsObj.getFromDate());
            logger.info("to date after set is" +approvalDetailsObj.getToDate());
            //SNo=activityDao.insertActivityLog(0,"CAD_ADMIN","Searching For LIU Records With The Given Details",null,null);
			//logger.info("First activity is");
			logger.info("mode Of payment wiht pagination in controller");

			List<String> modeOfPaymentList=approvaldao.getModeOfPayment();
			if(modeOfPaymentList==null)
			{
				modelAndViewObj.addObject("error", "Problem with Backend System");
				if("2".equalsIgnoreCase(role) )
					modelAndViewObj.setViewName("PAApprovals");
				else
					modelAndViewObj.setViewName("ExchangeAdviceApproval");
				//modelAndViewObj.setViewName("PAApprovals");
				return modelAndViewObj;
			}

			List<Circle> circleList=approvaldao.getCirclesList();
			if(circleList==null)
			{
				modelAndViewObj.addObject("error", "Problem with Backend System");
				if("2".equalsIgnoreCase(role) )
					modelAndViewObj.setViewName("PAApprovals");
				else
					modelAndViewObj.setViewName("ExchangeAdviceApproval");
				//modelAndViewObj.setViewName("PAApprovals");
				return modelAndViewObj;
			}
			// logger.info("modeOfPayment List" +modeOfPaymentList.size()+","+modeOfPaymentList.get(1)+","+modeOfPaymentList.get(2) );
			logger.info("payment advice process list in controller" );
			List<String> paymentAdviceProcessList=approvaldao.getPaymentAdviceProcessList();
			if(paymentAdviceProcessList==null)
			{
				modelAndViewObj.addObject("error", "Problem with Backend System");
				if("2".equalsIgnoreCase(role) )
					modelAndViewObj.setViewName("PAApprovals");
				else
					modelAndViewObj.setViewName("ExchangeAdviceApproval");
				//modelAndViewObj.setViewName("PAApprovals");
				return modelAndViewObj;
			}
			List<String> rejectReasonList=approvaldao.getRejectReasons();
			if(rejectReasonList==null)
			{
				modelAndViewObj.addObject("error", "Problem with Backend System");
				if("2".equalsIgnoreCase(role) )
					modelAndViewObj.setViewName("PAApprovals");
				else
					modelAndViewObj.setViewName("ExchangeAdviceApproval");
				//modelAndViewObj.setViewName("PAApprovals");
				return modelAndViewObj;
			}

			logger.info("payment advice process list size" +paymentAdviceProcessList.size());
			logger.info("all details in controller");
			HashMap<Integer, List<ApprovalDetails>> ApprovalDetailsMap = approvaldao.getApprovalDetails(pageNumber,approvalDetailsObj);
			String errorMsg=approvalDetailsObj.getErrorMessage();

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESSFULLY COMPLETED"))
				{
					errorMsg="";
				}
				else if(errorMsg.equalsIgnoreCase("FILES WITH SPECIFIED SEARCH CRITERIA NOT FOUND"))
				{
					errorMsg="No Pending Approvals to View.Please search with other criteria";
				}
				else
					errorMsg="No Records Found..";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(ApprovalDetailsMap==null)
			{

				errorMsg="Problem with Backend System while retrieving data";
				modelAndViewObj.addObject("errorMap", errorMsg);
				modelAndViewObj.addObject("modeOfPayList", modeOfPaymentList);
				modelAndViewObj.addObject("payAdviceProcessList", paymentAdviceProcessList);
				modelAndViewObj.addObject("rejectReasonList", rejectReasonList);
				modelAndViewObj.addObject("circleList", circleList);
				modelAndViewObj.addObject("approvalDetailsJspObj", approvalDetailsObj);
				if("2".equalsIgnoreCase(role))
					modelAndViewObj.setViewName("PAApprovals");
				else
					modelAndViewObj.setViewName("ExchangeAdviceApproval");
				//modelAndViewObj.setViewName("PAApprovals");
				return modelAndViewObj;
			}





			Set mapSet = (Set) ApprovalDetailsMap.entrySet();
			int totalPages=0;
			logger.info("length is" +ApprovalDetailsMap.size());
			//Create iterator on Set 
			Iterator mapIterator = mapSet.iterator();
			List<ApprovalDetails> ApprovalsDetailsList=null;
			while (mapIterator.hasNext()) 

			{
				Map.Entry<Integer,List<ApprovalDetails>> mapEntry = (Map.Entry<Integer,List<ApprovalDetails>>) mapIterator.next();
				// getKey Method of HashMap access a key of map
				totalPages=mapEntry.getKey();

				//getValue method returns corresponding key's value
				ApprovalsDetailsList=(List<ApprovalDetails>) mapEntry.getValue();
				logger.info("Key in controller: " + totalPages + "listsize : " + ApprovalsDetailsList.size());
			}

			logger.info("Key in controller: " + totalPages + "listsize : " + ApprovalsDetailsList.size());  
			logger.info("page number is :"  +pageNumber);

			logger.info("hashmap key 0 size" +ApprovalDetailsMap.isEmpty());
			Set s=ApprovalDetailsMap.keySet();
			int size=0;
			Iterator i=s.iterator();
			while(i.hasNext())
			{
				List<ApprovalDetails> a=ApprovalDetailsMap.get(i.next());
				size=a.size();
				// logger.info("hashmap values"+a.get(0).getRequestID());
			}
			logger.info("page number is :"  +pageNumber);
			modelAndViewObj.addObject("size",size);


			logger.info("key size is .." +ApprovalDetailsMap.size());	 
			modelAndViewObj.addObject("key", totalPages); 
			modelAndViewObj.addObject("ApprovalDetailsMapObj", ApprovalDetailsMap);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("error", "");
			modelAndViewObj.addObject("errorMap", errorMsg);
			modelAndViewObj.addObject("modeOfPayList", modeOfPaymentList);
			modelAndViewObj.addObject("payAdviceProcessList", paymentAdviceProcessList);
			modelAndViewObj.addObject("rejectReasonList", rejectReasonList);
			modelAndViewObj.addObject("circleList", circleList);
			 modelAndViewObj.addObject("approvalDetailsJspObj", approvalDetailsObj);




			logger.info("Model view page is:"+modelAndViewObj.getViewName());
			logger.info("Context is"+request.getContextPath());
			logger.info("Executed default page @controller");
			if("2".equalsIgnoreCase(role) )
				modelAndViewObj.setViewName("PAApprovals");
			else
				modelAndViewObj.setViewName("ExchangeAdviceApproval");
			//modelAndViewObj.setViewName("PAApprovals");
			//return modelAndViewObj;
	}
		catch (Exception e) {
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		return modelAndViewObj;
	}
	
	
	

	
	@RequestMapping(value = "/getCustomerType")
	public ModelAndView getCustomerType(ModelMap model,HttpServletRequest request, HttpServletResponse response)
	{
		ModelAndView modelAndViewObj = new ModelAndView();
		
         int custTypeId=0;
	  try
		{
		
      	custTypeId=Integer.parseInt(request.getParameter("custId"));		
	logger.info("customer id is " +custTypeId);
	
	approvalDetailsObj.setRequestID(custTypeId);
	
      
	
	String customerType=approvaldao.getCustomerType(approvalDetailsObj.getRequestID());
	
	logger.info("customer type is" +customerType);
		modelAndViewObj.addObject("customerType", customerType);
		modelAndViewObj.setViewName("PAApprovals");
		
}
	catch (Exception e) {
		logger.info(e.getLocalizedMessage());
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
	return modelAndViewObj;
}
	
	
	
	
	@RequestMapping(value = "/Approve")
	public ModelAndView Approve(ModelMap model,HttpServletRequest request, HttpServletResponse response)
	{
		ModelAndView modelAndViewObj = new ModelAndView();
		ApprovalDetails approveObj=new ApprovalDetails();
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String userName=session.getAttribute("uname").toString();
		String sessionId=session.getId();
		String role = session.getAttribute("user_role_id").toString();
		List<ApprovalDetails> approveReqIdObjList= new ArrayList<ApprovalDetails>();

		List<ApprovalDetails> approveFinalList= new ArrayList<ApprovalDetails>();


	  try
		{
		logger.info("Entered into  appproved@controller");
		 Long SNo=activityDao.insertActivityLog(0l,userId,"Payment Advice Approval",null,null,null,null,null);
		
			String selectedValue=request.getParameter("approvalString");
		
			logger.info("selected  value is:" +selectedValue );
			
			String[] reqId = request.getParameterValues("selectedRadio");
			
		
			 List<String> UpdatedValues=new ArrayList<String>();
	 		 
			 if(reqId!=null)
				{
					 	  for(int i=0;i<reqId.length;i++){
                      	 
						  ApprovalDetails approveUpdateObj=new ApprovalDetails();
						  String commentName=reqId[i]+"_comment";	
						  logger.info("comment name is" +commentName);
						  String comment=request.getParameter(commentName);
						  logger.info("comment is " +comment);
						  
						  
						  
						  approveUpdateObj.setRequestID(Long.parseLong(reqId[i]));
						  approveUpdateObj.setNotes(comment);
						  approveUpdateObj.setB2b_b2c(null);
						  approveUpdateObj.setInvalidRecordCount(0);
						  approveUpdateObj.setRequestStatus(null);
						  
						  approveReqIdObjList.add(approveUpdateObj);
					  }						  
						  
				}	  
						  
		
			String ApprovalValue=selectedValue.split("\\$")[1];
			approveObj.setApprovalStatus(ApprovalValue);
			approveObj.setRejectReason(null);
			approveObj.setApprovedName(userName);
            approveObj.setApprovedOLMId(userId);			
		  			
		
			
			logger.info("approval value is...."+approveObj.getApprovalStatus());

			approveFinalList=approvaldao.BulkApproveAndReject(approveReqIdObjList,approveObj,role);

			logger.info("approved result");
			for(int j=0;j<approveFinalList.size();j++){	
				if(approveFinalList.get(j).getRequestStatus()!=null && approveFinalList.get(j).getRequestStatus().equalsIgnoreCase("SUCCESS"))
				{
					logger.info("bloc1 >>>>>");
					SNo=activityDao.insertActivityLog(SNo,userId,"Payment Advice Approval","Success","Payment Advice Approved",null,null,null);

				}
				//----- to be mapped here and stopn the mail also
				else{
					logger.info("bloc2 >>>>>");
					SNo=activityDao.insertActivityLog(SNo,userId,"Payment Advice Approval","Failure","Payment Advice is NOT Approved",null,null,null);

				}
			}
			//	logger.info(approvedObj.getStatus()+""+approvedObj.getUploadedDate());
			//SNo=activityDao.insertActivityLog(0,"CAD_ADMIN","Searching For LIU Records With The Given Details",null,null);
			//logger.info("First activity is");
			File fileObj=new File(homePath+"/Conf/EmailAlertsTemplates/PaymentAdviceApprovalApprove.properties");
			InputStream inputStream=new FileInputStream(fileObj);
			Properties properties=new Properties();
			properties.load(inputStream);


			//******************************mail******************************
			String ApproverEmailId=approvaldao.getApproverEmailId(userId);


			for(int i=0;i<approveFinalList.size();i++){	
				logger.info("approveFinalList.get(i).getRequestID()>>" +approveFinalList.get(i).getRequestID());
				logger.info("approveFinalList.get(i).getRequestStatus()>>" +approveFinalList.get(i).getRequestStatus());
				if(!"NOT APPROVED AS EXCHANGE RATE IS REQUIRED FOR SOME UTRS".equalsIgnoreCase(approveFinalList.get(i).getRequestStatus())
						 && !((approveFinalList.get(i).getRequestStatus()).contains("Action already taken by some other user"))){
					
					if((approveFinalList.get(i).getRequestStatus()).contains("CAD APPROVED SUCCESS")){
					 fileObj=new File(homePath+"/Conf/EmailAlertsTemplates/PaymentAdviceApprovalApprove.properties");
					 inputStream=new FileInputStream(fileObj);
					}
					
					if((approveFinalList.get(i).getRequestStatus()).contains("CAD SUPERVISOR APPROVED")){
						 fileObj=new File(homePath+"/Conf/EmailAlertsTemplates/PaymentAdviceApprovalSupervisorApprove.properties");
						 inputStream=new FileInputStream(fileObj);
						}
					
					properties.load(inputStream);
				
					
					EMailContent emailContentObj=new EMailContent();
					logger.info("11approveFinalList.get(i).getRequestID()>>" +approveFinalList.get(i).getRequestID());
					emailContentObj.setEmailSubject(properties.getProperty("EmailSubject").replace("Ticket no.:", Long.toString(approveFinalList.get(i).getRequestID())));
					emailContentObj.setEmailHeader(properties.getProperty("EmailHeader"));		
					emailContentObj.setEmailBody(properties.getProperty("EmailBody").replace("Ticket no.:","Ticket no.:"+""+Long.toString(approveFinalList.get(i).getRequestID()))
							.replace("Total Records:","Total Records :"+""+approveFinalList.get(i).getTotalRecords()).replace("Total Value:", "Total Value: "+""+approveFinalList.get(i).getTotalAmount()));
					emailContentObj.setEmailFooter(properties.getProperty("EmailFooter"));

					logger.info("email subject is " +emailContentObj.getEmailSubject());
					logger.info("email body is " +emailContentObj.getEmailBody());
					List<String> emailToList=new ArrayList<String>();
					emailToList.add(approveFinalList.get(i).getAproveRejectEmailId());
					logger.info("uploaded email id" +approveFinalList.get(i).getAproveRejectEmailId());
					emailContentObj.setEmailToList(emailToList);


					List<String> emailCCList=new ArrayList<String>();
					emailCCList.add(ApproverEmailId);

					emailContentObj.setEmailCCList(emailCCList);

					//emailContentObj.setEmailBCCList(emailCCList);

					emailContentObj.setAttachmentRequired(false);

					SmtpUtility.setLogger(logger);

					SmtpMailContent smtpMailContentObj=SmtpUtility.generateEmailAlert(emailContentObj);
					logger.info("Error Code "+smtpMailContentObj.getErrorCode());
					logger.info(" Error Message "+smtpMailContentObj.getErrorMessage());
				}
			}

			//******************************mail tbc******************************


			/*List<String> emailCCList=new ArrayList<String>();
			emailCCList.add("chaitanya.yandrapalli@tcs.com");
			emailCCList.add("teja.illa@tcs.com");
			
			emailContentObj.setEmailCCList(emailCCList);
			
			emailContentObj.setEmailBCCList(emailCCList);*/
			
			//emailContentObj.setAttachmentRequired(false);
			
			/*List<EmailAttachment> emailAttachmentList=new ArrayList<EmailAttachment>();
			
			EmailAttachment emailAttachmentObj1=new EmailAttachment();
			emailAttachmentObj1.setAttachmentName("Plus_Button.png");
			emailAttachmentObj1.setAttachmentPath(homeDirectory);
			emailAttachmentList.add(emailAttachmentObj1);
			
			EmailAttachment emailAttachmentObj2=new EmailAttachment();
			emailAttachmentObj2=new EmailAttachment();
			emailAttachmentObj2.setAttachmentName("Payment_Advice_Upload.xls");
			emailAttachmentObj2.setAttachmentPath(homeDirectory);
			emailAttachmentList.add(emailAttachmentObj2);
			
			
			EmailAttachment emailAttachmentObj3=new EmailAttachment();
			emailAttachmentObj3.setAttachmentPath(homeDirectory);
			emailAttachmentObj3.setAttachmentName("CPS Functionality Document _ 1705.pdf");
			emailAttachmentList.add(emailAttachmentObj3);
			
			EmailAttachment emailAttachmentObj4=new EmailAttachment();
			emailAttachmentObj4=new EmailAttachment();
			emailAttachmentObj4.setAttachmentPath(homeDirectory);
			emailAttachmentObj4.setAttachmentName("Minstatmbc ppt.odp");
			emailAttachmentList.add(emailAttachmentObj4);
			
			emailContentObj.setEmailAttachmentList(emailAttachmentList);
			*/
			
             //SmtpUtility.setLogger(logger);
			
			/*SmtpMailContent smtpMailContentObj=SmtpUtility.generateEmailAlert(emailContentObj);
			
			logger.info("Error Code "+smtpMailContentObj.getErrorCode());
			logger.info(" Error Message "+smtpMailContentObj.getErrorMessage());
	*/
			modelAndViewObj.addObject("approveFinalListDetails", approveFinalList);
			modelAndViewObj.addObject("userType", role);
			modelAndViewObj.setViewName("PAApproved");
			
	}
		catch (Exception e) {
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		return modelAndViewObj;
	}
	
	
	
	@RequestMapping(value = "/Reject")
	public ModelAndView Reject(ModelMap model,HttpServletRequest request, HttpServletResponse response)
	

	{
		ModelAndView modelAndViewObj = new ModelAndView();
		ApprovalDetails rejectobj=new ApprovalDetails();
		
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String userName=session.getAttribute("uname").toString();
		String sessionId=session.getId();
		String role = session.getAttribute("user_role_id").toString();
		  List<ApprovalDetails> rejectReqIdObjList= new ArrayList<ApprovalDetails>();
		  
		  List<ApprovalDetails> rejectFinalList= new ArrayList<ApprovalDetails>();

		  try
			{
			logger.info("Entered into  reject@controller");
			 Long SNo=activityDao.insertActivityLog(0l,userId,"Payment Advice Rejection",null,null,null,null,null);
	
				String selectedValue=request.getParameter("approvalString");
			
				logger.info("selected  value is:" +selectedValue );
				
				Long requestId=Long.parseLong(selectedValue.split("\\$")[0]);
				
				String ApprovalValue=selectedValue.split("\\$")[1];
				String rejectReason=request.getParameter("rejectrReasonHidden");
				String rejectReasonDropDown=request.getParameter("rejectReasonDropDownhidden");
				
				rejectobj.setRequestID(requestId);
				rejectobj.setApprovalStatus(ApprovalValue);
				rejectobj.setRejectReason(rejectReason);
				rejectobj.setDropDownRejectReason(rejectReasonDropDown);
				
				rejectobj.setApprovedName(userName);
				rejectobj.setApprovedOLMId(userId);
				
		       logger.info("reject reason is" +rejectReason);   
				logger.info("request id is..." +rejectobj.getRequestID());
				logger.info("approval value is...."+rejectobj.getApprovalStatus());
				
				
				String[] reqRejectId = request.getParameterValues("selectedRadio");
				
				
		 		 
			 	if(reqRejectId!=null)
					{
						 	  for(int i=0;i<reqRejectId.length;i++){
				 
							  ApprovalDetails approveUpdateObj=new ApprovalDetails();
							  String commentName=reqRejectId[i]+"_comment";	
							  logger.info("comment name is" +commentName);
							  String comment=request.getParameter(commentName);
							  logger.info("comment is " +comment);
							  
							  approveUpdateObj.setRequestID(Integer.parseInt(reqRejectId[i]));
							  approveUpdateObj.setNotes(comment);
							  approveUpdateObj.setB2b_b2c(null);
							  approveUpdateObj.setInvalidRecordCount(0);
							  approveUpdateObj.setRequestStatus(null);
							  
							  rejectReqIdObjList.add(approveUpdateObj);
						  }						  
							  
					}	  
							  
				
				
			rejectFinalList=approvaldao.BulkApproveAndReject(rejectReqIdObjList,rejectobj,role);
				
				logger.info("rejected result");
				for(int j=0;j<rejectFinalList.size();j++){	
					if(rejectFinalList.get(j).getRequestStatus()!=null && rejectFinalList.get(j).getRequestStatus().equalsIgnoreCase("SUCCESS"))
					{
		        		SNo=activityDao.insertActivityLog(SNo,userId,"Payment Advice Rejection","Success","Payment Advice Rejected",null,null,null);

					}
					else{
		        		SNo=activityDao.insertActivityLog(SNo,userId,"Payment Advice Rejection","Failure","Payment Advice is NOT Rejected",null,null,null);
						
					}
				}
			
			//SNo=activityDao.insertActivityLog(0,"CAD_ADMIN","Searching For LIU Records With The Given Details",null,null);
			//logger.info("First activity is");
				File fileObj=new File(homePath+"/Conf/EmailAlertsTemplates/PaymentAdviceApprovalReject.properties");
				 InputStream inputStream=new FileInputStream(fileObj);
				 Properties properties=new Properties();
				 properties.load(inputStream);		
				
		
				 
				 //******************************mail******************************
				 String ApproverEmailId=approvaldao.getApproverEmailId(userId);
				 
				 
				 for(int i=0;i<rejectFinalList.size();i++){		
				if (!((rejectFinalList.get(i).getRequestStatus()).contains("Action already taken by some other user"))){
					
					if((rejectFinalList.get(i).getRequestStatus()).contains("CAD REJECTED")){
						 fileObj=new File(homePath+"/Conf/EmailAlertsTemplates/PaymentAdviceApprovalReject.properties");
						 inputStream=new FileInputStream(fileObj);
						}
						
						if((rejectFinalList.get(i).getRequestStatus()).contains("CAD SUPERVISOR REJECTED")){
							 fileObj=new File(homePath+"/Conf/EmailAlertsTemplates/PaymentAdviceApprovalSupervisorReject.properties");
							 inputStream=new FileInputStream(fileObj);
							}
						
						properties.load(inputStream);

					 
	            EMailContent emailContentObj=new EMailContent();
	         
				emailContentObj.setEmailSubject(properties.getProperty("EmailSubject").replace("Ticket no.:",Long.toString(rejectFinalList.get(i).getRequestID())));
				emailContentObj.setEmailHeader(properties.getProperty("EmailHeader"));	
				logger.info("rejectobj.getDropDownRejectReason()" +rejectobj.getDropDownRejectReason());
				emailContentObj.setEmailBody(properties.getProperty("EmailBody").replace("Ticket no.:","Ticket no.:"+""+Long.toString(rejectFinalList.get(i).getRequestID())).replace("reason:", "reason:"+""+rejectobj.getDropDownRejectReason()).replace("rejectionRemarks:","Rejection remarks:" +rejectFinalList.get(i).getRejectReason())
						.replace("Total Records:","Total Records :"+""+rejectFinalList.get(i).getTotalRecords()).replace("Total Value:", "Total Value: "+""+rejectFinalList.get(i).getTotalAmount()));
				emailContentObj.setEmailFooter(properties.getProperty("EmailFooter"));
				
				logger.info("email sub is " +emailContentObj.getEmailSubject());
				logger.info("email body is " +emailContentObj.getEmailBody());
				List<String> emailToList=new ArrayList<String>();
				emailToList.add(rejectFinalList.get(i).getAproveRejectEmailId());
				logger.info("uploaded email id" +rejectFinalList.get(i).getAproveRejectEmailId());
				emailContentObj.setEmailToList(emailToList);
				
				
				List<String> emailCCList=new ArrayList<String>();
				emailCCList.add(ApproverEmailId);
				
				emailContentObj.setEmailCCList(emailCCList);
				
				//emailContentObj.setEmailBCCList(emailCCList);
				
				emailContentObj.setAttachmentRequired(false);
				
	            SmtpUtility.setLogger(logger);
				
				SmtpMailContent smtpMailContentObj=SmtpUtility.generateEmailAlert(emailContentObj);
				logger.info("Error Code "+smtpMailContentObj.getErrorCode());
				logger.info(" Error Message "+smtpMailContentObj.getErrorMessage());
			 }	
			}
				 
				 
				 //******************************mail tbc******************************
				 
			/*List<String> emailCCList=new ArrayList<String>();
			emailCCList.add("chaitanya.yandrapalli@tcs.com");
			emailCCList.add("teja.illa@tcs.com");
			
			emailContentObj.setEmailCCList(emailCCList);
			
			emailContentObj.setEmailBCCList(emailCCList);*/
			
			//emailContentObj.setAttachmentRequired(false);
			
			/*List<EmailAttachment> emailAttachmentList=new ArrayList<EmailAttachment>();
			
			EmailAttachment emailAttachmentObj1=new EmailAttachment();
			emailAttachmentObj1.setAttachmentName("Plus_Button.png");
			emailAttachmentObj1.setAttachmentPath(homeDirectory);
			emailAttachmentList.add(emailAttachmentObj1);
			
			EmailAttachment emailAttachmentObj2=new EmailAttachment();
			emailAttachmentObj2=new EmailAttachment();
			emailAttachmentObj2.setAttachmentName("Payment_Advice_Upload.xls");
			emailAttachmentObj2.setAttachmentPath(homeDirectory);
			emailAttachmentList.add(emailAttachmentObj2);
			
			
			EmailAttachment emailAttachmentObj3=new EmailAttachment();
			emailAttachmentObj3.setAttachmentPath(homeDirectory);
			emailAttachmentObj3.setAttachmentName("CPS Functionality Document _ 1705.pdf");
			emailAttachmentList.add(emailAttachmentObj3);
			
			EmailAttachment emailAttachmentObj4=new EmailAttachment();
			emailAttachmentObj4=new EmailAttachment();
			emailAttachmentObj4.setAttachmentPath(homeDirectory);
			emailAttachmentObj4.setAttachmentName("Minstatmbc ppt.odp");
			emailAttachmentList.add(emailAttachmentObj4);
			
			emailContentObj.setEmailAttachmentList(emailAttachmentList);
			*/
			
            //SmtpUtility.setLogger(logger);
			
			/*SmtpMailContent smtpMailContentObj=SmtpUtility.generateEmailAlert(emailContentObj);
			
			logger.info("Error Code "+smtpMailContentObj.getErrorCode());
			logger.info(" Error Message "+smtpMailContentObj.getErrorMessage());
			*/
			
			modelAndViewObj.addObject("rejectFinalList", rejectFinalList);
			modelAndViewObj.addObject("userType", role);
			modelAndViewObj.setViewName("PARejected");
			
	}
		catch (Exception e) {
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		return modelAndViewObj;
	}
	//payment advice update
	
	@RequestMapping(value = "/paymentAdviceUpdate")
	public ModelAndView paymentAdviceUpdate(ModelMap model,HttpServletRequest request, HttpServletResponse response)
	{
		ModelAndView modelAndViewObj = new ModelAndView();
		ApprovalDetails updateObj=new ApprovalDetails();
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String userName="update user name";
		String sessionId=session.getId();
		String role = session.getAttribute("user_role_id").toString();
		  List<ApprovalDetails> approveReqIdObjList= new ArrayList<ApprovalDetails>();
		  
		  List<ApprovalDetails> approveFinalList= new ArrayList<ApprovalDetails>();
		  

	  try
		{
		logger.info("Entered into  update@controller");
		 Long SNo=activityDao.insertActivityLog(0l,userId,"Payment Advice Updation",null,null,null,null,null);

			String selectedValue=request.getParameter("approvalString");
		
			logger.info("selected  value is:" +selectedValue );
			
			String[] reqId = request.getParameterValues("selectedRadio");

			 List<String> UpdatedValues=new ArrayList<String>();
	 		 
		 	if(reqId!=null)
				{
					 	  for(int i=0;i<reqId.length;i++){
                         	 
						  ApprovalDetails approveUpdateObj=new ApprovalDetails();
						  String commentName=reqId[i]+"_comment";	
						  logger.info("comment name is" +commentName);
						  String comment=request.getParameter(commentName);
						  logger.info("comment in update is " +comment);
 
						  approveUpdateObj.setRequestID(Long.parseLong(reqId[i]));
						  approveUpdateObj.setNotes(comment);
						  approveUpdateObj.setB2b_b2c(null);
						  approveUpdateObj.setInvalidRecordCount(0);
						  approveUpdateObj.setRequestStatus(null);
						  
						  approveReqIdObjList.add(approveUpdateObj);
					  }						  
						  
				}	  
						  
		 	logger.info("approval");
			String ApprovalValue=selectedValue.split("\\$")[1];
			updateObj.setApprovalStatus(ApprovalValue);
			updateObj.setRejectReason(null);
			updateObj.setApprovedName(userName);
			updateObj.setApprovedOLMId(userId);			
		
			
			logger.info("approval value is...."+updateObj.getApprovalStatus());
			
			approveFinalList=approvaldao.BulkApproveAndReject(approveReqIdObjList,updateObj,role);
			logger.info("approveFinalList.size()" +approveFinalList.size());
			
			
			for(int j=0;j<approveFinalList.size();j++){	
				if(approveFinalList.get(j).getRequestStatus()!=null && approveFinalList.get(j).getRequestStatus().equalsIgnoreCase("SUCCESS"))
				{
	        		SNo=activityDao.insertActivityLog(SNo,userId,"Payment Advice Updation","Success","Payment Advice Notes Updated",null,null,null);

				}
				else{
	        		SNo=activityDao.insertActivityLog(SNo,userId,"Payment Advice Updation","Failure","Payment Advice Notes is NOT Updated",null,null,null);
					
				}
			}
			/*logger.info("approveFinalList.get(0).getRequestStatus()" +approveFinalList.get(0).getRequestStatus());
			logger.info("approveFinalList.get(0).getRequestStatus()" +approveFinalList.get(0).getRequestID());*/

			logger.info("updated result");
			modelAndViewObj.addObject("approveFinalListDetails", approveFinalList);
			modelAndViewObj.addObject("userType", role);
			modelAndViewObj.setViewName("PAApproved");
			
	}
		catch (Exception e) {
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		return modelAndViewObj;
	}
	

	
	
	//download//
	
	@RequestMapping(value = "/paymentAdviceDownloadSPV", method = RequestMethod.GET)
	public void paymentAdviceDownloadSPV(HttpServletRequest request,
			HttpServletResponse response) throws IOException {

		try{
	    	  
	    	  logger.info("ENTERED INTO paymentAdviceDownloadSPV EXPORT TO EXCEL METHOD @ CONTROLLER");
	    		String extension="xlsx";
	    		String requestId = request.getParameter("FileId").split("\\$")[0];
		    	String paymentMode = request.getParameter("FileId").split("\\$")[1];
	            logger.info("requesid payment mode" +requestId+paymentMode);
	    	   
	    		session = request.getSession(true);
	    		String userId = session.getAttribute("userid").toString();
	    		String role = session.getAttribute("user_role_id").toString();
	    		
		        ApprovalDetails paymentAdviceFileObj=approvaldao.downloadPaymentAdviceFile(userId,requestId, paymentMode,extension);	
		    
	//*****create empty zip --->get payment advice file --->get support file ---> add files to zip ---> download zip******	        
		        
		        
		       //********************creating empty zip***************************** 
		        String zipFile = "Payment_Advice_"+requestId+"."+"zip";
		        ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(zipFile));
		        zip.putNextEntry(new ZipEntry(zipFile));
		        zip.closeEntry();
		        zip.flush();
		        zip.close();
				logger.info("successfully generated an empty zip file");
			  //*********************creating empty zip completed******************** 

				
			 //********************get payment advice file************************	
				logger.info("paymentAdviceHomePath" +paymentAdviceHomePath);
				String filename=paymentAdviceHomePath+ File.separator+"UploadedFiles"+File.separator+"Payment_Advice_"+requestId+"."+extension;
				     //filename="C:/Users/1004362/Desktop/A/"+"Payment_Advice_"+requestId+"."+extension;
				       logger.info("Filename:"+filename);	
			 //********************get payment advice file completed*******************	
               
				       
		    //******************get support file************************       
				String supportFileName="";
				//File supportFilesFolder = new File("C:/Users/1004362/Desktop/A");
				File supportFilesFolder = new File(paymentAdviceHomePath+File.separator+"UploadedFiles"+File.separator+"SupportFiles"+File.separator);
				File[] listOfSupportFiles = supportFilesFolder.listFiles();

			for (int i = 0; i < listOfSupportFiles.length; i++) {
				if (listOfSupportFiles[i].isFile()) {
					logger.info("support file found");
					supportFileName = "Payment_Advice_Support_File_"+ requestId;
					if (listOfSupportFiles[i].getName().contains(supportFileName)) {
						logger.info("contains Payment_Advice_Support_File_ in name");
						logger.info("support File"+ listOfSupportFiles[i].getName());
						supportFileName = paymentAdviceHomePath+ File.separator+"UploadedFiles"+File.separator+"SupportFiles"+File.separator+listOfSupportFiles[i].getName();
						// supportFileName="C:/Users/1004362/Desktop/A/"+listOfSupportFiles[i].getName();
						logger.info("support file after mentioning path is"+ supportFileName);
						break;
					} else {
						logger.info("file not found");
						supportFileName ="FILE_NOT_FOUND";
					}
				}
			}
				//**********************get support file completed******************************
					
			    
				logger.info("final payment advice file name is......" +filename);
				logger.info("final support file name is............." +supportFileName);
				
				
				//****************************adding files to zip********************************		
			List<String> srcFiles = new ArrayList<String>();
			srcFiles.add(filename);
			if (!(supportFileName.equalsIgnoreCase("FILE_NOT_FOUND"))) {
				srcFiles.add(supportFileName);
			}
			logger.info("src files size is" +srcFiles.size());
			byte[] buffer = new byte[10240];
			FileOutputStream fos = new FileOutputStream(zipFile);
			ZipOutputStream zos = new ZipOutputStream(fos);
			try {
				for (int i = 0; i < srcFiles.size(); i++) {
					File srcFile = new File(srcFiles.get(i));
					FileInputStream fis = new FileInputStream(srcFile);
					zos.putNextEntry(new ZipEntry(srcFile.getName()));
					int length;
					while ((length = fis.read(buffer)) > 0) {
						zos.write(buffer, 0, length);
					}
					zos.closeEntry();
					fis.close();
					if (!(srcFile.getName().contains("Payment_Advice_Support_File_"))) {
						srcFile.delete();
					}
					logger.info("successfully zipped the file");
				}
				zos.close();
			} catch (IOException ioe) {
				logger.info("Error creating zip file: " + ioe);
				logger.info(ioe.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				ioe.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
	//********************************adding files to zip completed*******************************
				
	//********************************download zip************************************************			
			ServletOutputStream out = response.getOutputStream();
			FileInputStream in = new FileInputStream(zipFile);
			logger.info("zip Input File name:" + in);
			response.setContentType("APPLICATION/OCTET-STREAM");
			response.addHeader("content-disposition", "attachment; filename="+ zipFile);
			logger.info("PROCESS COMPLETED AND FETCHED THE FILE @ CONTROLLER");
			int octet = 0;
			while ((octet = in.read()) != -1)
			out.write(octet);
			in.close();
			out.flush();
			out.close();
			response.flushBuffer();
			logger.info("finished execution of payment Advice download");

		} catch (Exception e) {
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
	//********************************download zip completed*********************************	

	}
	
	
		@RequestMapping(value = "/paymentAdviceDownload", method = RequestMethod.GET)
		public void paymentAdviceDownload(HttpServletRequest request,
				HttpServletResponse response) throws IOException {

			try{
		    	  
		    	  logger.info("ENTERED INTO paymentAdviceDownload EXPORT TO EXCEL METHOD @ CONTROLLER");
		    		String extension="xlsx";
		    		String requestId = request.getParameter("FileId").split("\\$")[0];
			    	String paymentMode = request.getParameter("FileId").split("\\$")[1];
		            logger.info("requesid payment mode" +requestId+paymentMode);
		    	   
		    		session = request.getSession(true);
		    		String userId = session.getAttribute("userid").toString();
		    		String role = session.getAttribute("user_role_id").toString();
		    		
			        ApprovalDetails paymentAdviceFileObj=approvaldao.downloadPaymentAdviceFile(userId,requestId, paymentMode,extension);	
			    
		//*****create empty zip --->get payment advice file --->get support file ---> add files to zip ---> download zip******	        
			        
			        
			       //********************creating empty zip***************************** 
			        String zipFile = "Payment_Advice_"+requestId+"."+"zip";
			        ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(zipFile));
			        zip.putNextEntry(new ZipEntry(zipFile));
			        zip.closeEntry();
			        zip.flush();
			        zip.close();
					logger.info("successfully generated an empty zip file");
				  //*********************creating empty zip completed******************** 

					
				 //********************get payment advice file************************	
					logger.info("paymentAdviceHomePath" +paymentAdviceHomePath);
					String filename=paymentAdviceHomePath+ File.separator+"UploadedFiles"+File.separator+"Payment_Advice_"+requestId+"."+extension;
					     //filename="C:/Users/1004362/Desktop/A/"+"Payment_Advice_"+requestId+"."+extension;
					       logger.info("Filename:"+filename);	
				 //********************get payment advice file completed*******************	
	               
					       
			    //******************get support file************************       
					String supportFileName="";
					//File supportFilesFolder = new File("C:/Users/1004362/Desktop/A");
					File supportFilesFolder = new File(paymentAdviceHomePath+File.separator+"UploadedFiles"+File.separator+"SupportFiles"+File.separator);
					File[] listOfSupportFiles = supportFilesFolder.listFiles();

				for (int i = 0; i < listOfSupportFiles.length; i++) {
					if (listOfSupportFiles[i].isFile()) {
						logger.info("support file found");
						supportFileName = "Payment_Advice_Support_File_"+ requestId;
						if (listOfSupportFiles[i].getName().contains(supportFileName)) {
							logger.info("contains Payment_Advice_Support_File_ in name");
							logger.info("support File"+ listOfSupportFiles[i].getName());
							supportFileName = paymentAdviceHomePath+ File.separator+"UploadedFiles"+File.separator+"SupportFiles"+File.separator+listOfSupportFiles[i].getName();
							// supportFileName="C:/Users/1004362/Desktop/A/"+listOfSupportFiles[i].getName();
							logger.info("support file after mentioning path is"+ supportFileName);
							break;
						} else {
							logger.info("file not found");
							supportFileName ="FILE_NOT_FOUND";
						}
					}
				}
					//**********************get support file completed******************************
						
				    
					logger.info("final payment advice file name is......" +filename);
					logger.info("final support file name is............." +supportFileName);
					
					
					//****************************adding files to zip********************************		
				List<String> srcFiles = new ArrayList<String>();
				srcFiles.add(filename);
				if (!(supportFileName.equalsIgnoreCase("FILE_NOT_FOUND"))) {
					srcFiles.add(supportFileName);
				}
				logger.info("src files size is" +srcFiles.size());
				byte[] buffer = new byte[10240];
				FileOutputStream fos = new FileOutputStream(zipFile);
				ZipOutputStream zos = new ZipOutputStream(fos);
				try {
					for (int i = 0; i < srcFiles.size(); i++) {
						File srcFile = new File(srcFiles.get(i));
						FileInputStream fis = new FileInputStream(srcFile);
						zos.putNextEntry(new ZipEntry(srcFile.getName()));
						int length;
						while ((length = fis.read(buffer)) > 0) {
							zos.write(buffer, 0, length);
						}
						zos.closeEntry();
						fis.close();
						if (!(srcFile.getName().contains("Payment_Advice_Support_File_"))) {
							srcFile.delete();
						}
						logger.info("successfully zipped the file");
					}
					zos.close();
				} catch (IOException ioe) {
					logger.info("Error creating zip file: " + ioe);
					logger.info(ioe.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					ioe.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
		//********************************adding files to zip completed*******************************
					
		//********************************download zip************************************************			
				ServletOutputStream out = response.getOutputStream();
				FileInputStream in = new FileInputStream(zipFile);
				logger.info("zip Input File name:" + in);
				response.setContentType("APPLICATION/OCTET-STREAM");
				response.addHeader("content-disposition", "attachment; filename="+ zipFile);
				logger.info("PROCESS COMPLETED AND FETCHED THE FILE @ CONTROLLER");
				int octet = 0;
				while ((octet = in.read()) != -1)
				out.write(octet);
				in.close();
				out.flush();
				out.close();
				response.flushBuffer();
				logger.info("finished execution of payment Advice download");

			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		//********************************download zip completed*********************************	

		}
	//download....//
	@RequestMapping(value = "/vc3")
	public ModelAndView paymentAdvice() {

		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("vendorCreation");
		return modelAndViewObj;

	}
	
	
	@RequestMapping(value = "/getUTRDetails", method = RequestMethod.POST)
	public @ResponseBody ApprovalDetails getUTRDetails(
			HttpServletRequest request, HttpServletResponse response) {
		//ApprovalDetails utrDetailsObj = new ApprovalDetails();
		logger.info("enterd into @controller getUTRdETAILS");
		ApprovalDetails UTRDetailsObj=new ApprovalDetails();
		List<ApprovalDetails> UTRDetailsList = new ArrayList<ApprovalDetails>();
		Long requestId= Long.parseLong(request.getParameter("hiddenRequestId"));
		logger.info("requestId is " +requestId);
		
		UTRDetailsList = approvaldao.getUTRDetailsRecords(requestId);
		logger.info("list size is" +UTRDetailsList.size());
		UTRDetailsObj.setUtrDetailsList(UTRDetailsList);
		
		
		
		logger.info("UTRDetailsList is" + UTRDetailsList.size());
		
		
		return UTRDetailsObj;
	}
	
	
	
	@RequestMapping(value = "/updateUTRRecords", method = RequestMethod.POST)
	public @ResponseBody ApprovalDetails updateUTRRecords(
			HttpServletRequest request, HttpServletResponse response) {
		
		ApprovalDetails exchangeRateDetailsObj=new ApprovalDetails();
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String userName="exchangerate update user name";
		String sessionId=session.getId();
		
		
		  List<ApprovalDetails> updateRecordsObjList= new ArrayList<ApprovalDetails>();
		  String exchangeRateRequestId=request.getParameter("exchangeRateRequestId");
		  logger.info("exchangeRateRequestId is...." +exchangeRateRequestId);
		  System.out.println(("exchangeRateRequestId is...." +exchangeRateRequestId));
		  List<ApprovalDetails> approveFinalList= new ArrayList<ApprovalDetails>();
		  

	  try
		{
		logger.info("Entered into  updateUTRRecords@controller");
  System.out.println("Entered into  updateUTRRecords@controller");
			
		
			
			 String[] keyValuePairs=request.getParameterValues("updatedExchangeValues");
			 
			 logger.info("KEY VALUES length:" +keyValuePairs.length);
			 
			 List<String> UpdatedValues=new ArrayList<String>();
			 
			 
//			/ List<String> UpdatedValues=new ArrayList<String>();
	 		 
		 	if(keyValuePairs!=null)
				{
					 	  for(int i=0;i<keyValuePairs.length;i++){
			 
						  ApprovalDetails exchangeRateUTRDetails=new ApprovalDetails();
						  
						  
						  int requestId=Integer.parseInt(exchangeRateRequestId);
					String utrNo=keyValuePairs[i].split("\\$")[0];
						  Double exchangeRate= Double.parseDouble(keyValuePairs[i].split("\\$")[1]);
						  exchangeRateUTRDetails.setRequestID(requestId);
					exchangeRateUTRDetails.setUtrNumber(utrNo);
						  exchangeRateUTRDetails.setNewExchangeRate(exchangeRate);
						  
						  updateRecordsObjList.add(exchangeRateUTRDetails);
					  }						  
						  
				}	  
						  
		 	
		 	/*String ApprovalValue=selectedValue.split("\\$")[1];
			approveObj.setApprovalStatus(ApprovalValue);
			approveObj.setRejectReason(null);
			approveObj.setApprovedName(userName);
            approveObj.setApprovedOLMId(userId);	*/
		 	exchangeRateDetailsObj.setApprovedOLMId(userId);
		 	exchangeRateDetailsObj.setSessionId(sessionId);

		 	
			
			//ApprovalDetails exchangeRateUpdateResult=approvaldao.exchangeRateUpdate(updateRecordsObjList,exchangeRateDetailsObj);
		 	exchangeRateDetailsObj=approvaldao.exchangeRateUpdate(updateRecordsObjList,exchangeRateDetailsObj);
		 	
		 	logger.info("exchange rate update");
	}
	  catch (Exception e) {
		  logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
	
	  
	  
	  return exchangeRateDetailsObj;

	}
/////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////
	
	
	
	
	@RequestMapping(value = "/ajaxdefaultPage")
	public ModelAndView  defaultPage(ModelMap model,HttpServletRequest request, HttpServletResponse response)

	{
		ModelAndView modelAndViewObj = new ModelAndView();
		/*ApprovalDetails approvalDetailsObj=new ApprovalDetails();*/

	  try
		{
	      	logger.info("Entered into show appprovals default page @controller");

	
		//	logger.info("Entered in to else condition to check pagination");
			int pageNumber = 1;
			int totalPages=1;
			approvalDetailsObj.setPageNumber(pageNumber);
			approvalDetailsObj.setPaymentMode(null);
			approvalDetailsObj.setProcessType(null);
			approvalDetailsObj.setUploadedOLMId(null);
			
			
			//SNo=activityDao.insertActivityLog(0,"CAD_ADMIN","Searching For LIU Records With The Given Details",null,null);
			//logger.info("First activity is");
			logger.info("mode Of payment in controller");
			
			  List<String> modeOfPaymentList=approvaldao.getModeOfPayment();
			 /* if(modeOfPaymentList==null)
				 {
					 modelAndViewObj.addObject("error", "No results Found!!!");
					 modelAndViewObj.setViewName("PAApprovals");
					 return modelAndViewObj;
				 }*/
			  logger.info("modeOfPayment List" +modeOfPaymentList.size()+","+modeOfPaymentList.get(1)+","+modeOfPaymentList.get(2) );
			  logger.info("payment advice process list in controller" );
			  List<String> paymentAdviceProcessList=approvaldao.getPaymentAdviceProcessList();
			 /* if(paymentAdviceProcessList==null)
				 {
					 modelAndViewObj.addObject("error", "No results Found!!!");
					 modelAndViewObj.setViewName("PAApprovals");
					 return modelAndViewObj;
				 }*/
			  logger.info("payment advice process list size" +paymentAdviceProcessList.size());
			  logger.info("all details in controller");
			  HashMap<Integer, List<ApprovalDetails>> ApprovalDetailsMap = approvaldao.getApprovalDetails(pageNumber,approvalDetailsObj);
			/*  if(ApprovalDetailsMap==null)
				 {
					 modelAndViewObj.addObject("error", "Data Entered Is Invalid!!!No results Found!!!");
					 modelAndViewObj.setViewName("PAApprovals");
					 return modelAndViewObj;
				 }*/
			 
			/*  List<String> errorMsg=approvaldao.getModeOfPayment();
	          if(errorMsg!=null)
	          {
				    modelAndViewObj.addObject("errorMsg", errorMsg);
				    modelAndViewObj.setViewName("PAApprovals");
				    return modelAndViewObj;
	          }*/
			  approvalDetailsObj.setModeOfPaymentList(modeOfPaymentList);
			  approvalDetailsObj.setPaymentAdviceProcessList(paymentAdviceProcessList);
			  approvalDetailsObj.setApprovalDetailsHashMap(ApprovalDetailsMap);
			  approvalDetailsObj.setTotalPages(totalPages);
			  
			  
			  
			 logger.info("hashmap key 0 size" +ApprovalDetailsMap.isEmpty());
			 logger.info("page number is :"  +pageNumber);
			
			 
		    modelAndViewObj.addObject("key", totalPages);                             
			modelAndViewObj.addObject("ApprovalDetailsMapObj", ApprovalDetailsMap);   
			modelAndViewObj.addObject("currentPage", pageNumber);                     
			modelAndViewObj.addObject("modeOfPayList", modeOfPaymentList);            
			modelAndViewObj.addObject("payAdviceProcessList", paymentAdviceProcessList);
			
			logger.info("Context is"+request.getContextPath());
			logger.info("Executed default page @controller");
			modelAndViewObj.setViewName("ajaxPAApprovals");
			
			
	}
		catch (Exception e) {
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
	  return modelAndViewObj;
	}
	

	
	/*
	@RequestMapping(value = "/ajaxRedirect")
	public @ResponseBody ApprovalDetails ajaxRedirect(HttpServletRequest request, HttpServletResponse response)
	{
		
		ApprovalDetails approveObj=new ApprovalDetails();

	  try
		{
		logger.info("Entered into  ajax redirect appproved@controller");
      			
		int pageNumber = 1;
		int totalPages=1;
		approveObj.setPageNumber(pageNumber);
		approveObj.setPaymentMode(null);
		approveObj.setProcessType(null);
		approveObj.setUploadedOLMId(null);
		//SNo=activityDao.insertActivityLog(0,"CAD_ADMIN","Searching For LIU Records With The Given Details",null,null);
		//logger.info("First activity is");
		logger.info("ajax redirect mode Of payment in controller");
		
		  List<String> modeOfPaymentList=approvaldao.getModeOfPayment();
		  if(modeOfPaymentList==null)
			 {
				 modelAndViewObj.addObject("error", "No results Found!!!");
				 modelAndViewObj.setViewName("PAApprovals");
				 return modelAndViewObj;
			 }
		  logger.info("modeOfPayment List" +modeOfPaymentList.size()+","+modeOfPaymentList.get(1)+","+modeOfPaymentList.get(2) );
		  logger.info("payment advice process list in controller" );
		  List<String> paymentAdviceProcessList=approvaldao.getPaymentAdviceProcessList();
		  if(paymentAdviceProcessList==null)
			 {
				 modelAndViewObj.addObject("error", "No results Found!!!");
				 modelAndViewObj.setViewName("PAApprovals");
				 return modelAndViewObj;
			 }
		  logger.info("payment advice process list size" +paymentAdviceProcessList.size());
		  logger.info("all details in controller");
		  HashMap<Integer, List<ApprovalDetails>> ApprovalDetailsMap = approvaldao.getApprovalDetails(pageNumber,approveObj);
		  if(ApprovalDetailsMap==null)
			 {
				 modelAndViewObj.addObject("error", "Data Entered Is Invalid!!!No results Found!!!");
				 modelAndViewObj.setViewName("PAApprovals");
				 return modelAndViewObj;
			 }
		 
		  List<String> errorMsg=approvaldao.getModeOfPayment();
          if(errorMsg!=null)
          {
			    modelAndViewObj.addObject("errorMsg", errorMsg);
			    modelAndViewObj.setViewName("PAApprovals");
			    return modelAndViewObj;
          }
		  approveObj.setModeOfPaymentList(modeOfPaymentList);
		  approveObj.setPaymentAdviceProcessList(paymentAdviceProcessList);
		  approveObj.setApprovalDetailsHashMap(ApprovalDetailsMap);
		  approveObj.setTotalPages(totalPages);
		  
		  
		  
		logger.info("ajax redirect hashmap key 0 size" +ApprovalDetailsMap.isEmpty());
		logger.info("ajax redirect page number is :"  +pageNumber);		
		logger.info("Context is"+request.getContextPath());
		logger.info("Executed ajax redirect page @controller");
		
		
		
		
	}
		catch (Exception e) {
			e.printStackTrace();
		}
		return approveObj;
	}
	
	
	@RequestMapping(value = "/ajaxApprove")
	public @ResponseBody ApprovalDetails ajaxApprove(HttpServletRequest request, HttpServletResponse response)
	{
		
		ApprovalDetails approveObj=new ApprovalDetails();

	  try
		{
		logger.info("Entered into  appproved@controller");
      			
			String selectedValue=request.getParameter("approvalString");
		
			logger.info("selected  value is:" +selectedValue );
			int requestId=Integer.parseInt(selectedValue.split("\\$")[0]);
			String ApprovalValue=selectedValue.split("\\$")[1];
			
			approveObj.setRequestID(requestId);
			approveObj.setApprovalStatus(ApprovalValue);
			approveObj.setRejectReason(null);
	        
			logger.info("request id is..." +approveObj.getRequestID());
			logger.info("approval value is...."+approveObj.getApprovalStatus());
			approveObj=approvaldao.ApproveAndReject(approveObj);
			logger.info("approved result");
			logger.info(approveObj.getStatus()+""+approveObj.getUploadedDate());
			//SNo=activityDao.insertActivityLog(0,"CAD_ADMIN","Searching For LIU Records With The Given Details",null,null);
			//logger.info("First activity is");
		
	}
		catch (Exception e) {
			e.printStackTrace();
		}
		return approveObj;
	}
	
	*/
	
	
	
	
	
	/*@RequestMapping(value = "/downloadPaymentAdviceFiles", method = RequestMethod.GET)
	public void downloadPaymentAdviceFiles(HttpServletRequest request,
			HttpServletResponse response) throws IOException {

		try{
	    	  
	    	  logger.info("ENTERED INTO downloadPaymentAdviceFiles EXPORT TO EXCEL METHOD @ CONTROLLER");
	    		String extension="xls";
	    		String requestId = request.getParameter("FileId").split("\\$")[0];
		    	//String paymentMode = request.getParameter("FileId").split("\\$")[1];
	            //logger.info("requesid payment mode" +requestId+paymentMode);
	    	   
	    		session = request.getSession(true);
	    		String userId = session.getAttribute("userid").toString();
	    		String role = session.getAttribute("user_role_id").toString();
	    		
		       // ApprovalDetails paymentAdviceFileObj=approvaldao.downloadPaymentAdviceFile(userId,requestId, paymentMode,extension);	
		    
	//*****create empty zip --->get payment advice file --->get support file ---> add files to zip ---> download zip******	        
		        
		        
		       //********************creating empty zip***************************** 
		        String zipFile = "Payment_Advice_Files_"+requestId+"."+"zip";
		        ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(zipFile));
		        zip.putNextEntry(new ZipEntry(zipFile));
		        zip.closeEntry();
		        zip.flush();
		        zip.close();
				logger.info("successfully generated an empty zip file");
			  //*********************creating empty zip completed******************** 

				
			 //********************get payment advice file************************	
				logger.info("paymentAdviceHomePath" +paymentAdviceHomePath);
				//String filename=paymentAdviceHomePath+ File.separator+"UploadedFiles"+File.separator+"InputFiles"+File.separator+"Payment_Advice_"+requestId+"."+extension;
				     //filename="C:/Users/1004362/Desktop/A/"+"Payment_Advice_"+requestId+"."+extension;
//				       /logger.info("Filename:"+filename);	
				       
				       
				       
				       String paymentAdviceFileName="";
						//File supportFilesFolder = new File("C:/Users/1004362/Desktop/A");
						File paymentAdviceFilesFolder = new File(paymentAdviceHomePath+ File.separator+"UploadedFiles"+File.separator+"InputFiles"+File.separator);
						File[] listOfpaymentAdviceFiles = paymentAdviceFilesFolder.listFiles();
				       
				       
				       
				       for (int i = 0; i < listOfpaymentAdviceFiles.length; i++) {
							if (listOfpaymentAdviceFiles[i].isFile()) {
								logger.info("paymentAdvice file found");
								paymentAdviceFileName = "Payment_Advice_Upload_File_"+ requestId;
								if (listOfpaymentAdviceFiles[i].getName().contains(paymentAdviceFileName)) {
									logger.info("contains Payment_Advice_Upload_File_ in name");
									logger.info("payment advice File"+ listOfpaymentAdviceFiles[i].getName());
									paymentAdviceFileName = paymentAdviceHomePath+ File.separator+"UploadedFiles"+File.separator+"InputFiles"+File.separator+listOfpaymentAdviceFiles[i].getName();
									// supportFileName="C:/Users/1004362/Desktop/A/"+listOfSupportFiles[i].getName();
									logger.info("support file after mentioning path is"+ paymentAdviceFileName);
									break;
								} else {
									logger.info("file not found");
									paymentAdviceFileName ="FILE_NOT_FOUND";
								}
							}
						}
				       
				       
				       
			 //********************get payment advice file completed*******************	
               
				       
		    //******************get support file************************       
				String supportFileName="";
				//File supportFilesFolder = new File("C:/Users/1004362/Desktop/A");
				File supportFilesFolder = new File(paymentAdviceHomePath+File.separator+"UploadedFiles"+File.separator+"SupportFiles"+File.separator);
				File[] listOfSupportFiles = supportFilesFolder.listFiles();

			for (int i = 0; i < listOfSupportFiles.length; i++) {
				if (listOfSupportFiles[i].isFile()) {
					logger.info("support file found");
					supportFileName = "Payment_Advice_Support_File_"+ requestId;
					if (listOfSupportFiles[i].getName().contains(supportFileName)) {
						logger.info("contains Payment_Advice_Support_File_ in name");
						logger.info("support File"+ listOfSupportFiles[i].getName());
						supportFileName = paymentAdviceHomePath+ File.separator+"UploadedFiles"+File.separator+"SupportFiles"+File.separator+listOfSupportFiles[i].getName();
						// supportFileName="C:/Users/1004362/Desktop/A/"+listOfSupportFiles[i].getName();
						logger.info("support file after mentioning path is"+ supportFileName);
						break;
					} else {
						logger.info("file not found");
						supportFileName ="FILE_NOT_FOUND";
					}
				}
			}
				//**********************get support file completed******************************
					
			    
				logger.info("final payment advice file name is......" +paymentAdviceFileName);
				logger.info("final support file name is............." +supportFileName);
				
				
				//****************************adding files to zip********************************		
			List<String> srcFiles = new ArrayList<String>();
			srcFiles.add(paymentAdviceFileName);
			if (!(supportFileName.equalsIgnoreCase("FILE_NOT_FOUND"))) {
				srcFiles.add(supportFileName);
			}
			logger.info("src files size is" +srcFiles.size());
			byte[] buffer = new byte[10240];
			FileOutputStream fos = new FileOutputStream(zipFile);
			ZipOutputStream zos = new ZipOutputStream(fos);
			try {
				for (int i = 0; i < srcFiles.size(); i++) {
					File srcFile = new File(srcFiles.get(i));
					FileInputStream fis = new FileInputStream(srcFile);
					zos.putNextEntry(new ZipEntry(srcFile.getName()));
					int length;
					while ((length = fis.read(buffer)) > 0) {
						zos.write(buffer, 0, length);
					}
					zos.closeEntry();
					fis.close();
					logger.info("successfully zipped the file");
				}
				zos.close();
			} catch (IOException ioe) {
				logger.info("Error creating zip file: " + ioe);
			}
	//********************************adding files to zip completed*******************************
				
	//********************************download zip************************************************			
			ServletOutputStream out = response.getOutputStream();
			FileInputStream in = new FileInputStream(zipFile);
			logger.info("zip Input File name:" + in);
			response.setContentType("APPLICATION/OCTET-STREAM");
			response.addHeader("content-disposition", "attachment; filename="+ zipFile);
			logger.info("PROCESS COMPLETED AND FETCHED THE FILE @ CONTROLLER");
			int octet = 0;
			while ((octet = in.read()) != -1)
			out.write(octet);
			in.close();
			out.flush();
			out.close();
			response.flushBuffer();
			logger.info("finished execution of payment Advice download");

		} catch (Exception e) {
			e.printStackTrace();
		}
	//********************************download zip completed*********************************	

	}
//download....//	
*/	
	//Added for payment exchange rate
	
	@RequestMapping(value = "/percentExRate")
	public void getExchangeRate(HttpServletRequest request,HttpServletResponse response)
	{
		try{
		 ObjectMapper mapper = null;
		 PrintWriter out = null;
		 String percentExRate="";
		 String ticketNumber = request.getParameter("ticketNumber");
		 mapper = new ObjectMapper();
		  response.setContentType("application/json");
		  out = response.getWriter();
		  System.out.println("in percent exchange Rate controller method");
			percentExRate=approvaldao.fetchExchangeRate(ticketNumber);
			System.out.println("After fetching controller method"+percentExRate);
		  mapper.writeValue(out, percentExRate);
		}
		catch(Exception e){
			logger.info("getExchangeRate exception");
		}
		
        
	/*  try
		{
		  System.out.println("in percent exchange Rate controller method");
		percentExRate=approvaldao.fetchExchangeRate(ticketNumber);
		System.out.println("After fetching controller method"+percentExRate);
	}
	catch (Exception e) {
		logger.info(e.getLocalizedMessage());
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}*/
	//return percentExRate;
}
	
	
	
	
	
}
