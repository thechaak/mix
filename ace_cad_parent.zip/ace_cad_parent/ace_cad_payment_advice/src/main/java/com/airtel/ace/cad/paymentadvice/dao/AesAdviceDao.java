package com.airtel.ace.cad.paymentadvice.dao;

import com.airtel.ace.cad.aesadvice.model.AESAdviceLock;
import com.airtel.ace.cad.aesadvice.model.AESAdviceRequest;
import com.airtel.ace.cad.aesadvice.model.AESAdviceUploadFields;
import com.airtel.ace.cad.aesadvice.model.AESDetails;
import com.airtel.ace.cad.aesadvice.model.AESVendorFileRecords;
import com.airtel.ace.cad.paymentadvice.model.Transaction;
import com.airtel.ace.cad.paymentadvice.model.UserDetails;
import com.airtel.acecad.bulkupload.dto.FileStatusDTO;
public interface AesAdviceDao {
	public AESDetails getPaymentDetails(AESDetails paymentDetails);
	AESDetails getAESAdviceAllowedForUser(AESDetails paymentDetails);
	AESAdviceLock checkLockOnAESDetails(AESAdviceLock paymentAdviceLockObj);
	AESAdviceLock acquireLockOnAESDetails(AESAdviceLock paymentAdviceLockObj);
	AESAdviceLock releaseLockOnAESDetails(AESAdviceLock paymentAdviceLockObj);
	void releaseAllLocks(String userId) ;
	AESAdviceUploadFields getAESAdviceUploadFields();
	AESAdviceUploadFields getAESAdviceUploadMandateFields(String paymentAdviceProcess);
	AESAdviceRequest getAESAdviceRequestId();
	Transaction getDataBaseConnection();
	Transaction closeDataBaseConnection(Transaction transactionObj);
	Transaction loadAESAdviceRequest(Transaction transactionObj,AESAdviceRequest paymentAdviceRequestObj);
	
	UserDetails getEmailAddress(UserDetails userDetailsObj);
	//public void updateSupportFileDetails(String supportFileName, String fileId,String fileIdentifier,String statusDescription,int statusCode);
	public void updateSupportFileDetails(String supportFileName, String fileId,String statusDescription,int statusCode);
	AESVendorFileRecords getAesBankStatementDetails(AESVendorFileRecords aesVendorFileRecordsDTO) throws Exception;
	public AESVendorFileRecords downloadsAESBankStatementReports(AESVendorFileRecords aesVendorFileRecordsDTO) throws Exception;
}
