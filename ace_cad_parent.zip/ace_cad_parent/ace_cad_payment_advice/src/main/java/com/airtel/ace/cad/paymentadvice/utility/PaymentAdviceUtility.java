/**
 * 
 */
package com.airtel.ace.cad.paymentadvice.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;

import com.airtel.ace.cad.paymentadvice.context.ApplicationContextProvider;
import com.airtel.ace.cad.paymentadvice.dao.PaymentAdviceDAO;
import com.airtel.ace.cad.paymentadvice.model.PaymentAdviceRequest;
import com.airtel.ace.cad.paymentadvice.model.Transaction;
import com.airtel.ace.cad.paymentadvice.model.UserDetails;
import com.airtel.acecad.bulkupload.dto.FileUploadResult;
import com.airtel.acecad.bulkupload.uploadfile.ExcelReader;
import com.airtel.acecad.model.EMailContent;
import com.airtel.acecad.model.SmtpMailContent;
import com.airtel.acecad.utility.SmtpUtility;

/**
 * @author 587111
 *
 */
public class PaymentAdviceUtility {

	@Autowired
	ExcelReader excelReader;
	private static Logger logger =LogManager.getLogger("paymentAdviceLogger");
	private static String paymentAdviceHomePath = System.getenv("PAYMENT_ADVICE_HOME");
	private static String aceCadHomePath = System.getenv("ACE_CAD_HOME");

	/**
	 * @param args
	 */
	public static void releaseLockOnPaymentDetails(String userId){
		logger.info(" Releasing payment details locked by user id "+userId);
		PaymentAdviceDAO paymentAdviceDAOObj = (PaymentAdviceDAO) ApplicationContextProvider.getApplicationContext().getBean("paymentAdviceDAOObj");
		paymentAdviceDAOObj.releaseAllLocks(userId);
		logger.info(" Released payment details locked by user id "+userId);
	}
	public static String getDateTime() {
		Date today = Calendar.getInstance().getTime();
		SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyyHHmmss");
		return formatter.format(today);
	}
	public static String getDateAndTime() {
		Date today = Calendar.getInstance().getTime();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		return formatter.format(today);
	}
	@SuppressWarnings("resource")
	public static String validateSheetName(String fileType,MultipartFile uploadedFile,String sheetName){
		String message = null;
		logger.info(" Inside validateSheetName");
		if(fileType.equalsIgnoreCase("XLS")){
			logger.info(" Inside XLS");
			InputStream excelFileToRead = null;
			HSSFWorkbook wb=null;
			try {
				
				excelFileToRead = (InputStream)uploadedFile.getInputStream();
				wb = new HSSFWorkbook(excelFileToRead);
				HSSFSheet sheet=wb.getSheet(sheetName);
				logger.info(excelFileToRead);
				logger.info(sheet);
				if(sheet!=null){
					message="SUCCESS";
					logger.info(message+" "+uploadedFile.getOriginalFilename());
				}
				else{
					
					message="expected sheet \""+sheetName+"\" not found in the file "+uploadedFile.getOriginalFilename()+", please rename the excel sheet and upload ";
					logger.info(message);
					return message;
				}
			}
			catch (FileNotFoundException e) {
				message=e.getLocalizedMessage();
				// TODO Auto-generated catch block
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				return message;
			}catch (IOException e) {
				message=e.getLocalizedMessage();
				logger.info(e.getLocalizedMessage());
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				return message;
			}
			finally{
				if(excelFileToRead!=null){
					try {
						excelFileToRead.close();
					} catch (IOException e) {
						logger.info(e.getLocalizedMessage());
						// TODO Auto-generated catch block
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
					}
				}
			}
		}
		else if(fileType.equalsIgnoreCase("XLSX")){
			InputStream excelFileToRead = null;
			XSSFWorkbook wb = null;
			try {
				excelFileToRead = (InputStream)uploadedFile.getInputStream();
				wb = new XSSFWorkbook(excelFileToRead);
				XSSFSheet sheet=wb.getSheet(sheetName);
				if(sheet!=null){
					message="SUCCESS";
					logger.info(message);
				}
				else{
					message="expected sheet \""+sheetName+"\" not found in the file "+uploadedFile.getOriginalFilename()+", please rename the excel sheet and upload ";
					logger.info(message);
					return message;
				}
			}
			catch (FileNotFoundException e) {
				message=e.getLocalizedMessage();
				// TODO Auto-generated catch block
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				return message;
			}catch (IOException e) {
				message=e.getLocalizedMessage();
				// TODO Auto-generated catch block
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				return message;
			}
			finally{
				if(excelFileToRead!=null){
					try {
						excelFileToRead.close();
					} catch (IOException e) {
						logger.info(e.getLocalizedMessage());
						// TODO Auto-generated catch block
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
					}
				}
			}
		}
		return message;
	}

	@SuppressWarnings("resource")
	public  PaymentAdviceRequest processFileData
	(PaymentAdviceDAO paymentAdviceDAOObj,String paymentAdviceProcess,String fileType
			,MultipartFile uploadedFile,String sheetName,ArrayList<String> refNumbersArray,
			String userId,MultipartFile paymentAdviceSupportFile,String userName,
			HashMap<String,String> paymentModeAndRefNumberMap,String paymentModeType,
			HashMap<String,String> bankAccountNumberAndRefNumberMap,Object[] obj){
		String message = null;
		//ExcelReader excelReader=new ExcelReader();
		
		PaymentAdviceRequest paymntAdvRequestObj=new PaymentAdviceRequest();
	
		FileUploadResult fileUpload =null;

		try{
			////////insert into status table before calling the excel reader file
			//utr level validation bankAccountNumberAndRefNumberMap->{CITIN17777419077=NEFTD2, 270H1701201801737=GEETA}
			logger.info("paymentModeAndRefNumberMap->"+paymentModeAndRefNumberMap+" bankAccountNumberAndRefNumberMap->"+bankAccountNumberAndRefNumberMap);
		
			if("NEFT BANK STATEMENT".equalsIgnoreCase(paymentModeType)){
				paymentModeType="NEFT";
			}
			
			fileUpload=excelReader.readFromExcelfile(uploadedFile.getOriginalFilename(),
					"PAFILE", "UI", userId, paymentAdviceProcess, uploadedFile.getInputStream(), 
					paymentModeType,bankAccountNumberAndRefNumberMap,obj);
			// or else update afre inserting detila is stats table

			if((fileUpload.getStatus()==1) &&  (fileUpload.getStatusDescription()!=null && (fileUpload.getStatusDescription().toUpperCase().contains("SUCCESS")))){
				

				//PaymentAdviceRequest paymentAdviceRequestObj=paymentAdviceDAOObj.getPaymentAdviceRequestId();
				PaymentAdviceRequest paymentAdviceRequestObj=new PaymentAdviceRequest();

				paymentAdviceRequestObj.setRequestId(Integer.valueOf(fileUpload.getFileId()));
				logger.info("request id generated" + paymentAdviceRequestObj.getRequestId());
				paymentAdviceRequestObj.setUploadedUserName(userName);
				paymentAdviceRequestObj.setRenamedUploadedFileName(renameFilename
						(uploadedFile.getOriginalFilename(),"UPLOAD",paymentAdviceRequestObj.getRequestId()));
				
				if(paymentAdviceSupportFile!=null&&paymentAdviceSupportFile.getOriginalFilename()!=""){
					paymentAdviceRequestObj.setOriginalSupportedFileName(paymentAdviceSupportFile.getOriginalFilename());
					paymentAdviceRequestObj.setRenamedSupportedFileName(renameFilename(paymentAdviceSupportFile.getOriginalFilename(),"SUPPORT",paymentAdviceRequestObj.getRequestId()));
				}
				Transaction transactionObj=paymentAdviceDAOObj.getDataBaseConnection();

				if(transactionObj!=null&&transactionObj.getErrorCode()!=null&&
						transactionObj.getErrorCode().equalsIgnoreCase("SUCCESS")){
					paymentAdviceRequestObj.setPaymentMode(paymentModeType);
					//inserting data in payment advice request fire an update query here  
					transactionObj=paymentAdviceDAOObj.loadPaymentAdviceRequest(transactionObj,
							paymentAdviceRequestObj);

				}
				else if(transactionObj!=null&&transactionObj.getErrorCode()!=null
						&&transactionObj.getErrorCode().equalsIgnoreCase("FAILURE")){
					message=transactionObj.getErrorMessage();
					message="Unable to establish database connection";
					paymntAdvRequestObj.setErrorCode("FAILURE");
					paymntAdvRequestObj.setErrorMessage(message);
					return paymntAdvRequestObj;
				}
				else{
					message=" invalid response received while making database connection";
					paymntAdvRequestObj.setErrorCode("FAILURE");
					paymntAdvRequestObj.setErrorMessage(message);
					return paymntAdvRequestObj;
				}
				//to be changed PAYMENT_ADVICE_PKG.updateRequestDetails update payment advice req id here in neft table
				//and remove from advice_eft_reversal_record proc
				//this to be added
				if(transactionObj!=null&&transactionObj.getErrorCode()!=null
						&&transactionObj.getErrorCode().equalsIgnoreCase("FAILURE")){
					
					message="Data Failue Issue while raising Advice Ticket.Kindly raise again";
					paymntAdvRequestObj.setErrorCode("FAILURE");
					paymntAdvRequestObj.setErrorMessage(message);
					return paymntAdvRequestObj;
					
				}

				String retMessage=transferFileToDestination(uploadedFile, paymentAdviceRequestObj.getRenamedUploadedFileName(), "UPLOAD");
				if(retMessage!=null&&retMessage.equalsIgnoreCase("SUCCESS")){
					if(paymentAdviceRequestObj.getRenamedSupportedFileName()!=null){
						retMessage=transferFileToDestination(paymentAdviceSupportFile, paymentAdviceRequestObj.getRenamedSupportedFileName(), "SUPPORT");
						if(retMessage!=null&&retMessage.equalsIgnoreCase("SUCCESS")){
							message="payment advice request has been raised successfully, request id "+paymentAdviceRequestObj.getRequestId();
							paymntAdvRequestObj.setErrorCode("SUCCESS");
							paymntAdvRequestObj.setErrorMessage(message);
							logger.info("request id with support file" +paymentAdviceRequestObj.getRequestId());
							paymntAdvRequestObj.setRequestId(paymentAdviceRequestObj.getRequestId());
							return paymntAdvRequestObj;
						}
						else if(retMessage!=null&&retMessage.equalsIgnoreCase("FAILURE")){
							message=" unable to save payment advice support file to the server location";
							paymntAdvRequestObj.setErrorCode("FAILURE");
							paymntAdvRequestObj.setErrorMessage(message);
							return paymntAdvRequestObj;
						}
						else{
							paymntAdvRequestObj.setErrorCode("FAILURE");
							paymntAdvRequestObj.setErrorMessage(retMessage);
							return paymntAdvRequestObj;
						}
					}
					message="payment advice request has been raised successfully, request id "+paymentAdviceRequestObj.getRequestId();
					logger.info("request id without support file" +paymentAdviceRequestObj.getRequestId());
					paymntAdvRequestObj.setRequestId(paymentAdviceRequestObj.getRequestId());
					paymntAdvRequestObj.setRenamedSupportedFileName(paymentAdviceRequestObj.getRenamedSupportedFileName());
					paymntAdvRequestObj.setOriginalSupportedFileName(paymentAdviceRequestObj.getOriginalSupportedFileName());
					paymntAdvRequestObj.setOriginalUploadedFileName(paymentAdviceRequestObj.getOriginalUploadedFileName());
					paymntAdvRequestObj.setRenamedUploadedFileName(paymentAdviceRequestObj.getRenamedUploadedFileName());
					paymntAdvRequestObj.setUploadedBy(paymentAdviceRequestObj.getUploadedBy());
					paymntAdvRequestObj.setErrorCode("SUCCESS");
					paymntAdvRequestObj.setErrorMessage(message);
					return paymntAdvRequestObj;
				}
				else if(retMessage!=null&&retMessage.equalsIgnoreCase("FAILURE")){
					message=" unable to save payment advice upload file to the server location";
					paymntAdvRequestObj.setErrorCode("FAILURE");
					paymntAdvRequestObj.setErrorMessage(message);
					return paymntAdvRequestObj;
				}
				else{
					paymntAdvRequestObj.setErrorCode("FAILURE");
					paymntAdvRequestObj.setErrorMessage(retMessage);
					return paymntAdvRequestObj;
				}

			}
			else{
				paymntAdvRequestObj.setErrorCode("FAILURE");
				paymntAdvRequestObj.setErrorMessage(fileUpload.getStatusDescription());
				return paymntAdvRequestObj;
			}
		}
		catch(Exception e)
		{
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		return paymntAdvRequestObj;
	}

	@SuppressWarnings("resource")
	public  PaymentAdviceRequest processFileDataPAB
	(PaymentAdviceDAO paymentAdviceDAOObj,String paymentAdviceProcess,String fileType
			,MultipartFile uploadedFile,String sheetName,ArrayList<String> refNumbersArray,
			String userId,
			/* MultipartFile paymentAdviceSupportFile, */String userName,
			HashMap<String,String> paymentModeAndRefNumberMap,String paymentModeType,
			HashMap<String,String> bankAccountNumberAndRefNumberMap,Object[] obj){
		String message = null;
		//ExcelReader excelReader=new ExcelReader();
		
		PaymentAdviceRequest paymntAdvRequestObj=new PaymentAdviceRequest();
	
		FileUploadResult fileUpload =null;

		try{
			////////insert into status table before calling the excel reader file
			//utr level validation bankAccountNumberAndRefNumberMap->{CITIN17777419077=NEFTD2, 270H1701201801737=GEETA}
			logger.info("paymentModeAndRefNumberMap->"+paymentModeAndRefNumberMap+" bankAccountNumberAndRefNumberMap->"+bankAccountNumberAndRefNumberMap);
		
			if("NEFT BANK STATEMENT".equalsIgnoreCase(paymentModeType)){
				paymentModeType="NEFT";
			}
			
			fileUpload=excelReader.readFromExcelfile(uploadedFile.getOriginalFilename(),
					"PAB", "UI", userId, paymentAdviceProcess, uploadedFile.getInputStream(), 
					paymentModeType,bankAccountNumberAndRefNumberMap,obj);
			// or else update afre inserting detila is stats table

			if((fileUpload.getStatus()==1) &&  (fileUpload.getStatusDescription()!=null && (fileUpload.getStatusDescription().toUpperCase().contains("SUCCESS")))){
				

				//PaymentAdviceRequest paymentAdviceRequestObj=paymentAdviceDAOObj.getPaymentAdviceRequestId();
				PaymentAdviceRequest paymentAdviceRequestObj=new PaymentAdviceRequest();

				paymentAdviceRequestObj.setRequestId(Integer.valueOf(fileUpload.getFileId()));
				logger.info("request id generated" + paymentAdviceRequestObj.getRequestId());
				paymentAdviceRequestObj.setUploadedUserName(userName);
				paymentAdviceRequestObj.setRenamedUploadedFileName(renameFilename
						(uploadedFile.getOriginalFilename(),"UPLOAD",paymentAdviceRequestObj.getRequestId()));
				
				/*//for Support File
				 * if(paymentAdviceSupportFile!=null&&paymentAdviceSupportFile.
				 * getOriginalFilename()!=""){
				 * paymentAdviceRequestObj.setOriginalSupportedFileName(paymentAdviceSupportFile
				 * .getOriginalFilename());
				 * paymentAdviceRequestObj.setRenamedSupportedFileName(renameFilename(
				 * paymentAdviceSupportFile.getOriginalFilename(),"SUPPORT",
				 * paymentAdviceRequestObj.getRequestId())); }
				 */
				Transaction transactionObj=paymentAdviceDAOObj.getDataBaseConnection();

				if(transactionObj!=null&&transactionObj.getErrorCode()!=null&&
						transactionObj.getErrorCode().equalsIgnoreCase("SUCCESS")){
					paymentAdviceRequestObj.setPaymentMode(paymentModeType);
					//inserting data in payment advice request fire an update query here  
					transactionObj=paymentAdviceDAOObj.loadPaymentAdviceRequest(transactionObj,
							paymentAdviceRequestObj);

				}
				else if(transactionObj!=null&&transactionObj.getErrorCode()!=null
						&&transactionObj.getErrorCode().equalsIgnoreCase("FAILURE")){
					message=transactionObj.getErrorMessage();
					message="Unable to establish database connection";
					paymntAdvRequestObj.setErrorCode("FAILURE");
					paymntAdvRequestObj.setErrorMessage(message);
					return paymntAdvRequestObj;
				}
				else{
					message=" invalid response received while making database connection";
					paymntAdvRequestObj.setErrorCode("FAILURE");
					paymntAdvRequestObj.setErrorMessage(message);
					return paymntAdvRequestObj;
				}
				//to be changed PAYMENT_ADVICE_PKG.updateRequestDetails update payment advice req id here in neft table
				//and remove from advice_eft_reversal_record proc
				//this to be added
				if(transactionObj!=null&&transactionObj.getErrorCode()!=null
						&&transactionObj.getErrorCode().equalsIgnoreCase("FAILURE")){
					
					message="Data Failue Issue while raising Advice Ticket.Kindly raise again";
					paymntAdvRequestObj.setErrorCode("FAILURE");
					paymntAdvRequestObj.setErrorMessage(message);
					return paymntAdvRequestObj;
					
				}

				String retMessage=transferFileToDestination(uploadedFile, paymentAdviceRequestObj.getRenamedUploadedFileName(), "UPLOAD");
				if(retMessage!=null&&retMessage.equalsIgnoreCase("SUCCESS")){
					/*if(paymentAdviceRequestObj.getRenamedSupportedFileName()!=null){
						retMessage=transferFileToDestination(paymentAdviceSupportFile, paymentAdviceRequestObj.getRenamedSupportedFileName(), "SUPPORT");*/
						if(retMessage!=null&&retMessage.equalsIgnoreCase("SUCCESS")){
							message="payment advice request has been raised successfully, request id "+paymentAdviceRequestObj.getRequestId();
							paymntAdvRequestObj.setErrorCode("SUCCESS");
							paymntAdvRequestObj.setErrorMessage(message);
							logger.info("request id with support file" +paymentAdviceRequestObj.getRequestId());
							paymntAdvRequestObj.setRequestId(paymentAdviceRequestObj.getRequestId());
							return paymntAdvRequestObj;
						}
						else if(retMessage!=null&&retMessage.equalsIgnoreCase("FAILURE")){
							message=" unable to save payment advice support file to the server location";
							paymntAdvRequestObj.setErrorCode("FAILURE");
							paymntAdvRequestObj.setErrorMessage(message);
							return paymntAdvRequestObj;
						}
						/*
						 * else{ paymntAdvRequestObj.setErrorCode("FAILURE");
						 * paymntAdvRequestObj.setErrorMessage(retMessage); return paymntAdvRequestObj;
						 * }
						 */
						/* } */
					message="payment advice request has been raised successfully, request id "+paymentAdviceRequestObj.getRequestId();
					logger.info("request id without support file" +paymentAdviceRequestObj.getRequestId());
					paymntAdvRequestObj.setRequestId(paymentAdviceRequestObj.getRequestId());
					paymntAdvRequestObj.setRenamedSupportedFileName(paymentAdviceRequestObj.getRenamedSupportedFileName());
					paymntAdvRequestObj.setOriginalSupportedFileName(paymentAdviceRequestObj.getOriginalSupportedFileName());
					paymntAdvRequestObj.setOriginalUploadedFileName(paymentAdviceRequestObj.getOriginalUploadedFileName());
					paymntAdvRequestObj.setRenamedUploadedFileName(paymentAdviceRequestObj.getRenamedUploadedFileName());
					paymntAdvRequestObj.setUploadedBy(paymentAdviceRequestObj.getUploadedBy());
					paymntAdvRequestObj.setErrorCode("SUCCESS");
					paymntAdvRequestObj.setErrorMessage(message);
					return paymntAdvRequestObj;
				}
				else if(retMessage!=null&&retMessage.equalsIgnoreCase("FAILURE")){
					message=" unable to save payment advice upload file to the server location";
					paymntAdvRequestObj.setErrorCode("FAILURE");
					paymntAdvRequestObj.setErrorMessage(message);
					return paymntAdvRequestObj;
				}
				else{
					paymntAdvRequestObj.setErrorCode("FAILURE");
					paymntAdvRequestObj.setErrorMessage(retMessage);
					return paymntAdvRequestObj;
				}

			}
			else{
				paymntAdvRequestObj.setErrorCode("FAILURE");
				paymntAdvRequestObj.setErrorMessage(fileUpload.getStatusDescription());
				return paymntAdvRequestObj;
			}
		}
		catch(Exception e)
		{
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		return paymntAdvRequestObj;
	}
	
	
	
	/*public static boolean isRowEmpty(Row row) {
		boolean rowEmpty;
		int emptyCellCount=0;
		//logger.info("Firstcellnum:"+row.getFirstCellNum());
        //logger.info("row.getCell() is:"+row.getCell(row.getFirstCellNum()));
	    for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
	    	//logger.info("c is:"+c);
	    	//logger.info("cell is:"+row.getCell(c));
	        Cell cell = row.getCell(c);
	        //logger.info("c is:"+c);
	        if(cell!=null)
	        cell.setCellType(Cell.CELL_TYPE_STRING);
	        if (cell != null&&cell.getStringCellValue()!=null&&cell.getStringCellValue().length()==0)
	        	emptyCellCount=emptyCellCount+1;
	    }
	    if(row.getPhysicalNumberOfCells()==emptyCellCount){
	    	rowEmpty=true;
	    }
	    else{
	    	rowEmpty=false;
	    }
	    return rowEmpty;
	}*/
	public static boolean isRowEmpty(Row row) {

		boolean rowEmpty;
		int emptyCellCount=0;
		for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
			Cell cell = row.getCell(c);
			//  System.out.println("row value is::"+c);
			/*commented to test exchange_rate garbage value from xlsx file*/
			/* if(cell!=null)
	        cell.setCellType(Cell.CELL_TYPE_STRING);*/

			//COMMENT ABOVE LINES IF NEEDED AFTER TESTING 
			if(cell!=null)
				//  System.out.println("celltypeenum:..." +cell.getCellTypeEnum());
				if(cell.getCellTypeEnum()==CellType.STRING || cell.getCellTypeEnum()==CellType.BLANK)
				{
					if (cell != null&&cell.getStringCellValue()!=null&& cell.getStringCellValue().trim().length()==0)
						emptyCellCount=emptyCellCount+1;
				}
				else if(cell.getCellTypeEnum()==CellType.NUMERIC)
				{
					if (cell != null&&cell.getNumericCellValue()==0)
					{
						emptyCellCount=emptyCellCount+1;
					}
				}

		}


		if(row.getPhysicalNumberOfCells()==emptyCellCount){
			rowEmpty=true;
		}
		else{
			rowEmpty=false;
		}

		return rowEmpty;

	}
	public static String renameFilename(String fileName,String fileType,int requestId){
		String renamedFileName=null;
		int lastIndex=fileName.lastIndexOf(".");
		if(fileType.equalsIgnoreCase("SUPPORT")){
			renamedFileName=fileName.replace(fileName.substring(0, lastIndex),"Payment_Advice_Support_File_"+requestId);
		}
		if(fileType.equalsIgnoreCase("UPLOAD")){
			renamedFileName=fileName.replace(fileName.substring(0, lastIndex),"Payment_Advice_Upload_File_"+requestId);
		}
		logger.info(" Renamed FileName "+renamedFileName);
		return renamedFileName;
	}
	public static String transferFileToDestination(MultipartFile fileName,String renamedFileName,String fileType){
		String message = "FAILURE";
		if(fileType.equalsIgnoreCase("UPLOAD")){
			String destination =paymentAdviceHomePath+"/UploadedFiles/InputFiles/"+renamedFileName;
			File file = new File(destination);
			try {
				fileName.transferTo(file);
				message="SUCCESS";
			} catch (IllegalStateException e) {
				message=" unable to save uploaded file in the server location, reason for the failure is "+e.getLocalizedMessage();
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			} catch (IOException e) {
				message=" unable to save uploaded file in the server location, reason for the failure is "+e.getLocalizedMessage();
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}
		if(fileType.equalsIgnoreCase("SUPPORT")){
			String destination =paymentAdviceHomePath+"/UploadedFiles/SupportFiles/"+renamedFileName;
			File file = new File(destination);
			try {
				fileName.transferTo(file);
				message="SUCCESS";
			} catch (IllegalStateException e) {
				message=" unable to save uploaded file in the server location, reason for the failure is "+e.getLocalizedMessage();
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			} catch (IOException e) {
				message=" unable to save uploaded file in the server location, reason for the failure is "+e.getLocalizedMessage();
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}
		return message;
	}
	public static BigDecimal convertToDecimal(float inputVal){
		BigDecimal roundBigDecimalValue = new BigDecimal(inputVal).setScale(4,BigDecimal.ROUND_HALF_UP);
		return roundBigDecimalValue;
	}
	public static EMailContent sendEmailAlert(PaymentAdviceDAO paymentAdviceDAOObj,PaymentAdviceRequest paymentRequestObj,UserDetails userDetailsObj,String alertType){
		logger.info("Inside sendEmailAlert ");
		EMailContent eMailContentObj=new EMailContent();
		File file=null;
		InputStream inputStream=null;
		Properties props=null;
		if(alertType!=null&&alertType.equalsIgnoreCase("FILE_LEVEL_VALIDATIONS_SUCCESS_ALERT")){
			file=new File(aceCadHomePath+"/Conf/EmailAlertsTemplates/PaymentAdviceRequestIdConfirmationAlert.properties");
			try {
				inputStream=new FileInputStream(file);
				props=new Properties();
				props.load(inputStream);
				logger.info("requet id in mail body " +paymentRequestObj.getRequestId());
				eMailContentObj.setEmailSubject(props.getProperty("emailSubject").replace("A",Long.toString(paymentRequestObj.getRequestId())));
				eMailContentObj.setEmailHeader(props.getProperty("emailHeader"));
				eMailContentObj.setEmailFooter(props.getProperty("emailFooter"));
				eMailContentObj.setEmailBody(props.getProperty("emailBody").replace("A",Integer.toString(paymentRequestObj.getRequestId())));

				//Comment for testing
				eMailContentObj.setSmtpFromAddress("APS_Payment_Advice@airtel.com");

				userDetailsObj=paymentAdviceDAOObj.getEmailAddress(userDetailsObj);
				if(userDetailsObj!=null&&userDetailsObj.getErrorCode()!=null&&userDetailsObj.getErrorCode().equalsIgnoreCase("SUCCESS")){

					List<String> emailToList=new ArrayList<String>();
					emailToList.add(userDetailsObj.getEmailAddress());
					eMailContentObj.setEmailToList(emailToList);

					eMailContentObj.setAttachmentRequired(false);
					logger.info("eMail body: "+eMailContentObj.getEmailBody());
					/*List<EmailAttachment> emailAttachmentList=new ArrayList<EmailAttachment>();

					EmailAttachment emailUploadedAttachmentObj=new EmailAttachment();
					emailUploadedAttachmentObj.setAttachmentName(paymentRequestObj.getRenamedUploadedFileName());
					emailUploadedAttachmentObj.setAttachmentPath(paymentAdviceHomePath+"/UploadedFiles/InputFiles");
					emailAttachmentList.add(emailUploadedAttachmentObj);

					EmailAttachment emailSupportAttachmentObj=new EmailAttachment();
					emailSupportAttachmentObj.setAttachmentName(paymentRequestObj.getRenamedSupportedFileName());
					emailSupportAttachmentObj.setAttachmentPath(paymentAdviceHomePath+"/UploadedFiles/SupportFiles");
					emailAttachmentList.add(emailSupportAttachmentObj);
					eMailContentObj.setEmailAttachmentList(emailAttachmentList);*/
					//SmtpUtility.setLogger(logger);
					SmtpMailContent smtpMailContentObj=SmtpUtility.generateEmailAlert(eMailContentObj);
					eMailContentObj.setErrorCode(smtpMailContentObj.getErrorCode());
					eMailContentObj.setErrorMessage(smtpMailContentObj.getErrorMessage());
					return eMailContentObj;
				}
				else if(userDetailsObj!=null&&userDetailsObj.getErrorCode()!=null&&userDetailsObj.getErrorCode().equalsIgnoreCase("FAILURE")){
					eMailContentObj.setErrorCode(userDetailsObj.getErrorCode());
					eMailContentObj.setErrorMessage(userDetailsObj.getErrorMessage());
					return eMailContentObj;
				}
				else{
					eMailContentObj.setErrorCode("FAILURE");
					eMailContentObj.setErrorMessage("Invalid response received while capturing user email address");
					return eMailContentObj;
				}
			} catch (FileNotFoundException e) {
				eMailContentObj.setErrorCode("FAILURE");
				eMailContentObj.setErrorMessage("Unable to sent email alert, reason for the failure is "+e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
			catch (IOException e) {
				eMailContentObj.setErrorCode("FAILURE");
				eMailContentObj.setErrorMessage("Unable to sent email alert, reason for the failure is "+e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		catch (Exception e) {
			eMailContentObj.setErrorCode("FAILURE");
			eMailContentObj.setErrorMessage("Unable to sent email alert, reason for the failure is "+e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		}

		if(alertType!=null&&alertType.equalsIgnoreCase("SYSTEM_LEVEL_VALIDATIONS_SUCCESS_ALERT")){

		}

		if(alertType!=null&&alertType.equalsIgnoreCase("SYSTEM_LEVEL_VALIDATIONS_FAILURE_ALERT")){

		}

		if(alertType!=null&&alertType.equalsIgnoreCase("APPROVAL_ALERT")){

		}

		if(alertType!=null&&alertType.equalsIgnoreCase("REJECTION_ALERT")){

		}

		if(alertType!=null&&alertType.equalsIgnoreCase("POSTING_CONFIRMATION_ALERT")){

		}
		return eMailContentObj; 
	}
	public static void main(String[] args) {
		/*float convertedValue1=Float.parseFloat("123.00026");
		BigDecimal roundfinalPrice1 = new BigDecimal(convertedValue1).setScale(4,BigDecimal.ROUND_HALF_UP);
		logger.info(" roundfinalPrice"+Float.parseFloat(roundfinalPrice1.toString()));

		float convertedValue2=Float.parseFloat("123.00071");
		BigDecimal roundfinalPrice2 = new BigDecimal(convertedValue2).setScale(4,BigDecimal.ROUND_HALF_UP);
		logger.info(" roundfinalPrice"+Float.parseFloat(roundfinalPrice2.toString()));*/
		try{
			int number = 0;
			//if(number.matches("^[0-9]*$") && number.length() <=10)

			if(number==1)
			{
				logger.info("valid invoice");
			}
			else{
				logger.info("INVALID invoice");
			}

		}

		catch(NumberFormatException e)
		{
			logger.info(e.getLocalizedMessage());
		}
	}

	//PABULK processing
	
	@SuppressWarnings("resource")
	public  PaymentAdviceRequest processPABulkFileData
	(PaymentAdviceDAO paymentAdviceDAOObj,String paymentAdviceProcess,String fileType
			,MultipartFile uploadedFile,String sheetName,
			String userId,MultipartFile paymentAdviceSupportFile,String userName){
		String message = null;
		String paymentModeType = null;
		//ExcelReader excelReader=new ExcelReader();
		
		PaymentAdviceRequest paymntAdvRequestObj=new PaymentAdviceRequest();
	
		FileUploadResult fileUpload =null;

		try{
			
			paymentModeType="NEFT";
			
			fileUpload=excelReader.readFromExcelfile(uploadedFile.getOriginalFilename(),
					"PAB", "UI", userId, paymentAdviceProcess, uploadedFile.getInputStream(), 
					"PABulk",null,null);
		
			if((fileUpload.getStatus()==1) &&  (fileUpload.getStatusDescription()!=null && (fileUpload.getStatusDescription().toUpperCase().contains("SUCCESS")))){
				

				//PaymentAdviceRequest paymentAdviceRequestObj=paymentAdviceDAOObj.getPaymentAdviceRequestId();
				PaymentAdviceRequest paymentAdviceRequestObj=new PaymentAdviceRequest();

				paymentAdviceRequestObj.setRequestId(Integer.valueOf(fileUpload.getFileId()));
				logger.info("request id generated" + paymentAdviceRequestObj.getRequestId());
				paymentAdviceRequestObj.setUploadedUserName(userName);
				paymentAdviceRequestObj.setRenamedUploadedFileName(renameFilename
						(uploadedFile.getOriginalFilename(),"UPLOAD",paymentAdviceRequestObj.getRequestId()));
				
				if(paymentAdviceSupportFile!=null&&paymentAdviceSupportFile.getOriginalFilename()!=""){
					paymentAdviceRequestObj.setOriginalSupportedFileName(paymentAdviceSupportFile.getOriginalFilename());
					paymentAdviceRequestObj.setRenamedSupportedFileName(renameFilename(paymentAdviceSupportFile.getOriginalFilename(),"SUPPORT",paymentAdviceRequestObj.getRequestId()));
				}
				Transaction transactionObj=paymentAdviceDAOObj.getDataBaseConnection();

				if(transactionObj!=null&&transactionObj.getErrorCode()!=null&&
						transactionObj.getErrorCode().equalsIgnoreCase("SUCCESS")){
					paymentAdviceRequestObj.setPaymentMode(paymentModeType);
					//inserting data in payment advice request fire an update query here  
					transactionObj=paymentAdviceDAOObj.loadPaymentAdviceRequest(transactionObj,
							paymentAdviceRequestObj);

				}
				else if(transactionObj!=null&&transactionObj.getErrorCode()!=null
						&&transactionObj.getErrorCode().equalsIgnoreCase("FAILURE")){
					message=transactionObj.getErrorMessage();
					message="Unable to establish database connection";
					paymntAdvRequestObj.setErrorCode("FAILURE");
					paymntAdvRequestObj.setErrorMessage(message);
					return paymntAdvRequestObj;
				}
				else{
					message=" invalid response received while making database connection";
					paymntAdvRequestObj.setErrorCode("FAILURE");
					paymntAdvRequestObj.setErrorMessage(message);
					return paymntAdvRequestObj;
				}
				//to be changed PAYMENT_ADVICE_PKG.updateRequestDetails update payment advice req id here in neft table
				//and remove from advice_eft_reversal_record proc
				//this to be added
				if(transactionObj!=null&&transactionObj.getErrorCode()!=null
						&&transactionObj.getErrorCode().equalsIgnoreCase("FAILURE")){
					
					message="Data Failue Issue while raising Advice Ticket.Kindly raise again";
					paymntAdvRequestObj.setErrorCode("FAILURE");
					paymntAdvRequestObj.setErrorMessage(message);
					return paymntAdvRequestObj;
					
				}

				String retMessage=transferFileToDestination(uploadedFile, paymentAdviceRequestObj.getRenamedUploadedFileName(), "UPLOAD");
				if(retMessage!=null&&retMessage.equalsIgnoreCase("SUCCESS")){
					if(paymentAdviceRequestObj.getRenamedSupportedFileName()!=null){
						retMessage=transferFileToDestination(paymentAdviceSupportFile, paymentAdviceRequestObj.getRenamedSupportedFileName(), "SUPPORT");
						if(retMessage!=null&&retMessage.equalsIgnoreCase("SUCCESS")){
							message="payment advice request has been raised successfully, request id "+paymentAdviceRequestObj.getRequestId();
							paymntAdvRequestObj.setErrorCode("SUCCESS");
							paymntAdvRequestObj.setErrorMessage(message);
							logger.info("request id with support file" +paymentAdviceRequestObj.getRequestId());
							paymntAdvRequestObj.setRequestId(paymentAdviceRequestObj.getRequestId());
							return paymntAdvRequestObj;
						}
						else if(retMessage!=null&&retMessage.equalsIgnoreCase("FAILURE")){
							message=" unable to save payment advice support file to the server location";
							paymntAdvRequestObj.setErrorCode("FAILURE");
							paymntAdvRequestObj.setErrorMessage(message);
							return paymntAdvRequestObj;
						}
						else{
							paymntAdvRequestObj.setErrorCode("FAILURE");
							paymntAdvRequestObj.setErrorMessage(retMessage);
							return paymntAdvRequestObj;
						}
					}
					message="payment advice request has been raised successfully, request id "+paymentAdviceRequestObj.getRequestId();
					logger.info("request id without support file" +paymentAdviceRequestObj.getRequestId());
					paymntAdvRequestObj.setRequestId(paymentAdviceRequestObj.getRequestId());
					paymntAdvRequestObj.setRenamedSupportedFileName(paymentAdviceRequestObj.getRenamedSupportedFileName());
					paymntAdvRequestObj.setOriginalSupportedFileName(paymentAdviceRequestObj.getOriginalSupportedFileName());
					paymntAdvRequestObj.setOriginalUploadedFileName(paymentAdviceRequestObj.getOriginalUploadedFileName());
					paymntAdvRequestObj.setRenamedUploadedFileName(paymentAdviceRequestObj.getRenamedUploadedFileName());
					paymntAdvRequestObj.setUploadedBy(paymentAdviceRequestObj.getUploadedBy());
					paymntAdvRequestObj.setErrorCode("SUCCESS");
					paymntAdvRequestObj.setErrorMessage(message);
					return paymntAdvRequestObj;
				}
				else if(retMessage!=null&&retMessage.equalsIgnoreCase("FAILURE")){
					message=" unable to save payment advice upload file to the server location";
					paymntAdvRequestObj.setErrorCode("FAILURE");
					paymntAdvRequestObj.setErrorMessage(message);
					return paymntAdvRequestObj;
				}
				else{
					paymntAdvRequestObj.setErrorCode("FAILURE");
					paymntAdvRequestObj.setErrorMessage(retMessage);
					return paymntAdvRequestObj;
				}

			}
			else{
				paymntAdvRequestObj.setErrorCode("FAILURE");
				paymntAdvRequestObj.setErrorMessage(fileUpload.getStatusDescription());
				return paymntAdvRequestObj;
			}
		}
		catch(Exception e)
		{
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		return paymntAdvRequestObj;
	}

	
	//----------------------waiver email---------------------------->
	
	
	public static EMailContent sendWaiverEmailAlert(PaymentAdviceDAO paymentAdviceDAOObj,FileUploadResult paymentRequestObj,UserDetails userDetailsObj,String alertType){
		logger.info("Inside sendEmailAlert ");
		EMailContent eMailContentObj=new EMailContent();
		File file=null;
		InputStream inputStream=null;
		Properties props=null;
		if(alertType!=null&&alertType.equalsIgnoreCase("FILE_LEVEL_VALIDATIONS_SUCCESS_ALERT")){
			file=new File(aceCadHomePath+"/Conf/EmailAlertsTemplates/PaymentAdviceRequestIdConfirmationAlert.properties");
			try {
				inputStream=new FileInputStream(file);
				props=new Properties();
				props.load(inputStream);
				logger.info("requet id in mail body " +paymentRequestObj.getFileId());
				eMailContentObj.setEmailSubject(props.getProperty("emailSubject").replace("A",paymentRequestObj.getFileId()));
				eMailContentObj.setEmailHeader(props.getProperty("emailHeader"));
				eMailContentObj.setEmailFooter(props.getProperty("emailFooter"));
				eMailContentObj.setEmailBody(props.getProperty("emailBody").replace("A",paymentRequestObj.getFileId()));

				//Comment for testing
				eMailContentObj.setSmtpFromAddress("APS_Waiver@airtel.com");

				userDetailsObj=paymentAdviceDAOObj.getEmailAddress(userDetailsObj);
				if(userDetailsObj!=null&&userDetailsObj.getErrorCode()!=null&&userDetailsObj.getErrorCode().equalsIgnoreCase("SUCCESS")){

					List<String> emailToList=new ArrayList<String>();
					emailToList.add(userDetailsObj.getEmailAddress());
					eMailContentObj.setEmailToList(emailToList);

					eMailContentObj.setAttachmentRequired(false);
					logger.info("eMail body: "+eMailContentObj.getEmailBody());
					/*List<EmailAttachment> emailAttachmentList=new ArrayList<EmailAttachment>();

					EmailAttachment emailUploadedAttachmentObj=new EmailAttachment();
					emailUploadedAttachmentObj.setAttachmentName(paymentRequestObj.getRenamedUploadedFileName());
					emailUploadedAttachmentObj.setAttachmentPath(paymentAdviceHomePath+"/UploadedFiles/InputFiles");
					emailAttachmentList.add(emailUploadedAttachmentObj);

					EmailAttachment emailSupportAttachmentObj=new EmailAttachment();
					emailSupportAttachmentObj.setAttachmentName(paymentRequestObj.getRenamedSupportedFileName());
					emailSupportAttachmentObj.setAttachmentPath(paymentAdviceHomePath+"/UploadedFiles/SupportFiles");
					emailAttachmentList.add(emailSupportAttachmentObj);
					eMailContentObj.setEmailAttachmentList(emailAttachmentList);*/
					//SmtpUtility.setLogger(logger);
					SmtpMailContent smtpMailContentObj=SmtpUtility.generateEmailAlert(eMailContentObj);
					eMailContentObj.setErrorCode(smtpMailContentObj.getErrorCode());
					eMailContentObj.setErrorMessage(smtpMailContentObj.getErrorMessage());
					return eMailContentObj;
				}
				else if(userDetailsObj!=null&&userDetailsObj.getErrorCode()!=null&&userDetailsObj.getErrorCode().equalsIgnoreCase("FAILURE")){
					eMailContentObj.setErrorCode(userDetailsObj.getErrorCode());
					eMailContentObj.setErrorMessage(userDetailsObj.getErrorMessage());
					return eMailContentObj;
				}
				else{
					eMailContentObj.setErrorCode("FAILURE");
					eMailContentObj.setErrorMessage("Invalid response received while capturing user email address");
					return eMailContentObj;
				}
			} catch (FileNotFoundException e) {
				eMailContentObj.setErrorCode("FAILURE");
				eMailContentObj.setErrorMessage("Unable to sent email alert, reason for the failure is "+e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
			catch (IOException e) {
				eMailContentObj.setErrorCode("FAILURE");
				eMailContentObj.setErrorMessage("Unable to sent email alert, reason for the failure is "+e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		catch (Exception e) {
			eMailContentObj.setErrorCode("FAILURE");
			eMailContentObj.setErrorMessage("Unable to sent email alert, reason for the failure is "+e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		}


		return eMailContentObj; 
	}

}
