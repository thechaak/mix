/**
 * 
 */
package com.airtel.ace.cad.paymentadvice.model;

import java.util.HashMap;
   
/**
 * @author Chaitanya Yandrapalli - 587111
 *
 */
public class PaymentAdviceUploadFields {
	
	private String errorCode;
	private String errorMessage;
	private int fieldPosition;
	private String fieldName;
	private HashMap<Integer,String> fieldMap;
	private String refNumber;
	private String trackingId;
	private String targetFxAccountNumber;
	private String invoiceNumber;
	private Double invoiceAllocationAmount;
	private Double paymentExchangeRate;
	private Double tdsAmount;
	private String tranNo;
	private String remarks;
	private int requestId;
	private String paymentMode;
	private String uploadedBy;
	private Double amountInINR;
	private String bankAccountNumber;

	

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public int getFieldPosition() {
		return fieldPosition;
	}

	public void setFieldPosition(int fieldPosition) {
		this.fieldPosition = fieldPosition;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public HashMap<Integer, String> getFieldMap() {
		return fieldMap;
	}

	public void setFieldMap(HashMap<Integer, String> fieldMap) {
		this.fieldMap = fieldMap;
	}

	public String getRefNumber() {
		return refNumber;
	}

	public void setRefNumber(String refNumber) {
		this.refNumber = refNumber;
	}

	public String getTrackingId() {
		return trackingId;
	}

	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}

	public String getTargetFxAccountNumber() {
		return targetFxAccountNumber;
	}

	public void setTargetFxAccountNumber(String targetFxAccountNumber) {
		this.targetFxAccountNumber = targetFxAccountNumber;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	

	

	public String getTranNo() {
		return tranNo;
	}

	public void setTranNo(String tranNo) {
		this.tranNo = tranNo;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getUploadedBy() {
		return uploadedBy;
	}

	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public Double getInvoiceAllocationAmount() {
		return invoiceAllocationAmount;
	}

	public void setInvoiceAllocationAmount(Double invoiceAllocationAmount) {
		this.invoiceAllocationAmount = invoiceAllocationAmount;
	}

	public Double getPaymentExchangeRate() {
		return paymentExchangeRate;
	}

	public void setPaymentExchangeRate(Double paymentExchangeRate) {
		this.paymentExchangeRate = paymentExchangeRate;
	}

	public Double getTdsAmount() {
		return tdsAmount;
	}

	public void setTdsAmount(Double tdsAmount) {
		this.tdsAmount = tdsAmount;
	}

	public Double getAmountInINR() {
		return amountInINR;
	}

	public void setAmountInINR(Double amountInINR) {
		this.amountInINR = amountInINR;
	}
}
