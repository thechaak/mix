package com.airtel.ace.cad.paymentadvice.dao;




import java.util.HashMap;
import java.util.List;

import com.acecad.bulkupload.model.UserEmailDetails;
import com.airtel.ace.cad.aesadvice.model.AESFileDetails;
import com.airtel.ace.cad.aesadvice.model.AESFileStatus;
import com.airtel.ace.cad.aesadvice.model.AESVendorFileRecords;


public interface AESApprovalDAO {
	//public AESFileStatus getFilesApprove(int page);
	public AESFileDetails getAESChqWorkFlowApprovalDetails(String roleId,AESFileDetails aesFileDetails) throws Exception;
	public AESFileStatus searchFileAPS(String fileId, String fileName, String fromDate, String endDate,int page,String viewName,String olmId) throws Exception;
	public List<String> getStatusList() throws Exception;
	public HashMap<String, String> readFileTypeList() throws Exception;
	//public Object approveFile(List<String> checkedFileList,	String checkedRemark, String reason , String userId, String action) throws Exception;
	public Object approveFile(List<String> checkedFileList, String rejectReasonRemarks, String userId,String action, String rejectReasonDropDwn) throws Exception;
	public UserEmailDetails getEmailAddress(String  userId);
	public AESVendorFileRecords downloadaesChequeWorkFlowFile(String userId,String fileId,String requestFileName);
}
