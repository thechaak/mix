package com.airtel.ace.cad.paymentadvice.model;
   
import java.util.List;

public class VendorDetails {


    private String vendorName;
	private String vendorSpoc;
	private String emailId;

	private String payMode;
	private String addressLine1;
	private String addressLine2;
	private String city;
	private String state;
	private int pin;
	private String contact;
	private String status;
	private String vendorId;

	private String activeDate;
    private String inactiveDate;
    private String lob;
	private String vendorUserName;
	private String vendorUserAddress;
	private String vendorUserEmailId;
	private String vendorUseractiveDate;
	private String vendorUserInactiveDate;
	private String vendorUserOLMId;
	private String roleType;
	private String roleStatus;
	private String responseLDAP;
	private String vendorCategory;
	private String vendorActiveDate;
	private String vendorInactiveDate;
	private String olmExist;
	private String vendorExist;
	private String errorCode;
	private String errorMessage;
	private List<String> applicableRoleList;
	private List<String> paymodeList;
	private List<String> lobList;
	private String changeWhoId;
	private String circle;
	private String circleDescription;
	
	private List<String> allPaymodeList;
	private List<String> alllLobList;
	private List<String> allRMPaymentTransferList;
	private List<String> rmPaymentTransferList;
	private List<UserRole> userRoleList;
	private String roleDescription;
	private List<Circle> circleList;
	private List<Circle> circlesMapped;
	private List<Circle> circlesAllowed;
	private String spocEmailId;
	private String spocContactNum;
	public String getRoleDescription() {
		return roleDescription;
	}
	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}
	public List<UserRole> getUserRoleList() {
		return userRoleList;
	}
	public void setUserRoleList(List<UserRole> userRoleList) {
		this.userRoleList = userRoleList;
	}

	
	
	
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getVendorSpoc() {
		return vendorSpoc;
	}
	public void setVendorSpoc(String vendorSpoc) {
		this.vendorSpoc = vendorSpoc;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPayMode() {
		return payMode;
	}
	public void setPayMode(String payMode) {
		this.payMode = payMode;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getActiveDate() {
		return activeDate;
	}
	public void setActiveDate(String activeDate) {
		this.activeDate = activeDate;
	}
	public String getInactiveDate() {
		return inactiveDate;
	}
	public void setInactiveDate(String inactiveDate) {
		this.inactiveDate = inactiveDate;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getVendorUserName() {
		return vendorUserName;
	}
	public void setVendorUserName(String vendorUserName) {
		this.vendorUserName = vendorUserName;
	}
	public String getVendorUserAddress() {
		return vendorUserAddress;
	}
	public void setVendorUserAddress(String vendorUserAddress) {
		this.vendorUserAddress = vendorUserAddress;
	}
	public String getVendorUserEmailId() {
		return vendorUserEmailId;
	}
	public void setVendorUserEmailId(String vendorUserEmailId) {
		this.vendorUserEmailId = vendorUserEmailId;
	}
	public String getVendorUserInactiveDate() {
		return vendorUserInactiveDate;
	}
	public void setVendorUserInactiveDate(String vendorUserInactiveDate) {
		this.vendorUserInactiveDate = vendorUserInactiveDate;
	}
	public String getVendorUseractiveDate() {
		return vendorUseractiveDate;
	}
	public void setVendorUseractiveDate(String activeDate2) {
		this.vendorUseractiveDate = activeDate2;
	}
	public String getVendorUserOLMId() {
		return vendorUserOLMId;
	}
	public void setVendorUserOLMId(String vendorUserOLMId) {
		this.vendorUserOLMId = vendorUserOLMId;
	}
	public String getRoleType() {
		return roleType;
	}
	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}
	public String getRoleStatus() {
		return roleStatus;
	}
	public void setRoleStatus(String roleStatus) {
		this.roleStatus = roleStatus;
	}
	public String getResponseLDAP() {
		return responseLDAP;
	}
	public void setResponseLDAP(String responseLDAP) {
		this.responseLDAP = responseLDAP;
	}
	public String getVendorCategory() {
		return vendorCategory;
	}
	public void setVendorCategory(String vendorCategory) {
		this.vendorCategory = vendorCategory;
	}
	public String getVendorActiveDate() {
		return vendorActiveDate;
	}
	public void setVendorActiveDate(String vendorActiveDate) {
		this.vendorActiveDate = vendorActiveDate;
	}
	public String getVendorInactiveDate() {
		return vendorInactiveDate;
	}
	public void setVendorInactiveDate(String vendorInactiveDate) {
		this.vendorInactiveDate = vendorInactiveDate;
	}
	public String getOlmExist() {
		return olmExist;
	}
	public void setOlmExist(String olmExist) {
		this.olmExist = olmExist;
	}
	public List<String> getApplicableRoleList() {
		return applicableRoleList;
	}
	public void setApplicableRoleList(List<String> applicableRoleList) {
		this.applicableRoleList = applicableRoleList;
	}
	public String getVendorExist() {
		return vendorExist;
	}
	public void setVendorExist(String vendorExist) {
		this.vendorExist = vendorExist;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public List<String> getPaymodeList() {
		return paymodeList;
	}
	public void setPaymodeList(List<String> paymodeList) {
		this.paymodeList = paymodeList;
	}
	public List<String> getLobList() {
		return lobList;
	}
	public void setLobList(List<String> lobList) {
		this.lobList = lobList;
	}
	public List<String> getAllPaymodeList() {
		return allPaymodeList;
	}
	public void setAllPaymodeList(List<String> allPaymodeList) {
		this.allPaymodeList = allPaymodeList;
	}
	public List<String> getAlllLobList() {
		return alllLobList;
	}
	public void setAlllLobList(List<String> alllLobList) {
		this.alllLobList = alllLobList;
	}
	public String getChangeWhoId() {
		return changeWhoId;
	}
	public void setChangeWhoId(String changeWhoId) {
		this.changeWhoId = changeWhoId;
	}
	public List<String> getAllRMPaymentTransferList() {
		return allRMPaymentTransferList;
	}
	public void setAllRMPaymentTransferList(List<String> allRMPaymentTransferList) {
		this.allRMPaymentTransferList = allRMPaymentTransferList;
	}
	public List<String> getRmPaymentTransferList() {
		return rmPaymentTransferList;
	}
	public void setRmPaymentTransferList(List<String> rmPaymentTransferList) {
		this.rmPaymentTransferList = rmPaymentTransferList;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getCircleDescription() {
		return circleDescription;
	}
	public void setCircleDescription(String circleDescription) {
		this.circleDescription = circleDescription;
	}
	public List<Circle> getCircleList() {
		return circleList;
	}
	public void setCircleList(List<Circle> circleList) {
		this.circleList = circleList;
	}
	public String getSpocEmailId() {
		return spocEmailId;
	}
	public void setSpocEmailId(String spocEmailId) {
		this.spocEmailId = spocEmailId;
	}
	public String getSpocContactNum() {
		return spocContactNum;
	}
	public void setSpocContactNum(String spocContactNum) {
		this.spocContactNum = spocContactNum;
	}
	public List<Circle> getCirclesMapped() {
		return circlesMapped;
	}
	public void setCirclesMapped(List<Circle> circlesMapped) {
		this.circlesMapped = circlesMapped;
	}
	public List<Circle> getCirclesAllowed() {
		return circlesAllowed;
	}
	public void setCirclesAllowed(List<Circle> circlesAllowed) {
		this.circlesAllowed = circlesAllowed;
	}

}
