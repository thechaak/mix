package com.airtel.ace.cad.paymentadvice.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.acecad.bulkupload.model.FileDetails;
import com.airtel.ace.cad.aesadvice.model.AESAdviceLock;
import com.airtel.ace.cad.aesadvice.model.AESAdviceRequest;
import com.airtel.ace.cad.aesadvice.model.AESAdviceTemplate;
import com.airtel.ace.cad.aesadvice.model.AESDetails;
import com.airtel.ace.cad.aesadvice.model.AESVendorFileRecords;
import com.airtel.ace.cad.paymentadvice.dao.AesAdviceDao;
import com.airtel.ace.cad.paymentadvice.model.UserDetails;
import com.airtel.ace.cad.paymentadvice.utility.AESChequeUtility;
import com.airtel.acecad.UtilityJar.ActivityLog;
import com.airtel.acecad.bulkupload.dto.FileStatusAPS;
import com.airtel.acecad.bulkupload.dto.FileStatusDTO;
import com.airtel.acecad.bulkupload.dto.FileUploadResult;
import com.airtel.acecad.bulkupload.uploadfile.ExcelReader;
import com.airtel.acecad.bulkupload.util.CommonValidator;
import com.airtel.acecad.model.EMailContent;
@Controller
public class AESChequeUploadController {
	
	@Autowired
	AESChequeUtility aesChequeUtility;
	@Autowired
	AesAdviceDao aesAdviceDaoObj;
	@Autowired
	ActivityLog activityDao;
	@Autowired
	ExcelReader excelReader;
	HttpSession session;
	private static Logger logger =LogManager.getLogger("aesChequeUploadLogger");
	private String paymentAdviceHomePath = System.getenv("PAYMENT_ADVICE_HOME");
	private String templatesPath=System.getenv("ACE_CAD_HOME")+File.separator+"Templates";
	//private String downloadpath=System.getenv("PAYMENT_ADVICE_HOME")+File.separator+"UPLOADED_FILES"+File.separator+"AESChequeAllocation"+File.separator+"InputFiles";
	private String transferFile=System.getenv("ACE_CAD_HOME")+File.separator+"UPLOADED_FILES"+File.separator+"AESChequeAllocation"+File.separator+"InputFiles";
	private String transferSupportFile=System.getenv("ACE_CAD_HOME")+File.separator+"UPLOADED_FILES"+File.separator+"AESChequeAllocation"+File.separator+"SupportFiles";
	private String errorFilesPath=System.getenv("ACE_CAD_HOME")+File.separator+"ERRORED_FILES";
	
	@RequestMapping(value = "/aesUpload")
	public ModelAndView aesChequeHomePage(HttpServletRequest request,
			HttpServletResponse response) 
	{
		logger.info("Enterd in to AES Home Upload");
		ModelAndView modelAndViewObj = new ModelAndView();
		String maxTransInCart="5";
		
		//modelAndViewObj.addObject("maxTransInCart",maxTransInCart);
		modelAndViewObj.setViewName("aesHomePage");
		logger.info("Ended in to AES Home ");
		return modelAndViewObj;
		
		
	}
	@RequestMapping(value = "/aesChequeUpload")
	public ModelAndView aesChequeUploadPage(HttpServletRequest request,
			HttpServletResponse response) 
	{
		String maxTransInCart=null;
		String maxSizeAlldForSupFile=null;
		logger.info("Enterd in to AES Cheques Upload");
		ModelAndView modelAndViewObj = new ModelAndView();
		if(maxTransInCart==null||maxSizeAlldForSupFile==""){
			maxTransInCart="5";
		}
		if(maxSizeAlldForSupFile==null||maxSizeAlldForSupFile==""){
			maxSizeAlldForSupFile="21";
		}
		modelAndViewObj.addObject("maxTransInCart",maxTransInCart);
		modelAndViewObj.addObject("maxSizeAlldForSupFile",maxSizeAlldForSupFile);
		modelAndViewObj.setViewName("AESChequeUpload");
		logger.info("Ended in to AES Cheques Upload");
		return modelAndViewObj;
		
		
	}
@RequestMapping(value = "/aesBankStatement")
public ModelAndView aesBankStatementUploadHomePage(HttpServletRequest request) {
	session=request.getSession(true);
	String userId=session.getAttribute("userid").toString();
	String role=session.getAttribute("user_role_id").toString();
	String message ="";
	String type="";
	String searchFromDate =null;
	String searchEndDate =null;
	int page =0;
	List<String> uploadType=new ArrayList<String>();
	AESVendorFileRecords aesVendorFileRecordsDTO = new AESVendorFileRecords();

	logger.info("ENTERED INTO AESBANKTRANSFER");
	ModelAndView modelAndViewObj = new ModelAndView();
	session.setAttribute("uploadTypeList", uploadType);
	modelAndViewObj.addObject("uploadTypeList",uploadType);
	
	
  try{
	 message= request.getParameter("message");
	 type=request.getParameter("type");
	 }
	 catch(Exception e){
		 message="";type="";
	 }
			
	 try{
		 try{
		page = Integer.parseInt(request.getParameter("pageNum"));
		 }
		 catch(Exception e){
			 page =1;
		 }
		 logger.info("page==>"+ page);
		 logger.info("AES Bank Statement records0==>"+ "current page==> "+page +" total records==> "+aesVendorFileRecordsDTO.getTotalResults());
		logger.info("AES Bank Statement records1==>"+ "resultsPerPage==> "+aesVendorFileRecordsDTO.getResultPerPage() +" totalPages==> "+aesVendorFileRecordsDTO.getTotalPages());
		
		/*modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("totalRecords",fileDetailDto.getTotalResult());
		modelAndViewObj.addObject("resultsPerPage",fileDetailDto.getResultPerPage());
		modelAndViewObj.addObject("totalPages", fileDetailDto.getTotalPages());
		modelAndViewObj.addObject("fileDetailList", fileDetailDto.getPaymentTransferDetailsList());
		modelAndViewObj.addObject("filtersearch", "true");
		modelAndViewObj.addObject("message", message);
		modelAndViewObj.addObject("fileId", "-1");
		modelAndViewObj.addObject("acctNo", "-1");
		modelAndViewObj.addObject("lob", "-1");
		modelAndViewObj.addObject("status", "-1");
		modelAndViewObj.addObject("uploadDate", "-1");
		modelAndViewObj.addObject("role", role);*/
		
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("totalRecords",aesVendorFileRecordsDTO.getTotalResults());
		modelAndViewObj.addObject("resultsPerPage",aesVendorFileRecordsDTO.getResultPerPage());		
		modelAndViewObj.addObject("totalPages", aesVendorFileRecordsDTO.getTotalPages());
		modelAndViewObj.addObject("aesBulkStatementDetailList", aesVendorFileRecordsDTO.getAesBulkStatementDetailList());
		modelAndViewObj.addObject("filtersearch", "true");		
		modelAndViewObj.addObject("message", message);
		modelAndViewObj.addObject("fileId", "");
		modelAndViewObj.addObject("uploadedUser", "");
		modelAndViewObj.addObject("fromDate", "");
		modelAndViewObj.addObject("endDate", "");
		modelAndViewObj.addObject("role", role);
		//modelAndViewObj.addObject("aesVendorFileRecordsDTO",new AESVendorFileRecords());			
		modelAndViewObj.setViewName("aesBankStatementUpload");
		 
	 }
	 catch(Exception e1){
		 e1.printStackTrace();
		 page =1;
	 }
	 return modelAndViewObj;

}

@RequestMapping(value = "/searchAESBankStatement")
public ModelAndView searchAESBankStatement(HttpServletRequest request,
		HttpServletResponse response) 
{
	logger.info("Enterd in to AES Bank Statement Upload");
	ModelAndView modelAndViewObj = new ModelAndView();		
		
	List<AESVendorFileRecords> recordListFinal = new ArrayList();
	logger.info("START ------>aesBankStatement");
	AESVendorFileRecords aesVendorFileRecordsDTO = new AESVendorFileRecords();
	int page = 1;
	String messsage;
	String searchUserId=request.getParameter("uploadedUser");
	String searchFileId = request.getParameter("fileId");
	String searchFromDate =request.getParameter("fromDate");
	String searchEndDate =request.getParameter("endDate");
	String role=session.getAttribute("user_role_id").toString();
	boolean noSearchCriteria=true;
	
	try {
		if(request.getParameter("pageNum")!=null){
			aesVendorFileRecordsDTO.setCurrentPage(Integer.parseInt(request.getParameter("pageNum")));
		}else
			aesVendorFileRecordsDTO.setCurrentPage(page);
		
		if(request.getParameter("fileId")!=null){
			aesVendorFileRecordsDTO.setSearchFileId(request.getParameter("fileId"));
			noSearchCriteria=false;
		}else
			aesVendorFileRecordsDTO.setSearchFileId(searchFileId);
		
		if(request.getParameter("uploadedUser")!=null){
			aesVendorFileRecordsDTO.setSearchUserId(request.getParameter("uploadedUser"));
		}else
			aesVendorFileRecordsDTO.setSearchUserId(searchUserId);
		
		if(request.getParameter("fromDate")!=null){
			aesVendorFileRecordsDTO.setSearchFromDate(request.getParameter("fromDate"));
			noSearchCriteria=false;
		}else
			aesVendorFileRecordsDTO.setSearchFromDate(searchFromDate);
		
		if(request.getParameter("endDate")!=null){
			aesVendorFileRecordsDTO.setSearchEndDate(request.getParameter("endDate"));
			noSearchCriteria=false;
		}else
			aesVendorFileRecordsDTO.setSearchEndDate(searchEndDate);	
		
		aesVendorFileRecordsDTO = aesAdviceDaoObj.getAesBankStatementDetails(aesVendorFileRecordsDTO);
		
		if(noSearchCriteria){
			modelAndViewObj.addObject("filtersearch", "true");	
		}else
		modelAndViewObj.addObject("filtersearch", "false");	
	   			
		modelAndViewObj.addObject("totalRecords",aesVendorFileRecordsDTO.getTotalResults());
		modelAndViewObj.addObject("resultsPerPage",aesVendorFileRecordsDTO.getResultPerPage());			
		modelAndViewObj.addObject("aesBulkStatementDetailList", aesVendorFileRecordsDTO.getAesBulkStatementDetailList());
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.addObject("totalPages", aesVendorFileRecordsDTO.getTotalPages());
		modelAndViewObj.addObject("message", aesVendorFileRecordsDTO.getErrorMsg());
		modelAndViewObj.addObject("aesVendorFileRecordsDTO",new AESVendorFileRecords());
		modelAndViewObj.addObject("role", role);
		modelAndViewObj.setViewName("aesBankStatementUpload");			
      
		
		if(CommonValidator.isNull(searchFileId))
			modelAndViewObj.addObject("fileId",""); 
		else
			modelAndViewObj.addObject("fileId",searchFileId );
		
		if(CommonValidator.isNull(searchUserId))
			modelAndViewObj.addObject("uploadedUser", "");
		else
			modelAndViewObj.addObject("uploadedUser", searchUserId);
				
		if(CommonValidator.isNull(searchFromDate))
			modelAndViewObj.addObject("fromDate", "");
		else
			modelAndViewObj.addObject("fromDate",searchFromDate);
		
		if(CommonValidator.isNull(searchEndDate))
			modelAndViewObj.addObject("endDate", "");
		else
			modelAndViewObj.addObject("endDate", searchEndDate);
		
		logger.info("fileId==>"+searchFileId+"::uploadedUser===>"+searchUserId +"::::fromDate==>"+searchFromDate+":::endDate==>"+searchEndDate);
	} catch (Exception e) {
		logger.error(e);
	}

	return modelAndViewObj;

}

@RequestMapping(value="/downloadAESBankStatementReportExcel",method=RequestMethod.GET)
public void exportExcelAESBankStatementReport(HttpServletRequest request,HttpServletResponse response){
	 String[] columns = {"File Id","File Name","Transaction Id","Account No",
			 "Cheque No","Deposit Slip No","Amount","File Upload Date","Uploaded User Name",
			 "Bank Name","Remitter Name","Lob","Receiver Name","Annotation","Posting Status Description",
			 "Posting Tracking_Id","Posting Tracking_Serv","Reversal Status Description",
			 "Reversal Tracking_Id","Reversal Tracking_Serv"};  

	  String fileId="";
	  String uploadedUser ="";
	  String searchedFromDate ="";
	  String searchedEndDate ="";
	  
	  session=request.getSession(true);
      String userId=session.getAttribute("userid").toString();
	  String role=session.getAttribute("user_role_id").toString();
	  AESVendorFileRecords aesVendorFileRecordsDTO = new AESVendorFileRecords();
	  try{		  
		  try{
			  fileId= request.getParameter("fileId"); 
			  if(fileId!=null)
				  aesVendorFileRecordsDTO.setSearchFileId(fileId);
			  
			  uploadedUser= request.getParameter("uploadedUser");
			  if(uploadedUser!=null)
				  aesVendorFileRecordsDTO.setSearchUserId(uploadedUser);
			  
			  searchedFromDate = request.getParameter("fromDate");				
			  if(searchedFromDate!=null)
					aesVendorFileRecordsDTO.setSearchFromDate(searchedFromDate);
			
			  searchedEndDate=request.getParameter("endDate");		
			  if(searchedEndDate!=null)
					aesVendorFileRecordsDTO.setSearchEndDate(searchedEndDate);
			  
								
			  logger.info("In download excel file for downloadAESBankStatementReportExcel ==fileId==>"+ fileId+
					  "==>uploadedUser:"+uploadedUser+"===searchedFromDate:"+searchedFromDate
						+"==searchedEndDate:"+searchedEndDate);
			  }
				 catch(Exception e){
					e.printStackTrace();
		 }
		
		 aesVendorFileRecordsDTO= aesAdviceDaoObj.downloadsAESBankStatementReports(aesVendorFileRecordsDTO);
		
	     List<AESVendorFileRecords> aesBankStatementDetailList = null;	
	     response.setContentType("application/vnd.ms-excel");
	     response.setHeader("Content-Disposition", "attachment;filename=AESBankStatementTransLevelReport.xls");

	    if(aesVendorFileRecordsDTO!= null)
	    {
	    	aesBankStatementDetailList = aesVendorFileRecordsDTO.getAesBulkStatementDetailList();
	    	logger.info("aesBankStatementDetailList.size===========>"+aesBankStatementDetailList.size());
	    }
	    
	Workbook workbook = new HSSFWorkbook();//new XSSFWorkbook();use for .xlsx file
	Sheet sheet = workbook.createSheet("AESBankStatement Trans Level Report");
	Font headerFont = workbook.createFont();
	 headerFont.setBold(true);
     headerFont.setFontHeightInPoints((short) 10);
     headerFont.setColor(IndexedColors.GREEN.getIndex());
     
     CellStyle headerCellStyle = workbook.createCellStyle();
     headerCellStyle.setFont(headerFont);
     
     Row headerRow = sheet.createRow(0);
    
  // Create cells
        for(int i = 0; i < columns.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(columns[i]);
            cell.setCellStyle(headerCellStyle);
        }
        
        int rowNum = 1;
        
        for(AESVendorFileRecords xlsData: aesBankStatementDetailList) { 
        	logger.info("Inside for loop");
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(xlsData.getFile_id());
            row.createCell(1).setCellValue(xlsData.getFile_name());
            row.createCell(2).setCellValue(xlsData.getTransaction_id());
            row.createCell(3).setCellValue(xlsData.getAccountNo());
            row.createCell(4).setCellValue(xlsData.getChequeNo());
            row.createCell(5).setCellValue(xlsData.getDepositSlipNo());
            row.createCell(6).setCellValue(xlsData.getAmount());
            row.createCell(7).setCellValue(xlsData.getFile_upload_date());
            row.createCell(8).setCellValue(xlsData.getUploadedUserName());
            row.createCell(9).setCellValue(xlsData.getBankName());
            row.createCell(10).setCellValue(xlsData.getRemitterName());
            row.createCell(11).setCellValue(xlsData.getDerived_lob());
            row.createCell(12).setCellValue(xlsData.getReceiverName());
            row.createCell(13).setCellValue(xlsData.getAnnotation());
            row.createCell(14).setCellValue(xlsData.getPostingStatusDesc());
            row.createCell(15).setCellValue(xlsData.getPostingTrackingId());
            row.createCell(16).setCellValue(xlsData.getPostingTrackingIdServ());            
            row.createCell(17).setCellValue(xlsData.getReversalStatusDesc());
            row.createCell(18).setCellValue(xlsData.getReversalTrackingId());
            row.createCell(19).setCellValue(xlsData.getReversalTrackingIdServ());
            logger.info("xlsData.getFile_id()==>"+xlsData.getFile_id()+"::xlsData.getFile_name()==>"+xlsData.getFile_name()+":::xlsData.getTransaction_id()==>"+xlsData.getTransaction_id());
           }
        
     // Resize all columns to fit the content size
        for(int i = 0; i < columns.length; i++) {
            sheet.autoSizeColumn(i);
        }
        workbook.write(response.getOutputStream());
        response.getOutputStream().close();
       
        workbook.close();
	  }
				  
	  catch(Exception e){
		  logger.error("Exception in ExcelDownload==="+ e.getMessage());
	  }

}

@RequestMapping("/aesBankStatementUpload")
public ModelAndView uploadAESBankStatementFile(@RequestParam("file") MultipartFile file,HttpServletRequest request){
	
	session=request.getSession(true);
	String userId=session.getAttribute("userid").toString();
	String role=session.getAttribute("user_role_id").toString();
	
	ModelAndView modelAndViewObj = new ModelAndView();
	String fileName="",fileIdentifier = "";
			
	InputStream inputStream = null;
	
	if(file!=null){
		fileName = file.getOriginalFilename();
		fileIdentifier = fileName.substring(0, 8);
		logger.info("fileIdentifier for AES Bank Statement==========>"+fileIdentifier);
	try {
		byte[] bytes = file.getBytes();
		inputStream = new ByteArrayInputStream(bytes);
	}catch (IOException e) {
		logger.error(e);
	}
}
	
	File aesBankStatementObj=new File(paymentAdviceHomePath+"/Conf/PaymentAdvice.properties");
	FileDetails fileDetailsObj=new FileDetails();
	
	logger.info("fileName to go in advicestatus aps==>"+fileName);
	String path = "";
	FileUploadResult fileUpload =null;
	try{
			
	 fileUpload =  excelReader.readFromExcelfile(fileName,fileIdentifier, "UI", userId, "",inputStream,"AESBulk",null,null);
	 
	// aesAdviceDaoObj.updateSupportFileDetails(null, fileUpload.getFileId(),fileIdentifier,fileUpload.getStatusDescription(),fileUpload.getStatus());
	 
	if(fileUpload.getStatus() == 1){
		String renamedFileName=null;
		path =transferFile+File.separator+fileName;
		logger.info("file path is "+path);
		file.transferTo(new File(path));
	
	}
	else{
		path =errorFilesPath+File.separator+fileName ;
		logger.info("error file path is "+path);			
		file.transferTo(new File(path));			
	}
	
	logger.info("fileUpload.getStatusDescription()->>"+fileUpload.getStatusDescription());
	modelAndViewObj.addObject("msg",fileUpload.getStatusDescription());
	modelAndViewObj.addObject("type", "upload");
	modelAndViewObj.setViewName("aesBankStatementUpload");//use to identified that message for upload file

	}
	catch(Exception e){
		
		logger.error("Exception occure while read excel file ", e);
		if(fileUpload!=null){
			modelAndViewObj.addObject("msg",fileUpload.getStatusDescription());
			modelAndViewObj.addObject("type", "upload");
			modelAndViewObj.setViewName("aesBankStatementUpload");//use to identified that message for upload file
		}else
			modelAndViewObj.addObject("msg","Error occur while Uploading File ,Check file name must be unique");
			modelAndViewObj.addObject("type", "upload");
			modelAndViewObj.setViewName("aesBankStatementUpload");//use to identified that message for upload file
	}
	
	//if(fileUpload.getStatus() == 1){
	logger.info("fileUpload.getStatusDescription()==>"+fileUpload.getStatusDescription()+"fileUpload.getStatus()==>"+fileUpload.getStatus());
	if(fileUpload.getStatusDescription().contains("Records Successfully Inserted")){
		try{
			 UserDetails userDetailsObj=new UserDetails();
             userDetailsObj.setUserId(userId);

			AESAdviceRequest aesAdviceObj =new AESAdviceRequest();
			aesAdviceObj.setRequestId(Integer.parseInt(fileUpload.getFileId()));
			 EMailContent emailContentObj=AESChequeUtility.sendEmailAlert(fileIdentifier,aesAdviceDaoObj, aesAdviceObj, userDetailsObj, "FILE_LEVEL_VALIDATIONS_SUCCESS_ALERT");
		}catch(Exception e){
				e.printStackTrace();
		}
		
	}
		
	return modelAndViewObj;
}


	@RequestMapping(value = "/aesDPUpload")
	public ModelAndView aesDPUploadPage(HttpServletRequest request,
			HttpServletResponse response) 
	{
		logger.info("Enterd in to AES Direct Posting Upload");
		ModelAndView modelAndViewObj = new ModelAndView();
		String maxTransInCart="5";
		
		modelAndViewObj.addObject("maxTransInCart",maxTransInCart);
		modelAndViewObj.setViewName("AESDirectPosting");
		logger.info("Ended in to AES Direct Posting Upload");
		return modelAndViewObj;
		
		
	}
	
	
	@RequestMapping("/aesDirectPostingBulkUpload")
	public ModelAndView uploadSuspenseFile(@RequestParam("file") MultipartFile file,@RequestParam("aesDirectPostingSupportFile") MultipartFile aesDirectPostingSupportFile,HttpServletRequest request){
		
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		String supportFileName =null;
		String sheetName=null;
		String fileFormatValidation = "FAILURE";
		//FileUploadResult fileUpload =null;
		ModelAndView modelAndViewObj = new ModelAndView();
		String fileName="";
		//,fileIdentifier = "";
		
		if(aesDirectPostingSupportFile!=null && !aesDirectPostingSupportFile.isEmpty()){
			supportFileName = aesDirectPostingSupportFile.getOriginalFilename();
		}
		
		InputStream inputStream = null;
		InputStream supportInputStream = null;
		if(file!=null){
			fileName = file.getOriginalFilename();
			// To be commented as file name will be generic
			//fileIdentifier = fileName.substring(0, 5);
			logger.info("fileName for AES Direct Posting==========>"+fileName);
		try {
			byte[] bytes = file.getBytes();
			inputStream = new ByteArrayInputStream(bytes);
		}catch (IOException e) {
			logger.error(e);
		}
	}
		
		File paymentTransferSupportObj=new File(paymentAdviceHomePath+"/Conf/PaymentAdvice.properties");
		String maxSizeAlldForSupFile=null;
		float maxSizeAllowed,paymentTransferSupportFileInBytes, paymentTransferSupportFileInKBytes, paymentTransferSupportFileInMB;		
		FileDetails fileDetailsObj=new FileDetails();
		
		try {					
			supportInputStream = new FileInputStream(paymentTransferSupportObj);
			Properties properties=new Properties();
			properties.load(supportInputStream);		
			maxSizeAlldForSupFile=properties.getProperty("maxiumSizeAllowedForPaymentAdviceSupportFile");
			sheetName=properties.getProperty("sheetNameOfTheExcelFile");
		}
		catch(Exception e){
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		
		if(aesDirectPostingSupportFile !=null){
			paymentTransferSupportFileInBytes = aesDirectPostingSupportFile.getSize();
			paymentTransferSupportFileInKBytes = paymentTransferSupportFileInBytes / 1024;
			paymentTransferSupportFileInMB = paymentTransferSupportFileInKBytes / 1024;

			logger.info(" AES Direct Posting Support File Original Name : "+aesDirectPostingSupportFile.getOriginalFilename()
			+" AES Direct Posting Support File Size (in Bytes) : "+ paymentTransferSupportFileInBytes
			+ "  AES Direct Posting Support File Size (in Kilo Bytes) : "+paymentTransferSupportFileInKBytes
			+"  AES Direct Posting Support File Size (in Mega Bytes) : "+paymentTransferSupportFileInMB);

			maxSizeAllowed=Float.parseFloat(maxSizeAlldForSupFile);
			if(maxSizeAllowed<paymentTransferSupportFileInMB){
				logger.info(" AES Direct Posting Support file size "+paymentTransferSupportFileInMB+"is greater than allowed size "+maxSizeAllowed);
				fileDetailsObj.setErrorCode("FAILURE");
				fileDetailsObj.setErrorMsg(" AES Direct Posting Support file size "+paymentTransferSupportFileInMB+"is greater than allowed size "+maxSizeAllowed);
				modelAndViewObj.addObject("message",fileDetailsObj.getErrorMsg());
				modelAndViewObj.addObject("type", "upload");//use to identified that message for upload file
				return modelAndViewObj;
			}
		}
		
		logger.info("fileName to go in filestatus aps "+fileName);
		String path = "";
		String supportFilePath ="";
		FileUploadResult fileUpload =null;
		try{
		//To validate xls or xlsx format
		 if(fileName!=null && (fileName.toUpperCase().endsWith(".XLS"))){
			  fileFormatValidation=aesChequeUtility.validateSheetName("XLS", file,sheetName);
		 }
		 
		 if(fileName!=null && (fileName.toUpperCase().endsWith(".XLSX"))){
			  fileFormatValidation=aesChequeUtility.validateSheetName("XLSX", file,sheetName);
		 }
			
		 if(fileFormatValidation!=null && fileFormatValidation.equalsIgnoreCase("SUCCESS"))
		 {	 
		   fileUpload =  excelReader.readFromExcelfile(fileName,"AESDP", "UI", userId, "",inputStream,"AESBulk",null,null);
		 
			// aesAdviceDaoObj.updateSupportFileDetails(aesDirectPostingSupportFile.getOriginalFilename(), fileUpload.getFileId(),fileIdentifier,fileUpload.getStatusDescription(),fileUpload.getStatus());
			 aesAdviceDaoObj.updateSupportFileDetails(aesDirectPostingSupportFile.getOriginalFilename(), fileUpload.getFileId(),fileUpload.getStatusDescription(),fileUpload.getStatus());
			 
			if(fileUpload.getStatus() == 1){
				String renamedFileName=null;
						
				//path =transferFile+File.separator+fileName;
				if(fileName.endsWith(".xls")==true)
				  path =transferFile+File.separator+fileName.replace(".xls","_" +fileUpload.getFileId() + ".xls");		
				
				else if(fileName.endsWith(".xlsx")==true)
					path =transferFile+File.separator+fileName.replace(".xlsx","_" +fileUpload.getFileId() + ".xlsx");	
				
				logger.info("file path is "+path);
				file.transferTo(new File(path));
				
				if(aesDirectPostingSupportFile.getOriginalFilename()!=null && aesDirectPostingSupportFile.getOriginalFilename()!=""){
					int lastIndexSupport=aesDirectPostingSupportFile.getOriginalFilename().lastIndexOf(".");
					//renamedFileName=aesDirectPostingSupportFile.getOriginalFilename().replace(aesDirectPostingSupportFile.getOriginalFilename().substring(0, lastIndexSupport),"AES_Cheque_Suspense_Support_File_"+fileUpload.getFileId());
					renamedFileName=aesDirectPostingSupportFile.getOriginalFilename().replace(aesDirectPostingSupportFile.getOriginalFilename().substring(0, lastIndexSupport),"AES_Cheque_WorkFlow_Support_File_"+fileUpload.getFileId());
					logger.info("renamedFileName->>"+renamedFileName);
					supportFilePath = transferSupportFile+File.separator+renamedFileName ;
					aesDirectPostingSupportFile.transferTo(new File(supportFilePath));
				}
			 }		
		 }
		
		logger.info("fileUpload.getStatusDescription()->>"+fileUpload.getStatusDescription());
		modelAndViewObj.addObject("message",fileUpload.getStatusDescription());
		modelAndViewObj.addObject("type", "upload");
		modelAndViewObj.setViewName("AESDirectPosting");
		//use to identified that message for upload file

		}
		catch(Exception e){
			
			logger.error("Exception occure while read excel file ", e);
			if(fileUpload!=null){
				modelAndViewObj.addObject("message",fileUpload.getStatusDescription());
				modelAndViewObj.addObject("type", "upload");//use to identified that message for upload file
			}else
				modelAndViewObj.addObject("message","Error occur while Uploading File ,Check file name must be unique");
				modelAndViewObj.addObject("type", "upload");//use to identified that message for upload file
		}
		
		//if(fileUpload.getStatus() == 1){
		logger.info("fileUpload.getStatusDescription()==>"+fileUpload.getStatusDescription()+"fileUpload.getStatus()==>"+fileUpload.getStatus());
		if(fileUpload.getStatusDescription().contains("Records Successfully Inserted")){
			
			try{
				 UserDetails userDetailsObj=new UserDetails();
	             userDetailsObj.setUserId(userId);

				AESAdviceRequest aesAdviceObj =new AESAdviceRequest();
				aesAdviceObj.setRequestId(Integer.parseInt(fileUpload.getFileId()));
				 EMailContent emailContentObj=AESChequeUtility.sendEmailAlert("AESDP",aesAdviceDaoObj, aesAdviceObj, userDetailsObj, "FILE_LEVEL_VALIDATIONS_SUCCESS_ALERT");
			}catch(Exception e){
					e.printStackTrace();
			}
			
		}
		return modelAndViewObj;
	}
		
	@RequestMapping(value = "/getAESDetails", method = RequestMethod.POST)
	public @ResponseBody AESDetails getPaymentDetails(
			HttpServletRequest request, HttpServletResponse response) {

		logger.info(" Got an hit to url /getAESDetails");
		logger.info(" Calling  getAESDetails() method to retreive payment details for search criteria ");
		List<AESDetails> paymentDetailsList=new ArrayList<AESDetails>();
		AESDetails paymentDetailsObj1 = new AESDetails();
		try{
			AESDetails paymentDetailsObj=new AESDetails();
			String chequeNo = request.getParameter("chequeNo");
			String depositSlipNo = request.getParameter("depositSlipNo");
			logger.info("Cheque number form UI----->"+chequeNo + " ::Deposit Slip No===>" +depositSlipNo);
			paymentDetailsObj.setChequeNo(chequeNo);
			paymentDetailsObj.setDepositSlipNo(depositSlipNo);
			paymentDetailsObj1=aesAdviceDaoObj.getPaymentDetails(paymentDetailsObj);
			logger.info("Error msg form db------------"+paymentDetailsObj1.getErrorCode());
			}
   catch(Exception e){
	logger.info(e.getLocalizedMessage());
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);
}
		return paymentDetailsObj1;
}
	/*@RequestMapping("/aesBankStatementUpload")
	public ModelAndView uploadAESBankStatementFile(@RequestParam("file") MultipartFile file,HttpServletRequest request){
		
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		
		ModelAndView modelAndViewObj = new ModelAndView();
		String fileName="",fileIdentifier = "";
				
		InputStream inputStream = null;
		
		if(file!=null){
			fileName = file.getOriginalFilename();
			fileIdentifier = fileName.substring(0, 8);
			logger.info("fileIdentifier for AES Bank Statement==========>"+fileIdentifier);
		try {
			byte[] bytes = file.getBytes();
			inputStream = new ByteArrayInputStream(bytes);
		}catch (IOException e) {
			logger.error(e);
		}
	}
		
		File aesBankStatementObj=new File(paymentAdviceHomePath+"/Conf/PaymentAdvice.properties");
		FileDetails fileDetailsObj=new FileDetails();
		
		logger.info("fileName to go in advicestatus aps==>"+fileName);
		String path = "";
		FileUploadResult fileUpload =null;
		try{
				
		 fileUpload =  excelReader.readFromExcelfile(fileName,fileIdentifier, "UI", userId, "",inputStream,"AESBulk",null,null);
		 
		 aesAdviceDaoObj.updateSupportFileDetails(null, fileUpload.getFileId(),fileIdentifier,fileUpload.getStatusDescription(),fileUpload.getStatus());
		 
		if(fileUpload.getStatus() == 1){
			String renamedFileName=null;
			path =transferFile+File.separator+fileName;
			logger.info("file path is "+path);
			file.transferTo(new File(path));
			
		}
		else{
			path =errorFilesPath+File.separator+fileName ;
			logger.info("error file path is "+path);			
			file.transferTo(new File(path));			
		}
		
		logger.info("fileUpload.getStatusDescription()->>"+fileUpload.getStatusDescription());
		modelAndViewObj.addObject("msg",fileUpload.getStatusDescription());
		modelAndViewObj.addObject("type", "upload");
		modelAndViewObj.setViewName("aesBankStatementUpload");//use to identified that message for upload file

		}
		catch(Exception e){
			
			logger.error("Exception occure while read excel file ", e);
			if(fileUpload!=null){
				modelAndViewObj.addObject("msg",fileUpload.getStatusDescription());
				modelAndViewObj.addObject("type", "upload");
				modelAndViewObj.setViewName("aesBankStatementUpload");//use to identified that message for upload file
			}else
				modelAndViewObj.addObject("msg","Error occur while Uploading File ,Check file name must be unique");
				modelAndViewObj.addObject("type", "upload");
				modelAndViewObj.setViewName("aesBankStatementUpload");//use to identified that message for upload file
		}
		return modelAndViewObj;
	}
	*/
	
	@RequestMapping(value = "/raiseAESAdviceRequest", method = RequestMethod.POST)
    public @ResponseBody AESDetails raiseAESAdviceRequest
    (HttpServletRequest request,HttpServletResponse response,
    		@RequestParam("paymentAdviceSupportFile") MultipartFile aesChequeAdviceSupportFile,
    		@RequestParam("paymentAdviceFile") MultipartFile aesChequeAdviceFile)
	{
		File fileObj=new File(paymentAdviceHomePath+"/Conf/PaymentAdvice.properties");
            InputStream inputStream;
            String maxTransInCart=null;
            String maxSizeAlldForSupFile=null;
            String sheetName=null;
            String paymentMode = request.getParameter("paymentModeHiddenValue");
            logger.info("payment mode type is ..................." +paymentMode);
            try {
                    
                    inputStream = new FileInputStream(fileObj);
                     Properties properties=new Properties();
                     properties.load(inputStream);     
                     maxTransInCart=properties.getProperty("maximumTransactionsAllowedInCart");
                     maxSizeAlldForSupFile=properties.getProperty("maxiumSizeAllowedForPaymentAdviceSupportFile");
                     sheetName=properties.getProperty("sheetNameOfTheExcelFile");
            
            }
            catch(Exception e){
                    logger.info(e.getLocalizedMessage());
                    StringWriter errors= new StringWriter();
                    e.printStackTrace(new PrintWriter(errors));
                    logger.error(errors);
            }
            
            
            
            logger.info(" Got an hit to url /raiseAESAdviceRequest");
            logger.info(" Calling  raiseAESAdviceRequest() method to raise payment advice request");
            
            float maxSizeAllowed,aesChequeAdviceSupportFileInBytes, aesChequeAdviceSupportFileInKBytes, aesChequeAdviceSupportFileInMB;
            AESDetails paymentDetailsObj = new AESDetails();
            
            session = request.getSession(true);
            String userId = "NA",userName="NA";
            if (session.getAttribute("userid") != null) {
                    userId = session.getAttribute("userid").toString();
            }		logger.info("User id is ------------ >"+userId);
            if (session.getAttribute("uname") != null) {
                    userName = session.getAttribute("uname").toString();
            }
             Long SNo=0l;
            try {
                    SNo = activityDao.insertActivityLog(0l,userId,"AES Cheque Advice Upload",null,null,null,null,null);
            } catch (SQLException e) {
                   
                    logger.info(e.getLocalizedMessage());
                    StringWriter errors= new StringWriter();
                    e.printStackTrace(new PrintWriter(errors));
                    logger.error(errors);
            }

            if (userId != "NA" && userName!="NA") {
                  
                    
                    ArrayList<String> refNumbersArray=new ArrayList<String>();
                    HashMap<String,String> uniqueKeyAndRefNumberMap=new HashMap<String,String>();
                    String uniqueKeyComparison = "";
                    //String refNumber = request.getParameter("refNumber");
                    String[] refNumbers = request.getParameterValues("refNumber");
                   // logger.info("refNumbers----->"+refNumber);
                   // logger.info("refNumbers----->"+request.getParameterValues("refNumber").toString());
                    if(refNumbers!=null)
                    {
                      for (int i =0 ; i <refNumbers.length; i++) 
                      {
                        if(refNumbers[i]!=null)
                        {
                          String[] refs=refNumbers[i].split("\\$");
                          if(refs!=null)
                          {
                        	//var refNumber=chequeNo+'$'+depositSlipNo+'$'+amount;
                    		if(refs[0]!=null){
								if(refs[0]!=null && refs[1]!=null && refs[2]!=null){
									
									//paymentModeAndRefNumberMap.put(refs[1], refs[0]);
								//uniqueKeyComparison = refs[0]+"|"+ refs[1] +"|"+ refs[2];
									uniqueKeyComparison = refs[0]+"|"+ refs[1];
									logger.info("uniqueKeyComparison--->" +uniqueKeyComparison);
									uniqueKeyAndRefNumberMap.put(refs[0], uniqueKeyComparison);
									if(!refNumbersArray.contains(refs[0]))
										refNumbersArray.add(refs[0].toUpperCase());
								}
								
						
							}	 
                                   
                        }
                     }
                    }
                  }
                    else{
                            logger.info(" Unable to raise AES Cheque advice request, invalid reference numbers received ");
                            paymentDetailsObj.setErrorCode("FAILURE");
                            paymentDetailsObj.setErrorMessage(" Unable to raise AES Cheque advice request, invalid reference numbers received ");
                            return paymentDetailsObj;
                    }
                    
                    if (aesChequeAdviceSupportFile != null) {
                    	    aesChequeAdviceSupportFileInBytes = aesChequeAdviceSupportFile.getSize();
                    	    aesChequeAdviceSupportFileInKBytes = aesChequeAdviceSupportFileInBytes / 1024;
                    	    aesChequeAdviceSupportFileInMB = aesChequeAdviceSupportFileInKBytes / 1024;
                            logger.info(" AES Advice Support File Size (in Bytes) : "
                                            + aesChequeAdviceSupportFileInBytes);
                            logger.info(" AES Advice Support File Size (in Kilo Bytes) : "
                                            + aesChequeAdviceSupportFileInKBytes);
                            logger.info(" AES Advice Support File Size (in Mega Bytes) : "
                                            + aesChequeAdviceSupportFileInMB);
                            logger.info(" AES Advice Support File Original Name : "
                                            + aesChequeAdviceSupportFile.getOriginalFilename());
                            maxSizeAllowed=Float.parseFloat(maxSizeAlldForSupFile);
                            if(maxSizeAllowed<aesChequeAdviceSupportFileInMB){
                                    logger.info(" AES advice support file size "+aesChequeAdviceSupportFileInMB+"is greater than allowed size "+maxSizeAllowed);
                                    paymentDetailsObj.setErrorCode("FAILURE");
                                    paymentDetailsObj.setErrorMessage(" AES advice support file size "+aesChequeAdviceSupportFileInMB+"is greater than allowed size "+maxSizeAllowed);
                                    return paymentDetailsObj;
                            }
                    }
                    
                   if (aesChequeAdviceFile != null) {                        
                      logger.info(" AES Advice Original File Name : "+aesChequeAdviceFile.getOriginalFilename());
                      logger.info(" AES Advice  File Size  (in Bytes) : "+aesChequeAdviceFile.getSize());
                      if(aesChequeAdviceFile.getOriginalFilename()!=null && aesChequeAdviceFile.getOriginalFilename().toUpperCase().endsWith(".XLS"))
                      {
                        String fileFormatValidation=aesChequeUtility.validateSheetName("XLS", aesChequeAdviceFile,sheetName);
                    
                	    if(fileFormatValidation!=null && fileFormatValidation.equalsIgnoreCase("SUCCESS"))
                	    {
                	    
                         // AESAdviceRequest paymentRequestObj=aesChequeUtility.processFileData(aesAdviceDaoObj,"XLS", aesChequeAdviceFile,sheetName,refNumbersArray,userId,aesChequeAdviceSupportFile,userName,paymentModeAndRefNumberMap,depositSlipNumberAndRefNumberMap,amountAndRefNumberMap);
                	        AESAdviceRequest paymentRequestObj=aesChequeUtility.processFileData(aesAdviceDaoObj,"XLS", aesChequeAdviceFile,sheetName,refNumbersArray,userId,aesChequeAdviceSupportFile,userName,uniqueKeyAndRefNumberMap);
                         
                	        if(paymentRequestObj!=null&&paymentRequestObj.getErrorCode()!=null&&paymentRequestObj.getErrorCode().equalsIgnoreCase("SUCCESS")){
                             try {
                                   SNo=activityDao.insertActivityLog(SNo,userId,"AES Cheque Advice Upload","Success","AES Advice Uploaded",null,null,null);
                                  
                                   
                                 } catch (SQLException e) {
                                    // TODO Auto-generated catch block
                                    logger.info(e.getLocalizedMessage());
                                    StringWriter errors= new StringWriter();
                                    e.printStackTrace(new PrintWriter(errors));
                                    logger.error(errors);
                                    }
                                    paymentDetailsObj.setErrorCode("SUCCESS");
                                    paymentDetailsObj.setErrorMessage(paymentRequestObj.getErrorMessage());
                                    UserDetails userDetailsObj=new UserDetails();
                                    userDetailsObj.setUserId(userId);
                                    try
                                    {
                                    EMailContent emailContentObj=AESChequeUtility.sendEmailAlert("AESADV",aesAdviceDaoObj, paymentRequestObj, userDetailsObj, "FILE_LEVEL_VALIDATIONS_SUCCESS_ALERT");
                                    logger.info("payment advice email body is" +emailContentObj.getEmailBody());
                                    logger.info(" Email Status "+emailContentObj.getErrorCode()+", "+emailContentObj.getErrorMessage());
                                    paymentDetailsObj.setErrorCode("SUCCESS");
                                    paymentDetailsObj.setErrorMessage(paymentRequestObj.getErrorMessage());
                                    }
                                    catch(Exception e)
                                    {
                                    	 logger.info(e.getLocalizedMessage());
                                         StringWriter errors= new StringWriter();
                                         e.printStackTrace(new PrintWriter(errors));
                                         logger.error(errors);
                                       
                                    }
                               }
                                else if(paymentRequestObj!=null&&paymentRequestObj.getErrorCode()!=null&&paymentRequestObj.getErrorCode().equalsIgnoreCase("FAILURE")){
                                
                                try {
                                        SNo=activityDao.insertActivityLog(SNo,userId,"AES Advice Upload","FAILURE","AES Advice is NOT Upoladed",null,null,null);
                                } catch (SQLException e) {
                                // TODO Auto-generated catch block
                                logger.info(e.getLocalizedMessage());
                                StringWriter errors= new StringWriter();
                                e.printStackTrace(new PrintWriter(errors));
                                logger.error(errors);
                                }

                                 paymentDetailsObj.setErrorCode("FAILURE");
                                 paymentDetailsObj.setErrorMessage(paymentRequestObj.getErrorMessage());
                                }
                                else{
                                   paymentDetailsObj.setErrorCode("FAILURE");
                                   paymentDetailsObj.setErrorMessage(" Unable to raise AES Cheque advice request, invalid response received");
                                }
                        }
                        else{
                                paymentDetailsObj.setErrorCode("FAILURE");
                                paymentDetailsObj.setErrorMessage(" Unable to raise  AES Cheque advice request, reason for the failure is "+fileFormatValidation+" and try again ");
                        }
                        
                }
                else if(aesChequeAdviceFile.getOriginalFilename()!=null && aesChequeAdviceFile.getOriginalFilename().toUpperCase().endsWith(".XLSX")){
                        String fileFormatValidation=AESChequeUtility.validateSheetName("XLSX", aesChequeAdviceFile,sheetName);
                        
                        if(fileFormatValidation!=null&&fileFormatValidation.equalsIgnoreCase("SUCCESS")){
                                //AESChequeUtility aesChequeUtility=new AESChequeUtility();
                                AESAdviceRequest paymentRequestObj=aesChequeUtility.processFileData(aesAdviceDaoObj,"XLSX", aesChequeAdviceFile,sheetName,refNumbersArray,userId,aesChequeAdviceSupportFile,userName,uniqueKeyAndRefNumberMap);
                                
                                if(paymentRequestObj!=null&&paymentRequestObj.getErrorCode()!=null&&paymentRequestObj.getErrorCode().equalsIgnoreCase("SUCCESS")){
                                 try {
                                       SNo=activityDao.insertActivityLog(SNo,userId,"AES Cheque Advice Upload","Success","AES Cheque Advice Uploaded",null,null,null);
                                     } catch (SQLException e) {
                                        // TODO Auto-generated catch block
                                        logger.info(e.getLocalizedMessage());
                                        StringWriter errors= new StringWriter();
                                        e.printStackTrace(new PrintWriter(errors));
                                        logger.error(errors);
                                        }
                                        UserDetails userDetailsObj=new UserDetails();
                                        userDetailsObj.setUserId(userId);
                                        logger.info("request id in xlsx mail before sending mail" +paymentRequestObj.getRequestId());
                                        EMailContent emailContentObj=AESChequeUtility.sendEmailAlert("AESADV",aesAdviceDaoObj, paymentRequestObj, userDetailsObj, "FILE_LEVEL_VALIDATIONS_SUCCESS_ALERT");
                                        logger.info(" Email Status "+emailContentObj.getErrorCode()+", "+emailContentObj.getErrorMessage());
                                        paymentDetailsObj.setErrorCode("SUCCESS");
                                        paymentDetailsObj.setErrorMessage(paymentRequestObj.getErrorMessage());
                                }
                                else if(paymentRequestObj!=null&&paymentRequestObj.getErrorCode()!=null&&paymentRequestObj.getErrorCode().equalsIgnoreCase("FAILURE")){
                                        try {
                                                SNo=activityDao.insertActivityLog(SNo,userId,"AES Cheque Advice Upload","FAILURE","AES Cheque Advice is NOT Uploaded",null,null,null);
                                        } catch (SQLException e) {
                                        // TODO Auto-generated catch block
                                        logger.info(e.getLocalizedMessage());
                                        StringWriter errors= new StringWriter();
                                        e.printStackTrace(new PrintWriter(errors));
                                        logger.error(errors);
                                        }
                                        paymentDetailsObj.setErrorCode("FAILURE");
                                        paymentDetailsObj.setErrorMessage(paymentRequestObj.getErrorMessage());
                                }
                                else{
                                        paymentDetailsObj.setErrorCode("FAILURE");
                                        paymentDetailsObj.setErrorMessage(" Unable to raise AES Cheque Advice request, invalid response received");
                                }
                        }
                        else{
                                paymentDetailsObj.setErrorCode("FAILURE");
                                paymentDetailsObj.setErrorMessage(" Unable to raise AES Cheque Advice request, reason for the failure is "+fileFormatValidation+" and try again ");
                        }
                }
                else{
                        paymentDetailsObj.setErrorCode("FAILURE");
                        paymentDetailsObj.setErrorMessage(" Unable to raise AES Cheque Advice request, invalid AES Cheque advice file uploaded "+aesChequeAdviceFile.getOriginalFilename()+", system accepts file names ends with (xls or xlsx) !! ");
                        return paymentDetailsObj;
                }
                
        }
                    else{
                            logger.info(" Unable to raise AES Cheque Advice request, invalid AES Cheque advice file received "+aesChequeAdviceFile);
                            paymentDetailsObj.setErrorCode("FAILURE");
                            paymentDetailsObj.setErrorMessage(" Unable to raise AES Cheque Advice request, invalid reference to AES Cheque advice upload file received, please upload and try again !! ");
                            return paymentDetailsObj;
                    }
            }
            else{
                    paymentDetailsObj.setErrorCode("FAILURE");
                    paymentDetailsObj.setErrorMessage(" Unable to raise AES Cheque Advice request, user id or user name not able retreive from the login session !! ");
                    return paymentDetailsObj;
            }
            
            logger.info(" Exection of  raiseAESAdviceRequest() method has been completed");
            return paymentDetailsObj;
    }	


	@RequestMapping(value = "/checkLockOnAESDetails", method = RequestMethod.POST)
	public @ResponseBody AESAdviceLock checkLockOnAESDetails(
			HttpServletRequest request, HttpServletResponse response) {
		logger.info(" Got an hit to url /checkLockOnAESDetails");
		logger.info(" Calling  checkLockOnAESDetails() method to raise payment advice request");
		session = request.getSession(true);
		String userId = session.getAttribute("userid").toString();

		String referenceNum = request.getParameter("referenceNumber");
		logger.info(" referenceNum--------"+referenceNum+"user   id is -----------"+userId);
		AESAdviceLock paymentAdviceLockObj = new AESAdviceLock();
		try{
		paymentAdviceLockObj.setReferenceNum(referenceNum);
		paymentAdviceLockObj.setLockAcuiredBy(userId);
		paymentAdviceLockObj = aesAdviceDaoObj
				.checkLockOnAESDetails(paymentAdviceLockObj);
		logger.info(" Exection of  raiseAESAdviceRequest() method has been completed");
}catch(Exception e){
	logger.info(e.getLocalizedMessage());
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);

}
		return paymentAdviceLockObj;
	}

	@RequestMapping(value = "/acquireLockOnAESDetails", method = RequestMethod.POST)
	public @ResponseBody AESAdviceLock acquireLockOnAESDetails(
			HttpServletRequest request, HttpServletResponse response) {
		logger.info(" Got an hit to url /acquireLockOnAESDetails");
		logger.info(" Calling  acquireLockOnAESDetails() method to raise payment advice request");
		session = request.getSession(true);
		String userId = session.getAttribute("userid").toString();
		String referenceNum = request.getParameter("referenceNumber");
		logger.info("Reference Number------->"+referenceNum+" user id is---------> "+userId);
		AESAdviceLock paymentAdviceLockObj = new AESAdviceLock();
try{
		paymentAdviceLockObj.setLockAcuiredBy(userId);
		paymentAdviceLockObj.setReferenceNum(referenceNum);
		paymentAdviceLockObj = aesAdviceDaoObj
				.acquireLockOnAESDetails(paymentAdviceLockObj);
		logger.info(" Exection of  acquireLockOnAESDetails() method has been completed");
}catch(Exception e){
	logger.info(e.getLocalizedMessage());
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);
}
		return paymentAdviceLockObj;
	}

	@RequestMapping(value = "/releaseLockOnAESDetails", method = RequestMethod.POST)
	public @ResponseBody AESAdviceLock releaseLockOnAESDetails(
			HttpServletRequest request, HttpServletResponse response) {
		logger.info(" Got an hit to url /releaseLockOnAESDetails");
		logger.info(" Calling  releaseLockOnAESDetails() method to raise payment advice request");
		session = request.getSession(true);
		String userId = session.getAttribute("userid").toString();
		String referenceNum = request.getParameter("referenceNumber");
		AESAdviceLock paymentAdviceLockObj = new AESAdviceLock();
try{
		paymentAdviceLockObj.setLockAcuiredBy(userId);
		paymentAdviceLockObj.setReferenceNum(referenceNum);
		paymentAdviceLockObj = aesAdviceDaoObj
				.releaseLockOnAESDetails(paymentAdviceLockObj);
		logger.info(" Exection of  releaseLockOnAESDetails() method has been completed");
}catch(Exception e){
	logger.info(e.getLocalizedMessage());
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);

}
		return paymentAdviceLockObj;
	}

	@RequestMapping(value = "/getAESAdviceTemplate", method = RequestMethod.POST)
	public ModelAndView downLoadAESAdviceUploadTemplate(
			HttpServletRequest request, HttpServletResponse response) {
		logger.info(" Got an hit to url /downLoadAESAdviceUploadTemplate");
		logger.info(" Calling  downLoadAESAdviceUploadTemplate() method ");
		session = request.getSession(true);
		ModelAndView modelAndViewObj=new ModelAndView();
		AESAdviceTemplate paymentAdviceTemplateObj = new AESAdviceTemplate();
		String userId = session.getAttribute("userid").toString();
		paymentAdviceTemplateObj.setUserId(userId);
		paymentAdviceTemplateObj.setTemplatePath(paymentAdviceHomePath
				+ "/Templates/");
		String templateRequired=request.getParameter("templateName");
		if(templateRequired!=null&&templateRequired.equalsIgnoreCase("XLS")){
			//paymentAdviceTemplateObj.setTemplateName("AESADV_YYMMDD_NNNN.xls");
			paymentAdviceTemplateObj.setTemplateName("AES_Advice_Upload.xls");
			
			paymentAdviceTemplateObj.setDownloadedFileName(paymentAdviceTemplateObj
					.getTemplateName());

			ServletOutputStream out = null;
			FileInputStream in = null;
			try {
				out = response.getOutputStream();
				in = new FileInputStream(paymentAdviceTemplateObj.getTemplatePath()
						+ paymentAdviceTemplateObj.getTemplateName());

				response.setContentType("APPLICATION/OCTET-STREAM");

				response.addHeader("content-disposition", "attachment; filename="
						+ paymentAdviceTemplateObj.getDownloadedFileName());
				int octet;
				while ((octet = in.read()) != -1)
					out.write(octet);
				in.close();
				out.flush();
				out.close();
				response.flushBuffer();
				paymentAdviceTemplateObj.setErrorCode("SUCCESS");
				paymentAdviceTemplateObj.setErrorMessage("Download template "+paymentAdviceTemplateObj.getDownloadedFileName()+" has been downloaded successfully !!");
			} catch (FileNotFoundException e) {
				logger.info(e.getLocalizedMessage());
				paymentAdviceTemplateObj.setErrorCode("FAILURE");
				paymentAdviceTemplateObj.setErrorMessage(" Unable to download template file, because source file not found in the server ");
				modelAndViewObj.addObject("error", "Unable to download template file, because source file not found in the server ");
				// TODO Auto-generated catch block
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			} catch (IOException e) {
				logger.info(e.getLocalizedMessage());
				paymentAdviceTemplateObj.setErrorCode("FAILURE");
				paymentAdviceTemplateObj.setErrorMessage(" Unable to download template file, because IO Exception occured ");
				modelAndViewObj.addObject("error", "Unable to download template file, because IO Exception occured ");
				// TODO Auto-generated catch block
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
			paymentAdviceTemplateObj.setErrorCode("SUCCESS");

		}
		else if(templateRequired!=null&&templateRequired.equalsIgnoreCase("XLSX")){
			//paymentAdviceTemplateObj.setTemplateName("AESADV_YYMMDD_NNNN.xlsx");
			paymentAdviceTemplateObj.setTemplateName("AES_Advice_Upload.xlsx");
			paymentAdviceTemplateObj.setDownloadedFileName(paymentAdviceTemplateObj
					.getTemplateName());

			ServletOutputStream out = null;
			FileInputStream in = null;
			try {
				out = response.getOutputStream();
				in = new FileInputStream(paymentAdviceTemplateObj.getTemplatePath()
						+ paymentAdviceTemplateObj.getTemplateName());

				response.setContentType("APPLICATION/OCTET-STREAM");

				response.addHeader("content-disposition", "attachment; filename="
						+ paymentAdviceTemplateObj.getDownloadedFileName());
				int octet;
				while ((octet = in.read()) != -1)
					out.write(octet);
				in.close();
				out.flush();
				out.close();
				response.flushBuffer();
				paymentAdviceTemplateObj.setErrorCode("SUCCESS");
				paymentAdviceTemplateObj.setErrorMessage("Download template "+paymentAdviceTemplateObj.getDownloadedFileName()+" has been downloaded successfully !!");
			} catch (FileNotFoundException e) {
				logger.info(e.getLocalizedMessage());
				paymentAdviceTemplateObj.setErrorCode("FAILURE");
				paymentAdviceTemplateObj.setErrorMessage(" Unable to download template file, because source file not found in the server ");
				modelAndViewObj.addObject("error", "Unable to download template file, because source file not found in the server ");
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			} catch (IOException e) {
				logger.info(e.getLocalizedMessage());
				paymentAdviceTemplateObj.setErrorCode("FAILURE");
				paymentAdviceTemplateObj.setErrorMessage(" Unable to download template file, because IO Exception occured ");
				modelAndViewObj.addObject("error", "Unable to download template file, because IO Exception occured ");
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
			paymentAdviceTemplateObj.setErrorCode("SUCCESS");

		}
		modelAndViewObj.setViewName("paymentAdviceHome");;
		logger.info(" Execution of downLoadAESAdviceUploadTemplate() method completed ");
		return modelAndViewObj;
	}
	@RequestMapping(value = "/templateDownloadAES", method = RequestMethod.GET)
	public ModelAndView templateDownloadAPSINHelp(HttpServletRequest request,HttpServletResponse response) throws IOException {

		logger.info("START WorkFlowController------>templateDownloadAPS");
		ModelAndView modelAndViewObj = new ModelAndView();
		String filepath=null;
		String fileToDownload=null;
		
		FileInputStream in=null;
		String type=request.getParameter("type");
		if(type!=null && type.equalsIgnoreCase("templates"))
		{
			fileToDownload =request.getParameter("fileName");
		    filepath =templatesPath+File.separator;
		}  
		/*else
		{
			fileToDownload =request.getParameter("fileName");
			filepath=downloadpath+File.separator;
		}*/
		 String fileName = filepath+fileToDownload;
		 logger.info("File Name is "+fileName);

	        ServletOutputStream out = response.getOutputStream();
	        try
	        {
	         in = new FileInputStream(fileName);
	         modelAndViewObj.addObject("messsage", "");
	        }
	        catch(Exception e)
	        {
	        	logger.error(e);
	        	modelAndViewObj.addObject("messsage", "File not found with particular name");
	    		modelAndViewObj.setViewName("helpbulkUpload");
	    		return modelAndViewObj;
	        }
	      response.setContentType("APPLICATION/OCTET-STREAM");
	      response.addHeader("content-disposition",
	                "attachment; filename=" + fileToDownload);
	  

	        int octet;
	        while((octet = in.read()) != -1)
	            out.write(octet);

	        in.close();
	        out.flush();
	        out.close();
	        response.flushBuffer();
	        modelAndViewObj.setViewName("BulkUpload");
	        logger.info("END WorkFlowController------>templateDownloadAPS");
		return modelAndViewObj;
		
	}


}
