package com.airtel.ace.cad.paymentadvice.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.acecad.bulkupload.model.FileDetails;
import com.acecad.bulkupload.model.PaymentTransferDTO;
import com.acecad.bulkupload.model.UserEmailDetails;
import com.airtel.ace.cad.aesadvice.model.AESFileDetails;
import com.airtel.ace.cad.aesadvice.model.AESFileStatus;
import com.airtel.ace.cad.aesadvice.model.AESVendorFileRecords;
import com.airtel.ace.cad.paymentadvice.dao.AESApprovalDAO;
import com.airtel.ace.cad.paymentadvice.dao.ApprovalDAO;
import com.airtel.ace.cad.paymentadvice.model.ApprovalDetails;
import com.airtel.acecad.UtilityJar.ActivityLog;
import com.airtel.acecad.bulkupload.dto.CheckedFile;
import com.airtel.acecad.model.EMailContent;
import com.airtel.acecad.model.SmtpMailContent;
import com.airtel.acecad.utility.SmtpUtility;
@Controller
public class AESAdviceApproval {
	private String homePath=System.getenv("ACE_CAD_HOME"); 
	//ApprovalDetails approvalDetailsObj=new ApprovalDetails();
	ApprovalDetails approvalDetailsObj=new ApprovalDetails();
	HttpSession session;
	@Value("${LDAP_DOMAIN}")
	private String LDAP_DOMAIN;

	@Value("${LDAP_URL}")
	private String LDAP_URL;

	@Value("${PAYMENT_ADVICE_HOME}")
	private String downloadpath;
	@Autowired
	ApprovalDAO approvaldao;
	@Autowired
	AESApprovalDAO aesapprovaldao;
	@Autowired
	ActivityLog activityDao;
	/*@Autowired
	VendorDetails vendorDetailsObj;
*/
	@Autowired
	ActivityLog activityLog;
	private static Logger logger = LogManager.getLogger("aesAdviceApprovalLogger");
	private static String paymentAdviceHomePath = System.getenv("PAYMENT_ADVICE_HOME");
	String filepath=System.getenv("ACE_CAD_HOME")+File.separator+"UPLOADED_FILES"+File.separator+"AESChequeAllocation"+File.separator+"InputFiles";
    
/*	@RequestMapping(value = "/AESApprovals")
	public ModelAndView showApprovalDetails(ModelMap model,HttpServletRequest request, HttpServletResponse response)

	{
		logger.info("START ------>aesApprove");
		List<AESFileDetails> fileStatusListFinal = new ArrayList<AESFileDetails>();
		List<String> statusList = new ArrayList<String>();
		AESFileStatus fileStatusDTO = new AESFileStatus();
			
		int page = 0;
		boolean noSearchCriteria=true;
		session = request.getSession(true);
		ModelAndView modelAndViewObj = new ModelAndView();
		try{
			page = Integer.parseInt(request.getParameter("pageNum"));
		}
		catch(Exception e){
			page = 1;
		}
		finally{
			try {
			
			fileStatusDTO = aesapprovaldao.getFilesApprove(page);
				Iterator<AESFileDetails> iter = fileStatusDTO.getFileStatusList().iterator();
				while(iter.hasNext()){
					AESFileDetails fileStatusAPS = iter.next();
					String path = filepath+File.separator+fileStatusAPS.getFilePath();
					
					File f = new File(path);
				if(f.exists() && !f.isDirectory()) { 
					   fileStatusAPS.setIsExist("YES");
					}else{
						fileStatusAPS.setIsExist("NO");
					}
				
					
					fileStatusListFinal.add(fileStatusAPS);
						
				}
				List<String> rejectReasonList=approvaldao.getRejectReasons();
				
				modelAndViewObj.addObject("statusList",statusList);
				modelAndViewObj.addObject("filtersearch", "true");
				modelAndViewObj.addObject("fileStatusList",fileStatusListFinal);
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("totalRecords",fileStatusDTO.getTotalResults());
				modelAndViewObj.addObject("resultsPerPage",fileStatusDTO.getResultPerPage());
				modelAndViewObj.addObject("totalPages", fileStatusDTO.getTotalPages());
				modelAndViewObj.addObject("checkedFile", new CheckedFile());
				modelAndViewObj.addObject("rejectReasonList", rejectReasonList);
				modelAndViewObj.setViewName("AESAApprovals");
			} catch (Exception e) {
				logger.error(e);
			}
		}
		return modelAndViewObj;
		}*/

	
	@RequestMapping(value = "/AESApprovals")
	public ModelAndView showApprovalDetails(ModelMap model,HttpServletRequest request, HttpServletResponse response)

	{
		logger.info("START ------>aesApprove");
		List<AESFileDetails> fileStatusListFinal = new ArrayList<AESFileDetails>();
		List<String> statusList = new ArrayList<String>();
		//AESFileStatus aesFileStatusDTO = new AESFileStatus();
		AESFileDetails aesFileDetails = new AESFileDetails();
		
		int page = 0;
		boolean noSearchCriteria=true;
		session = request.getSession(true);
		ModelAndView modelAndViewObj = new ModelAndView();	
		String roleId = session.getAttribute("user_role_id").toString();
		String searchOlmId=null;
		String searchFileId = null;
		String searchFileName = null;
		String searchFromDate =null;
		String searchEndDate =null;
		
		try{
			page = Integer.parseInt(request.getParameter("pageNum"));
		}
		catch(Exception e){
			page = 1;
		}
		finally{
			try {
				
				if(request.getParameter("pageNum")!=null){
					aesFileDetails.setCurrentPage(Integer.parseInt(request.getParameter("pageNum")));
					noSearchCriteria=false;
				}else
					aesFileDetails.setCurrentPage(page);
				
				if(request.getParameter("OLMIdSearch")!=null){
					aesFileDetails.setOlmId(request.getParameter("OLMIdSearch"));
					noSearchCriteria=false;
				}else
					aesFileDetails.setOlmId(searchOlmId);
				
				if(request.getParameter("fileIdSearch")!=null){
					aesFileDetails.setFileId(request.getParameter("fileIdSearch"));
				}else
					aesFileDetails.setFileId(searchFileId);
				
				if(request.getParameter("fileNameSearch")!=null){
					aesFileDetails.setFileName(request.getParameter("fileNameSearch"));
				}else
					aesFileDetails.setFileName(searchFileName);
				
				if(request.getParameter("fromDate")!=null){
					aesFileDetails.setSearchFromDate(request.getParameter("fromDate"));
					noSearchCriteria=false;
				}else
					aesFileDetails.setSearchFromDate(searchFromDate);
				
				if(request.getParameter("endDate")!=null){
					aesFileDetails.setSearchEndDate(request.getParameter("endDate"));
					noSearchCriteria=false;
				}else
					aesFileDetails.setSearchEndDate(searchEndDate);	
				
				List<String> rejectReasonList=approvaldao.getRejectReasons();
				if(rejectReasonList==null)
				 {
					 modelAndViewObj.addObject("error", "Problem with Backend System");
					 modelAndViewObj.setViewName("AESAApprovals");
					 return modelAndViewObj;
				 }
				
				aesFileDetails = aesapprovaldao.getAESChqWorkFlowApprovalDetails(roleId, aesFileDetails);
			    
				if(noSearchCriteria){
					modelAndViewObj.addObject("filtersearch", "true");	
				}else
				modelAndViewObj.addObject("filtersearch", "false");	
				
				modelAndViewObj.addObject("totalRecords",aesFileDetails.getTotalResults());
				modelAndViewObj.addObject("resultsPerPage",aesFileDetails.getResultPerPage());				
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("totalPages", aesFileDetails.getTotalPages());
				modelAndViewObj.addObject("aesFileDetailList", aesFileDetails.getAesChqWorkFlowDetailsList());
				modelAndViewObj.addObject("message", aesFileDetails.getErrorMsg());
				modelAndViewObj.addObject("aesFileDetailsDTO",new AESFileDetails());			
				modelAndViewObj.addObject("rejectReasonList", rejectReasonList);
				modelAndViewObj.setViewName("AESAApprovals");
	
			} catch (Exception e) {
				logger.error(e);
			}
		}
		return modelAndViewObj;
		}

	
	@RequestMapping(value = "/aesApproveFile")
    public ModelAndView Approve(@RequestParam String action,@ModelAttribute("aesFileDetailsDTO") AESFileDetails aesFileDetailsDTO,HttpServletRequest request)
	{
		ModelAndView modelAndViewObj = new ModelAndView();
		session=request.getSession(true);
		String roleId = session.getAttribute("user_role_id").toString();
		String userId = session.getAttribute("userid").toString();
		
		List<FileDetails> approveFinalList=new ArrayList<FileDetails>();
		
		int page = 1;		
		action = request.getParameter("action");	
		String  rejectReasonRemarks=request.getParameter("reason");
		aesFileDetailsDTO.setRejectReason(rejectReasonRemarks);
		
		//String [] filesId=request.getParameterValues("selectedRadio");
		
		List<String>checkedAESList =aesFileDetailsDTO.getCheckedAESChqApprovalList();
		
		logger.info("In approve method " + action);		
		//logger.info("and File ID list size is " + filesId.toString());
		logger.info("Remark " + rejectReasonRemarks);
		
		/*List<String> fileids=new ArrayList<String>();
		for(String fileId:filesId)
			fileids.add(fileId);*/
			
		
		List<AESFileDetails> fileStatusListFinal = new ArrayList<AESFileDetails>();
		
		String message = "";
		Object[] obj =new Object[2];
		try {
			String status = null;
			aesFileDetailsDTO.setCurrentPage(page);
			
			obj = (Object[]) aesapprovaldao.approveFile(checkedAESList,rejectReasonRemarks, userId, action,aesFileDetailsDTO.getRejectReasonDropDown());
			
			status= (String) obj[0];
			approveFinalList= (List<FileDetails>) obj[1];
			
			logger.info("Status from Procedure is "+status);
			if (status.equalsIgnoreCase("Success") && action.equals("A")) {
				message = "AES File Approved.";

			} else if (status.equalsIgnoreCase("Success") && action.equals("R")) {
				message = "AES File Rejected.";
			}
			if (!status.equalsIgnoreCase("Success")) {
				message =  status;
			}
			logger.info("Inside approve button click method");
				
			/*Iterator<AESFileDetails> iter = fileStatusDTO.getFileStatusList().iterator();
			
			while(iter.hasNext()){
				AESFileDetails fileStatusAPS = iter.next();
				String path = filepath+File.separator+fileStatusAPS.getFilePath();
				logger.info("path is "+path);
				File f = new File(path);
				if(f.exists() && !f.isDirectory()) { 
				   fileStatusAPS.setIsExist("YES");
				}else{
					fileStatusAPS.setIsExist("NO");
				}
			
				
				fileStatusListFinal.add(fileStatusAPS);
					
			}*/
			
			List<String> rejectReasonList=approvaldao.getRejectReasons();
			
			/*modelAndViewObj.addObject("filtersearch", "true");
			modelAndViewObj.addObject("fileStatusList",fileStatusListFinal);
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.addObject("totalRecords",fileStatusDTO.getTotalResults());
			modelAndViewObj.addObject("resultsPerPage",fileStatusDTO.getResultPerPage());
			modelAndViewObj.addObject("totalPages", fileStatusDTO.getTotalPages());
			modelAndViewObj.addObject("checkedFile", new CheckedFile());
			
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.addObject("rejectReasonList", rejectReasonList);
			modelAndViewObj.addObject("message", "No service request in queue for approval");
			modelAndViewObj.addObject("approveRejectMessage", message);*/
			
			modelAndViewObj.addObject("message", message);
			modelAndViewObj.addObject("approveRejectMessage", message);
			modelAndViewObj.addObject("approveFinalListDetails", approveFinalList);
			modelAndViewObj.setViewName("AESAApproved");
			//Sending Mail
			
			File fileObj;
			if(action.equals("A"))
			{
				fileObj =new File(homePath+"/Conf/EmailAlertsTemplates/AESAdviceRequestApprove.properties");
			}
			else
			{
			  fileObj=new File(homePath+"/Conf/EmailAlertsTemplates/AESAdviceRequestReject.properties");
			}
				
			InputStream inputStream=new FileInputStream(fileObj);
			Properties properties=new Properties();
			properties.load(inputStream);
			
			UserEmailDetails userEmailDetails = new UserEmailDetails();
			userEmailDetails=aesapprovaldao.getEmailAddress(userId);
			logger.info("approveFinalList.size::>>>"+approveFinalList.size());
			for(int i=0;i<approveFinalList.size();i++)
			{	
			 logger.info("approveFinalList.get(i).getFileID()>>" +approveFinalList.get(i).getFileID());
			 logger.info("approveFinalList.get(i).getRequestStatus()>>" +approveFinalList.get(i).getRequestStatus());
			 if((approveFinalList.get(i).getRequestStatus())!=null){
				EMailContent emailContentObj=new EMailContent();
				
				emailContentObj.setEmailSubject(properties.getProperty("EmailSubject").replace("Ticket no.:", (approveFinalList.get(i).getFileID())));
				emailContentObj.setEmailHeader(properties.getProperty("EmailHeader"));
				
				if(action.equals("A")){
				 emailContentObj.setEmailBody(properties.getProperty("EmailBody").replace("Ticket no.:","Ticket no.:"+""+(approveFinalList.get(i).getFileID()))
						.replace("Total Records:","Total Records :"+""+approveFinalList.get(i).getTotalRecords()).replace("Total Value:", "Total Value: "+""+approveFinalList.get(i).getValidSum()));
				}
				
				if(action.equals("R")){
				  emailContentObj.setEmailBody(properties.getProperty("EmailBody").replace("Ticket no.:","Ticket no.:"+""+(approveFinalList.get(i).getFileID()))
						.replace("reason:","reason :"+""+approveFinalList.get(i).getRejectReason())
						.replace("rejectionRemarks:","rejectionRemarks :"+""+approveFinalList.get(i).getRejectedRemarks())
						.replace("Total Records:","Total Records :"+""+approveFinalList.get(i).getTotalRecords()).replace("Total Value:", "Total Value: "+""+approveFinalList.get(i).getValidSum()));
				}
				
				emailContentObj.setEmailFooter(properties.getProperty("EmailFooter"));

				logger.info("email subject is " +emailContentObj.getEmailSubject());
				logger.info("email body is " +emailContentObj.getEmailBody());
				List<String> emailToList=new ArrayList<String>();
				emailToList.add(approveFinalList.get(i).getEmailId());
				logger.info("uploaded email id" +approveFinalList.get(i).getEmailId());
				emailContentObj.setEmailToList(emailToList);
     	        List<String> emailCCList=new ArrayList<String>();
				emailCCList.add(userEmailDetails.getEmailAddress());

				emailContentObj.setEmailCCList(emailCCList);
        		emailContentObj.setAttachmentRequired(false);

				SmtpUtility.setLogger(logger);

				SmtpMailContent smtpMailContentObj=SmtpUtility.generateEmailAlert(emailContentObj);
				logger.info("Error Code "+smtpMailContentObj.getErrorCode());
				logger.info(" Error Message "+smtpMailContentObj.getErrorMessage());
			 }
			}
			
		
		} catch (Exception e) {
			logger.error(e);
		}
		
		
		return modelAndViewObj;
	}
	
	/*@RequestMapping(value = "/aesApproveFile")
	public ModelAndView Approve(@RequestParam String action,@ModelAttribute("checkedSR") CheckedFile checkedFile,HttpServletRequest request)
	{
		logger.info("In approve method " + action);
		ModelAndView modelAndViewObj = new ModelAndView();
		session=request.getSession(true);
		String roleId = session.getAttribute("user_role_id").toString();
		String userId = session.getAttribute("userid").toString();
		
		
		int page = 1;		
		action = request.getParameter("action");
		
		List<FileDetails> approveFinalList=new ArrayList<FileDetails>();
		String [] filesId=request.getParameterValues("selectedRadio");
		String  reasonTest=request.getParameter("reason");
		String  reason=request.getParameter("Reasons");
		logger.info("In approve method " + action);
		
		AESFileStatus fileStatusDTO = new AESFileStatus();
		
		logger.info("and File ID list size is " + filesId.toString());
		logger.info(" Reason  " + reason);
		logger.info("Remark " + reasonTest);
		List<String> fileids=new ArrayList<String>();
		for(String fileId:filesId)
			fileids.add(fileId);
			
		
		List<AESFileDetails> fileStatusListFinal = new ArrayList<AESFileDetails>();
		
		String message = "";
		Object[] obj =new Object[2];
		try {
			String status = "";
			
			//status = aesapprovaldao.approveFile(fileids,reasonTest,reason, userId, action);
			obj = (Object[]) aesapprovaldao.approveFile(fileids,reasonTest,reason, userId, action);
			status= (String) obj[0];
			approveFinalList= (List<FileDetails>) obj[1];
			logger.info("Status from Procedure is "+status);
			if (status.equalsIgnoreCase("Success") && action.equals("A")) {
				message = "AES File Approved.";

			} else if (status.equalsIgnoreCase("Success") && action.equals("R")) {
				message = "AES File Rejected.";
			}
			if (!status.equalsIgnoreCase("Success")) {
				message =  status;
			}
			logger.info("Inside approve button click method");
			//Ritu
			//fileStatusDTO = aesapprovaldao.getFilesApprove(page);
			
			Iterator<AESFileDetails> iter = fileStatusDTO.getFileStatusList().iterator();
			
			while(iter.hasNext()){
				AESFileDetails fileStatusAPS = iter.next();
				String path = filepath+File.separator+fileStatusAPS.getFilePath();
				logger.info("path is "+path);
				File f = new File(path);
				if(f.exists() && !f.isDirectory()) { 
				   fileStatusAPS.setIsExist("YES");
				}else{
					fileStatusAPS.setIsExist("NO");
				}
			
				
				fileStatusListFinal.add(fileStatusAPS);
					
			}
			List<String> rejectReasonList=approvaldao.getRejectReasons();
			modelAndViewObj.addObject("filtersearch", "true");
			modelAndViewObj.addObject("fileStatusList",fileStatusListFinal);
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.addObject("totalRecords",fileStatusDTO.getTotalResults());
			modelAndViewObj.addObject("resultsPerPage",fileStatusDTO.getResultPerPage());
			modelAndViewObj.addObject("totalPages", fileStatusDTO.getTotalPages());
			modelAndViewObj.addObject("checkedFile", new CheckedFile());
			
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.addObject("rejectReasonList", rejectReasonList);
			modelAndViewObj.addObject("message", "No service request in queue for approval");
			modelAndViewObj.addObject("approveRejectMessage", message);
			
			//Sending Mail
			
			File fileObj;
			if(action.equals("A"))
			{
				fileObj =new File(homePath+"/Conf/EmailAlertsTemplates/AESAdviceRequestApprove.properties");
			}
			else
			{
			  fileObj=new File(homePath+"/Conf/EmailAlertsTemplates/AESAdviceRequestReject.properties");
			}
				
			InputStream inputStream=new FileInputStream(fileObj);
			Properties properties=new Properties();
			properties.load(inputStream);
			
			UserEmailDetails userEmailDetails = new UserEmailDetails();
			userEmailDetails=aesapprovaldao.getEmailAddress(userId);
			logger.info("approveFinalList.size::>>>"+approveFinalList.size());
			for(int i=0;i<approveFinalList.size();i++)
			{	
			 logger.info("approveFinalList.get(i).getFileID()>>" +approveFinalList.get(i).getFileID());
			 logger.info("approveFinalList.get(i).getRequestStatus()>>" +approveFinalList.get(i).getRequestStatus());
			 if((approveFinalList.get(i).getRequestStatus())!=null){
				EMailContent emailContentObj=new EMailContent();
				
				emailContentObj.setEmailSubject(properties.getProperty("EmailSubject").replace("Ticket no.:", (approveFinalList.get(i).getFileID())));
				emailContentObj.setEmailHeader(properties.getProperty("EmailHeader"));
				
				if(action.equals("A")){
				 emailContentObj.setEmailBody(properties.getProperty("EmailBody").replace("Ticket no.:","Ticket no.:"+""+(approveFinalList.get(i).getFileID()))
						.replace("Total Records:","Total Records :"+""+approveFinalList.get(i).getTotalRecords()).replace("Total Value:", "Total Value: "+""+approveFinalList.get(i).getValidSum()));
				}
				
				if(action.equals("R")){
				  emailContentObj.setEmailBody(properties.getProperty("EmailBody").replace("Ticket no.:","Ticket no.:"+""+(approveFinalList.get(i).getFileID()))
						.replace("reason:","reason :"+""+approveFinalList.get(i).getRejectReason())
						.replace("rejectionRemarks:","rejectionRemarks :"+""+approveFinalList.get(i).getRejectedRemarks())
						.replace("Total Records:","Total Records :"+""+approveFinalList.get(i).getTotalRecords()).replace("Total Value:", "Total Value: "+""+approveFinalList.get(i).getValidSum()));
				}
				
				emailContentObj.setEmailFooter(properties.getProperty("EmailFooter"));

				logger.info("email subject is " +emailContentObj.getEmailSubject());
				logger.info("email body is " +emailContentObj.getEmailBody());
				List<String> emailToList=new ArrayList<String>();
				emailToList.add(approveFinalList.get(i).getEmailId());
				logger.info("uploaded email id" +approveFinalList.get(i).getEmailId());
				emailContentObj.setEmailToList(emailToList);
     	        List<String> emailCCList=new ArrayList<String>();
				emailCCList.add(userEmailDetails.getEmailAddress());

				emailContentObj.setEmailCCList(emailCCList);
        		emailContentObj.setAttachmentRequired(false);

				SmtpUtility.setLogger(logger);

				SmtpMailContent smtpMailContentObj=SmtpUtility.generateEmailAlert(emailContentObj);
				logger.info("Error Code "+smtpMailContentObj.getErrorCode());
				logger.info(" Error Message "+smtpMailContentObj.getErrorMessage());
			 }
			}
			
		
		} catch (Exception e) {
			logger.error(e);
		}
		
		modelAndViewObj.setViewName("AESAApprovals");
		return modelAndViewObj;
	} */
	
	/*	@RequestMapping(value = "/aesSearch", method = RequestMethod.GET)
		public ModelAndView apsFileSearch(HttpServletRequest request,HttpServletResponse response)throws Exception{
			logger.info("Reaching search file");
			List<AESFileDetails> fileStatusListFinal = new ArrayList<AESFileDetails>();
			int page = 0;
			String fileId= null, fromDate = null,endDate = null,fileName=null,viewName=null,fileIdentifier=null,olmid=null;
			List<String> statusList = new ArrayList<String>();
			ModelAndView modelAndViewObj = new ModelAndView();
			AESFileStatus fileStatusDTO = new AESFileStatus();
			try{
				 page = Integer.parseInt(request.getParameter("pageNum"));
				 viewName = request.getParameter("viewName");
				 fileId = request.getParameter("fileIdSearch");
				 fromDate = request.getParameter("fromDate");
				 endDate = request.getParameter("endDate");
				 olmid = request.getParameter("OLMIdSearch");
				 fileName = request.getParameter("fileNameSearch");
				 if(olmid == null){
					 olmid ="";
				 }
				 				 
				 
			}
			catch(Exception e){
				page = 1;
				 fileId = request.getParameter("fileIdSearch");
				 viewName = request.getParameter("viewName");
				 fromDate = request.getParameter("fromDate");
				 endDate = request.getParameter("endDate");
				 olmid = request.getParameter("OLMIdSearch");
				 fileName = request.getParameter("fileNameSearch");
				   if(olmid == null){
					 olmid ="";
				 }
				 
			}
			
			finally{
				fromDate = (fromDate == null) ? "" : fromDate;
				endDate = (endDate == null) ? "" : endDate;
				logger.info("File id is "+fileId );
				logger.info("from date is "+fromDate +" and end date is "+endDate);
				fileStatusDTO = aesapprovaldao.searchFileAPS(fileId, fileName, fromDate, endDate, page,viewName,olmid.toUpperCase().trim());
				Iterator<AESFileDetails> iter = fileStatusDTO.getFileStatusList().iterator();
				while(iter.hasNext()){
					AESFileDetails fileStatusAPS = iter.next();
					String path = filepath+File.separator+fileStatusAPS.getFilePath();
					logger.info("path is "+path);
					File f = new File(path);
					if(f.exists() && !f.isDirectory()) { 
					   fileStatusAPS.setIsExist("YES");
					}else{
						fileStatusAPS.setIsExist("NO");
					}
					
					fileStatusListFinal.add(fileStatusAPS);
				}
				List<String> rejectReasonList=approvaldao.getRejectReasons();
				modelAndViewObj.addObject("rejectReasonList", rejectReasonList);
				modelAndViewObj.addObject("searchedFileName", fileName);
				modelAndViewObj.addObject("searchedOlmid", olmid);
				modelAndViewObj.addObject("filtersearch", "false");
				modelAndViewObj.addObject("searchedFileId", fileId);
				modelAndViewObj.addObject("searchedFromDate", fromDate);
				modelAndViewObj.addObject("searchedEndDate", endDate);
				modelAndViewObj.addObject("fileStatusList",fileStatusListFinal);
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("totalRecords",fileStatusDTO.getTotalResults());
				modelAndViewObj.addObject("resultsPerPage",fileStatusDTO.getResultPerPage());
				modelAndViewObj.addObject("totalPages", fileStatusDTO.getTotalPages());
				modelAndViewObj.setViewName("AESAApprovals");
				modelAndViewObj.addObject("checkedFile", new CheckedFile());
				}
			return modelAndViewObj;
		
	
	}*/
		
		@RequestMapping(value = "/downloadAesFile" , method = RequestMethod.GET)
		public ModelAndView downloadFileByFileId(HttpServletRequest request,HttpServletResponse response) throws IOException{
			logger.info("START ------------------->downloadFileByFileId");
			ModelAndView modelAndViewObj = new ModelAndView();
			session = request.getSession(true);
			String fileName = request.getParameter("fileName");
			
			
			//modelAndViewObj.setViewName(fileName);
					/* log.info("End of failure records download "); */
			
			ServletOutputStream out = response.getOutputStream();
			FileInputStream in;
			fileName = filepath.substring(filepath.lastIndexOf("\\")+1,filepath.length());
			logger.info(fileName);
			fileName =   fileName.substring(fileName.lastIndexOf("/")+1,fileName.length());;
			logger.info("File Name of downloaded file is after removing / "+fileName);
		        try
		        {
		         in = new FileInputStream(filepath);
		         File file = new File(filepath);
		         modelAndViewObj.addObject("messsage", "");
		         response.setContentType("APPLICATION/OCTET-STREAM");
		         logger.info(file.getAbsolutePath()+" and ");
		        /* response.setContentLength(Integer.parseInt(String.valueOf(file.length())));*/
		        /* response.addHeader("Content-Length", String.valueOf(file.length()));*/
			     response.addHeader("content-disposition",
			                "attachment; filename="+fileName);
			     logger.info("file name in downloadFileByFileId "+fileName);
			     modelAndViewObj.setViewName("AESAApprovals");
			       	int octet;
			        while((octet = in.read()) != -1)
			            out.write(octet);

			        in.close();
			        out.flush();
			        out.close();
			        response.flushBuffer();
		        }
		        catch(Exception e)
		        {
		        	logger.error(e);
		        	modelAndViewObj.addObject("messsage", "File not found with particular name");
		    		return modelAndViewObj;
		        }
		   logger.info("File Name in downloadFileByFileId in last "+fileName);
			return null;
		}

    @RequestMapping(value = "/aesDownload", method = RequestMethod.GET)
	public void aesChequeDownload(HttpServletRequest request,HttpServletResponse response) throws IOException {
	
		try{
	    	  
	    	    logger.info("ENTERED INTO aesChequeDownload EXPORT TO EXCEL METHOD @ CONTROLLER");
	    		//String extension="xlsx";
	    		String requestFileIdId = request.getParameter("FileId");
	    		String requestFileName = request.getParameter("FileName");
	    		
	    		if(requestFileName.endsWith(".xls")==true)
	    			
	    			requestFileName=requestFileName.replace(".xls",
	    					"_" +requestFileIdId + ".xls");
	    		
	    		else if(requestFileName.endsWith(".xlsx")==true)
	    			requestFileName=requestFileName.replace(".xlsx",
	    					"_" +requestFileIdId + ".xlsx");
	    		
		    	
	            logger.info("requested fileid is===>" +requestFileIdId+"requestFileName is=========>"+requestFileName);
	    	   
	    		session = request.getSession(true);
	    		String userId = session.getAttribute("userid").toString();
	    		String role = session.getAttribute("user_role_id").toString();
	    		
	    		AESVendorFileRecords aesChequeDownloadObj=aesapprovaldao.downloadaesChequeWorkFlowFile(userId,requestFileIdId,requestFileName);	
		    
	          //*****create empty zip --->get payment transfer file --->get support file ---> add files to zip ---> download zip******	        
		        
		        
		       //********************creating empty zip***************************** 
		        String zipFile = "AESCheque_WorkFlow_"+requestFileIdId+"."+"zip";
		        ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(zipFile));
		        zip.putNextEntry(new ZipEntry(zipFile));
		        zip.closeEntry();
		        zip.flush();
		        zip.close();
				logger.info("successfully generated an empty zip file");
			  //*********************creating empty zip completed******************** 
	
				
			 //********************get payment transfer file************************	
				logger.info("homePath==>" +homePath);				
				
				/*if(requestFileName.endsWith(".xls")==true)
					
					requestFileName=requestFileName.replace(".xls",
							"_" +requestFileIdId + ".xls");
				
				else if(requestFileName.endsWith(".xlsx")==true)
					requestFileName=requestFileName.replace(".xlsx",
							"_" +requestFileIdId + ".xlsx");*/
				
				String filename=homePath+ File.separator+"UPLOADED_FILES"+File.separator+"AESChequeAllocation"+File.separator+"InputFiles"+File.separator+requestFileName;
				logger.info("Uploaded Filename====>"+filename);	
			 //********************get payment advice file completed*******************	
	           
				       
		    //******************get support file************************       
				String supportFileName=null;
				File supportFilesFolder = new File(homePath+File.separator+"UPLOADED_FILES"+File.separator+"AESChequeAllocation"+File.separator+"SupportFiles"+File.separator);
				File[] listOfSupportFiles = supportFilesFolder.listFiles();
				
				logger.info("supportFilesFolder=====>"+supportFilesFolder+" listOfSupportFiles==>"+listOfSupportFiles.length);
	
			for (int i = 0; i < listOfSupportFiles.length; i++) {
				if (listOfSupportFiles[i].isFile()) {
					logger.info("support file found");
					supportFileName = "AES_Cheque_WorkFlow_Support_File_"+ requestFileIdId;
					if (listOfSupportFiles[i].getName().contains(supportFileName)) {
						logger.info("contains AES Support Files in name==>" + listOfSupportFiles[i].getName());
						supportFileName = homePath+ File.separator+"UPLOADED_FILES"+File.separator+"AESChequeAllocation"+File.separator+"SupportFiles"+File.separator+listOfSupportFiles[i].getName();
						
						logger.info("support file after mentioning path is"+ supportFileName);
						break;
					} else {
						logger.info("file not found");
						supportFileName ="FILE_NOT_FOUND";
					}
				}
			}
				//**********************get support file completed******************************		
			    
				logger.info("final aes cheque workflow file name is......" +filename +"  final support file name is............."+supportFileName);
				
				//****************************adding files to zip********************************		
			List<String> srcFiles = new ArrayList<String>();
			srcFiles.add(filename);
			if (supportFileName!= null && !supportFileName.isEmpty() && !(supportFileName.equalsIgnoreCase("FILE_NOT_FOUND"))) {
				logger.info("supportFileName for adding===>"+supportFileName);
				srcFiles.add(supportFileName);
			}
			logger.info("src files size is" +srcFiles.size());
			byte[] buffer = new byte[10240];
			FileOutputStream fos = new FileOutputStream(zipFile);
			ZipOutputStream zos = new ZipOutputStream(fos);
			try {
				for (int i = 0; i < srcFiles.size(); i++) {
					File srcFile = new File(srcFiles.get(i));
					FileInputStream fis = new FileInputStream(srcFile);
					zos.putNextEntry(new ZipEntry(srcFile.getName()));
					int length;
					while ((length = fis.read(buffer)) > 0) {
						zos.write(buffer, 0, length);
					}
					zos.closeEntry();
					fis.close();
					/*if (!(srcFile.getName().contains("Payment_Transfer_Support_File_"))) {
						srcFile.delete();
					}*/
					logger.info("successfully zipped the file");
				}
				zos.close();
			} catch (IOException ioe) {
				logger.info("Error creating zip file: " + ioe);
				logger.info(ioe.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				ioe.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
	//********************************adding files to zip completed*******************************
				
	//********************************download zip************************************************			
			ServletOutputStream out = response.getOutputStream();
			FileInputStream in = new FileInputStream(zipFile);
			logger.info("zip Input File name:" + in);
			response.setContentType("APPLICATION/OCTET-STREAM");
			response.addHeader("content-disposition", "attachment; filename="+ zipFile);
			logger.info("PROCESS COMPLETED AND FETCHED THE FILE @ CONTROLLER");
			int octet = 0;
			while ((octet = in.read()) != -1)
			out.write(octet);
			in.close();
			out.flush();
			out.close();
			response.flushBuffer();
			logger.info("finished execution of payment transfer download");
	
		} catch (Exception e) {
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
	//********************************download zip completed*********************************	
	
	}
	
}

