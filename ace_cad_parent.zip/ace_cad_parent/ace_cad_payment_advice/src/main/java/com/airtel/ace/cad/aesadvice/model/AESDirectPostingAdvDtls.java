package com.airtel.ace.cad.aesadvice.model;

import java.sql.Timestamp;
import java.util.Date;

public class AESDirectPostingAdvDtls {
 String uniqueId;
 Double chequeAmount;
 String chequeNo;
 Date chequeDate;
 String depositSlipNo;
 Date depositDate;
 String accountExternalId;
 String invoiceNo;
 Double invoiceAllocationAmount;
 
 Timestamp createdDate;
 Timestamp modifiedDate;
 String trackingId;
 String trackingIdServ;
 String statusCode;
 String statusDescription;
 String noOfHit;
 String userId;
 int ticketId;
 int recordId;
 
	
public String getUniqueId() {
	return uniqueId;
}
public void setUniqueId(String uniqueId) {
	this.uniqueId = uniqueId;
}
public String getChequeNo() {
	return chequeNo;
}
public void setChequeNo(String chequeNo) {
	this.chequeNo = chequeNo;
}
public Date getChequeDate() {
	return chequeDate;
}
public void setChequeDate(Date chequeDate) {
	this.chequeDate = chequeDate;
}
public String getDepositSlipNo() {
	return depositSlipNo;
}
public void setDepositSlipNo(String depositSlipNo) {
	this.depositSlipNo = depositSlipNo;
}
public Date getDepositDate() {
	return depositDate;
}
public void setDepositDate(Date depositDate) {
	this.depositDate = depositDate;
}
public String getAccountExternalId() {
	return accountExternalId;
}
public void setAccountExternalId(String accountExternalId) {
	this.accountExternalId = accountExternalId;
}
public String getInvoiceNo() {
	return invoiceNo;
}
public void setInvoiceNo(String invoiceNo) {
	this.invoiceNo = invoiceNo;
}
public Double getInvoiceAllocationAmount() {
	return invoiceAllocationAmount;
}
public void setInvoiceAllocationAmount(Double invoiceAllocationAmount) {
	this.invoiceAllocationAmount = invoiceAllocationAmount;
}
public Timestamp getCreatedDate() {
	return createdDate;
}
public void setCreatedDate(Timestamp createdDate) {
	this.createdDate = createdDate;
}
public Timestamp getModifiedDate() {
	return modifiedDate;
}
public void setModifiedDate(Timestamp modifiedDate) {
	this.modifiedDate = modifiedDate;
}
public String getTrackingId() {
	return trackingId;
}
public void setTrackingId(String trackingId) {
	this.trackingId = trackingId;
}
public String getTrackingIdServ() {
	return trackingIdServ;
}
public void setTrackingIdServ(String trackingIdServ) {
	this.trackingIdServ = trackingIdServ;
}
public String getStatusCode() {
	return statusCode;
}
public void setStatusCode(String statusCode) {
	this.statusCode = statusCode;
}
public String getStatusDescription() {
	return statusDescription;
}
public void setStatusDescription(String statusDescription) {
	this.statusDescription = statusDescription;
}
public String getNoOfHit() {
	return noOfHit;
}
public void setNoOfHit(String noOfHit) {
	this.noOfHit = noOfHit;
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public int getTicketId() {
	return ticketId;
}
public void setTicketId(int ticketId) {
	this.ticketId = ticketId;
}
public int getRecordId() {
	return recordId;
}
public void setRecordId(int recordId) {
	this.recordId = recordId;
}
public Double getChequeAmount() {
	return chequeAmount;
}
public void setChequeAmount(Double chequeAmount) {
	this.chequeAmount = chequeAmount;
}
 
}
