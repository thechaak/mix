package com.airtel.ace.cad.paymentadvice.dao;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.airtel.ace.cad.aesadvice.model.AESAdviceLock;
import com.airtel.ace.cad.aesadvice.model.AESAdviceRequest;
import com.airtel.ace.cad.aesadvice.model.AESAdviceUploadFields;
import com.airtel.ace.cad.aesadvice.model.AESDetails;
import com.airtel.ace.cad.aesadvice.model.AESVendorFileRecords;
import com.airtel.ace.cad.paymentadvice.model.Transaction;
import com.airtel.ace.cad.paymentadvice.model.UserDetails;

import oracle.jdbc.OracleTypes;

public class AesAdviceDaoImpl implements AesAdviceDao {
	private static Logger logger =LogManager.getLogger("aesChequeUploadLogger");
	
	@Autowired
	DataSource dataSource;
	
	
	public AesAdviceDaoImpl(DataSource dataSource) {
		
		this.dataSource = dataSource;
	}


	public AESDetails getPaymentDetails(AESDetails paymentDetails) {
		
		logger.info(" Got a call to this method to retreive payment details ");
		logger.info(" Starting execution of getAESDetails() method");
		
		logger.info("Ref number from ----------"+paymentDetails.getChequeNo());
		List<AESDetails> paymentDetailsList=new ArrayList<AESDetails>();
		final String procedureCall = "{call ACE_CAD_AES_ADVICE.getAESChequeDetails(?,?,?,?,?)}";
		
		Connection connection = null;
		ResultSet paymentDetailsResultSet = null;
		CallableStatement callableStatement=null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			
			callableStatement.setString(1,paymentDetails.getChequeNo());
			callableStatement.setString(2,paymentDetails.getDepositSlipNo());
			
			callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(4, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(5, OracleTypes.VARCHAR);
			callableStatement.execute();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			
			paymentDetailsResultSet = (ResultSet) callableStatement.getObject(3);
			
			String errorCode=callableStatement.getString(4);
			String errorMessage=callableStatement.getString(5);
			
			paymentDetails.setErrorCode(errorCode);
			paymentDetails.setErrorMessage(errorMessage);
			while (paymentDetailsResultSet!=null&&paymentDetailsResultSet.next()){
				AESDetails paymentDetailsObj=new AESDetails();
				paymentDetailsObj.setFoundIn(paymentDetailsResultSet.getString("FOUND_IN"));
				paymentDetailsObj.setAccount_type(paymentDetailsResultSet.getString("ACCOUNT_TYPE"));
				paymentDetailsObj.setAccountNumber(paymentDetailsResultSet.getString("FX_ACCOUNT_NO"));
				paymentDetailsObj.setAcctExtId(paymentDetailsResultSet.getString("ACCT_EXT_ID"));
				paymentDetailsObj.setAmount(paymentDetailsResultSet.getString("PAYMENT_AMOUNT"));
				paymentDetailsObj.setAnnotation(paymentDetailsResultSet.getString("ANNOTATION"));
				paymentDetailsObj.setChequeNo(paymentDetailsResultSet.getString("REF_NUMBER"));
				paymentDetailsObj.setCurrencyCode(paymentDetailsResultSet.getString("CURRENCY_CODE"));
				paymentDetailsObj.setDepositSlipNo(paymentDetailsResultSet.getString("DEPOSIT_SLIP_NO"));
				
				if(paymentDetailsResultSet.getString("INVOICE_NO")!=null)
				paymentDetailsObj.setInvoice_no(paymentDetailsResultSet.getString("INVOICE_NO"));
				else
				paymentDetailsObj.setInvoice_no("");
				
				paymentDetailsObj.setPayment_advice_request_id(paymentDetailsResultSet.getString("PAYMENT_ADVICE_REQUEST_ID"));
				paymentDetailsObj.setTrackingId(paymentDetailsResultSet.getString("TRACKING_ID"));
				paymentDetailsObj.setTrackingIdServ(paymentDetailsResultSet.getString("TRACKING_ID_SERV"));
				paymentDetailsObj.setRecordSource(paymentDetailsResultSet.getString("RECORD_SOURCE"));
				
				if(paymentDetailsResultSet.getString("REV_TRACKING_ID")!=null)
				paymentDetailsObj.setRevTrackingId(paymentDetailsResultSet.getString("REV_TRACKING_ID"));
				else
				paymentDetailsObj.setRevTrackingId("");
				
				if(paymentDetailsResultSet.getString("REV_TRACKING_ID_SERV")!=null)
				paymentDetailsObj.setRevTrackingIdServ(paymentDetailsResultSet.getString("REV_TRACKING_ID_SERV"));
				else
				paymentDetailsObj.setRevTrackingIdServ("");
				
				paymentDetailsObj.setTransactionId(paymentDetailsResultSet.getString("TRANSACTION_ID"));
				if(paymentDetailsResultSet.getString("CUSTOMER_NAME")!=null)
				paymentDetailsObj.setCustomerName(paymentDetailsResultSet.getString("CUSTOMER_NAME"));
				else
				paymentDetailsObj.setCustomerName("");
				
				if(paymentDetailsResultSet.getString("REMITTER_NAME")!=null)
				paymentDetailsObj.setRemitterName(paymentDetailsResultSet.getString("REMITTER_NAME"));
				else
				paymentDetailsObj.setRemitterName("");
				
				if(paymentDetailsResultSet.getString("RECEIVER_NAME")!=null)
				paymentDetailsObj.setReceiverName(paymentDetailsResultSet.getString("RECEIVER_NAME"));
				else
				paymentDetailsObj.setReceiverName("");
				
				paymentDetailsObj.setLob(paymentDetailsResultSet.getString("LOB"));
				paymentDetailsObj.setPayment_fx_posting_status(paymentDetailsResultSet.getString("PAYMENT_FX_POSTING_STATUS"));
				paymentDetailsObj.setLegalEntity(paymentDetailsResultSet.getString("LEGAL_ENTITY"));
				paymentDetailsObj.setUnAllocateAmmount(paymentDetailsResultSet.getString("UNALLOCATED_AMOUNT"));
				
				
				paymentDetailsList.add(paymentDetailsObj);	
				
				}				
				
		} catch (SQLException e) {
			logger.info(e.getLocalizedMessage());
			paymentDetails.setErrorCode("FAILURE");
			if(e.getLocalizedMessage()!=null){
				//paymentDetails.setErrorMessage("Not able to retreive payment details, failure reason is : "+e.getLocalizedMessage());
				logger.info("failure reson is" +e.getLocalizedMessage());
				paymentDetails.setErrorMessage("Not able to retreive payment details");

			}
			else{
				paymentDetails.setErrorMessage("Not able to retreive payment details ");
			}
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentDetailsResultSet!=null){
				try {
					paymentDetailsResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		paymentDetails.setPaymentDetails(paymentDetailsList);
		logger.info(" Execution of getPaymentDetails() method has been completed");
		return paymentDetails;
	}


	/*public AESDetails getAESAdviceAllowedForUser(
			AESDetails paymentDetails) {
		logger.info(" Got a call to this method to retreive payment advice types allowed for the user "+paymentDetails.getUserId());
		logger.info(" Starting execution of getAESAdviceAllowedForUser() method");
		List<AESAdviceLov> paymentAdviceTypesList=new ArrayList<AESAdviceLov>();
		final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.getPaymentAdviceAllowedForUser(?,?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceTypesResultSet = null;
		CallableStatement callableStatement=null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setString(1,paymentDetails.getUserId());
			callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(4, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			paymentAdivceTypesResultSet = (ResultSet) callableStatement.getObject(2);
			String errorCode=callableStatement.getString(3);
			String errorMessage=callableStatement.getString(4);
			paymentDetails.setErrorCode(errorCode);
			paymentDetails.setErrorMessage(errorMessage);
			logger.info("result set size");
			while (paymentAdivceTypesResultSet!=null&&paymentAdivceTypesResultSet.next()){
				AESAdviceLov paymentAdviceLovObj=new AESAdviceLov();
				paymentAdviceLovObj.setPaymentAdviceType(paymentAdivceTypesResultSet.getString("TRANSFER_TYPE"));
				paymentAdviceTypesList.add(paymentAdviceLovObj);
			}
			logger.info("payment lov size in impl" +paymentAdviceTypesList.size());
		} catch (SQLException e) {
			logger.info(e.getLocalizedMessage());
			paymentDetails.setErrorCode("FAILURE");
			if(e.getLocalizedMessage()!=null){
				//paymentDetails.setErrorMessage("Not able to retreive payment advice types , failure reason is : "+e.getLocalizedMessage());
				paymentDetails.setErrorMessage("Not able to retreive payment advice types");

			}
			else{
				paymentDetails.setErrorMessage("Not able to retreive payment advice types ");
			}
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceTypesResultSet!=null){
				try {
					paymentAdivceTypesResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		paymentDetails.setPaymentAdviceLovList(paymentAdviceTypesList);
		logger.info(" Execution of getPaymentAdviceAllowedForUser() method has been completed");
		return paymentDetails;
	}
	
*/	
	

	public AESAdviceLock checkLockOnAESDetails(
			AESAdviceLock paymentAdviceLockObj) {
		logger.info(" Starting execution of checkLockOnAESDetails() method");
		final String procedureCall = "{call ACE_CAD_AES_ADVICE.checkLockOnAESDetails(?,?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceTypesResultSet = null;
		CallableStatement callableStatement=null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setString(1,paymentAdviceLockObj.getReferenceNum());
			callableStatement.setString(2, paymentAdviceLockObj.getLockAcuiredBy());
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(4, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			//String lockStatus=callableStatement.getString(2);
			String errorCode=callableStatement.getString(3);
			String errorMessage=callableStatement.getString(4);
			//paymentAdviceLockObj.setLockStatus(lockStatus);
			paymentAdviceLockObj.setErrorCode(errorCode);
			paymentAdviceLockObj.setErrorMessage(errorMessage);
		} catch (SQLException e) {
			logger.info(e.getLocalizedMessage());
			paymentAdviceLockObj.setErrorCode("FAILURE");
			if(e.getLocalizedMessage()!=null){
				//paymentAdviceLockObj.setErrorMessage("Not able to get lock status, failure reason is : "+e.getLocalizedMessage());
				logger.info("failure reason is" +e.getLocalizedMessage());
				  paymentAdviceLockObj.setErrorMessage("Not able to get lock status, failure reason is : Database issues");

				
			}
			else{
				paymentAdviceLockObj.setErrorMessage("Not able to get lock status");
			}
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceTypesResultSet!=null){
				try {
					paymentAdivceTypesResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of checkLockOnAESDetails() method has been completed");
		return paymentAdviceLockObj;
	}

	public AESAdviceLock acquireLockOnAESDetails(
			AESAdviceLock paymentAdviceLockObj) {
		logger.info(" Starting execution of acquireLockOnAESDetails() method");
		final String procedureCall = "{call ACE_CAD_AES_ADVICE.acquireLockOnAESDetails(?,?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceTypesResultSet = null;
		CallableStatement callableStatement=null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setString(1,paymentAdviceLockObj.getReferenceNum());
			callableStatement.setString(2, paymentAdviceLockObj.getLockAcuiredBy());
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(4, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			String errorCode=callableStatement.getString(3);
			String errorMessage=callableStatement.getString(4);
			paymentAdviceLockObj.setErrorCode(errorCode);
			paymentAdviceLockObj.setErrorMessage(errorMessage);
		} catch (SQLException e) {
			logger.info(e.getLocalizedMessage());
			//e.printStackTrace();
			paymentAdviceLockObj.setErrorCode("FAILURE");
			if(e.getLocalizedMessage()!=null){
				//paymentAdviceLockObj.setErrorMessage("Not able to acquire lock on reference number "+paymentAdviceLockObj.getReferenceNum()+", failure reason is : "+e.getLocalizedMessage());
				logger.info("failure reason is" +e.getLocalizedMessage());
				  paymentAdviceLockObj.setErrorMessage("Not able to acquire lock on reference number "+paymentAdviceLockObj.getReferenceNum()+", failure reason is : Database Issues");

			}
			else{
				paymentAdviceLockObj.setErrorMessage("Not able to acquire lock on reference number "+paymentAdviceLockObj.getReferenceNum());
			}
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceTypesResultSet!=null){
				try {
					paymentAdivceTypesResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of acquireLockOnAESDetails() method has been completed");
		return paymentAdviceLockObj;
	}
	
	
	public AESAdviceLock releaseLockOnAESDetails(
			AESAdviceLock paymentAdviceLockObj) {
		logger.info(" Starting execution of releaseLockOnAESDetails() method");
		final String procedureCall = "{call ACE_CAD_AES_ADVICE.releaseAESAllLocks(?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceTypesResultSet = null;
		CallableStatement callableStatement=null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			
			callableStatement.setString(1, paymentAdviceLockObj.getLockAcuiredBy());
			callableStatement.registerOutParameter(2, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			String errorCode=callableStatement.getString(2);
			String errorMessage=callableStatement.getString(3);
			paymentAdviceLockObj.setErrorCode(errorCode);
			paymentAdviceLockObj.setErrorMessage(errorMessage);
		} catch (SQLException e) {
			logger.info(e.getLocalizedMessage());
			//e.printStackTrace();
			paymentAdviceLockObj.setErrorCode("FAILURE");
			if(e.getLocalizedMessage()!=null){
				//paymentAdviceLockObj.setErrorMessage("Not able to release lock on reference number "+paymentAdviceLockObj.getReferenceNum()+", failure reason is : "+e.getLocalizedMessage());
				logger.info("failure reason is" +e.getLocalizedMessage());
				  paymentAdviceLockObj.setErrorMessage("Not able to release lock on reference number "+paymentAdviceLockObj.getReferenceNum()+", failure reason is : Database Issues");

			}
			else{
				paymentAdviceLockObj.setErrorMessage("Not able to release lock on reference number "+paymentAdviceLockObj.getReferenceNum());
			}
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceTypesResultSet!=null){
				try {
					paymentAdivceTypesResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of releaseLockOnAESDetails() method has been completed");
		return paymentAdviceLockObj;
	}
	

	public void releaseAllLocks(
			String userId) {
		logger.info(" Starting execution of releaseAllLocks() method");
		final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.releaseAllLocks(?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceTypesResultSet = null;
		CallableStatement callableStatement=null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setString(1,userId);
			callableStatement.registerOutParameter(2, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			String errorCode=callableStatement.getString(2);
			String errorMessage=callableStatement.getString(3);
			logger.info(" Procedure returned error code "+errorCode+", error message "+errorMessage);
		} catch (SQLException e) {
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceTypesResultSet!=null){
				try {
					paymentAdivceTypesResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of releaseLockOnAESDetails() method has been completed");
	}


	public AESAdviceUploadFields getAESAdviceUploadFields() {
		logger.info(" Starting execution of getAESAdviceUploadFields() method");
		final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.getPaymentAdviceUploadFields(?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceFieldsResultSet = null;
		CallableStatement callableStatement=null;
		AESAdviceUploadFields paymentAdviceUploadFiledsObj=new AESAdviceUploadFields();
		HashMap<Integer,String> paymentAdviceFieldsMap=new HashMap<Integer,String>();
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.registerOutParameter(1, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(2, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			paymentAdivceFieldsResultSet = (ResultSet) callableStatement.getObject(1);
			String errorCode=callableStatement.getString(2);
			String errorMessage=callableStatement.getString(3);
			paymentAdviceUploadFiledsObj.setErrorCode(errorCode);
			paymentAdviceUploadFiledsObj.setErrorMessage(errorMessage);
			logger.info(" Procedure returned error code "+errorCode+", error message "+errorMessage);
			while (paymentAdivceFieldsResultSet!=null&&paymentAdivceFieldsResultSet.next()){
				paymentAdviceFieldsMap.put(paymentAdivceFieldsResultSet.getInt("FIELD_POSITION"),paymentAdivceFieldsResultSet.getString("FIELD_NAME"));
			}
			paymentAdviceUploadFiledsObj.setFieldMap(paymentAdviceFieldsMap);
		} catch (SQLException e) {
			paymentAdviceUploadFiledsObj.setErrorCode("FAILURE");
			paymentAdviceUploadFiledsObj.setErrorMessage("Unable to retreive payment advice fields");
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceFieldsResultSet!=null){
				try {
					paymentAdivceFieldsResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of getAESAdviceUploadFields() method has been completed");
		return paymentAdviceUploadFiledsObj;
	}
	

	public AESAdviceUploadFields getPaymentAdviceUploadMandateFields(String paymentAdviceProcess){
		logger.info(" Starting execution of getAESAdviceUploadMandateFields() method");
		final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.getPaymentAdviceMandateFields(?,?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceFieldsResultSet = null;
		CallableStatement callableStatement=null;
		AESAdviceUploadFields paymentAdviceUploadFiledsObj=new AESAdviceUploadFields();
		HashMap<Integer,String> paymentAdviceFieldsMap=new HashMap<Integer,String>();
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setString(1,paymentAdviceProcess);
			callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(4, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			paymentAdivceFieldsResultSet = (ResultSet) callableStatement.getObject(2);
			String errorCode=callableStatement.getString(3);
			String errorMessage=callableStatement.getString(4);
			paymentAdviceUploadFiledsObj.setErrorCode(errorCode);
			paymentAdviceUploadFiledsObj.setErrorMessage(errorMessage);
			logger.info(" Procedure returned error code "+errorCode+", error message "+errorMessage);
			while (paymentAdivceFieldsResultSet!=null&&paymentAdivceFieldsResultSet.next()){
				paymentAdviceFieldsMap.put(paymentAdivceFieldsResultSet.getInt("FIELD_POSITION"),paymentAdivceFieldsResultSet.getString("FIELD_NAME"));
			}
			paymentAdviceUploadFiledsObj.setFieldMap(paymentAdviceFieldsMap);
		} catch (SQLException e) {
			paymentAdviceUploadFiledsObj.setErrorCode("FAILURE");
			paymentAdviceUploadFiledsObj.setErrorMessage("Unable to retreive payment advice mandate fields");
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceFieldsResultSet!=null){
				try {
					paymentAdivceFieldsResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of getAESAdviceUploadMandateFields() method has been completed");
		return paymentAdviceUploadFiledsObj;	
	}


	public AESAdviceRequest getAESAdviceRequestId() {
		logger.info(" Starting execution of getAESAdviceRequestId() method");
		final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.getAESAdviceRequestId(?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceFieldsResultSet = null;
		CallableStatement callableStatement=null;
		AESAdviceRequest paymentAdviceRequestObj=new AESAdviceRequest();
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.registerOutParameter(1, OracleTypes.NUMBER);
			callableStatement.registerOutParameter(2, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			int requestId=callableStatement.getInt(1);
			String errorCode=callableStatement.getString(2);
			String errorMessage=callableStatement.getString(3);
			paymentAdviceRequestObj.setRequestId(requestId);
			paymentAdviceRequestObj.setErrorCode(errorCode);
			paymentAdviceRequestObj.setErrorMessage(errorMessage);
			logger.info(" Procedure returned error code "+errorCode+", error message "+errorMessage);
		} catch (SQLException e) {
			paymentAdviceRequestObj.setErrorCode("FAILURE");
			paymentAdviceRequestObj.setErrorMessage("Unable to retreive payment advice request id");
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceFieldsResultSet!=null){
				try {
					paymentAdivceFieldsResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of getAESAdviceRequestId() method has been completed");
		return paymentAdviceRequestObj;
	}

	
	public Transaction getDataBaseConnection() {
		logger.info(" Execution of getDataBaseConnection() method started");
		Transaction transactionObj=new Transaction();
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			Connection connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			transactionObj.setDataBaseConnection(connection);
			transactionObj.setErrorCode("SUCCESS");
			transactionObj.setErrorMessage(" Database connection has been established successfully ");
		} catch (SQLException e) {
			transactionObj.setErrorCode("FAILURE");
			//transactionObj.setErrorMessage(" Unable to establish database connection, reason for the failure is "+e.getLocalizedMessage());
			transactionObj.setErrorMessage(" Unable to establish database connection");
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		
		logger.info(" Execution of getDataBaseConnection() method has been completed");
		return transactionObj;
	}


	public Transaction closeDataBaseConnection(Transaction transactionObj) {
		logger.info(" Execution of closeDataBaseConnection() method started");
		try {
			if(transactionObj.getDataBaseConnection()!=null){
				transactionObj.getDataBaseConnection().close();
				logger.info(" Database connection has been closed successfully !! ");
				transactionObj.setErrorCode("SUCCESS");
				transactionObj.setErrorMessage(" Database connection has been closed successfully ");
			}
			
		} catch (SQLException e) {
			transactionObj.setErrorCode("FAILURE");
			//transactionObj.setErrorMessage(" Unable to close database connection, reason for the failure is "+e.getLocalizedMessage());
			transactionObj.setErrorMessage(" Unable to close database connection");
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		
		logger.info(" Execution of closeDataBaseConnection() method has been completed");
		return transactionObj;
	}
	
	
	public Transaction loadAESAdviceRequest(Transaction transactionObj,AESAdviceRequest paymentAdviceRequestObj) {
		logger.info(" Starting execution of loadPaymentAdviceRequest() method");
		final String procedureCall = "{call AIRTL_AES_PAYMENT_DETAILS_PKG.updateRequestDetails(?,?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceFieldsResultSet = null;
		CallableStatement callableStatement=null;
		try {
			connection = transactionObj.getDataBaseConnection();
			connection.setAutoCommit(false);
			transactionObj.setDataBaseConnection(connection);
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setInt(1,paymentAdviceRequestObj.getRequestId());
			callableStatement.setString(2,paymentAdviceRequestObj.getOriginalSupportedFileName());

			//callableStatement.setString(3,paymentAdviceRequestObj.getPaymentMode());
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(4, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			String errorCode=callableStatement.getString(3);
			String errorMessage=callableStatement.getString(4);
			transactionObj.setErrorCode(errorCode);
			transactionObj.setErrorMessage(errorMessage);
			logger.info(" Procedure returned error code in loadAESAdviceRequest==>"+errorCode+", error message "+errorMessage);
		} catch (SQLException e) {
			transactionObj.setErrorCode("FAILURE");
			//transactionObj.setErrorMessage("Unable to save payment advice request information to the database, reason for the failure is "+e.getLocalizedMessage());
			transactionObj.setErrorMessage("Unable to save payment advice request information to the database");
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceFieldsResultSet!=null){
				try {
					paymentAdivceFieldsResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of loadPaymentAdviceRequest() method has been completed");
		return transactionObj;
	}
	
	
	/*public Transaction loadAESAdviceRequestData(Transaction transactionObj,AESAdviceUploadFields paymentAdviceData) {
		logger.info(" Starting execution of loadAESAdviceRequestData() method");
		final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.loadPaymentAdviceRequestData(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceFieldsResultSet = null;
		CallableStatement callableStatement=null;
		try {
			connection = transactionObj.getDataBaseConnection();
			transactionObj.setDataBaseConnection(connection);
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setInt(1,paymentAdviceData.getRequestId());
			callableStatement.setString(2,paymentAdviceData.getTrackingId());
			callableStatement.setString(3,paymentAdviceData.getRefNumber());
			callableStatement.setString(4,paymentAdviceData.getTargetFxAccountNumber());
			callableStatement.setString(5,paymentAdviceData.getInvoiceNumber());
			callableStatement.setDouble(6,paymentAdviceData.getInvoiceAllocationAmount());
			callableStatement.setDouble(7,paymentAdviceData.getPaymentExchangeRate());
			if(paymentAdviceData.getTdsAmount()!=null)
				callableStatement.setDouble(8,paymentAdviceData.getTdsAmount());
			else
				callableStatement.setFloat(8,0);
			callableStatement.setDouble(9,paymentAdviceData.getAmountInINR());
			callableStatement.setString(10,paymentAdviceData.getTranNo());
			callableStatement.setString(11,paymentAdviceData.getPaymentMode());
			callableStatement.setString(12,paymentAdviceData.getRemarks());
			callableStatement.setString(13,paymentAdviceData.getUploadedBy());
			callableStatement.setString(14,paymentAdviceData.getBankAccountNumber());	
			callableStatement.registerOutParameter(15, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(16, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			String errorCode=callableStatement.getString(15);
			String errorMessage=callableStatement.getString(16);
			transactionObj.setErrorCode(errorCode);
			transactionObj.setErrorMessage(errorMessage);
			logger.info(" Procedure returned error code "+errorCode+", error message "+errorMessage);
		} catch (SQLException e) {
			transactionObj.setErrorCode("FAILURE");
			//transactionObj.setErrorMessage("Unable to save payment advice request data to the database, reason for the failure is "+e.getLocalizedMessage());
			transactionObj.setErrorMessage("Unable to save payment advice request data to the database");
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceFieldsResultSet!=null){
				try {
					paymentAdivceFieldsResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of loadAESAdviceRequestData() method has been completed");
		return transactionObj;
	}*/

	
	public UserDetails getEmailAddress(UserDetails userDetailsObj) {
		logger.info(" Starting execution of getEmailAddress() method");
		final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.getUserEmailAddress(?,?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceFieldsResultSet = null;
		CallableStatement callableStatement=null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setString(1,userDetailsObj.getUserId());
			callableStatement.registerOutParameter(2, OracleTypes.VARCHAR); 
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(4, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			String emailId=callableStatement.getString(2);
			String errorCode=callableStatement.getString(3);
			String errorMessage=callableStatement.getString(4);
			userDetailsObj.setEmailAddress(emailId);
			userDetailsObj.setErrorCode(errorCode);
			userDetailsObj.setErrorMessage(errorMessage);
			logger.info("Email id is" +userDetailsObj.getEmailAddress());
			logger.info(" Procedure returned error code "+errorCode+", error message "+errorMessage);
		} catch (SQLException e) {
			userDetailsObj.setErrorCode("FAILURE");
			//userDetailsObj.setErrorMessage("Unable to retreive email address, reason for the failure is "+e.getLocalizedMessage());
			userDetailsObj.setErrorMessage("Unable to retreive email address");

			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceFieldsResultSet!=null){
				try {
					paymentAdivceFieldsResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of getEmailAddress() method has been completed");
		return userDetailsObj;
	}


	public AESAdviceUploadFields getAESAdviceUploadMandateFields(String paymentAdviceProcess) {
		// TODO Auto-generated method stub
		return null;
	}
	
	//public void updateSupportFileDetails(String supportFile,String fileId, String fileIdentifier,String statusDescription,int statusCode) {
	public void updateSupportFileDetails(String supportFile,String fileId,String statusDescription,int statusCode) {

		logger.info("Updating Support File Details");
		PreparedStatement ps =null;
		ResultSet fileNameResultSet=null;
		Connection conn=null;
		final String procedureCall;

		try 
		{
			logger.info("updateSupportDetails-> supportFile->"+supportFile+" fileId->"+fileId);

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
            
			/*if(statusDescription ==null){*/
			if(statusCode==1){
				//procedureCall = "update ADVICE_REQUEST_STATUS_APS set SUPPORT_FILE_NAME=?,STATUS_CODE = case when file_identifier='AESDUMMY' THEN 5 ELSE 2 END where I_REQUEST_ID=?";
				procedureCall = "update ADVICE_REQUEST_STATUS_APS set SUPPORT_FILE_NAME=? where I_REQUEST_ID=?";
			
			
			ps = conn.prepareCall(procedureCall);
			ps.setString(1, supportFile);
			ps.setString(2, fileId);

			ps.executeUpdate();
			}

		}catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally{
			if(fileNameResultSet!=null){
				try {
					fileNameResultSet.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}


			if(conn!=null){
				try {
					conn.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}

			}
		}
		
	}
public AESVendorFileRecords getAesBankStatementDetails(AESVendorFileRecords aesVendorFileRecordsDTO) throws Exception{		
		Connection conn = null;
		String procedureCall =null;
		int totalRecords=0;
		int totalPages =0,recordsPerPage=10;
		String errorcode = null;
		String errorMsg=null;
		CallableStatement callableStatement=null;
		ResultSet aesBankStatementDetails =null;
		List<AESVendorFileRecords> AESVendorFileRecordsList = new ArrayList<AESVendorFileRecords>();
	
		try{
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			logger.info("connection===========>" + dataSource.getConnection());
			conn = jdbcTemplate.getDataSource().getConnection();
			procedureCall = "{call AIRTL_AES_PAYMENT_DETAILS_PKG.AES_CHEQUE_BANK_STATEMENT_DTLS(?,?,?,?,?,?,?,?,?,?)}";

			callableStatement = conn.prepareCall(procedureCall);
			logger.info("aesVendorFileRecordsDTO.getCurrentPage()::"+aesVendorFileRecordsDTO.getCurrentPage() +
					" aesVendorFileRecordsDTO.getSearchUserId()::"+aesVendorFileRecordsDTO.getSearchUserId()+
					" aesVendorFileRecordsDTO.getSearchFileId():"+aesVendorFileRecordsDTO.getSearchFileId()+
					" aesVendorFileRecordsDTO.getSearchFromDate()::"+aesVendorFileRecordsDTO.getSearchFromDate()+
					" aesVendorFileRecordsDTO.getSearchEndDate()::"+aesVendorFileRecordsDTO.getSearchEndDate());
			
			callableStatement.setInt(1, aesVendorFileRecordsDTO.getCurrentPage());
			callableStatement.setString(2, aesVendorFileRecordsDTO.getSearchUserId());
			callableStatement.setString(3, aesVendorFileRecordsDTO.getSearchFileId());
			callableStatement.setString(4, aesVendorFileRecordsDTO.getSearchFromDate());
			callableStatement.setString(5, aesVendorFileRecordsDTO.getSearchEndDate());			
			
			callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(7, Types.INTEGER);
			callableStatement.registerOutParameter(8, Types.CHAR);
			callableStatement.registerOutParameter(9, Types.CHAR);
			callableStatement.registerOutParameter(10, Types.INTEGER);			
			
			callableStatement.executeUpdate();
			
			totalPages = callableStatement.getInt(7);
			errorcode= callableStatement.getString(8);
			errorMsg= callableStatement.getString(9);
			totalRecords= callableStatement.getInt(10);
			logger.info("totalPages====>"+totalPages+"   errorcode====>"+errorcode+"  errorMsg===>"+errorMsg+"  totalRecords==>"+totalRecords);
		
			aesVendorFileRecordsDTO.setErrorMsg(errorMsg);
			
			aesBankStatementDetails= (ResultSet) callableStatement.getObject(6);
			
			if(aesBankStatementDetails ==null){
				logger.info("result set details are null ..DB is returning null values!!!");
			}else{
				
				 while (aesBankStatementDetails.next()) 
				   {
					 AESVendorFileRecords aesVendorFileRecords1 = new AESVendorFileRecords();
					 aesVendorFileRecords1.setFile_id(aesBankStatementDetails.getString("FILE_ID"));
					 aesVendorFileRecords1.setFile_name(aesBankStatementDetails.getString("ORIGINAL_FILE_NAME"));					 
					 aesVendorFileRecords1.setTransaction_id(aesBankStatementDetails.getString("TRANSACTION_ID"));					 
					 aesVendorFileRecords1.setAccountNo(aesBankStatementDetails.getString("ACCT_EXT_ID"));
					 aesVendorFileRecords1.setChequeNo(aesBankStatementDetails.getString("CHEQUE_NO"));
					 aesVendorFileRecords1.setDepositSlipNo(aesBankStatementDetails.getString("DEPOSIT_SLIP_NO"));
					 aesVendorFileRecords1.setAmount(aesBankStatementDetails.getDouble("AMOUNT"));
					 aesVendorFileRecords1.setFile_upload_date(aesBankStatementDetails.getString("UPLOADED_DATE"));
					 aesVendorFileRecords1.setUploadedUserName(aesBankStatementDetails.getString("REQUEST_RAISED_BY"));
					 aesVendorFileRecords1.setBankName(aesBankStatementDetails.getString("BANK_NAME"));
					 aesVendorFileRecords1.setRemitterName(aesBankStatementDetails.getString("REMITTER_NAME"));
					 aesVendorFileRecords1.setDerived_lob(aesBankStatementDetails.getString("DERIVED_LOB"));
					 aesVendorFileRecords1.setReceiverName(aesBankStatementDetails.getString("RECEIVER_NAME"));
					 aesVendorFileRecords1.setAnnotation(aesBankStatementDetails.getString("ANNOTATION"));
					 aesVendorFileRecords1.setPostingStatusDesc(aesBankStatementDetails.getString("STATUS_DESCRIPTION"));
					 aesVendorFileRecords1.setPostingTrackingId(aesBankStatementDetails.getString("TRACKING_ID"));
					 aesVendorFileRecords1.setPostingTrackingIdServ(aesBankStatementDetails.getString("TRACKING_ID_SERV"));
					 aesVendorFileRecords1.setReversalTrackingId(aesBankStatementDetails.getString("REV_TRACKING_ID"));
					 aesVendorFileRecords1.setReversalTrackingIdServ(aesBankStatementDetails.getString("REV_TRACKING_ID_SERV"));
					 aesVendorFileRecords1.setReversalStatusDesc(aesBankStatementDetails.getString("REVERSAL_STATUS_DESC"));
					 
					 AESVendorFileRecordsList.add(aesVendorFileRecords1);
				   }
			 }
		
		}
		catch (SQLException e) {
			throw new RuntimeException(e);
		}finally{
			if(aesBankStatementDetails!=null){
				aesBankStatementDetails.close();
			}
			if(callableStatement!=null)
				callableStatement.close();
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}
		}
		aesVendorFileRecordsDTO.setResultPerPage(AESVendorFileRecordsList.size());
		aesVendorFileRecordsDTO.setTotalResults(totalRecords);
		aesVendorFileRecordsDTO.setTotalPages(totalPages);
		aesVendorFileRecordsDTO.setAesBulkStatementDetailList(AESVendorFileRecordsList);
		
		return aesVendorFileRecordsDTO;
	}


public AESVendorFileRecords downloadsAESBankStatementReports(AESVendorFileRecords aesVendorFileRecordsDTO) throws Exception{
 
	AESVendorFileRecords aesVendorFileRecordsDTO1 = getAesBankStatementDetails(aesVendorFileRecordsDTO);
	logger.info("aesVendorFileRecordsDTO1 in downloadsAESBankStatementReports==>"+aesVendorFileRecordsDTO1.getAesBulkStatementDetailList().size());
	return aesVendorFileRecordsDTO1;
}
	

	public AESDetails getAESAdviceAllowedForUser(AESDetails paymentDetails) {
		// TODO Auto-generated method stub
		return null;
	}


	
	}

	


