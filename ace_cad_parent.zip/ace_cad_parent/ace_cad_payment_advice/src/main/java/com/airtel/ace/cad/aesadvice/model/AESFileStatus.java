package com.airtel.ace.cad.aesadvice.model;

import java.util.HashMap;
import java.util.List;

import com.airtel.acecad.bulkupload.dto.FileStatusAPS;

public class AESFileStatus {
	
	List<AESFileDetails> fileStatusList;
	List<AESVendorFileRecords> aesVendorStatusList;

	private int totalResults; 
	private int resultPerPage;
	private int totalPages;
	private int currentPage;
	
	private HashMap<String,Integer> reasons = new HashMap<String, Integer>();	
	
    
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public List<AESFileDetails> getFileStatusList() {
		return fileStatusList;
	}
	public void setFileStatusList(List<AESFileDetails> fileStatusList) {
		this.fileStatusList = fileStatusList;
	}
	public List<AESVendorFileRecords> getAesVendorStatusList() {
		return aesVendorStatusList;
	}
	public void setAesVendorStatusList(List<AESVendorFileRecords> aesVendorStatusList) {
		this.aesVendorStatusList = aesVendorStatusList;
	}
	public int getTotalResults() {
		return totalResults;
	}
	public void setTotalResults(int totalResults) {
		this.totalResults = totalResults;
	}
	public int getResultPerPage() {
		return resultPerPage;
	}
	public void setResultPerPage(int resultPerPage) {
		this.resultPerPage = resultPerPage;
	}
	public int getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	public HashMap<String, Integer> getReasons() {
		return reasons;
	}
	public void setReasons(HashMap<String, Integer> reasons) {
		this.reasons = reasons;
	}
	
	


}
