package com.airtel.ace.cad.aesadvice.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AESVendorFileRecords {
 String receiverName;
 int buCode;
 String accountNo;
 String bankCurrency;
 Date dummyDate;
 String remitterName;
 String depositSlipNo;
 String bankRefNo;
 String otherRefNo;
 Double debitAmount;
 Double creditAmount;
 String paymentMode;
 String uniCode;
 Date segregationDate;
 String childAcctExtId;
 String annotation;
 String chequeNo;
 String glCode;
 String bankName;
 int circle;
 String lob;
 Double amount;
 
 //Variable used to be displayed on screen
 int totalResults; 
 int resultPerPage;
 int totalPages;
 String errorMsg;
 int currentPage;
 String searchUserId;
 String searchFileId;
 String searchFromDate;
 String searchEndDate;
 String postingStatusDesc;
 String postingTrackingId;
 String postingTrackingIdServ;
 String reversalTrackingId;
 String reversalTrackingIdServ;
 String reversalStatusDesc;
 //Variable to be displayed on Screen
 
 String file_id;
 String transaction_id;
 String file_name;
 int total_records;
 String file_upload_date;
 String uploadedUserName;
 String derived_lob;

//Parameters for Download AES Transfer and Support File
 String downloadStatus;
 String cheque_date;
 String deposit_date;
 String invoice_no;
 String invoice_alloaction_amount;
 String bankstatement_cheque_amount;
 String uploaded_by;
 String source_lob;
 String source_circle_name;
 String destination_lob;
 String destination_circle_name;
 String target_customer_name;
 String entity_name;
 String entity_name_invoice;
 String cad_reach_time;
 

//Parameters for Download Payment Transfer and Support File Ends here
 
 List<AESVendorFileRecords> aesBulkStatementDetailList = new ArrayList<AESVendorFileRecords>();
 
 
public String getCad_reach_time() {
	return cad_reach_time;
}
public void setCad_reach_time(String cad_reach_time) {
	this.cad_reach_time = cad_reach_time;
}
public String getCheque_date() {
	return cheque_date;
}
public void setCheque_date(String cheque_date) {
	this.cheque_date = cheque_date;
}

public String getDeposit_date() {
	return deposit_date;
}
public void setDeposit_date(String deposit_date) {
	this.deposit_date = deposit_date;
}
public String getInvoice_no() {
	return invoice_no;
}
public void setInvoice_no(String invoice_no) {
	this.invoice_no = invoice_no;
}
public String getInvoice_alloaction_amount() {
	return invoice_alloaction_amount;
}
public void setInvoice_alloaction_amount(String invoice_alloaction_amount) {
	this.invoice_alloaction_amount = invoice_alloaction_amount;
}
public String getBankstatement_cheque_amount() {
	return bankstatement_cheque_amount;
}
public void setBankstatement_cheque_amount(String bankstatement_cheque_amount) {
	this.bankstatement_cheque_amount = bankstatement_cheque_amount;
}

public String getUploaded_by() {
	return uploaded_by;
}
public void setUploaded_by(String uploaded_by) {
	this.uploaded_by = uploaded_by;
}
public String getSource_lob() {
	return source_lob;
}
public void setSource_lob(String source_lob) {
	this.source_lob = source_lob;
}
public String getSource_circle_name() {
	return source_circle_name;
}
public void setSource_circle_name(String source_circle_name) {
	this.source_circle_name = source_circle_name;
}
public String getDestination_lob() {
	return destination_lob;
}
public void setDestination_lob(String destination_lob) {
	this.destination_lob = destination_lob;
}
public String getDestination_circle_name() {
	return destination_circle_name;
}
public void setDestination_circle_name(String destination_circle_name) {
	this.destination_circle_name = destination_circle_name;
}
public String getTarget_customer_name() {
	return target_customer_name;
}
public void setTarget_customer_name(String target_customer_name) {
	this.target_customer_name = target_customer_name;
}
public String getEntity_name() {
	return entity_name;
}
public void setEntity_name(String entity_name) {
	this.entity_name = entity_name;
}
public String getEntity_name_invoice() {
	return entity_name_invoice;
}
public void setEntity_name_invoice(String entity_name_invoice) {
	this.entity_name_invoice = entity_name_invoice;
}
public String getReceiverName() {
	return receiverName;
}
public void setReceiverName(String receiverName) {
	this.receiverName = receiverName;
}
public int getBuCode() {
	return buCode;
}
public void setBuCode(int buCode) {
	this.buCode = buCode;
}
public String getAccountNo() {
	return accountNo;
}
public void setAccountNo(String accountNo) {
	this.accountNo = accountNo;
}
public String getBankCurrency() {
	return bankCurrency;
}
public void setBankCurrency(String bankCurrency) {
	this.bankCurrency = bankCurrency;
}
public Date getDummyDate() {
	return dummyDate;
}
public void setDummyDate(Date dummyDate) {
	this.dummyDate = dummyDate;
}
public String getRemitterName() {
	return remitterName;
}
public void setRemitterName(String remitterName) {
	this.remitterName = remitterName;
}
public String getDepositSlipNo() {
	return depositSlipNo;
}
public void setDepositSlipNo(String depositSlipNo) {
	this.depositSlipNo = depositSlipNo;
}
public String getBankRefNo() {
	return bankRefNo;
}
public void setBankRefNo(String bankRefNo) {
	this.bankRefNo = bankRefNo;
}
public String getOtherRefNo() {
	return otherRefNo;
}
public void setOtherRefNo(String otherRefNo) {
	this.otherRefNo = otherRefNo;
}
public Double getDebitAmount() {
	return debitAmount;
}
public void setDebitAmount(Double debitAmount) {
	this.debitAmount = debitAmount;
}
public Double getCreditAmount() {
	return creditAmount;
}
public void setCreditAmount(Double creditAmount) {
	this.creditAmount = creditAmount;
}
public String getPaymentMode() {
	return paymentMode;
}
public void setPaymentMode(String paymentMode) {
	this.paymentMode = paymentMode;
}
public String getUniCode() {
	return uniCode;
}
public void setUniCode(String uniCode) {
	this.uniCode = uniCode;
}
public Date getSegregationDate() {
	return segregationDate;
}
public void setSegregationDate(Date segregationDate) {
	this.segregationDate = segregationDate;
}
public String getChildAcctExtId() {
	return childAcctExtId;
}
public void setChildAcctExtId(String childAcctExtId) {
	this.childAcctExtId = childAcctExtId;
}
public String getAnnotation() {
	return annotation;
}
public void setAnnotation(String annotation) {
	this.annotation = annotation;
}
public String getChequeNo() {
	return chequeNo;
}
public void setChequeNo(String chequeNo) {
	this.chequeNo = chequeNo;
}
public String getGlCode() {
	return glCode;
}
public void setGlCode(String glCode) {
	this.glCode = glCode;
}
public String getBankName() {
	return bankName;
}
public void setBankName(String bankName) {
	this.bankName = bankName;
}
public int getCircle() {
	return circle;
}
public void setCircle(int circle) {
	this.circle = circle;
}
public String getLob() {
	return lob;
}
public void setLob(String lob) {
	this.lob = lob;
}
public Double getAmount() {
	return amount;
}
public void setAmount(Double amount) {
	this.amount = amount;
}
public int getTotalResults() {
	return totalResults;
}
public void setTotalResults(int totalResults) {
	this.totalResults = totalResults;
}
public int getResultPerPage() {
	return resultPerPage;
}
public void setResultPerPage(int resultPerPage) {
	this.resultPerPage = resultPerPage;
}
public int getTotalPages() {
	return totalPages;
}
public void setTotalPages(int totalPages) {
	this.totalPages = totalPages;
}
public String getErrorMsg() {
	return errorMsg;
}
public void setErrorMsg(String errorMsg) {
	this.errorMsg = errorMsg;
}
public int getCurrentPage() {
	return currentPage;
}
public void setCurrentPage(int currentPage) {
	this.currentPage = currentPage;
}
public List<AESVendorFileRecords> getAesBulkStatementDetailList() {
	return aesBulkStatementDetailList;
}
public void setAesBulkStatementDetailList(List<AESVendorFileRecords> aesBulkStatementDetailList) {
	this.aesBulkStatementDetailList = aesBulkStatementDetailList;
}
public String getSearchUserId() {
	return searchUserId;
}
public void setSearchUserId(String searchUserId) {
	this.searchUserId = searchUserId;
}
public String getSearchFileId() {
	return searchFileId;
}
public void setSearchFileId(String searchFileId) {
	this.searchFileId = searchFileId;
}
public String getSearchFromDate() {
	return searchFromDate;
}
public void setSearchFromDate(String searchFromDate) {
	this.searchFromDate = searchFromDate;
}
public String getSearchEndDate() {
	return searchEndDate;
}
public void setSearchEndDate(String searchEndDate) {
	this.searchEndDate = searchEndDate;
}
public String getPostingStatusDesc() {
	return postingStatusDesc;
}
public void setPostingStatusDesc(String postingStatusDesc) {
	this.postingStatusDesc = postingStatusDesc;
}
public String getPostingTrackingId() {
	return postingTrackingId;
}
public void setPostingTrackingId(String postingTrackingId) {
	this.postingTrackingId = postingTrackingId;
}
public String getPostingTrackingIdServ() {
	return postingTrackingIdServ;
}
public void setPostingTrackingIdServ(String postingTrackingIdServ) {
	this.postingTrackingIdServ = postingTrackingIdServ;
}
public String getReversalTrackingId() {
	return reversalTrackingId;
}
public void setReversalTrackingId(String reversalTrackingId) {
	this.reversalTrackingId = reversalTrackingId;
}
public String getReversalTrackingIdServ() {
	return reversalTrackingIdServ;
}
public void setReversalTrackingIdServ(String reversalTrackingIdServ) {
	this.reversalTrackingIdServ = reversalTrackingIdServ;
}
public String getFile_id() {
	return file_id;
}
public void setFile_id(String file_id) {
	this.file_id = file_id;
}
public String getTransaction_id() {
	return transaction_id;
}
public void setTransaction_id(String transaction_id) {
	this.transaction_id = transaction_id;
}
public String getFile_name() {
	return file_name;
}
public void setFile_name(String file_name) {
	this.file_name = file_name;
}
public int getTotal_records() {
	return total_records;
}
public void setTotal_records(int total_records) {
	this.total_records = total_records;
}
public String getFile_upload_date() {
	return file_upload_date;
}
public void setFile_upload_date(String file_upload_date) {
	this.file_upload_date = file_upload_date;
}
public String getUploadedUserName() {
	return uploadedUserName;
}
public void setUploadedUserName(String uploadedUserName) {
	this.uploadedUserName = uploadedUserName;
}
public String getDerived_lob() {
	return derived_lob;
}
public void setDerived_lob(String derived_lob) {
	this.derived_lob = derived_lob;
}
public String getReversalStatusDesc() {
	return reversalStatusDesc;
}
public void setReversalStatusDesc(String reversalStatusDesc) {
	this.reversalStatusDesc = reversalStatusDesc;
}
public String getDownloadStatus() {
	return downloadStatus;
}
public void setDownloadStatus(String downloadStatus) {
	this.downloadStatus = downloadStatus;
}

}
