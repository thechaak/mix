package com.airtel.ace.cad.paymentadvice;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        String a="Msddddddddaweddda";
        String a1="123";//123,132,213,231,321,312
        permutation("",a1);
        //String a2=reverseRecursively("hiItsme");
        //reverseWholeString();
        //HashMap<Character,Integer> d=findDuplicates(a);
        //deleteDuplicates(d);
        
	
    }
    
    private static void permutation(String perm, String word) {//""+1,123
        
    	if (word.isEmpty()) {
            System.out.println(perm + word);

        } else {
            for (int i = 0;i<word.length(); i++) {
                permutation(perm + word.charAt(i), word.substring(0, i) 
                                        + word.substring(i + 1, word.length()));
            }
        }

    }
    
    
    
    public static String reverseRecursively(String str) {
    
        //base case to handle one char string and empty string
        System.out.println(str);
    	if (str.length() < 2) {
            return str;
        }
        
        return reverseRecursively(str.substring(1)) + str.charAt(0);

    }
    
    static void reverseWholeString(){
    	String a="hiItsme";
    	char[] st=a.toCharArray();
    	int n=a.length();
    	String a1="";
    	for(int i=n-1;i>=0;i--){
    		a1=a1+st[i];
    	}
    	System.out.println(a1);
    }
    static void reverseStringWords(){
    	String a="hi Its me";
        String[]st=a.split(" ");
        StringBuffer sb=new StringBuffer();
        for(int i=0;i<st.length;i++){
        	String temp=st[st.length-1];
        	st[st.length-1]=st[0];
        	st[0]=temp;
        	sb.append(st[i]+" ");
        	System.out.println(sb.toString());
        	//String cc=Arrays.toString(st);
        }
        
    }
    
    static void deleteDuplicates(HashMap<Character,Integer> d){
    	
    	Iterator<Integer> iterator = d.values().iterator();
        
        while(iterator.hasNext()){
          Integer c = iterator.next();
          if(c.intValue()>1){
            iterator.remove();
          }
        }
        
        // Map - after removing a mapping
        System.out.println("after: " + d);	
    /*for(Entry<Character,Integer> df:d.entrySet()){
	    if(df.getValue()>1)
	    d.remove(df.getKey());
	}
    for(Entry<Character,Integer> f:d.entrySet()){
    	System.out.println(f.getKey()+" "+f.getValue());
    }*/
    }
    
    static HashMap<Character,Integer> findDuplicates(String a){
    HashMap<Character,Integer> mp=new  HashMap<Character,Integer>();
	for(int i=0;i<a.length();i++){
	if(mp.containsKey(a.charAt(i))){
		mp.put(a.charAt(i),mp.get(a.charAt(i))+1);
	}else{
		mp.put(a.charAt(i),1);
		}
	}
	for(Entry<Character,Integer> f:mp.entrySet()){
    	System.out.println(f.getKey()+" "+f.getValue());
    }
	return mp;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
   

