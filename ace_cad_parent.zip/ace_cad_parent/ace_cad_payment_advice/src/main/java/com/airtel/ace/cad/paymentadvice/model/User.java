package com.airtel.ace.cad.paymentadvice.model;

import java.util.List;
   
public class User extends VendorDetails{
	private String userId;
	private String userName;
	private String userStatus;
	private String userEmailId;
	private String userActiveDate;
	private String userInActiveDate;
	private String userRole;
	private String userCircle;
	private String createdBy;
	private String errorCode;
	private String errorMessage;
	private List<String> paymentAdviceLovs;
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

	public String getUserEmailId() {
		return userEmailId;
	}

	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId;
	}

	public String getUserActiveDate() {
		return userActiveDate;
	}

	public void setUserActiveDate(String userActiveDate) {
		this.userActiveDate = userActiveDate;
	}

	public String getUserInActiveDate() {
		return userInActiveDate;
	}

	public void setUserInActiveDate(String userInActiveDate) {
		this.userInActiveDate = userInActiveDate;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getUserCircle() {
		return userCircle;
	}

	public void setUserCircle(String userCircle) {
		this.userCircle = userCircle;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public List<String> getPaymentAdviceLovs() {
		return paymentAdviceLovs;
	}

	public void setPaymentAdviceLovs(List<String> paymentAdviceLovs) {
		this.paymentAdviceLovs = paymentAdviceLovs;
	}
}
