/**
 * 
 */
package com.airtel.ace.cad.paymentadvice.dao;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.airtel.ace.cad.paymentadvice.model.PaymentAdviceLock;
import com.airtel.ace.cad.paymentadvice.model.PaymentAdviceLov;
import com.airtel.ace.cad.paymentadvice.model.PaymentAdviceRequest;
import com.airtel.ace.cad.paymentadvice.model.PaymentAdviceUploadFields;
import com.airtel.ace.cad.paymentadvice.model.PaymentDetails;
import com.airtel.ace.cad.paymentadvice.model.PaymentType;
import com.airtel.ace.cad.paymentadvice.model.Transaction;
import com.airtel.ace.cad.paymentadvice.model.UserDetails;

/**
 * @author 587111
 *
 */
public class PaymentAdviceDAOImpl implements PaymentAdviceDAO {
	
	
	private static Logger logger =LogManager.getLogger("paymentAdviceLogger");
	
	@Autowired
	DataSource dataSource;

	public PaymentAdviceDAOImpl(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public PaymentDetails getPaymentTypes(){
		logger.info(" Got a call to this method to retreive payment types allowed for payment advice ");
		logger.info(" Starting execution of getPaymentTypes() method");
		PaymentDetails paymentDetailsObj=new PaymentDetails();
		List<PaymentType> paymentTypes=new ArrayList<PaymentType>();
		final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.getPaymentTypes(?,?,?)}";
		Connection connection = null;
		ResultSet paymentTypesResultSet = null;
		CallableStatement callableStatement=null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.registerOutParameter(1, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(2, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			paymentTypesResultSet = (ResultSet) callableStatement.getObject(1);
			String errorCode=callableStatement.getString(2);
			String errorMessage=callableStatement.getString(3);
			paymentDetailsObj.setErrorCode(errorCode);
			paymentDetailsObj.setErrorMessage(errorMessage);
			while (paymentTypesResultSet!=null&&paymentTypesResultSet.next()){
				PaymentType paymentTypeObj=new PaymentType();
				paymentTypeObj.setPaymentType(paymentTypesResultSet.getString("PAYMENT_TYPE"));
				paymentTypes.add(paymentTypeObj);
			}
		} catch (SQLException e) {
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
			paymentDetailsObj.setErrorCode("FAILURE");
			if(e.getLocalizedMessage()!=null){
				//paymentDetailsObj.setErrorMessage("Not able to retreive payment types, failure reason is : "+e.getLocalizedMessage());
				  paymentDetailsObj.setErrorMessage("Not able to retreive payment types");

			}
			else{
				paymentDetailsObj.setErrorMessage("Not able to retreive payment types ");
			}
			 errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentTypesResultSet!=null){
				try {
					paymentTypesResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		paymentDetailsObj.setPaymentTypes(paymentTypes);
		logger.info(" Execution of getPaymentTypes() method has been completed");
		return paymentDetailsObj;
	}
	
	public PaymentDetails getPaymentDetails(PaymentDetails paymentDetails){
		logger.info(" Got a call to this method to retreive payment details ");
		logger.info(" Starting execution of getPaymentDetails() method");
		List<PaymentDetails> paymentDetailsList=new ArrayList<PaymentDetails>();
		final String procedureCall = "{call PAYMENT_ADVICE_PKG.getPaymentDetails(?,?,?,?,?,?)}";
		Connection connection = null;
		ResultSet paymentDetailsResultSet = null;
		CallableStatement callableStatement=null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setString(1,paymentDetails.getPaymentMode());
			callableStatement.setString(2,paymentDetails.getRefNumber());
			callableStatement.setString(3,paymentDetails.getCustomerBankAccountNum());
			callableStatement.registerOutParameter(4, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(5, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(6, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			paymentDetailsResultSet = (ResultSet) callableStatement.getObject(4);
			String errorCode=callableStatement.getString(5);
			String errorMessage=callableStatement.getString(6);
			paymentDetails.setErrorCode(errorCode);
			paymentDetails.setErrorMessage(errorMessage);
			while (paymentDetailsResultSet!=null&&paymentDetailsResultSet.next()){
				PaymentDetails paymentDetailsObj=new PaymentDetails();
				paymentDetailsObj.setTransactionId(paymentDetailsResultSet.getString("TRANSACTION_ID"));
				paymentDetailsObj.setAcctExternalId(paymentDetailsResultSet.getString("ACCT_EXT_ID"));
				
				if(paymentDetailsResultSet.getString("FX_ACCOUNT_NO")!=null){
				paymentDetailsObj.setFxAccountNum(paymentDetailsResultSet.getString("FX_ACCOUNT_NO"));
				}
				else{
					paymentDetailsObj.setFxAccountNum("");
				}
				
				if(paymentDetailsResultSet.getString("CUSTOMER_NAME")!=null){
				paymentDetailsObj.setCustomerName(paymentDetailsResultSet.getString("CUSTOMER_NAME"));
				}
				else{
					paymentDetailsObj.setCustomerName("");
				}
				

				paymentDetailsObj.setPaymentMode(paymentDetailsResultSet.getString("PAYMENT_MODE"));
				paymentDetailsObj.setPaymentAmount(paymentDetailsResultSet.getString("PAYMENT_AMOUNT"));
				paymentDetailsObj.setRefNumber(paymentDetailsResultSet.getString("REF_NUMBER"));
				paymentDetailsObj.setChequeDate(paymentDetailsResultSet.getString("CHEQUE_DATE"));
				paymentDetailsObj.setCustomerBankAccountNum(paymentDetailsResultSet.getString("CUSTOMER_BANK_ACCOUNT_NO"));
				paymentDetailsObj.setPaymentReceivedDate(paymentDetailsResultSet.getString("PAYMENT_RECEIVED_DATE"));
				paymentDetailsObj.setTrackingId(paymentDetailsResultSet.getString("TRACKING_ID"));
				if(paymentDetailsResultSet.getString("TRACKING_ID")!=null){
				paymentDetailsObj.setTrackingId(paymentDetailsResultSet.getString("TRACKING_ID"));
				}
				else{
					paymentDetailsObj.setTrackingId("");
				}

				paymentDetailsObj.setCircle(paymentDetailsResultSet.getString("CIRCLE"));
				paymentDetailsObj.setAnnotation(paymentDetailsResultSet.getString("ANNOTATION"));
				paymentDetailsObj.setCurrencyCode(paymentDetailsResultSet.getString("CURRENCY_CODE"));
				paymentDetailsObj.setFundRecievedCurrency(paymentDetailsResultSet.getString("FUND_RECEIVED_CURRENCY")); 
				paymentDetailsObj.setIncomingTransActionRefNumber(paymentDetailsResultSet.getString("INCOMING_TRANSACTION_REF_NO"));
				paymentDetailsObj.setAmountInINR(paymentDetailsResultSet.getString("AMOUNT_IN_INR"));
				if(paymentDetailsResultSet.getString("REF_NO")!=null){
					paymentDetailsObj.setRefNo(paymentDetailsResultSet.getString("REF_NO"));
				}
				else{
					paymentDetailsObj.setRefNo("");

				}
				
				if(paymentDetailsResultSet.getString("EXCHANGE_RATE")!=null){
				paymentDetailsObj.setExchangeRate(paymentDetailsResultSet.getString("EXCHANGE_RATE"));
				}
				else{
					paymentDetailsObj.setExchangeRate(""); 
				}
				paymentDetailsObj.setBankName(paymentDetailsResultSet.getString("BANK_NAME"));
				paymentDetailsObj.setLob(paymentDetailsResultSet.getString("LOB"));
				paymentDetailsObj.setFxPostingStatus(paymentDetailsResultSet.getString("PAYMENT_FX_POSTING_STATUS"));
				//paymentDetailsObj.setPaymentPostingStatusCode(paymentDetailsResultSet.getString("PAYMENT_POSTING_STATUS_CODE"));
				//paymentDetailsObj.setPaymentAdviceStatusCode(paymentDetailsResultSet.getString("PAYMENT_ADVICE_STATUS_CODE"));
				//paymentDetailsObj.setPaymentAdviceStatus(paymentDetailsResultSet.getString("PAYMENT_ADVICE_STATUS"));
				paymentDetailsObj.setLegalEntity(paymentDetailsResultSet.getString("LEGAL_ENTITY"));
				if(paymentDetailsResultSet.getString("BANK_BRANCH_NAME")!=null){
				paymentDetailsObj.setBankBranchName(paymentDetailsResultSet.getString("BANK_BRANCH_NAME"));
				}
				else{
					paymentDetailsObj.setBankBranchName("");
				}
				if(paymentDetailsResultSet.getString("REMITTER_NAME")!=null){
				paymentDetailsObj.setRemitterName(paymentDetailsResultSet.getString("REMITTER_NAME"));
				}
				else{
					paymentDetailsObj.setRemitterName("");
				}
				paymentDetailsObj.setAccountType(paymentDetailsResultSet.getString("ACCOUNT_TYPE"));
				paymentDetailsObj.setSubsidairy(paymentDetailsResultSet.getString("SUBSIDIARY")); 
				paymentDetailsObj.setRecordType(paymentDetailsResultSet.getString("RECORD_TYPE"));
				paymentDetailsObj.setReverseFlag(paymentDetailsResultSet.getInt("REVERSAL_FLAG"));
				paymentDetailsObj.setInvoiceNumber(paymentDetailsResultSet.getString("INVOICE_NO"));
				paymentDetailsObj.setRecordSource(paymentDetailsResultSet.getString("RECORD_SOURCE"));
				paymentDetailsObj.setPaymentAdviceRequestId(Integer.toString(paymentDetailsResultSet.getInt("PAYMENT_ADVICE_REQUEST_ID")));
				
				if(paymentDetailsResultSet.getString("SOURCE_CIRCLE_MKT_CODE")!=null){
					paymentDetailsObj.setMktCode(paymentDetailsResultSet.getString("SOURCE_CIRCLE_MKT_CODE"));
				}
                 
				else{
					paymentDetailsObj.setMktCode("");

				}

				if(paymentDetails.getPaymentMode()!=null&&paymentDetails.getPaymentMode().equalsIgnoreCase("NEFT")){
					paymentDetails.setPaymentFoundIn(paymentDetailsResultSet.getString("FOUND_IN"));
					if(paymentDetailsResultSet.getString("RECEIVER_NAME")!=null){
						paymentDetailsObj.setReceiverName(paymentDetailsResultSet.getString("RECEIVER_NAME"));
						}
						else{
							paymentDetailsObj.setReceiverName("");
						}
				}				
				paymentDetailsList.add(paymentDetailsObj);	
			}
		} catch (SQLException e) {
			logger.info(e.getLocalizedMessage());
			paymentDetails.setErrorCode("FAILURE");
			if(e.getLocalizedMessage()!=null){
				//paymentDetails.setErrorMessage("Not able to retreive payment details, failure reason is : "+e.getLocalizedMessage());
				logger.info("failure reson is" +e.getLocalizedMessage());
				paymentDetails.setErrorMessage("Not able to retreive payment details");

			}
			else{
				paymentDetails.setErrorMessage("Not able to retreive payment details ");
			}
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentDetailsResultSet!=null){
				try {
					paymentDetailsResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		paymentDetails.setPaymentDetails(paymentDetailsList);
		logger.info(" Execution of getPaymentDetails() method has been completed");
		return paymentDetails;
	}


	public PaymentDetails getPaymentAdviceAllowedForUser(
			PaymentDetails paymentDetails) {
		logger.info(" Got a call to this method to retreive payment advice types allowed for the user "+paymentDetails.getUserId());
		logger.info(" Starting execution of getPaymentAdviceAllowedForUser() method");
		List<PaymentAdviceLov> paymentAdviceTypesList=new ArrayList<PaymentAdviceLov>();
		final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.getPaymentAdviceAllowedForUser(?,?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceTypesResultSet = null;
		CallableStatement callableStatement=null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setString(1,paymentDetails.getUserId());
			callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(4, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			paymentAdivceTypesResultSet = (ResultSet) callableStatement.getObject(2);
			String errorCode=callableStatement.getString(3);
			String errorMessage=callableStatement.getString(4);
			paymentDetails.setErrorCode(errorCode);
			paymentDetails.setErrorMessage(errorMessage);
			logger.info("result set size");
			while (paymentAdivceTypesResultSet!=null&&paymentAdivceTypesResultSet.next()){
				PaymentAdviceLov paymentAdviceLovObj=new PaymentAdviceLov();
				paymentAdviceLovObj.setPaymentAdviceType(paymentAdivceTypesResultSet.getString("TRANSFER_TYPE"));
				paymentAdviceTypesList.add(paymentAdviceLovObj);
			}
			logger.info("payment lov size in impl" +paymentAdviceTypesList.size());
		} catch (SQLException e) {
			logger.info(e.getLocalizedMessage());
			paymentDetails.setErrorCode("FAILURE");
			if(e.getLocalizedMessage()!=null){
				//paymentDetails.setErrorMessage("Not able to retreive payment advice types , failure reason is : "+e.getLocalizedMessage());
				paymentDetails.setErrorMessage("Not able to retreive payment advice types");

			}
			else{
				paymentDetails.setErrorMessage("Not able to retreive payment advice types ");
			}
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceTypesResultSet!=null){
				try {
					paymentAdivceTypesResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		paymentDetails.setPaymentAdviceLovList(paymentAdviceTypesList);
		logger.info(" Execution of getPaymentAdviceAllowedForUser() method has been completed");
		return paymentDetails;
	}
	
	
	

	public PaymentAdviceLock checkLockOnPaymentDetails(
			PaymentAdviceLock paymentAdviceLockObj) {
		logger.info(" Starting execution of checkLockOnPaymentDetails() method");
		final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.checkLockOnPaymentDetails(?,?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceTypesResultSet = null;
		CallableStatement callableStatement=null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setString(1,paymentAdviceLockObj.getReferenceNum());
			callableStatement.registerOutParameter(2, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(4, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			String lockStatus=callableStatement.getString(2);
			String errorCode=callableStatement.getString(3);
			String errorMessage=callableStatement.getString(4);
			paymentAdviceLockObj.setLockStatus(lockStatus);
			paymentAdviceLockObj.setErrorCode(errorCode);
			paymentAdviceLockObj.setErrorMessage(errorMessage);
		} catch (SQLException e) {
			logger.info(e.getLocalizedMessage());
			paymentAdviceLockObj.setErrorCode("FAILURE");
			if(e.getLocalizedMessage()!=null){
				//paymentAdviceLockObj.setErrorMessage("Not able to get lock status, failure reason is : "+e.getLocalizedMessage());
				logger.info("failure reason is" +e.getLocalizedMessage());
				  paymentAdviceLockObj.setErrorMessage("Not able to get lock status, failure reason is : Database issues");

				
			}
			else{
				paymentAdviceLockObj.setErrorMessage("Not able to get lock status");
			}
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceTypesResultSet!=null){
				try {
					paymentAdivceTypesResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of checkLockOnPaymentDetails() method has been completed");
		return paymentAdviceLockObj;
	}

	public PaymentAdviceLock acquireLockOnPaymentDetails(
			PaymentAdviceLock paymentAdviceLockObj) {
		logger.info(" Starting execution of acquireLockOnPaymentDetails() method");
		final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.acquireLockOnPaymentDetails(?,?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceTypesResultSet = null;
		CallableStatement callableStatement=null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setString(1,paymentAdviceLockObj.getReferenceNum());
			callableStatement.setString(2, paymentAdviceLockObj.getLockAcuiredBy());
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(4, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			String errorCode=callableStatement.getString(3);
			String errorMessage=callableStatement.getString(4);
			paymentAdviceLockObj.setErrorCode(errorCode);
			paymentAdviceLockObj.setErrorMessage(errorMessage);
		} catch (SQLException e) {
			logger.info(e.getLocalizedMessage());
			//e.printStackTrace();
			paymentAdviceLockObj.setErrorCode("FAILURE");
			if(e.getLocalizedMessage()!=null){
				//paymentAdviceLockObj.setErrorMessage("Not able to acquire lock on reference number "+paymentAdviceLockObj.getReferenceNum()+", failure reason is : "+e.getLocalizedMessage());
				logger.info("failure reason is" +e.getLocalizedMessage());
				  paymentAdviceLockObj.setErrorMessage("Not able to acquire lock on reference number "+paymentAdviceLockObj.getReferenceNum()+", failure reason is : Database Issues");

			}
			else{
				paymentAdviceLockObj.setErrorMessage("Not able to acquire lock on reference number "+paymentAdviceLockObj.getReferenceNum());
			}
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceTypesResultSet!=null){
				try {
					paymentAdivceTypesResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of acquireLockOnPaymentDetails() method has been completed");
		return paymentAdviceLockObj;
	}
	
	
	public PaymentAdviceLock releaseLockOnPaymentDetails(
			PaymentAdviceLock paymentAdviceLockObj) {
		logger.info(" Starting execution of releaseLockOnPaymentDetails() method");
		final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.releaseLockOnPaymentDetails(?,?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceTypesResultSet = null;
		CallableStatement callableStatement=null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setString(1,paymentAdviceLockObj.getReferenceNum());
			callableStatement.setString(2, paymentAdviceLockObj.getLockAcuiredBy());
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(4, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			String errorCode=callableStatement.getString(3);
			String errorMessage=callableStatement.getString(4);
			paymentAdviceLockObj.setErrorCode(errorCode);
			paymentAdviceLockObj.setErrorMessage(errorMessage);
		} catch (SQLException e) {
			logger.info(e.getLocalizedMessage());
			//e.printStackTrace();
			paymentAdviceLockObj.setErrorCode("FAILURE");
			if(e.getLocalizedMessage()!=null){
				//paymentAdviceLockObj.setErrorMessage("Not able to release lock on reference number "+paymentAdviceLockObj.getReferenceNum()+", failure reason is : "+e.getLocalizedMessage());
				logger.info("failure reason is" +e.getLocalizedMessage());
				  paymentAdviceLockObj.setErrorMessage("Not able to release lock on reference number "+paymentAdviceLockObj.getReferenceNum()+", failure reason is : Database Issues");

			}
			else{
				paymentAdviceLockObj.setErrorMessage("Not able to release lock on reference number "+paymentAdviceLockObj.getReferenceNum());
			}
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceTypesResultSet!=null){
				try {
					paymentAdivceTypesResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of releaseLockOnPaymentDetails() method has been completed");
		return paymentAdviceLockObj;
	}
	

	public void releaseAllLocks(
			String userId) {
		logger.info(" Starting execution of releaseAllLocks() method");
		final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.releaseAllLocks(?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceTypesResultSet = null;
		CallableStatement callableStatement=null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setString(1,userId);
			callableStatement.registerOutParameter(2, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			String errorCode=callableStatement.getString(2);
			String errorMessage=callableStatement.getString(3);
			logger.info(" Procedure returned error code "+errorCode+", error message "+errorMessage);
		} catch (SQLException e) {
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceTypesResultSet!=null){
				try {
					paymentAdivceTypesResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of releaseLockOnPaymentDetails() method has been completed");
	}


	public PaymentAdviceUploadFields getPaymentAdviceUploadFields() {
		logger.info(" Starting execution of getPaymentAdviceUploadFields() method");
		final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.getPaymentAdviceUploadFields(?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceFieldsResultSet = null;
		CallableStatement callableStatement=null;
		PaymentAdviceUploadFields paymentAdviceUploadFiledsObj=new PaymentAdviceUploadFields();
		HashMap<Integer,String> paymentAdviceFieldsMap=new HashMap<Integer,String>();
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.registerOutParameter(1, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(2, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			paymentAdivceFieldsResultSet = (ResultSet) callableStatement.getObject(1);
			String errorCode=callableStatement.getString(2);
			String errorMessage=callableStatement.getString(3);
			paymentAdviceUploadFiledsObj.setErrorCode(errorCode);
			paymentAdviceUploadFiledsObj.setErrorMessage(errorMessage);
			logger.info(" Procedure returned error code "+errorCode+", error message "+errorMessage);
			while (paymentAdivceFieldsResultSet!=null&&paymentAdivceFieldsResultSet.next()){
				paymentAdviceFieldsMap.put(paymentAdivceFieldsResultSet.getInt("FIELD_POSITION"),paymentAdivceFieldsResultSet.getString("FIELD_NAME"));
			}
			paymentAdviceUploadFiledsObj.setFieldMap(paymentAdviceFieldsMap);
		} catch (SQLException e) {
			paymentAdviceUploadFiledsObj.setErrorCode("FAILURE");
			paymentAdviceUploadFiledsObj.setErrorMessage("Unable to retreive payment advice fields");
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceFieldsResultSet!=null){
				try {
					paymentAdivceFieldsResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of getPaymentAdviceUploadFields() method has been completed");
		return paymentAdviceUploadFiledsObj;
	}
	

	public PaymentAdviceUploadFields getPaymentAdviceUploadMandateFields(String paymentAdviceProcess){
		logger.info(" Starting execution of getPaymentAdviceUploadMandateFields() method");
		final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.getPaymentAdviceMandateFields(?,?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceFieldsResultSet = null;
		CallableStatement callableStatement=null;
		PaymentAdviceUploadFields paymentAdviceUploadFiledsObj=new PaymentAdviceUploadFields();
		HashMap<Integer,String> paymentAdviceFieldsMap=new HashMap<Integer,String>();
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setString(1,paymentAdviceProcess);
			callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(4, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			paymentAdivceFieldsResultSet = (ResultSet) callableStatement.getObject(2);
			String errorCode=callableStatement.getString(3);
			String errorMessage=callableStatement.getString(4);
			paymentAdviceUploadFiledsObj.setErrorCode(errorCode);
			paymentAdviceUploadFiledsObj.setErrorMessage(errorMessage);
			logger.info(" Procedure returned error code "+errorCode+", error message "+errorMessage);
			while (paymentAdivceFieldsResultSet!=null&&paymentAdivceFieldsResultSet.next()){
				paymentAdviceFieldsMap.put(paymentAdivceFieldsResultSet.getInt("FIELD_POSITION"),paymentAdivceFieldsResultSet.getString("FIELD_NAME"));
			}
			paymentAdviceUploadFiledsObj.setFieldMap(paymentAdviceFieldsMap);
		} catch (SQLException e) {
			paymentAdviceUploadFiledsObj.setErrorCode("FAILURE");
			paymentAdviceUploadFiledsObj.setErrorMessage("Unable to retreive payment advice mandate fields");
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceFieldsResultSet!=null){
				try {
					paymentAdivceFieldsResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of getPaymentAdviceUploadMandateFields() method has been completed");
		return paymentAdviceUploadFiledsObj;	
	}


	public PaymentAdviceRequest getPaymentAdviceRequestId() {
		logger.info(" Starting execution of getPaymentAdviceRequestId() method");
		final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.getPaymentAdviceRequestId(?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceFieldsResultSet = null;
		CallableStatement callableStatement=null;
		PaymentAdviceRequest paymentAdviceRequestObj=new PaymentAdviceRequest();
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.registerOutParameter(1, OracleTypes.NUMBER);
			callableStatement.registerOutParameter(2, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			int requestId=callableStatement.getInt(1);
			String errorCode=callableStatement.getString(2);
			String errorMessage=callableStatement.getString(3);
			paymentAdviceRequestObj.setRequestId(requestId);
			paymentAdviceRequestObj.setErrorCode(errorCode);
			paymentAdviceRequestObj.setErrorMessage(errorMessage);
			logger.info(" Procedure returned error code "+errorCode+", error message "+errorMessage);
		} catch (SQLException e) {
			paymentAdviceRequestObj.setErrorCode("FAILURE");
			paymentAdviceRequestObj.setErrorMessage("Unable to retreive payment advice request id");
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceFieldsResultSet!=null){
				try {
					paymentAdivceFieldsResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of getPaymentAdviceRequestId() method has been completed");
		return paymentAdviceRequestObj;
	}

	
	public Transaction getDataBaseConnection() {
		logger.info(" Execution of getDataBaseConnection() method started");
		Transaction transactionObj=new Transaction();
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			Connection connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			transactionObj.setDataBaseConnection(connection);
			transactionObj.setErrorCode("SUCCESS");
			transactionObj.setErrorMessage(" Database connection has been established successfully ");
		} catch (SQLException e) {
			transactionObj.setErrorCode("FAILURE");
			//transactionObj.setErrorMessage(" Unable to establish database connection, reason for the failure is "+e.getLocalizedMessage());
			transactionObj.setErrorMessage(" Unable to establish database connection");
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		
		logger.info(" Execution of getDataBaseConnection() method has been completed");
		return transactionObj;
	}


	public Transaction closeDataBaseConnection(Transaction transactionObj) {
		logger.info(" Execution of closeDataBaseConnection() method started");
		try {
			if(transactionObj.getDataBaseConnection()!=null){
				transactionObj.getDataBaseConnection().close();
				logger.info(" Database connection has been closed successfully !! ");
				transactionObj.setErrorCode("SUCCESS");
				transactionObj.setErrorMessage(" Database connection has been closed successfully ");
			}
			
		} catch (SQLException e) {
			transactionObj.setErrorCode("FAILURE");
			//transactionObj.setErrorMessage(" Unable to close database connection, reason for the failure is "+e.getLocalizedMessage());
			transactionObj.setErrorMessage(" Unable to close database connection");
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		
		logger.info(" Execution of closeDataBaseConnection() method has been completed");
		return transactionObj;
	}
	
	
	public Transaction loadPaymentAdviceRequest(Transaction transactionObj,PaymentAdviceRequest paymentAdviceRequestObj) {
		logger.info(" Starting execution of loadPaymentAdviceRequest() method");
		final String procedureCall = "{call PAYMENT_ADVICE_PKG.updateRequestDetails(?,?,?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceFieldsResultSet = null;
		CallableStatement callableStatement=null;
		try {
			connection = transactionObj.getDataBaseConnection();
			connection.setAutoCommit(false);
			transactionObj.setDataBaseConnection(connection);
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setInt(1,paymentAdviceRequestObj.getRequestId());
			callableStatement.setString(2,paymentAdviceRequestObj.getOriginalSupportedFileName());

			callableStatement.setString(3,paymentAdviceRequestObj.getPaymentMode());
			callableStatement.registerOutParameter(4, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(5, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			String errorCode=callableStatement.getString(4);
			String errorMessage=callableStatement.getString(5);
			transactionObj.setErrorCode(errorCode);
			transactionObj.setErrorMessage(errorMessage);
			logger.info(" Procedure returned error code "+errorCode+", error message "+errorMessage);
		} catch (SQLException e) {
			transactionObj.setErrorCode("FAILURE");
			//transactionObj.setErrorMessage("Unable to save payment advice request information to the database, reason for the failure is "+e.getLocalizedMessage());
			transactionObj.setErrorMessage("Unable to save payment advice request information to the database");
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceFieldsResultSet!=null){
				try {
					paymentAdivceFieldsResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of loadPaymentAdviceRequest() method has been completed");
		return transactionObj;
	}
	
	
	public Transaction loadPaymentAdviceRequestData(Transaction transactionObj,PaymentAdviceUploadFields paymentAdviceData) {
		logger.info(" Starting execution of loadPaymentAdviceRequestData() method");
		final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.loadPaymentAdviceRequestData(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceFieldsResultSet = null;
		CallableStatement callableStatement=null;
		try {
			connection = transactionObj.getDataBaseConnection();
			transactionObj.setDataBaseConnection(connection);
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setInt(1,paymentAdviceData.getRequestId());
			callableStatement.setString(2,paymentAdviceData.getTrackingId());
			callableStatement.setString(3,paymentAdviceData.getRefNumber());
			callableStatement.setString(4,paymentAdviceData.getTargetFxAccountNumber());
			callableStatement.setString(5,paymentAdviceData.getInvoiceNumber());
			callableStatement.setDouble(6,paymentAdviceData.getInvoiceAllocationAmount());
			callableStatement.setDouble(7,paymentAdviceData.getPaymentExchangeRate());
			if(paymentAdviceData.getTdsAmount()!=null)
				callableStatement.setDouble(8,paymentAdviceData.getTdsAmount());
			else
				callableStatement.setFloat(8,0);
			callableStatement.setDouble(9,paymentAdviceData.getAmountInINR());
			callableStatement.setString(10,paymentAdviceData.getTranNo());
			callableStatement.setString(11,paymentAdviceData.getPaymentMode());
			callableStatement.setString(12,paymentAdviceData.getRemarks());
			callableStatement.setString(13,paymentAdviceData.getUploadedBy());
			callableStatement.setString(14,paymentAdviceData.getBankAccountNumber());	
			callableStatement.registerOutParameter(15, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(16, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			String errorCode=callableStatement.getString(15);
			String errorMessage=callableStatement.getString(16);
			transactionObj.setErrorCode(errorCode);
			transactionObj.setErrorMessage(errorMessage);
			logger.info(" Procedure returned error code "+errorCode+", error message "+errorMessage);
		} catch (SQLException e) {
			transactionObj.setErrorCode("FAILURE");
			//transactionObj.setErrorMessage("Unable to save payment advice request data to the database, reason for the failure is "+e.getLocalizedMessage());
			transactionObj.setErrorMessage("Unable to save payment advice request data to the database");
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceFieldsResultSet!=null){
				try {
					paymentAdivceFieldsResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of loadPaymentAdviceRequestData() method has been completed");
		return transactionObj;
	}

	
	public UserDetails getEmailAddress(UserDetails userDetailsObj) {
		logger.info(" Starting execution of getEmailAddress() method");
		final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.getUserEmailAddress(?,?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceFieldsResultSet = null;
		CallableStatement callableStatement=null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setString(1,userDetailsObj.getUserId());
			callableStatement.registerOutParameter(2, OracleTypes.VARCHAR); 
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(4, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			String emailId=callableStatement.getString(2);
			String errorCode=callableStatement.getString(3);
			String errorMessage=callableStatement.getString(4);
			userDetailsObj.setEmailAddress(emailId);
			userDetailsObj.setErrorCode(errorCode);
			userDetailsObj.setErrorMessage(errorMessage);
			logger.info("Email id is" +userDetailsObj.getEmailAddress());
			logger.info(" Procedure returned error code "+errorCode+", error message "+errorMessage);
		} catch (SQLException e) {
			userDetailsObj.setErrorCode("FAILURE");
			//userDetailsObj.setErrorMessage("Unable to retreive email address, reason for the failure is "+e.getLocalizedMessage());
			userDetailsObj.setErrorMessage("Unable to retreive email address");

			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceFieldsResultSet!=null){
				try {
					paymentAdivceFieldsResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of getEmailAddress() method has been completed");
		return userDetailsObj;
	}

	
}
