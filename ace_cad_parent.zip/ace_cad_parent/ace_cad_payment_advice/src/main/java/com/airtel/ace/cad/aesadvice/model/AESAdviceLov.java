package com.airtel.ace.cad.aesadvice.model;

public class AESAdviceLov {
	private String paymentAdviceType;
	private String status;
	public String getPaymentAdviceType() {
		return paymentAdviceType;
	}
	public void setPaymentAdviceType(String paymentAdviceType) {
		this.paymentAdviceType = paymentAdviceType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}


}
