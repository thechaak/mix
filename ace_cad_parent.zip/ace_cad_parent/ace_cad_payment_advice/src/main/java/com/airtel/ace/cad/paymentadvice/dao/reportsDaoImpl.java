/*package com.acecad.paymentAdviceApproval.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.springframework.jdbc.core.JdbcTemplate;

import com.acecad.reports.model.reportDetails;

public class reportsDaoImpl implements reportsDao{

	private DataSource dataSource;
	Connection conn = null;
	ResultSet resultset = null;
	
	public reportsDaoImpl(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	
	public int getRole(String parentUser)
	{
		int Role = 0;
		try {
			System.out.println("entered getRole method ");
			System.out.println("connection" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			System.out.println("connection established");
			String functionCall = "{? = call GETUSERROLE(?)}";
			CallableStatement callableStatement=conn.prepareCall(functionCall);
			callableStatement.registerOutParameter(1,Types.INTEGER);
			callableStatement.setString(2,parentUser);
			callableStatement.execute();
			
			 Role=callableStatement.getInt(1);
			 //System.out.println("role "+Role);
		}catch (Exception e) {
			e.printStackTrace();			
		}
		return Role;
	}


	
	public List<String> getStatus() {
		List<String> statusList=new ArrayList<String>();
		
		try {
			System.out.println("entered reportsdaoimpl");
			System.out.println("connection" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			System.out.println("connection established");
			// call proc
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GETFILESTATUS(?)}";

			CallableStatement callableStatement = conn
					.prepareCall(procedureCall);
			callableStatement.registerOutParameter(1, OracleTypes.CURSOR);
			callableStatement.executeUpdate();
			System.out.println("callable statements executed");
			
			resultset=(ResultSet) callableStatement.getObject(1);
		while(resultset.next())
		{
			statusList.add(resultset.getString("FILE_STATUS"));
		}
			
		
	}catch (Exception e) {
		e.printStackTrace();
	}
	finally{
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		return statusList ;
}


	public HashMap<Integer, List<reportDetails>> getReportDetails(
			reportDetails reportDetailsObj, int page) {
		
		HashMap<Integer, List<reportDetails>> mapWithReports=new HashMap<Integer, List<reportDetails>>();
		List<reportDetails>listOfReports=new ArrayList<reportDetails>();
		
		try {
			System.out.println("entered getreportdetails");
			System.out.println("connection" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			System.out.println("connection established");
			System.out.println(" User Id : "+reportDetailsObj.getChildUserId());
			System.out.println(" Status : "+reportDetailsObj.getStatus());
			// call proc
			final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.getBulkReportDetails(?,?,?,?,?,?,?,?,?,?,?,?)}";

			CallableStatement callableStatement = conn
					.prepareCall(procedureCall);
			

			
			
			callableStatement.setString(1, reportDetailsObj.getParentUserId());
			callableStatement.setString(2, reportDetailsObj.getChildUserId());
			callableStatement.setString(3, reportDetailsObj.getFileId());
			callableStatement.setString(4, reportDetailsObj.getStatus());
			callableStatement.setString(5, reportDetailsObj.getVendorId());
			callableStatement.setString(6, reportDetailsObj.getFromDate());
			callableStatement.setString(7, reportDetailsObj.getToDate());
			callableStatement.setInt(8, page);
			
			
			callableStatement.registerOutParameter(9, Types.INTEGER);
			callableStatement.registerOutParameter(10,Types.VARCHAR );
			callableStatement.registerOutParameter(11,Types.VARCHAR);
			callableStatement.registerOutParameter(12, OracleTypes.CURSOR);
			
		callableStatement.executeUpdate();
		System.out.println("callable statements executed");
		int totalPages=callableStatement.getInt(9);
		System.out.println("totalpages:"+totalPages);
		System.out.println("Error Code :"+callableStatement.getString(10));
		reportDetailsObj.setError_code(callableStatement.getString(10));
		System.out.println("Error Message :"+callableStatement.getString(11));
		reportDetailsObj.setError_msg(callableStatement.getString(11));
		resultset=(ResultSet)callableStatement.getObject(12);
		
		while(resultset!=null&&resultset.next()){
			
			reportDetails reportDetailsObject=new reportDetails();
			
			reportDetailsObject.setFileId(resultset.getString("FILE_ID"));
			
			reportDetailsObject.setUserId(resultset.getString("USER_ID"));
			reportDetailsObject.setVendorId(resultset.getString("VENDOR_ID"));
			reportDetailsObject.setVendorname(resultset.getString("VENDOR_NAME"));
			reportDetailsObject.setOriginalFileName(resultset.getString("ORIGINAL_FILE_NAME"));
			System.out.println(""+reportDetailsObject.getOriginalFileName());
			reportDetailsObject.setFinalFileName(resultset.getString("FINAL_FILE_NAME"));
			reportDetailsObject.setStatus(resultset.getString("FILE_STATUS"));
			reportDetailsObject.setTotRec(resultset.getInt("TOTAL_RECORDS"));
			reportDetailsObject.setValidRec(resultset.getInt("VALID_RECORDS"));
			reportDetailsObject.setInvalidRec(resultset.getInt("INVALID_RECORDS"));
			reportDetailsObject.setTotAmount(resultset.getInt("TOTAL_AMOUNT"));
			reportDetailsObject.setUploadedDate(resultset.getDate("UPLOADED_DATE"));
			reportDetailsObject.setMbl_count(resultset.getInt("MOB_COUNT"));
			reportDetailsObject.setFl_count(resultset.getInt("FL_COUNT"));
			reportDetailsObject.setIstm_count(resultset.getInt("ISTM_COUNT"));
			reportDetailsObject.setAes_count(resultset.getInt("AES_COUNT"));
			
			
			listOfReports.add(reportDetailsObject);
		}
		System.out.println("list size:"+listOfReports.size());
		
		
		
		mapWithReports.put(totalPages, listOfReports);
	}catch (Exception e) {
		e.printStackTrace();
	}
		return mapWithReports;
	
	}		
	
}
*/