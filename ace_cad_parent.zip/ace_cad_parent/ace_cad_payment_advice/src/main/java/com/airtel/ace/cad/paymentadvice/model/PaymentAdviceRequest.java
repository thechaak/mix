/**
 * 
 */
package com.airtel.ace.cad.paymentadvice.model;

/**
 * @author 
 *   
 */
public class PaymentAdviceRequest {
	private String errorCode;
	private String errorMessage;
	private String uploadedBy;
	private String uploadedUserName;
	private String uploadedUserCircle;
    private String originalUploadedFileName;
    private String renamedUploadedFileName;
    private String originalSupportedFileName;
    private String renamedSupportedFileName;
    private int requestId;
    private String sourceLOB;
    private String paymentAdviceProcessType;
    private int totalRecords;
    private int totalTragetAccounts;
    private Double totalInvoiceAllocationAmount;
    private Double amountInINR;
    private String paymentMode;
    public String getUploadedBy() {
		return uploadedBy;
	}

	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}

	public String getUploadedUserName() {
		return uploadedUserName;
	}

	public void setUploadedUserName(String uploadedUserName) {
		this.uploadedUserName = uploadedUserName;
	}

	public String getUploadedUserCircle() {
		return uploadedUserCircle;
	}

	public void setUploadedUserCircle(String uploadedUserCircle) {
		this.uploadedUserCircle = uploadedUserCircle;
	}

	public String getOriginalUploadedFileName() {
		return originalUploadedFileName;
	}

	public void setOriginalUploadedFileName(String originalUploadedFileName) {
		this.originalUploadedFileName = originalUploadedFileName;
	}

	public String getRenamedUploadedFileName() {
		return renamedUploadedFileName;
	}

	public void setRenamedUploadedFileName(String renamedUploadedFileName) {
		this.renamedUploadedFileName = renamedUploadedFileName;
	}

	public String getOriginalSupportedFileName() {
		return originalSupportedFileName;
	}

	public void setOriginalSupportedFileName(String originalSupportedFileName) {
		this.originalSupportedFileName = originalSupportedFileName;
	}

	public String getRenamedSupportedFileName() {
		return renamedSupportedFileName;
	}

	public void setRenamedSupportedFileName(String renamedSupportedFileName) {
		this.renamedSupportedFileName = renamedSupportedFileName;
	}

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public String getSourceLOB() {
		return sourceLOB;
	}

	public void setSourceLOB(String sourceLOB) {
		this.sourceLOB = sourceLOB;
	}

	public String getPaymentAdviceProcessType() {
		return paymentAdviceProcessType;
	}

	public void setPaymentAdviceProcessType(String paymentAdviceProcessType) {
		this.paymentAdviceProcessType = paymentAdviceProcessType;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public int getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}

	public int getTotalTragetAccounts() {
		return totalTragetAccounts;
	}

	public void setTotalTragetAccounts(int totalTragetAccounts) {
		this.totalTragetAccounts = totalTragetAccounts;
	}

	

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public Double getTotalInvoiceAllocationAmount() {
		return totalInvoiceAllocationAmount;
	}

	public void setTotalInvoiceAllocationAmount(
			Double totalInvoiceAllocationAmount) {
		this.totalInvoiceAllocationAmount = totalInvoiceAllocationAmount;
	}

	public Double getAmountInINR() {
		return amountInINR;
	}

	public void setAmountInINR(Double amountInINR) {
		this.amountInINR = amountInINR;
	}

}
