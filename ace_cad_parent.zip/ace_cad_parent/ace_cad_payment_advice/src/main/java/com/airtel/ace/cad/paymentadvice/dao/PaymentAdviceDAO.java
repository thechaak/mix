/**
 * 
 */
package com.airtel.ace.cad.paymentadvice.dao;

import java.util.List;

import com.airtel.ace.cad.paymentadvice.model.PaymentAdviceLock;
import com.airtel.ace.cad.paymentadvice.model.PaymentAdviceRequest;
import com.airtel.ace.cad.paymentadvice.model.PaymentAdviceUploadFields;
import com.airtel.ace.cad.paymentadvice.model.PaymentDetails;
import com.airtel.ace.cad.paymentadvice.model.Transaction;
import com.airtel.ace.cad.paymentadvice.model.UserDetails;

/**
 * @author 587111
 *
 */
public interface PaymentAdviceDAO {

	PaymentDetails getPaymentTypes();
	PaymentDetails getPaymentDetails(PaymentDetails paymentDetails);
	PaymentDetails getPaymentAdviceAllowedForUser(PaymentDetails paymentDetails);
	PaymentAdviceLock checkLockOnPaymentDetails(PaymentAdviceLock paymentAdviceLockObj);
	PaymentAdviceLock acquireLockOnPaymentDetails(PaymentAdviceLock paymentAdviceLockObj);
	PaymentAdviceLock releaseLockOnPaymentDetails(PaymentAdviceLock paymentAdviceLockObj);
	void releaseAllLocks(String userId) ;
	PaymentAdviceUploadFields getPaymentAdviceUploadFields();
	PaymentAdviceUploadFields getPaymentAdviceUploadMandateFields(String paymentAdviceProcess);
	PaymentAdviceRequest getPaymentAdviceRequestId();
	Transaction getDataBaseConnection();
	Transaction closeDataBaseConnection(Transaction transactionObj);
	Transaction loadPaymentAdviceRequest(Transaction transactionObj,PaymentAdviceRequest paymentAdviceRequestObj);
	Transaction loadPaymentAdviceRequestData(Transaction transactionObj,PaymentAdviceUploadFields paymentAdviceData) ;
	UserDetails getEmailAddress(UserDetails userDetailsObj);
	
}
