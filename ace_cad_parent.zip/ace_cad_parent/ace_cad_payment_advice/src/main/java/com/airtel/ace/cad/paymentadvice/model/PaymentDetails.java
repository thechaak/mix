/**
 * 
 */
package com.airtel.ace.cad.paymentadvice.model;

import java.util.List;
   
/**
 * @author 587111
 *
 */
public class PaymentDetails {
	
	private String userId;
	private List<PaymentType> paymentTypes;
	private String errorCode;
	private String errorMessage;
	private String paymentMode;
	private String lob;
	private String circle;
	private String refNumber;
	private String incomingTransActionRefNumber;
	private String fxAccountNum;
	private String customerName;
	private String customerBankAccountNum;
	private String paymentReceivedDate;
	private String paymentAmount;
	private String exchangeRate;
	private String currencyCode;
	private String refNo;
	private String annotation;
	private String bankBranchName;
	private String bankName;
	private String trackingId;
	private String chequeDate;
	private String legalEntity;
	private String remitterName;
	private String transactionId;
	private String acctExternalId;
	private String fxPostingStatus;
	private String paymentPostingStatusCode;
	private String paymentAdviceStatus;
	private String paymentAdviceStatusCode;
	private String amountInINR;
	private String paymentFoundIn;
	private String accountType;
	private String recordType;
	private int reverseFlag;
	private String invoiceNumber;
	private String recordSource; 
	private String paymentAdviceRequestId;
	private String mktCode;
	private String receiverName;
	private String fundRecievedCurrency;
	private String subsidairy;
 
	private List<PaymentDetails> paymentDetails;
	private List<PaymentAdviceLov> paymentAdviceLovList;
	
	public List<PaymentType> getPaymentTypes() {
		return paymentTypes;
	}


	public void setPaymentTypes(List<PaymentType> paymentTypes) {
		this.paymentTypes = paymentTypes;
	}


	public String getErrorMessage() {
		return errorMessage;
	}


	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}


	public String getErrorCode() {
		return errorCode;
	}


	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}


	public String getPaymentMode() {
		return paymentMode;
	}


	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}


	public String getLob() {
		return lob;
	}


	public void setLob(String lob) {
		this.lob = lob;
	}


	public String getCircle() {
		return circle;
	}


	public void setCircle(String circle) {
		this.circle = circle;
	}


	public String getRefNumber() {
		return refNumber;
	}


	public void setRefNumber(String refNumber) {
		this.refNumber = refNumber;
	}


	public String getIncomingTransActionRefNumber() {
		return incomingTransActionRefNumber;
	}


	public void setIncomingTransActionRefNumber(String incomingTransActionRefNumber) {
		this.incomingTransActionRefNumber = incomingTransActionRefNumber;
	}


	public String getFxAccountNum() {
		return fxAccountNum;
	}


	public void setFxAccountNum(String fxAccountNum) {
		this.fxAccountNum = fxAccountNum;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public String getPaymentReceivedDate() {
		return paymentReceivedDate;
	}


	public void setPaymentReceivedDate(String paymentReceivedDate) {
		this.paymentReceivedDate = paymentReceivedDate;
	}


	public String getPaymentAmount() {
		return paymentAmount;
	}


	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}


	public String getExchangeRate() {
		return exchangeRate;
	}


	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}


	public String getCurrencyCode() {
		return currencyCode;
	}


	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}


	public String getRefNo() {
		return refNo;
	}


	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}


	public String getAnnotation() {
		return annotation;
	}


	public void setAnnotation(String annotation) {
		this.annotation = annotation;
	}


	public String getBankBranchName() {
		return bankBranchName;
	}


	public void setBankBranchName(String bankBranchName) {
		this.bankBranchName = bankBranchName;
	}


	public String getBankName() {
		return bankName;
	}


	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


	public String getTrackingId() {
		return trackingId;
	}


	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}


	public String getChequeDate() {
		return chequeDate;
	}


	public void setChequeDate(String chequeDate) {
		this.chequeDate = chequeDate;
	}


	public String getLegalEntity() {
		return legalEntity;
	}


	public void setLegalEntity(String legalEntity) {
		this.legalEntity = legalEntity;
	}


	public String getRemitterName() {
		return remitterName;
	}


	public void setRemitterName(String remitterName) {
		this.remitterName = remitterName;
	}


	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}


	public String getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}


	public String getAcctExternalId() {
		return acctExternalId;
	}


	public void setAcctExternalId(String acctExternalId) {
		this.acctExternalId = acctExternalId;
	}


	public String getFxPostingStatus() {
		return fxPostingStatus;
	}


	public void setFxPostingStatus(String fxPostingStatus) {
		this.fxPostingStatus = fxPostingStatus;
	}


	public String getPaymentPostingStatusCode() {
		return paymentPostingStatusCode;
	}


	public void setPaymentPostingStatusCode(String paymentPostingStatusCode) {
		this.paymentPostingStatusCode = paymentPostingStatusCode;
	}


	public String getPaymentAdviceStatus() {
		return paymentAdviceStatus;
	}


	public void setPaymentAdviceStatus(String paymentAdviceStatus) {
		this.paymentAdviceStatus = paymentAdviceStatus;
	}


	public String getPaymentAdviceStatusCode() {
		return paymentAdviceStatusCode;
	}


	public void setPaymentAdviceStatusCode(String paymentAdviceStatusCode) {
		this.paymentAdviceStatusCode = paymentAdviceStatusCode;
	}


	public List<PaymentDetails> getPaymentDetails() {
		return paymentDetails;
	}


	public void setPaymentDetails(List<PaymentDetails> paymentDetails) {
		this.paymentDetails = paymentDetails;
	}


	public String getCustomerBankAccountNum() {
		return customerBankAccountNum;
	}


	public void setCustomerBankAccountNum(String customerBankAccountNum) {
		this.customerBankAccountNum = customerBankAccountNum;
	}


	public String getAmountInINR() {
		return amountInINR;
	}


	public void setAmountInINR(String amountInINR) {
		this.amountInINR = amountInINR;
	}


	public String getPaymentFoundIn() {
		return paymentFoundIn;
	}


	public void setPaymentFoundIn(String paymentFoundIn) {
		this.paymentFoundIn = paymentFoundIn;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public List<PaymentAdviceLov> getPaymentAdviceLovList() {
		return paymentAdviceLovList;
	}


	public void setPaymentAdviceLovList(List<PaymentAdviceLov> paymentAdviceLovList) {
		this.paymentAdviceLovList = paymentAdviceLovList;
	}


	public String getAccountType() {
		return accountType;
	}


	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}


	public String getRecordType() {
		return recordType;
	}


	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}


	public int getReverseFlag() {
		return reverseFlag;
	}


	public void setReverseFlag(int reverseFlag) {
		this.reverseFlag = reverseFlag;
	}


	public String getInvoiceNumber() {
		return invoiceNumber;
	}


	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}


	public String getRecordSource() {
		return recordSource;
	}


	public void setRecordSource(String recordSource) {
		this.recordSource = recordSource;
	}


	public String getPaymentAdviceRequestId() {
		return paymentAdviceRequestId;
	}


	public void setPaymentAdviceRequestId(String paymentAdviceRequestId) {
		this.paymentAdviceRequestId = paymentAdviceRequestId;
	}


	public String getMktCode() {
		return mktCode;
	}


	public void setMktCode(String mktCode) {
		this.mktCode = mktCode;
	}


	public String getReceiverName() {
		return receiverName;
	}


	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}


	public String getFundRecievedCurrency() {
		return fundRecievedCurrency;
	}


	public void setFundRecievedCurrency(String fundRecievedCurrency) {
		this.fundRecievedCurrency = fundRecievedCurrency;
	}


	public String getSubsidairy() {
		return subsidairy;
	}


	public void setSubsidairy(String subsidairy) {
		this.subsidairy = subsidairy;
	}

}
