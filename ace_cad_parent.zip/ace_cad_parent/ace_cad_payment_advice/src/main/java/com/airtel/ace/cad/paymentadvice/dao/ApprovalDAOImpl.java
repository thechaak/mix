package com.airtel.ace.cad.paymentadvice.dao;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.airtel.ace.cad.paymentadvice.model.ApprovalDetails;
import com.airtel.ace.cad.paymentadvice.model.Circle;

import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;

public class ApprovalDAOImpl implements ApprovalDAO {

	@Autowired
	DataSource dataSource;

	@Autowired
	private PlatformTransactionManager transactionManager;
	private static Logger logger = LogManager.getLogger("paymentAdviceApprovalLogger");
	private static String paymentAdviceHomePath = System.getenv("PAYMENT_ADVICE_HOME");


	/*public ApprovalDAOImpl(DataSource dataSource) {

		this.dataSource = dataSource;
		setTransactionManager(transactionManager);
	}*/

/*	public void setTransactionManager(
			PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}*/

	/*public List<VendorDetails> IDandName() {

		final String procedureCall = "{call AIRTL_VENDOR_DETAILS_PKG.AIRTL_VENDOR_ID_NAME_DETIALS(?)}";
		Connection connection = null;
		List<VendorDetails> IDandNameList = new ArrayList<VendorDetails>();
		ResultSet resSetIDandName = null;

		try {

			// Get Connection instance from dataSource
			logger.info("connect" + "ion:" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info("enterd into vendor insert");

			CallableStatement callableStatement = connection
					.prepareCall(procedureCall);

			logger.info("entered into IDandName retrieval in dao");

			callableStatement.registerOutParameter(1, OracleTypes.CURSOR);

			callableStatement.executeUpdate();

			resSetIDandName = (ResultSet) callableStatement.getObject(1);

			if (resSetIDandName == null) {
				logger.info("resultset is null");
				return IDandNameList;
			}

			while (resSetIDandName.next()) {

				VendorDetails IDandNamedetailsObj = new VendorDetails();

				IDandNamedetailsObj.setVendorName(resSetIDandName
						.getString("VENDOR_NAME"));
				IDandNamedetailsObj.setVendorId(resSetIDandName
						.getString("vendor_id"));

				IDandNameList.add(IDandNamedetailsObj);

				logger.info("vendor name is..."
						+ IDandNamedetailsObj.getVendorName());
				logger.info("vendor id is."
						+ IDandNamedetailsObj.getVendorId());

			}

		} catch (SQLException e) {
			e.printStackTrace();

		} finally {

			if (connection != null)
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}

		return IDandNameList;

	}
	
	*/
	
	//get paymode list and payment advice process details
	
	public List<String> getModeOfPayment() 
	{
		List<String> modeOfPaymentList=new ArrayList<String>();
		Connection connection = null;
		CallableStatement callableStatement=null;
		ResultSet modeOfPaymentResultSet=null;
		try 
		{
			logger.info("entered payment mode list");
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			logger.info("datasource is " +dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();

			final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.PAYMENT_MODE_LIST(?,?,?)}";

			 callableStatement = connection.prepareCall(procedureCall);
			callableStatement.registerOutParameter(1, Types.CHAR);
			callableStatement.registerOutParameter(2, Types.CHAR);
			callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
			
			
			callableStatement.executeUpdate();
			
			 modeOfPaymentResultSet=(ResultSet) callableStatement.getObject(3);
			if (modeOfPaymentResultSet == null) 
	        {
				logger.info("result set details are null ..DB is returning null values!!!");
				return null;
			}
			else
			{
		     while(modeOfPaymentResultSet!=null && modeOfPaymentResultSet.next())
		      {
			   
			    modeOfPaymentList.add(modeOfPaymentResultSet.getString("PAYMENT_MODE"));
			   
		      }
		}
		logger.info("LIST SIZE IS PAY MODE" +modeOfPaymentList.size());
	}catch (Exception e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		return null;
	}
	finally{
		
		if(callableStatement!=null){
		try {
			callableStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
	}
		
		if(modeOfPaymentResultSet!=null){
			try {
				modeOfPaymentResultSet.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);			}
		}
		
		if(connection!=null){
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);			}
		}
		
		
}
		return modeOfPaymentList;
}
	
	
	
	
	
	//get payment mode list and payment advice process details//
	
	
	//GET PAYMENT ADVICE USER_CIRCLES
	
	public List<Circle> getCirclesList() 
	{
		List<Circle> circlesList=new ArrayList<Circle>();
		Connection connection = null;
		CallableStatement callableStatement=null;
		ResultSet circlesResultSet=null;
		try 
		{
			logger.info("entered payment mode list");
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			logger.info("datasource is " +dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();

			final String procedureCall = "{call  PA_USER_CIRCLES(?,?,?)}";

			 callableStatement = connection.prepareCall(procedureCall);
			callableStatement.registerOutParameter(1, Types.CHAR);
			callableStatement.registerOutParameter(2, Types.CHAR);
			callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
			
			
			callableStatement.executeUpdate();
			
			 circlesResultSet=(ResultSet) callableStatement.getObject(3);
			if (circlesResultSet == null) 
	        {
				logger.info("result set details are null ..DB is returning null values!!!");
			}
			else
			{
		     while(circlesResultSet!=null && circlesResultSet.next())
		      {
			   
		    	 String circleCode = circlesResultSet
							.getString("CIRCLE_CODE");
					String circleName = circlesResultSet
							.getString("CIRCLE_NAME");
					Circle circleObj=new Circle();
					circleObj.setCircleCode(circleCode);
					circleObj.setCircleDescription(circleName);
					circlesList.add(circleObj);
			   
		      }
		}
		logger.info("circles list Size is" +circlesList.size());
	}catch (Exception e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);	
		return null;	
	}
	finally{
		
		if(callableStatement!=null){
		try {
			callableStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);		}
	}
		
		if(circlesResultSet!=null){
			try {
				circlesResultSet.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);			}
		}
		
		if(connection!=null){
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);			}
		}
		
		
}
		return circlesList;
}

	
	//get payment advice circles list completed 
	


	
	
	//get payment advice process details
	
		public List<String> getPaymentAdviceProcessList() 
		{
			List<String> paymentAdviceProcessList=new ArrayList<String>();
			Connection connection = null;
			CallableStatement callableStatement=null;
			ResultSet paymentAdviceProcesResultSet=null;
			try 
			{
				logger.info("entered liuReasonDropdown");
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				connection = jdbcTemplate.getDataSource().getConnection();

				final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.PROCESS_TYPE_LIST(?,?,?)}";

				 callableStatement = connection.prepareCall(procedureCall);
				callableStatement.registerOutParameter(1, Types.CHAR);
				callableStatement.registerOutParameter(2, Types.CHAR);
				callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
				
				
				callableStatement.executeUpdate();
				
				 paymentAdviceProcesResultSet=(ResultSet) callableStatement.getObject(3);
				if (paymentAdviceProcesResultSet == null) 
		        {
					logger.info("result set details are null ..DB is returning null values!!!");
				}
				else
				{
			     while(paymentAdviceProcesResultSet!=null && paymentAdviceProcesResultSet.next())
			      {
				   
				    paymentAdviceProcessList.add(paymentAdviceProcesResultSet.getString("PROCESS_TYPE"));
				    
			      }
			}
			
		}catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);		
			return null;	
		}
		finally{
			
			if(callableStatement!=null){
			try {
				callableStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);			}
		}
			
			if(paymentAdviceProcesResultSet!=null){
				try {
					paymentAdviceProcesResultSet.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);				}
			}
			
			if(connection!=null){
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);				}
			}
			
			
}
			return paymentAdviceProcessList;
	}
		
		
		
		
		
		//get  and payment advice process details//
		
		
		
		//get rejection reasons
		
				public List<String> getRejectReasons() 
				{
					List<String> rejectReasonsList=new ArrayList<String>();
					Connection connection = null;
					CallableStatement callableStatement=null;
					ResultSet rejectionReasonResultSet=null;
					try 
					{
						logger.info("entered getRejecReason");
						JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
						connection = jdbcTemplate.getDataSource().getConnection();

						final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.getRejectionReasons(?,?,?)}";

						 callableStatement = connection.prepareCall(procedureCall);
						callableStatement.registerOutParameter(1, OracleTypes.CURSOR);
						callableStatement.registerOutParameter(2, Types.CHAR);
						callableStatement.registerOutParameter(3, Types.CHAR);
						
						
						callableStatement.executeUpdate();
						
						 rejectionReasonResultSet=(ResultSet) callableStatement.getObject(1);
						if (rejectionReasonResultSet == null) 
				        {
							logger.info("result set details are null ..DB is returning null values!!!");
						}
						else
						{
					     while(rejectionReasonResultSet!=null && rejectionReasonResultSet.next())
					      {
						   
					    	 rejectReasonsList.add(rejectionReasonResultSet.getString("rejection_reason"));
						    
					      }
					}
					
				}catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
					return null;
					}
				finally{
					
					if(callableStatement!=null){
					try {
						callableStatement.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
					}
				}
					
					if(rejectionReasonResultSet!=null){
						try {
							rejectionReasonResultSet.close();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							logger.error(errors);
						}
					}
					
					if(connection!=null){
						try {
							connection.close();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							logger.error(errors);
						}
					}
					
					
}
					return rejectReasonsList;
			}
				
				
				
				///get reject reasons
					
	
	
	
	
	
	
	
	

	//first default page
	
	
	public HashMap<Integer, List<ApprovalDetails>> getApprovalDetails(int pageNumber, ApprovalDetails approvalDetailsObj)
	{
		HashMap<Integer, List<ApprovalDetails>> ApprovalDetailsMap = new HashMap<Integer, List<ApprovalDetails>>();

		List<ApprovalDetails> ApprovalDetailsList = new ArrayList<ApprovalDetails>();
		Connection connection=null;
		ResultSet allDetails =null;
		CallableStatement callableStatement=null;
		try {
			logger.info("entered daoimpl @getApprovalDetails");
		//	logger.info("connection" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			final String procedureCall = "{call PAYMENT_ADVICE_PKG.PAYMENT_ADVICE_DETAILS_SEARCH(?,?,?,?,?,?,?,?,?,?,?,?,?)}";

			 callableStatement = connection.prepareCall(procedureCall);

			 
			 
			    logger.info("page number :" +pageNumber);
				logger.info("payment mode " +approvalDetailsObj.getPaymentMode());
		        logger.info("process type " +approvalDetailsObj.getProcessType());
		        logger.info("uploaded olm id " +approvalDetailsObj.getUploadedOLMId());
				logger.info("request id " +approvalDetailsObj.getRequestID());
		        logger.info("circle " +approvalDetailsObj.getCircle());
		        logger.info("from date :" +approvalDetailsObj.getFromDate());
				logger.info("to date " +approvalDetailsObj.getToDate());
			 

			callableStatement.setInt(1, pageNumber);
			callableStatement.setString(2, approvalDetailsObj.getPaymentMode());
			callableStatement.setString(3, approvalDetailsObj.getProcessType());
			callableStatement.setString(4, approvalDetailsObj.getUploadedOLMId());
			callableStatement.setString(4, approvalDetailsObj.getUploadedOLMId());
			callableStatement.setLong(5, approvalDetailsObj.getRequestID());
			callableStatement.setString(6, approvalDetailsObj.getCircle());
			callableStatement.setString(7, approvalDetailsObj.getFromDate());
			callableStatement.setString(8, approvalDetailsObj.getToDate());
			callableStatement.setString(9, approvalDetailsObj.getRoleId());
			
			
			callableStatement.registerOutParameter(10, Types.INTEGER);
			callableStatement.registerOutParameter(11, Types.CHAR);
			callableStatement.registerOutParameter(12, Types.CHAR);
			
			callableStatement.registerOutParameter(13, OracleTypes.CURSOR);
			callableStatement.executeUpdate();

			logger.info("callable statements executed in getApprovalDetails@impl");

			int totalPages = callableStatement.getInt(10);
			
			logger.info("total pages :" +totalPages);
            logger.info("error code " +callableStatement.getString(11));
            logger.info("error message " +callableStatement.getString(12));
            approvalDetailsObj.setErrorMessage(callableStatement.getString(12));
            logger.info("error message after set" +approvalDetailsObj.getErrorMessage()); 
			allDetails = (ResultSet) callableStatement.getObject(13);
			
			if (allDetails == null) 
	        {
				logger.info("result set details are null ..DB is returning null values!!!");
			}
			
			else
			{
			  while (allDetails.next()) 
			   {
				ApprovalDetails approvalDetailsResObj = new ApprovalDetails();

				approvalDetailsResObj.setProcessType(allDetails.getString("VC_PROCESS_TYPE"));
				approvalDetailsResObj.setPaymentMode(allDetails.getString("VC_PAYMENT_MODE"));
				approvalDetailsResObj.setUploadedCircle(allDetails.getString("VC_UPLOADED_CIRCLE"));
				approvalDetailsResObj.setRequestID(allDetails.getInt("I_REQUEST_ID"));
				approvalDetailsResObj.setUploadedDate(allDetails.getString("DT_UPLOADED_DATE")); 
				approvalDetailsResObj.setApprovalTime(allDetails.getString("CAD_APPROVAL_TIME"));
				approvalDetailsResObj.setUploadedName(allDetails.getString("VC_UPLOADED_USER_NAME"));
				approvalDetailsResObj.setSourceLOB(allDetails.getString("VC_SOURCE_LOB"));
				approvalDetailsResObj.setDestinationLOB(allDetails.getString("VC_DESTINATION_LOB"));
				approvalDetailsResObj.setBankAccountNumber(allDetails.getString("VC_BANK_ACCOUNT_NUMBER"));
				approvalDetailsResObj.setTotalTargetAccounts(allDetails.getInt("I_TOTAL_TARGET_ACCOUNTS"));
				approvalDetailsResObj.setTotalAmount(allDetails.getDouble("I_TOTAL_AMOUNT"));
				approvalDetailsResObj.setPaymentCurrency(allDetails.getString("VC_PAYMENT_CURRENCY"));
				approvalDetailsResObj.setAmountInINR(allDetails.getDouble("I_AMOUNT_IN_INR"));
				approvalDetailsResObj.setB2b_b2c(allDetails.getString("B2C_FLAG"));

				approvalDetailsResObj.setFileName(allDetails.getString("VC_UPLOADED_RENAMED_FILE_NAME"));
				
				if(allDetails.getString("REQUEST_COMMENTS")!=null){
				approvalDetailsResObj.setNotes(allDetails.getString("REQUEST_COMMENTS"));
				}
				if(allDetails.getString("REQUEST_COMMENTS")==null){
					approvalDetailsResObj.setNotes("");
					}
				approvalDetailsResObj.setSupportFile(allDetails.getString("SUPPORT_FILE"));
				approvalDetailsResObj.setCurrencyFileType(allDetails.getString("CURRENCY"));
				//approvalDetailsResObj.setPercentChange(allDetails.getString("PERCENT_EXCHANGE_RATE"));
				System.out.println("percent exchange rate---->>>>>>"+approvalDetailsResObj.getPercentChange());
				
				logger.info("allDetails.getDate(DT_UPLOADED_DATE)" +allDetails.getString("DT_UPLOADED_DATE"));
				logger.info("Support File->>" +allDetails.getString("SUPPORT_FILE"));
				logger.info("approvalDetailsResObj.setUploadedDate" +approvalDetailsResObj.getUploadedDate());
				
				ApprovalDetailsList.add(approvalDetailsResObj);
			}
		  }
			/*logger.info("no of rows in the list returned from db::"
					+ ApprovalDetailsList.size());
			if (ApprovalDetailsList.size() != 0) 
			{
				logger.info("no of rows in the list returned from db::"+ ApprovalDetailsList.size());
				for (int i = 0; i < ApprovalDetailsList.size(); i++) 
				{
					ApprovalDetails approval = ApprovalDetailsList.get(i);
					logger.info(" File Id : " + (i + 1) +" "+ approval.getRequestID());
				}
			}
*/
			logger.info("all objects added to hashmap");
			ApprovalDetailsMap.put(totalPages, ApprovalDetailsList);
		} 
		catch (SQLException e) 
	    {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		logger.info("Sql Exception in catch:"+ e.getMessage());
		return null;
	    }
	   catch(Exception e)
	    {
		   StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		logger.info("Exception in catch:"+ e.getMessage());
		return null;
	    }
	           finally{
					
					if(callableStatement!=null){
					try {
						callableStatement.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
					}
				}
					
					if(allDetails!=null){
						try {
							allDetails.close();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							logger.error(errors);
						}
					}
					
					if(connection!=null){
						try {
							connection.close();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							logger.error(errors);
						}
					}
					
					
}

		return ApprovalDetailsMap;
	}


	//first default page........//

	

	public HashMap<Integer, List<ApprovalDetails>> getApprovalDetailsWithPgtn(int pageNumber, ApprovalDetails approvalDetailsObj)
	{
		HashMap<Integer, List<ApprovalDetails>> ApprovalDetailsMap = new HashMap<Integer, List<ApprovalDetails>>();

		List<ApprovalDetails> ApprovalDetailsList = new ArrayList<ApprovalDetails>();
		Connection connection=null;
		ResultSet allDetails=null;
		CallableStatement callableStatement=null;
		try {
			logger.info("entered daoimpl @getApprovalDetails");
			//logger.info("connection" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			final String procedureCall = "{call PAYMENT_ADVICE_PKG.PAYMENT_ADVICE_DETAILS_SEARCH(?,?,?,?,?,?,?,?,?,?,?,?)}";

			 callableStatement = connection.prepareCall(procedureCall);

			 
			    logger.info("page number :" +pageNumber);
				logger.info("payment mode " +approvalDetailsObj.getPaymentMode());
		        logger.info("process type " +approvalDetailsObj.getProcessType());
		        logger.info("uploaded olm id " +approvalDetailsObj.getUploadedOLMId());
				logger.info("request id " +approvalDetailsObj.getRequestID());
		        logger.info("circle " +approvalDetailsObj.getCircle());
		        logger.info("from date :" +approvalDetailsObj.getFromDate());
				logger.info("to date " +approvalDetailsObj.getToDate());
		        
			 
			 
			 
			 
			 
			callableStatement.setInt(1, pageNumber);
			callableStatement.setString(2, approvalDetailsObj.getPaymentMode());
			callableStatement.setString(3, approvalDetailsObj.getProcessType());
			callableStatement.setString(4, approvalDetailsObj.getUploadedOLMId());
			callableStatement.setLong(5, approvalDetailsObj.getRequestID());
			callableStatement.setString(6, approvalDetailsObj.getCircle());
			callableStatement.setString(7, approvalDetailsObj.getFromDate());
			callableStatement.setString(8, approvalDetailsObj.getToDate());
			
			
			callableStatement.registerOutParameter(9, Types.INTEGER);
			callableStatement.registerOutParameter(10, Types.CHAR);
			callableStatement.registerOutParameter(11, Types.CHAR);
			callableStatement.registerOutParameter(12, OracleTypes.CURSOR);
			callableStatement.executeUpdate();

			logger.info("callable statements executed in getApprovalDetails@impl");

			int totalPages = callableStatement.getInt(9);
			
			logger.info("total pages :" +totalPages);
			logger.info("error code " +callableStatement.getString(10));
	        logger.info("error message " +callableStatement.getString(11));
            approvalDetailsObj.setErrorMessage(callableStatement.getString(11));


			allDetails = (ResultSet) callableStatement.getObject(12);
			
			if (allDetails == null) 
	        {
				logger.info("result set details are null ..DB is returning null values!!!");
			}
			
			else
			{
			  while (allDetails.next()) 
			   {
				ApprovalDetails approvalDetailsResObj = new ApprovalDetails();

				approvalDetailsResObj.setProcessType(allDetails.getString("VC_PROCESS_TYPE"));
				approvalDetailsResObj.setPaymentMode(allDetails.getString("VC_PAYMENT_MODE"));
				approvalDetailsResObj.setUploadedCircle(allDetails.getString("VC_UPLOADED_CIRCLE"));
				approvalDetailsResObj.setRequestID(allDetails.getInt("I_REQUEST_ID"));
				approvalDetailsResObj.setUploadedDate(allDetails.getString("DT_UPLOADED_DATE"));
				approvalDetailsResObj.setUploadedName(allDetails.getString("VC_UPLOADED_USER_NAME"));
				approvalDetailsResObj.setSourceLOB(allDetails.getString("VC_SOURCE_LOB"));
				approvalDetailsResObj.setDestinationLOB(allDetails.getString("VC_DESTINATION_LOB"));
				approvalDetailsResObj.setBankAccountNumber(allDetails.getString("VC_BANK_ACCOUNT_NUMBER"));
				approvalDetailsResObj.setTotalTargetAccounts(allDetails.getInt("I_TOTAL_TARGET_ACCOUNTS"));
				approvalDetailsResObj.setTotalAmount(allDetails.getDouble("I_TOTAL_AMOUNT"));
				approvalDetailsResObj.setPaymentCurrency(allDetails.getString("VC_PAYMENT_CURRENCY"));
				approvalDetailsResObj.setAmountInINR(allDetails.getDouble("I_AMOUNT_IN_INR"));
				approvalDetailsResObj.setB2b_b2c(allDetails.getString("B2C_FLAG"));

				approvalDetailsResObj.setFileName(allDetails.getString("VC_UPLOADED_RENAMED_FILE_NAME"));
				approvalDetailsResObj.setNotes(allDetails.getString("REQUEST_COMMENTS"));				
				approvalDetailsResObj.setSupportFile(allDetails.getString("SUPPORT_FILE"));


				
				
				ApprovalDetailsList.add(approvalDetailsResObj);
			}
		  }
			
			logger.info("all objects added to hashmap");
			ApprovalDetailsMap.put(totalPages, ApprovalDetailsList);
		} 
		catch (SQLException e) 
	    {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		logger.info("Sql Exception in catch:"+ e.getMessage());
		return null;
	    }
	   catch(Exception e)
	    {
		   StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		logger.info("Exception in catch:"+ e.getMessage());
		return null;
	    }
	           finally{
					
					if(callableStatement!=null){
					try {
						callableStatement.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
					}
				}
					
					if(allDetails!=null){
						try {
							allDetails.close();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							logger.error(errors);
						}
					}
					
					if(connection!=null){
						try {
							connection.close();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							logger.error(errors);
						}
					}
					
					
}

		return ApprovalDetailsMap;
	}
	
	
/////////////..........................................//////
public ApprovalDetails downloadPaymentAdviceFile(String userId,String requestId,String paymentMode,String extension)
{
System.out.println("in advice download...........");
ResultSet resultsetdetails = null;
Connection connection=null;
CallableStatement callableStatement=null;
int i=1;
ApprovalDetails paymentAdvicedownloadObj=new ApprovalDetails();	

try {
   
JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
connection = jdbcTemplate.getDataSource().getConnection();
final String procedureCall = "{call PAYMENT_ADVICE_PKG.GET_PAYMENT_ADVICE_REQ_DETAILS(?,?,?,?,?)}";

 callableStatement = connection.prepareCall(procedureCall);


logger.info("details entered into callable statement of downloadPaymentAdviceFile @IMPL ");
logger.info("REQUEST ID AND PAYMENT MODE ARE" +"REQUEST ID" +requestId +"PAYMENT MODE" +paymentMode);
callableStatement.setString(1, userId);
callableStatement.setInt(2, Integer.parseInt(requestId));
callableStatement.setString(3, paymentMode);
callableStatement.registerOutParameter(4, OracleTypes.CURSOR);
callableStatement.registerOutParameter(5,OracleTypes.VARCHAR);

callableStatement.executeUpdate();

String downloadStatus=callableStatement.getString(5);

logger.info("status @ downloadPaymentAdviceFile"+downloadStatus );
paymentAdvicedownloadObj.setDownloadStatus(downloadStatus);


resultsetdetails = (ResultSet) callableStatement.getObject(4);

if (resultsetdetails == null) 
{
	logger.info("DB RETURNING NULL VALUES");
}

FileOutputStream downloadFile = null;
try 
{
	downloadFile = new FileOutputStream(new File(paymentAdviceHomePath+ File.separator+"UploadedFiles"+File.separator+"Payment_Advice_"+requestId+"."+extension));
	//downloadFile = new FileOutputStream(new File("C:/Users/1004362/Desktop/A/test1.xls"));


 }

catch (FileNotFoundException e) {
	
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);
}

XSSFWorkbook workbook = new XSSFWorkbook();
XSSFSheet worksheet = workbook.createSheet("Payment Advice");
XSSFRow row=null;
row = worksheet.createRow(0);
XSSFCellStyle cellStyle = workbook.createCellStyle();

Cell cellA1 = row.createCell((short) 0);
cellA1.setCellValue("Payment Mode");

Cell cellB1 = row.createCell((short) 1);
cellB1.setCellValue("Ticket No");

Cell cellC1 = row.createCell((short) 2);
cellC1.setCellValue("Ticket Date"); 

Cell cellD1 = row.createCell((short) 3);
cellD1.setCellValue("Request Raised by (OLM ID)");

Cell cellAF1 = row.createCell((short) 4);
cellAF1.setCellValue("Request Raised by (Name)");
//cellStyle = workbook.createCellStyle();

Cell cellE1 = row.createCell((short) 5);
cellE1.setCellValue("Source LOB");

Cell cellF1 = row.createCell((short) 6);
cellF1.setCellValue("Source Circle Name");

Cell cellG1 = row.createCell((short) 7);
cellG1.setCellValue("Destination LOB");
		
Cell cellH1 = row.createCell((short) 8);
cellH1.setCellValue("Destination Circle Name");

Cell cellI1 = row.createCell((short) 9);
cellI1.setCellValue("UTR No / Cheque no");

Cell cellJ1 = row.createCell((short) 10);
cellJ1.setCellValue("Incoming Transaction Ref No/Source FX Account No");

Cell cellK1 = row.createCell((short) 11);
cellK1.setCellValue("Value date/Trans Date");

Cell cellL1 = row.createCell((short) 12);
cellL1.setCellValue("Actual Amount Received (Actual currency)/Receipt Amount");

Cell cellM1 = row.createCell((short) 13);	           
cellM1.setCellValue("Payment Exchange Rate");

Cell cellN1 = row.createCell((short) 14);
cellN1.setCellValue("Fund Received Currency");

Cell cellNx1 = row.createCell((short) 15);
cellNx1.setCellValue("Dummy Account currency");

Cell cellNy1 = row.createCell((short) 16);
cellNy1.setCellValue("Posting Currency");

Cell cellO1 = row.createCell((short) 17);
cellO1.setCellValue("Amount in INR/Receipt Amount");

Cell cellP1 = row.createCell((short) 18);
cellP1.setCellValue("Legal Entity of Receiving Airtel Bank Account no");

Cell cellQ1 = row.createCell((short) 19);
cellQ1.setCellValue("Receiving account received from RBI 2/Bank Account Number");

Cell cellR1 = row.createCell((short) 20);
cellR1.setCellValue("Receiving Name/Source FX Account Name");

Cell cellS1 = row.createCell((short) 21);
cellS1.setCellValue("Remitter Name");

Cell cellT1 = row.createCell((short) 22);
cellT1.setCellValue("Ref No/Deposit Circle");

Cell cellU1 = row.createCell((short) 23);
cellU1.setCellValue("Payment Details 1/Annotation");

Cell cellV1 = row.createCell((short) 24);
cellV1.setCellValue("Payment Details 2 /Bank Branch Name");

Cell cellW1 = row.createCell((short) 25);
cellW1.setCellValue("Target FX Account Number");

Cell cellX1 = row.createCell((short) 26);
cellX1.setCellValue("Company / Customer name in FX");

Cell cellY1 = row.createCell((short) 27);
cellY1.setCellValue("Invoice Number");

Cell cellZ1 = row.createCell((short) 28);
cellZ1.setCellValue("Invoice Allocation Amount");

//Cell cellAA1 = row.createCell((short) 27);
//cellAA1.setCellValue("TDS Amount (Invoice wise)");

//Cell cellAB1 = row.createCell((short) 28);
//cellAB1.setCellValue("TAN No");

Cell cellAA1 = row.createCell((short) 29);
cellAA1.setCellValue("Cheque Date");

Cell cellAB1 = row.createCell((short) 30);
cellAB1.setCellValue("Bank Name");

Cell cellAC1 = row.createCell((short) 31);
cellAC1.setCellValue("Remarks");

Cell cellAD1 = row.createCell((short) 32);
cellAD1.setCellValue("B2B/B2C");

Cell cellAE1 = row.createCell((short) 33);
cellAE1.setCellValue("Payment Advice exemption");

Cell cellAH1 = row.createCell((short) 34);
cellAH1.setCellValue("Customer Email Id");

try{				
if(resultsetdetails!=null){
	while (resultsetdetails.next()) {
		
		ApprovalDetails paDownloadObj=new ApprovalDetails();
		
		paDownloadObj.setPaymentMode(resultsetdetails.getString("PAYMENT_MODE"));
		paDownloadObj.setRequestID(Long.parseLong(resultsetdetails.getString("TICKET_NO")));
		paDownloadObj.setUploadedDate(resultsetdetails.getString("TICKET_DATE"));
		paDownloadObj.setUploadedName(resultsetdetails.getString("REQUEST_RAISED_BY"));
		paDownloadObj.setDestinationLOB(resultsetdetails.getString("DESTINATION_LOB"));
	if(resultsetdetails.getString("DESTINATION_LOB")!=null && resultsetdetails.getString("DESTINATION_LOB").equalsIgnoreCase("BTS")){
			paDownloadObj.setDestinationLOB("FL");
		}
		paDownloadObj.setSourceLOB(resultsetdetails.getString("SOURCE_LOB"));
		
		if(resultsetdetails.getString("SOURCE_LOB")!=null && resultsetdetails.getString("SOURCE_LOB").equalsIgnoreCase("BTS")){
			paDownloadObj.setSourceLOB("FL");
		}
		if(resultsetdetails.getString("SOURCE_LOB")==null){
			paDownloadObj.setSourceLOB("-");
		}
		paDownloadObj.setSourceCircle(resultsetdetails.getString("SOURCE_CIRCLE"));
		paDownloadObj.setDestinationCircle(resultsetdetails.getString("DESTINATION_CIRCLE"));
		paDownloadObj.setUtrNumber(resultsetdetails.getString("CHQ_NUMBER"));
		paDownloadObj.setPaymentReceivedDate(resultsetdetails.getDate("TRANS_DATE"));					
		paDownloadObj.setPaymentAmount(resultsetdetails.getDouble("RECEIPT_AMOUNT"));
		paDownloadObj.setNewExchangeRate(resultsetdetails.getDouble("PAYMENT_EXCHANGE_RATE"));
		paDownloadObj.setPaymentCurrency(resultsetdetails.getString("PAYMENT_CURRENCY"));
		
		//
		
		paDownloadObj.setFundCurrency(resultsetdetails.getString("FUND_RECD_CURRENCY"));
		paDownloadObj.setDummyAcctCurrency(resultsetdetails.getString("DUMMY_ACCT_CURRENCY"));
		
		//
		paDownloadObj.setAmountInINR(resultsetdetails.getDouble("RECEIPT_AMOUNT_1"));
		paDownloadObj.setLegalEntity(resultsetdetails.getString("LEGAL_ENTITY"));
		paDownloadObj.setBankAccountNumber(resultsetdetails.getString("BANK_ACCOUNT_NO"));
		paDownloadObj.setRemitterName(resultsetdetails.getString("REMITTER_NAME"));
		paDownloadObj.setTargetFxAccountNumber(resultsetdetails.getString("TARGET_FX_ACCOUNT_NO"));
		paDownloadObj.setCustomerName(resultsetdetails.getString("CUSTOMER_NAME"));
		paDownloadObj.setInvoiceNumber(resultsetdetails.getString("INVOICE_NO"));
		paDownloadObj.setInvoiceAllocationAmount(resultsetdetails.getString("INVOICE_ALLOCATION_AMOUNT"));
		//paDownloadObj.setTdsAmount(resultsetdetails.getDouble("TDS_AMOUNT"));
		//paDownloadObj.setTanNumber(resultsetdetails.getString("TAN_NUMBER"));
		paDownloadObj.setChequeDate(resultsetdetails.getDate("CHEQUE_DATE"));
		paDownloadObj.setBankName(resultsetdetails.getString("BANK_NAME"));
		paDownloadObj.setRemarks(resultsetdetails.getString("REMARKS"));
		paDownloadObj.setUploadedOLMId(resultsetdetails.getString("UPLOADED_USER_ID"));
		
		
		
		//add
		
		paDownloadObj.setB2b_b2c(resultsetdetails.getString("DERIVED_SEGMENT"));
		paDownloadObj.setSupportFile(resultsetdetails.getString("SUPPORT_FILE"));	
		paDownloadObj.setCustomerEmailId(resultsetdetails.getString("CUSTOMER_EMAIL_ID"));	
		///add end
		

		
		if(paymentMode.equalsIgnoreCase("CHEQUE")){
			paDownloadObj.setIncomingTransactionRefNumber(resultsetdetails.getString("SOURCE_FX_ACCOUNT_NO"));
			paDownloadObj.setReceiverName(resultsetdetails.getString("SOURCE_FX_ACCOUNT_NAME"));
			paDownloadObj.setRefNo(resultsetdetails.getString("DEPOSIT_CIRCLE"));
			paDownloadObj.setPaymentDetails1(resultsetdetails.getString("ANNOTATION"));
			paDownloadObj.setPaymentDetails2(resultsetdetails.getString("BANK_BRANCH_NAME"));
		}
		else if(paymentMode.equalsIgnoreCase("NEFT")){
			paDownloadObj.setIncomingTransactionRefNumber(resultsetdetails.getString("INCOMING_TRANSACTION_REF_NO"));
			paDownloadObj.setReceiverName(resultsetdetails.getString("RECEIVER_NAME"));
			paDownloadObj.setRefNo(resultsetdetails.getString("REF_NO"));
			paDownloadObj.setPaymentDetails1(resultsetdetails.getString("PAYMENT_DETAILS_1"));
			paDownloadObj.setPaymentDetails2(resultsetdetails.getString("PAYMENT_DETAILS_2"));
		}

		
	//	logger.info("VC_UPLOADED_USER_ID" +resultsetdetails.getString("VC_UPLOADED_USER_ID"));
		row = worksheet.createRow(i);
			 System.out.println("hello baby...........");
			 
			XSSFCell cellA2 = row.createCell((short) 0);
			cellA2.setCellValue(paDownloadObj.getPaymentMode());
			
			XSSFCell cellB2 = row.createCell((short) 1);
			cellB2.setCellValue(paDownloadObj.getRequestID());
			
			//worksheet.autoSizeColumn(1);

			
			XSSFCell cellC2 = row.createCell((short) 2);
			//cellC2.setCellValue(paDownloadObj.getUploadedDate());
			
			CreationHelper createHelper = workbook.getCreationHelper();
			cellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
			cellC2.setCellValue(paDownloadObj.getUploadedDate());
			cellC2.setCellStyle(cellStyle);
			//worksheet.autoSizeColumn(2);
			
			XSSFCell cellD2 = row.createCell((short) 3);
			cellD2.setCellValue(paDownloadObj.getUploadedOLMId());
			
			XSSFCell cellAF2 = row.createCell((short) 4);
			cellAF2.setCellValue(paDownloadObj.getUploadedName());
			
			XSSFCell cellE2 = row.createCell((short) 5);
			cellE2.setCellValue(paDownloadObj.getSourceLOB());
			
			XSSFCell cellF2 = row.createCell((short) 6);
			cellF2.setCellValue(paDownloadObj.getSourceCircle());

			XSSFCell cellG2 = row.createCell((short) 7);
			cellG2.setCellValue(paDownloadObj.getDestinationLOB());

			XSSFCell cellH2 = row.createCell((short) 8);
			cellH2.setCellValue(paDownloadObj.getDestinationCircle());
			
			XSSFCell cellI2 = row.createCell((short) 9);
			cellI2.setCellValue(paDownloadObj.getUtrNumber());
			
			XSSFCell cellJ2 = row.createCell((short) 10);
			cellJ2.setCellValue(paDownloadObj.getIncomingTransactionRefNumber());
			
			XSSFCell cellK2 = row.createCell((short) 11);
			//cellK2.setCellValue(paDownloadObj.getPaymentReceivedDate());
			
			CreationHelper createHelper10 = workbook.getCreationHelper();
			cellStyle.setDataFormat(createHelper10.createDataFormat().getFormat("MM/dd/yyyy"));
			cellK2.setCellValue(paDownloadObj.getPaymentReceivedDate());
			cellK2.setCellStyle(cellStyle);
			//worksheet.autoSizeColumn(10);

			XSSFCell cellL2 = row.createCell((short) 12);
			cellL2.setCellValue(paDownloadObj.getPaymentAmount());
						
			XSSFCell cellM2 = row.createCell((short) 13);
             cellM2.setCellValue(paDownloadObj.getNewExchangeRate());
			
		    XSSFCell cellN2 = row.createCell((short) 14);
			cellN2.setCellValue(paDownloadObj.getFundCurrency());

			//
			
			XSSFCell cellNx2 = row.createCell((short) 15);
			cellNx2.setCellValue(paDownloadObj.getDummyAcctCurrency());
			
			XSSFCell cellNz2 = row.createCell((short) 16);
			cellNz2.setCellValue(paDownloadObj.getPaymentCurrency());
			
			//
			
			XSSFCell cellO2 = row.createCell((short) 17);
			cellO2.setCellValue(paDownloadObj.getAmountInINR());
												
			XSSFCell cellP2 = row.createCell((short) 18);
			cellP2.setCellValue(paDownloadObj.getLegalEntity());

			XSSFCell cellQ2 = row.createCell((short) 19);
			cellQ2.setCellValue(paDownloadObj.getBankAccountNumber());
			
			XSSFCell cellR2 = row.createCell((short) 20);
			cellR2.setCellValue(paDownloadObj.getReceiverName());
			
			XSSFCell cellS2 = row.createCell((short) 21);
			cellS2.setCellValue(paDownloadObj.getRemitterName());
			
			XSSFCell cellT2 = row.createCell((short) 22);
			cellT2.setCellValue(paDownloadObj.getRefNo());
			
			XSSFCell cellU2 = row.createCell((short) 23);
			cellU2.setCellValue(paDownloadObj.getPaymentDetails1());
			
			XSSFCell cellV2 = row.createCell((short) 24);
			cellV2.setCellValue(paDownloadObj.getPaymentDetails2());
			
			XSSFCell cellW2 = row.createCell((short) 25);
			cellW2.setCellValue(paDownloadObj.getTargetFxAccountNumber());
			
			XSSFCell cellX2 = row.createCell((short) 26);
			cellX2.setCellValue(paDownloadObj.getCustomerName());
			
			XSSFCell cellY2 = row.createCell((short) 27);
			cellY2.setCellValue(paDownloadObj.getInvoiceNumber());
			
			XSSFCell cellZ2 = row.createCell((short) 28);
			cellZ2.setCellValue(paDownloadObj.getInvoiceAllocationAmount());
			
			//XSSFCell cellAA2 = row.createCell((short) 27);
			//cellAA2.setCellValue(paDownloadObj.getTdsAmount());
			
			//XSSFCell cellAB2 = row.createCell((short) 28);
		///	cellAB2.setCellValue(paDownloadObj.getTanNumber());
			
			XSSFCell cellAA2 = row.createCell((short) 29);
			//cellAC2.setCellValue(paDownloadObj.getChequeDate());
			
			CreationHelper createHelper29 = workbook.getCreationHelper();
			cellStyle.setDataFormat(createHelper29.createDataFormat().getFormat("MM/dd/yyyy"));
		if(paDownloadObj.getChequeDate()!=null){
			cellAA2.setCellValue(paDownloadObj.getChequeDate());
		}
		else{
			cellAA2.setCellValue("NA");
		}
			cellAA2.setCellStyle(cellStyle);
			//worksheet.autoSizeColumn(28);
			
			XSSFCell cellAB2 = row.createCell((short) 30);
			cellAB2.setCellValue(paDownloadObj.getBankName());
			
			XSSFCell cellAC2 = row.createCell((short) 31);
			cellAC2.setCellValue(paDownloadObj.getRemarks());
			
			XSSFCell cellAD2 = row.createCell((short) 32);
			cellAD2.setCellValue(paDownloadObj.getB2b_b2c());
			
			XSSFCell cellAE2 = row.createCell((short) 33);
			cellAE2.setCellValue(paDownloadObj.getSupportFile());
			
			XSSFCell cellAH2 = row.createCell((short) 34);
			cellAH2.setCellValue(paDownloadObj.getCustomerEmailId());
			//logger.info("i value" +i);
			i++;
			//logger.info("i++ value" +i);

		
		}
	
	
	for(int j=0;j<32;j++){
  		worksheet.autoSizeColumn(j);
	}
	
     }
         else{
            logger.info("resultsetdetails are null for payment advice download");
         }

}
catch(Exception e){
logger.info("exception when getting data for file");
StringWriter errors= new StringWriter();
e.printStackTrace(new PrintWriter(errors));
logger.error(errors);

}
	    try {
			workbook.write(downloadFile);
			    downloadFile.flush();
			    downloadFile.close();
		} catch (IOException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}				  
	    
}

catch(Exception e){
logger.info("main try exception");
StringWriter errors= new StringWriter();
e.printStackTrace(new PrintWriter(errors));
logger.error(errors);	

}

    finally{
		
		if(callableStatement!=null){
		try {
			callableStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
	}
		
		if(resultsetdetails!=null){
			try {
				resultsetdetails.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}
		
		if(connection!=null){
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}
		
		
}
	

return paymentAdvicedownloadObj;


}	
	
	
	public List<ApprovalDetails> BulkApproveAndReject(List<ApprovalDetails> approveUpdateList,ApprovalDetails approveUpdateObj,String roleId) {
		
		final String procedureCall = "{call PAYMENT_ADVICE_PKG.PAYMENT_ADVICE_APPROVE(?,?,?,?,?,?,?,?,?,?)}";
			Connection connection = null;
			List<ApprovalDetails> approveFinalList=new ArrayList<ApprovalDetails>();
			ResultSet resulSetArray=null;
			CallableStatement callableStatement=null;
		  
			try {

				// Get Connection instance from dataSource
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				connection = jdbcTemplate.getDataSource().getConnection();
				
				  StructDescriptor structDescriptor = StructDescriptor.createDescriptor("PAY_ADV_APPROVE_OBJ", connection);

			        STRUCT[] structs = new STRUCT[approveUpdateList.size()];
			        for (int index = 0; index < approveUpdateList.size(); index++)
			        {
			        	ApprovalDetails approveAccountsObj = approveUpdateList.get(index);
			            Object[] params = new Object[3];

			            params[0] = approveAccountsObj.getRequestID();
			            logger.info("requestID:"+approveAccountsObj.getRequestID());
			            
		 	            params[1] = approveAccountsObj.getNotes();
		 	           logger.info("notes"+approveAccountsObj.getNotes());
			            
		 	            params[2] = approveAccountsObj.getRequestStatus();
		 	         logger.info("requeststatus"+approveAccountsObj.getRequestStatus());
			            
	   	                
			            STRUCT struct = new STRUCT(structDescriptor, connection, params);
			          
			            structs[index] = struct;
			        }
			        logger.info("length of struct"+structs.length);
			        
			        ArrayDescriptor desc = ArrayDescriptor.createDescriptor("PAY_ADV_APPROVE_TYPE",connection);
			        
			        ARRAY oracleArray = new ARRAY(desc, connection, structs);


				 callableStatement = connection.prepareCall(procedureCall);
				logger.info("reject reason approvalstatus" +approveUpdateObj.getRejectReason()+"action is"+approveUpdateObj.getApprovalStatus()+approveUpdateObj.getApprovedName()+approveUpdateObj.getApprovedOLMId());
				logger.info("oracle array is " +oracleArray);
				callableStatement.setArray(1, oracleArray);
				callableStatement.setString(2,approveUpdateObj.getApprovalStatus());
				logger.info("approval action is" +approveUpdateObj.getApprovalStatus());
				callableStatement.setString(3,approveUpdateObj.getRejectReason());
				callableStatement.setString(4,approveUpdateObj.getDropDownRejectReason());
				logger.info("dropDownRejectReason is" +approveUpdateObj.getDropDownRejectReason());

				callableStatement.setString(5, approveUpdateObj.getApprovedName());
				callableStatement.setString(6, approveUpdateObj.getApprovedOLMId());
				callableStatement.setString(7, roleId);
				callableStatement.registerOutParameter(8, Types.VARCHAR);
				callableStatement.registerOutParameter(9, Types.VARCHAR);
				callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
				
				callableStatement.executeUpdate(); 

				
				 String errorMsg=callableStatement.getString(9);
				 String errorCode=callableStatement.getString(8);

				 logger.info("ERROR MESSAGE"+errorMsg );
				 logger.info("ERROR CODE:"+errorCode );

		            
		            
		             resulSetArray=(ResultSet) callableStatement.getObject(10);
					logger.info("resulSetArray" +resulSetArray);
					if (resulSetArray == null) 
			        {
						logger.info("DB RETURNING NULL VALUES");
						ApprovalDetails approveFinalObj1 = new ApprovalDetails();
						approveFinalObj1.setErrorMessage(errorMsg);
						approveFinalList.add(approveFinalObj1);
					}
					
					else
					{
						
					   while (resulSetArray.next())
					   {
							ApprovalDetails approveFinalObj = new ApprovalDetails();
							
							logger.info("resulSetArray.getString(REQUEST_ID)" +resulSetArray.getString("REQUEST_ID"));
							logger.info("resulSetArray.getString(REQUEST_STATUS)" +resulSetArray.getString("REQUEST_STATUS"));
							approveFinalObj.setRequestID(resulSetArray.getLong("REQUEST_ID"));
							//approveFinalObj.setB2b_b2c(resulSetArray.getString("B2B_B2C"));
							approveFinalObj.setRequestStatus(resulSetArray.getString("REQUEST_STATUS"));
							approveFinalObj.setAproveRejectEmailId(resulSetArray.getString("USER_EMAIL_ID"));
							approveFinalObj.setTotalRecords(resulSetArray.getInt("TOTAL_RECORDS"));
							approveFinalObj.setTotalAmount(resulSetArray.getDouble("TOTAL_AMOUNT"));
							approveFinalObj.setRejectReason(resulSetArray.getString("REJECT_REASON"));
							//approveFinalObj.setDropDownRejectReason(resulSetArray.getString("REJECT_REASON_DROP_DOWN"));
						 
							approveFinalList.add(approveFinalObj);
							
					}
				}
					logger.info("BulkApproveAndReject executed @daoImpl");
			          
				
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);

			}
			catch (Exception e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);

			}finally {

				
				
				if (callableStatement != null){
					try {
						callableStatement.close();
					} catch (SQLException e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
					}
				}
				
				if (resulSetArray != null){
					try {
						resulSetArray.close();
					} catch (SQLException e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
					}
				}
				
				
				if (connection != null){
					try {
						connection.close();
					} catch (SQLException e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
					}
				}
			}
			return approveFinalList;
			
		}

	
	
	
//APPROVE
public ApprovalDetails exchangeRateUpdate(List<ApprovalDetails> updateRecordsObjList,ApprovalDetails exchangeRateDetailsObj) {
	
	final String procedureCall = "{call PAYMENT_ADVICE_PKG.PAY_ADV_EXCHG_RATE_UPD_PROC(?,?,?,?,?)}";
		Connection connection = null;
		List<ApprovalDetails> approveFinalList=new ArrayList<ApprovalDetails>();
		ApprovalDetails exchangeRateResultObj=new ApprovalDetails();
		CallableStatement callableStatement=null;
	  
		try {

			// Get Connection instance from dataSource
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			
			  StructDescriptor structDescriptor = StructDescriptor.createDescriptor("PAY_ADV_EXCHG_RATE_UPD_OBJ", connection);

		        STRUCT[] structs = new STRUCT[updateRecordsObjList.size()];
		        for (int index = 0; index < updateRecordsObjList.size(); index++)
		        {
		        	ApprovalDetails exchangeRateDetailsObj2 = updateRecordsObjList.get(index);
		            Object[] params = new Object[3];

		            params[0] = exchangeRateDetailsObj2.getRequestID();
		            logger.info("requestID:"+exchangeRateDetailsObj2.getRequestID());
		            
	 	            params[1] = exchangeRateDetailsObj2.getUtrNumber();
	 	           logger.info("utr no"+exchangeRateDetailsObj2.getUtrNumber());
		            
	 	            params[2] = exchangeRateDetailsObj2.getNewExchangeRate();
	 	         logger.info("exchangerate"+exchangeRateDetailsObj2.getNewExchangeRate());
		            
	 	           /* params[3] = approveAccountsObj.getRequestStatus();
	 	          logger.info("requestStatus:"+approveAccountsObj.getRequestStatus());*/
		            
   	                
		            STRUCT struct = new STRUCT(structDescriptor, connection, params);
		          
		            structs[index] = struct;
		        }
		        logger.info("length of struct in exchange rate update"+structs.length);
		        
		        ArrayDescriptor desc = ArrayDescriptor.createDescriptor("PAY_ADV_EXCHG_RATE_UPD_TYPE",connection);
		        
		        ARRAY oracleArray = new ARRAY(desc, connection, structs);


			 callableStatement = connection.prepareCall(procedureCall);
			logger.info("change who and sesssion id" +exchangeRateDetailsObj.getApprovedOLMId()+""+exchangeRateDetailsObj.getSessionId());
			callableStatement.setArray(1, oracleArray);
			callableStatement.setString(2,exchangeRateDetailsObj.getApprovedOLMId());
			callableStatement.setString(3,exchangeRateDetailsObj.getSessionId());
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.registerOutParameter(5, Types.VARCHAR);
			
			
			callableStatement.executeUpdate(); 

			
			 String errorMsg=callableStatement.getString(4);
			 String errorCode=callableStatement.getString(5);

			 logger.info("ERROR MESSAGE"+errorMsg );
			 logger.info("ERROR CODE:"+errorCode );
			 exchangeRateResultObj.setErrorMessage(errorMsg);
			 exchangeRateResultObj.setErrorCode(errorCode);		
				logger.info("EXECUTED PROC PAY_ADV_EXCHG_RATE_UPD_PROC");
		          
			
		} catch (SQLException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);

		}
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);

		}finally {

			
			
			if (callableStatement != null){
				try {
					callableStatement.close();
				} catch (SQLException e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			
			
			
			if (connection != null){
				try {
					connection.close();
				} catch (SQLException e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		return exchangeRateResultObj;
		
	}

/*	public ApprovalDetails ApproveAndReject(ApprovalDetails approvalDetailsObj)
	{
		

		ApprovalDetails approvalDetailsResObj = new ApprovalDetails();
		Connection connection=null;
		ResultSet allDetails;
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);
		try {
			
			logger.info("connection" + dataSource1.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource1);
			connection = jdbcTemplate.getDataSource().getConnection();
			connection.setAutoCommit(false);
			
			
			final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.PAYMENT_ADVICE_APPROVE(?,?,?,?,?,?,?)}";

			CallableStatement callableStatement = connection.prepareCall(procedureCall);
			
			ArrayDescriptor des = ArrayDescriptor.createDescriptor(
					"ARRAY_FILE_TABLE", connection);
			Object[] reqIdArray = approvalDetailsObj.getReqIdList()
					.toArray();
			logger.info("Array Element " + reqIdArray[0]);
			ARRAY reqIdArrayToPass = new ARRAY(des, connection,
					reqIdArray);
			

			callableStatement.setArray(1, reqIdArrayToPass);
			callableStatement.setString(2, approvalDetailsObj.getApprovalStatus());
			callableStatement.setString(3, approvalDetailsObj.getRejectReason());
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.registerOutParameter(5, Types.VARCHAR);
			callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(7, Types.VARCHAR);
			callableStatement.executeUpdate();
logger.info("req id and value" +approvalDetailsObj.getReqIdList().get(0)+""+approvalDetailsObj.getApprovalStatus());
			logger.info("callable statements executed in APPROVAL@impl");
		    allDetails = (ResultSet) callableStatement.getObject(6);
		    
			logger.info("4 and 5 and 7" +callableStatement.getString(4)+""+callableStatement.getString(5)+""+callableStatement.getString(7));
			approvalDetailsResObj.setCustomerType(callableStatement.getString(7));
			if (allDetails == null) 
	        {
				logger.info("result set details are null ..DB is returning null values!!!");
			}
			
			else
			{
			  while (allDetails.next()) 
			   {
			

				approvalDetailsResObj.setRequestID(allDetails.getInt("I_REQUEST_ID"));
				approvalDetailsResObj.setStatus(allDetails.getInt("I_STATUS"));
				approvalDetailsResObj.setUploadedDate(allDetails.getDate("DT_UPLOADED_DATE"));
				approvalDetailsResObj.setRequestID(allDetails.getInt("I_REQUEST_ID"));
				approvalDetailsResObj.setUploadedDate(allDetails.getDate("DT_UPLOADED_DATE"));
				approvalDetailsResObj.setUploadedName(allDetails.getString("VC_UPLOADED_USER_NAME"));
				approvalDetailsResObj.setSourceLOB(allDetails.getString("VC_SOURCE_LOB"));
				approvalDetailsResObj.setDestinationLOB(allDetails.getString("VC_DESTINATION_LOB"));
			//	approvalDetailsResObj.setBankAccountNumber(allDetails.getString("VC_BANK_ACCOUNT_NUMBER"));
				approvalDetailsResObj.setTotalTargetAccounts(allDetails.getInt("I_TOTAL_TARGET_ACCOUNTS"));
				approvalDetailsResObj.setTotalAmount(allDetails.getInt("I_TOTAL_AMOUNT"));
				approvalDetailsResObj.setPaymentCurrency(allDetails.getString("VC_PAYMENT_CURRENCY"));
				approvalDetailsResObj.setAmountInINR(allDetails.getInt("I_AMOUNT_IN_INR"));
				transactionManager.commit(status);
				connection.commit();
			}
		  }
			
			logger.info("all details set");
			
		} 
		catch (SQLException e) 
	    {
		e.printStackTrace();
		logger.info("Sql Exception in catch:"+ e.getMessage());
		return null;
	    }
	   catch(Exception e)
	    {
		e.printStackTrace();
		logger.info("Exception in catch:"+ e.getMessage());
		return null;
	    }
	           finally{
	        	   if(connection!=null){
	        	   try {
	        		   connection.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
	        	   }
	           }

		return approvalDetailsResObj;
	}*/
//APPROVE..../

	/*
	//REJCET
	public ApprovalDetails Reject(ApprovalDetails approvalDetailsObj)
	{
		

		ApprovalDetails approvalDetailsResObj = new ApprovalDetails();
		Connection connection=null;
		ResultSet allDetails;
		try {
			logger.info("entered daoimpl @getApprovalDetails");
			logger.info("connection" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.PAYMENT_ADVICE_APPROVE(?,?,?,?,?,?)}";

			CallableStatement callableStatement = connection.prepareCall(procedureCall);

			callableStatement.setInt(1, approvalDetailsObj.getRequestID());
			callableStatement.setString(2, approvalDetailsObj.getApprovalStatus());
			callableStatement.setString(3, approvalDetailsObj.getApprovalStatus());
			callableStatement.registerOutParameter(4, Types.CHAR);
			callableStatement.registerOutParameter(5, Types.CHAR);
			callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
			callableStatement.executeUpdate();

			logger.info("callable statements executed in REJECT@impl");
		    allDetails = (ResultSet) callableStatement.getObject(6);
			
			if (allDetails == null) 
	        {
				logger.info("result set details are null ..DB is returning null values!!!");
			}
			
			else
			{
			  while (allDetails.next()) 
			   {
			

				  approvalDetailsResObj.setRequestID(allDetails.getInt("I_REQUEST_ID"));
					approvalDetailsResObj.setStatus(allDetails.getInt("I_STATUS"));
					approvalDetailsResObj.setUploadedDate(allDetails.getDate("DT_UPLOADED_DATE"));
				approvalDetailsResObj.setRequestID(allDetails.getInt("I_REQUEST_ID"));
				approvalDetailsResObj.setUploadedDate(allDetails.getDate("DT_UPLOADED_DATE"));
				approvalDetailsResObj.setUploadedName(allDetails.getString("VC_UPLOADED_USER_NAME"));
				approvalDetailsResObj.setSourceLOB(allDetails.getString("VC_SOURCE_LOB"));
				approvalDetailsResObj.setDestinationLOB(allDetails.getString("VC_DESTINATION_LOB"));
			//	approvalDetailsResObj.setBankAccountNumber(allDetails.getString("VC_BANK_ACCOUNT_NUMBER"));
				approvalDetailsResObj.setTotalTargetAccounts(allDetails.getInt("I_TOTAL_TARGET_ACCOUNTS"));
				approvalDetailsResObj.setTotalAmount(allDetails.getInt("I_TOTAL_AMOUNT"));
				approvalDetailsResObj.setPaymentCurrency(allDetails.getString("VC_PAYMENT_CURRENCY"));
				approvalDetailsResObj.setAmountInINR(allDetails.getInt("I_AMOUNT_IN_INR"));
				
			}
		  }
			
			logger.info("all details set");
			
		} 
		catch (SQLException e) 
	    {
		e.printStackTrace();
		logger.info("Sql Exception in catch:"+ e.getMessage());
		return null;
	    }
	   catch(Exception e)
	    {
		e.printStackTrace();
		logger.info("Exception in catch:"+ e.getMessage());
		return null;
	    }
	           finally{
	        	   if(connection!=null){
	        	   try {
	        		   connection.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
	        	   }
	           }

		return approvalDetailsResObj;
	}
//REJECT..../
	
	

*/
	
	

	public String getCustomerType(Long requestId)
	{
		
		Connection connection=null;
		String customerType=null;
		CallableStatement callableStatement=null;
		try {
			logger.info("entered daoimpl @getCustomerType");
			//logger.info("connection" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			final String procedureCall = "{call ACE_CAD_PAYMENT_ADVICE.Customer_Type_Check(?,?)}";

			 callableStatement = connection.prepareCall(procedureCall);

			callableStatement.setLong(1, requestId);
			callableStatement.registerOutParameter(2, Types.CHAR);
			callableStatement.executeUpdate();

			logger.info("callable statements executed in getCustomerType@impl");

		 customerType=callableStatement.getString(2);
		 logger.info("customer type in daoImpl" +customerType);
		}
			
	   catch(Exception e)
	    {
		   StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		logger.info("Exception in catch:"+ e.getMessage());
		return null;
	    }
	           finally{

					
					
					if (callableStatement != null){
						try {
							callableStatement.close();
						} catch (SQLException e) {
							StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							logger.error(errors);
						}
					}
					
					if (connection != null){
						try {
							connection.close();
						} catch (SQLException e) {
							StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							logger.error(errors);
						}
					}
				}

		return customerType;
	}

	public String getApproverEmailId(String userId)
	{
		CallableStatement callableStatement=null;
		Connection connection=null;
		String approverEmailid=null;
		try {
			logger.info("entered daoimpl @getApproverEmailId");
			//logger.info("connection" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			final String procedureCall = "{call GET_PA_APPROVER_EMAIL_ID(?,?)}";

			 callableStatement = connection.prepareCall(procedureCall);

			callableStatement.setString(1, userId);
			callableStatement.registerOutParameter(2, Types.VARCHAR);
			callableStatement.executeUpdate();

			logger.info("callable statements executed in getApproverEmailid@impl");

			approverEmailid=callableStatement.getString(2);
			logger.info("callable statement is" +callableStatement);
		 logger.info("approver EmailId" +approverEmailid);
		}
			
	   catch(Exception e)
	    {
		   StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		logger.info("Exception in catch:"+ e.getMessage());
		return null;
	    }
	           finally{

					
					
					if (callableStatement != null){
						try {
							callableStatement.close();
						} catch (SQLException e) {
							StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							logger.error(errors);
						}
					}
					
					
					if (connection != null){
						try {
							connection.close();
						} catch (SQLException e) {
							StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							logger.error(errors);
						}
					}
				}

		return approverEmailid;
	}	



public List<ApprovalDetails> getUTRDetailsRecords(Long requestId)
{
	

	List<ApprovalDetails> UtrDetailsRecordsList = new ArrayList<ApprovalDetails>();
	Connection connection=null;
	CallableStatement callableStatement=null;
	ResultSet allUTRDetails=null;
	
	try {
		logger.info("entered daoimpl @getUTRDetails");
		//logger.info("connection" + dataSource.getConnection());
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
		final String procedureCall = "{call PAYMENT_ADVICE_PKG.get_UTR_details(?,?,?,?)}";

		 callableStatement = connection.prepareCall(procedureCall);

		callableStatement.setLong(1, requestId);
		
		callableStatement.registerOutParameter(2, Types.CHAR);
		callableStatement.registerOutParameter(3, Types.CHAR);
		
		callableStatement.registerOutParameter(4, OracleTypes.CURSOR);
		
		callableStatement.executeUpdate();

		logger.info("callable statements executed in getUTRDetails@impl");

		
		
		allUTRDetails = (ResultSet) callableStatement.getObject(4);
		
		if (allUTRDetails == null) 
        {
			logger.info("result set details are null ..DB is returning null values!!!");    
             
		}
		
		else
		{
		  while (allUTRDetails.next()) 
		   {
			ApprovalDetails utrDetailsObj = new ApprovalDetails();
			utrDetailsObj.setUtrNumber(allUTRDetails.getString("UTR_CHQ_NUMBER"));
			//utrDetailsObj.setFxAccountNumber(allUTRDetails.getString("FX_ACCOUNT_NO"));
			//utrDetailsObj.setInvoiceNumber(allUTRDetails.getString("INVOICE_NO"));
			//utrDetailsObj.setOrig_tracking_id(allUTRDetails.getInt("REV_ORIG_TRACKING_ID"));
			
			utrDetailsObj.setNewExchangeRate(allUTRDetails.getDouble("PAYMENT_EXCHANGE_RATE"));
			utrDetailsObj.setPaymentAmount(allUTRDetails.getDouble("PAYMENT_AMOUNT"));
			utrDetailsObj.setRevExchangeRate(allUTRDetails.getDouble("REV_EXCHANGE_RATE"));
			utrDetailsObj.setReversalAmt(allUTRDetails.getDouble("REVERSAL_AMOUNT"));
			//utrDetailsObj.setOldExchangeRate(allUTRDetails.getDouble("OLD_EXCHANGE_RATE"));
			//utrDetailsObj.setTdsAmount(allUTRDetails.getDouble("TDS_AMOUNT"));
			//utrDetailsObj.setTanNumber(allUTRDetails.getString("TAN_NUMBER"));
			//utrDetailsObj.setRemarks(allUTRDetails.getString("INPUT_REMARKS"));
			//utrDetailsObj.setRecordId(allUTRDetails.getInt("RECORD_ID"));
			utrDetailsObj.setSource_reversal_currency(allUTRDetails.getString("SOURCE_REVERSAL_CURRENCY"));
			utrDetailsObj.setFx_customer_currency(allUTRDetails.getString("CUSTOMER_CURRENCY"));
			//utrDetailsObj.setPercentChange(allUTRDetails.getString("PERCENT_EXCHANGE_RATE"));
			
           utrDetailsObj.setRequestID(allUTRDetails.getLong("REQUEST_ID"));
           utrDetailsObj.setSubsidiary(allUTRDetails.getString("SUBSIDIARY")); 
			
			UtrDetailsRecordsList.add(utrDetailsObj);
		}
	  }
		/*logger.info("no of rows in the list returned from db::"
				+ ApprovalDetailsList.size());
		if (ApprovalDetailsList.size() != 0) 
		{
			logger.info("no of rows in the list returned from db::"+ ApprovalDetailsList.size());
			for (int i = 0; i < ApprovalDetailsList.size(); i++) 
			{
				ApprovalDetails approval = ApprovalDetailsList.get(i);
				logger.info(" File Id : " + (i + 1) +" "+ approval.getRequestID());
			}
		}
*/

	} 
	catch (SQLException e) 
    {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	logger.info("Sql Exception in catch:"+ e.getMessage());
	return null;
    }
   catch(Exception e)
    {
	   StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	logger.info("Exception in catch:"+ e.getMessage());
	return null;
    }
           finally{

				
				
				if (callableStatement != null){
					try {
						callableStatement.close();
					} catch (SQLException e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
					}
				}
				
				if (allUTRDetails != null){
					try {
						allUTRDetails.close();
					} catch (SQLException e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
					}
				}
				
				
				if (connection != null){
					try {
						connection.close();
					} catch (SQLException e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
					}
				}
			}

	return UtrDetailsRecordsList;
}


public String fetchExchangeRate (String ticketNumber)throws Exception{

	String status="";
	Connection conn=null;
	Integer count=0;
	String sqlExchangeRate="";
	try{
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		logger.info("connect" + "ion:" + dataSource.getConnection());
		System.out.println("before fetching query data");
		conn = jdbcTemplate.getDataSource().getConnection();
        sqlExchangeRate="select count(*) FROM ADVICE_VENDOR_FILES_RECORDS a where a.I_REQUEST_ID="+ticketNumber+" and a.PERCENT_EXCHANGE_RATE >(select to_number(s.PARAMETER_VALUE) FROM SYSTEM_PARAMETERS_APS s where s.PARAMETER_NAME='AdviceExchangeRate')";
		PreparedStatement ps = conn.prepareStatement(sqlExchangeRate);
		ResultSet exRateRecords = ps.executeQuery();
		System.out.println("after fetching exchange rate query result");
		
		if(exRateRecords.next()){
			count = exRateRecords.getInt(1);
			
			 if(count>0)
			    {
			    	status="success";
			    }
			    else{
		        status="failure";
		}
			
			
		}
	   
		if (conn != null && !conn.isClosed()) {
			conn.close();
		}
	}
	catch (SQLException e) {
		throw new RuntimeException(e);
	}


	return status;

}




}
