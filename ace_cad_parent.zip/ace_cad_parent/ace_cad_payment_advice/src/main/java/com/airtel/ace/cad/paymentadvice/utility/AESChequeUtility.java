package com.airtel.ace.cad.paymentadvice.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;

import com.airtel.ace.cad.aesadvice.model.AESAdviceRequest;
import com.airtel.ace.cad.paymentadvice.context.ApplicationContextProvider;
import com.airtel.ace.cad.paymentadvice.dao.AesAdviceDao;
import com.airtel.ace.cad.paymentadvice.model.Transaction;
import com.airtel.ace.cad.paymentadvice.model.UserDetails;
import com.airtel.acecad.bulkupload.dto.FileUploadResult;
import com.airtel.acecad.bulkupload.uploadfile.ExcelReader;
import com.airtel.acecad.model.EMailContent;
import com.airtel.acecad.model.SmtpMailContent;
import com.airtel.acecad.utility.SmtpUtility;


public class AESChequeUtility {
	@Autowired
	ExcelReader excelReader;
	private static Logger logger =LogManager.getLogger("aesChequeUploadLogger");
	private static String paymentAdviceHomePath = System.getenv("PAYMENT_ADVICE_HOME");
	private static String aceCadHomePath = System.getenv("ACE_CAD_HOME");

	/**
	 * @param args
	 */
	public static void releaseLockOnAESDetails(String userId){
		logger.info(" Releasing payment details locked by user id "+userId);
		AesAdviceDao paymentAdviceDAOObj = (AesAdviceDao) ApplicationContextProvider.getApplicationContext().getBean("aesAdviceDaoObj");
		paymentAdviceDAOObj.releaseAllLocks(userId);
		logger.info(" Released payment details locked by user id "+userId);
	}
	public static String getDateTime() {
		Date today = Calendar.getInstance().getTime();
		SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyyHHmmss");
		return formatter.format(today);
	}
	public static String getDateAndTime() {
		Date today = Calendar.getInstance().getTime();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		return formatter.format(today);
	}
	@SuppressWarnings("resource")
	public static String validateSheetName(String fileType,MultipartFile uploadedFile,String sheetName){
		String message = null;
		if(fileType.equalsIgnoreCase("XLS")){
			InputStream excelFileToRead = null;
			HSSFWorkbook wb=null;
			try {
				excelFileToRead = (InputStream)uploadedFile.getInputStream();
				wb = new HSSFWorkbook(excelFileToRead);
				HSSFSheet sheet=wb.getSheet(sheetName);
				if(sheet!=null){
					message="SUCCESS";
				}
				else{
					message="expected sheet \""+sheetName+"\" not found in the file "+uploadedFile.getOriginalFilename()+", please rename the excel sheet and upload ";
					return message;
				}
			}
			catch (FileNotFoundException e) {
				message=e.getLocalizedMessage();
				// TODO Auto-generated catch block
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				return message;
			}catch (IOException e) {
				message=e.getLocalizedMessage();
				logger.info(e.getLocalizedMessage());
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				return message;
			}
			finally{
				if(excelFileToRead!=null){
					try {
						excelFileToRead.close();
					} catch (IOException e) {
						logger.info(e.getLocalizedMessage());
						// TODO Auto-generated catch block
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
					}
				}
			}
		}
		else if(fileType.equalsIgnoreCase("XLSX")){
			InputStream excelFileToRead = null;
			XSSFWorkbook wb = null;
			try {
				excelFileToRead = (InputStream)uploadedFile.getInputStream();
				wb = new XSSFWorkbook(excelFileToRead);
				XSSFSheet sheet=wb.getSheet(sheetName);
				if(sheet!=null){
					message="SUCCESS";
				}
				else{
					message="expected sheet \""+sheetName+"\" not found in the file "+uploadedFile.getOriginalFilename()+", please rename the excel sheet and upload ";
					return message;
				}
			}
			catch (FileNotFoundException e) {
				message=e.getLocalizedMessage();
				// TODO Auto-generated catch block
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				return message;
			}catch (IOException e) {
				message=e.getLocalizedMessage();
				// TODO Auto-generated catch block
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				return message;
			}
			finally{
				if(excelFileToRead!=null){
					try {
						excelFileToRead.close();
					} catch (IOException e) {
						logger.info(e.getLocalizedMessage());
						// TODO Auto-generated catch block
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
					}
				}
			}
		}
		return message;
	}

	@SuppressWarnings("resource")
	public  AESAdviceRequest processFileData
	(AesAdviceDao paymentAdviceDAOObj,String fileType
			,MultipartFile uploadedFile,String sheetName,ArrayList<String> refNumbersArray,
			String userId,MultipartFile paymentAdviceSupportFile,String userName,
			HashMap<String,String> uniqueKeyAndRefNumberMap)
	{
		
		String message = null;				
		AESAdviceRequest paymntAdvRequestObj=new AESAdviceRequest();
	
		FileUploadResult fileUpload =null;

		try{
			logger.info("uniqueKeyAndRefNumberMap in processFileData--->"+uniqueKeyAndRefNumberMap);
			
			//Add Cheque No , Deposit Slip No, amount
			//Change in cartUtr (to be added all values)
			Iterator itr=uniqueKeyAndRefNumberMap.keySet().iterator();
			Set<String> cartUtr=new HashSet<String>();
			String ref=null;
			while(itr.hasNext()){
				ref=String.valueOf(uniqueKeyAndRefNumberMap.get(itr.next())).toUpperCase();
				logger.info("key value --------"+ref);
				cartUtr.add(ref);

			}
			
			logger.info("utrCart->"+cartUtr+"uploadedFile.getOriginalFilename()->"+uploadedFile.getOriginalFilename()+" userId->"+userId);
			
			//Change in readFromExcelfile
			fileUpload=excelReader.readFromExcelfile(uploadedFile.getOriginalFilename(), "AESADV", "UI", userId, "", uploadedFile.getInputStream(), "AESCheque",uniqueKeyAndRefNumberMap,null);
		    
			if(fileUpload.getStatus()==1 &&  (fileUpload.getStatusDescription()!=null && (fileUpload.getStatusDescription().toUpperCase().contains("SUCCESS")))){
      	        
				AESAdviceRequest paymentAdviceRequestObj=new AESAdviceRequest();

				paymentAdviceRequestObj.setRequestId(Integer.valueOf(fileUpload.getFileId()));
				logger.info("request id generated" + paymentAdviceRequestObj.getRequestId());
				paymentAdviceRequestObj.setUploadedUserName(userName);
				paymentAdviceRequestObj.setRenamedUploadedFileName(renameFilename(uploadedFile.getOriginalFilename(),"UPLOAD",paymentAdviceRequestObj.getRequestId()));
				
				if(paymentAdviceSupportFile!=null&&paymentAdviceSupportFile.getOriginalFilename()!=""){
					int lastIndexSupport=paymentAdviceSupportFile.getOriginalFilename().lastIndexOf(".");
					paymentAdviceRequestObj.setOriginalSupportedFileName(paymentAdviceSupportFile.getOriginalFilename());
					paymentAdviceRequestObj.setRenamedSupportedFileName(paymentAdviceSupportFile.getOriginalFilename().replace(paymentAdviceSupportFile.getOriginalFilename().substring(0, lastIndexSupport),"AES_Cheque_WorkFlow_Support_File_"+fileUpload.getFileId()));
					//paymentAdviceRequestObj.setRenamedSupportedFileName(renameFilename(paymentAdviceSupportFile.getOriginalFilename(),"SUPPORT",paymentAdviceRequestObj.getRequestId()));
				}			
			
				Transaction transactionObj=paymentAdviceDAOObj.getDataBaseConnection();

				if(transactionObj!=null&&transactionObj.getErrorCode()!=null&&transactionObj.getErrorCode().equalsIgnoreCase("SUCCESS")){
					//paymentAdviceRequestObj.setPaymentMode(paymentModeType);
					//inserting data in payment advice request fire an update query here  
					transactionObj=paymentAdviceDAOObj.loadAESAdviceRequest(transactionObj, paymentAdviceRequestObj);

				}
				else if(transactionObj!=null&&transactionObj.getErrorCode()!=null&&transactionObj.getErrorCode().equalsIgnoreCase("FAILURE")){
					message=transactionObj.getErrorMessage();
					message="Unable to establish database connection";
					paymntAdvRequestObj.setErrorCode("FAILURE");
					paymntAdvRequestObj.setErrorMessage(message);
					return paymntAdvRequestObj;
				}
				else{
					message=" invalid response received while making database connection";
					paymntAdvRequestObj.setErrorCode("FAILURE");
					paymntAdvRequestObj.setErrorMessage(message);
					return paymntAdvRequestObj;
				}

				String retMessage=transferFileToDestination(uploadedFile, paymentAdviceRequestObj.getRenamedUploadedFileName(), "UPLOAD");
				if(retMessage!=null&&retMessage.equalsIgnoreCase("SUCCESS")){
					if(paymentAdviceRequestObj.getRenamedSupportedFileName()!=null){
						retMessage=transferFileToDestination(paymentAdviceSupportFile, paymentAdviceRequestObj.getRenamedSupportedFileName(), "SUPPORT");
						if(retMessage!=null&&retMessage.equalsIgnoreCase("SUCCESS")){
							message="AES advice request has been raised successfully, request id "+paymentAdviceRequestObj.getRequestId();
							paymntAdvRequestObj.setErrorCode("SUCCESS");
							paymntAdvRequestObj.setErrorMessage(message);
							logger.info("request id with support file" +paymentAdviceRequestObj.getRequestId());
							paymntAdvRequestObj.setRequestId(paymentAdviceRequestObj.getRequestId());
							return paymntAdvRequestObj;
						}
						else if(retMessage!=null&&retMessage.equalsIgnoreCase("FAILURE")){
							message=" unable to save AES advice support file to the server location";
							paymntAdvRequestObj.setErrorCode("FAILURE");
							paymntAdvRequestObj.setErrorMessage(message);
							return paymntAdvRequestObj;
						}
						else{
							paymntAdvRequestObj.setErrorCode("FAILURE");
							paymntAdvRequestObj.setErrorMessage(retMessage);
							return paymntAdvRequestObj;
						}
					}
					message="AES advice request has been raised successfully, request id "+paymentAdviceRequestObj.getRequestId();
					logger.info("request id without support file" +paymentAdviceRequestObj.getRequestId());
					paymntAdvRequestObj.setRequestId(paymentAdviceRequestObj.getRequestId());
					paymntAdvRequestObj.setRenamedSupportedFileName(paymentAdviceRequestObj.getRenamedSupportedFileName());
					paymntAdvRequestObj.setOriginalSupportedFileName(paymentAdviceRequestObj.getOriginalSupportedFileName());
					paymntAdvRequestObj.setOriginalUploadedFileName(paymentAdviceRequestObj.getOriginalUploadedFileName());
					paymntAdvRequestObj.setRenamedUploadedFileName(paymentAdviceRequestObj.getRenamedUploadedFileName());
					paymntAdvRequestObj.setUploadedBy(paymentAdviceRequestObj.getUploadedBy());
					paymntAdvRequestObj.setErrorCode("SUCCESS");
					paymntAdvRequestObj.setErrorMessage(message);
					return paymntAdvRequestObj;
				}
				else if(retMessage!=null&&retMessage.equalsIgnoreCase("FAILURE")){
					message=" unable to save AES advice upload file to the server location";
					paymntAdvRequestObj.setErrorCode("FAILURE");
					paymntAdvRequestObj.setErrorMessage(message);
					return paymntAdvRequestObj;
				}
				else{
					paymntAdvRequestObj.setErrorCode("FAILURE");
					paymntAdvRequestObj.setErrorMessage(retMessage);
					return paymntAdvRequestObj;
				}

			}
			else{
				paymntAdvRequestObj.setErrorCode("FAILURE");
				paymntAdvRequestObj.setErrorMessage(fileUpload.getStatusDescription());
				return paymntAdvRequestObj;
			}
		}
		catch(Exception e)
		{
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		return paymntAdvRequestObj;
	}

	/*public static boolean isRowEmpty(Row row) {
		boolean rowEmpty;
		int emptyCellCount=0;
		//logger.info("Firstcellnum:"+row.getFirstCellNum());
        //logger.info("row.getCell() is:"+row.getCell(row.getFirstCellNum()));
	    for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
	    	//logger.info("c is:"+c);
	    	//logger.info("cell is:"+row.getCell(c));
	        Cell cell = row.getCell(c);
	        //logger.info("c is:"+c);
	        if(cell!=null)
	        cell.setCellType(Cell.CELL_TYPE_STRING);
	        if (cell != null&&cell.getStringCellValue()!=null&&cell.getStringCellValue().length()==0)
	        	emptyCellCount=emptyCellCount+1;
	    }
	    if(row.getPhysicalNumberOfCells()==emptyCellCount){
	    	rowEmpty=true;
	    }
	    else{
	    	rowEmpty=false;
	    }
	    return rowEmpty;
	}*/
	public static boolean isRowEmpty(Row row) {

		boolean rowEmpty;
		int emptyCellCount=0;
		for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
			Cell cell = row.getCell(c);
			//  System.out.println("row value is::"+c);
			/*commented to test exchange_rate garbage value from xlsx file*/
			/* if(cell!=null)
	        cell.setCellType(Cell.CELL_TYPE_STRING);*/

			//COMMENT ABOVE LINES IF NEEDED AFTER TESTING 
			if(cell!=null)
				//  System.out.println("celltypeenum:..." +cell.getCellTypeEnum());
				if(cell.getCellTypeEnum()==CellType.STRING || cell.getCellTypeEnum()==CellType.BLANK)
				{
					if (cell != null&&cell.getStringCellValue()!=null&& cell.getStringCellValue().trim().length()==0)
						emptyCellCount=emptyCellCount+1;
				}
				else if(cell.getCellTypeEnum()==CellType.NUMERIC)
				{
					if (cell != null&&cell.getNumericCellValue()==0)
					{
						emptyCellCount=emptyCellCount+1;
					}
				}

		}


		if(row.getPhysicalNumberOfCells()==emptyCellCount){
			rowEmpty=true;
		}
		else{
			rowEmpty=false;
		}

		return rowEmpty;

	}
	public static String renameFilename(String fileName,String fileType,int requestId){
		String renamedFileName=null;
		int lastIndex=fileName.lastIndexOf(".");
		if(fileType.equalsIgnoreCase("SUPPORT")){
			renamedFileName=fileName.replace(fileName.substring(0, lastIndex),fileName);
		}
		if(fileType.equalsIgnoreCase("UPLOAD")){
			renamedFileName=fileName.replace(fileName.substring(0, lastIndex),fileName);
		}
		logger.info(" Renamed FileName "+renamedFileName);
		return renamedFileName;
	}
	public static String transferFileToDestination(MultipartFile fileName,String renamedFileName,String fileType){
		String message = "FAILURE";
		if(fileType.equalsIgnoreCase("UPLOAD")){
			String transferFile=System.getenv("ACE_CAD_HOME")+File.separator+"UPLOADED_FILES"+File.separator+"AESChequeAllocation"+File.separator+"InputFiles/"+renamedFileName;
			File file = new File(transferFile);
			try {
				fileName.transferTo(file);
				message="SUCCESS";
			} catch (IllegalStateException e) {
				message=" unable to save uploaded file in the server location, reason for the failure is "+e.getLocalizedMessage();
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			} catch (IOException e) {
				message=" unable to save uploaded file in the server location, reason for the failure is "+e.getLocalizedMessage();
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}
		if(fileType.equalsIgnoreCase("SUPPORT")){
			String destination =System.getenv("ACE_CAD_HOME")+File.separator+"UPLOADED_FILES"+File.separator+"AESChequeAllocation"+File.separator+"SupportFiles/"+renamedFileName;
			File file = new File(destination);
			try {
				fileName.transferTo(file);
				message="SUCCESS";
			} catch (IllegalStateException e) {
				message=" unable to save uploaded file in the server location, reason for the failure is "+e.getLocalizedMessage();
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			} catch (IOException e) {
				message=" unable to save uploaded file in the server location, reason for the failure is "+e.getLocalizedMessage();
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}
		return message;
	}
	public static BigDecimal convertToDecimal(float inputVal){
		BigDecimal roundBigDecimalValue = new BigDecimal(inputVal).setScale(4,BigDecimal.ROUND_HALF_UP);
		return roundBigDecimalValue;
	}
	public static EMailContent sendEmailAlert(String fileIdentifier,AesAdviceDao aesAdviceDAOObj,AESAdviceRequest aesAdviceRequestObj,UserDetails userDetailsObj,String alertType){
		EMailContent eMailContentObj=new EMailContent();
		File file=null;
		InputStream inputStream=null;
		Properties props=null;
		if(alertType!=null&&alertType.equalsIgnoreCase("FILE_LEVEL_VALIDATIONS_SUCCESS_ALERT")){
			file=new File(aceCadHomePath+"/Conf/EmailAlertsTemplates/AESAdviceRequestIdConfirmationAlert.properties");
			try {
				inputStream=new FileInputStream(file);
				props=new Properties();
				props.load(inputStream);
				logger.info("requet id in mail body " +aesAdviceRequestObj.getRequestId());
				logger.info("sendEmailAlert file identifier>>" +fileIdentifier);
				if("AESDUMMY".equals(fileIdentifier)){
					logger.info("AESDUMMY sendEmailAlert file identifier>>" +fileIdentifier);
					eMailContentObj.setEmailSubject(props.getProperty("emailSubject").replace("A","AESBankStatement ").replace("X", String.valueOf(aesAdviceRequestObj.getRequestId())));
					eMailContentObj.setEmailBody(props.getProperty("emailBody").replace("A","AESBankStatement").replaceAll("X",  String.valueOf(aesAdviceRequestObj.getRequestId())));

				}	
				
				if("AESDP".equals(fileIdentifier)){
					logger.info("AESDP sendEmailAlert file identifier>>" +fileIdentifier);
					eMailContentObj.setEmailSubject(props.getProperty("emailSubject").replace("A","AESDirectPosting ").replace("X", String.valueOf(aesAdviceRequestObj.getRequestId())));
					eMailContentObj.setEmailBody(props.getProperty("emailBody").replace("A","AESDirectPosting ").replaceAll("X",  String.valueOf(aesAdviceRequestObj.getRequestId())));

				}	
				
				if("AESADV".equals(fileIdentifier)){
					logger.info("AESADV sendEmailAlert file identifier>>" +fileIdentifier);
					eMailContentObj.setEmailSubject(props.getProperty("emailSubject").replace("A","AESAdvice ").replace("X", String.valueOf(aesAdviceRequestObj.getRequestId())));
					eMailContentObj.setEmailBody(props.getProperty("emailBody").replace("A","AESAdvice ").replaceAll("X",  String.valueOf(aesAdviceRequestObj.getRequestId())));

				}	
				logger.info("setEmailSubject>>"+eMailContentObj.getEmailSubject());
				logger.info("setEmailSubject>>"+eMailContentObj.getEmailBody());
				
				eMailContentObj.setEmailHeader(props.getProperty("emailHeader","Dear User"));
				eMailContentObj.setEmailFooter(props.getProperty("emailFooter","Regards,<br>Airtel AESs System."));
				
				//Comment for testing
				eMailContentObj.setSmtpFromAddress("APS_Payment_Advice@airtel.com");

				userDetailsObj=aesAdviceDAOObj.getEmailAddress(userDetailsObj);
				if(userDetailsObj!=null&&userDetailsObj.getErrorCode()!=null&&userDetailsObj.getErrorCode().equalsIgnoreCase("SUCCESS")){

					List<String> emailToList=new ArrayList<String>();
					emailToList.add(userDetailsObj.getEmailAddress());
					eMailContentObj.setEmailToList(emailToList);

					eMailContentObj.setAttachmentRequired(false);

					//SmtpUtility.setLogger(logger);
					SmtpMailContent smtpMailContentObj=SmtpUtility.generateEmailAlert(eMailContentObj);
					eMailContentObj.setErrorCode(smtpMailContentObj.getErrorCode());
					eMailContentObj.setErrorMessage(smtpMailContentObj.getErrorMessage());
					return eMailContentObj;
				}
				else if(userDetailsObj!=null&&userDetailsObj.getErrorCode()!=null&&userDetailsObj.getErrorCode().equalsIgnoreCase("FAILURE")){
					eMailContentObj.setErrorCode(userDetailsObj.getErrorCode());
					eMailContentObj.setErrorMessage(userDetailsObj.getErrorMessage());
					return eMailContentObj;
				}
				else{
					eMailContentObj.setErrorCode("FAILURE");
					eMailContentObj.setErrorMessage("Invalid response received while capturing user email address");
					return eMailContentObj;
				}
			} catch (FileNotFoundException e) {
				//eMailContentObj.setErrorCode("FAILURE");
				//eMailContentObj.setErrorMessage("Unable to sent email alert, reason for the failure is "+e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
			catch (IOException e) {
				//eMailContentObj.setErrorCode("FAILURE");
				//eMailContentObj.setErrorMessage("Unable to sent email alert, reason for the failure is "+e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}

		if(alertType!=null&&alertType.equalsIgnoreCase("SYSTEM_LEVEL_VALIDATIONS_SUCCESS_ALERT")){

		}

		if(alertType!=null&&alertType.equalsIgnoreCase("SYSTEM_LEVEL_VALIDATIONS_FAILURE_ALERT")){

		}

		if(alertType!=null&&alertType.equalsIgnoreCase("APPROVAL_ALERT")){

		}

		if(alertType!=null&&alertType.equalsIgnoreCase("REJECTION_ALERT")){

		}

		if(alertType!=null&&alertType.equalsIgnoreCase("POSTING_CONFIRMATION_ALERT")){

		}
		return eMailContentObj; 
	}
	public static void main(String[] args) {
		/*float convertedValue1=Float.parseFloat("123.00026");
		BigDecimal roundfinalPrice1 = new BigDecimal(convertedValue1).setScale(4,BigDecimal.ROUND_HALF_UP);
		logger.info(" roundfinalPrice"+Float.parseFloat(roundfinalPrice1.toString()));

		float convertedValue2=Float.parseFloat("123.00071");
		BigDecimal roundfinalPrice2 = new BigDecimal(convertedValue2).setScale(4,BigDecimal.ROUND_HALF_UP);
		logger.info(" roundfinalPrice"+Float.parseFloat(roundfinalPrice2.toString()));*/
		try{
			int number = 0;
			//if(number.matches("^[0-9]*$") && number.length() <=10)

			if(number==1)
			{
				logger.info("valid invoice");
			}
			else{
				logger.info("INVALID invoice");
			}

		}

		catch(NumberFormatException e)
		{
			logger.info(e.getLocalizedMessage());
		}
	}




}
