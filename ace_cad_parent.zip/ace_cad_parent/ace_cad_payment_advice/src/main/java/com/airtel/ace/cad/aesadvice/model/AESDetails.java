package com.airtel.ace.cad.aesadvice.model;

import java.util.List;



public class AESDetails {
	private String entityName;
	private String accountNumber;
	private String date;
	private String remitterName;
	private String depositSlipNo;
	private String chequeNo;
	private String amount;
	private String uniCodeIdentifier;
	private String lob;
	private String payment_fx_posting_status;
	private String invoice_no;
	private String account_type;
	private String payment_advice_request_id;
	private String recordSource;
	private String foundIn;
	private String transactionId;
	private String customerName;
	private String receiverName;
	private String acctExtId;
	private String trackingId;
	private String trackingIdServ;
	private String revTrackingId;
	private String revTrackingIdServ;
	private String legalEntity;
	private String annotation;
	private String currencyCode;
	private String particulars;
	private String unAllocateAmmount;
	private String errorCode;
	private String errorMessage;
	private List<AESDetails> paymentDetails;
	private List<AESAdviceLov> paymentAdviceLovList;
	
	
	
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getEntityName() {
		return entityName;
	}
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getRemitterName() {
		return remitterName;
	}
	public void setRemitterName(String remitterName) {
		this.remitterName = remitterName;
	}
	public String getDepositSlipNo() {
		return depositSlipNo;
	}
	public void setDepositSlipNo(String depositSlipNo) {
		this.depositSlipNo = depositSlipNo;
	}
	public String getChequeNo() {
		return chequeNo;
	}
	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getUniCodeIdentifier() {
		return uniCodeIdentifier;
	}
	public void setUniCodeIdentifier(String uniCodeIdentifier) {
		this.uniCodeIdentifier = uniCodeIdentifier;
	}
	public String getParticulars() {
		return particulars;
	}
	public void setParticulars(String particulars) {
		this.particulars = particulars;
	}
	public List<AESAdviceLov> getPaymentAdviceLovList() {
		return paymentAdviceLovList;
	}
	public void setPaymentAdviceLovList(List<AESAdviceLov> paymentAdviceLovList) {
		this.paymentAdviceLovList = paymentAdviceLovList;
	}
	public List<AESDetails> getPaymentDetails() {
		return paymentDetails;
	}
	public void setPaymentDetails(List<AESDetails> paymentDetails) {
		this.paymentDetails = paymentDetails;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getPayment_fx_posting_status() {
		return payment_fx_posting_status;
	}
	public void setPayment_fx_posting_status(String payment_fx_posting_status) {
		this.payment_fx_posting_status = payment_fx_posting_status;
	}
	public String getInvoice_no() {
		return invoice_no;
	}
	public void setInvoice_no(String invoice_no) {
		this.invoice_no = invoice_no;
	}
	public String getAccount_type() {
		return account_type;
	}
	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}
	public String getPayment_advice_request_id() {
		return payment_advice_request_id;
	}
	public void setPayment_advice_request_id(String payment_advice_request_id) {
		this.payment_advice_request_id = payment_advice_request_id;
	}
	public String getRecordSource() {
		return recordSource;
	}
	public void setRecordSource(String recordSource) {
		this.recordSource = recordSource;
	}
	public String getFoundIn() {
		return foundIn;
	}
	public void setFoundIn(String foundIn) {
		this.foundIn = foundIn;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getReceiverName() {
		return receiverName;
	}
	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}
	public String getAcctExtId() {
		return acctExtId;
	}
	public void setAcctExtId(String acctExtId) {
		this.acctExtId = acctExtId;
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	public String getTrackingIdServ() {
		return trackingIdServ;
	}
	public void setTrackingIdServ(String trackingIdServ) {
		this.trackingIdServ = trackingIdServ;
	}
	public String getRevTrackingId() {
		return revTrackingId;
	}
	public void setRevTrackingId(String revTrackingId) {
		this.revTrackingId = revTrackingId;
	}
	public String getRevTrackingIdServ() {
		return revTrackingIdServ;
	}
	public void setRevTrackingIdServ(String revTrackingIdServ) {
		this.revTrackingIdServ = revTrackingIdServ;
	}
	public String getAnnotation() {
		return annotation;
	}
	public void setAnnotation(String annotation) {
		this.annotation = annotation;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getLegalEntity() {
		return legalEntity;
	}
	public void setLegalEntity(String legalEntity) {
		this.legalEntity = legalEntity;
	}
	public String getUnAllocateAmmount() {
		return unAllocateAmmount;
	}
	public void setUnAllocateAmmount(String unAllocateAmmount) {
		this.unAllocateAmmount = unAllocateAmmount;
	}
	
		
 
	

}
