package com.airtel.ace.cad.paymentadvice.dao;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.acecad.bulkupload.model.FileDetails;
import com.acecad.bulkupload.model.PaymentTransferDTO;
import com.acecad.bulkupload.model.UserEmailDetails;
import com.airtel.ace.cad.aesadvice.model.AESFileDetails;
import com.airtel.ace.cad.aesadvice.model.AESFileStatus;
import com.airtel.ace.cad.aesadvice.model.AESVendorFileRecords;
import com.airtel.acecad.bulkupload.util.NamedParameterStatement;

import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;



public class AESApprovalDAOImpl implements AESApprovalDAO {
	@Autowired
	DataSource dataSource;

	@Autowired
	private PlatformTransactionManager transactionManager;

	private static Logger log = LogManager.getLogger("aesAdviceApprovalLogger");
	//private static String paymentAdviceHomePath = System.getenv("PAYMENT_ADVICE_HOME");
	private String homePath=System.getenv("ACE_CAD_HOME");
	
	/*public AESFileStatus getFilesApprove(int page) {
		DecimalFormat dfa = new DecimalFormat("#");
		dfa.setMaximumFractionDigits(8);
		log.info("START : in getFileStatusAPS");
		List<AESFileDetails> fileStatusApsList = new ArrayList<AESFileDetails>();
		AESFileStatus fileStatusDTO = new AESFileStatus();
		NamedParameterStatement namedParameter = null;
		int totalRecords=0;
		int totalPages =0,recordsPerPage=10;
		String totRecordsQuery = "select count(*) from(select q.*,RowNum r from ( select  f.I_REQUEST_ID,f.ORIGINAL_FILE_NAME,f.total_amount,f.TOTAL_RECORDS,f.user_id,f.UPLOADED_DATE,UPPER(u.user_name) from ADVICE_REQUEST_STATUS_APS f INNER JOIN AES_ADVICE_DP_FILES_RECORDS s on f.I_REQUEST_ID = s.TICKET_ID AND F.STATUS_CODE=5 AND DERIVED_B2B_B2C IS NOT NULL LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_id) )q)";
		log.info(totRecordsQuery);
		Connection conn = null;

		try{
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			log.info("connect" + "ion:" + dataSource.getConnection());
			conn = jdbcTemplate.getDataSource().getConnection();
			PreparedStatement psTotalRecords = conn.prepareStatement(totRecordsQuery);
			ResultSet rsTotalRecords = psTotalRecords.executeQuery();
			if(rsTotalRecords.next()){
				totalRecords = rsTotalRecords.getInt(1);
			}
			psTotalRecords.close();
			rsTotalRecords.close();
			if(totalRecords%recordsPerPage ==0){
				totalPages = totalRecords/recordsPerPage;
			}else{
				totalPages = (totalRecords/recordsPerPage)+1;
			}
			log.info("Total Pages are "+totalPages);

			fileStatusDTO.setTotalPages(totalPages);
			fileStatusDTO.setTotalResults(totalRecords);
			ResultSet rs= null;
			int count = 0;
			StringBuffer sb = new StringBuffer("select * from (select q.*,RowNum r from (  select  f.I_REQUEST_ID,f.ORIGINAL_FILE_NAME,f.total_amount,f.TOTAL_RECORDS,f.user_id,f.UPLOADED_DATE,UPPER(u.user_name) from ADVICE_REQUEST_STATUS_APS f INNER JOIN AES_ADVICE_DP_FILES_RECORDS s on f.I_REQUEST_ID = s.TICKET_ID AND F.STATUS_CODE=5 AND DERIVED_B2B_B2C IS NOT NULL LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_id) )q)where r  between "+(((page-1)*recordsPerPage)+1) +" AND "+(page*recordsPerPage));
			log.info(sb);
			try {

				conn = new JdbcTemplate(dataSource).getDataSource().getConnection();
				conn.setAutoCommit(false);
			} catch (Exception e) {

			}
			try {

				if (conn != null) {

					namedParameter = new NamedParameterStatement(conn, sb.toString());
					rs = namedParameter.executeQuery();

					try {

						while (rs.next()) {
							AESFileDetails fileStatusAps = new AESFileDetails();
							fileStatusAps.setFileId(rs.getInt(1));
							
							String fileName = rs.getString(2);
							fileStatusAps.setFilePath(fileName.substring(fileName.lastIndexOf("/")+1, fileName.length()));
							String fileNameFinal = fileName.substring(fileName.lastIndexOf("/")+1, fileName.length());
							
							//String circle = getCircleFromMarketCode(marketCode);
							//fileStatusAps.setCircle(circle);
							fileStatusAps.setSumOfAmount(String.valueOf(dfa.format((Double.parseDouble(String.valueOf(rs.getLong(3))))/100)));
							fileStatusAps.setTotalRecords(rs.getInt(4));
							fileStatusAps.setOlmId(rs.getString(5));
							String date =rs.getString(6);
							DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
							Date startDate = df.parse(date);
							SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm");
							String parsedDate = formatter.format(startDate);
							fileStatusAps.setProcessDate(parsedDate);
							fileStatusAps.setFirstLastName(rs.getString(7));
							fileStatusApsList.add(fileStatusAps);

							count++;
						}
						log.info("count of row from FileStatusAPS-->" + count);
					} catch (Exception e) {
						log.info(e);

					}

				}
			} catch (Exception e) {

			} finally {
				try{
					conn.commit();
					namedParameter.close();
					rs.close();
					conn.close();
				}catch(Exception e){
					log.error(e);
				}
			}
			log.info("END :in method readFileColMstApsData of FileUploadDaoImpl");

		}catch(Exception e){
			log.error(e);
		}
		fileStatusDTO.setFileStatusList(fileStatusApsList);
		fileStatusDTO.setResultPerPage(fileStatusApsList.size());
		return fileStatusDTO;

		}*/
	
	public AESFileDetails getAESChqWorkFlowApprovalDetails(String roleId,AESFileDetails aesFileDetails) throws Exception{		
		Connection conn = null;
		String procedureCall =null;
		int totalRecords=0;
		int totalPages =0;
		String errorcode = null;
		String errorMsg=null;
		boolean chkBoxStatus = false;
		String chkBoxEnabled=null;
		
		CallableStatement callableStatement=null;
		ResultSet aesChqWrkFlowDetails =null;
		List<AESFileDetails> ApprovalDetailsList = new ArrayList<AESFileDetails>();			
	
		try{
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			log.info("connect" + "ion:" + dataSource.getConnection());
			conn = jdbcTemplate.getDataSource().getConnection();
			procedureCall = "{call AIRTL_AES_PAYMENT_DETAILS_PKG.AES_CHQWKFLOW_DETAIL_SEARCH(?,?,?,?,?,?,?,?,?,?,?)}";

			callableStatement = conn.prepareCall(procedureCall);
			
			callableStatement.setInt(1, aesFileDetails.getCurrentPage());
			callableStatement.setString(2, aesFileDetails.getOlmId());
			callableStatement.setString(3, aesFileDetails.getFileId());
			callableStatement.setString(4, aesFileDetails.getFileName());
			callableStatement.setString(5, aesFileDetails.getSearchFromDate());
			callableStatement.setString(6, aesFileDetails.getSearchEndDate());	
			
			callableStatement.registerOutParameter(8, Types.INTEGER);
			callableStatement.registerOutParameter(9, Types.CHAR);
			callableStatement.registerOutParameter(10, Types.CHAR);
			callableStatement.registerOutParameter(11, Types.INTEGER);
			
			callableStatement.registerOutParameter(7, OracleTypes.CURSOR);
			callableStatement.executeUpdate();
			
			totalPages = callableStatement.getInt(8);
			errorcode= callableStatement.getString(9);
			errorMsg= callableStatement.getString(10);
			totalRecords= callableStatement.getInt(11);
			
		
			aesFileDetails.setErrorMsg(errorMsg);
			
			aesChqWrkFlowDetails= (ResultSet) callableStatement.getObject(7);
			
			if(aesChqWrkFlowDetails ==null){
				log.info("result set details are null ..DB is returning null values!!!");
			}else{
				
				 while (aesChqWrkFlowDetails.next())
				 {
					 AESFileDetails aesChqWrkFlowDetails1 = new AESFileDetails();
										 
					 aesChqWrkFlowDetails1.setFileId(aesChqWrkFlowDetails.getString("FILE_ID"));
					 aesChqWrkFlowDetails1.setFileName(aesChqWrkFlowDetails.getString("ORIGINAL_FILE_NAME"));						
					 aesChqWrkFlowDetails1.setProcessDate(aesChqWrkFlowDetails.getString("FILE_UPLOAD_DATE"));												
					 aesChqWrkFlowDetails1.setOlmId(aesChqWrkFlowDetails.getString("VENDOR_USERID"));
					 aesChqWrkFlowDetails1.setFirstLastName(aesChqWrkFlowDetails.getString("USER_NAME"));
					
					 aesChqWrkFlowDetails1.setTotalRecords(aesChqWrkFlowDetails.getInt("TOTAL_RECORDS"));						
					 aesChqWrkFlowDetails1.setSumOfAmount(aesChqWrkFlowDetails.getString("TOTAL_AMOUNT"));						 
					 aesChqWrkFlowDetails1.setAttachedFile(aesChqWrkFlowDetails.getString("ATTACHED_FILE")); 
					 aesChqWrkFlowDetails1.setStatusDescription(aesChqWrkFlowDetails.getString("STATUS"));
					 
					 chkBoxStatus = (aesChqWrkFlowDetails.getString("STATUS")).contains("APPROVAL PENDING");
					 if(chkBoxStatus)
						 chkBoxEnabled ="true";
					 else
						 chkBoxEnabled="false";
					 aesChqWrkFlowDetails1.setCheckBoxEnable(chkBoxEnabled);
					 
				     log.info("File Name===>"+aesChqWrkFlowDetails1.getFileName());
					 ApprovalDetailsList.add(aesChqWrkFlowDetails1);
				   }
				
			 }
		
		}
		catch (SQLException e) {
			throw new RuntimeException(e);
		}finally{
			if(aesChqWrkFlowDetails!=null){
				aesChqWrkFlowDetails.close();
			}
			if(callableStatement!=null)
				callableStatement.close();
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}
		}
		aesFileDetails.setResultPerPage(ApprovalDetailsList.size());
		aesFileDetails.setTotalResults(totalRecords);
		aesFileDetails.setTotalPages(totalPages);
		aesFileDetails.setAesChqWorkFlowDetailsList(ApprovalDetailsList);
		
		return aesFileDetails;
	}
	

	
	public AESFileStatus searchFileAPS(String fileId, String fileName, String fromDate, String endDate,
			int page, String viewName, String olmId) throws Exception {
		Connection con = null;
		DecimalFormat dfa = new DecimalFormat("#");
		dfa.setMaximumFractionDigits(8);
		ResultSet rs=null;
		List<AESFileDetails> fileStatusApsList = new ArrayList<AESFileDetails>();
		int recordsPerPage =10;
		con = new JdbcTemplate(dataSource).getDataSource().getConnection();
		AESFileStatus fileStatusDTO = new AESFileStatus();
		
				String dateCondition;
		if(endDate == null || endDate.equals("")){
			Date date = new Date();
			DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			endDate = formatter.format(date);
		}
		if(fromDate == null || fromDate.equals("")){
			dateCondition = " AND TRUNC(f.UPLOADED_DATE)  <=  to_date('"+endDate+"','dd/MM/yyyy')";
		}
		else{
			dateCondition = " AND TRUNC(f.UPLOADED_DATE)  BETWEEN to_date('"+fromDate+"','dd/MM/yyyy') AND to_date('"+endDate+"','dd/MM/yyyy')";
		}
		String countQuery,dataQuery;
		if(viewName.equalsIgnoreCase("AESApprovals")){
			//countQuery ="select count(*) from (select  f.I_REQUEST_ID,f.ORIGINAL_FILE_NAME,f.total_amount,f.TOTAL_RECORDS,f.user_id,f.UPLOADED_DATE,UPPER(u.user_name) from ADVICE_REQUEST_STATUS_APS f LEFT OUTER JOIN STATUS_MASTER_TABLE_APS s on f.status_code = s.status_code LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_id) where (f.status_code>=1 and f.status_code<=4) AND f.file_identifier IN('AESADV','AESDP')  and UPPER(f.user_id) like '%"+olmId+"%' and f.I_REQUEST_ID like '%"+fileId+"%' and UPPER(f.ORIGINAL_FILE_NAME) like '%"+fileName+"%' "+dateCondition+"  order by f.I_REQUEST_ID desc )";
			countQuery ="select count(*) from (select  f.I_REQUEST_ID,f.ORIGINAL_FILE_NAME,f.total_amount,f.TOTAL_RECORDS,f.user_id,f.UPLOADED_DATE,UPPER(u.user_name) from ADVICE_REQUEST_STATUS_APS f  INNER JOIN AES_ADVICE_DP_FILES_RECORDS s on f.I_REQUEST_ID = s.TICKET_ID AND F.STATUS_CODE=5 AND DERIVED_B2B_B2C IS NOT NULL LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_id) where (F.STATUS_CODE=5) AND f.file_identifier IN('AESADV','AESDP')  and UPPER(f.user_id) like '%"+olmId+"%' and f.I_REQUEST_ID like '%"+fileId+"%' and UPPER(f.ORIGINAL_FILE_NAME) like '%"+fileName+"%' "+dateCondition+"  order by f.I_REQUEST_ID desc )";
			dataQuery = "select * from (select q.*,RowNum r  from (select  f.I_REQUEST_ID,f.ORIGINAL_FILE_NAME,f.total_amount,f.TOTAL_RECORDS,f.user_id,f.UPLOADED_DATE,UPPER(u.user_name) from ADVICE_REQUEST_STATUS_APS f INNER JOIN AES_ADVICE_DP_FILES_RECORDS s on f.I_REQUEST_ID = s.TICKET_ID AND F.STATUS_CODE=5 AND DERIVED_B2B_B2C IS NOT NULL LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_id) where (F.STATUS_CODE=5) AND f.file_identifier IN('AESADV','AESDP') and UPPER(f.user_id) like '%"+olmId.toUpperCase()+"%' and f.I_REQUEST_ID like '%"+fileId+"%' and UPPER(f.ORIGINAL_FILE_NAME) like '%"+fileName+"%'  "+dateCondition+"  order by f.I_REQUEST_ID desc)q )where r  between "+(((page-1)*recordsPerPage)+1) +" AND "+(page*recordsPerPage);
			//dataQuery = "select * from (select q.*,RowNum r  from (select  f.I_REQUEST_ID,f.ORIGINAL_FILE_NAME,f.total_amount,f.TOTAL_RECORDS,f.user_id,f.UPLOADED_DATE,UPPER(u.user_name) from ADVICE_REQUEST_STATUS_APS f LEFT OUTER JOIN STATUS_MASTER_TABLE_APS s on f.status_code = s.status_code LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_id) where (f.status_code>=1 and f.status_code<=4) AND f.file_identifier IN('AESADV','AESDP') and UPPER(f.user_id) like '%"+olmId.toUpperCase()+"%' and f.I_REQUEST_ID like '%"+fileId+"%' and UPPER(f.ORIGINAL_FILE_NAME) like '%"+fileName+"%'  "+dateCondition+"  order by f.I_REQUEST_ID desc)q )where r  between "+(((page-1)*recordsPerPage)+1) +" AND "+(page*recordsPerPage);
			log.info("countQuery==>"+countQuery+"::dataQuery===>"+dataQuery);
		}else{
			countQuery ="select count(*) from (select   f.file_id,f.file_identifier,f.file_path,f.sum_of_amount,f.total_records,f.invalid_count,f.source,f.user_name,f.status,f.error_reason,f.process_date,f.pending_approval_level,f.is_worklist_compliant,s.status_meaning,UPPER(u.user_name),RowNum r from FILE_STATUS_APS f LEFT OUTER JOIN STATUS_MASTER_TABLE_APS s on f.status = s.status_code LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_name) where (f.status>=1 and f.status <=4) AND f.source <> 'SFTP' AND f.file_identifier IN('ADJ','CNR','DNR','DPP','RDJ','RDP','REF','SNR') and UPPER(f.user_name) like '%"+olmId+"%' and f.file_id like '%"+fileId+"%' and UPPER(f.file_path) like '%"+fileName+"%' and UPPER(f.file_identifier)"+dateCondition+"  order by f.file_id desc )";
			dataQuery = "select * from (select q.*,RowNum r  from (select  f.file_id,f.file_identifier,f.file_path,f.sum_of_amount,f.total_records,f.invalid_count,f.source,f.user_name,f.status,f.error_reason,f.process_date,f.pending_approval_level,f.is_worklist_compliant,s.status_meaning,UPPER(u.user_name) from FILE_STATUS_APS f LEFT OUTER JOIN STATUS_MASTER_TABLE_APS s on f.status = s.status_code LEFT OUTER JOIN AIRTL_USER_DETAILS u on UPPER(u.userid) = UPPER(f.user_name) where (f.status>=1 and f.status <=4) AND f.source <> 'SFTP' AND f.file_identifier IN('ADJ','CNR','DNR','DPP','RDJ','RDP','REF','SNR') and UPPER(f.user_name) like '%"+olmId+"%' and f.file_id like '%"+fileId+"%' and UPPER(f.file_path) like '%"+fileName+"%' and UPPER(f.file_identifier)"+dateCondition+"  order by f.file_id)q )where r  between "+(((page-1)*recordsPerPage)+1) +" AND "+(page*recordsPerPage);
		}
		PreparedStatement psTotalRecords = con.prepareStatement(countQuery);
		log.info(dataQuery);
		log.info(countQuery);
		ResultSet rsTotalRecords = psTotalRecords.executeQuery();
		int totalRecords = 0;
		if(rsTotalRecords.next()){
			totalRecords = rsTotalRecords.getInt(1);
		}
		psTotalRecords.close();
		rsTotalRecords.close();
		log.info("Total Records are "+totalRecords);
		int totalPages;
		if(totalRecords%recordsPerPage ==0){
			totalPages = totalRecords/recordsPerPage;
		}else{
			totalPages = (totalRecords/recordsPerPage)+1;
		}
		log.info("here is searchfile totalPages " + totalPages+" page is "+page);
		fileStatusDTO.setTotalPages(totalPages);
		fileStatusDTO.setTotalResults(totalRecords);

		PreparedStatement ps = con.prepareStatement(dataQuery);
		rs = ps.executeQuery();
		while(rs.next()){
			AESFileDetails fileStatusAps = new AESFileDetails();
			fileStatusAps.setFileId((rs.getString(1)));
			String fileName1 = rs.getString(2);
			fileStatusAps.setFilePath(fileName1.substring(fileName1.lastIndexOf("/")+1, fileName1.length()));
			String fileNameFinal = fileName1.substring(fileName1.lastIndexOf("/")+1, fileName1.length());
			
			//String circle = getCircleFromMarketCode(marketCode);
			//fileStatusAps.setCircle(circle);
			fileStatusAps.setSumOfAmount(String.valueOf(dfa.format((Double.parseDouble(String.valueOf(rs.getLong(3))))/100)));
			fileStatusAps.setTotalRecords(rs.getInt(4));
			fileStatusAps.setOlmId(rs.getString(5));
			String date =rs.getString(6);
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
			Date startDate = df.parse(date);
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm");
			String parsedDate = formatter.format(startDate);
			fileStatusAps.setProcessDate(parsedDate);
			fileStatusAps.setFirstLastName(rs.getString(7));
			fileStatusApsList.add(fileStatusAps);

			
}
		fileStatusDTO.setFileStatusList(fileStatusApsList);
		fileStatusDTO.setResultPerPage(fileStatusApsList.size());
		if(con != null){
			ps.close();
			rs.close();
			con.close();
		}
		return fileStatusDTO;
}
	public List<String> getStatusList() throws Exception {
		Connection con = null;
		ResultSet rs=null;
		
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
		
		List<String> statusList = new ArrayList<String>();
		String query = "select distinct STATUS_MEANING from STATUS_MASTER_TABLE_APS where status_meaning IN('In Progress','Approval Pending','Failed','Success','Approved','Rejected','Partial Success')";
		PreparedStatement ps;
		
			ps = con.prepareStatement(query);
		rs = ps.executeQuery();
		while(rs.next()){
			statusList.add(rs.getString(1));
		}
		
		
		log.info(query);
		
		if(con!=null){
			ps.close();
			rs.close();
			con.close();
		
		}
		
		return statusList;
	}
	public HashMap<String, String> readFileTypeList() throws Exception {
		log.info("START :in method readFileIdentifierFromMst of FileUploadDaoImpl");
		NamedParameterStatement namedParameter = null;
		Connection con = null;
		ResultSet rs = null;
		StringBuffer sb = new StringBuffer("select file_identifier,File_Type  from file_identifier_mst_aps where file_identifier IN('DPP','RDP','ADJ','CNR','DNR','RDJ','REF','SNR','RRC')");
		//StringBuffer sb = new StringBuffer("select file_identifier,File_Type  from file_identifier_mst_aps where file_identifier IN('DPP','RDP','ADJ','CNR','DNR','RDJ','REF','SNR','CHQ','EFT','MIS','DIR','REVCHQ','PTF','NONBANK')");

		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
			log.info("connection __________" + con);
		} catch (Exception e) {
			//log.info(e);
			log.info("Connection not established ", e);
		}
		log.info("connection made...");
		HashMap<String,String> fileTypeList = new HashMap<String,String>();
		if (con != null) {
			namedParameter = new NamedParameterStatement(con, sb.toString());
			rs = namedParameter.executeQuery();
			try {
				while (rs.next()) {
					fileTypeList.put(rs.getString(1), rs.getString(2));
				}
			} catch (Exception e) {
				log.info(e);

			}
			finally{
				con.commit();
				rs.close();
				namedParameter.close();
				con.close();
			}
		}


		log.info("END : in method readFileIdentifierFromMst  of FileUploadDaoImpl");
		return fileTypeList;


	}
	
	public Object approveFile(List<String> checkedFileList, String rejectReasonRemarks, String userId,String action, String rejectReasonDropDwn) throws Exception {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		String status = null;
		Connection conn=null;
		log.info("ApproveFile for AESDP AND AESADV");
		String userAction="";
		/*if(action.equals("A"))
		{
			userAction="Approval Required";
		}
		else
		{
			userAction="Reject";
		}*/
		List<String> emptyList = new ArrayList<String>();
		List<FileDetails> approveFinalList=new ArrayList<FileDetails>();
		ResultSet resulSetArray=null;
		Object[] obj =new Object[2];
		CallableStatement callableStatement =null ;
		final String procedureCall = "{call AIRTL_AES_PAYMENT_DETAILS_PKG.getApprovalRejectionDetails(?,?,?,?,?,?,?,?)}";
		try {
			conn = jdbcTemplate.getDataSource().getConnection();
			ArrayDescriptor des = ArrayDescriptor.createDescriptor("ARRAY_FILEID_TABLE", conn);
			//ArrayDescriptor desRemarks = ArrayDescriptor.createDescriptor("P_ARRAY", conn);
			Object[] arrayFileId = checkedFileList.toArray();
			//Object[] arrayRemarks = checkedRemarkList.toArray();
			ARRAY array_to_pass_file = new ARRAY(des, conn, arrayFileId);
			//ARRAY array_to_pass_remarks = new ARRAY(desRemarks, conn, arrayRemarks);
			callableStatement = conn.prepareCall(procedureCall);
			callableStatement.setArray(1, array_to_pass_file);
			callableStatement.setString(2,action );
			callableStatement.setString(3,rejectReasonDropDwn );
			callableStatement.setString(4,rejectReasonRemarks);
			callableStatement.setString(5, userId);
			callableStatement.registerOutParameter(6, Types.VARCHAR);
			callableStatement.registerOutParameter(7, Types.VARCHAR);
			callableStatement.registerOutParameter(8, OracleTypes.CURSOR);
			
			callableStatement.executeUpdate();
			status = callableStatement.getString(6);
			log.info("status in approve proc "+status);
			
			obj[0]=status;
			
			resulSetArray=(ResultSet) callableStatement.getObject(8);
			
			if (resulSetArray == null) 
	        {
				log.info("DB RETURNING NULL VALUES");
				
			}else{
				 while (resulSetArray.next())
				   {
					   FileDetails approveFinalObj = new FileDetails();
						
						log.info("resulSetArray.getString(TICKET_ID)" +resulSetArray.getString("TICKET_ID"));
						log.info("resulSetArray.getString(REQUEST_STATUS)" +resulSetArray.getString("REQUEST_STATUS"));
						approveFinalObj.setFileID(String.valueOf(resulSetArray.getInt("TICKET_ID")));					
						approveFinalObj.setRequestStatus(resulSetArray.getString("REQUEST_STATUS"));
						approveFinalObj.setEmailId(resulSetArray.getString("USER_EMAIL_ID"));
						approveFinalObj.setTotalRecords(resulSetArray.getInt("TOTAL_RECORDS"));
						approveFinalObj.setValidSum(resulSetArray.getDouble("TOTAL_AMOUNT"));
						approveFinalObj.setRejectReason(resulSetArray.getString("REJECT_REASON"));
						approveFinalObj.setRejectedRemarks(resulSetArray.getString("REJECT_REASON_REMARKS"));
					 
						approveFinalList.add(approveFinalObj);
						
				}				 
				 
				  obj[1]=approveFinalList;
				
			}
			
		} catch (Exception e) {
			log.error(e);
		}finally{
			conn.commit();
			if (resulSetArray != null){
				 try {
						resulSetArray.close();
					} catch (SQLException e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						log.error(errors);
					}
				}
			if(callableStatement!=null)
				callableStatement.close();
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}	
			
		}
		//return status;
		return obj;
	}
	
	public AESVendorFileRecords downloadaesChequeWorkFlowFile(String userId,String fileId,String requestFileName){
	ResultSet resultsetdetails = null;
	Connection connection=null;
	CallableStatement callableStatement=null;
	int i=1;
	AESVendorFileRecords aesVendorDownloadObj=new AESVendorFileRecords();	

	try {
	   
	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
	connection = jdbcTemplate.getDataSource().getConnection();
	//proc to be created
	final String procedureCall = "{call AIRTL_AES_PAYMENT_DETAILS_PKG.GET_FILE_RECORDS_DETAILS(?,?,?,?)}";

	callableStatement = connection.prepareCall(procedureCall);
	log.info("File Id To be downloaded for AES Advice Approval==>" +"REQUEST ID" +fileId);
	callableStatement.setString(1, userId);
	callableStatement.setInt(2, Integer.parseInt(fileId));
	callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
	callableStatement.registerOutParameter(4,OracleTypes.VARCHAR);

	callableStatement.executeUpdate();

	String downloadStatus=callableStatement.getString(4);	
	aesVendorDownloadObj.setDownloadStatus(downloadStatus);
	log.info("status @ downloadaesChequeWorkFlowFile==>"+aesVendorDownloadObj.getDownloadStatus());

	resultsetdetails = (ResultSet) callableStatement.getObject(3);

	if (resultsetdetails == null) 
	{
		log.info("Db not returning any values");
	}

	FileOutputStream downloadFile = null;
	try 
	{
		/*if(requestFileName.endsWith(".xls")==true)
			
			requestFileName=requestFileName.replace(".xls",
					"_" +fileId + ".xls");
		
		else if(requestFileName.endsWith(".xlsx")==true)
			requestFileName=requestFileName.replace(".xlsx",
					"_" +fileId + ".xlsx");*/
		
		log.info("requestFileName===>"+requestFileName);
		downloadFile = new FileOutputStream(new File(homePath+ File.separator+"UPLOADED_FILES"+File.separator+"AESChequeAllocation"+File.separator+"InputFiles"+File.separator+requestFileName));
	    log.info("downloadFile path for AES Advice Download===>"+downloadFile);
	 }

	catch (FileNotFoundException e) {
		
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		log.error(errors);
	}

	XSSFWorkbook workbook = new XSSFWorkbook();
	XSSFSheet worksheet = workbook.createSheet("AES Advice");
	XSSFRow row=null;
	row = worksheet.createRow(0);
	XSSFCellStyle cellStyle = workbook.createCellStyle();

	/*Cell cellA1 = row.createCell((short) 0);
	cellA1.setCellValue("Unique ID");

	Cell cellB1 = row.createCell((short) 1);
	cellB1.setCellValue("Cheque No");

	Cell cellC1 = row.createCell((short) 2);
	cellC1.setCellValue("Cheque Date"); 

	Cell cellD1 = row.createCell((short) 3);
	cellD1.setCellValue("Deposit Slip No");		
	
	Cell cellE1 = row.createCell((short) 4);
	cellE1.setCellValue("Deposit Date (MM/DD/YYYY)");
	
	Cell cellF1 = row.createCell((short) 5);
	cellF1.setCellValue("Target FX Account Number");


	Cell cellG1 = row.createCell((short) 6);
	cellG1.setCellValue("Invoice/CSIN Number");

	Cell cellH1 = row.createCell((short) 7);
	cellH1.setCellValue("Invoice Allocation Amount");

	Cell cellI1 = row.createCell((short) 8);
	cellI1.setCellValue("Cheque Amount");
			
	Cell cellJ1 = row.createCell((short) 9);
	cellJ1.setCellValue("Payment Mode");

	Cell cellK1 = row.createCell((short) 10);
	cellK1.setCellValue("Ticket No");

	Cell cellL1 = row.createCell((short) 11);
	cellL1.setCellValue("Ticket Date");

	Cell cellM1 = row.createCell((short) 12);
	cellM1.setCellValue("Request Raised by (OLM ID)");

	Cell cellN1 = row.createCell((short) 13);
	cellN1.setCellValue("Request Raised by (Name)"); 

	Cell cellO1 = row.createCell((short) 14);
	cellO1.setCellValue("Source LOB");

	Cell cellP1 = row.createCell((short) 15);
	cellP1.setCellValue("Source Circle Name");

	Cell cellQ1 = row.createCell((short) 16);
	cellQ1.setCellValue("Destination LOB");

	Cell cellR1 = row.createCell((short) 17);
	cellR1.setCellValue("Destination Circle Name");

	Cell cellS1 = row.createCell((short) 18);
	cellS1.setCellValue("Target Customer Name");
			
	Cell cellT1 = row.createCell((short) 19);
	cellT1.setCellValue("Remitter name");

	Cell cellU1 = row.createCell((short) 20);
	cellU1.setCellValue("Particulars");		
	
	Cell cellV1 = row.createCell((short) 21);
	cellV1.setCellValue("Entity Name");

	Cell cellW1 = row.createCell((short) 22);
	cellW1.setCellValue("Entity Name- Based on the Invoice no");	
	
	Cell cellX1 = row.createCell((short) 23);
	cellX1.setCellValue("CAD Reach Time");*/
	
	Cell cellB1 = row.createCell((short) 0);
	cellB1.setCellValue("Cheque No");

	Cell cellC1 = row.createCell((short) 1);
	cellC1.setCellValue("Cheque Date"); 

	Cell cellD1 = row.createCell((short) 2);
	cellD1.setCellValue("Deposit Slip No");		
	
	Cell cellE1 = row.createCell((short) 3);
	cellE1.setCellValue("Deposit Date (MM/DD/YYYY)");
	
	Cell cellF1 = row.createCell((short) 4);
	cellF1.setCellValue("Target FX Account Number");


	Cell cellG1 = row.createCell((short) 5);
	cellG1.setCellValue("Invoice/CSIN Number");

	Cell cellH1 = row.createCell((short) 6);
	cellH1.setCellValue("Invoice Allocation Amount");

	Cell cellI1 = row.createCell((short) 7);
	cellI1.setCellValue("Cheque Amount");
			
	Cell cellJ1 = row.createCell((short) 8);
	cellJ1.setCellValue("Payment Mode");

	Cell cellK1 = row.createCell((short) 9);
	cellK1.setCellValue("Ticket No");

	Cell cellL1 = row.createCell((short) 10);
	cellL1.setCellValue("Ticket Date");

	Cell cellM1 = row.createCell((short) 11);
	cellM1.setCellValue("Request Raised by (OLM ID)");

	Cell cellN1 = row.createCell((short) 12);
	cellN1.setCellValue("Request Raised by (Name)"); 

	Cell cellO1 = row.createCell((short) 13);
	cellO1.setCellValue("Source LOB");

	Cell cellP1 = row.createCell((short) 14);
	cellP1.setCellValue("Source Circle Name");

	Cell cellQ1 = row.createCell((short) 15);
	cellQ1.setCellValue("Destination LOB");

	Cell cellR1 = row.createCell((short) 16);
	cellR1.setCellValue("Destination Circle Name");

	Cell cellS1 = row.createCell((short) 17);
	cellS1.setCellValue("Target Customer Name");
			
	Cell cellT1 = row.createCell((short) 18);
	cellT1.setCellValue("Remitter name");

	Cell cellU1 = row.createCell((short) 19);
	cellU1.setCellValue("Particulars");		
	
	Cell cellV1 = row.createCell((short) 20);
	cellV1.setCellValue("Entity Name");

	Cell cellW1 = row.createCell((short) 21);
	cellW1.setCellValue("Entity Name- Based on the Invoice no");	
	
	Cell cellX1 = row.createCell((short) 22);
	cellX1.setCellValue("CAD Reach Time");
	
	try{				
	if(resultsetdetails!=null){
		while (resultsetdetails.next()) {
			
			AESVendorFileRecords aesDownloadObj=new AESVendorFileRecords();
			
			aesDownloadObj.setUniCode(resultsetdetails.getString("UNIQUE_ID"));
			aesDownloadObj.setChequeNo(resultsetdetails.getString("CHEQUE_NO"));
			aesDownloadObj.setCheque_date(resultsetdetails.getString("CHEQUE_DATE"));
			aesDownloadObj.setDepositSlipNo(resultsetdetails.getString("DEPOSIT_SLIP_NO"));
			aesDownloadObj.setDeposit_date(resultsetdetails.getString("DEPOSIT_DATE"));
			aesDownloadObj.setAccountNo(resultsetdetails.getString("TARGET_ACCOUNT_NO"));
			aesDownloadObj.setInvoice_no(resultsetdetails.getString("INVOICE_NO"));
			aesDownloadObj.setInvoice_alloaction_amount(resultsetdetails.getString("INVOICE_ALLOCATION_AMOUNT"));
			aesDownloadObj.setBankstatement_cheque_amount(resultsetdetails.getString("BANKSTATEMENT_AMOUNT"));
			aesDownloadObj.setPaymentMode(resultsetdetails.getString("PAYMENT_MODE"));
			aesDownloadObj.setFile_id(resultsetdetails.getString("TICKET_ID"));
			aesDownloadObj.setFile_upload_date(resultsetdetails.getString("TICKET_UPLOAD_DATE"));
			aesDownloadObj.setUploaded_by(resultsetdetails.getString("UPLOADED_BY"));
			aesDownloadObj.setUploadedUserName(resultsetdetails.getString("UPLOADED_BY_NAME"));
			aesDownloadObj.setSource_lob(resultsetdetails.getString("SOURCE_LOB"));
			aesDownloadObj.setSource_circle_name(resultsetdetails.getString("SOURCE_CIRCLE_NAME"));
			aesDownloadObj.setDestination_lob(resultsetdetails.getString("DESTINATION_LOB"));
			aesDownloadObj.setDestination_circle_name(resultsetdetails.getString("DESTINATION_CIRCLE_NAME"));
			aesDownloadObj.setTarget_customer_name(resultsetdetails.getString("TARGET_CUSTOMER_NAME"));
			aesDownloadObj.setRemitterName(resultsetdetails.getString("REMITTER_NAME"));
			aesDownloadObj.setAnnotation(resultsetdetails.getString("ANNOTATION"));
			aesDownloadObj.setEntity_name(resultsetdetails.getString("ENTITY_NAME"));
			aesDownloadObj.setEntity_name_invoice(resultsetdetails.getString("ENTITY_NAME_INVOICE"));
			aesDownloadObj.setCad_reach_time(resultsetdetails.getString("CAD_REACH_TIME"));
			
			row = worksheet.createRow(i);
				 
			//Columns to be mapped after query update in procedure
			
			/*XSSFCell cellA2 = row.createCell((short) 0);
			cellA2.setCellValue(aesDownloadObj.getUniCode());*/
					
			XSSFCell cellB2 = row.createCell((short) 0);
			cellB2.setCellValue(aesDownloadObj.getChequeNo());			
				
			XSSFCell cellC2 = row.createCell((short) 1);
			CreationHelper createHelper = workbook.getCreationHelper();
			cellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
			cellC2.setCellValue(aesDownloadObj.getCheque_date());
			cellC2.setCellStyle(cellStyle);
		
				
			XSSFCell cellD2 = row.createCell((short) 2);
			cellD2.setCellValue(aesDownloadObj.getDepositSlipNo());
			
			XSSFCell cellE2 = row.createCell((short) 3);
			createHelper = workbook.getCreationHelper();
			cellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
			cellE2.setCellValue(aesDownloadObj.getDeposit_date());
			cellE2.setCellStyle(cellStyle);
			
			XSSFCell cellF2 = row.createCell((short) 4);
			cellF2.setCellValue(aesDownloadObj.getAccountNo());
			
			XSSFCell cellG2 = row.createCell((short) 5);
			cellG2.setCellValue(aesDownloadObj.getInvoice_no());
			
			XSSFCell cellH2 = row.createCell((short) 6);
			cellH2.setCellValue(aesDownloadObj.getInvoice_alloaction_amount());
			
			XSSFCell cellI2 = row.createCell((short) 7);
			cellI2.setCellValue(aesDownloadObj.getBankstatement_cheque_amount());
										
			XSSFCell cellJ2 = row.createCell((short) 8);
			cellJ2.setCellValue(aesDownloadObj.getPaymentMode());
			
			XSSFCell cellK2 = row.createCell((short) 9);
			cellK2.setCellValue(aesDownloadObj.getFile_id());
							
			XSSFCell cellL2 = row.createCell((short) 10);
			createHelper = workbook.getCreationHelper();
			cellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
			cellL2.setCellValue(aesDownloadObj.getFile_upload_date());
			cellL2.setCellStyle(cellStyle);
			
			XSSFCell cellM2 = row.createCell((short) 11);
			cellM2.setCellValue(aesDownloadObj.getUploaded_by());
			
			XSSFCell cellN2 = row.createCell((short) 12);
			cellN2.setCellValue(aesDownloadObj.getUploadedUserName());
			
			XSSFCell cellO2 = row.createCell((short) 13);
			cellO2.setCellValue(aesDownloadObj.getSource_lob());
			
			XSSFCell cellP2 = row.createCell((short) 14);
			cellP2.setCellValue(aesDownloadObj.getSource_circle_name());
			
			XSSFCell cellQ2 = row.createCell((short) 15);
			cellQ2.setCellValue(aesDownloadObj.getDestination_lob());
			
			XSSFCell cellR2 = row.createCell((short) 16);
			cellR2.setCellValue(aesDownloadObj.getDestination_circle_name());
			
			XSSFCell cellS2 = row.createCell((short) 17);
			cellS2.setCellValue(aesDownloadObj.getTarget_customer_name());				

			XSSFCell cellT2 = row.createCell((short) 18);
			cellT2.setCellValue(aesDownloadObj.getRemitterName());
				
			XSSFCell cellU2 = row.createCell((short) 19);
			cellU2.setCellValue(aesDownloadObj.getAnnotation());
			
			XSSFCell cellV2 = row.createCell((short) 20);
			cellV2.setCellValue(aesDownloadObj.getEntity_name());
			
			XSSFCell cellW2 = row.createCell((short) 21);
			cellW2.setCellValue(aesDownloadObj.getEntity_name_invoice());
			
			XSSFCell cellX2 = row.createCell((short) 22);
			cellX2.setCellValue(aesDownloadObj.getCad_reach_time());
			
			i++;			
		}
		
		for(int j=0;j<10;j++){
	  		worksheet.autoSizeColumn(j);
		}
		
	  }
	    else{
	        log.info("resultsetdetails are null for aes transfer approval download");
	     }

	}
	catch(Exception e){
	log.info("exception when getting data for file");
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	log.error(errors);

	}
    try {
		workbook.write(downloadFile);
		downloadFile.flush();
		downloadFile.close();
	} catch (IOException e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		log.error(errors);
	}				  
		    
}catch(Exception e){
	log.info("main try exception");
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	log.error(errors);	
}finally{			
		if(callableStatement!=null){
		try {
			callableStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			log.error(errors);
		}
		}
			
	if(resultsetdetails!=null){
		try {
			resultsetdetails.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			log.error(errors);
		}
	}			
	if(connection!=null){
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			log.error(errors);
		}
	}
}
 return aesVendorDownloadObj;
 }	
	
public UserEmailDetails getEmailAddress(String  userId) {
	log.info(" Starting execution of getEmailAddress() method");
	final String procedureCall = "{call AIRTL_AES_PAYMENT_DETAILS_PKG.getUserEmailAddress(?,?,?,?)}";
	Connection connection = null;
	ResultSet paymentAdivceFieldsResultSet = null;
	CallableStatement callableStatement=null;
	UserEmailDetails userDetailsObj = new UserEmailDetails();
	try {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
		log.info(" Database connection has been established successfully !! ");
		callableStatement = connection.prepareCall(procedureCall);
		callableStatement.setString(1,userId);
		callableStatement.registerOutParameter(2, OracleTypes.VARCHAR); 
		callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
		callableStatement.registerOutParameter(4, OracleTypes.VARCHAR);
		callableStatement.executeUpdate();
		log.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
		String emailId=callableStatement.getString(2);
		String errorCode=callableStatement.getString(3);
		String errorMessage=callableStatement.getString(4);
		userDetailsObj.setEmailAddress(emailId);
		userDetailsObj.setErrorCode(errorCode);
		userDetailsObj.setErrorMessage(errorMessage);
		log.info("Email id is" +userDetailsObj.getEmailAddress());
		log.info(" Procedure returned error code "+errorCode+", error message "+errorMessage);
	} catch (SQLException e) {
		userDetailsObj.setErrorCode("FAILURE");
		//userDetailsObj.setErrorMessage("Unable to retreive email address, reason for the failure is "+e.getLocalizedMessage());
		userDetailsObj.setErrorMessage("Unable to retreive email address");

		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		log.error(errors);
	}
	finally {
		if(paymentAdivceFieldsResultSet!=null){
			try {
				paymentAdivceFieldsResultSet.close();
				log.info(" Result set has been closed successfully !! ");
			} catch (SQLException e) {
				log.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				log.error(errors);
			}
		}
		
		if(callableStatement!=null){
			try {
				callableStatement.close();
				log.info(" Callable statement has been closed successfully !! ");
			} catch (SQLException e) {
				log.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				log.error(errors);
			}
		}
		
		if (connection != null){
			try {
				connection.close();
				log.info(" Database connection has been closed successfully !! ");
			} catch (SQLException e) {
				log.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				log.error(errors);
			}
		}
	}
	log.info(" Execution of getEmailAddress() method has been completed");
	return userDetailsObj;
 }	
}

