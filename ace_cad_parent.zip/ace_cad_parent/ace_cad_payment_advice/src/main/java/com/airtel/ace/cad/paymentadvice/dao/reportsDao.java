/*package com.acecad.paymentAdviceApproval.dao;

import java.util.HashMap;
import java.util.List;

import com.acecad.reports.model.reportDetails;

public interface reportsDao {
	
	int getRole(String parentUser);
	
	List<String>  getStatus();
	
	HashMap<Integer, List<reportDetails>> getReportDetails(reportDetails reportDetailsObj,int page);
	
	
}
*/