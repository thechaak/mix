package com.airtel.ace.cad.paymentadvice;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class NewApp {
	
	public static void main(String[] args) {
		
		
		
		
		
	}
	static void FindPairWithoutSorting(){//SingleLoop Less Complexity O(n)
	int	a[]={4,2,1,5,8};
	int sum=6;
	Map<Integer,Integer> mp=new HashMap<Integer,Integer>();
	for(int i=0;i<a.length;i++){
		if(mp.containsKey(sum-a[i])){
			int j=0;
			j=mp.get(sum-a[i]);
			System.out.println("("+a[i]+","+a[j]+")");
		}
		mp.put(a[i],i);
	}
	}
	
	
	static void FindPairWithSorting(){//SingleLoop a little more Complexity O(n Log n)
	int	a[]={4,2,1,5,8};
	Arrays.sort(a);//1 2 4 5 8
	int sum=6;
	int j=a.length-1;
	int i=0;
	while(i<j){
		if(a[i]+a[j]==sum){
			System.out.println("("+a[i]+","+a[j]+")");
		}
		if(a[i]+a[j]<sum){
		i++;
		}else{
		j--;
		}
	}
	}
	
	static void LargestnSmallestnumber(){
		int	a[]={4,2,1,5,8};
		int b[]=a.clone();
		Arrays.sort(b);
		int s=b[0];
		int l=b[b.length-1];
		for(int i=0;i<a.length;i++){
			if(a[i]==s){
			System.out.println("Smallest int:"+s+" ...at location:"+i+1);	
			}else if(a[i]==l){
				System.out.println("largest int:"+l+" ...at location:"+i+1);
			}
		}
	}



}
