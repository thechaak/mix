package com.airtel.ace.cad.paymentadvice.model;
  
public class Circle {
private String circleCode;
private String circleDescription;
private String circleStatus;
public String getCircleCode() {
	return circleCode;
}
public void setCircleCode(String circleCode) {
	this.circleCode = circleCode;
}
public String getCircleDescription() {
	return circleDescription;
}
public void setCircleDescription(String circleDescription) {
	this.circleDescription = circleDescription;
}
public String getCircleStatus() {
	return circleStatus;
}
public void setCircleStatus(String circleStatus) {
	this.circleStatus = circleStatus;
}
}
