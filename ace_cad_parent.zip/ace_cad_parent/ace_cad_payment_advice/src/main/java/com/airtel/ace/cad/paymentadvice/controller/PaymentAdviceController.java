/**
 * 
 */
package com.airtel.ace.cad.paymentadvice.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.acecad.bulkupload.model.FileDetails;
import com.acecad.bulkupload.model.PaymentTransferDTO;
import com.airtel.ace.cad.aesadvice.model.AESAdviceRequest;
import com.airtel.ace.cad.paymentadvice.dao.PaymentAdviceDAO;
import com.airtel.ace.cad.paymentadvice.model.PaymentAdviceLock;
import com.airtel.ace.cad.paymentadvice.model.PaymentAdviceRequest;
import com.airtel.ace.cad.paymentadvice.model.PaymentAdviceTemplate;
import com.airtel.ace.cad.paymentadvice.model.PaymentDetails;
import com.airtel.ace.cad.paymentadvice.model.UserDetails;
import com.airtel.ace.cad.paymentadvice.utility.AESChequeUtility;
import com.airtel.ace.cad.paymentadvice.utility.PaymentAdviceUtility;
import com.airtel.acecad.UtilityJar.ActivityLog;
import com.airtel.acecad.bulkupload.dto.FileUploadResult;
import com.airtel.acecad.bulkupload.uploadfile.ExcelReader;
/*import com.airtel.acecad.model.EMailContent;*/
import com.airtel.acecad.model.EMailContent;
/**
 * @author 587111
 *
 */

@Controller
public class PaymentAdviceController {

	@Autowired
	PaymentAdviceDAO paymentAdviceDAOObj;
	HttpSession session;
	@Autowired
	ActivityLog activityDao;
	@Autowired
	PaymentAdviceUtility paymentAdviceUtility;
	@Autowired
	AESChequeUtility aesChequeUtility;
	@Autowired
	ExcelReader excelReader;
	
	private static Logger logger = LogManager.getLogger("paymentAdviceLogger");
	private String paymentAdviceHomePath = System.getenv("PAYMENT_ADVICE_HOME");

	private String errorFilesPath = System.getenv("ACE_CAD_HOME") + File.separator + "ERRORED_FILES";
	private String uploadWavierFiles = System.getenv("ACE_CAD_HOME") + File.separator + "Wavier_Files" + File.separator
			+ "Input files";
	private String uploadSupportFiles = System.getenv("ACE_CAD_HOME") + File.separator + "Wavier_Files" + File.separator
			+ "Support Files";
	
	
	
	
	/*@Value("${maximumTransactionsAllowedInCart}")
	private String maxTransInCart;
	*/
	/*@Value("${maxiumSizeAllowedForPaymentAdviceSupportFile}")
	private String maxSizeAlldForSupFile;*/
	
	/*@Value("${sheetNameOfTheExcelFile}")
	private String sheetName;
	*/
	
	
	///adding for AES workflow
	
	
	@RequestMapping(value = "/aesDetail")
	public ModelAndView paymentAdviceAESHomePage(HttpServletRequest request,
			HttpServletResponse response) {

		
		
		
		File fileObj=new File(paymentAdviceHomePath+"/Conf/PaymentAdvice.properties");
		InputStream inputStream;
		String maxTransInCart=null;
		String maxSizeAlldForSupFile=null;
		String sheetName=null;
		try {
			inputStream = new FileInputStream(fileObj);
			 Properties properties=new Properties();
			 properties.load(inputStream);	
		
	
			 maxTransInCart=properties.getProperty("maximumTransactionsAllowedInCart");
			 maxSizeAlldForSupFile=properties.getProperty("maxiumSizeAllowedForPaymentAdviceSupportFile");
			 sheetName=properties.getProperty("sheetNameOfTheExcelFile");
		
		}
		catch(Exception e){
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		
		
		
		
		
		
		
		logger.info(" Got an hit to payment advice AES url /paymentAdvice ");
		logger.info(" Loading payment adivce AES home page ..... ");
		ModelAndView modelAndViewObj = new ModelAndView();
		session = request.getSession(true);
		String userId = "NA";
		if (session.getAttribute("userid") != null) {
			userId = session.getAttribute("userid").toString();
			PaymentAdviceUtility.releaseLockOnPaymentDetails(userId);
			logger.info("userId in /paymentAdvice" +userId);
		}

		if (userId != "" && userId != null && userId != "NA") {
			PaymentDetails paymentDetailsObj = paymentAdviceDAOObj
					.getPaymentTypes();
			paymentDetailsObj.setUserId(userId);
			logger.info("  getPayments() method returned, error code "
					+ paymentDetailsObj.getErrorCode() + ",error message "
					+ paymentDetailsObj.getErrorMessage() + " as a respone");

			if (paymentDetailsObj != null
					&& paymentDetailsObj.getErrorCode().equalsIgnoreCase(
							"SUCCESS")) {
				if (paymentDetailsObj.getPaymentTypes() != null
						&& paymentDetailsObj.getPaymentTypes().size() == 0) {
					modelAndViewObj
							.addObject(
									"error",
									"Payment types have been not mapped for the payment advice process, please try after some time !!");
				} else {
					paymentDetailsObj = paymentAdviceDAOObj
							.getPaymentAdviceAllowedForUser(paymentDetailsObj);


					if (paymentDetailsObj != null
							&& paymentDetailsObj.getErrorCode()
									.equalsIgnoreCase("SUCCESS")) {
						if (paymentDetailsObj.getPaymentTypes() != null
								&& paymentDetailsObj.getPaymentAdviceLovList()
										.size() == 0) {
							modelAndViewObj
									.addObject(
											"error",
											"Payment advice types have been not mapped for the user "
													+ paymentDetailsObj
															.getUserId()
													+ ", please map the payment advice types if you are rm or cc !!");
						} else {
							logger.info("paymet lov in controller" +paymentDetailsObj
													.getPaymentAdviceLovList().size());
							modelAndViewObj
									.addObject("paymentAdviceTypes",
											paymentDetailsObj
													.getPaymentAdviceLovList());
							modelAndViewObj.addObject("paymentTypes",
									paymentDetailsObj.getPaymentTypes());
						}
					} else if (paymentDetailsObj != null
							&& paymentDetailsObj.getErrorCode()
									.equalsIgnoreCase("FAILURE")) {
						/*modelAndViewObj.addObject("error",
								paymentDetailsObj.getErrorMessage());*/
						modelAndViewObj.addObject("error",
								"Database Issues");
					} else {
						modelAndViewObj
								.addObject("error",
										"Unexpected response received, Please try after some time ");
					}

				}
			} else if (paymentDetailsObj != null
					&& paymentDetailsObj.getErrorCode().equalsIgnoreCase(
							"FAILURE")) {
				/*modelAndViewObj.addObject("error",
						paymentDetailsObj.getErrorMessage());*/
				modelAndViewObj.addObject("error",
						"Database Issues");
			} else {
				modelAndViewObj
						.addObject("error",
								"Unexpected response received, Please try after some time ");
			}
		} else {
			modelAndViewObj
					.addObject(
							"error",
							"Not able to retreive user id from session, either session has expired or user has not logged in or session has not yet initiated, please close the browser and try again after some time");
		}
		if(maxTransInCart==null||maxSizeAlldForSupFile==""){
			maxTransInCart="5";
		}
		if(maxSizeAlldForSupFile==null||maxSizeAlldForSupFile==""){
			maxSizeAlldForSupFile="21";
		}
		modelAndViewObj.addObject("maxTransInCart",maxTransInCart);
		modelAndViewObj.addObject("maxSizeAlldForSupFile",maxSizeAlldForSupFile);
		
		modelAndViewObj.setViewName("paymentAdviceHome");
		logger.info(" Payment adivce home page has been loaded successfully !!");
		return modelAndViewObj;
	}

	
	
	/////adding end for AES workflow
	
	
	
	
	
	@RequestMapping(value = "/paymentAdvice")
	public ModelAndView paymentAdviceHomePage(HttpServletRequest request,
			HttpServletResponse response) {

		
		
		
		File fileObj=new File(paymentAdviceHomePath+"/Conf/PaymentAdvice.properties");
		InputStream inputStream;
		String maxTransInCart=null;
		String maxSizeAlldForSupFile=null;
		String sheetName=null;
		try {
			inputStream = new FileInputStream(fileObj);
			 Properties properties=new Properties();
			 properties.load(inputStream);	
		
	
			 maxTransInCart=properties.getProperty("maximumTransactionsAllowedInCart");
			 maxSizeAlldForSupFile=properties.getProperty("maxiumSizeAllowedForPaymentAdviceSupportFile");
			 sheetName=properties.getProperty("sheetNameOfTheExcelFile");
		
		}
		catch(Exception e){
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		
		
		
		
		
		
		
		logger.info(" Got an hit to payment advice url /paymentAdvice ");
		logger.info(" Loading payment adivce home page ..... ");
		ModelAndView modelAndViewObj = new ModelAndView();
		session = request.getSession(true);
		String userId = "NA";
		if (session.getAttribute("userid") != null) {
			userId = session.getAttribute("userid").toString();
			PaymentAdviceUtility.releaseLockOnPaymentDetails(userId);
			logger.info("userId in /paymentAdvice" +userId);
		}

		if (userId != "" && userId != null && userId != "NA") {
			PaymentDetails paymentDetailsObj = paymentAdviceDAOObj
					.getPaymentTypes();
			paymentDetailsObj.setUserId(userId);
			/*logger.info("  getPayments() method returned, error code "
					+ paymentDetailsObj.getErrorCode() + ",error message "
					+ paymentDetailsObj.getErrorMessage() + " as a respone");*/

			if (paymentDetailsObj != null
					&& paymentDetailsObj.getErrorCode().equalsIgnoreCase(
							"SUCCESS")) {
				if (paymentDetailsObj.getPaymentTypes() != null
						&& paymentDetailsObj.getPaymentTypes().size() == 0) {
					modelAndViewObj
							.addObject(
									"error",
									"Payment types have been not mapped for the payment advice process, please try after some time !!");
				} else {
					paymentDetailsObj = paymentAdviceDAOObj
							.getPaymentAdviceAllowedForUser(paymentDetailsObj);


					if (paymentDetailsObj != null
							&& paymentDetailsObj.getErrorCode()
									.equalsIgnoreCase("SUCCESS")) {/*
						if (paymentDetailsObj.getPaymentTypes() != null
								&& paymentDetailsObj.getPaymentAdviceLovList()
										.size() == 0) {
							modelAndViewObj
									.addObject(
											"error",
											"Payment advice types have been not mapped for the user "
													+ paymentDetailsObj
															.getUserId()
													+ ", please map the payment advice types if you are rm or cc !!");
						} else {
							logger.info("paymet lov in controller" +paymentDetailsObj
													.getPaymentAdviceLovList().size());
							modelAndViewObj
									.addObject("paymentAdviceTypes",
											paymentDetailsObj
													.getPaymentAdviceLovList());
							modelAndViewObj.addObject("paymentTypes",
									paymentDetailsObj.getPaymentTypes());
						}
					*/} else if (paymentDetailsObj != null
							&& paymentDetailsObj.getErrorCode()
									.equalsIgnoreCase("FAILURE")) {
						/*modelAndViewObj.addObject("error",
								paymentDetailsObj.getErrorMessage());*/
						modelAndViewObj.addObject("error",
								"Database Issues");
					} else {
						modelAndViewObj
								.addObject("error",
										"Unexpected response received, Please try after some time ");
					}

				}
			} else if (paymentDetailsObj != null
					&& paymentDetailsObj.getErrorCode().equalsIgnoreCase(
							"FAILURE")) {
				/*modelAndViewObj.addObject("error",
						paymentDetailsObj.getErrorMessage());*/
				modelAndViewObj.addObject("error",
						"Database Issues");
			} else {
				modelAndViewObj
						.addObject("error",
								"Unexpected response received, Please try after some time ");
			}
		} else {
			modelAndViewObj
					.addObject(
							"error",
							"Not able to retreive user id from session, either session has expired or user has not logged in or session has not yet initiated, please close the browser and try again after some time");
		}
		if(maxTransInCart==null||maxSizeAlldForSupFile==""){
			maxTransInCart="5";
		}
		if(maxSizeAlldForSupFile==null||maxSizeAlldForSupFile==""){
			maxSizeAlldForSupFile="21";
		}
		modelAndViewObj.addObject("maxTransInCart",maxTransInCart);
		modelAndViewObj.addObject("maxSizeAlldForSupFile",maxSizeAlldForSupFile);
		
		modelAndViewObj.setViewName("paymentAdviceHome");
		logger.info(" Payment adivce home page has been loaded successfully !!");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/getPaymentDetails", method = RequestMethod.POST)
	public @ResponseBody PaymentDetails getPaymentDetails(
			HttpServletRequest request, HttpServletResponse response) {

		logger.info(" Got an hit to url /getPaymentDetails");
		logger.info(" Calling  getPaymentDetails() method to retreive payment details for search criteria ");

		PaymentDetails paymentDetailsObj = new PaymentDetails();
try{
		String paymentMode = request.getParameter("paymentMode");
		if (paymentMode != null && paymentMode.equalsIgnoreCase("CHEQUE")) {
			String chequeNo = request.getParameter("chequeNo");
			String bankAccountNo = request.getParameter("bankAccountNo");
			paymentDetailsObj.setPaymentMode(paymentMode);
			paymentDetailsObj.setRefNumber(chequeNo);
			paymentDetailsObj.setCustomerBankAccountNum(bankAccountNo);
			paymentDetailsObj = paymentAdviceDAOObj
					.getPaymentDetails(paymentDetailsObj);
		} else if (paymentMode != null && paymentMode.equalsIgnoreCase("NEFT")) {
			String utrNo = request.getParameter("utrNo");
			String bankAccountNo = request.getParameter("eCollectNo");
			paymentDetailsObj.setPaymentMode(paymentMode);
			paymentDetailsObj.setRefNumber(utrNo);
			paymentDetailsObj.setCustomerBankAccountNum(bankAccountNo);
			paymentDetailsObj = paymentAdviceDAOObj
					.getPaymentDetails(paymentDetailsObj);
		} else {
			paymentDetailsObj.setErrorCode("FAILURE");
			paymentDetailsObj
					.setErrorCode("Unable to process your request, invalid payment type : "
							+ paymentMode + " has been captured");
		}
}catch(Exception e){
	logger.info(e.getLocalizedMessage());
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);
}
		return paymentDetailsObj;
	}
	
	
	@RequestMapping(value = "/viewPABulkUpload")
	public ModelAndView PABulkHomePage(HttpServletRequest request,
			HttpServletResponse response) 
	{
		logger.info("Enterd in to PA Bulk Upload view");
		ModelAndView modelAndViewObj = new ModelAndView();
		String maxTransInCart="5";
		
		//modelAndViewObj.addObject("maxTransInCart",maxTransInCart);
		modelAndViewObj.setViewName("PAbulk");
		logger.info("Ended in to PA Bulk upload view ");
		return modelAndViewObj;
		
		
	}

	
	@RequestMapping(value = "/PABulkUpload", method = RequestMethod.POST)
	/*public ModelAndView PABulkFileUpload(HttpServletRequest request,
			HttpServletResponse response,@RequestParam("file") MultipartFile paymentAdviceBulkFile) {
		//@RequestParam("paymentAdviceFile") MultipartFile paymentAdviceFile
	}*/
	public ModelAndView  PABulkFileUpload(HttpServletRequest request,
			HttpServletResponse response,@RequestParam("paymentAdviceBulkSupportFile") MultipartFile paymentAdviceBulkSupportFile,@RequestParam("paymentAdviceBulkFile") MultipartFile paymentAdviceBulkFile) {
			
		File fileObj=new File(paymentAdviceHomePath+"/Conf/PaymentAdvice.properties");
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		String userName = session.getAttribute("uname").toString();
		String supportFileName =null;
		String sheetName=null;
		String fileFormatValidation = "FAILURE";
		ModelAndView modelAndViewObj = new ModelAndView();
		String fileName="";
		String retMessage="";
		String paymentAdviceProcess=null;
		String maxSizeAlldForSupFile=null;
		
		InputStream inputStream = null;
		InputStream supportInputStream = null;
		
		String maxTransInCart=null;
		
		PaymentDetails paymentDetailsObj = new PaymentDetails();
		
		Long SNo=0l;
		
		float maxSizeAllowed,paymentAdviceSupportFileInBytes, paymentAdviceSupportFileInKBytes, paymentAdviceSupportFileInMB;
		
		/*if(paymentAdviceBulkFile!=null){
			fileName = paymentAdviceBulkFile.getOriginalFilename();
			// To be commented as file name will be generic
			//fileIdentifier = fileName.substring(0, 5);
			logger.info("fileName for paymentAdviceBulkFile==========>"+fileName);
		try {
			byte[] bytes = paymentAdviceBulkFile.getBytes();
			inputStream = new ByteArrayInputStream(bytes);
		}catch (IOException e) {
			logger.error(e);
		}
	}*/
		
 try {
			
			inputStream = new FileInputStream(fileObj);
			 Properties properties=new Properties();
			 properties.load(inputStream);	
		
	
			 maxTransInCart=properties.getProperty("maximumTransactionsAllowedInCart");
			 maxSizeAlldForSupFile=properties.getProperty("maxiumSizeAllowedForPaymentAdviceSupportFile");
			 sheetName=properties.getProperty("sheetNameOfTheExcelFile");
		
		}
		catch(Exception e){
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}

		if (paymentAdviceBulkSupportFile != null) {
			paymentAdviceSupportFileInBytes = paymentAdviceBulkSupportFile.getSize();
			paymentAdviceSupportFileInKBytes = paymentAdviceSupportFileInBytes / 1024;
			paymentAdviceSupportFileInMB = paymentAdviceSupportFileInKBytes / 1024;
			logger.info(" Payment Advice Support File Size (in Bytes) : "
					+ paymentAdviceSupportFileInBytes);
			logger.info(" Payment Advice Support File Size (in Kilo Bytes) : "
					+ paymentAdviceSupportFileInKBytes);
			logger.info(" Payment Advice Support File Size (in Mega Bytes) : "
					+ paymentAdviceSupportFileInMB);
			logger.info(" Payment Advice Support File Original Name : "
					+ paymentAdviceBulkSupportFile.getOriginalFilename());
			maxSizeAllowed=Float.parseFloat(maxSizeAlldForSupFile);
			if(maxSizeAllowed<paymentAdviceSupportFileInMB){
				logger.info(" Payment advice support file size "+paymentAdviceSupportFileInMB+"is greater than allowed size "+maxSizeAllowed);
				paymentDetailsObj.setErrorCode("FAILURE");
				paymentDetailsObj.setErrorMessage(" Payment advice support file size "+paymentAdviceSupportFileInMB+"is greater than allowed size "+maxSizeAllowed);
				//return paymentDetailsObj;
				modelAndViewObj.addObject("message",paymentDetailsObj.getErrorMessage());
				modelAndViewObj.addObject("type", "upload");//use to identified that message for upload file
				return modelAndViewObj;
			}
		}
		
		File paymentTransferSupportObj=new File(paymentAdviceHomePath+"/Conf/PaymentAdvice.properties");
		
		FileDetails fileDetailsObj=new FileDetails();
		PaymentAdviceRequest paymntAdvRequestObj=new PaymentAdviceRequest();
		String message = null;
		
		paymentAdviceProcess="UNACCOUNTED AMOUNT ALLOCATION";
		
		try {					
			supportInputStream = new FileInputStream(paymentTransferSupportObj);
			Properties properties=new Properties();
			properties.load(supportInputStream);		
			maxSizeAlldForSupFile=properties.getProperty("maxiumSizeAllowedForPaymentAdviceSupportFile");
			sheetName=properties.getProperty("sheetNameOfTheExcelFile");
		}
		catch(Exception e){
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		
		/*
		 * if(aesDirectPostingSupportFile !=null){ paymentTransferSupportFileInBytes =
		 * aesDirectPostingSupportFile.getSize(); paymentTransferSupportFileInKBytes =
		 * paymentTransferSupportFileInBytes / 1024; paymentTransferSupportFileInMB =
		 * paymentTransferSupportFileInKBytes / 1024;
		 * 
		 * logger.info(" AES Direct Posting Support File Original Name : "
		 * +aesDirectPostingSupportFile.getOriginalFilename()
		 * +" AES Direct Posting Support File Size (in Bytes) : "+
		 * paymentTransferSupportFileInBytes +
		 * "  AES Direct Posting Support File Size (in Kilo Bytes) : "
		 * +paymentTransferSupportFileInKBytes
		 * +"  AES Direct Posting Support File Size (in Mega Bytes) : "
		 * +paymentTransferSupportFileInMB);
		 * 
		 * maxSizeAllowed=Float.parseFloat(maxSizeAlldForSupFile);
		 * if(maxSizeAllowed<paymentTransferSupportFileInMB){
		 * logger.info(" AES Direct Posting Support file size "
		 * +paymentTransferSupportFileInMB+"is greater than allowed size "
		 * +maxSizeAllowed); fileDetailsObj.setErrorCode("FAILURE");
		 * fileDetailsObj.setErrorMsg(" AES Direct Posting Support file size "
		 * +paymentTransferSupportFileInMB+"is greater than allowed size "
		 * +maxSizeAllowed);
		 * modelAndViewObj.addObject("message",fileDetailsObj.getErrorMsg());
		 * modelAndViewObj.addObject("type", "upload");//use to identified that message
		 * for upload file return modelAndViewObj; } }
		 */
		
		logger.info("fileName to go in filestatus aps "+fileName);
		String path = "";
		String supportFilePath ="";
		FileUploadResult fileUpload =null;
		PaymentAdviceRequest paymentRequestObj = null;
		try{
		
	 if (paymentAdviceBulkFile != null) {	
		//To validate xls or xlsx format
		 if(paymentAdviceBulkFile.getOriginalFilename()!=null && (paymentAdviceBulkFile.getOriginalFilename().toUpperCase().endsWith(".XLS"))){
			  fileFormatValidation=PaymentAdviceUtility.validateSheetName("XLS", paymentAdviceBulkFile,sheetName);
		 }
		 
		 if(paymentAdviceBulkFile.getOriginalFilename()!=null && (paymentAdviceBulkFile.getOriginalFilename().toUpperCase().endsWith(".XLSX"))){
			  fileFormatValidation=PaymentAdviceUtility.validateSheetName("XLSX", paymentAdviceBulkFile,sheetName);
		 }
			
		 if(fileFormatValidation!=null && fileFormatValidation.equalsIgnoreCase("SUCCESS"))
		 {	
			 paymentRequestObj=paymentAdviceUtility.processPABulkFileData(paymentAdviceDAOObj, paymentAdviceProcess,"XLS", paymentAdviceBulkFile,sheetName,
						userId,paymentAdviceBulkSupportFile,userName);
			
			
			 if(paymentRequestObj!=null&&paymentRequestObj.getErrorCode()!=null&&paymentRequestObj.getErrorCode().equalsIgnoreCase("SUCCESS")){
				 try {
						SNo=activityDao.insertActivityLog(SNo,userId,"Payment Advice Upload","Success","Payment Advice Uploaded",null,null,null);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						logger.info(e.getLocalizedMessage());
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
					}
				 try {
				 paymentDetailsObj.setErrorCode("SUCCESS");
				paymentDetailsObj.setErrorMessage(paymentRequestObj.getErrorMessage());
				UserDetails userDetailsObj=new UserDetails();
				userDetailsObj.setUserId(userId);
				logger.info("payment advice email generation");
				EMailContent emailContentObj=PaymentAdviceUtility.sendEmailAlert(paymentAdviceDAOObj, paymentRequestObj, userDetailsObj, "FILE_LEVEL_VALIDATIONS_SUCCESS_ALERT");
				logger.info("payment advice email body is" +emailContentObj.getEmailBody());
				logger.info(" Email Status "+emailContentObj.getErrorCode()+", "+emailContentObj.getErrorMessage());
				paymentDetailsObj.setErrorCode("SUCCESS");
				paymentDetailsObj.setErrorMessage(paymentRequestObj.getErrorMessage());
				
				 } catch (Exception e) {
						// TODO Auto-generated catch block
						logger.info(e.getLocalizedMessage());
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
					}
				 
				 
			}
			else if(paymentRequestObj!=null&&paymentRequestObj.getErrorCode()!=null&&paymentRequestObj.getErrorCode().equalsIgnoreCase("FAILURE")){
				
				try {
					SNo=activityDao.insertActivityLog(SNo,userId,"Payment Advice Upload","FAILURE","Payment Advice is NOT Upoladed",null,null,null);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					logger.info(e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}

				paymentDetailsObj.setErrorCode("FAILURE");
				paymentDetailsObj.setErrorMessage(paymentRequestObj.getErrorMessage());
			}
			else{
				paymentDetailsObj.setErrorCode("FAILURE");
				paymentDetailsObj.setErrorMessage(" Unable to raise payment advice request, invalid response received");
			}
			//Commented by Ritu on 14thAug 20202 
		  /* fileUpload =  excelReader.readFromExcelfile(fileName,"PAB", "UI", userId, "",inputStream,"PABulk",null,null);
		 	 
			if(fileUpload.getStatus() == 1){
				String renamedFileName=null;
					
				//path =transferFile+File.separator+fileName;
				if(fileName.endsWith(".xls")==true) {
					renamedFileName =fileName.replace(".xls","_" +fileUpload.getFileId() + ".xls");		
				retMessage=paymentAdviceUtility.transferFileToDestination(paymentAdviceBulkFile, renamedFileName, "UPLOAD");
				}else if(fileName.endsWith(".xlsx")==true) {
					renamedFileName =fileName.replace(".xlsx","_" +fileUpload.getFileId() + ".xlsx");	
				retMessage=paymentAdviceUtility.transferFileToDestination(paymentAdviceBulkFile, renamedFileName, "UPLOAD");
				}
				
			 }	*/	
		 }
		 else{
				paymentDetailsObj.setErrorCode("FAILURE");
				paymentDetailsObj.setErrorMessage(" Unable to raise payment advice request, reason for the failure is "+fileFormatValidation+" and try again ");
			}
		 
	 }
		
	//	logger.info("fileUpload.getStatusDescription()->>"+fileUpload.getStatusDescription());
		modelAndViewObj.addObject("message",paymentRequestObj.getErrorMessage());
		modelAndViewObj.addObject("type", "upload");
		modelAndViewObj.setViewName("PAbulk");
		//use to identified that message for upload file

		}
		catch(Exception e){
			
			logger.error("Exception occure while read excel file ", e);
			if(paymentRequestObj!=null){
				modelAndViewObj.addObject("message",fileUpload.getStatusDescription());
				modelAndViewObj.addObject("type", "upload");//use to identified that message for upload file
			}else
				modelAndViewObj.addObject("message","Error occur while Uploading File ,Check file name must be unique");
				modelAndViewObj.addObject("type", "upload");//use to identified that message for upload file
		}
		
		//if(fileUpload.getStatus() == 1){
	//	logger.info("fileUpload.getStatusDescription()==>"+fileUpload.getStatusDescription()+"fileUpload.getStatus()==>"+fileUpload.getStatus());
	  //Commented by Ritu on 14 Aug 2020
		/*	if(fileUpload.getStatusDescription().contains("Records Successfully Inserted")){
			
			try{
				 UserDetails userDetailsObj=new UserDetails();
	             userDetailsObj.setUserId(userId);

				AESAdviceRequest aesAdviceObj =new AESAdviceRequest();
				aesAdviceObj.setRequestId(Integer.parseInt(fileUpload.getFileId()));
				EMailContent emailContentObj=AESChequeUtility.sendEmailAlert("AESDP",aesAdviceDaoObj, aesAdviceObj, userDetailsObj, "FILE_LEVEL_VALIDATIONS_SUCCESS_ALERT");
				
				
			}catch(Exception e){
					e.printStackTrace();
			}
			
		}*/
	  return modelAndViewObj;
	//return paymentDetailsObj;
	
	}
	
	
	
	@RequestMapping(value = "/raisePaymentAdviceRequest", method = RequestMethod.POST)
	public @ResponseBody PaymentDetails raisePaymentAdviceRequest(HttpServletRequest request,HttpServletResponse response,@RequestParam("paymentAdviceSupportFile") MultipartFile paymentAdviceSupportFile,@RequestParam("paymentAdviceFile") MultipartFile paymentAdviceFile) {
	
		
		
		File fileObj=new File(paymentAdviceHomePath+"/Conf/PaymentAdvice.properties");
		InputStream inputStream;
		String maxTransInCart=null;
		String maxSizeAlldForSupFile=null;
		String sheetName=null;
        String paymentAdviceProcess=null;
		String paymentMode = request.getParameter("paymentModeHiddenValue");
	    logger.info("payment mode type is ..................." +paymentMode);
		try {
			
			inputStream = new FileInputStream(fileObj);
			 Properties properties=new Properties();
			 properties.load(inputStream);	
		
	
			 maxTransInCart=properties.getProperty("maximumTransactionsAllowedInCart");
			 maxSizeAlldForSupFile=properties.getProperty("maxiumSizeAllowedForPaymentAdviceSupportFile");
			 sheetName=properties.getProperty("sheetNameOfTheExcelFile");
		
		}
		catch(Exception e){
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		
		
		
		logger.info(" Got an hit to url /raisePaymentAdviceRequest");
		logger.info(" Calling  raisePaymentAdviceRequest() method to raise payment advice request");
		
		float maxSizeAllowed,paymentAdviceSupportFileInBytes, paymentAdviceSupportFileInKBytes, paymentAdviceSupportFileInMB;
		PaymentDetails paymentDetailsObj = new PaymentDetails();
		
		session = request.getSession(true);
		String userId = "NA",userName="NA";
		if (session.getAttribute("userid") != null) {
			userId = session.getAttribute("userid").toString();
		}
		if (session.getAttribute("uname") != null) {
			userName = session.getAttribute("uname").toString();
		}
		 Long SNo=0l;
		try {
			SNo = activityDao.insertActivityLog(0l,userId,"Payment Advice Upload",null,null,null,null,null);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}

		if (userId != "NA" && userName!="NA") {
			paymentAdviceProcess="UNACCOUNTED AMOUNT ALLOCATION";
			if(paymentAdviceProcess==null||paymentAdviceProcess==""){
				paymentDetailsObj.setErrorCode("FAILURE");
				paymentDetailsObj.setErrorMessage(" invalid payment advice process "+paymentAdviceProcess+" received, please try again ");
				return paymentDetailsObj;
			}
			
			ArrayList<String> refNumbersArray=new ArrayList<String>();
			HashMap<String,String> paymentModeAndRefNumberMap=new HashMap<String,String>();
			HashMap<String,String> bankAccountNumberAndRefNumberMap=new HashMap<String,String>();
			
			//HashMap<List<String>,HashMap<String,String>> RefNumberMap=new HashMap<List<String>,HashMap<String,String>>();
			
			List<String> incNumber =new ArrayList<String>();
			List<String> utrNumber =new ArrayList<String>();
			List<String> bankVirtualNumber =new ArrayList<String>();
			Object[] obj=new Object[3];
			
			
			String[] refNumbers = request.getParameterValues("refNumber");
			if(refNumbers!=null){
				for (int i = 0; i < refNumbers.length; i++) {
					if(refNumbers[i]!=null){
						String[] refs=refNumbers[i].split("\\$");
						if(refs!=null){
							if(refs[0]!=null&&refs[0].equalsIgnoreCase("CHEQUE")){
								if(refs[1]!=null){
									paymentModeAndRefNumberMap.put(refs[1], refs[0]);
									if(!refNumbersArray.contains(refs[1]))
										refNumbersArray.add(refs[1].toUpperCase());
								}
								
								
								
								if(refs[5]!=null){
									bankAccountNumberAndRefNumberMap.put(refs[1], refs[5]);
									logger.info("bank account number in Cheque map" +	bankAccountNumberAndRefNumberMap.get(refs[1]));
								}
								
							}
							if(refs[0]!=null&&refs[0].equalsIgnoreCase("NEFT")){
								if(refs[1]!=null){
									paymentModeAndRefNumberMap.put(refs[1], refs[0]);
									if(!refNumbersArray.contains(refs[1]))
										refNumbersArray.add(refs[1].toUpperCase());
								}
								if(refs[2]!=null){
									paymentModeAndRefNumberMap.put(refs[2], refs[0]);
									if(!refNumbersArray.contains(refs[2]))
										refNumbersArray.add(refs[1].toUpperCase());
								}
								logger.info("refs[1].toUpperCase()" +refs[1].toUpperCase()+"..."+"refs[2].toUpperCase()" +refs[2].toUpperCase());
								
								if(refs[6]!=null){
									bankAccountNumberAndRefNumberMap.put(refs[1], refs[6]);
									logger.info("bank account number in NEFT map" +bankAccountNumberAndRefNumberMap.get(refs[1]));
									
									utrNumber.add(refs[1]);
									incNumber.add(refs[2]);
									bankVirtualNumber.add(refs[6]);
								}
																
							}	
						}
					}
				}
				
				//adding here
				//RefNumberMap.put(incNumber, bankAccountNumberAndRefNumberMap);
				obj[0]=utrNumber;
				obj[1]=bankVirtualNumber;
				obj[2]=incNumber;
			}
			else{
				logger.info(" Unable to raise payment advice request, invalid reference numbers received ");
				paymentDetailsObj.setErrorCode("FAILURE");
				paymentDetailsObj.setErrorMessage(" Unable to raise payment advice request, invalid reference numbers received ");
				return paymentDetailsObj;
			}
			
			if (paymentAdviceSupportFile != null) {
				paymentAdviceSupportFileInBytes = paymentAdviceSupportFile.getSize();
				paymentAdviceSupportFileInKBytes = paymentAdviceSupportFileInBytes / 1024;
				paymentAdviceSupportFileInMB = paymentAdviceSupportFileInKBytes / 1024;
				logger.info(" Payment Advice Support File Size (in Bytes) : "
						+ paymentAdviceSupportFileInBytes);
				logger.info(" Payment Advice Support File Size (in Kilo Bytes) : "
						+ paymentAdviceSupportFileInKBytes);
				logger.info(" Payment Advice Support File Size (in Mega Bytes) : "
						+ paymentAdviceSupportFileInMB);
				logger.info(" Payment Advice Support File Original Name : "
						+ paymentAdviceSupportFile.getOriginalFilename());
				maxSizeAllowed=Float.parseFloat(maxSizeAlldForSupFile);
				if(maxSizeAllowed<paymentAdviceSupportFileInMB){
					logger.info(" Payment advice support file size "+paymentAdviceSupportFileInMB+"is greater than allowed size "+maxSizeAllowed);
					paymentDetailsObj.setErrorCode("FAILURE");
					paymentDetailsObj.setErrorMessage(" Payment advice support file size "+paymentAdviceSupportFileInMB+"is greater than allowed size "+maxSizeAllowed);
					return paymentDetailsObj;
				}
			}
			
			if (paymentAdviceFile != null) {			
				logger.info(" Payment Advice Original File Name : "+paymentAdviceFile.getOriginalFilename());
				logger.info(" Payment Advice  File Size  (in Bytes) : "+paymentAdviceFile.getSize());
				if(paymentAdviceFile.getOriginalFilename()!=null&&paymentAdviceFile.getOriginalFilename().toUpperCase().endsWith(".XLS")){
					String fileFormatValidation=PaymentAdviceUtility.validateSheetName("XLS", paymentAdviceFile,sheetName);
					if(fileFormatValidation!=null&&fileFormatValidation.equalsIgnoreCase("SUCCESS")){
						logger.info("process tyope selected is " +paymentAdviceProcess);
						
						PaymentAdviceRequest paymentRequestObj=paymentAdviceUtility.processFileData(paymentAdviceDAOObj, paymentAdviceProcess,"XLS", paymentAdviceFile,sheetName,
								refNumbersArray,userId,paymentAdviceSupportFile,userName,paymentModeAndRefNumberMap,paymentMode,bankAccountNumberAndRefNumberMap,obj);
						if(paymentRequestObj!=null&&paymentRequestObj.getErrorCode()!=null&&paymentRequestObj.getErrorCode().equalsIgnoreCase("SUCCESS")){
							 try {
									SNo=activityDao.insertActivityLog(SNo,userId,"Payment Advice Upload","Success","Payment Advice Uploaded",null,null,null);
								} catch (SQLException e) {
									// TODO Auto-generated catch block
									logger.info(e.getLocalizedMessage());
									StringWriter errors= new StringWriter();
									e.printStackTrace(new PrintWriter(errors));
									logger.error(errors);
								}
							 try {
							 paymentDetailsObj.setErrorCode("SUCCESS");
							paymentDetailsObj.setErrorMessage(paymentRequestObj.getErrorMessage());
							UserDetails userDetailsObj=new UserDetails();
							userDetailsObj.setUserId(userId);
							logger.info("payment advice email generation");
							EMailContent emailContentObj=PaymentAdviceUtility.sendEmailAlert(paymentAdviceDAOObj, paymentRequestObj, userDetailsObj, "FILE_LEVEL_VALIDATIONS_SUCCESS_ALERT");
							logger.info("payment advice email body is" +emailContentObj.getEmailBody());
							logger.info(" Email Status "+emailContentObj.getErrorCode()+", "+emailContentObj.getErrorMessage());
							paymentDetailsObj.setErrorCode("SUCCESS");
							paymentDetailsObj.setErrorMessage(paymentRequestObj.getErrorMessage());
							
							 } catch (Exception e) {
									// TODO Auto-generated catch block
									logger.info(e.getLocalizedMessage());
									StringWriter errors= new StringWriter();
									e.printStackTrace(new PrintWriter(errors));
									logger.error(errors);
								}
							 
							 
						}
						else if(paymentRequestObj!=null&&paymentRequestObj.getErrorCode()!=null&&paymentRequestObj.getErrorCode().equalsIgnoreCase("FAILURE")){
							
							try {
								SNo=activityDao.insertActivityLog(SNo,userId,"Payment Advice Upload","FAILURE","Payment Advice is NOT Upoladed",null,null,null);
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								logger.info(e.getLocalizedMessage());
								StringWriter errors= new StringWriter();
								e.printStackTrace(new PrintWriter(errors));
								logger.error(errors);
							}

							paymentDetailsObj.setErrorCode("FAILURE");
							paymentDetailsObj.setErrorMessage(paymentRequestObj.getErrorMessage());
						}
						else{
							paymentDetailsObj.setErrorCode("FAILURE");
							paymentDetailsObj.setErrorMessage(" Unable to raise payment advice request, invalid response received");
						}
					}
					else{
						paymentDetailsObj.setErrorCode("FAILURE");
						paymentDetailsObj.setErrorMessage(" Unable to raise payment advice request, reason for the failure is "+fileFormatValidation+" and try again ");
					}
					
				}
				else if(paymentAdviceFile.getOriginalFilename()!=null&&paymentAdviceFile.getOriginalFilename().toUpperCase().endsWith(".XLSX")){
					String fileFormatValidation=PaymentAdviceUtility.validateSheetName("XLSX", paymentAdviceFile,sheetName);
					if(fileFormatValidation!=null&&fileFormatValidation.equalsIgnoreCase("SUCCESS")){
						//PaymentAdviceUtility paymentAdviceUtility=new PaymentAdviceUtility();
						PaymentAdviceRequest paymentRequestObj=paymentAdviceUtility.processFileData(paymentAdviceDAOObj, paymentAdviceProcess,"XLSX", paymentAdviceFile,sheetName,refNumbersArray,userId,paymentAdviceSupportFile,userName
								,paymentModeAndRefNumberMap,paymentMode,bankAccountNumberAndRefNumberMap,obj);
						if(paymentRequestObj!=null&&paymentRequestObj.getErrorCode()!=null&&paymentRequestObj.getErrorCode().equalsIgnoreCase("SUCCESS")){
			        		 try {
								SNo=activityDao.insertActivityLog(SNo,userId,"Payment Advice Upload","Success","Payment Advice Uploaded",null,null,null);
							
							UserDetails userDetailsObj=new UserDetails();
							userDetailsObj.setUserId(userId);
							logger.info("payment advice email generation");
							logger.info("request id in xlsx mail before sending mail" +paymentRequestObj.getRequestId());
							EMailContent emailContentObj=PaymentAdviceUtility.sendEmailAlert(paymentAdviceDAOObj, paymentRequestObj, userDetailsObj, "FILE_LEVEL_VALIDATIONS_SUCCESS_ALERT");
							logger.info(" Email Status "+emailContentObj.getErrorCode()+", "+emailContentObj.getErrorMessage());
							paymentDetailsObj.setErrorCode("SUCCESS");
							paymentDetailsObj.setErrorMessage(paymentRequestObj.getErrorMessage());
			        		 } catch (SQLException e) {
									// TODO Auto-generated catch block
									logger.info(e.getLocalizedMessage());
									StringWriter errors= new StringWriter();
									e.printStackTrace(new PrintWriter(errors));
									logger.error(errors);
							} catch (Exception e) {
									// TODO Auto-generated catch block
									logger.info(e.getLocalizedMessage());
									StringWriter errors= new StringWriter();
									e.printStackTrace(new PrintWriter(errors));
									logger.error(errors);
								}
						}
						else if(paymentRequestObj!=null&&paymentRequestObj.getErrorCode()!=null&&paymentRequestObj.getErrorCode().equalsIgnoreCase("FAILURE")){
							try {
								SNo=activityDao.insertActivityLog(SNo,userId,"Payment Advice Upload","FAILURE","Payment Advice is NOT Uploaded",null,null,null);
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								logger.info(e.getLocalizedMessage());
								StringWriter errors= new StringWriter();
								e.printStackTrace(new PrintWriter(errors));
								logger.error(errors);
							}
							paymentDetailsObj.setErrorCode("FAILURE");
							paymentDetailsObj.setErrorMessage(paymentRequestObj.getErrorMessage());
						}
						else{
							paymentDetailsObj.setErrorCode("FAILURE");
							paymentDetailsObj.setErrorMessage(" Unable to raise payment advice request, invalid response received");
						}
					}
					else{
						paymentDetailsObj.setErrorCode("FAILURE");
						paymentDetailsObj.setErrorMessage(" Unable to raise payment advice request, reason for the failure is "+fileFormatValidation+" and try again ");
					}
				}
				else{
					paymentDetailsObj.setErrorCode("FAILURE");
					paymentDetailsObj.setErrorMessage(" Unable to raise payment advice request, invalid payment advice file uploaded "+paymentAdviceFile.getOriginalFilename()+", system accepts file names ends with (xls or xlsx) !! ");
					return paymentDetailsObj;
				}
				
			}
			else{
				logger.info(" Unable to raise payment advice request, invalid payment advice file received "+paymentAdviceFile);
				paymentDetailsObj.setErrorCode("FAILURE");
				paymentDetailsObj.setErrorMessage(" Unable to raise payment advice request, invalid reference to payment advice upload file received, please upload and try again !! ");
				return paymentDetailsObj;
			}
		}
		else{
			paymentDetailsObj.setErrorCode("FAILURE");
			paymentDetailsObj.setErrorMessage(" Unable to raise payment advice request, user id or user name not able retreive from the login session !! ");
			return paymentDetailsObj;
		}
		
		logger.info(" Exection of  raisePaymentAdviceRequest() method has been completed");
		return paymentDetailsObj;
	}

	@RequestMapping(value = "/checkLockOnPaymentDetails", method = RequestMethod.POST)
	public @ResponseBody PaymentAdviceLock checkLockOnPaymentDetails(
			HttpServletRequest request, HttpServletResponse response) {
		logger.info(" Got an hit to url /checkLockOnPaymentDetails");
		logger.info(" Calling  checkLockOnPaymentDetails() method to raise payment advice request");

		String referenceNum = request.getParameter("referenceNumber");
		PaymentAdviceLock paymentAdviceLockObj = new PaymentAdviceLock();
		try{
		paymentAdviceLockObj.setReferenceNum(referenceNum);
		paymentAdviceLockObj = paymentAdviceDAOObj
				.checkLockOnPaymentDetails(paymentAdviceLockObj);
		logger.info(" Exection of  raisePaymentAdviceRequest() method has been completed");
}catch(Exception e){
	logger.info(e.getLocalizedMessage());
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);

}
		return paymentAdviceLockObj;
	}

	@RequestMapping(value = "/acquireLockOnPaymentDetails", method = RequestMethod.POST)
	public @ResponseBody PaymentAdviceLock acquireLockOnPaymentDetails(
			HttpServletRequest request, HttpServletResponse response) {
		logger.info(" Got an hit to url /acquireLockOnPaymentDetails");
		logger.info(" Calling  acquireLockOnPaymentDetails() method to raise payment advice request");
		session = request.getSession(true);
		String userId = session.getAttribute("userid").toString();
		String referenceNum = request.getParameter("referenceNumber");
		PaymentAdviceLock paymentAdviceLockObj = new PaymentAdviceLock();
try{
		paymentAdviceLockObj.setLockAcuiredBy(userId);
		paymentAdviceLockObj.setReferenceNum(referenceNum);
		paymentAdviceLockObj = paymentAdviceDAOObj
				.acquireLockOnPaymentDetails(paymentAdviceLockObj);
		logger.info(" Exection of  acquireLockOnPaymentDetails() method has been completed");
}catch(Exception e){
	logger.info(e.getLocalizedMessage());
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);
}
		return paymentAdviceLockObj;
	}

	@RequestMapping(value = "/releaseLockOnPaymentDetails", method = RequestMethod.POST)
	public @ResponseBody PaymentAdviceLock releaseLockOnPaymentDetails(
			HttpServletRequest request, HttpServletResponse response) {
		logger.info(" Got an hit to url /releaseLockOnPaymentDetails");
		logger.info(" Calling  releaseLockOnPaymentDetails() method to raise payment advice request");
		session = request.getSession(true);
		String userId = session.getAttribute("userid").toString();
		String referenceNum = request.getParameter("referenceNumber");
		PaymentAdviceLock paymentAdviceLockObj = new PaymentAdviceLock();
try{
		paymentAdviceLockObj.setLockAcuiredBy(userId);
		paymentAdviceLockObj.setReferenceNum(referenceNum);
		paymentAdviceLockObj = paymentAdviceDAOObj
				.releaseLockOnPaymentDetails(paymentAdviceLockObj);
		logger.info(" Exection of  releaseLockOnPaymentDetails() method has been completed");
}catch(Exception e){
	logger.info(e.getLocalizedMessage());
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);

}
		return paymentAdviceLockObj;
	}

	@RequestMapping(value = "/getPABulkTemplate", method = RequestMethod.POST)
	public ModelAndView downLoadPABulkUploadTemplate(
			HttpServletRequest request, HttpServletResponse response) {
		logger.info(" Got an hit to url /downLoadPABulkUploadTemplate");
		logger.info(" Calling  downLoadPABulkUploadTemplate() method ");
		session = request.getSession(true);
		ModelAndView modelAndViewObj=new ModelAndView();
		PaymentAdviceTemplate paymentAdviceTemplateObj = new PaymentAdviceTemplate();
		String userId = session.getAttribute("userid").toString();
		paymentAdviceTemplateObj.setUserId(userId);
		paymentAdviceTemplateObj.setTemplatePath(paymentAdviceHomePath
				+ "/UploadTemplate/");
		String templateRequired=request.getParameter("templateName");
		if(templateRequired!=null&&templateRequired.equalsIgnoreCase("XLS")){
			paymentAdviceTemplateObj.setTemplateName("Payment_Advice_Bulk_Upload.xls");
			paymentAdviceTemplateObj.setDownloadedFileName(paymentAdviceTemplateObj
					.getTemplateName().replace(".xls",
							"_" + PaymentAdviceUtility.getDateTime() + ".xls"));

			ServletOutputStream out = null;
			FileInputStream in = null;
			try {
				out = response.getOutputStream();
				in = new FileInputStream(paymentAdviceTemplateObj.getTemplatePath()
						+ paymentAdviceTemplateObj.getTemplateName());

				response.setContentType("APPLICATION/OCTET-STREAM");

				response.addHeader("content-disposition", "attachment; filename="
						+ paymentAdviceTemplateObj.getDownloadedFileName());
				int octet;
				while ((octet = in.read()) != -1)
					out.write(octet);
				in.close();
				out.flush();
				out.close();
				response.flushBuffer();
				paymentAdviceTemplateObj.setErrorCode("SUCCESS");
				paymentAdviceTemplateObj.setErrorMessage("Download template "+paymentAdviceTemplateObj.getDownloadedFileName()+" has been downloaded successfully !!");
			} catch (FileNotFoundException e) {
				logger.info(e.getLocalizedMessage());
				paymentAdviceTemplateObj.setErrorCode("FAILURE");
				paymentAdviceTemplateObj.setErrorMessage(" Unable to download template file, because source file not found in the server ");
				modelAndViewObj.addObject("error", "Unable to download template file, because source file not found in the server ");
				// TODO Auto-generated catch block
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			} catch (IOException e) {
				logger.info(e.getLocalizedMessage());
				paymentAdviceTemplateObj.setErrorCode("FAILURE");
				paymentAdviceTemplateObj.setErrorMessage(" Unable to download template file, because IO Exception occured ");
				modelAndViewObj.addObject("error", "Unable to download template file, because IO Exception occured ");
				// TODO Auto-generated catch block
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
			paymentAdviceTemplateObj.setErrorCode("SUCCESS");

		}
		else if(templateRequired!=null&&templateRequired.equalsIgnoreCase("XLSX")){
			paymentAdviceTemplateObj.setTemplateName("Payment_Advice_Bulk_Upload.xlsx");
			paymentAdviceTemplateObj.setDownloadedFileName(paymentAdviceTemplateObj
					.getTemplateName().replace(".xlsx",
							"_" + PaymentAdviceUtility.getDateTime() + ".xlsx"));

			ServletOutputStream out = null;
			FileInputStream in = null;
			try {
				out = response.getOutputStream();
				in = new FileInputStream(paymentAdviceTemplateObj.getTemplatePath()
						+ paymentAdviceTemplateObj.getTemplateName());

				response.setContentType("APPLICATION/OCTET-STREAM");

				response.addHeader("content-disposition", "attachment; filename="
						+ paymentAdviceTemplateObj.getDownloadedFileName());
				int octet;
				while ((octet = in.read()) != -1)
					out.write(octet);
				in.close();
				out.flush();
				out.close();
				response.flushBuffer();
				paymentAdviceTemplateObj.setErrorCode("SUCCESS");
				paymentAdviceTemplateObj.setErrorMessage("Download template "+paymentAdviceTemplateObj.getDownloadedFileName()+" has been downloaded successfully !!");
			} catch (FileNotFoundException e) {
				logger.info(e.getLocalizedMessage());
				paymentAdviceTemplateObj.setErrorCode("FAILURE");
				paymentAdviceTemplateObj.setErrorMessage(" Unable to download template file, because source file not found in the server ");
				modelAndViewObj.addObject("error", "Unable to download template file, because source file not found in the server ");
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			} catch (IOException e) {
				logger.info(e.getLocalizedMessage());
				paymentAdviceTemplateObj.setErrorCode("FAILURE");
				paymentAdviceTemplateObj.setErrorMessage(" Unable to download template file, because IO Exception occured ");
				modelAndViewObj.addObject("error", "Unable to download template file, because IO Exception occured ");
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
			paymentAdviceTemplateObj.setErrorCode("SUCCESS");

		}
		modelAndViewObj.setViewName("paymentAdviceHome");;
		logger.info(" Execution of downLoadPABulkUploadTemplate() method completed ");
		return modelAndViewObj;
	}
	
	
	@RequestMapping(value = "/getPaymentAdviceTemplate", method = RequestMethod.POST)
	public ModelAndView downLoadPaymentAdviceUploadTemplate(
			HttpServletRequest request, HttpServletResponse response) {
		logger.info(" Got an hit to url /downLoadPaymentAdviceUploadTemplate");
		logger.info(" Calling  downLoadPaymentAdviceUploadTemplate() method ");
		session = request.getSession(true);
		ModelAndView modelAndViewObj=new ModelAndView();
		PaymentAdviceTemplate paymentAdviceTemplateObj = new PaymentAdviceTemplate();
		String userId = session.getAttribute("userid").toString();
		paymentAdviceTemplateObj.setUserId(userId);
		paymentAdviceTemplateObj.setTemplatePath(paymentAdviceHomePath
				+ "/UploadTemplate/");
		String templateRequired=request.getParameter("templateName");
		if(templateRequired!=null&&templateRequired.equalsIgnoreCase("XLS")){
			paymentAdviceTemplateObj.setTemplateName("Payment_Advice_Upload.xls");
			paymentAdviceTemplateObj.setDownloadedFileName(paymentAdviceTemplateObj
					.getTemplateName().replace(".xls",
							"_" + PaymentAdviceUtility.getDateTime() + ".xls"));

			ServletOutputStream out = null;
			FileInputStream in = null;
			try {
				out = response.getOutputStream();
				in = new FileInputStream(paymentAdviceTemplateObj.getTemplatePath()
						+ paymentAdviceTemplateObj.getTemplateName());

				response.setContentType("APPLICATION/OCTET-STREAM");

				response.addHeader("content-disposition", "attachment; filename="
						+ paymentAdviceTemplateObj.getDownloadedFileName());
				int octet;
				while ((octet = in.read()) != -1)
					out.write(octet);
				in.close();
				out.flush();
				out.close();
				response.flushBuffer();
				paymentAdviceTemplateObj.setErrorCode("SUCCESS");
				paymentAdviceTemplateObj.setErrorMessage("Download template "+paymentAdviceTemplateObj.getDownloadedFileName()+" has been downloaded successfully !!");
			} catch (FileNotFoundException e) {
				logger.info(e.getLocalizedMessage());
				paymentAdviceTemplateObj.setErrorCode("FAILURE");
				paymentAdviceTemplateObj.setErrorMessage(" Unable to download template file, because source file not found in the server ");
				modelAndViewObj.addObject("error", "Unable to download template file, because source file not found in the server ");
				// TODO Auto-generated catch block
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			} catch (IOException e) {
				logger.info(e.getLocalizedMessage());
				paymentAdviceTemplateObj.setErrorCode("FAILURE");
				paymentAdviceTemplateObj.setErrorMessage(" Unable to download template file, because IO Exception occured ");
				modelAndViewObj.addObject("error", "Unable to download template file, because IO Exception occured ");
				// TODO Auto-generated catch block
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
			paymentAdviceTemplateObj.setErrorCode("SUCCESS");

		}
		else if(templateRequired!=null&&templateRequired.equalsIgnoreCase("XLSX")){
			paymentAdviceTemplateObj.setTemplateName("Payment_Advice_Upload.xlsx");
			paymentAdviceTemplateObj.setDownloadedFileName(paymentAdviceTemplateObj
					.getTemplateName().replace(".xlsx",
							"_" + PaymentAdviceUtility.getDateTime() + ".xlsx"));

			ServletOutputStream out = null;
			FileInputStream in = null;
			try {
				out = response.getOutputStream();
				in = new FileInputStream(paymentAdviceTemplateObj.getTemplatePath()
						+ paymentAdviceTemplateObj.getTemplateName());

				response.setContentType("APPLICATION/OCTET-STREAM");

				response.addHeader("content-disposition", "attachment; filename="
						+ paymentAdviceTemplateObj.getDownloadedFileName());
				int octet;
				while ((octet = in.read()) != -1)
					out.write(octet);
				in.close();
				out.flush();
				out.close();
				response.flushBuffer();
				paymentAdviceTemplateObj.setErrorCode("SUCCESS");
				paymentAdviceTemplateObj.setErrorMessage("Download template "+paymentAdviceTemplateObj.getDownloadedFileName()+" has been downloaded successfully !!");
			} catch (FileNotFoundException e) {
				logger.info(e.getLocalizedMessage());
				paymentAdviceTemplateObj.setErrorCode("FAILURE");
				paymentAdviceTemplateObj.setErrorMessage(" Unable to download template file, because source file not found in the server ");
				modelAndViewObj.addObject("error", "Unable to download template file, because source file not found in the server ");
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			} catch (IOException e) {
				logger.info(e.getLocalizedMessage());
				paymentAdviceTemplateObj.setErrorCode("FAILURE");
				paymentAdviceTemplateObj.setErrorMessage(" Unable to download template file, because IO Exception occured ");
				modelAndViewObj.addObject("error", "Unable to download template file, because IO Exception occured ");
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
			paymentAdviceTemplateObj.setErrorCode("SUCCESS");

		}
		modelAndViewObj.setViewName("paymentAdviceHome");;
		logger.info(" Execution of downLoadPaymentAdviceUploadTemplate() method completed ");
		return modelAndViewObj;
	}
	
	
	
	
	  	
	  	
	  	
	  //<--------------------Waiver Code Ends ----------------------->
	
	
	
	
}
 