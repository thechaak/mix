package com.airtel.ace.cad.paymentadvice.dao;
 
import java.util.HashMap;
import java.util.List;

import  com.airtel.ace.cad.paymentadvice.model.ApprovalDetails;
import com.airtel.ace.cad.paymentadvice.model.Circle;

public  interface ApprovalDAO {

	List<String> getPaymentAdviceProcessList();
	String getCustomerType(Long requestId);
	/*VendorDetails vendorCreation(VendorDetails vendorDetailsObj);
	
	List<VendorDetails> IDandName() ;
	

	VendorDetails AllVendorDetails(VendorDetails vendorDetailsObj);

	VendorDetails SubmitVendorUserDetails(VendorDetails vendorDetailsObj);

	VendorDetails roleCheck(VendorDetails vendorDetailsObj);

	VendorDetails vendorDates(VendorDetails vendorDetailsObj);

	VendorDetails OLMExist(VendorDetails vendorDetailsObj);

	VendorDetails getOLMDetails(VendorDetails vendorDetailsObj);

	VendorDetails modifyVendorUserDetails(VendorDetails vendorDetailsObj);

	VendorDetails getVendorDates(VendorDetails vendorDetailsObj);

	VendorDetails vendorExist(VendorDetails vendorDetailsObj);
	
	VendorDetails updateVendorDetails(VendorDetails vendorDetailsObj);
	
	List<String> getAllLOBs();
	
	List<String> getAllPaymentModes();
	
	VendorDetails getVendorDetails(VendorDetails vendorDetailsObj);
	
	User createCADUser(User userObj);
	
	List<String> getAllTrasferTypes();
	
	User createRMCCUser(User userObj);
	
	User createVendorUser(User userObj);

	VendorDetails modifyUserDetails(VendorDetails vendorDetailsObj);

	List<UserRole> getUserRoles();

	HashMap<Integer, List<ApprovalDetails>> getReportDetails(
			ApprovalDetails approvalDetailsObj, int page);*/
	List<String> getModeOfPayment();
	HashMap<Integer, List<ApprovalDetails>> getApprovalDetails(int pageNumber, ApprovalDetails approvalDetailsObj);
	HashMap<Integer, List<ApprovalDetails>> getApprovalDetailsWithPgtn(int pageNumber,ApprovalDetails approvalDetailsObj);
	
	List<ApprovalDetails> BulkApproveAndReject(List<ApprovalDetails> approveUpdateList,ApprovalDetails approveObj,String role);
	
	//ApprovalDetails ApproveAndReject(ApprovalDetails approveObj);

	
	List<ApprovalDetails> getUTRDetailsRecords(Long utrNumber);
	ApprovalDetails exchangeRateUpdate(List<ApprovalDetails> updateRecordsObjList,
			ApprovalDetails exchangeRateDetailsObj);
	List<String> getRejectReasons();
	ApprovalDetails downloadPaymentAdviceFile(String userId,String requestId, String paymentMode, String extension);
	String getApproverEmailId(String userId);
	List<Circle> getCirclesList();


	public String fetchExchangeRate (String ticketNumber)throws Exception;
	
	
}
