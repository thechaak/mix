package com.acecad.bulkupload.model;

import java.util.List;

public class Transfer {
	
	BulkDetails bulkObj;
	List<BulkDetails> listBulkDetails;
	public BulkDetails getBulkObj() {
		return bulkObj;
	}
	public void setBulkObj(BulkDetails bulkObj) {
		this.bulkObj = bulkObj;
	}
	public List<BulkDetails> getListBulkDetails() {
		return listBulkDetails;
	}
	public void setListBulkDetails(List<BulkDetails> listBulkDetails) {
		this.listBulkDetails = listBulkDetails;
	}
	

}
