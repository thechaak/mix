/**
 * 
 */
package com.acecad.bulkupload.model;
   
/**
 * @author 587111
 *
 */
public class UserEmailDetails {
	private String userId;
	private String errorCode;
	private String errorMessage; 
	private String emailAddress;

	public String getUserId() {
		return userId;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	
	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
