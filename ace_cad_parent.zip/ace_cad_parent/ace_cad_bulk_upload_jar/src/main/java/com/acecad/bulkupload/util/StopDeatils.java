package com.acecad.bulkupload.util;

public class StopDeatils {
	private String fileID;
	private String finalFileName;
	private int totalRecords;
	private String fileUploadDate;
	private String paymentAmount;
	private String userId;
	private String userName;
	private String paymentMode;
	
	public String getFileID() {
		return fileID;
	}
	public void setFileID(String fileID) {
		this.fileID = fileID;
	}
	
	public String getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getFinalFileName() {
		return finalFileName;
	}
	public void setFinalFileName(String finalFileName) {
		this.finalFileName = finalFileName;
	}
	public int getTotalRecords() {
		return totalRecords;
	}
	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}
	public String getFileUploadDate() {
		return fileUploadDate;
	}
	public void setFileUploadDate(String fileUploadDate) {
		this.fileUploadDate = fileUploadDate;
	}
	@Override
	public String toString() {
		return "StopDeatils [fileID=" + fileID + ", finalFileName=" + finalFileName + ", totalRecords=" + totalRecords
				+ ", fileUploadDate=" + fileUploadDate + ", paymentAmount=" + paymentAmount + ", userId=" + userId
				+ ", userName=" + userName + ", paymentMode=" + paymentMode + "]";
	}
	
	
	
	

}
