package com.acecad.bulkupload.util;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Value;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
/*import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;*/
/*import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;*/
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.acecad.bulkupload.dao.BulkDao;
import com.acecad.bulkupload.model.BulkDetails;
import com.acecad.bulkupload.model.FileDetails;
import com.acecad.bulkupload.model.UserEmailDetails;
import com.airtel.acecad.UtilityJar.ActivityLog;
import com.airtel.acecad.model.EMailContent;
import com.airtel.acecad.model.SmtpMailContent;
import com.airtel.acecad.utility.SmtpUtility;


public class BulkUtil {
	
	private static String homePath=System.getenv("ACE_CAD_HOME");
	private static Logger logger =LogManager.getLogger("bulkUploadLogger");
	
	public HttpSession session;
	@Autowired
	ActivityLog activityLogDao;
		
	@Autowired
	BulkDao bulkDao;
	
	@Value("${MAXIMUM_RECORDS_IN_FILE}")
	private int MAXIMUM_RECORDS_IN_FILE;
	
	@Value("${MAXIMUM_AMOUNT_IN_FILE}")
	private double MAXIMUM_AMOUNT_IN_FILE;
	//private static String homePath = System.getenv("ACE_CAD_HOME");

	public static String validateUploadedFile(MultipartFile file) {

		String filename = file.getOriginalFilename();
		System.out.println("file name"+filename);
		String	extension = filename.substring(filename.lastIndexOf(".") + 1, filename.length());
		System.out.println("extension is..."+extension);
		String excel = "xls";
		String excelx="xlsx";
	
		if (extension.equalsIgnoreCase(excel)) {
		   return excel;
		}
		else if(extension.equalsIgnoreCase(excelx)){
		  	   return excelx;
		    }
		else return extension;
		}

	

	public static boolean validateRecordCount(MultipartFile file)
	{
		
		try {
			if(file.getInputStream()!=null)
			{ 
			
			return true;
			}
			
		} catch (IOException e) {
			
			StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
		}
		return false;
		
	}
	public  ModelAndView validatexls(
			 MultipartFile file,
			HttpServletRequest request,String downloadpath,String errorFilesPath, String extension) 
	{
		String paymentMode="CHEQUE";
		
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
        String exchangerateregex="[0-9][0-9]?[0-9]?[0-9]?+(\\.[0-9]?[0-9]?[0-9]?[0-9]?[0-9]?[0-9]?)?";
		String dateRegex="[0-9][0-9][\\/][0-9][0-9][\\/][0-9]{4}";
		boolean isValidTrans=false;
		FileDetails fileDetailsObj2=null;
		FileDetails fileDetailsObj=new FileDetails();
		
		String original = file.getOriginalFilename();
		fileDetailsObj.setOriginalFileName(original);
		logger.info("original file name is:" + original);

		

		logger.info("replaced file name is:" + userId
				+ file.getOriginalFilename());

		fileDetailsObj.setFinalFileName(userId
				+ file.getOriginalFilename());
		
		ModelAndView modelAndViewObj=new ModelAndView();
		boolean recordCount = BulkUtil.validateRecordCount(file);
		Long SNo=0l;
		try{
		SNo=activityLogDao.insertActivityLog(0l,userId,"file upload",null,null,original,null,null);
		}catch(SQLException sqlexception)
		{
			sqlexception.printStackTrace();
			modelAndViewObj.addObject("message","DB Connectivity issues");
			modelAndViewObj.setViewName("Error");
			return modelAndViewObj;
		}
		
		
		if (recordCount) {
			try {

				InputStream file1 =  (file
						.getInputStream());

				HSSFWorkbook workbook = new HSSFWorkbook(file1);

				HSSFSheet sheet = workbook.getSheetAt(0);

				logger.info("Present Sheet name is" + "\t"
						+ workbook.getSheetName(0));

				Iterator<Row> rows1 = sheet.rowIterator();

			//	HSSFRow row1 = (HSSFRow) rows1.next();
				int noOfRec = sheet.getPhysicalNumberOfRows() - 1;
			
				fileDetailsObj.setTotalRecords(noOfRec);
			
				if(noOfRec==-1)
				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT is zero",original,null,null);
		              logger.info("invalid file with no records");
						modelAndViewObj.addObject("error",
								"Invalid file with no records");
						modelAndViewObj.setViewName("bulk");
						return modelAndViewObj;
				}
				
			
                logger.info("\n no of rec " + noOfRec);

				double sum = 0;
			//	Iterator<Row> rows2 = sheet.rowIterator();
				HSSFRow row = null;
			//	HSSFRow row3 = (HSSFRow) rows2.next();

				Iterator<Row> rows = sheet.rowIterator();
				
				
		//		int num=0;
				/*while(num<=noOfRec)
				{
					row3 = (HSSFRow) rows2.next();
					for(int k = row3.getFirstCellNum();k<25;k++)
					if(row3.getCell(k)==null)
					{
						SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Payment Amount IN THE FILE SHOULD BE ONLY NUMBER");
						//logger.info("Payment Amount SHOULD BE ONLY NUMBER");
						modelAndViewObj.addObject("error", "Invalid file ");
						modelAndViewObj.setViewName("bulk");
						return modelAndViewObj;
					}
					noOfRec++;
				}*/
				HSSFCell cell2;
				double cellValue2 = 0;
				Iterator<Row> rowIterator1 = sheet.iterator();
				HSSFRow row2 = (HSSFRow) rowIterator1.next();
							

				List<String> headersList=new ArrayList<String>();
				
				for (int j = row2.getFirstCellNum(); j <=25; j++)
				{	
				Cell cell=row2.getCell(j);
					if (cell != null) {
	   		cell.setCellType(
				Cell.CELL_TYPE_STRING);
	   	
					headersList.add(cell.getStringCellValue());
				}
   else
   {
	   SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Invalid File",original,null,null);
          logger.info("invalid file ");
			modelAndViewObj.addObject("error",
					"Invalid file  ");
			modelAndViewObj.setViewName("bulk");
			return modelAndViewObj;
   }
	   }
				String headerStatus=bulkDao.headerProc("BULK_UPLOAD",null,headersList);

				logger.info("header status is" +headerStatus);
				if(!(headerStatus.equalsIgnoreCase("SUCCESS")))
				{
					modelAndViewObj.addObject("error",
							"Invalid file WITH HEADER MISMATCH");
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
				}
				if(noOfRec==0)
				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT is zero",original,null,null);
		              logger.info("invalid file with no records");
						modelAndViewObj.addObject("error",
								"Invalid file with no records");
						modelAndViewObj.setViewName("bulk");
						return modelAndViewObj;
				}
				if(noOfRec>MAXIMUM_RECORDS_IN_FILE)
				{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT MORE THAN DEFINED",original,null,null);
	              logger.info("RECORD COUNT IS MORE THAN DEFINED");
					modelAndViewObj.addObject("error",
							"Count of Total records should not be more than"+MAXIMUM_RECORDS_IN_FILE);
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
				}
				logger.info("HEADERS LIST SIZE..." +headersList.size());
				row = (HSSFRow) rows.next();
				java.util.Date utilDate = new java.util.Date();
					java.sql.Date sqlDate = new java.sql.Date(
							utilDate.getTime());
					
					fileDetailsObj.setVendorUserId(session.getAttribute("userid").toString());//session
					
					fileDetailsObj.setVendorType(role);//session
					
					fileDetailsObj.setFileTYpe("Payment");
					fileDetailsObj.setPaymentMode(paymentMode);
					fileDetailsObj.setMode("GUI");

					
					
					while (rows.hasNext()) {
						try
						{
						row = (HSSFRow) rows.next();
						cell2 = row.getCell((short) 11);
						if(cell2!=null)
						row.getCell(11).setCellType(
								Cell.CELL_TYPE_STRING);
						if(row.getCell(11)!=null)
						{
						cell2 = row.getCell((short) 11);
						if(!cell2.getStringCellValue().isEmpty())
						cellValue2 = Double.parseDouble(cell2.getStringCellValue());

						sum = (sum + cellValue2);
						}
						
						fileDetailsObj.setPaymentAmount(Double.toString(sum));
						
						}catch(Exception e)
						{
							SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Payment Amount IN THE FILE SHOULD BE ONLY NUMBER",original,null,null);
							logger.info("Payment Amount SHOULD BE ONLY NUMBER");
							modelAndViewObj.addObject("error", "Payment Amount should be only Number");
							modelAndViewObj.setViewName("bulk");
							return modelAndViewObj;
						}
					}
					if(sum>MAXIMUM_AMOUNT_IN_FILE)
					{
						SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","PAYMENT AMOUNT MORE THAN DEFINED",original,null,null);
						 logger.info("Total Payment Amount IS MORE THAN DEFINED");
							modelAndViewObj.addObject("error",
									"Total Value in File should not be greater than"+MAXIMUM_AMOUNT_IN_FILE);
							modelAndViewObj.setViewName("bulk");
							return modelAndViewObj;
					}					

								
						
		       if(headerStatus.equalsIgnoreCase("SUCCESS")){
		    	   
		    		    	  
		    	   FileDetails fileDetailsObj1 = bulkDao.vendorDetails(fileDetailsObj);
		    		    	  
		    	   if(fileDetailsObj1.getErrorMsg().equalsIgnoreCase("SUCCESS"))
		    	   {
				
		    		   if (fileDetailsObj1.getStatus().equalsIgnoreCase("1")) {
	
							
						modelAndViewObj.addObject("status",
								fileDetailsObj1.getStatus());
						modelAndViewObj.addObject("fileId",
								fileDetailsObj1.getFileID());

						java.util.Date utilDate1 = new java.util.Date();
						java.sql.Date sqlDate1 = new java.sql.Date(
								utilDate1.getTime());
					int serialNo=0;
					List<BulkDetails> bulkList=new ArrayList<BulkDetails>();
							while (rowIterator1.hasNext()) {
								BulkDetails bd = new BulkDetails();
								
								row2 = (HSSFRow) rowIterator1.next();
								boolean isRowEmpty=isRowEmpty(row2);
								
								if(isRowEmpty)
								{
									
									rowIterator1.remove();
								}
								else
								{
								
								for (int j = row2.getFirstCellNum(); j <=25; j++) {
									
									bd.setFileID(fileDetailsObj.getFileID());
									bd.setInsertDate(sqlDate1);
									bd.setChangeDate(sqlDate1);
									bd.setChangeWho(userId);
									bd.setTransferType("PAYMENT");
						Cell cell=row2.getCell(j);
									if (j == 0) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											try
											{
												if(cell.getStringCellValue().length()>5)
											{
																				
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Serial No maximum length should be 5",original,null,null);
													logger.info("Serial No maximum length should be 10");
													modelAndViewObj.addObject("error", "Invalid File:Serial No maximum length should be 5");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
											
											}
											Long.parseLong(cell
													.getStringCellValue());
											}
											catch(Exception e)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","SERIAL NO IN THE FILE SHOULD BE ONLY NUMBER",original,null,null);
												logger.info("SERIAL NUMBER SHOULD BE ONLY NUMBER");
												modelAndViewObj.addObject("error", "Serial Number should be only number");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										serialNo++;
										bd.setsNo(Integer.toString(serialNo));
								
										}
									} else if (j == 1) {

										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setServiceType( (cell
													.getStringCellValue()));
										}
									} else if (j == 2) {
										try{
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
																					
										
														  try {
														//		date = new SimpleDateFormat("MM/dd/yyyy").parse(row2.getCell(j).getStringCellValue());
																// java.sql.Date sqlDate13 = new java.sql.Date(row2.getCell(j).getDateCellValue().getTime());
															     String dateString=cell.getStringCellValue();
                                                            if(dateString.length()>10||!(dateString.matches(dateRegex)))
														{
															SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Trans date the File should be only Date",original,null,null);
															logger.info("Trans Date should be only date");
															modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
															modelAndViewObj.setViewName("bulk");
															 fileDetailsObj.getConnection().close();
															return modelAndViewObj;
														}
																 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
																 Date  date =  sdf.parse(dateString); 
																 java.sql.Date sqlDate13 = new java.sql.Date(date.getTime());
																bd.setPaymentDate(sqlDate13);
																
																	String subString2= dateString.substring(0, 2);
																	
																	String subString3= dateString.substring(3, 5);
																	boolean status1=true;
																	boolean status2=true;
																	
																	
																	if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
																	status1=false;
																	if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
																	status2=false;
																	if(!(status1&&status2))
																	{
																		modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																		modelAndViewObj.setViewName("bulk");
																		 fileDetailsObj.getConnection().close();
																		return modelAndViewObj;
																	}
																	
																	
																	
															 /* DateFormat d
															  * ateFormat = new SimpleDateFormat("MM/dd/yyyy");
															
															  String datestring = dateFormat.format(row2.getCell(j).getDateCellValue()); 
																																											     
															         Date date2 = dateFormat.parse(datestring);
															         System.out
																			.println("date"+datestring);*/
															    
																
													        } catch (Exception ex) {
													        	ex.printStackTrace();
													        	SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Trans date IN THE FILE SHOULD BE ONLY Date",original,null,null);
																logger.info("Trans Date SHOULD BE ONLY date");
																modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																modelAndViewObj.setViewName("bulk");
																 fileDetailsObj.getConnection().close();
																return modelAndViewObj;
													        }

													//	  bd.setPaymentDate(null);
											      
													
													
												}
										}
										catch(Exception ex)
										{
											ex.printStackTrace();
											SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Trans date IN THE FILE SHOULD BE ONLY Date",original,null,null);
											logger.info("Trans Date SHOULD BE  Date");
											modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid");
											modelAndViewObj.setViewName("bulk");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
									} else if (j == 3) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setPaymentMode(cell
													.getStringCellValue());
											
										}
									} else if (j == 4) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setCircle(cell
													.getStringCellValue());
                                          if(bd.getCircle().length()>10)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Deposit Circle maximum length should be 10",original,null,null);
												logger.info("Deposit Circle maximum length should be 10");
												modelAndViewObj.addObject("error", "Invalid File:Deposit Circle maximum length should be 10");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											
										}
									} else if (j == 5) {

										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setAcctEXTID(cell
													.getStringCellValue());
											if(bd.getAcctEXTID().length()>75)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Account no length should be maximum 80",original,null,null);
												logger.info("Account No SHOULD BE  max 20");
												modelAndViewObj.addObject("error", "Invalid File:Account No length should be Maximum 80");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											
										}
									} else if (j == 6) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setDelNO(cell
													.getStringCellValue());
											if(bd.getDelNO().length()>20)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Del no length should be maximum 20",original,null,null);
												logger.info("Del no SHOULD BE  Max 20 digits");
												modelAndViewObj.addObject("error", "Invalid File:Del No length should be Maximum 20");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										
										}
										
										if((bd.getDelNO()==null || bd.getDelNO().isEmpty() || bd.getDelNO().equals("0")) &&  (bd.getAcctEXTID()==null || bd.getAcctEXTID().isEmpty() || bd.getAcctEXTID().equals("0")))
										{
											SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Either Del no or Account External ID should be Valid",original,null,null);
											logger.info("Either Del no or Account External ID should be Valid");
											modelAndViewObj.addObject("error", "Either Del no or Account External ID should be Valid");
											modelAndViewObj.setViewName("bulk");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
										
									}else if (j == 7) {
												if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
													cell.setCellType(
															Cell.CELL_TYPE_STRING);
													try
													{
														
														bd.setInvoiceNo(cell
																.getStringCellValue());
														if(bd.getInvoiceNo().length()>20)
														{
															SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Invoice no length should be maximum 20",original,null,null);
															logger.info("Invoice Number max length is 20 ");
															modelAndViewObj.addObject("error", "Invalid File:Invoice No length should be Maximum 20");
															modelAndViewObj.setViewName("bulk");
															 fileDetailsObj.getConnection().close();
															return modelAndViewObj;
														}
                                                      Long.parseLong(cell
															.getStringCellValue());
													}
													catch(Exception e)
													{
														SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","INVOICE NUMBER IN THE FILE SHOULD BE ONLY NUMBER",original,null,null);
														logger.info("INVOICE NUMBER SHOULD BE ONLY NUMBER");
														modelAndViewObj.addObject("error", "Invoice should be only number");
														modelAndViewObj.setViewName("bulk");
														 fileDetailsObj.getConnection().close();
														return modelAndViewObj;
													}
													
												}
									} else if (j == 8) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
																					
										
														  try {
														//		date = new SimpleDateFormat("MM/dd/yyyy").parse(row2.getCell(j).getStringCellValue());
																// java.sql.Date sqlDate13 = new java.sql.Date(row2.getCell(j).getDateCellValue().getTime());
															     String dateString=cell.getStringCellValue();
                                                             if(dateString.length()>10||!(dateString.matches(dateRegex)))
																{
																  SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Cheque Date the File should be only  Date",original,null,null);
																	logger.info("Cheque Date should be only date");
																	modelAndViewObj.addObject("error", "Invalid File:Cheque Date Format should be valid(MM/DD/YYYY)");
																	modelAndViewObj.setViewName("bulk");
																	 fileDetailsObj.getConnection().close();
																	return modelAndViewObj;
																}
																 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
																 Date  date =  sdf.parse(dateString); 
																 java.sql.Date sqlDate13 = new java.sql.Date(date.getTime());
																bd.setChequeDate(sqlDate13);
																 

																	String subString2= dateString.substring(0, 2);
																	
																	String subString3= dateString.substring(3, 5);
																	boolean status1=true;
																	boolean status2=true;
																	
																	
																	if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
																	status1=false;
																	if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
																	status2=false;
																	if(!(status1&&status2))
																	{
																		modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																		modelAndViewObj.setViewName("bulk");
																		 fileDetailsObj.getConnection().close();
																		return modelAndViewObj;
																	}
																	
																	
																	
															 /* DateFormat d
															  * ateFormat = new SimpleDateFormat("MM/dd/yyyy");
															
															  String datestring = dateFormat.format(row2.getCell(j).getDateCellValue()); 
																																											     
															         Date date2 = dateFormat.parse(datestring);
															         System.out
																			.println("date"+datestring);*/
															    
																
													        } catch (Exception ex) {
													        	ex.printStackTrace();
													        	SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Trans date IN THE FILE SHOULD BE ONLY Date",original,null,null);
																logger.info("Trans Date SHOULD BE ONLY date");
																modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																modelAndViewObj.setViewName("bulk");
																 fileDetailsObj.getConnection().close();
																return modelAndViewObj;
													        }

													//	  bd.setPaymentDate(null);
											      
													
													
												}
										}
										else if (j == 9) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);
												bd.setChequeNo(cell
														.getStringCellValue());
                                              if(bd.getChequeNo().length()>15)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Cheque No maximum length should be  15",original,null,null);
													logger.info("Cheque No maximum length should be  15");
													modelAndViewObj.addObject("error", "Invalid File:Cheque No maximum length should be  15");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
												
											}
										
									} else if (j == 10) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setRemitterBranch(cell
													.getStringCellValue());
                                          if(bd.getRemitterBranch().length()>150)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Bank Name maximum length should be  150",original,null,null);
												logger.info("Bank Name maximum length should be  150");
												modelAndViewObj.addObject("error", "Invalid File:Bank Name maximum length should be  150");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									 else if (j == 11) {
										 if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										 cell.setCellType(
													Cell.CELL_TYPE_STRING);
											try
											{
												
											bd.setPaymentAmt(cell.getStringCellValue());
                                              if(bd.getPaymentAmt().length()>18)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Amount size should be maximum 18",original,null,null);
												logger.info("Payment Amount size should be maximum 18");
												modelAndViewObj.addObject("error", "Payment Amount maximum size should be  18");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
                                              Double.parseDouble(cell.getStringCellValue());
											}
											catch(Exception e)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","PAYMENT AMOUNT SHOULD BE ONLY NUMBER",original,null,null);
												logger.info("PAYMENT AMOUNT SHOULD BE ONLY NUMBER");
												modelAndViewObj.addObject("error", "Amount should be only number");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											}}
										
									
									 else if (j == 12) {
										 if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											 cell.setCellType(
														Cell.CELL_TYPE_STRING);
												bd.setPaymentCurrency(cell
														.getStringCellValue());
												
																								
											}
										}
									 else if (j == 13) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												 cell.setCellType(
															Cell.CELL_TYPE_STRING);
													try
													{
														
													bd.setExchangeRate(cell.getStringCellValue());
                                                      if(bd.getExchangeRate().length()>10)
													{
														SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Exchange rate maximum length should be 10",original,null,null);
														logger.info("Exchange rate maximum length should be 10");
														modelAndViewObj.addObject("error", "Exchange rate maximum length should be 10");
														modelAndViewObj.setViewName("bulk");
														 fileDetailsObj.getConnection().close();													
														return modelAndViewObj;
													}
                                                      if(!bd.getExchangeRate().matches(exchangerateregex))
													{
														SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Exchange rate should be only number with defined format",original,null,null);
														logger.info("Exchange rate should be only number with defined format");
														modelAndViewObj.addObject("error", "Exchange rate should be only number with defined format");
														modelAndViewObj.setViewName("bulk");
														 fileDetailsObj.getConnection().close();													
														return modelAndViewObj;
													}
												//	Double.parseDouble(cell.getStringCellValue());
													}
													catch(Exception e)
													{
														SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","EXCHANGE RATE SHOULD BE ONLY NUMBER",original,null,null);
														logger.info("EXCHANGE RATE SHOULD BE ONLY NUMBER");
														modelAndViewObj.addObject("error", "Exchange rate should be only number");
														modelAndViewObj.setViewName("bulk");
														 fileDetailsObj.getConnection().close();													
														return modelAndViewObj;
													}
											}
										}
									 else if (j == 14) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);

												bd.setPaymentDetails2(cell
														.getStringCellValue());
                                              if(bd.getPaymentDetails2().length()>150)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Bank Branch Name maximum length should be  150",original,null,null);
													logger.info("Bank Branch Name maximum length should be  150");
													modelAndViewObj.addObject("error", "Invalid File:Bank Branch Name maximum length should be  150");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
											}
										}
									 else if (j == 15) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);

												bd.setBankVirtualAcctNo(cell
														.getStringCellValue());
                                              if(bd.getBankVirtualAcctNo().length()>100)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Bank Account Number maximum length should be  100",original,null,null);
													logger.info("Bank Account Number maximum length should be  100");
													modelAndViewObj.addObject("error", "Invalid File:Bank Account Number maximum length should be  100");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
											}
										}
									 else if (j == 16) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);

												bd.setRemitterIfsc(cell
														.getStringCellValue());
                                              if(bd.getRemitterIfsc().length()>15)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","IFSC code maximum length should be  15",original,null,null);
													logger.info("IFSC code maximum length should be  15");
													modelAndViewObj.addObject("error", "Invalid File:IFSC code maximum length should be  15");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
											}
										}
									
				
									 else if (j == 17) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);

												bd.setLockboxID(cell
														.getStringCellValue());
                                              if(bd.getLockboxID().length()>25)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Source (Drop Box-id /TID) maximum length should be  25",original,null,null);
													logger.info("Source (Drop Box-id /TID) maximum length should be  25");
													modelAndViewObj.addObject("error", "Invalid File:Source (Drop Box-id /TID) maximum length should be  25");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
											}
										} else if (j == 18) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);

												bd.setRemitterName(cell
														.getStringCellValue());
                                              if(bd.getRemitterName().length()>150)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Remitter Name maximum length should be  150",original,null,null);
													logger.info("Remitter Name maximum length should be  150");
													modelAndViewObj.addObject("error", "Invalid File:Remitter Name maximum length should be  150");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
											}
										} else if (j == 19) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);

												bd.setDepositSlipNo(cell
														.getStringCellValue());
												//Geeta change length of deposit slip no 10 to 15
                                              if(bd.getDepositSlipNo().length()>15)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Deposit Slip Number maximum length should be  15",original,null,null);
													logger.info("Deposit Slip Number maximum length should be  15");
													modelAndViewObj.addObject("error", "Invalid File:Deposit Slip Number maximum length should be  15");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
											}
										} else if (j == 20) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);

												bd.setAnnotation(cell
														.getStringCellValue());
                                              if(bd.getAnnotation().length()>255)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Annotation maximum length should be  255",original,null,null);
													logger.info("Annotation maximum length should be  255");
													modelAndViewObj.addObject("error", "Invalid File:Annotation maximum length should be  255");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
											}
										} else if (j == 21) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);

												bd.setSRNo(cell
														.getStringCellValue());
                                              if(bd.getSRNo().length()>20)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","SR Number maximum length should be  20",original,null,null);
													logger.info("SR Number maximum length should be  20");
													modelAndViewObj.addObject("error", "Invalid File:SR Number maximum length should be  20");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
											}
										} else if (j == 22) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);

												try
												{
													
												bd.setOrderNo(cell.getStringCellValue());
                                                  if(bd.getOrderNo().length()>15)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Order Number maximum length should be  15",original,null,null);
													logger.info("Order Number maximum length should be  15");
													modelAndViewObj.addObject("error", "Invalid File:Order Number maximum length should be  15");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
                                                  Double.parseDouble(cell.getStringCellValue());
												}
												catch(Exception e)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","ORDER NUMBER SHOULD BE ONLY NUMBER",original,null,null);
													logger.info("ORDER NUMBER SHOULD BE ONLY NUMBER");
													modelAndViewObj.addObject("error", "Order Number should be only number");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
											}
										}
										else if (j == 23) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);

												try
												{
													
												bd.setCircuitId((cell.getStringCellValue()));
                                                  if(bd.getCircuitId().length()>15)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Circuit ID maximum length should be  15",original,null,null);
													logger.info("Circuit ID maximum length should be  15");
													modelAndViewObj.addObject("error", "Invalid File:Circuit ID maximum length should be  15");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
                                                  Double.parseDouble(cell.getStringCellValue());
												}
												catch(Exception e)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","CIRCUIT ID SHOULD BE ONLY NUMBER",original,null,null);
													logger.info("CIRCUIT ID SHOULD BE ONLY NUMBER");
													modelAndViewObj.addObject("error", "circuit id should be only number");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
											}
										}
										else if (j == 24) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);

												try
												{
													
												bd.setServiceNo((cell.getStringCellValue()));
                                                  if(bd.getServiceNo().length()>15)
													{
														SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Service Number maximum length should be  15",original,null,null);
														logger.info("Service Number maximum length should be  15");
														modelAndViewObj.addObject("error", "Invalid File:Service Number maximum length should be  15");
														modelAndViewObj.setViewName("bulk");
														 fileDetailsObj.getConnection().close();
														return modelAndViewObj;
													}
                                                  Double.parseDouble(cell.getStringCellValue());
												}
												catch(Exception e)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","SERVICE NUMBER SHOULD BE ONLY NUMBER",original,null,null);
													logger.info("SERVICE NUMBER SHOULD BE ONLY NUMBER");
													modelAndViewObj.addObject("error", "service Number should be only number");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
											}
										}
										else if (j == 25) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);

												bd.setReceiverName(cell
														.getStringCellValue());
                                              if(bd.getReceiverName().length()>150)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Customer name maximum length should be  150",original,null,null);
													logger.info("Customer name maximum length should be  150");
													modelAndViewObj.addObject("error", "Invalid File:Customer name maximum length should be  150");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
											}
										}
								}
								
							
								bulkList.add(bd);
								}	
							
							}
							System.out.println("Records fed to List object:"+bulkList.size());
							int b = bulkDao.insertDetails(bulkList,fileDetailsObj1.getConnection(),fileDetailsObj1.getTransactionDef(),fileDetailsObj1.getTransactionManager(),fileDetailsObj1.getTransaction());
							if(b==0){
								
								isValidTrans=false;
							//	break;
							}
							else{
								logger.info("INSERTED into records table");
								isValidTrans=true;
							}
							if(isValidTrans){
								fileDetailsObj.setConnection(fileDetailsObj1.getConnection());
								fileDetailsObj.setTransaction(fileDetailsObj1.getTransaction());
								fileDetailsObj.setTransactionManager(fileDetailsObj1.getTransactionManager());
								fileDetailsObj.setTransactionDef(fileDetailsObj1.getTransactionDef());
								fileDetailsObj2 = bulkDao
										.recordCheckxls(fileDetailsObj,errorFilesPath,extension);
											
							
								if(fileDetailsObj2.getErrorMsg().equalsIgnoreCase("SUCCESS"))
                            {
									logger.info("RECORD CHECK SUCCESFULL");
									if(fileDetailsObj2.getStatus()==null)
									{
										logger.info("validations are succesfull");
										SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","success"," file Upload and validations successfull",original,null,null);
										 BulkUtil.fileUpload(file,downloadpath,fileDetailsObj1.getOriginalFileName(),extension);
										 
										 /* Email for request pending for cheque*/
										 File fileObj=new File(homePath+File.separator+"Conf"+File.separator+"EmailAlertsTemplates"+File.separator+"PaymentPostingRequestPendingStatusAlert.properties");
										 InputStream inputStream=new FileInputStream(fileObj);
										 Properties properties=new Properties();
										 properties.load(inputStream);
										 
										 
										//added for testing amount
										 DecimalFormat df = new DecimalFormat("#");
									     df.setMaximumFractionDigits(2);
									     //System.out.println(df.format(d));
									     logger.info("sending mail #####################-->>>fileDetailsObj1.getPaymentAmount() ->"+fileDetailsObj1.getPaymentAmount());
									   											 
									     String payAmount=null;
									     if(fileDetailsObj1.getPaymentAmount()!=null && !fileDetailsObj1.getPaymentAmount().isEmpty())
									     {
									    	 payAmount=fileDetailsObj1.getPaymentAmount();
									     }
									     else{
									    	 payAmount="0";
									     }
									     double paymentAmount=Double.valueOf(payAmount);

										 
										 
										 EMailContent emailContentObj=new EMailContent();
											
											emailContentObj.setEmailSubject(properties.getProperty("emailSubject").replace(":PayMode", "Cheque")+" "+getDateTime());
											emailContentObj.setEmailHeader(properties.getProperty("emailHeader"));
											emailContentObj.setEmailBody(properties.getProperty("emailBody").replace("A", fileDetailsObj1.getFileID()).replace(" : B",Integer.toString(fileDetailsObj1.getTotalRecords())).replace(" : C", (df.format(paymentAmount))).replace("<userid>",userId).replace("<filename>", fileDetailsObj1.getOriginalFileName()));
											emailContentObj.setEmailFooter(properties.getProperty("emailFooter"));
											
											List<String> emailToList=bulkDao.getSupervisorEmailIds(userId,role);
											
											emailContentObj.setEmailToList(emailToList);
											
											/*List<String> emailCCList=new ArrayList<String>();
											//emailCCList.add("chaitanya.yandrapalli@tcs.com");
											emailCCList.add("teja.illa@tcs.com");
											
											emailContentObj.setEmailCCList(emailCCList);
											
											emailContentObj.setEmailBCCList(emailCCList);*/
											
											/*emailContentObj.setAttachmentRequired(true);
											
											List<EmailAttachment> emailAttachmentList=new ArrayList<EmailAttachment>();
											
											EmailAttachment emailAttachmentObj1=new EmailAttachment();
											emailAttachmentObj1.setAttachmentName(fileDetailsObj2.getOriginalFileName());
											emailAttachmentObj1.setAttachmentPath(downloadpath);
											emailAttachmentList.add(emailAttachmentObj1);
											
											EmailAttachment emailAttachmentObj2=new EmailAttachment();
											emailAttachmentObj2=new EmailAttachment();
											emailAttachmentObj2.setAttachmentName("Payment_Advice_Upload.xls");
											emailAttachmentObj2.setAttachmentPath(downloadpath);
											emailAttachmentList.add(emailAttachmentObj2);
											
											
											EmailAttachment emailAttachmentObj3=new EmailAttachment();
											emailAttachmentObj3.setAttachmentPath(downloadpath);
											emailAttachmentObj3.setAttachmentName("CPS Functionality Document _ 1705.pdf");
											emailAttachmentList.add(emailAttachmentObj3);
											
											EmailAttachment emailAttachmentObj4=new EmailAttachment();
											emailAttachmentObj4=new EmailAttachment();
											emailAttachmentObj4.setAttachmentPath(downloadpath);
											emailAttachmentObj4.setAttachmentName("Minstatmbc ppt.odp");
											emailAttachmentList.add(emailAttachmentObj4);
											
											emailContentObj.setEmailAttachmentList(emailAttachmentList);*/
			                              /* emailContentObj.setAttachmentRequired(true);
											
											List<EmailAttachment> emailAttachmentList=new ArrayList<EmailAttachment>();
											
											EmailAttachment emailAttachmentObj1=new EmailAttachment();
											emailAttachmentObj1.setAttachmentName(fileDetailsObj2.getOriginalFileName());
											emailAttachmentObj1.setAttachmentPath(downloadpath);
											emailAttachmentList.add(emailAttachmentObj1);
											emailContentObj.setEmailAttachmentList(emailAttachmentList);*/
											
											SmtpUtility.setLogger(logger);
											
											SmtpMailContent smtpMailContentObj=SmtpUtility.generateEmailAlert(emailContentObj);
											
											System.out.println("Error Code "+smtpMailContentObj.getErrorCode());
											System.out.println(" Error Message "+smtpMailContentObj.getErrorMessage());
											
										    logger.info("File has been uploaded succesfully ");
										    logger.info("File upload success and pending for Approval");
								
									}else
									{	
										logger.info("validations are not succesfull");
										SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","file Upload Success but validations failed",original,null,null);
									
									}
                            	                            	
							
                               fileDetailsObj.getConnection().commit();
                               fileDetailsObj.getTransactionManager().commit(fileDetailsObj.getTransaction());
                         
                               fileDetailsObj.getConnection().close();
             

                            }
                            else
                            {
                            	
                            	logger.info("File has been  not uploaded because of data failure issues ");
                            	
                            	fileDetailsObj.getTransactionManager().rollback(fileDetailsObj.getTransaction());
                            	fileDetailsObj.getConnection().close();
                            	SNo=activityLogDao.insertActivityLog(SNo,userId,"file uploading","failed","FAILED DUE TO DATA FAILURE ISSUES",original,null,null);
								 modelAndViewObj.addObject("error","File with different format");
								 modelAndViewObj.setViewName("bulk");
								                                                       
								 return modelAndViewObj;
                            }
							
							
								logger.info("File upload success and pending for Approval");

								modelAndViewObj.addObject("status",
									fileDetailsObj2.getStatus());
							 modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj1);
							 modelAndViewObj.addObject("extension", extension);
								modelAndViewObj.setViewName("bulkUploadSuccess");
								logger.info("END OF UPLOAD OF CHEQUE FORMAT");

							}
							else{
								logger.info("records are not inserted because of data failure issues");
								SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","Failure","FAILED DUE TO DATA FAILURE ISSUES",original,null,null);
								 modelAndViewObj.addObject("error","data failure issues");
								 modelAndViewObj.setViewName("bulk");
								 fileDetailsObj.getConnection().close();                     
								 return modelAndViewObj;
							}
	
					} else

					{
						logger.info("FILE ALREADY UPLOADED");
						// System.out.println("Given header amount and sum of all the records are not matched..!!!");
						 SNo=activityLogDao.insertActivityLog(SNo,userId,"file uploading","failure","FILE WITH SAME NAME ALREADY UPLOADED",original,null,null);
					
						 modelAndViewObj.addObject("error", "Invalid File:FileName cannot be same ");
						modelAndViewObj.setViewName("bulk");
						 fileDetailsObj.getConnection().close();
						return modelAndViewObj;
					}
					}
		    	   else
		    	   {
		    		   SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","Failure","FAILED DUE TO DATA FAILURE ISSUES",original,null,null);
		    		   logger.info("file  details has not been inserted into status table because of data failure issues"+fileDetailsObj1.getErrorMsg());
	    		   modelAndViewObj.addObject("error", "database  failure issues");
	    		   modelAndViewObj.setViewName("bulk");
	    		   fileDetailsObj.getConnection().close();
	    		   return modelAndViewObj;// main if sumCountHeader==sum closed
		    	   }// main if sumCountHeader==sum closed
					
				} else

				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","failure","HEADERS ARE NOT MATCHED IN THE UPLOADED FILE",original,null,null);
				
					System.out
							.println("Given header is not macthed");
					logger.info("Given header is not macthed");

					modelAndViewObj.addObject("error", "Invalid file:Headers are Not Matched");
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
				}
			
				
			}

			catch (Exception e) {
				//logger.error(null, e.printStackTrace());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("error", "invalid file");
				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
				
			}

		}

		else {
			try{
			SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","valid xls file","file is null",original,null,null);
			}catch(SQLException sqlexception)
			{
				sqlexception.printStackTrace();
				modelAndViewObj.addObject("message","DB Connectivity issues");
				modelAndViewObj.setViewName("Error");
				return modelAndViewObj;
			}
			
			logger.info("File is not valid!!");

			modelAndViewObj.addObject("error", "UPLOADED FILE IS EMPTY");
			modelAndViewObj.setViewName("bulk");
			return modelAndViewObj;
		}
		return modelAndViewObj;
		
		
	}
	public  ModelAndView validatexlsx(
			 MultipartFile file,
			HttpServletRequest request,String downloadpath,String errorFilesPath, String extension) 
	{
		session=request.getSession(true);
		FileDetails fileDetailsObj=new FileDetails();
		boolean isValidTrans=false;
		FileDetails fileDetailsObj2=null;
	String userId = session.getAttribute("userid").toString();
	String original = file.getOriginalFilename();
	String role=session.getAttribute("user_role_id").toString();
	fileDetailsObj.setOriginalFileName(original);
    String exchangerateregex="[0-9][0-9]?[0-9]?[0-9]?+(\\.[0-9]?[0-9]?[0-9]?[0-9]?[0-9]?[0-9]?)?";
	String dateRegex="[0-9][0-9][\\/][0-9][0-9][\\/][0-9]{4}";
	logger.info("original file name is:" + original);

	fileDetailsObj.setFinalFileName(userId
			+ file.getOriginalFilename());
	logger.info("final name is ....."
			+ fileDetailsObj.getFinalFileName());
	ModelAndView modelAndViewObj=new ModelAndView();
	boolean recordCount = BulkUtil.validateRecordCount(file);
	Long SNo=0l;
	try{
		SNo=activityLogDao.insertActivityLog(0l,userId,"file upload",null,null,original,null,null);
	}catch(SQLException sqlexception)
	{
		sqlexception.printStackTrace();
		modelAndViewObj.addObject("message","DB Connectivity issues");
		modelAndViewObj.setViewName("Error");
		return modelAndViewObj;
	}
	if (recordCount) {
		try {

			InputStream file1 = (file
					.getInputStream());

			//Workbook workbook = WorkbookFactory.create(file1);
			//XSSFWorkbook workbook=(XSSFWorkbook) WorkbookFactory.create(file1);
          Workbook workbook = new XSSFWorkbook(file1);
          XSSFSheet  sheet = (XSSFSheet) workbook.getSheetAt(0);
		//	org.apache.poi.xssf.usermodel.XSSFSheet  sheet = workbook.getSheetAt(0);

			logger.info("Present Sheet name is" + "\t"
					+ workbook.getSheetName(0));

	//		Iterator<Row> rows1 = sheet.rowIterator();

//	      Row row1 = rows1.next();
			int noOfRec = sheet.getPhysicalNumberOfRows() - 1;
			
			fileDetailsObj.setTotalRecords(noOfRec);
			logger.info("total records "+fileDetailsObj.getTotalRecords());
			

			System.out.println("\n no of rec " + noOfRec);
			if(noOfRec==-1)
			{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT is zero",original,null,null);
	              logger.info("invalid file with no records");
					modelAndViewObj.addObject("error",
							"Invalid file with no records");
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
			}
			Iterator<Row> rowIterator1 = sheet.iterator();
			XSSFRow row2 = (XSSFRow) rowIterator1.next();
						
			List<String> headersList=new ArrayList<String>();
			
					for (int j = row2.getFirstCellNum(); j <=25; j++)
					{	
						Cell cell=row2.getCell(j);
		if (cell != null) {
		   		cell.setCellType(
					Cell.CELL_TYPE_STRING);
						headersList.add(cell.getStringCellValue());
					}
		else
		{
		   SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Invalid File",original,null,null);
		      logger.info("invalid file ");
				modelAndViewObj.addObject("error",
						"Invalid file  ");
				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
		}
		   }
					String headerStatus=bulkDao.headerProc("BULK_UPLOAD",null,headersList);

	                logger.info("header status is" +headerStatus);	
	                if(!(headerStatus.equalsIgnoreCase("SUCCESS")))
	                {
	                	modelAndViewObj.addObject("error",
	    						"HEADER NOT MATCHED");
	    				modelAndViewObj.setViewName("bulk");
	    				return modelAndViewObj;	
	                }
	                if(noOfRec==0)
	    			{
	    				SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT is 0",original,null,null);
	    	              logger.info("invalid file with no records");
	    					modelAndViewObj.addObject("error",
	    							"Invalid file with no records");
	    					modelAndViewObj.setViewName("bulk");
	    					return modelAndViewObj;
	    			}
	    			
					if(noOfRec>MAXIMUM_RECORDS_IN_FILE)
					{
			SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","Failure","RECORD COUNT MORE THANK DEFINED VALUE",original,null,null);
			logger.info("record count has exceeded");
						modelAndViewObj.addObject("error",
								"Count of Total records should not be more than"+MAXIMUM_RECORDS_IN_FILE);
						modelAndViewObj.setViewName("bulk");
						return modelAndViewObj;
					}
   
			double sum = 0;

			XSSFRow row = null;

			Iterator<Row> rows = sheet.rowIterator();

			row =  (XSSFRow) rows.next();
			

			Cell cell2;
			double cellValue2 = 0;

				while (rows.hasNext()) {
				try
				{
				row = (XSSFRow) rows.next();
				cell2 = row.getCell((short) 11);
				if(cell2!=null)
			
			row.getCell(11).setCellType(
					Cell.CELL_TYPE_STRING);
				if(row.getCell(11)!=null)
				{
					
				

				cell2 = row.getCell((short) 11);
				if(!cell2.getStringCellValue().isEmpty())
				cellValue2 = Double.parseDouble(cell2.getStringCellValue());

				sum = (sum + cellValue2);
				}
				
				
				}catch(Exception e)
				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Payment Amount IN THE FILE SHOULD BE ONLY NUMBER",original,null,null);
					logger.info("Payment Amount SHOULD BE ONLY NUMBER");
					modelAndViewObj.addObject("error", "Payment Amount should be only Number");
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
				}
			}
			if(sum>MAXIMUM_AMOUNT_IN_FILE)
			{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","Failure","PAYMENT AMOUNT IS MORE THAN DEFINED",original,null,null);
				 logger.info("Total Payment Amount IS MORE THAN DEFINED");
					modelAndViewObj.addObject("error",
							"Total Value in File should not be greater than"+MAXIMUM_AMOUNT_IN_FILE);
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
			}

			

				java.util.Date utilDate = new java.util.Date();
				java.sql.Date sqlDate = new java.sql.Date(
						utilDate.getTime());
			
				
				fileDetailsObj.setVendorUserId(userId);
				
				fileDetailsObj.setVendorType(role);//session
				fileDetailsObj.setPaymentAmount(Double.toString(sum));
				fileDetailsObj.setFileTYpe("Payment");
				String paymentMode="CHEQUE";
				fileDetailsObj.setPaymentMode(paymentMode);
				fileDetailsObj.setMode("GUI");
			

					
	       if(headerStatus.equalsIgnoreCase("SUCCESS")){
	    	
	    	
	    	
	    	   FileDetails fileDetailsObj1 = bulkDao.vendorDetails(fileDetailsObj);
	    	  
	    	   if(fileDetailsObj1.getErrorMsg().equalsIgnoreCase("SUCCESS"))
	    	   {
	    	
	
           if (fileDetailsObj1.getStatus().equalsIgnoreCase("1")) {

					modelAndViewObj.addObject("status",
							fileDetailsObj1.getStatus());
					modelAndViewObj.addObject("fileId",
							fileDetailsObj1.getFileID());

					

					java.util.Date utilDate1 = new java.util.Date();
					java.sql.Date sqlDate1 = new java.sql.Date(
							utilDate1.getTime());
				int serialNo=0;
				List<BulkDetails> bulkList=new ArrayList<BulkDetails>();
						while (rowIterator1.hasNext()) {
							BulkDetails bd = new BulkDetails();
							
							row2 = (XSSFRow) rowIterator1.next();
							boolean isRowEmpty=isRowEmpty(row2);
							
							if(isRowEmpty)
							{
								
								rowIterator1.remove();
							}
							else
							{
							for (int j = row2.getFirstCellNum(); j <=25; j++) {
								
								bd.setFileID(fileDetailsObj.getFileID());
								bd.setInsertDate(sqlDate1);
								bd.setChangeDate(sqlDate1);
								bd.setChangeWho(userId);
								bd.setTransferType("PAYMENT");
								Cell cell=row2.getCell(j);
								if (j == 0) {
									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);
										try
										{
											if(cell.getStringCellValue().length()>5)
										{
																
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Serial No maximum length should be 5",original,null,null);
												logger.info("Serial No maximum length should be 5");
												modelAndViewObj.addObject("error", "Invalid File:Serial No maximum length should be 5");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
										
										}
										Long.parseLong(cell
												.getStringCellValue());
										}
										catch(Exception e)
										{
											SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","SERIAL NO IN THE FILE SHOULD BE ONLY NUMBER",original,null,null);
											logger.info("SERIAL NUMBER SHOULD BE ONLY NUMBER");
											modelAndViewObj.addObject("error", "Serial Number should be only number");
											modelAndViewObj.setViewName("bulk");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
									serialNo++;
									bd.setsNo(Integer.toString(serialNo));
							
									}
								} else if (j == 1) {

									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);
										bd.setServiceType( (cell
												.getStringCellValue()));
									}
								} else if (j == 2) {
									try{
									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);
																				
									
													  try {
													//		date = new SimpleDateFormat("MM/dd/yyyy").parse(row2.getCell(j).getStringCellValue());
															// java.sql.Date sqlDate13 = new java.sql.Date(row2.getCell(j).getDateCellValue().getTime());
														  String dateString=cell.getStringCellValue();
                                                         if(dateString.length()>10||!(dateString.matches(dateRegex)))
															{
																SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Trans date the File should be only Date",original,null,null);
																logger.info("Trans Date should be only date");
																modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																modelAndViewObj.setViewName("bulk");
																 fileDetailsObj.getConnection().close();
																return modelAndViewObj;
															}
															 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
															 Date  date =  sdf.parse(dateString); 
															 java.sql.Date sqlDate13 = new java.sql.Date(date.getTime());
															bd.setPaymentDate(sqlDate13);
															
																String subString2= dateString.substring(0, 2);
																
																String subString3= dateString.substring(3, 5);
																boolean status1=true;
																boolean status2=true;
																
																
																if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
																status1=false;
																if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
																status2=false;
																if(!(status1&&status2))
																{
																	modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																	modelAndViewObj.setViewName("bulk");
																	 fileDetailsObj.getConnection().close();
																	return modelAndViewObj;
																}
																
																
																
														 /* DateFormat d
														  * ateFormat = new SimpleDateFormat("MM/dd/yyyy");
														
														  String datestring = dateFormat.format(row2.getCell(j).getDateCellValue()); 
																																										     
														         Date date2 = dateFormat.parse(datestring);
														         System.out
																		.println("date"+datestring);*/
														    
															
												        } catch (Exception ex) {
												        	ex.printStackTrace();
												        	SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Trans date IN THE FILE SHOULD BE ONLY Date",original,null,null);
															logger.info("Trans Date SHOULD BE ONLY date");
															modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
															modelAndViewObj.setViewName("bulk");
															 fileDetailsObj.getConnection().close();
															return modelAndViewObj;
												        }

												//	  bd.setPaymentDate(null);
										      
												
												
											}
									}
									catch(Exception ex)
									{
										ex.printStackTrace();
										SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Trans date IN THE FILE SHOULD BE ONLY Date",original,null,null);
										logger.info("Trans Date SHOULD BE  Date");
										modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid");
										modelAndViewObj.setViewName("bulk");
										 fileDetailsObj.getConnection().close();
										return modelAndViewObj;
									}
								} else if (j == 3) {
									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);

										bd.setPaymentMode(cell
												.getStringCellValue());
										
									}
								} else if (j == 4) {
									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);
										bd.setCircle(cell
												.getStringCellValue());
                                      if(bd.getCircle().length()>10)
										{
											SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Deposit Circle maximum length should be 10",original,null,null);
											logger.info("Deposit Circle maximum length should be 10");
											modelAndViewObj.addObject("error", "Invalid File:Deposit Circle maximum length should be 10");
											modelAndViewObj.setViewName("bulk");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
										
									}
								} else if (j == 5) {

									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);

										bd.setAcctEXTID(cell
												.getStringCellValue());
										if(bd.getAcctEXTID().length()>75)
										{
											SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Account no length should be maximum 80",original,null,null);
											logger.info("Account No SHOULD BE  max 20");
											modelAndViewObj.addObject("error", "Invalid File:Account No length should be Maximum 80");
											modelAndViewObj.setViewName("bulk");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
										
									}
								} else if (j == 6) {
									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);
										bd.setDelNO(cell
												.getStringCellValue());
										if(bd.getDelNO().length()>20)
										{
											SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Del no length should be maximum 20",original,null,null);
											logger.info("Del no SHOULD BE  Max 20 digits");
											modelAndViewObj.addObject("error", "Invalid File:Del No length should be Maximum 20");
											modelAndViewObj.setViewName("bulk");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
									
									}
									if((bd.getDelNO()==null || bd.getDelNO().isEmpty() || bd.getDelNO().equals("0")) &&  (bd.getAcctEXTID()==null || bd.getAcctEXTID().isEmpty() || bd.getAcctEXTID().equals("0")))
									{
										SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Either Del no or Account External ID should be Valid",original,null,null);
										logger.info("Either Del no or Account External ID should be Valid");
										modelAndViewObj.addObject("error", "Either Del no or Account External ID should be Valid");
										modelAndViewObj.setViewName("bulk");
										 fileDetailsObj.getConnection().close();
										return modelAndViewObj;
									}
								}else if (j == 7) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);
												try
												{
													
													bd.setInvoiceNo(cell
															.getStringCellValue());
													if(bd.getInvoiceNo().length()>20)
													{
														SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Invoice no length should be maximum 20",original,null,null);
														logger.info("Invoice Number max length is 20 ");
														modelAndViewObj.addObject("error", "Invalid File:Invoice No length should be Maximum 20");
														modelAndViewObj.setViewName("bulk");
														 fileDetailsObj.getConnection().close();
														return modelAndViewObj;
													}
                                                  Long.parseLong(cell
														.getStringCellValue());
												}
												catch(Exception e)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","INVOICE NUMBER IN THE FILE SHOULD BE ONLY NUMBER",original,null,null);
													logger.info("INVOICE NUMBER SHOULD BE ONLY NUMBER");
													modelAndViewObj.addObject("error", "Invoice should be only number");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
												
											}
								} else if (j == 8) {
									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);
																				
									
													  try {
													//		date = new SimpleDateFormat("MM/dd/yyyy").parse(row2.getCell(j).getStringCellValue());
															// java.sql.Date sqlDate13 = new java.sql.Date(row2.getCell(j).getDateCellValue().getTime());
														  String dateString=cell.getStringCellValue();
                                                        if(dateString.length()>10||!(dateString.matches(dateRegex)))
															{
															  SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Cheque date should be only Date",original,null,null);
																logger.info("Cheque Date should be only date");
																modelAndViewObj.addObject("error", "Invalid File:Cheque Date Format should be valid(MM/DD/YYYY)");
																modelAndViewObj.setViewName("bulk");
																 fileDetailsObj.getConnection().close();
																return modelAndViewObj;
															}
															 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
															 Date  date =  sdf.parse(dateString); 
															 java.sql.Date sqlDate13 = new java.sql.Date(date.getTime());
															bd.setChequeDate(sqlDate13);
															 

																String subString2= dateString.substring(0, 2);
																
																String subString3= dateString.substring(3, 5);
																boolean status1=true;
																boolean status2=true;
																
																
																if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
																status1=false;
																if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
																status2=false;
																if(!(status1&&status2))
																{
																	modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																	modelAndViewObj.setViewName("bulk");
																	 fileDetailsObj.getConnection().close();
																	return modelAndViewObj;
																}
																
																
																
														 /* DateFormat d
														  * ateFormat = new SimpleDateFormat("MM/dd/yyyy");
														
														  String datestring = dateFormat.format(row2.getCell(j).getDateCellValue()); 
																																										     
														         Date date2 = dateFormat.parse(datestring);
														         System.out
																		.println("date"+datestring);*/
														    
															
												        } catch (Exception ex) {
												        	ex.printStackTrace();
												        	SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Trans date IN THE FILE SHOULD BE ONLY Date",original,null,null);
															logger.info("Trans Date SHOULD BE ONLY date");
															modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
															modelAndViewObj.setViewName("bulk");
															 fileDetailsObj.getConnection().close();
															return modelAndViewObj;
												        }

												//	  bd.setPaymentDate(null);
										      
												
												
											}
									}
									else if (j == 9) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setChequeNo(cell
													.getStringCellValue());
                                          if(bd.getChequeNo().length()>15)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Cheque No maximum length should be  15",original,null,null);
												logger.info("Cheque No maximum length should be  15");
												modelAndViewObj.addObject("error", "Invalid File:Cheque No maximum length should be  15");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											
										}
									
								} else if (j == 10) {
									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);

										bd.setRemitterBranch(cell
												.getStringCellValue());
                                      if(bd.getRemitterBranch().length()>150)
										{
											SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Bank Name maximum length should be  150",original,null,null);
											logger.info("Bank Name maximum length should be  150");
											modelAndViewObj.addObject("error", "Invalid File:Bank Name maximum length should be  150");
											modelAndViewObj.setViewName("bulk");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
									}
								}
								 else if (j == 11) {
									 if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
									 cell.setCellType(
												Cell.CELL_TYPE_STRING);
										try
										{
											
										bd.setPaymentAmt(cell.getStringCellValue());
                                          if(bd.getPaymentAmt().length()>18)
										{
											SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Amount size should be maximum 18",original,null,null);
											logger.info("Payment Amount size should be maximum 18");
											modelAndViewObj.addObject("error", "Payment Amount maximum size should be 18");
											modelAndViewObj.setViewName("bulk");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
                                          Double.parseDouble(cell.getStringCellValue());
										}
										catch(Exception e)
										{
											SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","PAYMENT AMOUNT SHOULD BE ONLY NUMBER",original,null,null);
											logger.info("PAYMENT AMOUNT SHOULD BE ONLY NUMBER");
											modelAndViewObj.addObject("error", "Amount should be only number");
											modelAndViewObj.setViewName("bulk");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
										}
									 }
									
								
								 else if (j == 12) {
									 if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										 cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setPaymentCurrency(cell
													.getStringCellValue());
											
																							
										}
									}
								 else if (j == 13) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											 cell.setCellType(
														Cell.CELL_TYPE_STRING);
												try
												{
													
												bd.setExchangeRate(cell.getStringCellValue());
                                                  if(bd.getExchangeRate().length()>11)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Exchange rate maximum length should be 11",original,null,null);
													logger.info("Exchange rate maximum length should be 11");
													modelAndViewObj.addObject("error", "Exchange rate maximum length should be 11");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();													
													return modelAndViewObj;
												}
                                                  if(!bd.getExchangeRate().matches(exchangerateregex))
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Exchange rate should be only number with defined format",original,null,null);
												logger.info("Exchange rate should be only number with defined format");
												modelAndViewObj.addObject("error", "Exchange rate should be only number with defined format");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();													
												return modelAndViewObj;
											}
                                             //     Double.parseDouble(cell.getStringCellValue());
												}
												catch(Exception e)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","EXCHANGE RATE SHOULD BE ONLY NUMBER",original,null,null);
													logger.info("EXCHANGE RATE SHOULD BE ONLY NUMBER");
													modelAndViewObj.addObject("error", "Exchange rate should be only number");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();													
													return modelAndViewObj;
												}
										}
									}
								 else if (j == 14) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setPaymentDetails2(cell
													.getStringCellValue());
                                          if(bd.getPaymentDetails2().length()>150)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Bank Branch Name maximum length should be  150",original,null,null);
												logger.info("Bank Branch Name maximum length should be  150");
												modelAndViewObj.addObject("error", "Invalid File:Bank Branch Name maximum length should be  150");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
								 else if (j == 15) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setBankVirtualAcctNo(cell
													.getStringCellValue());
                                          if(bd.getBankVirtualAcctNo().length()>100)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Bank Account Number maximum length should be  100",original,null,null);
												logger.info("Bank Account Number maximum length should be  100");
												modelAndViewObj.addObject("error", "Invalid File:Bank Account Number maximum length should be  100");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
								 else if (j == 16) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setRemitterIfsc(cell
													.getStringCellValue());
                                          if(bd.getRemitterIfsc().length()>15)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","IFSC code maximum length should be  15",original,null,null);
												logger.info("IFSC code maximum length should be  15");
												modelAndViewObj.addObject("error", "Invalid File:IFSC code maximum length should be  15");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
								
			
								 else if (j == 17) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setLockboxID(cell
													.getStringCellValue());
                                          if(bd.getLockboxID().length()>25)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Source (Drop Box-id /TID) maximum length should be  25",original,null,null);
												logger.info("Source (Drop Box-id /TID) maximum length should be  25");
												modelAndViewObj.addObject("error", "Invalid File:Source (Drop Box-id /TID) maximum length should be  25");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									} else if (j == 18) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setRemitterName(cell
													.getStringCellValue());
                                          if(bd.getRemitterName().length()>150)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Remitter Name maximum length should be  150",original,null,null);
												logger.info("Remitter Name maximum length should be  150");
												modelAndViewObj.addObject("error", "Invalid File:Remitter Name maximum length should be  150");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									} else if (j == 19) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setDepositSlipNo(cell
													.getStringCellValue());
                                          if(bd.getDepositSlipNo().length()>10)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Deposit Slip Number maximum length should be  10",original,null,null);
												logger.info("Deposit Slip Number maximum length should be  10");
												modelAndViewObj.addObject("error", "Invalid File:Deposit Slip Number maximum length should be  10");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									} else if (j == 20) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setAnnotation(cell
													.getStringCellValue());
                                          if(bd.getAnnotation().length()>255)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Annotation maximum length should be  255",original,null,null);
												logger.info("Annotation maximum length should be  255");
												modelAndViewObj.addObject("error", "Invalid File:Annotation maximum length should be  255");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									} else if (j == 21) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setSRNo(cell
													.getStringCellValue());
                                          if(bd.getSRNo().length()>20)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","SR Number maximum length should be  20",original,null,null);
												logger.info("SR Number maximum length should be  20");
												modelAndViewObj.addObject("error", "Invalid File:SR Number maximum length should be  20");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									} else if (j == 22) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											try
											{
												
											bd.setOrderNo(cell.getStringCellValue());
                                              if(bd.getOrderNo().length()>15)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Order Number maximum length should be  15",original,null,null);
												logger.info("Order Number maximum length should be  15");
												modelAndViewObj.addObject("error", "Invalid File:Order Number maximum length should be  15");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
                                              Double.parseDouble(cell.getStringCellValue());
											}
											catch(Exception e)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","ORDER NUMBER SHOULD BE ONLY NUMBER",original,null,null);
												logger.info("ORDER NUMBER SHOULD BE ONLY NUMBER");
												modelAndViewObj.addObject("error", "Order Number should be only number");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 23) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											try
											{
												
											bd.setCircuitId((cell.getStringCellValue()));
                                              if(bd.getCircuitId().length()>15)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Circuit ID maximum length should be  15",original,null,null);
												logger.info("Circuit ID maximum length should be  15");
												modelAndViewObj.addObject("error", "Invalid File:Circuit ID maximum length should be  15");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
                                              Double.parseDouble(cell.getStringCellValue());
											}
											catch(Exception e)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","CIRCUIT ID SHOULD BE ONLY NUMBER",original,null,null);
												logger.info("CIRCUIT ID SHOULD BE ONLY NUMBER");
												modelAndViewObj.addObject("error", "circuit id should be only number");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 24) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											try
											{
												
											bd.setServiceNo((cell.getStringCellValue()));
                                              if(bd.getServiceNo().length()>15)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Service Number maximum length should be  15",original,null,null);
													logger.info("Service Number maximum length should be  15");
													modelAndViewObj.addObject("error", "Invalid File:Service Number maximum length should be  15");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
                                              Double.parseDouble(cell.getStringCellValue());
											}
											catch(Exception e)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","SERVICE NUMBER SHOULD BE ONLY NUMBER",original,null,null);
												logger.info("SERVICE NUMBER SHOULD BE ONLY NUMBER");
												modelAndViewObj.addObject("error", "service Number should be only number");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 25) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setReceiverName(cell
													.getStringCellValue());
                                          if(bd.getReceiverName().length()>150)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Customer name maximum length should be  150",original,null,null);
												logger.info("Customer name maximum length should be  150");
												modelAndViewObj.addObject("error", "Invalid File:Customer name maximum length should be  150");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
							}
							bulkList.add(bd);
							}
							
						}
						int b = bulkDao.insertDetails(bulkList,fileDetailsObj1.getConnection(),fileDetailsObj1.getTransactionDef(),fileDetailsObj1.getTransactionManager(),fileDetailsObj1.getTransaction());
						
						if(b==0){
						//	fileDetailsObj1.getTransactionManager().rollback(fileDetailsObj1.getTransaction());
							isValidTrans=false;
						//	break;
						}
						else{
							
							isValidTrans=true;
						}
						if(isValidTrans){
							logger.info("INSERTED into records table");
							fileDetailsObj.setConnection(fileDetailsObj1.getConnection());
							fileDetailsObj.setTransaction(fileDetailsObj1.getTransaction());
							fileDetailsObj.setTransactionManager(fileDetailsObj1.getTransactionManager());
							fileDetailsObj.setTransactionDef(fileDetailsObj1.getTransactionDef());
							fileDetailsObj2 = bulkDao
									.recordCheckxlsx(fileDetailsObj,errorFilesPath,extension);
							
							
							
							if(fileDetailsObj2.getErrorMsg().equalsIgnoreCase("SUCCESS"))
                                {
								if(fileDetailsObj2.getStatus()==null)
								{
									logger.info("validations successfull in record check");
									SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","success","file upload and validations successful",original,null,null);
									 BulkUtil.fileUpload(file,downloadpath,fileDetailsObj1.getOriginalFileName(),extension);
									 /* Email for request pending for cheque*/
									 File fileObj=new File(homePath+File.separator+"Conf"+File.separator+"EmailAlertsTemplates"+File.separator+"PaymentPostingRequestPendingStatusAlert.properties");
									 InputStream inputStream=new FileInputStream(fileObj);
									 Properties properties=new Properties();
									 properties.load(inputStream);
									
									 
									//added for testing amount
									 DecimalFormat df = new DecimalFormat("#");
								     df.setMaximumFractionDigits(2);
								     //System.out.println(df.format(d));
								     logger.info("sending mail #####################-->>>fileDetailsObj1.getPaymentAmount() ->"+fileDetailsObj1.getPaymentAmount());
								   											 
								     String payAmount=null;
								     if(fileDetailsObj1.getPaymentAmount()!=null && !fileDetailsObj1.getPaymentAmount().isEmpty())
								     {
								    	 payAmount=fileDetailsObj1.getPaymentAmount();
								     }
								     else{
								    	 payAmount="0";
								     }
								     double paymentAmount=Double.valueOf(payAmount);

									 
									 EMailContent emailContentObj=new EMailContent();
										
										emailContentObj.setEmailSubject(properties.getProperty("emailSubject").replace(":PayMode", "Cheque")+" "+getDateTime());
										emailContentObj.setEmailHeader(properties.getProperty("emailHeader"));
										emailContentObj.setEmailBody(properties.getProperty("emailBody").replace("A", fileDetailsObj1.getFileID()).replace(" : B",Integer.toString(fileDetailsObj1.getTotalRecords())).replace(" : C", (df.format(paymentAmount))).replace("<userid>",userId).replace("<filename>", fileDetailsObj1.getOriginalFileName()));
										emailContentObj.setEmailFooter(properties.getProperty("emailFooter"));
										
										List<String> emailToList=bulkDao.getSupervisorEmailIds(userId,role);
									
										
										emailContentObj.setEmailToList(emailToList);
										
																			
										/*emailContentObj.setAttachmentRequired(true);
										
										List<EmailAttachment> emailAttachmentList=new ArrayList<EmailAttachment>();
										
										EmailAttachment emailAttachmentObj1=new EmailAttachment();
										emailAttachmentObj1.setAttachmentName(fileDetailsObj2.getOriginalFileName());
										emailAttachmentObj1.setAttachmentPath(downloadpath);
										emailAttachmentList.add(emailAttachmentObj1);*/
										
										/*EmailAttachment emailAttachmentObj2=new EmailAttachment();
										emailAttachmentObj2=new EmailAttachment();
										emailAttachmentObj2.setAttachmentName("Payment_Advice_Upload.xls");
										emailAttachmentObj2.setAttachmentPath(downloadpath);
										emailAttachmentList.add(emailAttachmentObj2);
										
										
										EmailAttachment emailAttachmentObj3=new EmailAttachment();
										emailAttachmentObj3.setAttachmentPath(downloadpath);
										emailAttachmentObj3.setAttachmentName("CPS Functionality Document _ 1705.pdf");
										emailAttachmentList.add(emailAttachmentObj3);
										
										EmailAttachment emailAttachmentObj4=new EmailAttachment();
										emailAttachmentObj4=new EmailAttachment();
										emailAttachmentObj4.setAttachmentPath(downloadpath);
										emailAttachmentObj4.setAttachmentName("Minstatmbc ppt.odp");
										emailAttachmentList.add(emailAttachmentObj4);*/
										
									//	emailContentObj.setEmailAttachmentList(emailAttachmentList);
										
										
										SmtpUtility.setLogger(logger);
										
										SmtpMailContent smtpMailContentObj=SmtpUtility.generateEmailAlert(emailContentObj);
										
										logger.info("Error Code "+smtpMailContentObj.getErrorCode());
										logger.info(" Error Message "+smtpMailContentObj.getErrorMessage());
									 System.out.println("file has been uploaded successfully");
							
								}else
								{	
									logger.info("some validations are failed in record check");
									SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","file upload successful but validations failed",original,null,null);
								
								}
								
								
	                               fileDetailsObj.getConnection().commit();
	                               fileDetailsObj.getTransactionManager().commit(fileDetailsObj.getTransaction());
	                           
                                   fileDetailsObj.getConnection().close();
                                   

                                }
                                else
                                {
                                	SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failed","failed because of data failure issues",original,null,null);
                                	fileDetailsObj.getTransactionManager().rollback(fileDetailsObj.getTransaction());
                                	fileDetailsObj.getConnection().close();
                                	logger.info("file has been not uploaded because of data failure issues");
									 modelAndViewObj.addObject("error","data failure issues");
									 modelAndViewObj.setViewName("bulk");
									 fileDetailsObj.getConnection().close();
									 return modelAndViewObj;
                                }
						
						
					
						modelAndViewObj.addObject("flag",
								fileDetailsObj2.getFlag());
						modelAndViewObj.addObject("status",
								fileDetailsObj2.getStatus());
						modelAndViewObj.addObject("extension", extension);
						 modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj1);
							modelAndViewObj.setViewName("bulkUploadSuccess");
							
							logger.info("END OF UPLOAD CHEQUE");

						}
						else{
							logger.info("records not inserted because of data failure issues");
							SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","Failure","DATA FAILURE ISSUES",original,null,null);
							 modelAndViewObj.addObject("error","data failure issues");
							 modelAndViewObj.setViewName("bulk");
							 fileDetailsObj.getConnection().close();
							 return modelAndViewObj;
						}
				}
	else
	
	{
		
		SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","FILE ALREADY UPLOADED",original,null,null);
	
		logger.info("same file has been uploaded already");
		 modelAndViewObj.addObject("error", "Invalid File:FileName cannot be same ");
		modelAndViewObj.setViewName("bulk");
		fileDetailsObj.getConnection().close();
		return modelAndViewObj;
	}}
	    	   else
	    	   {
	    		   SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","DATA FAILURE ISSUES",original,null,null);
	    		   logger.info("file  details has not been inserted into status table because of data failure issues");
    		   modelAndViewObj.addObject("error", "database  failure issues");
    		   modelAndViewObj.setViewName("bulk");
    		   fileDetailsObj.getConnection().close();
    		   return modelAndViewObj;
	    	   }
	    	   
	    	  
				
			} else

			{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","HEADERS ARE NOT MATCHED IN THE UPLOADED FILE",original,null,null);
				
				logger.info("Given header is not macthed");

				modelAndViewObj.addObject("error", "HEADERS ARE NOT MATCHED IN THE UPLOADED FILE");
				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
			}
		
		}

		catch (Exception e) {
			StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			modelAndViewObj.addObject("error", "invalid file with different format");
			modelAndViewObj.setViewName("bulk");
			return modelAndViewObj;
			
		}

	}

	else {
		try{
		SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","valid xls file","file is null",original,null,null);
		}catch(SQLException sqlexception)
		{
			sqlexception.printStackTrace();
			modelAndViewObj.addObject("message","DB Connectivity issues");
			modelAndViewObj.setViewName("Error");
			return modelAndViewObj;
		}
		
		logger.info("File is not valid!!");

		modelAndViewObj.addObject("error", "Entered file is empty!!");
		modelAndViewObj.setViewName("bulk");
		return modelAndViewObj;
	}
	return modelAndViewObj;
	
	
}
	public  ModelAndView validatexlsOthers(
			 MultipartFile file,
			HttpServletRequest request,String downloadpath,String errorFilesPath, String extension) 
	{
		session=request.getSession(true);
		boolean isValidTrans=false;
		FileDetails fileDetailsObj2=null;
		FileDetails fileDetailsObj=new FileDetails();
	String userId = session.getAttribute("userid").toString();
	String original = file.getOriginalFilename();
	String role=session.getAttribute("user_role_id").toString();
      String dateRegex="[0-9][0-9][\\/][0-9][0-9][\\/][0-9]{4}";
	fileDetailsObj.setOriginalFileName(original);
	logger.info("original file name is:" + original);


	fileDetailsObj.setFinalFileName(userId
			+ file.getOriginalFilename());
	logger.info("final name is ....."
			+ fileDetailsObj.getFinalFileName());
	ModelAndView modelAndViewObj=new ModelAndView();
	boolean recordCount = BulkUtil.validateRecordCount(file);
	int NumberOfRec=0;
	Long SNo=0l;
	try{
		SNo=activityLogDao.insertActivityLog(0l,userId,"file upload",null,null,original,null,null);
	}catch(SQLException sqlexception)
	{
		sqlexception.printStackTrace();
		modelAndViewObj.addObject("message","DB Connectivity issues");
		modelAndViewObj.setViewName("Error");
		return modelAndViewObj;
	}
	
	if (recordCount) {
		

		try {

			InputStream file1 =  (file
					.getInputStream());

		//	Workbook workbook = WorkbookFactory.create(file1);
			HSSFWorkbook workbook = new HSSFWorkbook(file1);
          HSSFSheet sheet = workbook.getSheetAt(0);
			//org.apache.poi.ss.usermodel.Sheet  sheet = workbook.getSheetAt(0);

			System.out.println("Present Sheet name is" + "\t"
					+ workbook.getSheetName(0));

			Iterator<Row> rows1 = sheet.rowIterator();
 
			int noOfRec = sheet.getPhysicalNumberOfRows() - 1;
			if(noOfRec==-1)
			{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT is zero",original,null,null);
	              logger.info("invalid file with no records");
					modelAndViewObj.addObject("error",
							"Invalid file with no records");
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
			}
			
			fileDetailsObj.setTotalRecords(noOfRec);
			logger.info("total records "+fileDetailsObj.getTotalRecords());
			
			
			double sum = 0;
			Iterator<Row> rowIterator1 = sheet.iterator();
			HSSFRow row2 = (HSSFRow) rowIterator1.next();
						

			List<String> headersList=new ArrayList<String>();
						
						for (int j = row2.getFirstCellNum(); j <=12; j++)
						{	
							Cell cell=row2.getCell(j);
			if (cell != null) {
			   		cell.setCellType(
						Cell.CELL_TYPE_STRING);
			   		
							headersList.add(cell.getStringCellValue());
						}
			else
			{
			   SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Invalid File",original,null,null);
			      logger.info("invalid file ");
					modelAndViewObj.addObject("error",
							"Invalid file  ");
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
			}
			   }
						String headerStatus=bulkDao.headerProc("OTHERS",null,headersList);

					       logger.info("header status is" +headerStatus);	
						 if(!(headerStatus.equalsIgnoreCase("SUCCESS")))
			                {
			                	modelAndViewObj.addObject("error",
			    						"HEADER NOT MATCHED");
			    				modelAndViewObj.setViewName("bulk");
			    				return modelAndViewObj;	
			                }
						 if(noOfRec==0)
							{
								SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT MORE THAN DEFINED",original,null,null);
					              logger.info("invalid file with no records");
									modelAndViewObj.addObject("error",
											"Invalid file with no records");
									modelAndViewObj.setViewName("bulk");
									return modelAndViewObj;
							}
						if(noOfRec>MAXIMUM_RECORDS_IN_FILE)
						{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","COUNT OF RECORDS MORE THAN DEFINED",original,null,null);
				logger.info("record count has exceeded");
				modelAndViewObj.addObject("error",
						"Count of Total records should not be more than"+MAXIMUM_RECORDS_IN_FILE);
							modelAndViewObj.setViewName("bulk");
							return modelAndViewObj;
						}
			Row row = null;
			Iterator<Row> rows = sheet.rowIterator();
			/*row = rows1.next();
			

			
			CellReference ref1 = new CellReference("C3");

			Cell cellContent1 = row.getCell(ref1.getCol());

			double sumCountHeader = (cellContent1.getNumericCellValue());*/

			//logger.info("value in the header:" + sumCountHeader);

			Cell cell2;
			double cellValue2 = 0;

			row = rows.next();
			//row = rows.next();

			while (rows.hasNext() && rows.hasNext()!=false) {
				
				row = (HSSFRow) rows.next();
				try
				{
				cell2 = row.getCell((short) 7);
					if(cell2!=null)
				
				row.getCell(7).setCellType(
						Cell.CELL_TYPE_STRING);
				if(row.getCell(7)!=null)
				{
				//	row.getCell(7).setCellType(Cell.CELL_TYPE_STRING);
				

				cell2 = row.getCell((short) 7);
if(!cell2.getStringCellValue().isEmpty()){
				cellValue2 = Double.parseDouble(cell2.getStringCellValue());
}

				sum = (sum + cellValue2);
				}
				
				
				}catch(Exception e)
				{
					e.printStackTrace();
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Payment Amount IN THE FILE SHOULD BE ONLY NUMBER",original,null,null);
					logger.info("Payment Amount SHOULD BE ONLY NUMBER");
					modelAndViewObj.addObject("error", "Payment Amount should be only Number");
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
				}
			}
			if(sum>MAXIMUM_AMOUNT_IN_FILE)
			{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","TOTAL PAYMENT AMOUNT IS MORE THAN DEFINED",original,null,null);
				 logger.info("Total Payment Amount IS MORE THAN DEFINED");
					modelAndViewObj.addObject("error",
							"Total Value in File should not be greater than"+MAXIMUM_AMOUNT_IN_FILE);
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
			}

		

				java.util.Date utilDate = new java.util.Date();
				java.sql.Date sqlDate = new java.sql.Date(
						utilDate.getTime());
						
				fileDetailsObj.setVendorUserId(userId);
				
				fileDetailsObj.setVendorType(role);
				fileDetailsObj.setPaymentAmount(Double.toString(sum));
				fileDetailsObj.setFileTYpe("Payment");
				String paymentMode="OTHERS";
				fileDetailsObj.setPaymentMode(paymentMode);
				fileDetailsObj.setMode("GUI");
			
							
					logger.info("size of headers list is " +headersList.size());
										
	       if(headerStatus.equalsIgnoreCase("SUCCESS")){
	    	
	    		    	
	    	   FileDetails fileDetailsObj1 = bulkDao.vendorDetails(fileDetailsObj);
	    	  
	    	   if(fileDetailsObj1.getErrorMsg().equalsIgnoreCase("SUCCESS"))
	    	   {
	    	
	
	    		   if (fileDetailsObj1.getStatus().equalsIgnoreCase("1")) {

 
					modelAndViewObj.addObject("status",
							fileDetailsObj1.getStatus());
					modelAndViewObj.addObject("fileId",
							fileDetailsObj1.getFileID());

					

					java.util.Date utilDate1 = new java.util.Date();
					java.sql.Date sqlDate1 = new java.sql.Date(
							utilDate1.getTime());
				int serialNo=0;
					List<BulkDetails> bulkList=new ArrayList<BulkDetails>();
							while (rowIterator1.hasNext()&& rowIterator1.hasNext()!=false) {
								BulkDetails bd = new BulkDetails();
								
								row2 = (HSSFRow) rowIterator1.next();
								boolean isRowEmpty=isRowEmpty(row2);
								
								if(isRowEmpty)
								{
									
									rowIterator1.remove();
								}
								else
								{
								
																	
								for (int j = row2.getFirstCellNum(); j <=12; j++) {
									
									bd.setFileID(fileDetailsObj.getFileID());
									bd.setInsertDate(sqlDate1);
									bd.setChangeDate(sqlDate1);
									bd.setTransferType("PAYMENT");
									bd.setPaymentMode(paymentMode);
									Cell cell=row2.getCell(j);
									if (j == 0) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											try
											{
												
												if(cell.getStringCellValue().length()>5)
											{
																	
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Serial No maximum length should be 5",original,null,null);
													logger.info("Serial No maximum length should be 5");
													modelAndViewObj.addObject("error", "Invalid File:Serial Number maximum length should be 5");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
											
											}
                                              Long.parseLong(cell
													.getStringCellValue());
											}
											catch(Exception e)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","SERIAL NUMBER SHOULD BE ONLY NUMBER",original,null,null);
												logger.info("Serial Number should be only Number");
												modelAndViewObj.addObject("error", "Serial Number should be only number");
												modelAndViewObj.setViewName("bulk");
												fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										serialNo++;
										bd.setsNo(Integer.toString(serialNo));
								
										}
									} else if (j == 1) {

										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											bd.setServiceType( (cell
													.getStringCellValue()));
										}
									} else if (j == 2) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
																					
										
														  try {
														//		date = new SimpleDateFormat("MM/dd/yyyy").parse(row2.getCell(j).getStringCellValue());
																// java.sql.Date sqlDate13 = new java.sql.Date(row2.getCell(j).getDateCellValue().getTime());
															  String dateString=cell.getStringCellValue();
                                                             if(dateString.length()>10||!(dateString.matches(dateRegex)))
																{
																	SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Trans date the File should be only Date",original,null,null);
																	logger.info("Trans Date should be only date");
																	modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																	modelAndViewObj.setViewName("bulk");
																	 fileDetailsObj.getConnection().close();
																	return modelAndViewObj;
																}
																 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
																 Date  date =  sdf.parse(dateString); 
																 java.sql.Date sqlDate13 = new java.sql.Date(date.getTime());
																 
																bd.setPaymentDate(sqlDate13);
																 

																	String subString2= dateString.substring(0, 2);
																	
																	String subString3= dateString.substring(3, 5);
																	boolean status1=true;
																	boolean status2=true;
																	
																	
																	if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
																	status1=false;
																	if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
																	status2=false;
																	if(!(status1&&status2))
																	{
																		modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																		modelAndViewObj.setViewName("bulk");
																		 fileDetailsObj.getConnection().close();
																		return modelAndViewObj;
																	}
																	
																	
																	
															 /* DateFormat d
															  * ateFormat = new SimpleDateFormat("MM/dd/yyyy");
															
															  String datestring = dateFormat.format(row2.getCell(j).getDateCellValue()); 
																																											     
															         Date date2 = dateFormat.parse(datestring);
															         System.out
																			.println("date"+datestring);*/
															    
																
													        } catch (Exception ex) {
													        	ex.printStackTrace();
													        	SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Trans date IN THE FILE SHOULD BE ONLY Date",original,null,null);
																logger.info("Trans Date SHOULD BE ONLY date");
																modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																modelAndViewObj.setViewName("bulk");
																 fileDetailsObj.getConnection().close();
																return modelAndViewObj;
													        }

													//	  bd.setPaymentDate(null);
											      
													
													
												}
									} else if (j == 3) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											try
											{
												
											
												bd.setPaymentCode(cell.getStringCellValue());
                                              if(bd.getPaymentCode().length()>15)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Code maximum length should be 15",original,null,null);
													logger.info("Payment Code maximum length should be  15");
													modelAndViewObj.addObject("error", "Invalid File:Payment Code maximum length should be  15");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
                                              Long.parseLong(cell.getStringCellValue().trim());
											
											}
											catch(Exception e)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","Failure","Payment Code SHOULD BE ONLY NUMBER",original,null,null);
												logger.info("Payment Code should be only number");
												modelAndViewObj.addObject("error", "Payment Code should be only number");
												modelAndViewObj.setViewName("bulk");
												fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									} else if (j == 4) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											
											bd.setAcctEXTID(cell
													.getStringCellValue());
                                          if(bd.getAcctEXTID().length()>75)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Acount No.(External_Account_No) maximum length should be 75",original,null,null);
												logger.info("Acount No.(External_Account_No) maximum length should be  75");
												modelAndViewObj.addObject("error", "Invalid File:Acount No.(External_Account_No) maximum length should be  75");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											
										}
									} else if (j == 5) {

										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											bd.setDelNO(cell
													.getStringCellValue());
											if(bd.getDelNO().length()>20)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Del no length should be maximum 20",original,null,null);
												logger.info("Del no SHOULD BE  Max 20 digits");
												modelAndViewObj.addObject("error", "Invalid File:Del No length should be Maximum 20");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											
										}
										if((bd.getDelNO()==null || bd.getDelNO().isEmpty() || bd.getDelNO().equals("0")) &&  (bd.getAcctEXTID()==null || bd.getAcctEXTID().isEmpty() || bd.getAcctEXTID().equals("0")))
										{
											SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Either Del no or Account External ID should be Valid",original,null,null);
											logger.info("Either Del no or Account External ID should be Valid");
											modelAndViewObj.addObject("error", "Either Del no or Account External ID should be Valid");
											modelAndViewObj.setViewName("bulk");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
									} else if (j == 6) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											try
											{
												
												
												bd.setInvoiceNo(cell
														.getStringCellValue());
												if(bd.getInvoiceNo().length()>20)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Invoice no length should be maximum 20",original,null,null);
													logger.info("Invoice Number max length is 20 ");
													modelAndViewObj.addObject("error", "Invalid File:Invoice No length should be Maximum 20");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
                                              Long.parseLong(cell
													.getStringCellValue());
											}
											catch(Exception e)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","INVOICE NUMBER SHOULD BE ONLY NUMBER",original,null,null);
												logger.info("Invoice Number should be only Number");
												modelAndViewObj.addObject("error", "Invoice should be only number");
												modelAndViewObj.setViewName("bulk");
												fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}else if (j == 7) {
												if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
													cell.setCellType(
															Cell.CELL_TYPE_STRING);
													try
													{
														
														
													bd.setPaymentAmt(cell.getStringCellValue());
                                                      if(bd.getPaymentAmt().length()>18)
													{
														SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Amount size should be maximum 18",original,null,null);
														logger.info("Payment Amount size should be maximum 18");
														modelAndViewObj.addObject("error", "Payment Amount maximum size should be 18");
														modelAndViewObj.setViewName("bulk");
														 fileDetailsObj.getConnection().close();
														return modelAndViewObj;
													}
													Double.parseDouble(cell.getStringCellValue());
													}
													catch(Exception e)
													{
														SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","PAYMENT AMOUNT SHOULD BE ONLY NUMBER",original,null,null);
														logger.info("Payment Amount should be only Number");
														modelAndViewObj.addObject("error", "Amount should be only number");
														modelAndViewObj.setViewName("bulk");
														fileDetailsObj.getConnection().close();
														return modelAndViewObj;
													}
													}
													
												
									} else if (j == 8) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
																					
										
														  try {
														//		date = new SimpleDateFormat("MM/dd/yyyy").parse(row2.getCell(j).getStringCellValue());
																// java.sql.Date sqlDate13 = new java.sql.Date(row2.getCell(j).getDateCellValue().getTime());
															  String dateString=cell.getStringCellValue();
                                                             if(dateString.length()>10||!(dateString.matches(dateRegex)))
																{
																	SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Receipt date in the File should be only Date",original,null,null);
																	logger.info("Trans Date should be only date");
																	modelAndViewObj.addObject("error", "Invalid File: Receipt Date Format should be valid(MM/DD/YYYY)");
																	modelAndViewObj.setViewName("bulk");
																	 fileDetailsObj.getConnection().close();
																	return modelAndViewObj;
																}
																 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
																 Date  date =  sdf.parse(dateString); 
																 java.sql.Date sqlDate13 = new java.sql.Date(date.getTime());
																bd.setReceiptDate(sqlDate13);
																
																	String subString2= dateString.substring(0, 2);
																	
																	String subString3= dateString.substring(3, 5);
																	boolean status1=true;
																	boolean status2=true;
																	
																	
																	if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
																	status1=false;
																	if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
																	status2=false;
																	if(!(status1&&status2))
																	{
																		modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																		modelAndViewObj.setViewName("bulk");
																		 fileDetailsObj.getConnection().close();
																		return modelAndViewObj;
																	}
																	
																	
																	
															 /* DateFormat d
															  * ateFormat = new SimpleDateFormat("MM/dd/yyyy");
															
															  String datestring = dateFormat.format(row2.getCell(j).getDateCellValue()); 
																																											     
															         Date date2 = dateFormat.parse(datestring);
															         System.out
																			.println("date"+datestring);*/
															    
																
													        } catch (Exception ex) {
													        	ex.printStackTrace();
													        	SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Trans date IN THE FILE SHOULD BE ONLY Date",original,null,null);
																logger.info("Trans Date SHOULD BE ONLY date");
																modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																modelAndViewObj.setViewName("bulk");
																 fileDetailsObj.getConnection().close();
																return modelAndViewObj;
													        }

													//	  bd.setPaymentDate(null);
											      
													
													
												}
										}
										else if (j == 9) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);
												
												bd.setChequeNo(cell
														.getStringCellValue());
                                              if(bd.getChequeNo().length()>15)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Ref Num (Receipt No / Cheque No / Credit Card Authorisation No.) maximum length should be 15",original,null,null);
													logger.info("Payment Ref Num (Receipt No / Cheque No / Credit Card Authorisation No.) max length is 15");
													modelAndViewObj.addObject("error", "Invalid File:Payment Ref Num (Receipt No / Cheque No / Credit Card Authorisation No.) Maximum length should be 15");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
												
											}
										
									} else if (j == 10) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											bd.setRemitterBranch(cell
													.getStringCellValue());
                                          if(bd.getRemitterBranch().length()>150)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Bank Name maximum length should be 150",original,null,null);
												logger.info("Bank Name max length is 20");
												modelAndViewObj.addObject("error", "Invalid File:Bank Name Maximum length should be 150");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									 else if (j == 11) {
										 if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										 cell.setCellType(
													Cell.CELL_TYPE_STRING);
										
										 bd.setSRNo(cell
													.getStringCellValue());
                                           if(bd.getSRNo().length()>20)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","SR Number maximum length should be 20",original,null,null);
												logger.info("SR Number max length is 20");
												modelAndViewObj.addObject("error", "Invalid File:SR Number Maximum length should be 20");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											}}
										
									
									 else if (j == 12) {
										 if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											 cell.setCellType(
														Cell.CELL_TYPE_STRING);
											
												bd.setAnnotation(cell
														.getStringCellValue());
                                           if(bd.getAnnotation().length()>255)
													{
														SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Annotation maximum length should be 255",original,null,null);
														logger.info("Annotation max length is 255");
														modelAndViewObj.addObject("error", "Invalid File:Annotation Maximum length should be 255");
														modelAndViewObj.setViewName("bulk");
														 fileDetailsObj.getConnection().close();
														return modelAndViewObj;
													}
																								
											}
										}
									
								}
								bulkList.add(bd);
								}
							}
								System.out.println("list size"+bulkList.size());
							int b = bulkDao.insertDetails(bulkList,fileDetailsObj1.getConnection(),fileDetailsObj1.getTransactionDef(),fileDetailsObj1.getTransactionManager(),fileDetailsObj1.getTransaction());
							
							if(b==0){
							//	fileDetailsObj1.getTransactionManager().rollback(fileDetailsObj1.getTransaction());
								isValidTrans=false;
								//break;
							}
							else{
								
								isValidTrans=true;
							}
							if(isValidTrans){
								logger.info("INSERTED into records table");
								fileDetailsObj.setConnection(fileDetailsObj1.getConnection());
								fileDetailsObj.setTransaction(fileDetailsObj1.getTransaction());
								fileDetailsObj.setTransactionManager(fileDetailsObj1.getTransactionManager());
								fileDetailsObj.setTransactionDef(fileDetailsObj1.getTransactionDef());
								fileDetailsObj2 = bulkDao
										.recordCheckxlsOthers(fileDetailsObj,errorFilesPath,extension);
								
								
								
								if(fileDetailsObj2.getErrorMsg().equalsIgnoreCase("SUCCESS"))
	                                {
									if(fileDetailsObj2.getStatus()==null)
									{
										logger.info("validations successfull in record check");
										SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","success","file upload and validations successful",original,null,null);
										 BulkUtil.fileUpload(file,downloadpath,fileDetailsObj1.getOriginalFileName(),extension);
										 logger.info("file has been uploaded successfully");
										
										 
										 /* Email for request pending for misc*/
										 File fileObj=new File(homePath+File.separator+"Conf"+File.separator+"EmailAlertsTemplates"+File.separator+"PaymentPostingRequestPendingStatusAlert.properties");
										 InputStream inputStream=new FileInputStream(fileObj);
										 Properties properties=new Properties();
										 properties.load(inputStream);
										 
										 EMailContent emailContentObj=new EMailContent();
											
										 //added for testing amount
										 DecimalFormat df = new DecimalFormat("#");
									     df.setMaximumFractionDigits(2);
									     //System.out.println(df.format(d));
									     logger.info("sending mail #####################-->>>fileDetailsObj1.getPaymentAmount() ->"+fileDetailsObj1.getPaymentAmount());
									   											 
									     String payAmount=null;
									     if(fileDetailsObj1.getPaymentAmount()!=null && !fileDetailsObj1.getPaymentAmount().isEmpty())
									     {
									    	 payAmount=fileDetailsObj1.getPaymentAmount();
									     }
									     else{
									    	 payAmount="0";
									     }
									     double paymentAmount=Double.valueOf(payAmount);

										 
											emailContentObj.setEmailSubject(properties.getProperty("emailSubject").replace(":PayMode", "Misc")+" "+getDateTime());
											emailContentObj.setEmailHeader(properties.getProperty("emailHeader"));
											emailContentObj.setEmailBody(properties.getProperty("emailBody").replace("A", fileDetailsObj1.getFileID()).replace(" : B",Integer.toString(fileDetailsObj1.getTotalRecords())).replace(" : C", (df.format(paymentAmount))).replace("<userid>",userId).replace("<filename>", fileDetailsObj1.getOriginalFileName()));
											emailContentObj.setEmailFooter(properties.getProperty("emailFooter"));
											
											List<String> emailToList=bulkDao.getSupervisorEmailIds(userId,role);
											
											emailContentObj.setEmailToList(emailToList);
											
											/*List<String> emailCCList=new ArrayList<String>();
											emailCCList.add("chaitanya.yandrapalli@tcs.com");
											emailCCList.add("teja.illa@tcs.com");
											
											emailContentObj.setEmailCCList(emailCCList);
											
											emailContentObj.setEmailBCCList(emailCCList);*/
											
											/*emailContentObj.setAttachmentRequired(true);
											
											List<EmailAttachment> emailAttachmentList=new ArrayList<EmailAttachment>();
											
											EmailAttachment emailAttachmentObj1=new EmailAttachment();
											emailAttachmentObj1.setAttachmentName(fileDetailsObj2.getOriginalFileName());
											emailAttachmentObj1.setAttachmentPath(downloadpath);
											emailAttachmentList.add(emailAttachmentObj1);*/
											
											/*EmailAttachment emailAttachmentObj2=new EmailAttachment();
											emailAttachmentObj2=new EmailAttachment();
											emailAttachmentObj2.setAttachmentName("Payment_Advice_Upload.xls");
											emailAttachmentObj2.setAttachmentPath(downloadpath);
											emailAttachmentList.add(emailAttachmentObj2);
											
											
											EmailAttachment emailAttachmentObj3=new EmailAttachment();
											emailAttachmentObj3.setAttachmentPath(downloadpath);
											emailAttachmentObj3.setAttachmentName("CPS Functionality Document _ 1705.pdf");
											emailAttachmentList.add(emailAttachmentObj3);
											
											EmailAttachment emailAttachmentObj4=new EmailAttachment();
											emailAttachmentObj4=new EmailAttachment();
											emailAttachmentObj4.setAttachmentPath(downloadpath);
											emailAttachmentObj4.setAttachmentName("Minstatmbc ppt.odp");
											emailAttachmentList.add(emailAttachmentObj4);*/
											
										//	emailContentObj.setEmailAttachmentList(emailAttachmentList);
											
											
											SmtpUtility.setLogger(logger);
											
											SmtpMailContent smtpMailContentObj=SmtpUtility.generateEmailAlert(emailContentObj);
											
											logger.info("Error Code "+smtpMailContentObj.getErrorCode());
											logger.info(" Error Message "+smtpMailContentObj.getErrorMessage());
								
									}else
									{	
										logger.info("some validations are failed in record check");
										SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","file upload successful but validations failed",original,null,null);
									
									}
									
									
		                               fileDetailsObj.getConnection().commit();
		                               fileDetailsObj.getTransactionManager().commit(fileDetailsObj.getTransaction());
		                           
	                                   fileDetailsObj.getConnection().close();
	                                   

	                                }
	                                else
	                                {
	                                	SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failed","failed because of data failure issues",original,null,null);
	                                	fileDetailsObj.getTransactionManager().rollback(fileDetailsObj.getTransaction());
	                                	fileDetailsObj.getConnection().close();
	                                	logger.info("file has been not uploaded because of data failure issues");
										 modelAndViewObj.addObject("error","data failure issues");
										 modelAndViewObj.setViewName("bulk");
										 
										 return modelAndViewObj;
	                                }
							
						
						
							modelAndViewObj.addObject("flag",
									fileDetailsObj2.getFlag());
							modelAndViewObj.addObject("status",
									fileDetailsObj2.getStatus());
							modelAndViewObj.addObject("extension", extension);
							 modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj1);
								modelAndViewObj.setViewName("bulkUploadSuccess");
								logger.info("End of Upload");

							}
							else{
								logger.info("records not inserted because of data failure issues");
								SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","Failure","Data issues!!",original,null,null);
								 modelAndViewObj.addObject("error","data failure issues");
								 modelAndViewObj.setViewName("bulk");
								 fileDetailsObj.getConnection().close();
								 return modelAndViewObj;
							}
					}
	else

	{
		
		SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","FILE WITH SAME NAME UPLOADED ALREADY",original,null,null);

		logger.info("same file has been uploaded already");
		 modelAndViewObj.addObject("error", "Invalid File:FileName cannot be same");
		modelAndViewObj.setViewName("bulk");
		fileDetailsObj.getConnection().close();
		return modelAndViewObj;
	}}
		    	   else
		    	   {
		    		   try{
		    		   SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","DATA FAILURE ISSUES",original,null,null);
		    			}catch(SQLException sqlexception)
		    			{
		    				sqlexception.printStackTrace();
		    				modelAndViewObj.addObject("message","DB Connectivity issues");
		    				modelAndViewObj.setViewName("Error");
		    				return modelAndViewObj;
		    			}
		    		   logger.info("file  details has not been inserted into status table because of data failure issues");
	    		   modelAndViewObj.addObject("error", "database  failure issues");
	    		   modelAndViewObj.setViewName("bulk");
	    		   fileDetailsObj.getConnection().close();
	    		   return modelAndViewObj;// main if sumCountHeader==sum closed
		    	   }
		    	   
		    	   // main if sumCountHeader==sum closed
					
				} else

				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","HEADERS ARE NOT MATCHED IN THE GIVEN FILE",original,null,null);
					
					logger.info("Given header is not macthed");

					modelAndViewObj.addObject("error", "HEADERS ARE NOT MATCHED IN THE UPLOADED FILE");
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
				}
		
			}

			catch (Exception e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("error", "invalid file with different format");
				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
				
			}

		}

		else {
			try{
			SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","valid xls file","file is empty",original,null,null);
		}catch(SQLException sqlexception)
		{
			sqlexception.printStackTrace();
			modelAndViewObj.addObject("message","DB Connectivity issues");
			modelAndViewObj.setViewName("Error");
			return modelAndViewObj;
		}
			logger.info("File is not valid!!");

			modelAndViewObj.addObject("error", "Entered file is empty!!");
			modelAndViewObj.setViewName("bulk");
			return modelAndViewObj;
		}
		return modelAndViewObj;
		
	}
	public  ModelAndView validatexlsxOthers(
			 MultipartFile file,
			HttpServletRequest request,String downloadpath,String errorFilesPath, String extension) 
	{

		session=request.getSession(true);
		boolean isValidTrans=false;
		FileDetails fileDetailsObj=new FileDetails();
		FileDetails fileDetailsObj2=null;
	String userId = session.getAttribute("userid").toString();
	String original = file.getOriginalFilename();
	String role=session.getAttribute("user_role_id").toString();
     String dateRegex="[0-9][0-9][\\/][0-9][0-9][\\/][0-9]{4}";
	fileDetailsObj.setOriginalFileName(original);
	logger.info("original file name is:" + original);

	fileDetailsObj.setFinalFileName(userId
			+ file.getOriginalFilename());
	logger.info("final name is ....."
			+ fileDetailsObj.getFinalFileName());
	ModelAndView modelAndViewObj=new ModelAndView();
	boolean recordCount = BulkUtil.validateRecordCount(file);
	Long SNo=0l;
	try{
	SNo=activityLogDao.insertActivityLog(0l,userId,"file upload",null,null,original,null,null);
	}catch(SQLException sqlexception)
	{
		sqlexception.printStackTrace();
		modelAndViewObj.addObject("message","DB Connectivity issues");
		modelAndViewObj.setViewName("Error");
		return modelAndViewObj;
	}
	if (recordCount) {
			try {

				InputStream file1 =(file
					.getInputStream());

			/*Workbook workbook = WorkbookFactory.create(file1);

			org.apache.poi.ss.usermodel.Sheet  sheet = workbook.getSheetAt(0);*/
		//		XSSFWorkbook workbook=(XSSFWorkbook) WorkbookFactory.create(file1);
              Workbook workbook = new XSSFWorkbook(file1);
              XSSFSheet  sheet = (XSSFSheet) workbook.getSheetAt(0);
			//	org.apache.poi.xssf.usermodel.XSSFSheet  sheet = workbook.getSheetAt(0);

			logger.info("Present Sheet name is" + "\t"
					+ workbook.getSheetName(0));

		//	Iterator<Row> rows1 = sheet.rowIterator();

	   //   Row row1 = rows1.next();
			int noOfRec = sheet.getPhysicalNumberOfRows() - 1;
			if(noOfRec==-1)
			{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT is zero",original,null,null);
	              logger.info("invalid file with no records");
					modelAndViewObj.addObject("error",
							"Invalid file with no records");
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
			}
			
			fileDetailsObj.setTotalRecords(noOfRec);
			logger.info("total records in xlsx "+fileDetailsObj.getTotalRecords());

			
		    

	
			double sum = 0;
			Iterator<Row> rowIterator1 = sheet.iterator();
			Row row2 = (XSSFRow) rowIterator1.next();
						

			List<String> headersList=new ArrayList<String>();
			
			for (int j = row2.getFirstCellNum(); j <=12; j++)
			{	
				Cell cell=row2.getCell(j);
if (cell != null) {
   		cell.setCellType(
			Cell.CELL_TYPE_STRING);
				headersList.add(cell.getStringCellValue());
			}
else
{
   SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Invalid File",original,null,null);
      logger.info("invalid file ");
		modelAndViewObj.addObject("error",
				"Invalid file  ");
		modelAndViewObj.setViewName("bulk");
		return modelAndViewObj;
}
   }

			String headerStatus=bulkDao.headerProc("OTHERS",null,headersList);

			logger.info("header status is" +headerStatus);	
			if(!(headerStatus.equalsIgnoreCase("SUCCESS")))
			{
				modelAndViewObj.addObject("error",
						"HEADER NOT MATCHED");
				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
			}
			if(noOfRec==0)
			{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT MORE THAN DEFINED",original,null,null);
	              logger.info("invalid file with no records");
					modelAndViewObj.addObject("error",
							"Invalid file with no records");
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
			}
			 if(noOfRec>MAXIMUM_RECORDS_IN_FILE)
				{
	    	 SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","RECORD COUNT MORE THAN DEFINED",original,null,null);
	    	 		logger.info("record count has exceeded");
	    	 		modelAndViewObj.addObject("error",
	    	 				"Count of Total records should not be more than"+MAXIMUM_RECORDS_IN_FILE);
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
				}
			Row row = null;

			Iterator<Row> rows = sheet.rowIterator();

			row =  (XSSFRow)rows.next();
		

			Cell cell2;
			double cellValue2 = 0;

			while (rows.hasNext()) {
				try
				{
				row = (XSSFRow) rows.next();
				cell2 = row.getCell((short) 7);
				if(cell2!=null)
			
			row.getCell(7).setCellType(
					Cell.CELL_TYPE_STRING);
				if(row.getCell(7)!=null)
				{
					
				

				cell2 = row.getCell((short) 7);
				if(!cell2.getStringCellValue().isEmpty())
				cellValue2 = Double.parseDouble(cell2.getStringCellValue());

				sum = (sum + cellValue2);
				}
				
				
				}catch(Exception e)
				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Payment Amount IN THE FILE SHOULD BE ONLY NUMBER",original,null,null);
					logger.info("Payment Amount SHOULD BE ONLY NUMBER");
					modelAndViewObj.addObject("error", "Payment Amount should be only Number");
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
				}
			}
			if(sum>MAXIMUM_AMOUNT_IN_FILE)
			{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","PAYMENT AMOUNT IS MORE THAN DEFINED",original,null,null);
				 logger.info("Total Payment Amount IS MORE THAN DEFINED");
					modelAndViewObj.addObject("error",
							"Total Value in File should not be greater than"+MAXIMUM_AMOUNT_IN_FILE);
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
			}


				java.util.Date utilDate = new java.util.Date();
				java.sql.Date sqlDate = new java.sql.Date(
						utilDate.getTime());
							
				fileDetailsObj.setVendorUserId(userId);
				
				fileDetailsObj.setVendorType(role);//session
				fileDetailsObj.setPaymentAmount(Double.toString(sum));
				fileDetailsObj.setFileTYpe("Payment");
				String paymentMode="OTHERS";
				fileDetailsObj.setPaymentMode(paymentMode);
				fileDetailsObj.setMode("GUI");
					
					
		
					
	       if(headerStatus.equalsIgnoreCase("SUCCESS")){
	    	
	        	
	    	   FileDetails fileDetailsObj1 = bulkDao.vendorDetails(fileDetailsObj);
	    	  
	    	   if(fileDetailsObj1.getErrorMsg().equalsIgnoreCase("SUCCESS"))
	    	   {
	    	
	
	    		   if (fileDetailsObj1.getStatus().equalsIgnoreCase("1")) {

					modelAndViewObj.addObject("status",
							fileDetailsObj1.getStatus());
					modelAndViewObj.addObject("fileId",
							fileDetailsObj1.getFileID());
				

					java.util.Date utilDate1 = new java.util.Date();
					java.sql.Date sqlDate1 = new java.sql.Date(
							utilDate1.getTime());
				int serialNo=0;
				List<BulkDetails> bulkList=new ArrayList<BulkDetails>();
				while (rowIterator1.hasNext()) {
					BulkDetails bd = new BulkDetails();
					
					row2 = (XSSFRow) rowIterator1.next();
					boolean isRowEmpty=isRowEmpty(row2);
					
					if(isRowEmpty)
					{
						
						rowIterator1.remove();
					}
					else
					{
					
					for (int j = row2.getFirstCellNum(); j <=12; j++) {
						
						bd.setFileID(fileDetailsObj.getFileID());
						bd.setInsertDate(sqlDate1);
						bd.setChangeDate(sqlDate1);
						bd.setTransferType("PAYMENT");
						bd.setPaymentMode(paymentMode);
						Cell cell=row2.getCell(j);
						if (j == 0) {
							if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
								cell.setCellType(
										Cell.CELL_TYPE_STRING);
								try
								{
									if(cell.getStringCellValue().length()>5)
									{
															
											SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Serial No maximum length should be 5",original,null,null);
											logger.info("Serial No maximum length should be 5");
											modelAndViewObj.addObject("error", "Invalid File:Serial No maximum length should be 5");
											modelAndViewObj.setViewName("bulk");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
									
									}
									Long.parseLong(cell
											.getStringCellValue());
								}
								catch(Exception e)
								{
									SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","SERIAL NUMBER SHOULD BE ONLY NUMBER",original,null,null);
									logger.info("Serial Number should be only Number");
									modelAndViewObj.addObject("error", "Serial Number should be only number");
									modelAndViewObj.setViewName("bulk");
									fileDetailsObj.getConnection().close();
									return modelAndViewObj;
								}
							serialNo++;
							bd.setsNo(Integer.toString(serialNo));
					
							}
						} else if (j == 1) {

							if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
								cell.setCellType(
										Cell.CELL_TYPE_STRING);
								bd.setServiceType( (cell
										.getStringCellValue()));
							}
						} else if (j == 2) {
							if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
								cell.setCellType(
										Cell.CELL_TYPE_STRING);
																		
							
											  try {
											//		date = new SimpleDateFormat("MM/dd/yyyy").parse(cell.getStringCellValue());
													// java.sql.Date sqlDate13 = new java.sql.Date(cell.getDateCellValue().getTime());
												  String dateString=cell.getStringCellValue();
                                                if(dateString.length()>10||!(dateString.matches(dateRegex)))
														{
															SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Trans date the File should be only Date",original,null,null);
															logger.info("Trans Date should be only date");
															modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
															modelAndViewObj.setViewName("bulk");
															 fileDetailsObj.getConnection().close();
															return modelAndViewObj;
														}
													 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
													 Date  date =  sdf.parse(dateString); 
													 java.sql.Date sqlDate13 = new java.sql.Date(date.getTime());
													bd.setPaymentDate(sqlDate13);
													 System.out
															.println("date in control"+date);

														String subString2= dateString.substring(0, 2);
														System.out
																.println("substring month"+subString2);
														String subString3= dateString.substring(3, 5);
														boolean status1=true;
														boolean status2=true;
														
														
														if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
														status1=false;
														if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
														status2=false;
														if(!(status1&&status2))
														{
															modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
															modelAndViewObj.setViewName("bulk");
															 fileDetailsObj.getConnection().close();
															return modelAndViewObj;
														}
														
														
														
												 
												    
													
										        } catch (Exception ex) {
										        	ex.printStackTrace();
										        	SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Trans date IN THE FILE SHOULD BE ONLY Date",original,null,null);
													logger.info("Trans Date SHOULD BE ONLY date");
													modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
										        }

										//	  bd.setPaymentDate(null);
								      
										
										
									}
						} else if (j == 3) {
							if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
								cell.setCellType(
										Cell.CELL_TYPE_STRING);

								try
								{
									
								bd.setPaymentCode(cell.getStringCellValue());
                                  if(bd.getPaymentCode().length()>15)
										{
											SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Code maximum length should be 15",original,null,null);
											logger.info("Payment Code maximum length should be  15");
											modelAndViewObj.addObject("error", "Invalid File:Payment Code maximum length should be  15");
											modelAndViewObj.setViewName("bulk");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
                                  Long.parseLong(cell.getStringCellValue());
								}
								catch(Exception e)
								{
									SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","Failure","Payment Code SHOULD BE ONLY NUMBER",original,null,null);
									logger.info("Payment Code should be only number");
									modelAndViewObj.addObject("error", "Payment Code should be only number");
									modelAndViewObj.setViewName("bulk");
									fileDetailsObj.getConnection().close();
									return modelAndViewObj;
								}
							}
						} else if (j == 4) {
							if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
								cell.setCellType(
										Cell.CELL_TYPE_STRING);
								bd.setAcctEXTID(cell
										.getStringCellValue());
                              if(bd.getAcctEXTID().length()>75)
									{
										SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Acount No.(External_Account_No) maximum length should be 75",original,null,null);
										logger.info("Acount No.(External_Account_No) maximum length should be  75");
										modelAndViewObj.addObject("error", "Invalid File:Acount No.(External_Account_No) maximum length should be  75");
										modelAndViewObj.setViewName("bulk");
										 fileDetailsObj.getConnection().close();
										return modelAndViewObj;
									}
								
							}
						} else if (j == 5) {

							if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
								cell.setCellType(
										Cell.CELL_TYPE_STRING);

								bd.setDelNO(cell
										.getStringCellValue());
								if(bd.getDelNO().length()>20)
								{
									SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Del no length should be maximum 20",original,null,null);
									logger.info("Del no SHOULD BE  Max 20 digits");
									modelAndViewObj.addObject("error", "Invalid File:Del No length should be Maximum 20");
									modelAndViewObj.setViewName("bulk");
									 fileDetailsObj.getConnection().close();
									return modelAndViewObj;
								}
								
							}
							if((bd.getDelNO()==null || bd.getDelNO().isEmpty() || bd.getDelNO().equals("0")) &&  (bd.getAcctEXTID()==null || bd.getAcctEXTID().isEmpty() || bd.getAcctEXTID().equals("0")))
							{
								SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Either Del no or Account External ID should be Valid",original,null,null);
								logger.info("Either Del no or Account External ID should be Valid");
								modelAndViewObj.addObject("error", "Either Del no or Account External ID should be Valid");
								modelAndViewObj.setViewName("bulk");
								 fileDetailsObj.getConnection().close();
								return modelAndViewObj;
							}
						} else if (j == 6) {
							if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
								cell.setCellType(
										Cell.CELL_TYPE_STRING);
								try
								{
									
									bd.setInvoiceNo(cell
											.getStringCellValue());
									if(bd.getInvoiceNo().length()>20)
									{
										SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Invoice no length should be maximum 20",original,null,null);
										logger.info("Invoice Number max length is 20 ");
										modelAndViewObj.addObject("error", "Invalid File:Invoice No length should be Maximum 20");
										modelAndViewObj.setViewName("bulk");
										 fileDetailsObj.getConnection().close();
										return modelAndViewObj;
									}
                                  Long.parseLong(cell
										.getStringCellValue());
								}
								catch(Exception e)
								{
									SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","INVOICE NUMBER SHOULD BE ONLY NUMBER",original,null,null);
									logger.info("Invoice Number should be only Number");
									modelAndViewObj.addObject("error", "Invoice should be only number");
									modelAndViewObj.setViewName("bulk");
									fileDetailsObj.getConnection().close();
									return modelAndViewObj;
								}
							}
						}else if (j == 7) {
									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);
										try
										{
											
										bd.setPaymentAmt(cell.getStringCellValue());
                                          if(bd.getPaymentAmt().length()>18)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Amount size should be maximum 18",original,null,null);
												logger.info("Payment Amount size should be maximum 18");
												modelAndViewObj.addObject("error", "Payment Amount maximum size should be  18");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
                                          Double.parseDouble(cell.getStringCellValue());
										}
										catch(Exception e)
										{
											SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","PAYMENT AMOUNT SHOULD BE ONLY NUMBER",original,null,null);
											logger.info("Payment Amount should be only Number");
											modelAndViewObj.addObject("error", "Amount should be only number");
											modelAndViewObj.setViewName("bulk");
											fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
										}
										
									
						} else if (j == 8) {
							if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
								cell.setCellType(
										Cell.CELL_TYPE_STRING);
																		
							
											  try {
											//		date = new SimpleDateFormat("MM/dd/yyyy").parse(row2.getCell(j).getStringCellValue());
													// java.sql.Date sqlDate13 = new java.sql.Date(row2.getCell(j).getDateCellValue().getTime());
												  String dateString=cell.getStringCellValue();
                                                 if(dateString.length()>10||!(dateString.matches(dateRegex)))
														{
														  	SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Receipt date   should be only Date",original,null,null);
															logger.info("Receipt Date should be only date");
															modelAndViewObj.addObject("error", "Invalid File:Receipt Date Format should be valid(MM/DD/YYYY)");
															modelAndViewObj.setViewName("bulk");
															 fileDetailsObj.getConnection().close();
															return modelAndViewObj;
														}
													 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
													 Date  date =  sdf.parse(dateString); 
													 java.sql.Date sqlDate13 = new java.sql.Date(date.getTime());
													bd.setReceiptDate(sqlDate13);
													
														String subString2= dateString.substring(0, 2);
														
														String subString3= dateString.substring(3, 5);
														boolean status1=true;
														boolean status2=true;
														
														
														if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
														status1=false;
														if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
														status2=false;
														if(!(status1&&status2))
														{
															modelAndViewObj.addObject("error", "Invalid File:Receipt Date Format should be valid(MM/DD/YYYY)");
															modelAndViewObj.setViewName("bulk");
															 fileDetailsObj.getConnection().close();
															return modelAndViewObj;
														}
														
													
																					    
													
										        } catch (Exception ex) {
										        	ex.printStackTrace();
										        	SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Receipt date IN THE FILE SHOULD BE ONLY Date",original,null,null);
													logger.info("Trans Date SHOULD BE ONLY date");
													modelAndViewObj.addObject("error", "Invalid File:Receipt Date Format should be valid(MM/DD/YYYY)");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
										        }

										
									}
							}
							else if (j == 9) {
								if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
									cell.setCellType(
											Cell.CELL_TYPE_STRING);
									bd.setChequeNo(cell
											.getStringCellValue());
                                  if(bd.getChequeNo().length()>15)


										{
											SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Ref Num (Receipt No / Cheque No / Credit Card Authorisation No.) maximum length should be 15",original,null,null);
											logger.info("Payment Ref Num (Receipt No / Cheque No / Credit Card Authorisation No.) max length is 15");
											modelAndViewObj.addObject("error", "Invalid File:Payment Ref Num (Receipt No / Cheque No / Credit Card Authorisation No.) Maximum length should be 15");
											modelAndViewObj.setViewName("bulk");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
									
								}
							
						} else if (j == 10) {
							if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
								cell.setCellType(
										Cell.CELL_TYPE_STRING);

								bd.setRemitterBranch(cell
										.getStringCellValue());
                              if(bd.getRemitterBranch().length()>150)
									{
										SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Bank Name maximum length should be 150",original,null,null);
										logger.info("Bank Name max length is 150");
										modelAndViewObj.addObject("error", "Invalid File:Bank Name Maximum length should be 150");
										modelAndViewObj.setViewName("bulk");
										 fileDetailsObj.getConnection().close();
										return modelAndViewObj;
									}
							}
						}
						 else if (j == 11) {
							 if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
							 cell.setCellType(
										Cell.CELL_TYPE_STRING);
							 bd.setSRNo(cell
										.getStringCellValue());
                               if(bd.getSRNo().length()>20)
									{
										SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","SR Number maximum length should be 20",original,null,null);
										logger.info("SR Number max length is 20");
										modelAndViewObj.addObject("error", "Invalid File:SR Number Maximum length should be 20");
										modelAndViewObj.setViewName("bulk");
										 fileDetailsObj.getConnection().close();
										return modelAndViewObj;
									}
								}}
							
						
						 else if (j == 12) {
							 if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
								 cell.setCellType(
											Cell.CELL_TYPE_STRING);
									bd.setAnnotation(cell
											.getStringCellValue());
                               if(bd.getAnnotation().length()>255)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Annotation maximum length should be 255",original,null,null);
												logger.info("Annotation max length is 255");
												modelAndViewObj.addObject("error", "Invalid File:Annotation Maximum length should be 255");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											
																					
								}
							}
						
					}
					bulkList.add(bd);
					}	
				}
				int b = bulkDao.insertDetails(bulkList,fileDetailsObj1.getConnection(),fileDetailsObj1.getTransactionDef(),fileDetailsObj1.getTransactionManager(),fileDetailsObj1.getTransaction());
				
				if(b==0){
					//fileDetailsObj1.getTransactionManager().rollback(fileDetailsObj1.getTransaction());
					isValidTrans=false;
				//	break;
				}
				else{
					
					isValidTrans=true;
				}
			    
				if(isValidTrans){
					logger.info("INSERTED into records table");
					fileDetailsObj.setConnection(fileDetailsObj1.getConnection());
					fileDetailsObj.setTransaction(fileDetailsObj1.getTransaction());
					fileDetailsObj.setTransactionManager(fileDetailsObj1.getTransactionManager());
					fileDetailsObj.setTransactionDef(fileDetailsObj1.getTransactionDef());
					fileDetailsObj2 = bulkDao
							.recordCheckxlsxOthers(fileDetailsObj,errorFilesPath,extension);
					
					
					
					if(fileDetailsObj2.getErrorMsg().equalsIgnoreCase("SUCCESS"))
                        {
						if(fileDetailsObj2.getStatus()==null)
						{
							logger.info("validations successfull in record check");
							SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","success","file upload and validations successful",original,null,null);
							 BulkUtil.fileUpload(file,downloadpath,fileDetailsObj1.getOriginalFileName(),extension);
							 logger.info("file has been uploaded successfully");
							 /* Email for request pending for misc*/
							 File fileObj=new File(homePath+File.separator+"Conf"+File.separator+"EmailAlertsTemplates"+File.separator+"PaymentPostingRequestPendingStatusAlert.properties");
							 InputStream inputStream=new FileInputStream(fileObj);
							 Properties properties=new Properties();
							 properties.load(inputStream);
							 
							 EMailContent emailContentObj=new EMailContent();
							
							//added for testing amount
							 DecimalFormat df = new DecimalFormat("#");
						     df.setMaximumFractionDigits(2);
						     //System.out.println(df.format(d));
						     logger.info("sending mail #####################-->>>fileDetailsObj1.getPaymentAmount() ->"+fileDetailsObj1.getPaymentAmount());
						   											 
						     String payAmount=null;
						     if(fileDetailsObj1.getPaymentAmount()!=null && !fileDetailsObj1.getPaymentAmount().isEmpty())
						     {
						    	 payAmount=fileDetailsObj1.getPaymentAmount();
						     }
						     else{
						    	 payAmount="0";
						     }
						     double paymentAmount=Double.valueOf(payAmount);
							 
								emailContentObj.setEmailSubject(properties.getProperty("emailSubject").replace(":PayMode", "Misc")+" "+getDateTime());
								emailContentObj.setEmailHeader(properties.getProperty("emailHeader"));
								emailContentObj.setEmailBody(properties.getProperty("emailBody").replace("A", fileDetailsObj1.getFileID()).replace(" : B",Integer.toString(fileDetailsObj1.getTotalRecords())).replace(" : C", (df.format(paymentAmount))).replace("<userid>",userId).replace("<filename>", fileDetailsObj1.getOriginalFileName()));
								emailContentObj.setEmailFooter(properties.getProperty("emailFooter"));
								
								List<String> emailToList=bulkDao.getSupervisorEmailIds(userId,role);
								
								emailContentObj.setEmailToList(emailToList);
								
								
								
								SmtpUtility.setLogger(logger);
								
								SmtpMailContent smtpMailContentObj=SmtpUtility.generateEmailAlert(emailContentObj);
					
						}else
						{	
							logger.info("some validations are failed in record check");
							SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","file upload successful but validations failed",original,null,null);
						
						}
						 
						
						
                           fileDetailsObj.getConnection().commit();
                           fileDetailsObj.getTransactionManager().commit(fileDetailsObj.getTransaction());
                       
                           fileDetailsObj.getConnection().close();
                           

                        }
                        else
                        {
                        	SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failed","failed because of data failure issues",original,null,null);
                        	fileDetailsObj.getTransactionManager().rollback(fileDetailsObj.getTransaction());
                        	fileDetailsObj.getConnection().close();
                        	logger.info("file has been not uploaded because of data failure issues");
							 modelAndViewObj.addObject("error","DATA FAILURE ISSUES");
							 modelAndViewObj.setViewName("bulk");
							 return modelAndViewObj;
                        }
			
				modelAndViewObj.addObject("status",
						fileDetailsObj2.getStatus());
				modelAndViewObj.addObject("extension", extension);
				 modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj1);
					modelAndViewObj.setViewName("bulkUploadSuccess");
					logger.info("End of Upload");

				}
				else{
					logger.info("records not inserted because of data failure issues");
					SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","Failure","Data issues!!",original,null,null);
					 modelAndViewObj.addObject("error","data failure issues");
					 modelAndViewObj.setViewName("bulk");
					 fileDetailsObj.getConnection().close();
					 return modelAndViewObj;
				}
		}
				else
				
				{
				
				SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","file already uploaded",original,null,null);
				
				logger.info("same file has been uploaded already");
				modelAndViewObj.addObject("error", "Invalid File:FileName cannot be same");
				modelAndViewObj.setViewName("bulk");
				fileDetailsObj.getConnection().close();
				return modelAndViewObj;
				}}
	   else
	   {
		   logger.info("file  details has not been inserted into status table because of data failure issues");
	   modelAndViewObj.addObject("error", "database  failure issues");
	   modelAndViewObj.setViewName("bulk");
	   fileDetailsObj.getConnection().close();
	   return modelAndViewObj;
	   }
	   
	  	
	} else

	{
		SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","HEADERS ARE NOT MATCHED IN THE UPLOADED FILE",original,null,null);
		
		logger.info("Given header is not macthed");

		modelAndViewObj.addObject("error", "HEADERS ARE NOT MATCHED");
		modelAndViewObj.setViewName("bulk");
		return modelAndViewObj;
	}

}

			catch (Exception e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("error", "invalid file with different format");
				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
				
			}

}

		else {
			try{
		SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","valid xls file","file is empty",original,null,null);
			}catch(SQLException sqlexception)
			{
				sqlexception.printStackTrace();
				modelAndViewObj.addObject("message","DB Connectivity issues");
				modelAndViewObj.setViewName("Error");
				return modelAndViewObj;
			}
		
		logger.info("File is not valid!!");
		
		modelAndViewObj.addObject("error", "Entered file is empty!!");
		modelAndViewObj.setViewName("bulk");
		return modelAndViewObj;
		}
		return modelAndViewObj;
			
		}
	
	
	public  ModelAndView validatexlsBankStatement(
			 MultipartFile file,
			HttpServletRequest request,String downloadpath,String errorFilesPath, String extension) 
	{
		
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		boolean isValidTrans=false;
		FileDetails fileDetailsObj2=null;
		FileDetails fileDetailsObj=new FileDetails();
		String exchangerateregex="[0-9][0-9]?[0-9]?[0-9]?+(\\.[0-9]?[0-9]?[0-9]?[0-9]?[0-9]?[0-9]?)?";
		String dateRegex="[0-9][0-9][\\/][0-9][0-9][\\/][0-9]{4}";
		String original = file.getOriginalFilename();
		fileDetailsObj.setOriginalFileName(original);
		logger.info("original file name is:" + original);

		
		fileDetailsObj.setFinalFileName(userId
				+ file.getOriginalFilename());
		logger.info("final name is ....."
				+ fileDetailsObj.getFinalFileName());
		ModelAndView modelAndViewObj=new ModelAndView();
		boolean recordCount = BulkUtil.validateRecordCount(file);
		Long SNo=0l;
		try{
		SNo=activityLogDao.insertActivityLog(0l,userId,"file upload",null,null,original,null,null);
		}catch(SQLException sqlexception)
		{
			sqlexception.printStackTrace();
			modelAndViewObj.addObject("message","DB Connectivity issues");
			modelAndViewObj.setViewName("Error");
			return modelAndViewObj;
		}
		if (recordCount) {
			try {

				InputStream file1 =  (file
						.getInputStream());

				HSSFWorkbook workbook = new HSSFWorkbook(file1);

				HSSFSheet sheet = workbook.getSheetAt(0);

				logger.info("Present Sheet name is" + "\t"
						+ workbook.getSheetName(0));

				

			
				int noOfRec = sheet.getPhysicalNumberOfRows() - 1;
				if(noOfRec==-1)
				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT is zero",original,null,null);
		              logger.info("invalid file with no records");
						modelAndViewObj.addObject("error",
								"Invalid file with no records");
						modelAndViewObj.setViewName("bulk");
						return modelAndViewObj;
				}
				fileDetailsObj.setTotalRecords(noOfRec);
			
				
				

			
				double sum = 0;

				HSSFRow row = null;

				Iterator<Row> rows = sheet.rowIterator();

				row = (HSSFRow) rows.next();
				
				HSSFCell cell2;
				double cellValue2 = 0;
				Iterator<Row> rowIterator1 = sheet.iterator();
				HSSFRow row2 = (HSSFRow) rowIterator1.next();
							

				List<String> headersList=new ArrayList<String>();
				
				for (int j = row2.getFirstCellNum(); j <=30; j++)
				{	
					Cell cell=row2.getCell(j);
					if (cell != null) {
	   		cell.setCellType(
				Cell.CELL_TYPE_STRING);
					headersList.add(cell.getStringCellValue());
				}
   else
   {
	   SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Invalid File",original,null,null);
          logger.info("invalid file ");
			modelAndViewObj.addObject("error",
					"Invalid file with Header mismatch");
			modelAndViewObj.setViewName("bulk");
			return modelAndViewObj;
   }
	   }

				String headerStatus=bulkDao.headerProc("BANKSTATEMENT",null,headersList);

			logger.info("header status is" +headerStatus);
			if(!(headerStatus.equalsIgnoreCase("SUCCESS")))
			{
				modelAndViewObj.addObject("error",
						"Invalid file  ");
				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
			}
			if(noOfRec==0)
			{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT MORE THAN DEFINED",original,null,null);
	              logger.info("invalid file with no records");
					modelAndViewObj.addObject("error",
							"Invalid file with no records");
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
			}
				if(noOfRec>MAXIMUM_RECORDS_IN_FILE)
				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","TOTAL RECORDS ARE MORE THAN DEFINED",original,null,null);
					logger.info("record count has exceeded");
					modelAndViewObj.addObject("error",
							"Count of Total records should not be more than"+MAXIMUM_RECORDS_IN_FILE);
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
				}

				while (rows.hasNext()) {
					try
					{
					row = (HSSFRow) rows.next();
                      cell2 = row.getCell((short) 28);
						if(cell2!=null)
					row.getCell(28).setCellType(
							Cell.CELL_TYPE_STRING);
					if(row.getCell(28)!=null)
					{
						
					

					cell2 = row.getCell((short) 28);
					if(!cell2.getStringCellValue().isEmpty())
					cellValue2 = Double.parseDouble(cell2.getStringCellValue());

					sum = (sum + cellValue2);
					}
					
					
					}catch(Exception e)
					{
						SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Payment Amount IN THE FILE SHOULD BE ONLY NUMBER",original,null,null);
						logger.info("Payment Amount SHOULD BE ONLY NUMBER");
						modelAndViewObj.addObject("error", "Payment Amount should be only Number");
						modelAndViewObj.setViewName("bulk");
						return modelAndViewObj;
					}
				}
			/*	if(sum>20000000)
				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","PAYMENT AMOUNT IS MORE THAN DEFINED");
					 logger.info("Total Payment Amount IS MORE THAN DEFINED");
						modelAndViewObj.addObject("error",
								"Total Value in File should not be greater than 2cr.");
						modelAndViewObj.setViewName("bulk");
						return modelAndViewObj;
				}*/

			

					java.util.Date utilDate = new java.util.Date();
					java.sql.Date sqlDate = new java.sql.Date(
							utilDate.getTime());
					
					fileDetailsObj.setVendorUserId(session.getAttribute("userid").toString());//session
					
					fileDetailsObj.setVendorType(role);//session
					fileDetailsObj.setPaymentAmount(Double.toString(sum));
					fileDetailsObj.setFileTYpe("Payment");
					String paymentMode="NEFT";
					fileDetailsObj.setPaymentMode(paymentMode);
					fileDetailsObj.setMode("GUI");

								

						logger.info("size of headers list is " +headersList.size());
								
						
		       if(headerStatus.equalsIgnoreCase("SUCCESS")){
		    	   
		    		    	  
		    	   FileDetails fileDetailsObj1 = bulkDao.vendorDetails(fileDetailsObj);
		    	 
		    	   if(fileDetailsObj1.getErrorMsg().equalsIgnoreCase("SUCCESS"))
		    	   {
				
		    		   if (fileDetailsObj1.getStatus().equalsIgnoreCase("1")) {
	
							modelAndViewObj.addObject("status",
								fileDetailsObj1.getStatus());
						modelAndViewObj.addObject("fileId",
								fileDetailsObj1.getFileID());

						java.util.Date utilDate1 = new java.util.Date();
						java.sql.Date sqlDate1 = new java.sql.Date(
								utilDate1.getTime());
					int serialNo=0;
					List<BulkDetails> bulkList=new ArrayList<BulkDetails>();
							while (rowIterator1.hasNext()) {
								BulkDetails bd = new BulkDetails();
								serialNo++;
								bd.setsNo(Integer.toString(serialNo));
								
								
								row2 = (HSSFRow) rowIterator1.next();
								boolean isRowEmpty=isRowEmpty(row2);
								
								if(isRowEmpty)
								{
									
									rowIterator1.remove();
								}
								else
								{
								
								for (int j = row2.getFirstCellNum(); j<=30; j++) {
									
									bd.setFileID(fileDetailsObj.getFileID());
									bd.setInsertDate(sqlDate1);
									bd.setChangeDate(sqlDate1);
						            bd.setPaymentMode("NEFT");
						            bd.setTransferType("PAYMENT");
						            Cell cell=row2.getCell(j);
									if (j == 0) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											
											bd.setChequeNo(cell
													.getStringCellValue());
                                          if(bd.getChequeNo().length()>25)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","UTR No maximum length should be 25",original,null,null);
												logger.info("UTR No max length is 25");
												modelAndViewObj.addObject("error", "Invalid File:UTR No Maximum length should be 25");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
								
										}
									} else if (j == 1) {

										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
										
											bd.setIncomingTransactionNo(cell
													.getStringCellValue());
                                          if(bd.getIncomingTransactionNo().length()>25)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Incoming Transaction Ref No maximum length should be 25",original,null,null);
												logger.info("Incoming Transaction Ref No max length is 25");
												modelAndViewObj.addObject("error", "Invalid File:Incoming Transaction Ref No Maximum length should be 25");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										
											
										}
									} else if (j == 2) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
																					
										
														  try {
														//		date = new SimpleDateFormat("MM/dd/yyyy").parse(row2.getCell(j).getStringCellValue());
																// java.sql.Date sqlDate13 = new java.sql.Date(row2.getCell(j).getDateCellValue().getTime());
															  String dateString=cell.getStringCellValue();
                                                             if(dateString.length()>10||!(dateString.matches(dateRegex)))
																{
																  SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Value date   should be only Date",original,null,null);
																	logger.info("Value Date should be only date");
																	modelAndViewObj.addObject("error", "Invalid File:Value Date Format should be valid(MM/DD/YYYY)");
																	modelAndViewObj.setViewName("bulk");
																	 fileDetailsObj.getConnection().close();
																	return modelAndViewObj;
																}
																 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
																 Date  date =  sdf.parse(dateString); 
																 java.sql.Date sqlDate13 = new java.sql.Date(date.getTime());
																bd.setPaymentDate(sqlDate13);
																
																	String subString2= dateString.substring(0, 2);
																	
																	String subString3= dateString.substring(3, 5);
																	boolean status1=true;
																	boolean status2=true;
																	
																	
																	if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
																	status1=false;
																	if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
																	status2=false;
																	if(!(status1&&status2))
																	{
																		modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																		modelAndViewObj.setViewName("bulk");
																		 fileDetailsObj.getConnection().close();
																		return modelAndViewObj;
																	}
																	
																	
														
															    
																
													        } catch (Exception ex) {
													        	ex.printStackTrace();
													        	SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Trans date IN THE FILE SHOULD BE ONLY Date",original,null,null);
																logger.info("Trans Date SHOULD BE ONLY date");
																modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																modelAndViewObj.setViewName("bulk");
																 fileDetailsObj.getConnection().close();
																return modelAndViewObj;
													        }

													//	  bd.setPaymentDate(null);
											      
													
													
												}
									} else if (j == 3) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											try
											{
												
											bd.setAmountInr(cell.getStringCellValue());
                                              if(bd.getAmountInr().length()>18)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Amount In INR maximum length should be 18",original,null,null);
												logger.info("Amount should be only Number");
												modelAndViewObj.addObject("error", "Amount In INR maximum length should be 18");
												modelAndViewObj.setViewName("bulk");
												fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											Double.parseDouble(cell.getStringCellValue());
											}
											catch(Exception e)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","PAYMENT AMOUNT SHOULD BE ONLY NUMBER",original,null,null);
												logger.info("Amount should be only Number");
												modelAndViewObj.addObject("error", "Amount in INR should be only number");
												modelAndViewObj.setViewName("bulk");
												fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										
											
										}
									} else if (j == 4) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setAccountNumberRBI1(cell
													.getStringCellValue());
                                          if(bd.getAccountNumberRBI1().length()>25)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Receiving account received from RBI 1 maximum length should be 25",original,null,null);
												logger.info("Receiving account received from RBI 1 max length is 25");
												modelAndViewObj.addObject("error", "Invalid File:Receiving account received from RBI 1 Maximum length should be 25");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									} else if (j == 5) {

										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setBankVirtualAcctNo(cell
													.getStringCellValue());
                                          if(bd.getBankVirtualAcctNo().length()>25)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Receiving account received from RBI 2 maximum length should be 25",original,null,null);
												logger.info("Receiving account received from RBI 2 max length is 25");
												modelAndViewObj.addObject("error", "Invalid File:Receiving account received from RBI 2 Maximum length should be 25");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											
										}
									} else if (j == 12) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setReceiverName(cell
													.getStringCellValue());
                                          if(bd.getReceiverName().length()>100)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Receiving Name maximum length should be 100",original,null,null);
												logger.info("Receiving Name max length is 100");
												modelAndViewObj.addObject("error", "Invalid File:Receiving Name Maximum length should be 100");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 15) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setReceiverIfsc(cell
													.getStringCellValue());
                                          if(bd.getReceiverIfsc().length()>50)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Receiver IFSC maximum length should be 50",original,null,null);
												logger.info("Receiver IFSC max length is 50");
												modelAndViewObj.addObject("error", "Invalid File:Receiver IFSC Maximum length should be 50");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
								
									else if (j == 18) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setRemitterAccNo(cell
													.getStringCellValue());
                                          if(bd.getRemitterAccNo().length()>50)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Remitter A/c No maximum length should be 50",original,null,null);
												logger.info("Remitter A/c No max length is 50");
												modelAndViewObj.addObject("error", "Invalid File:Remitter A/c No Maximum length should be 50");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 19) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setRemitterBranch(cell
													.getStringCellValue());
                                          if(bd.getRemitterBranch().length()>150)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Remitter Branch maximum length should be 150",original,null,null);
												logger.info("Remitter Branch max length is 150");
												modelAndViewObj.addObject("error", "Invalid File:Remitter A/c No Maximum length should be 150");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 20) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setRemitterName(cell
													.getStringCellValue());
											//Geeta change length of remitter name 150 to 260
                                          if(bd.getRemitterName().length()>260)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Remitter Name maximum length should be 260",original,null,null);
												logger.info("Remitter Name max length is 260");
												modelAndViewObj.addObject("error", "Invalid File:Remitter Name Maximum length should be 260");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 22) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setRemitterIfsc(cell
													.getStringCellValue());
                                          if(bd.getRemitterIfsc().length()>50)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Remitter IFSC maximum length should be 50",original,null,null);
												logger.info("Remitter IFSC max length is 50");
												modelAndViewObj.addObject("error", "Invalid File:Remitter IFSC Maximum length should be 50");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 23) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setRefNo(cell
													.getStringCellValue());
                                          if(bd.getRefNo().length()>50)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Ref No maximum length should be 50",original,null,null);
												logger.info("Ref No max length is 50");
												modelAndViewObj.addObject("error", "Invalid File:Ref No Maximum length should be 50");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 24) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setProductType(cell
													.getStringCellValue());
                                          if(bd.getProductType().length()>50)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Product Type maximum length should be 50",original,null,null);
												logger.info("Product Type max length is 50");
												modelAndViewObj.addObject("error", "Invalid File:Product Type Maximum length should be 50");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 25) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setPaymentDetails1(cell
													.getStringCellValue());
                                          if(bd.getPaymentDetails1().length()>500)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Details 1 maximum length should be 500",original,null,null);
												logger.info("Payment Details 1 max length is 500");
												modelAndViewObj.addObject("error", "Invalid File:Payment Details 1 Maximum length should be 500");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 26) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setPaymentDetails2(cell
													.getStringCellValue());
                                          if(bd.getPaymentDetails2().length()>500)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Details 2 maximum length should be 500",original,null,null);
												logger.info("Payment Details 2 max length is 500");
												modelAndViewObj.addObject("error", "Invalid File:Payment Details 2 Maximum length should be 500");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 27) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setPaymentDetails3(cell
													.getStringCellValue());
                                          if(bd.getPaymentDetails3().length()>500)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Details 3 maximum length should be 500",original,null,null);
												logger.info("Payment Details 3 max length is 500");
												modelAndViewObj.addObject("error", "Invalid File:Payment Details 3 Maximum length should be 500");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									 else if (j == 28) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);
												
												try
												{
													
												bd.setPaymentAmt(cell.getStringCellValue());
                                                  if(bd.getPaymentAmt().length()>18)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Amount size should be maximum 18",original,null,null);
													logger.info("Payment Amount size should be maximum 18");
													modelAndViewObj.addObject("error", "Payment Amount maximum size should be 18");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
                                                  Double.parseDouble(cell.getStringCellValue());
												}
												catch(Exception e)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","PAYMENT AMOUNT SHOULD BEONLY NUMBER",original,null,null);
													logger.info("Payment amount should be only number");
													modelAndViewObj.addObject("error", "Payment amount should be only number");
													modelAndViewObj.setViewName("bulk");
													fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
											
												
											}
										}
									 else if (j == 29) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);
												
												try
												{
													
												bd.setExchangeRate(cell.getStringCellValue());
                                                  if(bd.getExchangeRate().length()>10)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Exchange rate maximum length should be 10",original,null,null);
													logger.info("Exchange rate maximum length should be 10");
													modelAndViewObj.addObject("error", "Exchange rate maximum length should be 10");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();													
													return modelAndViewObj;
												}
                                                  if(!bd.getExchangeRate().matches(exchangerateregex))
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Exchange rate should be only number with defined format",original,null,null);
													logger.info("Exchange rate should be only number with defined format");
													modelAndViewObj.addObject("error", "Exchange rate should be only number with defined format");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();													
													return modelAndViewObj;
												}
                                             //     Double.parseDouble(cell.getStringCellValue());
												}
												catch(Exception e)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","EXCHANGE RATE SHOULD BE ONLY NUMBER",original,null,null);
													logger.info("Exchange rate should be only number");
													modelAndViewObj.addObject("error", "Exchange rate should be only number");
													modelAndViewObj.setViewName("bulk");
													fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
											
												
											}
										}
									 else if (j == 30) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);
												
												bd.setPaymentCurrency(cell
														.getStringCellValue());
											}
										}
								}
								bulkList.add(bd);
								}
							}
							int b = bulkDao.insertDetails(bulkList,fileDetailsObj1.getConnection(),fileDetailsObj1.getTransactionDef(),fileDetailsObj1.getTransactionManager(),fileDetailsObj1.getTransaction());
							
							if(b==0){
							//	fileDetailsObj1.getTransactionManager().rollback(fileDetailsObj1.getTransaction());
								isValidTrans=false;
							//	break;
							}
							else{
							
								isValidTrans=true;
							}
						    
							if(isValidTrans){
								fileDetailsObj.setConnection(fileDetailsObj1.getConnection());
								fileDetailsObj.setTransaction(fileDetailsObj1.getTransaction());
								fileDetailsObj.setTransactionManager(fileDetailsObj1.getTransactionManager());
								fileDetailsObj.setTransactionDef(fileDetailsObj1.getTransactionDef());
								fileDetailsObj2 = bulkDao
										.recordCheckxlsBankStatement(fileDetailsObj,errorFilesPath,extension);
											
								if(fileDetailsObj2.getErrorMsg().equalsIgnoreCase("SUCCESS"))
	                            {
										logger.info("RECORD CHECK SUCCESFULL");
										if(fileDetailsObj2.getStatus()==null)
										{
											logger.info("validations are succesfull");
											SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","success"," file Upload and validations successfull",original,null,null);
											 BulkUtil.fileUpload(file,downloadpath,fileDetailsObj1.getOriginalFileName(),extension);
											 
											 /* Email for request pending for cheque*/
											 File fileObj=new File(homePath+File.separator+"Conf"+File.separator+"EmailAlertsTemplates"+File.separator+"PaymentPostingRequestPendingStatusAlert.properties");
											
											 InputStream inputStream=new FileInputStream(fileObj);
											 Properties properties=new Properties();
											 properties.load(inputStream);
											 
											 
											//added for testing amount
											 DecimalFormat df = new DecimalFormat("#");
										     df.setMaximumFractionDigits(2);
										     //System.out.println(df.format(d));
										     logger.info("sending mail #####################-->>>fileDetailsObj1.getPaymentAmount() ->"+fileDetailsObj1.getPaymentAmount());
										   											 
										     String payAmount=null;
										     if(fileDetailsObj1.getPaymentAmount()!=null && !fileDetailsObj1.getPaymentAmount().isEmpty())
										     {
										    	 payAmount=fileDetailsObj1.getPaymentAmount();
										     }
										     else{
										    	 payAmount="0";
										     }
										     double paymentAmount=Double.valueOf(payAmount);
											 				 
											 
											 EMailContent emailContentObj=new EMailContent();
												
												emailContentObj.setEmailSubject(properties.getProperty("emailSubject").replace(":PayMode", "NEFT")+" "+getDateTime());
												emailContentObj.setEmailHeader(properties.getProperty("emailHeader"));
												emailContentObj.setEmailBody(properties.getProperty("emailBody").replace("A", fileDetailsObj1.getFileID()).replace(" : B",Integer.toString(fileDetailsObj1.getTotalRecords())).replace(" : C", (df.format(paymentAmount))).replace("<userid>",userId).replace("<filename>", fileDetailsObj1.getOriginalFileName()));
												emailContentObj.setEmailFooter(properties.getProperty("emailFooter"));
												
												List<String> emailToList=bulkDao.getSupervisorEmailIds(userId,role);
												
												emailContentObj.setEmailToList(emailToList);
												
												
												SmtpUtility.setLogger(logger);
												
												SmtpMailContent smtpMailContentObj=SmtpUtility.generateEmailAlert(emailContentObj);
												
												System.out.println("Error Code "+smtpMailContentObj.getErrorCode());
												System.out.println(" Error Message "+smtpMailContentObj.getErrorMessage());
												
											    logger.info("File has been uploaded succesfully ");
									
										}else
										{	
											logger.info("validations are not succesfull");
											SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","file Upload Success but validations failed",original,null,null);
										
										}
	                            	                            	
								
	                               fileDetailsObj.getConnection().commit();
	                               fileDetailsObj.getTransactionManager().commit(fileDetailsObj.getTransaction());
	                         
	                               fileDetailsObj.getConnection().close();
	             

	                            }
	                            else
	                            {
	                            	
	                            	logger.info("File has been  not uploaded because of data failure issues ");
	                            	
	                            	fileDetailsObj.getTransactionManager().rollback(fileDetailsObj.getTransaction());
	                            	fileDetailsObj.getConnection().close();
	                            	SNo=activityLogDao.insertActivityLog(SNo,userId,"file uploading","failed","FAILED DUE TO DATA FAILURE ISSUES",original,null,null);
									 modelAndViewObj.addObject("error","data failure issues");
									 modelAndViewObj.setViewName("bulk");
									 
									 return modelAndViewObj;
	                            }
							
						
							modelAndViewObj.addObject("status",
									fileDetailsObj2.getStatus());
							 modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj1);
							 modelAndViewObj.addObject("extension", extension);
								modelAndViewObj.setViewName("bulkUploadSuccess");
								logger.info("End of Upload");

							}
							else{
								logger.info("records are not inserted because of data failure issues");
								SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","Failure","Data FAILURE issues!!",original,null,null);
								 modelAndViewObj.addObject("error","data failure issues");
								 modelAndViewObj.setViewName("bulk");
								 fileDetailsObj.getConnection().close();
								 return modelAndViewObj;
							}
	
					} else

					{
						// System.out.println("Given header amount and sum of all the records are not matched..!!!");
						 SNo=activityLogDao.insertActivityLog(SNo,userId,"file uploading","failure","FILE ALREADY UPLOADED WITH THE SAME NAME",original,null,null);
					
						 modelAndViewObj.addObject("error", "Invalid File:FileName cannot be same");
						modelAndViewObj.setViewName("bulk");
						fileDetailsObj.getConnection().close();
						return modelAndViewObj;
					}}
		    	   else
		    	   {
		    	  logger.info("file  details has not been inserted into status table because of data failure issues");
	    		   modelAndViewObj.addObject("error", "database  failure issues");
	    		   modelAndViewObj.setViewName("bulk");
	    		   fileDetailsObj.getConnection().close();
	    		   return modelAndViewObj;// main if sumCountHeader==sum closed
		    	   }// main if sumCountHeader==sum closed
					
				} else

				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","failure","HEADERS ARE NOT MATCHED IN THE GIVEN FILE",original,null,null);
				
					logger.info("Given header is not macthed");

					modelAndViewObj.addObject("error", "HEADERS ARE NOT MATCHED");
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
				}
		
			}

			catch (Exception e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("error", "invalid file with different format");
				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
				
			}

		}

		else {
			try{
			SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","valid xls file","file is empty",original,null,null);
			}catch(SQLException sqlexception)
			{
				StringWriter errors= new StringWriter();
				sqlexception.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("message","DB Connectivity issues");
				modelAndViewObj.setViewName("Error");
				return modelAndViewObj;
			}
			logger.info("File is not valid!!");

			modelAndViewObj.addObject("error", "Entered file is empty!!");
			modelAndViewObj.setViewName("bulk");
			return modelAndViewObj;
		}
		return modelAndViewObj;
		
		
	}
	public  ModelAndView validatexlsxBankStatement(
			 MultipartFile file,
			HttpServletRequest request,String downloadpath,String errorFilesPath, String extension) 
	{
		
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		boolean isValidTrans=false;
		FileDetails fileDetailsObj2=null;
		FileDetails fileDetailsObj=new FileDetails();
		String exchangerateregex="[0-9][0-9]?[0-9]?[0-9]?+(\\.[0-9]?[0-9]?[0-9]?[0-9]?[0-9]?[0-9]?)?";
		String dateRegex="[0-9][0-9][\\/][0-9][0-9][\\/][0-9]{4}";
		String original = file.getOriginalFilename();
		fileDetailsObj.setOriginalFileName(original);
		logger.info("original file name is:" + original);

		
		fileDetailsObj.setFinalFileName(userId
				+ file.getOriginalFilename());
		logger.info("final name is ....."
				+ fileDetailsObj.getFinalFileName());
		ModelAndView modelAndViewObj=new ModelAndView();
		boolean recordCount = BulkUtil.validateRecordCount(file);
		Long SNo=0l;
		try{
		SNo=activityLogDao.insertActivityLog(0l,userId,"file upload",null,null,original,null,null);
		}catch(SQLException sqlexception)
		{
			sqlexception.printStackTrace();
			modelAndViewObj.addObject("message","DB Connectivity issues");
			modelAndViewObj.setViewName("Error");
			return modelAndViewObj;
		}
		if (recordCount) {
			try {

				InputStream file1 =(file
						.getInputStream());

			//	XSSFWorkbook workbook=(XSSFWorkbook) WorkbookFactory.create(file1);
              Workbook workbook = new XSSFWorkbook(file1);
                Sheet sheet = workbook.getSheetAt(0);
				//org.apache.poi.xssf.usermodel.XSSFSheet  sheet = workbook.getSheetAt(0);
				logger.info("Present Sheet name is" + "\t"
						+ workbook.getSheetName(0));

				

				
				int noOfRec = sheet.getPhysicalNumberOfRows() - 1;
				if(noOfRec==-1)
				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT is zero",original,null,null);
		              logger.info("invalid file with no records");
						modelAndViewObj.addObject("error",
								"Invalid file with no records");
						modelAndViewObj.setViewName("bulk");
						return modelAndViewObj;
				}

				fileDetailsObj.setTotalRecords(noOfRec);
				
				if(noOfRec>MAXIMUM_RECORDS_IN_FILE)
				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","failure","COUNT OF RECORDS NOT MATCHED",original,null,null);
	              logger.info("record count has exceeded");
	              modelAndViewObj.addObject("error",
							"Count of Total records should not be more than"+MAXIMUM_RECORDS_IN_FILE);
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
				}
				

			
				double sum = 0;

				Row row = null;

				Iterator<Row> rows = sheet.rowIterator();

				row = (XSSFRow) rows.next();
				

				Cell cell2;
				double cellValue2 = 0;
				Iterator<Row> rowIterator1 = sheet.iterator();
				Row row2 = (XSSFRow) rowIterator1.next();
							

				List<String> headersList=new ArrayList<String>();
				
				for (int j = row2.getFirstCellNum(); j <=30; j++)
				{	
					Cell cell=row2.getCell(j);
   if (cell != null) {
	   		cell.setCellType(
				Cell.CELL_TYPE_STRING);
					headersList.add(cell.getStringCellValue());
				}
   else
   {
	  SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Invalid File",original,null,null);
          logger.info("invalid file ");
			modelAndViewObj.addObject("error",
					"Invalid file  ");
			modelAndViewObj.setViewName("bulk");
			return modelAndViewObj;
   }
	   }
				String headerStatus=bulkDao.headerProc("BANKSTATEMENT",null,headersList);

				logger.info("header status is" +headerStatus);
				if(!(headerStatus.equalsIgnoreCase("SUCCESS")))
				{
					modelAndViewObj.addObject("error",
							"Header not matched");
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
				}
				if(noOfRec==0)
				{
					//SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT MORE THAN DEFINED");
		              logger.info("invalid file with no records");
						modelAndViewObj.addObject("error",
								"Invalid file with no records");
						modelAndViewObj.setViewName("bulk");
						return modelAndViewObj;
				}
				if(noOfRec>MAXIMUM_RECORDS_IN_FILE)
				{
					//SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT MORE THAN DEFINED");
		              logger.info("invalid file with more records than defined");
						modelAndViewObj.addObject("error",
								"Invalid file with more records than defined");
						modelAndViewObj.setViewName("bulk");
						return modelAndViewObj;
				}
				while (rows.hasNext()) {
					try
					{
					row = (XSSFRow) rows.next();
					cell2 = row.getCell((short) 28);
					if(cell2!=null)
				
				row.getCell(28).setCellType(
						Cell.CELL_TYPE_STRING);
					if(row.getCell(28)!=null)
					{
								

					cell2 = row.getCell((short) 28);
					if(!cell2.getStringCellValue().isEmpty())
					cellValue2 = Double.parseDouble(cell2.getStringCellValue());

					sum = (sum + cellValue2);
					}
					
					
					}catch(Exception e)
					{
						SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Payment Amount IN THE FILE SHOULD BE ONLY NUMBER",original,null,null);
						logger.info("Payment Amount SHOULD BE ONLY NUMBER");
						modelAndViewObj.addObject("error", "Payment Amount should be only Number");
						modelAndViewObj.setViewName("bulk");
						return modelAndViewObj;
					}
				}
			/*	if(sum>20000000)
				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","failure","PAYMENT AMOUNT IS MORE THAN DEFINED");
					 logger.info("Total Payment Amount IS MORE THAN DEFINED");
						modelAndViewObj.addObject("error",
								"Total Value in File should not be greater than 2cr.");
						modelAndViewObj.setViewName("bulk");
						return modelAndViewObj;
				}*/

			

					java.util.Date utilDate = new java.util.Date();
					java.sql.Date sqlDate = new java.sql.Date(
							utilDate.getTime());
					
					fileDetailsObj.setVendorUserId(session.getAttribute("userid").toString());
			
					fileDetailsObj.setVendorType(role);
					fileDetailsObj.setPaymentAmount(Double.toString(sum));
					fileDetailsObj.setFileTYpe("Payment");
					String paymentMode="NEFT";
					fileDetailsObj.setPaymentMode(paymentMode);
					fileDetailsObj.setMode("GUI");

						
						logger.info("size of heders list is " +headersList.size());
									
						
		       if(headerStatus.equalsIgnoreCase("SUCCESS")){
		    	   
		    	    	  
		    	   FileDetails fileDetailsObj1 = bulkDao.vendorDetails(fileDetailsObj);
		    	
		    	   if(fileDetailsObj1.getErrorMsg().equalsIgnoreCase("SUCCESS"))
		    	   {
				
		    		   if (fileDetailsObj1.getStatus().equalsIgnoreCase("1")) {
	
	
						modelAndViewObj.addObject("status",
								fileDetailsObj1.getStatus());
						modelAndViewObj.addObject("fileId",
								fileDetailsObj1.getFileID());

						java.util.Date utilDate1 = new java.util.Date();
						java.sql.Date sqlDate1 = new java.sql.Date(
								utilDate1.getTime());
					int serialNo=0;
					List<BulkDetails> bulkList=new ArrayList<BulkDetails>();
							while (rowIterator1.hasNext()) {
								BulkDetails bd = new BulkDetails();
								serialNo++;
								bd.setsNo(Integer.toString(serialNo));
								
								
								row2 = (XSSFRow) rowIterator1.next();
								boolean isRowEmpty=isRowEmpty(row2);
								
								if(isRowEmpty)
								{
									
									rowIterator1.remove();
								}
								else
								{
								
								for (int j = row2.getFirstCellNum(); j <=30; j++) {
									
									bd.setFileID(fileDetailsObj.getFileID());
									bd.setInsertDate(sqlDate1);
									bd.setChangeDate(sqlDate1);
						            bd.setPaymentMode("NEFT");
						            bd.setTransferType("PAYMENT");
						            Cell cell=row2.getCell(j);
									if (j == 0) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
																					
											bd.setChequeNo(cell
													.getStringCellValue());
                                          if(bd.getChequeNo().length()>25)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","UTR No maximum length should be 25",original,null,null);
												logger.info("UTR No max length is 25");
												modelAndViewObj.addObject("error", "Invalid File:UTR No Maximum length should be 25");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
								
										}
									} else if (j == 1) {

										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
										
											bd.setIncomingTransactionNo(cell
													.getStringCellValue());
                                          if(bd.getIncomingTransactionNo().length()>25)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Incoming Transaction Ref No maximum length should be 25",original,null,null);
												logger.info("Incoming Transaction Ref No max length is 25");
												modelAndViewObj.addObject("error", "Invalid File:Incoming Transaction Ref No Maximum length should be 25");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										
											
										}
									} else if (j == 2) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
																					
										
														  try {
														//		date = new SimpleDateFormat("MM/dd/yyyy").parse(row2.getCell(j).getStringCellValue());
																// java.sql.Date sqlDate13 = new java.sql.Date(row2.getCell(j).getDateCellValue().getTime());
															  String dateString=cell.getStringCellValue();
                                                            if(dateString.length()>10||!(dateString.matches(dateRegex)))
																{
																	SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Value date the File should be only Date",original,null,null);
																	logger.info("Value Date should be only date");
																	modelAndViewObj.addObject("error", "Invalid File:Value Date Format should be valid(MM/DD/YYYY)");
																	modelAndViewObj.setViewName("bulk");
																	 fileDetailsObj.getConnection().close();
																	return modelAndViewObj;
																}
																 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
																 Date  date =  sdf.parse(dateString); 
																 java.sql.Date sqlDate13 = new java.sql.Date(date.getTime());
																bd.setPaymentDate(sqlDate13);
																

																	String subString2= dateString.substring(0, 2);
																	
																	String subString3= dateString.substring(3, 5);
																	boolean status1=true;
																	boolean status2=true;
																	
																	
																	if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
																	status1=false;
																	if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
																	status2=false;
																	if(!(status1&&status2))
																	{
																		modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																		modelAndViewObj.setViewName("bulk");
																		 fileDetailsObj.getConnection().close();
																		return modelAndViewObj;
																	}
																	
																	
																														    
																
													        } catch (Exception ex) {
													        	ex.printStackTrace();
													        	SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Trans date IN THE FILE SHOULD BE ONLY Date",original,null,null);
																logger.info("Trans Date SHOULD BE ONLY date");
																modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																modelAndViewObj.setViewName("bulk");
																 fileDetailsObj.getConnection().close();
																return modelAndViewObj;
													        }

													//	  bd.setPaymentDate(null);
											      
													
													
												}
									} else if (j == 3) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											try
											{
												
											bd.setAmountInr(cell.getStringCellValue());
                                              if(bd.getAmountInr().length()>18)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Amount In INR maximum length should be 18",original,null,null);
												logger.info("Amount should be only Number");
												modelAndViewObj.addObject("error", "Amount In INR maximum length should be 18");
												modelAndViewObj.setViewName("bulk");
												fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											Double.parseDouble(cell.getStringCellValue());
											}
											catch(Exception e)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","PAYMENT AMOUNT SHOULD BE ONLY NUMBER",original,null,null);
												logger.info("Amount should be only Number");
												modelAndViewObj.addObject("error", "Amount in INR should be only number");
												modelAndViewObj.setViewName("bulk");
												fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										
											
										}
									} else if (j == 4) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setAccountNumberRBI1(cell
													.getStringCellValue());
                                          if(bd.getAccountNumberRBI1().length()>25)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Receiving account received from RBI 1 maximum length should be 25",original,null,null);
												logger.info("Receiving account received from RBI 1 max length is 25");
												modelAndViewObj.addObject("error", "Invalid File:Receiving account received from RBI 1 Maximum length should be 25");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									} else if (j == 5) {

										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setBankVirtualAcctNo(cell
													.getStringCellValue());
                                          if(bd.getBankVirtualAcctNo().length()>25)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Receiving account received from RBI 2 maximum length should be 25",original,null,null);
												logger.info("Receiving account received from RBI 2 max length is 25");
												modelAndViewObj.addObject("error", "Invalid File:Receiving account received from RBI 2 Maximum length should be 25");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											
										}
									} else if (j == 12) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setReceiverName(cell
													.getStringCellValue());
                                          if(bd.getReceiverName().length()>100)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Receiving Name maximum length should be 100",original,null,null);
												logger.info("Receiving Name max length is 100");
												modelAndViewObj.addObject("error", "Invalid File:Receiving Name Maximum length should be 100");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 15) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setReceiverIfsc(cell
													.getStringCellValue());
                                          if(bd.getReceiverIfsc().length()>50)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Receiver IFSC maximum length should be 50",original,null,null);
												logger.info("Receiver IFSC max length is 50");
												modelAndViewObj.addObject("error", "Invalid File:Receiver IFSC Maximum length should be 50");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
								
									else if (j == 18) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setRemitterAccNo(cell
													.getStringCellValue());
                                          if(bd.getRemitterAccNo().length()>50)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Remitter A/c No maximum length should be 50",original,null,null);
												logger.info("Remitter A/c No max length is 50");
												modelAndViewObj.addObject("error", "Invalid File:Remitter A/c No Maximum length should be 50");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 19) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setRemitterBranch(cell
													.getStringCellValue());
                                          if(bd.getRemitterBranch().length()>150)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Remitter Branch maximum length should be 150",original,null,null);
												logger.info("Remitter Branch max length is 150");
												modelAndViewObj.addObject("error", "Invalid File:Remitter A/c No Maximum length should be 150");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 20) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setRemitterName(cell
													.getStringCellValue());
                                          if(bd.getRemitterName().length()>150)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Remitter Name maximum length should be 150",original,null,null);
												logger.info("Remitter Name max length is 150");
												modelAndViewObj.addObject("error", "Invalid File:Remitter Name Maximum length should be 150");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 22) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setRemitterIfsc(cell
													.getStringCellValue());
                                          if(bd.getRemitterIfsc().length()>50)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Remitter IFSC maximum length should be 50",original,null,null);
												logger.info("Remitter IFSC max length is 50");
												modelAndViewObj.addObject("error", "Invalid File:Remitter IFSC Maximum length should be 50");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 23) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setRefNo(cell
													.getStringCellValue());
                                          if(bd.getRefNo().length()>50)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Ref No maximum length should be 50",original,null,null);
												logger.info("Ref No max length is 50");
												modelAndViewObj.addObject("error", "Invalid File:Ref No Maximum length should be 50");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 24) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setProductType(cell
													.getStringCellValue());
                                          if(bd.getProductType().length()>50)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Product Type maximum length should be 50",original,null,null);
												logger.info("Product Type max length is 50");
												modelAndViewObj.addObject("error", "Invalid File:Product Type Maximum length should be 50");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 25) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setPaymentDetails1(cell
													.getStringCellValue());
                                          if(bd.getPaymentDetails1().length()>500)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Details 1 maximum length should be 500",original,null,null);
												logger.info("Payment Details 1 max length is 500");
												modelAndViewObj.addObject("error", "Invalid File:Payment Details 1 Maximum length should be 500");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 26) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setPaymentDetails2(cell
													.getStringCellValue());
                                          if(bd.getPaymentDetails2().length()>500)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Details 2 maximum length should be 500",original,null,null);
												logger.info("Payment Details 2 max length is 500");
												modelAndViewObj.addObject("error", "Invalid File:Payment Details 2 Maximum length should be 500");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									else if (j == 27) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setPaymentDetails3(cell
													.getStringCellValue());
                                          if(bd.getPaymentDetails3().length()>500)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Details 3 maximum length should be 500",original,null,null);
												logger.info("Payment Details 3 max length is 500");
												modelAndViewObj.addObject("error", "Invalid File:Payment Details 3 Maximum length should be 500");
												modelAndViewObj.setViewName("bulk");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									}
									 else if (j == 28) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);
												
												try
												{
													
												bd.setPaymentAmt(cell.getStringCellValue());
                                                  if(bd.getPaymentAmt().length()>18)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Amount size should be maximum 18",original,null,null);
													logger.info("Payment Amount size should be maximum 18");
													modelAndViewObj.addObject("error", "Payment Amount size should be maximum 18");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
                                                  Double.parseDouble(cell.getStringCellValue());
												}
												catch(Exception e)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","PAYMENT AMOUNT SHOULD BEONLY NUMBER",original,null,null);
													logger.info("Payment amount should be only number");
													modelAndViewObj.addObject("error", "Payment amount should be only number");
													modelAndViewObj.setViewName("bulk");
													fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
											
												
											}
										}
									 else if (j == 29) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);
												
												try
												{
													
												bd.setExchangeRate(cell.getStringCellValue());
                                                  if(bd.getExchangeRate().length()>11)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Exchange rate maximum length should be 11",original,null,null);
													logger.info("Exchange rate maximum length should be 11");
													modelAndViewObj.addObject("error", "Exchange rate maximum length should be 11");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();													
													return modelAndViewObj;
												}
                                                  if(!bd.getExchangeRate().matches(exchangerateregex))
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Exchange rate should be only number with defined format",original,null,null);
													logger.info("Exchange rate should be only number with defined format");
													modelAndViewObj.addObject("error", "Exchange rate should be only number with defined format");
													modelAndViewObj.setViewName("bulk");
													 fileDetailsObj.getConnection().close();													
													return modelAndViewObj;
												}
                                             //     Double.parseDouble(cell.getStringCellValue());
												}
												catch(Exception e)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","EXCHANGE RATE SHOULD BE ONLY NUMBER",original,null,null);
													logger.info("Exchange rate should be only number");
													modelAndViewObj.addObject("error", "Exchange rate should be only number");
													modelAndViewObj.setViewName("bulk");
													fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
											
												
											}
										}
									 else if (j == 30) {
											if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
												cell.setCellType(
														Cell.CELL_TYPE_STRING);
												
												bd.setPaymentCurrency(cell
														.getStringCellValue());
											}
										}
								}
								bulkList.add(bd);
							}
                            }
							int b = bulkDao.insertDetails(bulkList,fileDetailsObj1.getConnection(),fileDetailsObj1.getTransactionDef(),fileDetailsObj1.getTransactionManager(),fileDetailsObj1.getTransaction());
							
							if(b==0){
						//	fileDetailsObj1.getTransactionManager().rollback(fileDetailsObj1.getTransaction());
							isValidTrans=false;
						//	break;
						}
						else{
							logger.info("INSERTED into records table");
							isValidTrans=true;
						}
							if(isValidTrans){
								fileDetailsObj.setConnection(fileDetailsObj1.getConnection());
								fileDetailsObj.setTransaction(fileDetailsObj1.getTransaction());
								fileDetailsObj.setTransactionManager(fileDetailsObj1.getTransactionManager());
								fileDetailsObj.setTransactionDef(fileDetailsObj1.getTransactionDef());
								fileDetailsObj2 = bulkDao
										.recordCheckxlsxBankStatement(fileDetailsObj,errorFilesPath,extension);
															
								if(fileDetailsObj2.getErrorMsg().equalsIgnoreCase("SUCCESS"))
	                            {
										logger.info("RECORD CHECK SUCCESFULL");
										if(fileDetailsObj2.getStatus()==null)
										{
											logger.info("validations are succesfull");
											SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","success"," file Upload and validations successfull",original,null,null);
											 BulkUtil.fileUpload(file,downloadpath,fileDetailsObj1.getOriginalFileName(),extension);
											 
											 /* Email for request pending for cheque*/
											 File fileObj=new File(homePath+File.separator+"Conf"+File.separator+"EmailAlertsTemplates"+File.separator+"PaymentPostingRequestPendingStatusAlert.properties");
											 InputStream inputStream=new FileInputStream(fileObj);
											 Properties properties=new Properties();
											 properties.load(inputStream);
											 
											 
											//added for testing amount
											 DecimalFormat df = new DecimalFormat("#");
										     df.setMaximumFractionDigits(2);
										     //System.out.println(df.format(d));
										     logger.info("sending mail #####################-->>>fileDetailsObj1.getPaymentAmount() ->"+fileDetailsObj1.getPaymentAmount());
										   											 
										     String payAmount=null;
										     if(fileDetailsObj1.getPaymentAmount()!=null && !fileDetailsObj1.getPaymentAmount().isEmpty())
										     {
										    	 payAmount=fileDetailsObj1.getPaymentAmount();
										     }
										     else{
										    	 payAmount="0";
										     }
										     double paymentAmount=Double.valueOf(payAmount);

											 
											 EMailContent emailContentObj=new EMailContent();
												
												emailContentObj.setEmailSubject(properties.getProperty("emailSubject").replace(":PayMode", "NEFT")+" "+getDateTime());
												emailContentObj.setEmailHeader(properties.getProperty("emailHeader"));
												emailContentObj.setEmailBody(properties.getProperty("emailBody").replace("A", fileDetailsObj1.getFileID()).replace(" : B",Integer.toString(fileDetailsObj1.getTotalRecords())).replace(" : C", (df.format(paymentAmount))).replace("<userid>",userId).replace("<filename>", fileDetailsObj1.getOriginalFileName()));
												emailContentObj.setEmailFooter(properties.getProperty("emailFooter"));
												
												List<String> emailToList=bulkDao.getSupervisorEmailIds(userId,role);
												
												emailContentObj.setEmailToList(emailToList);
												
												/*List<String> emailCCList=new ArrayList<String>();
												//emailCCList.add("chaitanya.yandrapalli@tcs.com");
												emailCCList.add("teja.illa@tcs.com");
												
												emailContentObj.setEmailCCList(emailCCList);
												
												emailContentObj.setEmailBCCList(emailCCList);*/
												
												/*emailContentObj.setAttachmentRequired(true);
												
												List<EmailAttachment> emailAttachmentList=new ArrayList<EmailAttachment>();
												
												EmailAttachment emailAttachmentObj1=new EmailAttachment();
												emailAttachmentObj1.setAttachmentName(fileDetailsObj2.getOriginalFileName());
												emailAttachmentObj1.setAttachmentPath(downloadpath);
												emailAttachmentList.add(emailAttachmentObj1);
												
												EmailAttachment emailAttachmentObj2=new EmailAttachment();
												emailAttachmentObj2=new EmailAttachment();
												emailAttachmentObj2.setAttachmentName("Payment_Advice_Upload.xls");
												emailAttachmentObj2.setAttachmentPath(downloadpath);
												emailAttachmentList.add(emailAttachmentObj2);
												
												
												EmailAttachment emailAttachmentObj3=new EmailAttachment();
												emailAttachmentObj3.setAttachmentPath(downloadpath);
												emailAttachmentObj3.setAttachmentName("CPS Functionality Document _ 1705.pdf");
												emailAttachmentList.add(emailAttachmentObj3);
												
												EmailAttachment emailAttachmentObj4=new EmailAttachment();
												emailAttachmentObj4=new EmailAttachment();
												emailAttachmentObj4.setAttachmentPath(downloadpath);
												emailAttachmentObj4.setAttachmentName("Minstatmbc ppt.odp");
												emailAttachmentList.add(emailAttachmentObj4);
												
												emailContentObj.setEmailAttachmentList(emailAttachmentList);*/
				                             /*  emailContentObj.setAttachmentRequired(true);
												
												List<EmailAttachment> emailAttachmentList=new ArrayList<EmailAttachment>();
												
												EmailAttachment emailAttachmentObj1=new EmailAttachment();
												emailAttachmentObj1.setAttachmentName(fileDetailsObj2.getOriginalFileName());
												emailAttachmentObj1.setAttachmentPath(downloadpath);
												emailAttachmentList.add(emailAttachmentObj1);
												emailContentObj.setEmailAttachmentList(emailAttachmentList);*/
												
												SmtpUtility.setLogger(logger);
												
												SmtpMailContent smtpMailContentObj=SmtpUtility.generateEmailAlert(emailContentObj);
												
												System.out.println("Error Code "+smtpMailContentObj.getErrorCode());
												System.out.println(" Error Message "+smtpMailContentObj.getErrorMessage());
												
											    logger.info("File has been uploaded succesfully ");
									
										}else
										{	
											logger.info("validations are not succesfull");
											SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","file Upload Success but validations failed",original,null,null);
										
										}
	                            	                            	
								
	                               fileDetailsObj.getConnection().commit();
	                               fileDetailsObj.getTransactionManager().commit(fileDetailsObj.getTransaction());
	                         
	                               fileDetailsObj.getConnection().close();
	             

	                            }
	                            else
	                            {
	                            	
	                            	logger.info("File has been  not uploaded because of data failure issues ");
	                            	
	                            	fileDetailsObj.getTransactionManager().rollback(fileDetailsObj.getTransaction());
	                            	fileDetailsObj.getConnection().close();
	                            	SNo=activityLogDao.insertActivityLog(SNo,userId,"file uploading","failed","FAILED DUE TO DATA FAILURE ISSUES",original,null,null);
									 modelAndViewObj.addObject("error","data failure issues");
									 modelAndViewObj.setViewName("bulk");
									 return modelAndViewObj;
	                            }

							modelAndViewObj.addObject("flag",
									fileDetailsObj2.getFlag());
							modelAndViewObj.addObject("status",
									fileDetailsObj2.getStatus());
							 modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj1);
							 modelAndViewObj.addObject("extension", extension);
								modelAndViewObj.setViewName("bulkUploadSuccess");
								logger.info("End of Upload");
								
							}
							else{
								logger.info("records are not inserted because of data failure issues");
								SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","Failure","Data issues!!",original,null,null);
								 modelAndViewObj.addObject("error","data failure issues");
								 modelAndViewObj.setViewName("bulk");
								 fileDetailsObj.getConnection().close();
								 return modelAndViewObj;
							}
						
					} else

					{
						
						 SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","FILE ALREADY UPLOADED WITH THE SAME NAME",original,null,null);
					logger.info("File Already Uploaded");
						 modelAndViewObj.addObject("error", "Invalid File:FileName cannot be same ");
						modelAndViewObj.setViewName("bulk");
						fileDetailsObj.getConnection().close();
						return modelAndViewObj;
					}
		    		   }
		    	   else
		    	   {
		    		   logger.info("file  details has not been inserted into status table because of data failure issues");
	    		   modelAndViewObj.addObject("error", "database  failure issues");
	    		   modelAndViewObj.setViewName("bulk");
	    		   fileDetailsObj.getConnection().close();
	    		   return modelAndViewObj;
		    	   }
					
				} else

				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","failure","HEADERS ARE NOT MATCHED",original,null,null);
				
					logger.info("Given header is not macthed");

					modelAndViewObj.addObject("error", "HEADERS ARE NOT MATCHED IN THE UPLOADED FILE");
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
				}
			
			}

			catch (Exception e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("error", "invalid file with different format");
				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
				
			}

		}

		else {
			try{
			SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","valid xls file","file is null",original,null,null);
			}catch(SQLException sqlexception)
			{
				sqlexception.printStackTrace();
				modelAndViewObj.addObject("message","DB Connectivity issues");
				modelAndViewObj.setViewName("Error");
				return modelAndViewObj;
			}
			logger.info("File is not valid!!");

			modelAndViewObj.addObject("error", "Entered file is empty!!");
			modelAndViewObj.setViewName("bulk");
			return modelAndViewObj;
		}
		return modelAndViewObj;
		
		
	}
	public  ModelAndView validatexlsReversal(
			 MultipartFile file,
			HttpServletRequest request,String downloadpath,String errorFilesPath, String extension) 
	{
		boolean isValidTrans=false;
		FileDetails fileDetailsObj2=null;
		session=request.getSession(true);
		FileDetails fileDetailsObj=new FileDetails();
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
      String dateRegex="[0-9][0-9][\\/][0-9][0-9][\\/][0-9]{4}";
		String original = file.getOriginalFilename();
		fileDetailsObj.setOriginalFileName(original);
		logger.info("original file name is:" + original);


		ModelAndView modelAndViewObj=new ModelAndView();
		boolean recordCount = BulkUtil.validateRecordCount(file);
		Long SNo=0l;
		try{
		SNo=activityLogDao.insertActivityLog(0l,userId,"file upload",null,null,original,null,null);
		}catch(SQLException sqlexception)
		{
			sqlexception.printStackTrace();
			modelAndViewObj.addObject("message","DB Connectivity issues");
			modelAndViewObj.setViewName("Error");
			return modelAndViewObj;
		}
		if (recordCount) {
				

			try {

				InputStream file1 =  (file
						.getInputStream());

				HSSFWorkbook workbook = new HSSFWorkbook(file1);

				HSSFSheet sheet = workbook.getSheetAt(0);

				logger.info("Present Sheet name is" + "\t"
						+ workbook.getSheetName(0));

				Iterator<Row> rows1 = sheet.rowIterator();

				//HSSFRow row1 = (HSSFRow) rows1.next();
				int  noOfRec = sheet.getPhysicalNumberOfRows() - 1;
			//	System.out.println(noOfRec);
				if(noOfRec==-1)
				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT is zero",original,null,null);
		              logger.info("invalid file with no records");
						modelAndViewObj.addObject("error",
								"Invalid file with no records");
						modelAndViewObj.setViewName("reversal");
						return modelAndViewObj;
				}
				fileDetailsObj.setTotalRecords(noOfRec);
			//	System.out.println("total records "+fileDetailsObj.getTotalRecords());
	
				//System.out.println("defined"+);
				
				Iterator<Row> rowIterator1 = sheet.iterator();
				HSSFRow row2 = (HSSFRow) rowIterator1.next();
			//	 row2 = (HSSFRow) rowIterator1.next();
			


				List<String> headersList=new ArrayList<String>();		
				for (int j = row2.getFirstCellNum(); j <=6; j++)
				{	
					Cell cell=row2.getCell(j);
   if (cell != null) {
	   		cell.setCellType(
				Cell.CELL_TYPE_STRING);
					headersList.add(cell.getStringCellValue());
				}
   else
   {
	   SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Invalid File",original,null,null);
          logger.info("invalid file ");
			modelAndViewObj.addObject("error",
					"Invalid file  ");
			modelAndViewObj.setViewName("reversal");
			return modelAndViewObj;
   }
	   }
					
 logger.info("size of headers list is " +headersList.size());
 
				
// SNo=activityLogDao.insertActivityLog(0,"CAD_SPOC","File level validations header",null,null);


					String headerStatus=bulkDao.headerProc("REVERSAL",null,headersList);

					logger.info("header status is" +headerStatus);	
					if(!(headerStatus.equalsIgnoreCase("SUCCESS")))
					{
						modelAndViewObj.addObject("error",
								"Invalid file WITH HEADER MISMATCH");
						modelAndViewObj.setViewName("reversal");
						return modelAndViewObj;
					}
					if(noOfRec==0)
					{
						SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT is zero",original,null,null);
			              logger.info("invalid file with no records");
							modelAndViewObj.addObject("error",
									"Invalid file with no records");
							modelAndViewObj.setViewName("reversal");
							return modelAndViewObj;
					}
			if(noOfRec>MAXIMUM_RECORDS_IN_FILE)
							{
				logger.info("record count has exceeded");
				modelAndViewObj.addObject("error",
						"Count of Total records should not be more than"+MAXIMUM_RECORDS_IN_FILE);
								modelAndViewObj.setViewName("reversal");
								return modelAndViewObj;
							}
				System.out.println("\n no of rec " + noOfRec);
	
					
					java.util.Date utilDate = new java.util.Date();
					java.sql.Date sqlDate = new java.sql.Date(
							utilDate.getTime());
					
					fileDetailsObj.setVendorUserId(userId);//session
				
					fileDetailsObj.setVendorType(role);//session
				//	fileDetailsObj.setPaymentAmount(sum);
					fileDetailsObj.setFileTYpe("DIRECT_REVERSAL");
					fileDetailsObj.setMode("GUI");
								
		
						
		       if(headerStatus.equalsIgnoreCase("SUCCESS")){
		    	   
		    	
		    	   FileDetails fileDetailsObj1 = bulkDao.reversalFileDetails(fileDetailsObj);
		    	  
		    	   if(fileDetailsObj1.getErrorMsg().equalsIgnoreCase("SUCCESS"))
		    	   {
				
		    		   if (fileDetailsObj1.getStatus().equalsIgnoreCase("1")) {

						
						modelAndViewObj.addObject("status",
								fileDetailsObj1.getStatus());
						modelAndViewObj.addObject("fileId",
								fileDetailsObj1.getFileID());
						java.util.Date utilDate1 = new java.util.Date();
						java.sql.Date sqlDate1 = new java.sql.Date(
								utilDate1.getTime());
						
						//System.out.println("payment date in records table"+formattedDate);
					int serialNo=0;
					List<BulkDetails> bulkList=new ArrayList<BulkDetails>();
							while (rowIterator1.hasNext()) {
								
								BulkDetails bd = new BulkDetails();
								serialNo++;
								bd.setsNo(Integer.toString(serialNo));
								
								row2 = (HSSFRow) rowIterator1.next();
								boolean isRowEmpty=isRowEmpty(row2);
								
								if(isRowEmpty)
								{
									
									rowIterator1.remove();
								}
								else
								{
								
								for (int j = row2.getFirstCellNum(); j <=6; j++) {
									
									bd.setFileID(fileDetailsObj.getFileID());
								//	bd.setPaymentDate(sqlDate1);
									bd.setChangeDate(sqlDate1);
									bd.setTransferType("REVERSAL");
									Cell cell=row2.getCell(j);
									if (j == 0) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											bd.setAcctEXTID(cell
													.getStringCellValue());
                                          if(bd.getAcctEXTID().length()>75)
											{
												logger.info("ACCOUNT_NO maximum length should be 75");
												modelAndViewObj.addObject("error", "ACCOUNT_NO maximum length should be 75");
												modelAndViewObj.setViewName("reversal");
												 fileDetailsObj.getConnection().close();
												 return modelAndViewObj;
											}
											
								
										}
									} else if (j == 1) {

										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
										
											try
											{
												
											bd.setTrackingId((cell.getStringCellValue()));
                                              if(bd.getTrackingId().length()>10)
											{
												logger.info("Tracking Id maximum length should be 10");
												modelAndViewObj.addObject("error", "Tracking Id maximum length should be 10");
												modelAndViewObj.setViewName("reversal");
												 fileDetailsObj.getConnection().close();
												 return modelAndViewObj;
											}
                                              Long.parseLong(cell.getStringCellValue());
											}
											catch(Exception e)
											{
												logger.info("Tracking Id should be only Number");
												modelAndViewObj.addObject("error", "Tracking id should be only number");
												modelAndViewObj.setViewName("reversal");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											
										}
									} else if (j == 2) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											try
											{
												
											bd.setTrackingIdServ((cell.getStringCellValue()));
                                              if(bd.getTrackingIdServ().length()>3)
											{
												logger.info("Tracking Id Serv maximum length should be 3");
												modelAndViewObj.addObject("error", "Tracking Id Serv maximum length should be 3");
												modelAndViewObj.setViewName("reversal");
												 fileDetailsObj.getConnection().close();
												 return modelAndViewObj;
											}
                                              Long.parseLong(cell.getStringCellValue());
											}
											catch(Exception e)
											{
												logger.info("Tracking Id Serv should be only Number");
												modelAndViewObj.addObject("error", "Tracking id serv should be only number");
												modelAndViewObj.setViewName("reversal");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}

											
										}
									} else if (j == 3) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											try
											{
												
											bd.setPaymentCode(cell.getStringCellValue());
                                              if(bd.getPaymentCode().length()>10)
											{
												logger.info("Payment code (BMF_TRANS_TYPE) maximum length should be 10");
												modelAndViewObj.addObject("error", "Payment code (BMF_TRANS_TYPE) maximum length should be 10");
												modelAndViewObj.setViewName("reversal");
												 fileDetailsObj.getConnection().close();
												 return modelAndViewObj;
											}
                                              Long.parseLong(cell.getStringCellValue());
											}
											catch(Exception e)
											{
												logger.info("Payment Code should be only Number");
												modelAndViewObj.addObject("error", "payment code should be only number");
												modelAndViewObj.setViewName("reversal");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										
											
										}
									} else if (j == 4) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {cell.setCellType(
												Cell.CELL_TYPE_STRING);
										
										
										  try {
										//		date = new SimpleDateFormat("MM/dd/yyyy").parse(cell.getStringCellValue());
												// java.sql.Date sqlDate13 = new java.sql.Date(cell.getDateCellValue().getTime());
											  String dateString=cell.getStringCellValue();
                                             if(dateString.length()>10||!(dateString.matches(dateRegex)))
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Reversal date the File should be only Date",original,null,null);
													logger.info("Reversal Date should be only date");
													modelAndViewObj.addObject("error", "Invalid File:Reversal Date Format should be valid(MM/DD/YYYY)");
													modelAndViewObj.setViewName("reversal");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
												 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
												 Date  date =  sdf.parse(dateString); 
												 java.sql.Date sqlDate13 = new java.sql.Date(date.getTime());
												bd.setPaymentDate(sqlDate13);
												

													String subString2= dateString.substring(0, 2);
													
													String subString3= dateString.substring(3, 5);
													boolean status1=true;
													boolean status2=true;
													
													
													if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
													status1=false;
													if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
													status2=false;
													if(!(status1&&status2))
													{
														modelAndViewObj.addObject("error", "Invalid File:Reversal Date Format should be valid(MM/DD/YYYY)");
														modelAndViewObj.setViewName("reversal");
														 fileDetailsObj.getConnection().close();
														return modelAndViewObj;
													}
													
													
																				    
												
									        } catch (Exception ex) {
									        	ex.printStackTrace();
									        	SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Trans date IN THE FILE SHOULD BE ONLY Date",original,null,null);
												logger.info("Trans Date SHOULD BE ONLY date");
												modelAndViewObj.addObject("error", "Invalid File:Reversal Date Format should be valid(MM/DD/YYYY)");
												modelAndViewObj.setViewName("reversal");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
									        }

									//	  bd.setPaymentDate(null);
							      }
									} else if (j == 5) {

										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setSRNo(cell
													.getStringCellValue());
                                          if(bd.getSRNo().length()>20)
											{
												logger.info("SR Number maximum length should be 20");
												modelAndViewObj.addObject("error", "SR Number maximum length should be 20");
												modelAndViewObj.setViewName("reversal");
												 fileDetailsObj.getConnection().close();
												 return modelAndViewObj;
											}
											
										}
									} else if (j == 6) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setAnnotation(cell
													.getStringCellValue());
                                          if(bd.getAnnotation().length()>255)
											{
												logger.info("Annotation maximum length should be 255");
												modelAndViewObj.addObject("error", "Annotation maximum length should be 255");
												modelAndViewObj.setViewName("reversal");
												 fileDetailsObj.getConnection().close();
												 return modelAndViewObj;
											}
										}
									}
									
								}
							
								bulkList.add(bd);
								}
							}
							int b = bulkDao.insertDetails(bulkList,fileDetailsObj1.getConnection(),fileDetailsObj1.getTransactionDef(),fileDetailsObj1.getTransactionManager(),fileDetailsObj1.getTransaction());
							
							//System.out.println("Status of transaction : "+b);
							if(b==0){
								//fileDetailsObj1.getTransactionManager().rollback(fileDetailsObj1.getTransaction());
								isValidTrans=false;
							//	break;
							}
							else{
								logger.info("INSERTED into records table");
								isValidTrans=true;
							}
							if(isValidTrans){
								fileDetailsObj.setConnection(fileDetailsObj1.getConnection());
								fileDetailsObj.setTransaction(fileDetailsObj1.getTransaction());
								fileDetailsObj.setTransactionManager(fileDetailsObj1.getTransactionManager());
								fileDetailsObj.setTransactionDef(fileDetailsObj1.getTransactionDef());
								fileDetailsObj2 = bulkDao
										.recordCheckxlsReversal(fileDetailsObj,errorFilesPath,extension);
						
								
								//System.out.println(" sno in activity log ::"+SNo);
                        if(fileDetailsObj2.getErrorMsg().equalsIgnoreCase("SUCCESS")&&fileDetailsObj2.getStatus()==null)
                        {
                          	 fileDetailsObj2.setConnection(fileDetailsObj1.getConnection());
   								fileDetailsObj2.setTransaction(fileDetailsObj1.getTransaction());
   								fileDetailsObj2.setTransactionManager(fileDetailsObj1.getTransactionManager());
   								fileDetailsObj2.setTransactionDef(fileDetailsObj1.getTransactionDef());
   								fileDetailsObj2.setUserId(userId);
   								fileDetailsObj2.setSessionId(session.getId());
   							 BulkUtil.fileUpload(file,downloadpath,fileDetailsObj1.getOriginalFileName(),extension);
   							 
   							 fileDetailsObj.getConnection().commit();
   							 
	                             fileDetailsObj.getTransactionManager().commit(fileDetailsObj.getTransaction());
	                        	
	                       
	                           fileDetailsObj.getConnection().close();
	                           logger.info("End of Reversal Upload");
   						//FileDetails fileDetailsObj3  =bulkDao.approveReversalFilePaymentCheck(fileDetailsObj2,errorFilesPath,extension);
   	

                           }
                        else if(fileDetailsObj2.getErrorMsg().equalsIgnoreCase("SUCCESS")&&fileDetailsObj2.getStatus()!=null)
                        {
                       	
					
                        	logger.info("End of Reversal Upload");
								SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","success"," file Upload  success and validations are not successfull",original,null,null); 
								  fileDetailsObj.getConnection().commit();
	                              fileDetailsObj.getTransactionManager().commit(fileDetailsObj.getTransaction());
	                        
	                            fileDetailsObj.getConnection().close();
                        }
                        else
                        {
                        	
                        	logger.info("File has been  not uploaded because of data failure issues ");
                        	
                        	fileDetailsObj.getTransactionManager().rollback(fileDetailsObj.getTransaction());
                        	fileDetailsObj.getConnection().close();
                        	SNo=activityLogDao.insertActivityLog(SNo,userId,"file uploading","failed","failed because of data failure issues",original,null,null);
								 modelAndViewObj.addObject("error","data failure issues");
								 modelAndViewObj.setViewName("reversal");
								 return modelAndViewObj;
                        }
    
							modelAndViewObj.addObject("flag",
									fileDetailsObj2.getFlag());
							modelAndViewObj.addObject("status",
									fileDetailsObj2.getStatus());
							 modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj1);
							 modelAndViewObj.addObject("extension", extension);
								modelAndViewObj.setViewName("reversalSuccess");

							}
							else{
								logger.info("records are not inserted because of data failure issues");
								SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","Failure","Data issues!!",original,null,null);
								 modelAndViewObj.addObject("error","data failure issues");
								 modelAndViewObj.setViewName("reversal");
								 return modelAndViewObj;
							}
	
					}else

					{
						// System.out.println("Given header amount and sum of all the records are not matched..!!!");
						 SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","file already uploaded",original,null,null);
					
						 modelAndViewObj.addObject("error", "Same fileName already Uploaded");
						modelAndViewObj.setViewName("reversal");
						return modelAndViewObj;
					} }
		    	   else
		    	   {
		    		   logger.info("file  details has not been inserted into status table because of data failure issues");
	    		   modelAndViewObj.addObject("error", "database  failure issues");
	    		   modelAndViewObj.setViewName("reversal");
	    		   return modelAndViewObj;// main if sumCountHeader==sum closed
		    	  
		    	   }
		    	   
				} else

				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","failure","Headers are not matched",original,null,null);
				
					logger.info("Given header is not macthed");

					modelAndViewObj.addObject("error", "Header not matched");
					modelAndViewObj.setViewName("reversal");
					return modelAndViewObj;
				}
			
				
			}

			catch (Exception e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("error", "Invalid file");
				modelAndViewObj.setViewName("reversal");
				return modelAndViewObj;
				
			}

		}

		else {
			try{
			SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","valid xls file","file is empty",original,null,null);
			}catch(SQLException sqlexception)
			{
				sqlexception.printStackTrace();
				modelAndViewObj.addObject("message","DB Connectivity issues");
				modelAndViewObj.setViewName("Error");
				return modelAndViewObj;
			}
			logger.info("File is not valid!!");

			modelAndViewObj.addObject("error", "Entered file is empty!!");
			modelAndViewObj.setViewName("reversal");
			return modelAndViewObj;
		}
		return modelAndViewObj;
		
		
	}
	public  ModelAndView validatexlsxReversal(
			 MultipartFile file,
			HttpServletRequest request,String downloadpath,String errorFilesPath, String extension) 
	{
		boolean isValidTrans=false;
		FileDetails fileDetailsObj2=null;
		session=request.getSession(true);
		FileDetails fileDetailsObj=new FileDetails();
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
      	String dateRegex="[0-9][0-9][\\/][0-9][0-9][\\/][0-9]{4}";
		String original = file.getOriginalFilename();
		fileDetailsObj.setOriginalFileName(original);
		logger.info("original file name is:" + original);


		ModelAndView modelAndViewObj=new ModelAndView();
		boolean recordCount = BulkUtil.validateRecordCount(file);
		//int SNo=0;
		Long SNo = 0l;
		try {
			SNo = activityLogDao.insertActivityLog(0l,userId,"file upload",null,null,original,null,null);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		if (recordCount) {
		

			try {

				InputStream file1 = (file
						.getInputStream());
					Workbook workbook = new XSSFWorkbook(file1);
			//	XSSFWorkbook workbook=(XSSFWorkbook) WorkbookFactory.create(file1);
			//	org.apache.poi.xssf.usermodel.XSSFSheet  sheet = workbook.getSheetAt(0);
				XSSFSheet  sheet = (XSSFSheet) workbook.getSheetAt(0);
				logger.info("Present Sheet name is" + "\t"
						+ workbook.getSheetName(0));

		//		Iterator<Row> rows1 = sheet.rowIterator();

			//	Row row1 = (Row) rows1.next();
				int  noOfRec = sheet.getPhysicalNumberOfRows() - 1;
			//	System.out.println(noOfRec);
				fileDetailsObj.setTotalRecords(noOfRec);
			
				if(noOfRec==-1)
				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT is zero",original,null,null);
		              logger.info("invalid file with no records");
						modelAndViewObj.addObject("error",
								"Invalid file with no records");
						modelAndViewObj.setViewName("reversal");
						return modelAndViewObj;
				}
				Iterator<Row> rowIterator1 = sheet.iterator();
				Row row2 = (XSSFRow) rowIterator1.next();
				


				List<String> headersList=new ArrayList<String>();
				
				
				for (int j = row2.getFirstCellNum(); j <=6; j++)
				{
					Cell cell=row2.getCell(j);
					if (cell != null) {
			   		cell.setCellType(
							Cell.CELL_TYPE_STRING);
								headersList.add(cell.getStringCellValue());
							}
			   else
			   {
				   SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Invalid File",original,null,null);
			          logger.info("invalid file ");
						modelAndViewObj.addObject("error",
								"Invalid file  ");
						modelAndViewObj.setViewName("reversal");
						return modelAndViewObj;
			   }}
				


			
// SNo=activityLogDao.insertActivityLog(0,"CAD_SPOC","File level validations header",null,null);


				String headerStatus=bulkDao.headerProc("REVERSAL",null,headersList);

				logger.info("header status is" +headerStatus);	
				
			
				if(!(headerStatus.equalsIgnoreCase("SUCCESS")))
				{
					modelAndViewObj.addObject("error",
							"Invalid file WITH HEADER MISMATCH");
					modelAndViewObj.setViewName("reversal");
					return modelAndViewObj;
				}
				if(noOfRec==0)
				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT is zero",original,null,null);
		              logger.info("invalid file with no records");
						modelAndViewObj.addObject("error",
								"Invalid file with no records");
						modelAndViewObj.setViewName("reversal");
						return modelAndViewObj;
				}
				//System.out.println("\n no of rec " + noOfRec);
				if(noOfRec>MAXIMUM_RECORDS_IN_FILE)
				{
	             logger.info("record count has exceeded");
	             modelAndViewObj.addObject("error",
							"Count of Total records should not be more than"+MAXIMUM_RECORDS_IN_FILE);
					modelAndViewObj.setViewName("bulk");
					return modelAndViewObj;
				}
						

							
					java.util.Date utilDate = new java.util.Date();
					java.sql.Date sqlDate = new java.sql.Date(
							utilDate.getTime());
				
					fileDetailsObj.setVendorUserId(userId);//session
				
					fileDetailsObj.setVendorType(role);//session
				//	fileDetailsObj.setPaymentAmount(sum);
					fileDetailsObj.setFileTYpe("DIRECT_REVERSAL");
								

								
						
		       if(headerStatus.equalsIgnoreCase("SUCCESS")){
		    	   
		    	
		    	   FileDetails fileDetailsObj1 = bulkDao.reversalFileDetails(fileDetailsObj);
		    	  
		    	   if(fileDetailsObj1.getErrorMsg().equalsIgnoreCase("SUCCESS"))
		    	   {
				
		    		   if (fileDetailsObj1.getStatus().equalsIgnoreCase("1")) {
	
							
						modelAndViewObj.addObject("status",
								fileDetailsObj1.getStatus());
						modelAndViewObj.addObject("fileId",
								fileDetailsObj1.getFileID());
						java.util.Date utilDate1 = new java.util.Date();
						java.sql.Date sqlDate1 = new java.sql.Date(
								utilDate1.getTime());
						
						//System.out.println("payment date in records table"+formattedDate);
					int serialNo=0;
					List<BulkDetails> bulkList=new ArrayList<BulkDetails>();
							while (rowIterator1.hasNext()) {
								BulkDetails bd = new BulkDetails();
								serialNo++;
								bd.setsNo(Integer.toString(serialNo));
								
								
								row2 = (XSSFRow) rowIterator1.next();
								boolean isRowEmpty=isRowEmpty(row2);
								
								if(isRowEmpty)
								{
									
									rowIterator1.remove();
								}
								else
								{
								
								for (int j = row2.getFirstCellNum(); j <=6; j++) {
									
									bd.setFileID(fileDetailsObj.getFileID());
									
									bd.setChangeDate(sqlDate1);
									bd.setTransferType("REVERSAL");
									Cell cell=row2.getCell(j);
									if (j == 0) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											bd.setAcctEXTID(cell
													.getStringCellValue());
                                          if(bd.getAcctEXTID().length()>75)
											{
												logger.info("ACCOUNT_NO maximum length should be 75");
												modelAndViewObj.addObject("error", "ACCOUNT_NO maximum length should be 75");
												modelAndViewObj.setViewName("reversal");
												 fileDetailsObj.getConnection().close();
												 return modelAndViewObj;
											}
								
										}
									} else if (j == 1) {

										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											row2.getCell(j).setCellType(
													Cell.CELL_TYPE_STRING);
										
											try
											{
												
											bd.setTrackingId(cell.getStringCellValue());
											if(cell.getStringCellValue().length()>10)
											{
												logger.info("Tracking Id should be max 10 digits");
												modelAndViewObj.addObject("error", "Tracking Id should be max 10 digits");
												modelAndViewObj.setViewName("reversal");
												   fileDetailsObj1.getConnection().close();
												return modelAndViewObj;
											}
                                              Long.parseLong(cell.getStringCellValue());
											}
											catch(Exception e)
											{
												logger.info("Tracking Id should be only number");
												modelAndViewObj.addObject("error", "Tracking ID should be only number");
												modelAndViewObj.setViewName("reversal");
												   fileDetailsObj1.getConnection().close();
												return modelAndViewObj;
											}
											
										}
									} else if (j == 2) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											try
											{
												
											bd.setTrackingIdServ(cell.getStringCellValue());
											if(cell.getStringCellValue().length()>3)
											{
												logger.info("Tracking Id serv  should be max 3 digits");
												modelAndViewObj.addObject("error", "Tracking Id serv should be max 3 digits");
												modelAndViewObj.setViewName("reversal");
												   fileDetailsObj1.getConnection().close();
												return modelAndViewObj;
											}
                                              Long.parseLong(cell.getStringCellValue());
											}
											catch(Exception e)
											{
												logger.info("Tracking Id serv should be only number");
												modelAndViewObj.addObject("error", "Tracking ID serv should be only number");
												modelAndViewObj.setViewName("reversal");
												  fileDetailsObj1.getConnection().close();
												return modelAndViewObj;
											}

											
										}
									} else if (j == 3) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											try
											{
												
											bd.setPaymentCode(cell.getStringCellValue());
                                              if(bd.getPaymentCode().length()>10)
											{
												logger.info("Payment code (BMF_TRANS_TYPE) maximum length should be 10");
												modelAndViewObj.addObject("error", "Payment code (BMF_TRANS_TYPE) maximum length should be 10");
												modelAndViewObj.setViewName("reversal");
												 fileDetailsObj.getConnection().close();
												 return modelAndViewObj;
											}
                                              Long.parseLong(cell.getStringCellValue());
											}
											catch(Exception e)
											{
												logger.info("Payment Code should be only number");
												modelAndViewObj.addObject("error", "Payment Code should be only number");
												modelAndViewObj.setViewName("reversal");
												  fileDetailsObj1.getConnection().close();
												return modelAndViewObj;
											}
										
											
										}
									} else if (j == 4) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
																					
										
														  try {
														
															  String dateString=cell.getStringCellValue();
                                                  if(dateString.length()>10||!(dateString.matches(dateRegex)))
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Reversal date the File should be only Date",original,null,null);
													logger.info("Reversal Date should be only date");
													modelAndViewObj.addObject("error", "Invalid File:Reversal Date Format should be valid(MM/DD/YYYY)");
													modelAndViewObj.setViewName("reversal");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
																 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
																 Date  date =  sdf.parse(dateString); 
																 java.sql.Date sqlDate13 = new java.sql.Date(date.getTime());
																bd.setPaymentDate(sqlDate13);
																
																	String subString2= dateString.substring(0, 2);
																	
																	String subString3= dateString.substring(3, 5);
																	boolean status1=true;
																	boolean status2=true;
																	
																	
																	if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
																	status1=false;
																	if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
																	status2=false;
																	if(!(status1&&status2))
																	{
																		modelAndViewObj.addObject("error", "Invalid File:Reversal Date Format should be valid(MM/DD/YYYY)");
																		modelAndViewObj.setViewName("reversal");
																		 fileDetailsObj.getConnection().close();
																		return modelAndViewObj;
																	}
																	
																													    
																
													        } catch (Exception ex) {
													        	ex.printStackTrace();
													        	SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Reversal date IN THE FILE SHOULD BE ONLY Date",original,null,null);
																logger.info("Trans Date SHOULD BE ONLY date");
																modelAndViewObj.addObject("error", "Invalid File:Reversal Date Format should be valid(MM/DD/YYYY)");
																modelAndViewObj.setViewName("reversal");
																 fileDetailsObj.getConnection().close();
																return modelAndViewObj;
													        }

													
													
												}
									} else if (j == 5) {

										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setSRNo(cell
													.getStringCellValue());
                                          if(bd.getSRNo().length()>20)
											{
												logger.info("SR Number maximum length should be 20");
												modelAndViewObj.addObject("error", "SR Number maximum length should be 20");
												modelAndViewObj.setViewName("reversal");
												 fileDetailsObj.getConnection().close();
												 return modelAndViewObj;
											}
											
										}
									} else if (j == 6) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setAnnotation(cell
													.getStringCellValue());
                                          if(bd.getAnnotation().length()>255)
											{
												logger.info("Annotation maximum length should be 255");
												modelAndViewObj.addObject("error", "Annotation maximum length should be 255");
												modelAndViewObj.setViewName("reversal");
												 fileDetailsObj.getConnection().close();
												 return modelAndViewObj;
											}
										}
									}
									
								}
								bulkList.add(bd);
								}
							}
							int b = bulkDao.insertDetails(bulkList,fileDetailsObj1.getConnection(),fileDetailsObj1.getTransactionDef(),fileDetailsObj1.getTransactionManager(),fileDetailsObj1.getTransaction());
							
							
							if(b==0){
							//	fileDetailsObj1.getTransactionManager().rollback(fileDetailsObj1.getTransaction());
								isValidTrans=false;
							//	break;
							}
							else{
							
								isValidTrans=true;
							}
						    
							if(isValidTrans){
								fileDetailsObj.setConnection(fileDetailsObj1.getConnection());
								fileDetailsObj.setTransaction(fileDetailsObj1.getTransaction());
								fileDetailsObj.setTransactionManager(fileDetailsObj1.getTransactionManager());
								fileDetailsObj.setTransactionDef(fileDetailsObj1.getTransactionDef());
								fileDetailsObj2 = bulkDao
										.recordCheckxlsxReversal(fileDetailsObj,errorFilesPath,extension);
						
								
								//System.out.println(" sno in activity log ::"+SNo);
								  if(fileDetailsObj2.getErrorMsg().equalsIgnoreCase("SUCCESS")&&fileDetailsObj2.getStatus()==null)
			                         {
				                       	     fileDetailsObj2.setConnection(fileDetailsObj1.getConnection());
											fileDetailsObj2.setTransaction(fileDetailsObj1.getTransaction());
											fileDetailsObj2.setTransactionManager(fileDetailsObj1.getTransactionManager());
											fileDetailsObj2.setTransactionDef(fileDetailsObj1.getTransactionDef());
											 BulkUtil.fileUpload(file,downloadpath,fileDetailsObj1.getOriginalFileName(),extension);
											fileDetailsObj2.setUserId(userId);
											fileDetailsObj2.setSessionId(session.getId());
											 fileDetailsObj.getConnection().commit();
				                             fileDetailsObj.getTransactionManager().commit(fileDetailsObj.getTransaction());
				                       
				                           fileDetailsObj.getConnection().close();
				                           logger.info("End of Upload");
				                         
			                        }
			                         else if(fileDetailsObj2.getErrorMsg().equalsIgnoreCase("SUCCESS")&&fileDetailsObj2.getStatus()!=null)
			                         {
			                        	
			                        	 logger.info("validations failed");
			                        	 logger.info("End of Upload");
											SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","success"," file Upload succesfull but validations failed",original,null,null); 
											  fileDetailsObj2.getConnection().commit();
				                              fileDetailsObj2.getTransactionManager().commit(fileDetailsObj.getTransaction());
				                        
				                            fileDetailsObj2.getConnection().close();
			                         }
                        else
                        {
                        	
                        	logger.info("File has been  not uploaded because of data failure issues ");
                        	
                        	fileDetailsObj.getTransactionManager().rollback(fileDetailsObj.getTransaction());
                        	fileDetailsObj.getConnection().close();
                        	SNo=activityLogDao.insertActivityLog(SNo,userId,"file uploading","failed","failed because of data failure issues",original,null,null);
								 modelAndViewObj.addObject("error","data failure issues");
								 modelAndViewObj.setViewName("reversal");
								 return modelAndViewObj;
                        }
                    		modelAndViewObj.addObject("flag",
									fileDetailsObj2.getFlag());
							modelAndViewObj.addObject("status",
									fileDetailsObj2.getStatus());
							 modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj1);
							 modelAndViewObj.addObject("extension", extension);
								modelAndViewObj.setViewName("reversalSuccess");
								

							}
							else{
								logger.info("records are not inserted because of data failure issues");
								SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","Failure","Data issues!!",original,null,null);
								 modelAndViewObj.addObject("error","data failure issues");
								 modelAndViewObj.setViewName("reversal");
								
		                        	//fileDetailsObj.getConnection().close();
								 return modelAndViewObj;
							}
	
					}else

					{
						// System.out.println("Given header amount and sum of all the records are not matched..!!!");
						 SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","file already uploaded",original,null,null);
					
						 modelAndViewObj.addObject("error", "Same fileName cannot be Uploaded again");
						modelAndViewObj.setViewName("reversal");
						return modelAndViewObj;
					} }
		    	   else
		    	   {
		    		   logger.info("file  details has not been inserted into status table because of data failure issues");
	    		   modelAndViewObj.addObject("error", "database  failure issues");
	    		   modelAndViewObj.setViewName("reversal");
	    		 
               	   fileDetailsObj.getConnection().close();
	    		   return modelAndViewObj;// main if sumCountHeader==sum closed
		    	  
		    	   }
		    	   
				} else

				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","failure","headers are not matched",original,null,null);
				
					logger.info("Given header is not macthed");

					modelAndViewObj.addObject("error", "Header not matched");
					modelAndViewObj.setViewName("reversal");
					return modelAndViewObj;
				}
			
				
			}

			catch (Exception e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("error", "invalid file with different format");
				modelAndViewObj.setViewName("reversal");
				return modelAndViewObj;
				
			}

		}

		else {
			try {
				SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","valid xls file","file is empty",original,null,null);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
			
			logger.info("File is not valid!!");

			modelAndViewObj.addObject("error", "Entered file is empty!!");
			modelAndViewObj.setViewName("reversal");
			return modelAndViewObj;
		}
		return modelAndViewObj;
		}
	public  ModelAndView validatexlsxChequeBounce(
			 MultipartFile file,
			HttpServletRequest request,String downloadpath,String errorFilesPath, String extension) 
	{boolean isValidTrans=false;
	FileDetails fileDetailsObj2=null;
	session=request.getSession(true);
	FileDetails fileDetailsObj=new FileDetails();
	String userId=session.getAttribute("userid").toString();
	String role=session.getAttribute("user_role_id").toString();
     String dateRegex="[0-9][0-9][\\/][0-9][0-9][\\/][0-9]{4}";
	String original = file.getOriginalFilename();
	fileDetailsObj.setOriginalFileName(original);
	logger.info("original file name is:" + original);
	double cellValue2=0;
	double sum=0;

	ModelAndView modelAndViewObj=new ModelAndView();
	boolean recordCount = BulkUtil.validateRecordCount(file);
	
	Long SNo = 0l;
	try {
		SNo = activityLogDao.insertActivityLog(0l,userId,"file upload",null,null,original,null,null);
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
	if (recordCount) {
		try {

			InputStream file1 = (file
					.getInputStream());

		//	XSSFWorkbook workbook=(XSSFWorkbook) WorkbookFactory.create(file1);
          Workbook workbook = new XSSFWorkbook(file1);
          XSSFSheet  sheet = (XSSFSheet) workbook.getSheetAt(0);
		//	org.apache.poi.xssf.usermodel.XSSFSheet  sheet = workbook.getSheetAt(0);
			System.out.println("Present Sheet name is" + "\t"
					+ workbook.getSheetName(0));

//			Iterator<Row> rows1 = sheet.rowIterator();
	
			int  noOfRec = sheet.getPhysicalNumberOfRows() - 1;
	
			fileDetailsObj.setTotalRecords(noOfRec);
			
			if(noOfRec==-1)
			{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT is zero",original,null,null);
	              logger.info("invalid file with no records");
					modelAndViewObj.addObject("error",
							"Invalid file with no records");
					modelAndViewObj.setViewName("reversal");
					return modelAndViewObj;
			}
			Iterator<Row> rowIterator1 = sheet.iterator();
			Row row2 = (XSSFRow) rowIterator1.next();
		
			List<String> headersList=new ArrayList<String>();
			
			
			for (int j = row2.getFirstCellNum(); j <=7; j++)
			{
				Cell cell=row2.getCell(j);
				if (cell != null) {
		   		cell.setCellType(
						Cell.CELL_TYPE_STRING);
							headersList.add(cell.getStringCellValue());
						}
		   else
		   {
			   SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Invalid File",original,null,null);
		          logger.info("invalid file ");
					modelAndViewObj.addObject("error",
							"Invalid file  ");
					modelAndViewObj.setViewName("reversal");
					return modelAndViewObj;
		   }
		}
			
			logger.info("size of headers list is " +headersList.size());


			String headerStatus=bulkDao.headerProc("CHEQUE_BOUNCE",null,headersList);

			logger.info("header status is" +headerStatus);
			if(!(headerStatus.equalsIgnoreCase("SUCCESS")))
			{
				modelAndViewObj.addObject("error",
						"Invalid file WITH HEADER MISMATCH");
				modelAndViewObj.setViewName("reversal");
				return modelAndViewObj;
			}
			if(noOfRec==0)
			{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT is zero",original,null,null);
	              logger.info("invalid file with no records");
					modelAndViewObj.addObject("error",
							"Invalid file with no records");
					modelAndViewObj.setViewName("reversal");
					return modelAndViewObj;
			}
			if(noOfRec>MAXIMUM_RECORDS_IN_FILE)
			{
				logger.info("record count has exceeded");
				modelAndViewObj.addObject("error",
						"Count of Total records should not be more than"+MAXIMUM_RECORDS_IN_FILE);
				modelAndViewObj.setViewName("reversal");
				return modelAndViewObj;
			}
			System.out.println("\n no of rec " + noOfRec);

		//	row1 = (Row) rows1.next();
			
				//SNo=activityLogDao.insertActivityLog(SNo,"CAD_SPOC","File level validations","success","record count and sum is matched");
									
				java.util.Date utilDate = new java.util.Date();
				java.sql.Date sqlDate = new java.sql.Date(
						utilDate.getTime());
				//DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			//	Date date = new Date();
				fileDetailsObj.setVendorUserId(userId);//session
				
			//	fileDetailsObj.setFileUploadDate(sqlDate);
			
			//	fileDetailsObj.setChangeWho("useriD");//session
			//	fileDetailsObj.setChangeDate(sqlDate);
				//fileDetailsObj.setVendorID(userId);//session
				fileDetailsObj.setVendorType(role);//session
			//	fileDetailsObj.setPaymentAmount(sum);
				fileDetailsObj.setFileTYpe("CHEQUE_BOUNCE");
							

				Iterator<Row> rows = sheet.iterator();
				Row row=(XSSFRow)rows.next();
				
				while (rows.hasNext()) {
					try
					{
                      Cell cell2 = row.getCell((short) 5);
					row = (XSSFRow) rows.next();
                      if(cell2!=null)
					row.getCell(5).setCellType(
							Cell.CELL_TYPE_STRING);
					if(row.getCell(5)!=null)
					{
					 cell2 = row.getCell((short) 5);
					if(!cell2.getStringCellValue().isEmpty())
					cellValue2 = Double.parseDouble(cell2.getStringCellValue());
					
					sum = (sum + cellValue2);
					}
					
					fileDetailsObj.setPaymentAmount(Double.toString(sum));
					
					}catch(Exception e)
					{
						SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Payment Amount IN THE FILE SHOULD BE ONLY NUMBER",original,null,null);
						logger.info("Payment Amount SHOULD BE ONLY NUMBER");
						modelAndViewObj.addObject("error", "Payment Amount should be only Number");
						modelAndViewObj.setViewName("reversal");
						return modelAndViewObj;
					}
				}		
					
	       if(headerStatus.equalsIgnoreCase("SUCCESS")){
	    	   
	    	//   SNo=activityLogDao.insertActivityLog(SNo,"CAD_SPOC","File level validations header","success","headers are matched");
	    
	    	  // SNo=activityLogDao.insertActivityLog(0,"CAD_SPOC","file uploading",null,null);
	    	   FileDetails fileDetailsObj1 = bulkDao.reversalFileDetails(fileDetailsObj);
	    	  
	    	   if(fileDetailsObj1.getErrorMsg().equalsIgnoreCase("SUCCESS"))
	    	   {
			
	    		   if (fileDetailsObj1.getStatus().equalsIgnoreCase("1")) {

					modelAndViewObj.addObject("status",
							fileDetailsObj1.getStatus());
					modelAndViewObj.addObject("fileId",
							fileDetailsObj1.getFileID());
					java.util.Date utilDate1 = new java.util.Date();
					java.sql.Date sqlDate1 = new java.sql.Date(
							utilDate1.getTime());
					
					//System.out.println("payment date in records table"+formattedDate);
				int serialNo=0;
				List<BulkDetails> bulkList=new ArrayList<BulkDetails>();
						while (rowIterator1.hasNext()) {
							
							BulkDetails bd = new BulkDetails();
							/*serialNo++;
							bd.setsNo(serialNo);*/
							
							row2 = (XSSFRow) rowIterator1.next();
							boolean isRowEmpty=isRowEmpty(row2);
							
							if(isRowEmpty)
							{
								
								rowIterator1.remove();
							}
							else
							{
							
							for (int j = row2.getFirstCellNum(); j <=7; j++) {
								
								bd.setFileID(fileDetailsObj.getFileID());
							//	bd.setPaymentDate(sqlDate1);
								bd.setChangeDate(sqlDate1);
								Cell cell=row2.getCell(j);
								if (j == 0) {
									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);
										try
										{
											if(cell.getStringCellValue().length()>5)
										{
																
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Serial No maximum length should be 5",original,null,null);
												logger.info("Serial No maximum length should be 5");
												modelAndViewObj.addObject("error", "Invalid File:Serial No maximum length should be 5");
												modelAndViewObj.setViewName("reversal");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
										
										}
										Long.parseLong(cell
												.getStringCellValue());
										}
										catch(Exception e)
										{
											SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","SERIAL NO IN THE FILE SHOULD BE ONLY NUMBER",original,null,null);
											logger.info("SERIAL NUMBER SHOULD BE ONLY NUMBER");
											modelAndViewObj.addObject("error", "Serial Number should be only number");
											modelAndViewObj.setViewName("reversal");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
									serialNo++;
									bd.setsNo(Integer.toString(serialNo));
							
									}
								}
								else if (j == 1) {

									  if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
																					
										
														  try {
														//		date = new SimpleDateFormat("MM/dd/yyyy").parse(row2.getCell(j).getStringCellValue());
																// java.sql.Date sqlDate13 = new java.sql.Date(row2.getCell(j).getDateCellValue().getTime());
															     String dateString=cell.getStringCellValue();
                                                             if(dateString.length()>10||!(dateString.matches(dateRegex)))
																{
																	SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Trans date the File should be only Date",original,null,null);
																	logger.info("Trans Date should be only date");
																	modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																	modelAndViewObj.setViewName("reversal");
																	 fileDetailsObj.getConnection().close();
																	return modelAndViewObj;
																}
																 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
																 Date  date =  sdf.parse(dateString); 
																 java.sql.Date sqlDate13 = new java.sql.Date(date.getTime());
																bd.setPaymentDate(sqlDate13);
																 

																	String subString2= dateString.substring(0, 2);
																	
																	String subString3= dateString.substring(3, 5);
																	boolean status1=true;
																	boolean status2=true;
																	
																	
																	if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
																	status1=false;
																	if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
																	status2=false;
																	if(!(status1&&status2))
																	{
																		modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																		modelAndViewObj.setViewName("reversal");
																		 fileDetailsObj.getConnection().close();
																		return modelAndViewObj;
																	}
																	
																	
																															
													        } catch (Exception ex) {
													        	ex.printStackTrace();
													        	SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Trans date IN THE FILE SHOULD BE ONLY Date",original,null,null);
																logger.info("Trans Date SHOULD BE ONLY date");
																modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																modelAndViewObj.setViewName("reversal");
																 fileDetailsObj.getConnection().close();
																return modelAndViewObj;
													        }

													//	  bd.setPaymentDate(null);
											      
													
													
												}
								} else if (j == 2) {
									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);
										
									bd.setChequeNo(cell.getStringCellValue());
                                      if(bd.getChequeNo().length()>15)
									{
										logger.info("Cheque no maximum length should be 15");
										modelAndViewObj.addObject("error", "Invalid File:CHEQUE NO maximum length should be 15");
										modelAndViewObj.setViewName("reversal");
										 fileDetailsObj.getConnection().close();
										return modelAndViewObj;
									}
										
																				
									}
								} else if (j == 3) {
                    if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
						cell.setCellType(
								Cell.CELL_TYPE_STRING);
																
					
									  try {
									//		date = new SimpleDateFormat("MM/dd/yyyy").parse(row2.getCell(j).getStringCellValue());
											// java.sql.Date sqlDate13 = new java.sql.Date(row2.getCell(j).getDateCellValue().getTime());
										  String dateString=cell.getStringCellValue();
                                         if(dateString.length()>10||!(dateString.matches(dateRegex)))
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Cheque date the File should be only Date",original,null,null);
												logger.info("Cheque Date should be only date");
												modelAndViewObj.addObject("error", "Invalid File:Cheque Date Format should be valid(MM/DD/YYYY)");
												modelAndViewObj.setViewName("reversal");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
											 Date  date =  sdf.parse(dateString); 
											 java.sql.Date sqlDate13 = new java.sql.Date(date.getTime());
											bd.setChequeDate(sqlDate13);
											

												String subString2= dateString.substring(0, 2);
												
												String subString3= dateString.substring(3, 5);
												boolean status1=true;
												boolean status2=true;
												
												
												if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
												status1=false;
												if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
												status2=false;
												if(!(status1&&status2))
												{
													modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
													modelAndViewObj.setViewName("reversal");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
												
											
								        } catch (Exception ex) {
								        	ex.printStackTrace();
								        	SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Trans date IN THE FILE SHOULD BE ONLY Date",original,null,null);
											logger.info("Trans Date SHOULD BE ONLY date");
											modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
											modelAndViewObj.setViewName("reversal");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
								        }

								//	  bd.setPaymentDate(null);
						      
								
								
							}
								} else if (j == 4) {
									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);

										bd.setBankName(cell
												.getStringCellValue());
                                      if(bd.getBankName().length()>150)
										{
											logger.info("Bank Name maximum length should be 150");
											modelAndViewObj.addObject("error", "Invalid File:Bank Name maximum length should be 150");
											modelAndViewObj.setViewName("reversal");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
										
									}
								}
								else if (j == 5) {

									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);
										try{
											
										bd.setPaymentAmt((cell
												.getStringCellValue()));
                                          if(bd.getPaymentAmt().length()>18)
										{
											SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Amount size should be maximum 18",original,null,null);
											logger.info("Payment Amount size should be maximum 18");
											modelAndViewObj.addObject("error", "Payment maximum Amount size should be  18");
											modelAndViewObj.setViewName("reversal");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
                                          Double.parseDouble(cell.getStringCellValue());
										}
										catch(Exception e)
										{
											logger.info("Payment Amount should be only number");
											modelAndViewObj.addObject("error", "Payment Amount should be only number");
											modelAndViewObj.setViewName("reversal");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;	
										}
									}
								}
								else if (j == 6) {

									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);

										bd.setBankVirtualAcctNo(cell
												.getStringCellValue());
                                      if(bd.getBankVirtualAcctNo().length()>150)
										{
											logger.info("Bank Account Number maximum length should be 150");
											modelAndViewObj.addObject("error", "Invalid File:Bank Account Number maximum length should be 150");
											modelAndViewObj.setViewName("reversal");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
										
									}
								} else if (j == 7) {
									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);
										bd.setBounceReason(cell
												.getStringCellValue());
                                      if(bd.getBounceReason().length()>150)
									{
										logger.info("Return_Reason maximum length should be 150");
										modelAndViewObj.addObject("error", "Invalid File:Return_Reason maximum length should be 150");
										modelAndViewObj.setViewName("reversal");
										 fileDetailsObj.getConnection().close();
										return modelAndViewObj;
									}
									}
								}
								
							}
						
							bulkList.add(bd);
							}
						}
						int b = bulkDao.insertDetails(bulkList,fileDetailsObj1.getConnection(),fileDetailsObj1.getTransactionDef(),fileDetailsObj1.getTransactionManager(),fileDetailsObj1.getTransaction());
						
						//		System.out.println("Status of transaction : "+b);
								if(b==0){
								//	fileDetailsObj1.getTransactionManager().rollback(fileDetailsObj1.getTransaction());
									isValidTrans=false;
								//	break;
								}
								else{
							//		System.out.println("INSERTED into records table");
									isValidTrans=true;
								}
					    
						if(isValidTrans){
							fileDetailsObj.setConnection(fileDetailsObj1.getConnection());
							fileDetailsObj.setTransaction(fileDetailsObj1.getTransaction());
							fileDetailsObj.setTransactionManager(fileDetailsObj1.getTransactionManager());
							fileDetailsObj.setTransactionDef(fileDetailsObj1.getTransactionDef());
							fileDetailsObj2 = bulkDao
									.recordCheckxlsxChequeBounce(fileDetailsObj,errorFilesPath,extension);
					
							
							//System.out.println(" sno in activity log ::"+SNo);
                    if(fileDetailsObj2.getErrorMsg().equalsIgnoreCase("SUCCESS")&&fileDetailsObj2.getStatus()==null)
                    {
                   	 fileDetailsObj2.setConnection(fileDetailsObj1.getConnection());
							fileDetailsObj2.setTransaction(fileDetailsObj1.getTransaction());
							fileDetailsObj2.setTransactionManager(fileDetailsObj1.getTransactionManager());
							fileDetailsObj2.setTransactionDef(fileDetailsObj1.getTransactionDef());
							fileDetailsObj2.setUserId(userId);
							fileDetailsObj2.setSessionId(session.getId());
							BulkUtil.fileUpload(file,downloadpath,fileDetailsObj1.getOriginalFileName(),extension);
							 fileDetailsObj.getTransactionManager().commit(fileDetailsObj.getTransaction());
							 fileDetailsObj.getConnection().commit();
                            
                       
                           fileDetailsObj.getConnection().close();
                         

                    }
                    else if(fileDetailsObj2.getErrorMsg().equalsIgnoreCase("SUCCESS")&&fileDetailsObj2.getStatus()!=null)
                    {
                    	 
							logger.info("validations are succesfull");
							SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","success"," file Upload and validations successfull",original,null,null); 
							  fileDetailsObj.getConnection().commit();
                              fileDetailsObj.getTransactionManager().commit(fileDetailsObj.getTransaction());
                        
                            fileDetailsObj.getConnection().close();
                    }
                    else
                    {
                    	
                    	logger.info("File has been  not uploaded because of data failure issues ");
                    	
                    	fileDetailsObj.getTransactionManager().rollback(fileDetailsObj.getTransaction());
                    	fileDetailsObj.getConnection().close();
                    	SNo=activityLogDao.insertActivityLog(SNo,userId,"file uploading","failed","failed because of data failure issues",original,null,null);
							 modelAndViewObj.addObject("error","data failure issues"+fileDetailsObj2.getErrorMsg());
							 modelAndViewObj.setViewName("reversal");
							 return modelAndViewObj;
                    }
                	
						
						

						modelAndViewObj.addObject("flag",
								fileDetailsObj2.getFlag());
						modelAndViewObj.addObject("status",
								fileDetailsObj2.getStatus());
						 modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj1);
						 modelAndViewObj.addObject("extension", extension);
							modelAndViewObj.setViewName("reversalSuccess");
							logger.info("End of Upload");

						}
						else{
							logger.info("records are not inserted because of data failure issues");
							SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","Failure","Data issues!!",original,null,null);
							 modelAndViewObj.addObject("error","data failure issues");
							
	                        	fileDetailsObj.getConnection().close();
							 modelAndViewObj.setViewName("reversal");
							 return modelAndViewObj;
						}

				}else

				{
					// System.out.println("Given header amount and sum of all the records are not matched..!!!");
					 SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","file already uploaded",original,null,null);
				
					 modelAndViewObj.addObject("error", "Same fileName already uploaded");
					modelAndViewObj.setViewName("reversal");
					return modelAndViewObj;
				} }
	    	   else
	    	   {
	    		   logger.info("file  details has not been inserted into status table because of data failure issues");
    		   modelAndViewObj.addObject("error", "database  failure issues");
    		   modelAndViewObj.setViewName("reversal");
    		   return modelAndViewObj;// main if sumCountHeader==sum closed
	    	  
	    	   }
	    	   
			} else

			{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","failure","headers are not matched",original,null,null);
			
				logger.info("Given header is not macthed");

				modelAndViewObj.addObject("error", "Header not matched");
				modelAndViewObj.setViewName("reversal");
				return modelAndViewObj;
			}
		
			
		}

		catch (Exception e) {
			StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			modelAndViewObj.addObject("error", "Data failure ");
			modelAndViewObj.setViewName("reversal");
			return modelAndViewObj;
			
		}

	}

	else {
		try {
			SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","valid xls file","file is empty",original,null,null);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println("sno in activity log"+SNo);
		logger.info("File is not valid!!");

		modelAndViewObj.addObject("error", "Entered file is empty!!");
		modelAndViewObj.setViewName("reversal");
		return modelAndViewObj;
	}
	return modelAndViewObj;
	}
	public  ModelAndView validatexlsChequeBounce(
			 MultipartFile file,
			HttpServletRequest request,String downloadpath,String errorFilesPath, String extension) 
	{boolean isValidTrans=false;
	FileDetails fileDetailsObj2=null;
	session=request.getSession(true);
	FileDetails fileDetailsObj=new FileDetails();
	String userId=session.getAttribute("userid").toString();
	String role=session.getAttribute("user_role_id").toString();
	String original = file.getOriginalFilename();
     String dateRegex="[0-9][0-9][\\/][0-9][0-9][\\/][0-9]{4}";
	fileDetailsObj.setOriginalFileName(original);
	logger.info("original file name is:" + original);

	double cellValue2=0;
	double sum=0;
	ModelAndView modelAndViewObj=new ModelAndView();
	boolean recordCount = BulkUtil.validateRecordCount(file);
	//int SNo=0;
	Long SNo = 0l;
	try {
		SNo = activityLogDao.insertActivityLog(0l,userId,"file upload",null,null,original,null,null);
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
	if (recordCount) {
		//SNo=activityLogDao.insertActivityLog(SNo,"CAD_SPOC","File  level validations","valid xls file","file is not null");
		logger.info("Entered into bulk upload method for record count validations");
		

		try {

			InputStream file1 =(file
					.getInputStream());

			HSSFWorkbook workbook = new HSSFWorkbook(file1);

			HSSFSheet sheet = workbook.getSheetAt(0);

			logger.info("Present Sheet name is" + "\t"
					+ workbook.getSheetName(0));

	//		Iterator<Row> rows1 = sheet.rowIterator();

	//		HSSFRow row1 = (HSSFRow) rows1.next();
			int  noOfRec = sheet.getPhysicalNumberOfRows() -1;
			
			fileDetailsObj.setTotalRecords(noOfRec);
			System.out.println("total records "+fileDetailsObj.getTotalRecords());

			//System.out.println("defined"+);
			if(noOfRec==-1)
			{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT is zero",original,null,null);
	              logger.info("invalid file with no records");
					modelAndViewObj.addObject("error",
							"Invalid file with no records");
					modelAndViewObj.setViewName("reversal");
					return modelAndViewObj;
			}
			Iterator<Row> rows = sheet.iterator();
			Iterator<Row> rowIterator1 = sheet.iterator();
			HSSFRow row2 = (HSSFRow) rowIterator1.next();
		


			List<String> headersList=new ArrayList<String>();
			
			
				for (int j = row2.getFirstCellNum(); j <=7; j++)
			{
					Cell cell=row2.getCell(j);
					if (cell != null) {
		   		cell.setCellType(
						Cell.CELL_TYPE_STRING);
		  
							headersList.add(cell.getStringCellValue());
						}
		   else
		   {
			   SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Invalid File",original,null,null);
		          logger.info("invalid file ");
					modelAndViewObj.addObject("error",
							"Invalid file  ");
					modelAndViewObj.setViewName("reversal");
					return modelAndViewObj;
		   }
			}
			
				logger.info("size of headers list is " +headersList.size());

		
				String headerStatus=bulkDao.headerProc("CHEQUE_BOUNCE",null,headersList);

			logger.info("header status is" +headerStatus);
			if(!(headerStatus.equalsIgnoreCase("SUCCESS")))
			{
				modelAndViewObj.addObject("error",
						"Invalid file WITH HEADER MISMATCH");
				modelAndViewObj.setViewName("reversal");
				return modelAndViewObj;
			}
			if(noOfRec==0)
			{
               logger.info("invalid file with no records");
               modelAndViewObj.addObject("error",
						"invalid file with no records");
				modelAndViewObj.setViewName("reversal");
				return modelAndViewObj;
			}
			if(noOfRec>MAXIMUM_RECORDS_IN_FILE)
			{
               logger.info("record count has exceeded");
               modelAndViewObj.addObject("error",
						"Count of Total records should not be more than"+MAXIMUM_RECORDS_IN_FILE);
				modelAndViewObj.setViewName("reversal");
				return modelAndViewObj;
			}
			System.out.println("\n no of rec " + noOfRec);
				
				java.util.Date utilDate = new java.util.Date();
				java.sql.Date sqlDate = new java.sql.Date(
						utilDate.getTime());
				//DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			//	Date date = new Date();
				fileDetailsObj.setVendorUserId(userId);//session
				
		
				fileDetailsObj.setVendorType(role);//session
			//	fileDetailsObj.setPaymentAmount(sum);
				fileDetailsObj.setFileTYpe("CHEQUE_BOUNCE");
							
				
				Row row=rows.next();
				
				while (rows.hasNext()) {
					try
					{
					row = (HSSFRow) rows.next();
					/*row.getCell(11).setCellType(
							Cell.CELL_TYPE_STRING);*/
					row.getCell(5).setCellType(
							Cell.CELL_TYPE_STRING);
					
					if(row.getCell(5)!=null)
					{
					Cell cell2 = row.getCell((short) 5);
					if(!cell2.getStringCellValue().isEmpty())
					cellValue2 = Double.parseDouble(cell2.getStringCellValue());
					
					sum = (sum + cellValue2);
					}
					
					fileDetailsObj.setPaymentAmount(Double.toString(sum));
					
					}catch(Exception e)
					{
						SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Payment Amount IN THE FILE SHOULD BE ONLY NUMBER",original,null,null);
						logger.info("Payment Amount SHOULD BE ONLY NUMBER");
						modelAndViewObj.addObject("error", "Payment Amount should be only Number");
						modelAndViewObj.setViewName("reversal");
						return modelAndViewObj;
					}
				}		
								
					
	       if(headerStatus.equalsIgnoreCase("SUCCESS")){
	    	   
	    	
	    	   FileDetails fileDetailsObj1 = bulkDao.reversalFileDetails(fileDetailsObj);
	    	   System.out.println("fileDetailsObj1 status is..." +fileDetailsObj1.getStatus());
	    	   System.out.println("fileDetailsObj1 error message is..." +fileDetailsObj1.getErrorMsg());
	    	  
	    	   if(fileDetailsObj1.getErrorMsg().equalsIgnoreCase("SUCCESS"))
	    	   {
			
	    		   if (fileDetailsObj1.getStatus().equalsIgnoreCase("1")) {

						modelAndViewObj.addObject("status",
							fileDetailsObj1.getStatus());
					modelAndViewObj.addObject("fileId",
							fileDetailsObj1.getFileID());
					java.util.Date utilDate1 = new java.util.Date();
					java.sql.Date sqlDate1 = new java.sql.Date(
							utilDate1.getTime());
					
					//System.out.println("payment date in records table"+formattedDate);
				int serialNo=0;
				List<BulkDetails> bulkList=new ArrayList<BulkDetails>();
						while (rowIterator1.hasNext()) {
							
							BulkDetails bd = new BulkDetails();
							/*serialNo++;
							bd.setsNo(serialNo);*/
							
							row2 = (HSSFRow) rowIterator1.next();
							boolean isRowEmpty=isRowEmpty(row2);
							
							if(isRowEmpty)
							{
								
								rowIterator1.remove();
							}
							else
							{
							
							for (int j = row2.getFirstCellNum(); j <=7; j++) {
								
								bd.setFileID(fileDetailsObj.getFileID());
							//	bd.setPaymentDate(sqlDate1);
								bd.setChangeDate(sqlDate1);
								Cell cell=row2.getCell(j);
								if (j == 0) {
									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);
										try
										{
											if(cell.getStringCellValue().length()>5)
											{
																	
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Serial No maximum length should be 5",original,null,null);
													logger.info("Serial No maximum length should be 5");
													modelAndViewObj.addObject("error", "Invalid File:Serial No maximum length should be 5");
													modelAndViewObj.setViewName("reversal");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
											
											}
											Long.parseLong(cell
													.getStringCellValue());
										}
										catch(Exception e)
										{
											SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","SERIAL NO IN THE FILE SHOULD BE ONLY NUMBER",original,null,null);
											logger.info("SERIAL NUMBER SHOULD BE ONLY NUMBER");
											modelAndViewObj.addObject("error", "Serial Number should be only number");
											modelAndViewObj.setViewName("reversal");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
									serialNo++;
									bd.setsNo(Integer.toString(serialNo));
							
									}
								}
								else if (j == 1) {

									  if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
																					
										
														  try {
														//		date = new SimpleDateFormat("MM/dd/yyyy").parse(row2.getCell(j).getStringCellValue());
																// java.sql.Date sqlDate13 = new java.sql.Date(row2.getCell(j).getDateCellValue().getTime());
															  String dateString=cell.getStringCellValue();
                                                             if(dateString.length()>10||!(dateString.matches(dateRegex)))
																{
																	SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Trans date the File should be only Date",original,null,null);
																	logger.info("Trans Date should be only date");
																	modelAndViewObj.addObject("error", "Invalid File:Trans Date Format should be valid(MM/DD/YYYY)");
																	modelAndViewObj.setViewName("reversal");
																	 fileDetailsObj.getConnection().close();
																	return modelAndViewObj;
																}
																 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
																 Date  date =  sdf.parse(dateString); 
																 java.sql.Date sqlDate13 = new java.sql.Date(date.getTime());
																bd.setPaymentDate(sqlDate13);
																 

																	String subString2= dateString.substring(0, 2);
																	
																	String subString3= dateString.substring(3, 5);
																	boolean status1=true;
																	boolean status2=true;
																	
																	
																	if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
																	status1=false;
																	if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
																	status2=false;
																	if(!(status1&&status2))
																	{
																		modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																		modelAndViewObj.setViewName("reversal");
																		 fileDetailsObj.getConnection().close();
																		return modelAndViewObj;
																	}
																	
																														    
																
													        } catch (Exception ex) {
													        	ex.printStackTrace();
													        	SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Trans date IN THE FILE SHOULD BE ONLY Date",original,null,null);
																logger.info("Trans Date SHOULD BE ONLY date");
																modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
																modelAndViewObj.setViewName("reversal");
																 fileDetailsObj.getConnection().close();
																return modelAndViewObj;
													        }

													//	  bd.setPaymentDate(null);
											      
													
													
												}
								} else if (j == 2) {
									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);
										
									bd.setChequeNo(cell.getStringCellValue());
                                      if(bd.getChequeNo().length()>15)
									{
										logger.info("Cheque no maximum length should be 15");
										modelAndViewObj.addObject("error", "Invalid File:CHEQUE NO maximum length should be 15");
										modelAndViewObj.setViewName("reversal");
										 fileDetailsObj.getConnection().close();
										return modelAndViewObj;
									}
										
																				
									}
								} else if (j == 3) {
                    if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
						cell.setCellType(
								Cell.CELL_TYPE_STRING);
																
					
									  try {
									//		date = new SimpleDateFormat("MM/dd/yyyy").parse(row2.getCell(j).getStringCellValue());
											// java.sql.Date sqlDate13 = new java.sql.Date(row2.getCell(j).getDateCellValue().getTime());
										  String dateString=cell.getStringCellValue();
                                         if(dateString.length()>10||!(dateString.matches(dateRegex)))
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Cheque date the File should be only Date",original,null,null);
												logger.info("Cheque Date should be only date");
												modelAndViewObj.addObject("error", "Invalid File:Cheque Date Format should be valid(MM/DD/YYYY)");
												modelAndViewObj.setViewName("reversal");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
											 Date  date =  sdf.parse(dateString); 
											 java.sql.Date sqlDate13 = new java.sql.Date(date.getTime());
											bd.setChequeDate(sqlDate13);
											
												String subString2= dateString.substring(0, 2);
												
												String subString3= dateString.substring(3, 5);
												boolean status1=true;
												boolean status2=true;
												
												
												if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
												status1=false;
												if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
												status2=false;
												if(!(status1&&status2))
												{
													modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
													modelAndViewObj.setViewName("reversal");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
												
												
												
										 /* DateFormat d
										  * ateFormat = new SimpleDateFormat("MM/dd/yyyy");
										
										  String datestring = dateFormat.format(row2.getCell(j).getDateCellValue()); 
																																						     
										         Date date2 = dateFormat.parse(datestring);
										         System.out
														.println("date"+datestring);*/
										    
											
								        } catch (Exception ex) {
								        	ex.printStackTrace();
								        	SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Trans date IN THE FILE SHOULD BE ONLY Date",original,null,null);
											logger.info("Trans Date SHOULD BE ONLY date");
											modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
											modelAndViewObj.setViewName("reversal");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
								        }

								//	  bd.setPaymentDate(null);
						      
								
								
							}
								} else if (j == 4) {
									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);

										bd.setBankName(cell
												.getStringCellValue());
                                      if(bd.getBankName().length()>150)
										{
											logger.info("Bank Name maximum length should be 150");
											modelAndViewObj.addObject("error", "Invalid File:Bank Name maximum length should be 150");
											modelAndViewObj.setViewName("reversal");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
										
									}
								} else if (j == 6) {

									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);

										bd.setBankVirtualAcctNo(cell
												.getStringCellValue());
                                      if(bd.getBankVirtualAcctNo().length()>150)
										{
											logger.info("Bank Account Number maximum length should be 150");
											modelAndViewObj.addObject("error", "Invalid File:Bank Account Number maximum length should be 150");
											modelAndViewObj.setViewName("reversal");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
										
									}
								} 
								else if (j == 5) {

									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);
										try{
											
										bd.setPaymentAmt((cell
												.getStringCellValue()));
                                          if(bd.getPaymentAmt().length()>18)
										{
											SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Amount size should be maximum 18",original,null,null);
											logger.info("Payment Amount size should be maximum 18");
											modelAndViewObj.addObject("error", "Payment maximum Amount size should be  18");
											modelAndViewObj.setViewName("reversal");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;
										}
                                          Double.parseDouble(cell.getStringCellValue());
										}
										catch(Exception e)
										{
											logger.info("Payment Amount should be only number");
											modelAndViewObj.addObject("error", "Payment Amount should be only number");
											modelAndViewObj.setViewName("reversal");
											 fileDetailsObj.getConnection().close();
											return modelAndViewObj;	
										}
									}
								}else if (j == 7) {
									if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
										cell.setCellType(
												Cell.CELL_TYPE_STRING);
										bd.setBounceReason(cell
												.getStringCellValue());
                                      if(bd.getBounceReason().length()>150)
									{
										logger.info("Return_Reason maximum length should be 150");
										modelAndViewObj.addObject("error", "Invalid File:Return_Reason maximum length should be 150");
										modelAndViewObj.setViewName("reversal");
										 fileDetailsObj.getConnection().close();
										return modelAndViewObj;
									}
									}
								}
								
							}
						
						bulkList.add(bd);
							}
						}
						int b = bulkDao.insertDetails(bulkList,fileDetailsObj1.getConnection(),fileDetailsObj1.getTransactionDef(),fileDetailsObj1.getTransactionManager(),fileDetailsObj1.getTransaction());
						
						//		System.out.println("Status of transaction : "+b);
								if(b==0){
								//	fileDetailsObj1.getTransactionManager().rollback(fileDetailsObj1.getTransaction());
									isValidTrans=false;
									//break;
								}
								else{
									System.out.println("INSERTED into records table");
									isValidTrans=true;
								}
					    
						if(isValidTrans){
							fileDetailsObj.setConnection(fileDetailsObj1.getConnection());
							fileDetailsObj.setTransaction(fileDetailsObj1.getTransaction());
							fileDetailsObj.setTransactionManager(fileDetailsObj1.getTransactionManager());
							fileDetailsObj.setTransactionDef(fileDetailsObj1.getTransactionDef());
							fileDetailsObj2 = bulkDao
									.recordCheckxlsChequeBounce(fileDetailsObj,errorFilesPath,extension);
					
														
                    if(fileDetailsObj2.getErrorMsg().equalsIgnoreCase("SUCCESS")&&fileDetailsObj2.getStatus()==null)
                    {
                      	 fileDetailsObj2.setConnection(fileDetailsObj1.getConnection());
								fileDetailsObj2.setTransaction(fileDetailsObj1.getTransaction());
								fileDetailsObj2.setTransactionManager(fileDetailsObj1.getTransactionManager());
								fileDetailsObj2.setTransactionDef(fileDetailsObj1.getTransactionDef());
								fileDetailsObj2.setUserId(userId);
								fileDetailsObj2.setSessionId(session.getId());
							 BulkUtil.fileUpload(file,downloadpath,fileDetailsObj1.getOriginalFileName(),extension);
							 fileDetailsObj.getConnection().commit();
                             fileDetailsObj.getTransactionManager().commit(fileDetailsObj.getTransaction());
                       
                           fileDetailsObj.getConnection().close();
                         
						 
						 
						 }
                    else if(fileDetailsObj2.getErrorMsg().equalsIgnoreCase("SUCCESS")&&fileDetailsObj2.getStatus()!=null)
                    {
                    	logger.info("validations are succesfull");
							SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","success"," file Upload and validations successfull",original,null,null); 
							  fileDetailsObj.getConnection().commit();
                              fileDetailsObj.getTransactionManager().commit(fileDetailsObj.getTransaction());
                        
                            fileDetailsObj.getConnection().close();
                    }
                    else
                    {
                    	
                    	logger.info("File has been  not uploaded because of data failure issues ");
                    	
                    	fileDetailsObj.getTransactionManager().rollback(fileDetailsObj.getTransaction());
                    	fileDetailsObj.getConnection().close();
                    	SNo=activityLogDao.insertActivityLog(SNo,userId,"file uploading","failed","failed because of data failure issues",original,null,null);
							 modelAndViewObj.addObject("error","data failure issues"+fileDetailsObj2.getErrorMsg());
							 modelAndViewObj.setViewName("reversal");
							 return modelAndViewObj;
                    }
                	
						
						modelAndViewObj.addObject("status",
								fileDetailsObj2.getStatus());
						 modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj1);
						 modelAndViewObj.addObject("extension", extension);
							modelAndViewObj.setViewName("reversalSuccess");
							logger.info("End of Upload");
						}
						else{
							logger.info("records are not inserted because of data failure issues");
							SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","Failure","Data issues!!",original,null,null);
							 modelAndViewObj.addObject("error","data failure issues");
							
	                        	fileDetailsObj.getConnection().close();
							 modelAndViewObj.setViewName("reversal");
							 return modelAndViewObj;
						}

				}else

				{
					
					 SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","file already uploaded",original,null,null);
					 logger.info("File Already Uploaded");
					 modelAndViewObj.addObject("error", "Same FileName cannot be uplaoded again");
					modelAndViewObj.setViewName("reversal");
					return modelAndViewObj;
				} }
	    	   else
	    	   {
	    		   logger.info("file  details has not been inserted into status table because of data failure issues");
    		   modelAndViewObj.addObject("error", "database  failure issues");
    		 
    		   modelAndViewObj.setViewName("reversal");
    		   return modelAndViewObj;// main if sumCountHeader==sum closed
	    	  
	    	   }
	    	   
			} else

			{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","failure","headers are not matched",original,null,null);
			
				logger.info("Given header is not macthed");

				modelAndViewObj.addObject("error", "Header not matched");
				modelAndViewObj.setViewName("reversal");
				return modelAndViewObj;
			}
		
			
		}

		catch (Exception e) {
		StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			modelAndViewObj.addObject("error", "invalid file with different format");
			modelAndViewObj.setViewName("reversal");
			return modelAndViewObj;
			
		}

	}

	else {
		try {
			SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","valid xls file","file is empty",original,null,null);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println("sno in activity log"+SNo);
		logger.info("File is not valid!!");

		modelAndViewObj.addObject("error", "Entered file is empty!!");
		modelAndViewObj.setViewName("reversal");
		return modelAndViewObj;
	}
	return modelAndViewObj;
	}
			

public static String fileUpload(MultipartFile file,String downloadpath,String fileId, String extension)
	{
		
	
		        try {
					file.transferTo(new java.io.File(downloadpath, fileId));

			       // System.out.println("file name in BulkUtil..." + fileId);

				} catch (IOException e) {
					e.printStackTrace();
				}
				return fileId;
	 }



public ModelAndView validatexlsTransfer(MultipartFile file,
		HttpServletRequest request, String downloadpath, String errorFilesPath,
		String extension) {boolean isValidTrans=false;
		FileDetails fileDetailsObj2=null;
		session=request.getSession(true);
		FileDetails fileDetailsObj=new FileDetails();
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		String original = file.getOriginalFilename();
        String dateRegex="[0-9][0-9][\\/][0-9][0-9][\\/][0-9]{4}";
		fileDetailsObj.setOriginalFileName(original);
		logger.info("original file name is:" + original);


		ModelAndView modelAndViewObj=new ModelAndView();
		boolean recordCount = BulkUtil.validateRecordCount(file);
		//int SNo=0;
		Long SNo = 0l;
		try {
			SNo = activityLogDao.insertActivityLog(0l,userId,"file upload",null,null,original,null,null);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		if (recordCount) {
			//SNo=activityLogDao.insertActivityLog(SNo,"CAD_SPOC","File  level validations","valid xls file","file is not null");
			/*System.out
					.println("Entered into bulk upload method for record count validations");
			*/

			try {

				InputStream file1 =  (file
						.getInputStream());

				HSSFWorkbook workbook = new HSSFWorkbook(file1);

				HSSFSheet sheet = workbook.getSheetAt(0);

				logger.info("Present Sheet name is" + "\t"
						+ workbook.getSheetName(0));

				Iterator<Row> rows1 = sheet.rowIterator();

			//	HSSFRow row1 = (HSSFRow) rows1.next();
				int  noOfRec = sheet.getPhysicalNumberOfRows() - 1;
			//	System.out.println(noOfRec);
				fileDetailsObj.setTotalRecords(noOfRec);
				if(noOfRec==-1)
				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT is zero",original,null,null);
		              logger.info("invalid file with no records");
						modelAndViewObj.addObject("error",
								"Invalid file with no records");
						modelAndViewObj.setViewName("bulkTransfer");
						return modelAndViewObj;
				}
			//	System.out.println("total records "+fileDetailsObj.getTotalRecords());

				//System.out.println("defined"+);

				logger.info("\n no of rec " + noOfRec);
					Iterator<Row> rowIterator1 = sheet.iterator();
					HSSFRow row2 = (HSSFRow) rowIterator1.next();
					
					
					
					List<String> headersList=new ArrayList<String>();
					
					
					for (int j = row2.getFirstCellNum(); j <=12; j++)
					{
						Cell cell=row2.getCell(j);
						if (cell != null) {
				   		cell.setCellType(
								Cell.CELL_TYPE_STRING);
					   		
									headersList.add(cell.getStringCellValue());
								}
				   else
				   {
					   SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Invalid File",original,null,null);
				          logger.info("invalid file ");
							modelAndViewObj.addObject("error",
									"Invalid file with header not matched ");
							modelAndViewObj.setViewName("bulkTransfer");
							return modelAndViewObj;
				   }
					}
			

					String headerStatus=bulkDao.headerProc("TRANSFER",null,headersList);
					logger.info("header status is" +headerStatus);
					if(!(headerStatus.equalsIgnoreCase("SUCCESS")))
					{
						modelAndViewObj.addObject("error",
								"Invalid file WITH HEADER MISMATCH");
						modelAndViewObj.setViewName("bulkTransfer");
						return modelAndViewObj;
					}

					if(noOfRec==0)
					{
						SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT is zero",original,null,null);
			              logger.info("invalid file with no records");
							modelAndViewObj.addObject("error",
									"Invalid file with no records");
							modelAndViewObj.setViewName("bulkTransfer");
							return modelAndViewObj;
					}
					if(noOfRec>MAXIMUM_RECORDS_IN_FILE)
					{
		            	logger.info("record count is not matched");
		            	modelAndViewObj.addObject("error",
								"Count of Total records should not be more than"+MAXIMUM_RECORDS_IN_FILE);
						modelAndViewObj.setViewName("bulkTransfer");
						return modelAndViewObj;
					}
					//SNo=activityLogDao.insertActivityLog(SNo,"CAD_SPOC","File level validations","success","record count and sum is matched");
					
					
					java.util.Date utilDate = new java.util.Date();
					java.sql.Date sqlDate = new java.sql.Date(
							utilDate.getTime());
					//DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
				//	Date date = new Date();
					fileDetailsObj.setVendorUserId(userId);//session
					
				//	fileDetailsObj.setFileUploadDate(sqlDate);
				
				//	fileDetailsObj.setChangeWho("useriD");//session
				//	fileDetailsObj.setChangeDate(sqlDate);
					//fileDetailsObj.setVendorID(userId);//session
					fileDetailsObj.setVendorType(role);//session
				//	fileDetailsObj.setPaymentAmount(sum);
					fileDetailsObj.setFileTYpe("Transfer");
								

						
						
					logger.info("size of headers list is " +headersList.size());
	 
					
	// SNo=activityLogDao.insertActivityLog(0,"CAD_SPOC","File level validations header",null,null);


						

						logger.info("header status is" +headerStatus);			
						
		       if(headerStatus.equalsIgnoreCase("SUCCESS")){
		    	   
		    	//   SNo=activityLogDao.insertActivityLog(SNo,"CAD_SPOC","File level validations header","success","headers are matched");
		    
		    	  // SNo=activityLogDao.insertActivityLog(0,"CAD_SPOC","file uploading",null,null);
		    	   FileDetails fileDetailsObj1 = bulkDao.transferFileDetails(fileDetailsObj);
		    	  
		    	   if(fileDetailsObj1.getErrorMsg().equalsIgnoreCase("SUCCESS"))
		    	   {
				
	if (fileDetailsObj1.getStatus().equalsIgnoreCase("1")) {


						modelAndViewObj.addObject("status",
								fileDetailsObj1.getStatus());
						modelAndViewObj.addObject("fileId",
								fileDetailsObj1.getFileID());
						java.util.Date utilDate1 = new java.util.Date();
						java.sql.Date sqlDate1 = new java.sql.Date(
								utilDate1.getTime());
						
						//System.out.println("payment date in records table"+formattedDate);
					int serialNo=0;
					List<BulkDetails> bulkList=new ArrayList<BulkDetails>();
							while (rowIterator1.hasNext()) {
								
								BulkDetails bd = new BulkDetails();
								serialNo++;
								bd.setsNo(Integer.toString(serialNo));
								
								row2 = (HSSFRow) rowIterator1.next();
								boolean isRowEmpty=isRowEmpty(row2);
								
								if(isRowEmpty)
								{
									
									rowIterator1.remove();
								}
								else
								{
								
								for (int j = row2.getFirstCellNum(); j <=12; j++) {
									
									bd.setFileID(fileDetailsObj.getFileID());
								//	bd.setPaymentDate(sqlDate1);
									bd.setChangeDate(sqlDate1);
									Cell cell=row2.getCell(j);
									if (j == 0) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											bd.setTransferType(cell
													.getStringCellValue());
											if(!(bd.getTransferType().equalsIgnoreCase("APP")||bd.getTransferType().equalsIgnoreCase("REV")))
											{
												logger.info("TRANSFER TYPE SHOULD BE ONLY APP OR REV");
												modelAndViewObj.addObject("error", "TRANSFER TYPE SHOULD BE ONLY APP OR REV");
												modelAndViewObj.setViewName("bulkTransfer");
												return modelAndViewObj;
											}
											else{
												bd.setTransferType(cell
														.getStringCellValue().toUpperCase());
											}
											
								
										}
									} else if (j == 1) {

										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {cell.setCellType(
												Cell.CELL_TYPE_STRING);
										
										
										  try {
										//		date = new SimpleDateFormat("MM/dd/yyyy").parse(row2.getCell(j).getStringCellValue());
												// java.sql.Date sqlDate13 = new java.sql.Date(row2.getCell(j).getDateCellValue().getTime());
											  String dateString=cell.getStringCellValue();
                                             if(dateString.length()>10||!(dateString.matches(dateRegex)))
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Trans date the File should be only Date",original,null,null);
													logger.info("Trans Date should be only date");
													modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
													modelAndViewObj.setViewName("bulkTransfer");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
												 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
												 Date  date =  sdf.parse(dateString); 
												 java.sql.Date sqlDate13 = new java.sql.Date(date.getTime());
												bd.setPaymentDate(sqlDate13);
												 

													String subString2= dateString.substring(0, 2);
													
													String subString3= dateString.substring(3, 5);
													boolean status1=true;
													boolean status2=true;
													
													
													if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
													status1=false;
													if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
													status2=false;
													if(!(status1&&status2))
													{
														modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
														modelAndViewObj.setViewName("bulkTransfer");
														 fileDetailsObj.getConnection().close();
														return modelAndViewObj;
													}
													
																					    
												
									        } catch (Exception ex) {
									        	ex.printStackTrace();
									        	SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Trans date IN THE FILE SHOULD BE ONLY Date",original,null,null);
												logger.info("Payment Date SHOULD BE ONLY date");
												modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
									        }

									//	  bd.setPaymentDate(null);
							      
									}
									} else if (j == 2) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setPaymentMode(cell.getStringCellValue());
                                          if(bd.getPaymentMode().length()>15)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Mode maximum length should be 15",original,null,null);
												logger.info("Payment Mode maximum length should be 15");
												modelAndViewObj.addObject("error", "Invalid File:Payment Mode maximum length should be 15");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									} else if (j == 3) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											
											bd.setServiceType(cell.getStringCellValue());
                                          if(bd.getServiceType().length()>10)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","LOB maximum length should be 10",original,null,null);
												logger.info("LOB maximum length should be 10");
												modelAndViewObj.addObject("error", "Invalid File:LOB maximum length should be 15");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											
										}
									} else if (j == 4) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											
											bd.setAcctEXTID(cell.getStringCellValue());
                                          if(bd.getAcctEXTID().length()>75)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Account No maximum length should be 75",original,null,null);
												logger.info("Account No maximum length should be 75");
												modelAndViewObj.addObject("error", "Invalid File:Account No maximum length should be 75");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											
										}
									} else if (j == 5) {

										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											try
											{
												bd.setInvoiceNo(cell
														.getStringCellValue());
												if(bd.getInvoiceNo().length()>20)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Invoice no length should be maximum 20",original,null,null);
													logger.info("Invoice Number max length is 20 ");
													modelAndViewObj.addObject("error", "Invalid File:Invoice No maximum length should be 20");
													modelAndViewObj.setViewName("bulkTransfer");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
												Long.parseLong(cell
														.getStringCellValue());
											}
											catch(Exception e)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","INVOICE NUMBER IN THE FILE SHOULD BE ONLY NUMBER",original,null,null);
												logger.info("INVOICE NUMBER SHOULD BE ONLY NUMBER");
												modelAndViewObj.addObject("error", "Invoice should be only number");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
																				
										}
									} else if (j == 6) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											try
											{
												
											bd.setPaymentAmt(cell.getStringCellValue());
                                              if(bd.getPaymentAmt().length()>18)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Amount size should be maximum 18",original,null,null);
												logger.info("Payment Amount size should be maximum 18");
												modelAndViewObj.addObject("error", "Payment maximum Amount size should be  18");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
                                              Double.parseDouble(cell.getStringCellValue());
											}
											catch(Exception e)
											{
												logger.info("Payment Amount should be only Number");
												modelAndViewObj.addObject("error", "Payment amount should be only number");
												modelAndViewObj.setViewName("bulkTransfer");
												return modelAndViewObj;
											}
										
											
										}
									}
									else if (j == 7) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setChequeNo(cell
													.getStringCellValue());
                                          if(bd.getChequeNo().length()>15)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Chq No / Trans id maximum length should be 15",original,null,null);
												logger.info("Chq No / Trans id maximum length should be 15");
												modelAndViewObj.addObject("error", "Invalid File:Chq No / Trans id maximum length should be 15");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											
										}
									}
									else if (j == 8) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											try
											{
												
											bd.setTrackingId(cell.getStringCellValue());
                                              if(bd.getTrackingId().length()>10)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","TRACKING_ID maximum length should be 10",original,null,null);
												logger.info("TRACKING_ID maximum length should be 10");
												modelAndViewObj.addObject("error", "Invalid File:TRACKING_ID maximum length should be 10");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
                                              Long.parseLong(cell.getStringCellValue());
											}
											catch(Exception e)
											{
												logger.info("Tracking ID should be only number");
												modelAndViewObj.addObject("error", "Tracking id should be only number");
												modelAndViewObj.setViewName("bulkTransfer");
												return modelAndViewObj;
											}
										
											
										}
									}
									else if (j == 9) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											try
											{
												
											bd.setTrackingIdServ(cell.getStringCellValue());
                                              if(bd.getTrackingIdServ().length()>3)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","TRACKING_ID Serv maximum length should be 3",original,null,null);
												logger.info("TRACKING_ID Serv maximum length should be 3");
												modelAndViewObj.addObject("error", "Invalid File:TRACKING_ID Serv maximum length should be 3");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
                                              Long.parseLong(cell.getStringCellValue());
											}
											catch(Exception e)
											{
												logger.info("Tracking Id serv should be only number");
												modelAndViewObj.addObject("error", "Tracking id serv should be only number");
												modelAndViewObj.setViewName("bulkTransfer");
												return modelAndViewObj;
											}
										
											
										}
									}
									else if (j == 10) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setCollectionManager(cell
													.getStringCellValue());
                                          if(bd.getCollectionManager().length()>75)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Collection Manager Name maximum length should be 75",original,null,null);
												logger.info("Collection Manager Name maximum length should be 75");
												modelAndViewObj.addObject("error", "Invalid File:Collection Manager Name maximum length should be 75");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											
										}
									}
									else if (j == 11) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											try
											{
												
											bd.setTicketNo(cell.getStringCellValue());
                                              if(bd.getTicketNo().length()>15)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Ticket No maximum length should be 15",original,null,null);
													logger.info("Ticket No maximum length should be 15");
													modelAndViewObj.addObject("error", "Invalid File:Ticket No Name maximum length should be 15");
													modelAndViewObj.setViewName("bulkTransfer");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
                                              Long.parseLong(cell.getStringCellValue());
											}
											catch(Exception e)
											{
												logger.info("Sr number should be only number");
												modelAndViewObj.addObject("error", "sr number should be only number");
												modelAndViewObj.setViewName("bulkTransfer");
												return modelAndViewObj;
											}
										
											
										}
									}
									else if (j == 12) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setAnnotation(cell
													.getStringCellValue());
                                          if(bd.getAnnotation().length()>255)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Annotation maximum length should be 255",original,null,null);
												logger.info("Annotation maximum length should be 255");
												modelAndViewObj.addObject("error", "Invalid File:Annotation Name maximum length should be 255");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											
										}
									}
							
							
								}
							
							bulkList.add(bd);
							}
							}
	int b = bulkDao.insertDetails(bulkList,fileDetailsObj1.getConnection(),fileDetailsObj1.getTransactionDef(),fileDetailsObj1.getTransactionManager(),fileDetailsObj1.getTransaction());
							
							//	System.out.println("Status of transaction : "+b);
								if(b==0){
									//fileDetailsObj1.getTransactionManager().rollback(fileDetailsObj1.getTransaction());
									isValidTrans=false;
									//break;
								}
								else{
								//	System.out.println("INSERTED into records table");
									isValidTrans=true;
								}
							if(isValidTrans){
								fileDetailsObj.setConnection(fileDetailsObj1.getConnection());
								fileDetailsObj.setTransaction(fileDetailsObj1.getTransaction());
								fileDetailsObj.setTransactionManager(fileDetailsObj1.getTransactionManager());
								fileDetailsObj.setTransactionDef(fileDetailsObj1.getTransactionDef());
								fileDetailsObj2 = bulkDao
										.recordCheckxlsTransfer(fileDetailsObj,errorFilesPath,extension);
						
								
								//System.out.println(" sno in activity log ::"+SNo);
	                    if(fileDetailsObj2.getErrorMsg().equalsIgnoreCase("SUCCESS")&&fileDetailsObj2.getStatus()==null)
	                    {
	                      	 fileDetailsObj2.setConnection(fileDetailsObj1.getConnection());
									fileDetailsObj2.setTransaction(fileDetailsObj1.getTransaction());
									fileDetailsObj2.setTransactionManager(fileDetailsObj1.getTransactionManager());
									fileDetailsObj2.setTransactionDef(fileDetailsObj1.getTransactionDef());
									fileDetailsObj2.setUserId(userId);
									fileDetailsObj2.setSessionId(session.getId());
								 BulkUtil.fileUpload(file,downloadpath,fileDetailsObj1.getOriginalFileName(),extension);
								 fileDetailsObj.getConnection().commit();
	                             fileDetailsObj.getTransactionManager().commit(fileDetailsObj.getTransaction());
	                       
	                           fileDetailsObj.getConnection().close();
								
				
	                       }
	                    else if(fileDetailsObj2.getErrorMsg().equalsIgnoreCase("SUCCESS")&&fileDetailsObj2.getStatus()!=null)
	                    {
	                    	logger.info("validations are not sucessfull");
								SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","success"," file Upload  success and validations  not successfull",original,null,null); 
								  fileDetailsObj.getConnection().commit();
	                              fileDetailsObj.getTransactionManager().commit(fileDetailsObj.getTransaction());
	                        
	                            fileDetailsObj.getConnection().close();
	                    }
	                    else
	                    {
	                    	
	                    	logger.info("File has been  not uploaded because of data failure issues ");
	                    	
	                    	fileDetailsObj.getTransactionManager().rollback(fileDetailsObj.getTransaction());
	                    	fileDetailsObj.getConnection().close();
	                    	SNo=activityLogDao.insertActivityLog(SNo,userId,"file uploading","failed","failed because of data failure issues",original,null,null);
								 modelAndViewObj.addObject("error","data failure issues");
								 modelAndViewObj.setViewName("bulkTransfer");
								 return modelAndViewObj;
	                    }

							modelAndViewObj.addObject("flag",
									fileDetailsObj2.getFlag());
							modelAndViewObj.addObject("status",
									fileDetailsObj2.getStatus());
							 modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj1);
							 modelAndViewObj.addObject("extension", extension);
								modelAndViewObj.setViewName("transferSuccess");
								logger.info("End of upload");

							}
							else{
								logger.info("records are not inserted because of data failure issues");
								SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","Failure","Data issues!!",original,null,null);
								 modelAndViewObj.addObject("error","data failure issues");
								 modelAndViewObj.setViewName("bulkTransfer");
								 return modelAndViewObj;
							}

					}else

					{
						// System.out.println("Given header amount and sum of all the records are not matched..!!!");
						 SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","file already uploaded",original,null,null);
						 logger.info("File already Uploaded");
						 modelAndViewObj.addObject("error", "Invalid File:FileName cannot be same");
						modelAndViewObj.setViewName("bulkTransfer");
						return modelAndViewObj;
					} }
		    	   else
		    	   {
		    		   logger.info("file  details has not been inserted into status table because of data failure issues");
	    		   modelAndViewObj.addObject("error", "database  failure issues");
	    		   modelAndViewObj.setViewName("bulkTransfer");
	    		   return modelAndViewObj;// main if sumCountHeader==sum closed
		    	  
		    	   }
		    	   
				} else

				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","failure","headers are not matched",original,null,null);
				
					logger.info("Given header is not macthed");

					modelAndViewObj.addObject("error", "Invalid File with Header Mismatch");
					modelAndViewObj.setViewName("bulkTransfer");
					return modelAndViewObj;
				}
			
				
			}

			catch (Exception e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("error", "invalid file");
				modelAndViewObj.setViewName("bulkTransfer");
				return modelAndViewObj;
				
			}

		}

		else {
			try {
				SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","valid xls file","file is empty",original,null,null);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//System.out.println("sno in activity log"+SNo);
			logger.info("File is not valid!!");

			modelAndViewObj.addObject("error", "Entered file is empty!!");
			modelAndViewObj.setViewName("bulkTransfer");
			return modelAndViewObj;
		}
		return modelAndViewObj;
	}
public static boolean isRowEmpty(Row row) {
	
	
	boolean rowEmpty;
	int emptyCellCount=0;
    for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
        Cell cell = row.getCell(c);
    //  System.out.println("row value is::"+c);
        /*commented to test exchange_rate garbage value from xlsx file*/
        /* if(cell!=null)
        cell.setCellType(Cell.CELL_TYPE_STRING);*/
         
         //COMMENT ABOVE LINES IF NEEDED AFTER TESTING 
        if(cell!=null)
      //  System.out.println("celltypeenum:..." +cell.getCellTypeEnum());
        if(cell.getCellTypeEnum()==CellType.STRING || cell.getCellTypeEnum()==CellType.BLANK)
        {
        if (cell != null&&cell.getStringCellValue()!=null&& cell.getStringCellValue().trim().length()==0)
  	        emptyCellCount=emptyCellCount+1;
        }
        else if(cell.getCellTypeEnum()==CellType.NUMERIC)
        {
        	if (cell != null&&cell.getNumericCellValue()==0)
        	{
            	emptyCellCount=emptyCellCount+1;
        	}
        }
        
    }

 	    
    if(row.getPhysicalNumberOfCells()==emptyCellCount){
    	rowEmpty=true;
    }
    else{
    	rowEmpty=false;
    }
  
    return rowEmpty;


}

public static String getDateTime() {
	Date today = Calendar.getInstance().getTime();
	SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
	return formatter.format(today);
}
public static void main(String[] args){
	logger.info(getDateTime());
}



public ModelAndView validatexlsxTransfer(MultipartFile file,
		HttpServletRequest request, String downloadpath, String errorFilesPath,
		String isFileValid) {boolean isValidTrans=false;
		FileDetails fileDetailsObj2=null;
		session=request.getSession(true);
		FileDetails fileDetailsObj=new FileDetails();
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
        String dateRegex="[0-9][0-9][\\/][0-9][0-9][\\/][0-9]{4}";
		String original = file.getOriginalFilename();
		fileDetailsObj.setOriginalFileName(original);
		logger.info("original file name is:" + original);


		ModelAndView modelAndViewObj=new ModelAndView();
		boolean recordCount = BulkUtil.validateRecordCount(file);
		//int SNo=0;
		Long SNo=0l;
		try {
			SNo = activityLogDao.insertActivityLog(0l,userId,"file upload",null,null,original,null,null);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		if (recordCount) {
			//SNo=activityLogDao.insertActivityLog(SNo,"CAD_SPOC","File  level validations","valid xls file","file is not null");
			/*System.out
					.println("Entered into bulk upload method for record count validations");
			*/

			try {

				InputStream file1 =  (file
						.getInputStream());

		//		XSSFWorkbook workbook=(XSSFWorkbook) WorkbookFactory.create(file1);
              Workbook workbook = new XSSFWorkbook(file1);
              XSSFSheet  sheet = (XSSFSheet) workbook.getSheetAt(0);
				//org.apache.poi.xssf.usermodel.XSSFSheet  sheet = workbook.getSheetAt(0);
				logger.info("Present Sheet name is" + "\t"
						+ workbook.getSheetName(0));

				Iterator<Row> rows1 = sheet.rowIterator();

			//	HSSFRow row1 = (HSSFRow) rows1.next();
				int  noOfRec = sheet.getPhysicalNumberOfRows() - 1;
			//	System.out.println(noOfRec);
				fileDetailsObj.setTotalRecords(noOfRec);
				if(noOfRec==-1)
				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT is zero",original,null,null);
		              logger.info("invalid file with no records");
						modelAndViewObj.addObject("error",
								"Invalid file with no records");
						modelAndViewObj.setViewName("bulkTransfer");
						return modelAndViewObj;
				}
			//	System.out.println("total records "+fileDetailsObj.getTotalRecords());

				//System.out.println("defined"+);

				logger.info("\n no of rec " + noOfRec);
					Iterator<Row> rowIterator1 = sheet.iterator();
					Row row2 = (XSSFRow) rowIterator1.next();
															
					List<String> headersList=new ArrayList<String>();
					
					
					for (int j = row2.getFirstCellNum(); j <=12; j++)
					{
						Cell cell=row2.getCell(j);
						if (cell != null) {
				   		cell.setCellType(
								Cell.CELL_TYPE_STRING);
					   		
									headersList.add(cell.getStringCellValue());
								}
				   else
				   {
					   SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Invalid File",original,null,null);
				          logger.info("invalid file ");
							modelAndViewObj.addObject("error",
									"Invalid file with Header Mismatch ");
							modelAndViewObj.setViewName("bulkTransfer");
							return modelAndViewObj;
				   }
					}
			

					String headerStatus=bulkDao.headerProc("TRANSFER",null,headersList);
					logger.info("header status is" +headerStatus);
					if(!(headerStatus.equalsIgnoreCase("SUCCESS")))
					{
						modelAndViewObj.addObject("error",
								"Invalid file with Header Mismatch ");
						modelAndViewObj.setViewName("bulkTransfer");
						return modelAndViewObj;
					}

					if(noOfRec==0)
					{
						SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","RECORD COUNT is zero",original,null,null);
			              logger.info("invalid file with no records");
							modelAndViewObj.addObject("error",
									"Invalid file with no records");
							modelAndViewObj.setViewName("bulkTransfer");
							return modelAndViewObj;
					}
					if(noOfRec>MAXIMUM_RECORDS_IN_FILE)
					{
		            	logger.info("record count is not matched");
		            	modelAndViewObj.addObject("error",
								"Count of Total records should not be more than"+MAXIMUM_RECORDS_IN_FILE);
						modelAndViewObj.setViewName("bulkTransfer");
						return modelAndViewObj;
					}
					//SNo=activityLogDao.insertActivityLog(SNo,"CAD_SPOC","File level validations","success","record count and sum is matched");
					
					
					java.util.Date utilDate = new java.util.Date();
					java.sql.Date sqlDate = new java.sql.Date(
							utilDate.getTime());
					//DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
				//	Date date = new Date();
					fileDetailsObj.setVendorUserId(userId);//session
					
				//	fileDetailsObj.setFileUploadDate(sqlDate);
				
				//	fileDetailsObj.setChangeWho("useriD");//session
				//	fileDetailsObj.setChangeDate(sqlDate);
					//fileDetailsObj.setVendorID(userId);//session
					fileDetailsObj.setVendorType(role);//session
				//	fileDetailsObj.setPaymentAmount(sum);
					fileDetailsObj.setFileTYpe("Transfer");
								

						
						
					logger.info("size of heders list is " +headersList.size());
	 
					
	// SNo=activityLogDao.insertActivityLog(0,"CAD_SPOC","File level validations header",null,null);


						

						logger.info("header status is" +headerStatus);			
						
		       if(headerStatus.equalsIgnoreCase("SUCCESS")){
		    	   
		    	//   SNo=activityLogDao.insertActivityLog(SNo,"CAD_SPOC","File level validations header","success","headers are matched");
		    
		    	  // SNo=activityLogDao.insertActivityLog(0,"CAD_SPOC","file uploading",null,null);
		    	   FileDetails fileDetailsObj1 = bulkDao.transferFileDetails(fileDetailsObj);
		    	  
		    	   if(fileDetailsObj1.getErrorMsg().equalsIgnoreCase("SUCCESS"))
		    	   {
				
		    		   if (fileDetailsObj1.getStatus().equalsIgnoreCase("1")) {


						modelAndViewObj.addObject("status",
								fileDetailsObj1.getStatus());
						modelAndViewObj.addObject("fileId",
								fileDetailsObj1.getFileID());
						java.util.Date utilDate1 = new java.util.Date();
						java.sql.Date sqlDate1 = new java.sql.Date(
								utilDate1.getTime());
						
						//System.out.println("payment date in records table"+formattedDate);
					int serialNo=0;
					List<BulkDetails> bulkList=new ArrayList<BulkDetails>();
							while (rowIterator1.hasNext()) {
								
								BulkDetails bd = new BulkDetails();
								serialNo++;
								bd.setsNo(Integer.toString(serialNo));
								
								row2 = (XSSFRow) rowIterator1.next();
								boolean isRowEmpty=isRowEmpty(row2);
								
								if(isRowEmpty)
								{
									
									rowIterator1.remove();
								}
								else
								{
								
								for (int j = row2.getFirstCellNum(); j <=12; j++) {
									
									bd.setFileID(fileDetailsObj.getFileID());
								//	bd.setPaymentDate(sqlDate1);
									bd.setChangeDate(sqlDate1);
									Cell cell=row2.getCell(j);
									if (j == 0) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											bd.setTransferType(cell
													.getStringCellValue());
											if(!(bd.getTransferType().equalsIgnoreCase("APP")||bd.getTransferType().equalsIgnoreCase("REV")))
											{
												logger.info("TRANSFER TYPE SHOULD BE ONLY APP OR REV");
												modelAndViewObj.addObject("error", "TRANSFER TYPE SHOULD BE ONLY APP OR REV");
												modelAndViewObj.setViewName("bulkTransfer");
												fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											
								
										}
									} else if (j == 1) {

										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {cell.setCellType(
												Cell.CELL_TYPE_STRING);
										
										
										  try {
										//		date = new SimpleDateFormat("MM/dd/yyyy").parse(row2.getCell(j).getStringCellValue());
												// java.sql.Date sqlDate13 = new java.sql.Date(row2.getCell(j).getDateCellValue().getTime());
											  String dateString=cell.getStringCellValue();
                                             if(dateString.length()>10||!(dateString.matches(dateRegex)))
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Trans date the File should be only Date",original,null,null);
													logger.info("Trans Date should be only date");
													modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
													modelAndViewObj.setViewName("bulkTransfer");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
												 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
												 Date  date =  sdf.parse(dateString); 
												 java.sql.Date sqlDate13 = new java.sql.Date(date.getTime());
												bd.setPaymentDate(sqlDate13);
												 
													String subString2= dateString.substring(0, 2);
												
													String subString3= dateString.substring(3, 5);
													boolean status1=true;
													boolean status2=true;
													
													
													if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
													status1=false;
													if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
													status2=false;
													if(!(status1&&status2))
													{
														modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid(MM/DD/YYYY)");
														modelAndViewObj.setViewName("bulkTransfer");
														 fileDetailsObj.getConnection().close();
														return modelAndViewObj;
													}
													
																					    
												
									        } catch (Exception ex) {
									        	ex.printStackTrace();
									        	SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Trans date IN THE FILE SHOULD BE ONLY Date",original,null,null);
												logger.info("Payment Date SHOULD BE ONLY date");
												modelAndViewObj.addObject("error", "Invalid File:Date Format should be valid");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
									        }

									//	  bd.setPaymentDate(null);
							      
									}
									} else if (j == 2) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											bd.setPaymentMode(cell.getStringCellValue());
                                          if(bd.getPaymentMode().length()>15)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Mode maximum length should be 15",original,null,null);
												logger.info("Payment Mode maximum length should be 15");
												modelAndViewObj.addObject("error", "Invalid File:Payment Mode maximum length should be 15");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										}
									} else if (j == 3) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											
											bd.setServiceType(cell.getStringCellValue());
                                          if(bd.getServiceType().length()>10)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","LOB maximum length should be 10",original,null,null);
												logger.info("LOB maximum length should be 10");
												modelAndViewObj.addObject("error", "Invalid File:LOB maximum length should be 15");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											
										}
									} else if (j == 4) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											
											bd.setAcctEXTID(cell.getStringCellValue());
                                          if(bd.getAcctEXTID().length()>75)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Account No maximum length should be 75",original,null,null);
												logger.info("Account No maximum length should be 75");
												modelAndViewObj.addObject("error", "Invalid File:Account No maximum length should be 75");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											
										}
									} else if (j == 5) {

										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											try
											{
												bd.setInvoiceNo(cell
														.getStringCellValue());
												if(bd.getInvoiceNo().length()>20)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Invoice no length should be maximum 20",original,null,null);
													logger.info("Invoice Number max length is 20 ");
													modelAndViewObj.addObject("error", "Invalid File:Invoice No maximum length should be 20");
													modelAndViewObj.setViewName("bulkTransfer");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
												Long.parseLong(cell
														.getStringCellValue());
											}
											catch(Exception e)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","INVOICE NUMBER IN THE FILE SHOULD BE ONLY NUMBER",original,null,null);
												logger.info("INVOICE NUMBER SHOULD BE ONLY NUMBER");
												modelAndViewObj.addObject("error", "Invoice should be only number");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											/*bd.setInvoiceNo(cell
													.getStringCellValue());
											if(bd.getInvoiceNo().length()>20)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File upload","failure","Invoice no length should be maximum 20");
												logger.info("Invoice Number max length is 20 ");
												modelAndViewObj.addObject("error", "Invalid File:Invoice No length should be Maximum 20");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}*/
											
										}
									} else if (j == 6) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											try
											{
												
											bd.setPaymentAmt(cell.getStringCellValue());
                                              if(bd.getPaymentAmt().length()>18)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Payment Amount size should be maximum 18",original,null,null);
												logger.info("Payment Amount size should be maximum 18");
												modelAndViewObj.addObject("error", "Payment Amount maximum size should be  18");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
                                              Double.parseDouble(cell.getStringCellValue());
											}
											catch(Exception e)
											{
												logger.info("Payment Amount should be only Number");
												modelAndViewObj.addObject("error", "Payment amount should be only number");
												modelAndViewObj.setViewName("bulkTransfer");
												fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										
											
										}
									}
									else if (j == 7) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setChequeNo(cell
													.getStringCellValue());
                                          if(bd.getChequeNo().length()>15)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Chq No / Trans id maximum length should be 15",original,null,null);
												logger.info("Chq No / Trans id maximum length should be 15");
												modelAndViewObj.addObject("error", "Invalid File:Chq No / Trans id maximum length should be 15");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											
										}
									}
									else if (j == 8) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											try
											{
												
											bd.setTrackingId(cell.getStringCellValue());
                                              if(bd.getTrackingId().length()>10)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","TRACKING_ID maximum length should be 10",original,null,null);
												logger.info("TRACKING_ID maximum length should be 10");
												modelAndViewObj.addObject("error", "Invalid File:TRACKING_ID maximum length should be 10");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
                                              Long.parseLong(cell.getStringCellValue());
											}
											catch(Exception e)
											{
												logger.info("Tracking ID should be only number");
												modelAndViewObj.addObject("error", "Tracking id should be only number");
												modelAndViewObj.setViewName("bulkTransfer");
												fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										
											
										}
									}
									else if (j == 9) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											try
											{
												
											bd.setTrackingIdServ(cell.getStringCellValue());
                                              if(bd.getTrackingIdServ().length()>3)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","TRACKING_ID Serv maximum length should be 3",original,null,null);
												logger.info("TRACKING_ID Serv maximum length should be 3");
												modelAndViewObj.addObject("error", "Invalid File:TRACKING_ID Serv maximum length should be 3");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
                                              Long.parseLong(cell.getStringCellValue());
											}
											catch(Exception e)
											{
												logger.info("Tracking Id serv should be only number");
												modelAndViewObj.addObject("error", "Tracking id serv should be only number");
												modelAndViewObj.setViewName("bulkTransfer");
												fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										
											
										}
									}
									else if (j == 10) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setCollectionManager(cell
													.getStringCellValue());
                                          if(bd.getCollectionManager().length()>75)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Collection Manager Name maximum length should be 75",original,null,null);
												logger.info("Collection Manager Name maximum length should be 75");
												modelAndViewObj.addObject("error", "Invalid File:Collection Manager Name maximum length should be 75");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											
										}
									}
									else if (j == 11) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);
											
											try
											{
												
											bd.setTicketNo(cell.getStringCellValue());
                                              if(bd.getTicketNo().length()>15)
												{
													SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Ticket No maximum length should be 15",original,null,null);
													logger.info("Ticket No maximum length should be 15");
													modelAndViewObj.addObject("error", "Invalid File:Ticket No Name maximum length should be 15");
													modelAndViewObj.setViewName("bulkTransfer");
													 fileDetailsObj.getConnection().close();
													return modelAndViewObj;
												}
                                              Long.parseLong(cell.getStringCellValue());
											}
											catch(Exception e)
											{
												logger.info("Sr number should be only number");
												modelAndViewObj.addObject("error", "sr number should be only number");
												modelAndViewObj.setViewName("bulkTransfer");
												fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
										
											
										}
									}
									else if (j == 12) {
										if (cell != null&&(!(cell.getCellTypeEnum().toString().equalsIgnoreCase("BLANK")))) {
											cell.setCellType(
													Cell.CELL_TYPE_STRING);

											bd.setAnnotation(cell
													.getStringCellValue());
                                          if(bd.getAnnotation().length()>255)
											{
												SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","Failure","Annotation maximum length should be 255",original,null,null);
												logger.info("Annotation maximum length should be 255");
												modelAndViewObj.addObject("error", "Invalid File:Annotation Name maximum length should be 255");
												modelAndViewObj.setViewName("bulkTransfer");
												 fileDetailsObj.getConnection().close();
												return modelAndViewObj;
											}
											
										}
									}
							
							
								}
							
							bulkList.add(bd);
							}
							}
	int b = bulkDao.insertDetails(bulkList,fileDetailsObj1.getConnection(),fileDetailsObj1.getTransactionDef(),fileDetailsObj1.getTransactionManager(),fileDetailsObj1.getTransaction());
							
							//	System.out.println("Status of transaction : "+b);
								if(b==0){
								//	fileDetailsObj1.getTransactionManager().rollback(fileDetailsObj1.getTransaction());
									isValidTrans=false;
								//	break;
								}
								else{
								//	System.out.println("INSERTED into records table");
									isValidTrans=true;
								}
							if(isValidTrans){
								fileDetailsObj.setConnection(fileDetailsObj1.getConnection());
								fileDetailsObj.setTransaction(fileDetailsObj1.getTransaction());
								fileDetailsObj.setTransactionManager(fileDetailsObj1.getTransactionManager());
								fileDetailsObj.setTransactionDef(fileDetailsObj1.getTransactionDef());
								String extension="xlsx";
								fileDetailsObj2 = bulkDao
										.recordCheckxlsxTransfer(fileDetailsObj,errorFilesPath,extension);
						
								
								//System.out.println(" sno in activity log ::"+SNo);
	                    if(fileDetailsObj2.getErrorMsg().equalsIgnoreCase("SUCCESS")&&fileDetailsObj2.getStatus()==null)
	                    {
	                      	 fileDetailsObj2.setConnection(fileDetailsObj1.getConnection());
									fileDetailsObj2.setTransaction(fileDetailsObj1.getTransaction());
									fileDetailsObj2.setTransactionManager(fileDetailsObj1.getTransactionManager());
									fileDetailsObj2.setTransactionDef(fileDetailsObj1.getTransactionDef());
									fileDetailsObj2.setUserId(userId);
									fileDetailsObj2.setSessionId(session.getId());
								 BulkUtil.fileUpload(file,downloadpath,fileDetailsObj1.getOriginalFileName(),extension);
								 fileDetailsObj.getConnection().commit();
	                             fileDetailsObj.getTransactionManager().commit(fileDetailsObj.getTransaction());
	                       
	                           fileDetailsObj.getConnection().close();
								
					   }
	                    else if(fileDetailsObj2.getErrorMsg().equalsIgnoreCase("SUCCESS")&&fileDetailsObj2.getStatus()!=null)
	                    {
	                    	logger.info("validations are not sucessfull");
								SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","success"," file Upload  success and validations  not successfull",original,null,null); 
								  fileDetailsObj.getConnection().commit();
	                              fileDetailsObj.getTransactionManager().commit(fileDetailsObj.getTransaction());
	                        
	                            fileDetailsObj.getConnection().close();
	                    }
	                    else
	                    {
	                    	
	                    	logger.info("File has been  not uploaded because of data failure issues ");
	                    	
	                    	fileDetailsObj.getTransactionManager().rollback(fileDetailsObj.getTransaction());
	                    	fileDetailsObj.getConnection().close();
	                    	SNo=activityLogDao.insertActivityLog(SNo,userId,"file uploading","failed","failed because of data failure issues",original,null,null);
								 modelAndViewObj.addObject("error","data failure issues");
								 modelAndViewObj.setViewName("bulkTransfer");
								 return modelAndViewObj;
	                    }

							modelAndViewObj.addObject("flag",
									fileDetailsObj2.getFlag());
							modelAndViewObj.addObject("status",
									fileDetailsObj2.getStatus());
							 modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj1);
							 modelAndViewObj.addObject("extension", extension);
								modelAndViewObj.setViewName("transferSuccess");
								logger.info("End of upload");

							}
							else{
								logger.info("records are not inserted because of data failure issues");
								SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","Failure","Data issues!!",original,null,null);
								 modelAndViewObj.addObject("error","data failure issues");
								 modelAndViewObj.setViewName("bulkTransfer");
								 return modelAndViewObj;
							}

					}else

					{
						// System.out.println("Given header amount and sum of all the records are not matched..!!!");
						 SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","file already uploaded",original,null,null);
						 logger.info("File already Uploaded");
						 modelAndViewObj.addObject("error", "Invalid File:FileName cannot be same");
						modelAndViewObj.setViewName("bulkTransfer");
						return modelAndViewObj;
					} }
		    	   else
		    	   {
		    		   logger.info("file  details has not been inserted into status table because of data failure issues");
	    		   modelAndViewObj.addObject("error", "database  failure issues");
	    		   modelAndViewObj.setViewName("bulkTransfer");
	    		   return modelAndViewObj;// main if sumCountHeader==sum closed
		    	  
		    	   }
		    	   
				} else

				{
					SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","failure","headers are not matched",original,null,null);
				
					logger.info("Given header is not macthed");

					modelAndViewObj.addObject("error", "Invalid File with Header Mismatch");
					modelAndViewObj.setViewName("bulkTransfer");
					return modelAndViewObj;
				}
			
				
			}

			catch (Exception e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("error", "invalid file");
				modelAndViewObj.setViewName("bulkTransfer");
				return modelAndViewObj;
				
			}

		}

		else {
			try {
				SNo=activityLogDao.insertActivityLog(SNo,userId,"File Upload","valid xls file","file is empty",original,null,null);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//System.out.println("sno in activity log"+SNo);
			logger.info("File is not valid!!");

			modelAndViewObj.addObject("error", "Entered file is empty!!");
			modelAndViewObj.setViewName("bulkTransfer");
			return modelAndViewObj;
		}
		return modelAndViewObj;
		}
public static String getTimeAndDate() {
	Date today = Calendar.getInstance().getTime();
	SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyyHHmmss");
	return formatter.format(today);
}

//Added by Ritu on 14th June 2019
public static EMailContent sendEmailAlert(BulkDao bulkDao,FileDetails fileDetailsObj,String alertType){
	EMailContent eMailContentObj=new EMailContent();
	File file=null;
	InputStream inputStream=null;
	Properties props=null;
	UserEmailDetails userEmailDetails = new UserEmailDetails();
	if(alertType!=null&&alertType.equalsIgnoreCase("FILE_LEVEL_VALIDATIONS_SUCCESS_ALERT")){
		file=new File(homePath+"/Conf/EmailAlertsTemplates/PaymentTransferRequestIdConfirmationAlert.properties");
		try {
			inputStream=new FileInputStream(file);
			props=new Properties();
			props.load(inputStream);
			logger.info("requet id in mail body " +fileDetailsObj.getFileID());
			eMailContentObj.setEmailSubject(props.getProperty("emailSubject","Payment Transfer request Id A has been submitted").replace("A",fileDetailsObj.getFileID()));
			eMailContentObj.setEmailHeader(props.getProperty("emailHeader","Dear User"));
			eMailContentObj.setEmailFooter(props.getProperty("emailFooter","Regards,<br>Airtel Payments System."));
			eMailContentObj.setEmailBody(props.getProperty("emailBody").replace("A",fileDetailsObj.getFileID()));

			//Comment for testing
			eMailContentObj.setSmtpFromAddress("APS_Payment_Transfer@airtel.com");

			userEmailDetails=bulkDao.getEmailAddress(fileDetailsObj.getUserId());
			if(userEmailDetails!=null&&userEmailDetails.getErrorCode()!=null&&userEmailDetails.getErrorCode().equalsIgnoreCase("SUCCESS")){

				List<String> emailToList=new ArrayList<String>();
				emailToList.add(userEmailDetails.getEmailAddress());
				eMailContentObj.setEmailToList(emailToList);

				eMailContentObj.setAttachmentRequired(false);

				SmtpUtility.setLogger(logger);
				SmtpMailContent smtpMailContentObj=SmtpUtility.generateEmailAlert(eMailContentObj);
				eMailContentObj.setErrorCode(smtpMailContentObj.getErrorCode());
				eMailContentObj.setErrorMessage(smtpMailContentObj.getErrorMessage());
				return eMailContentObj;
			}
			else if(userEmailDetails!=null&&userEmailDetails.getErrorCode()!=null&&userEmailDetails.getErrorCode().equalsIgnoreCase("FAILURE")){
				eMailContentObj.setErrorCode(userEmailDetails.getErrorCode());
				eMailContentObj.setErrorMessage(userEmailDetails.getErrorMessage());
				return eMailContentObj;
			}
			else{
				eMailContentObj.setErrorCode("FAILURE");
				eMailContentObj.setErrorMessage("Invalid response received while capturing user email address");
				return eMailContentObj;
			}
		} catch (FileNotFoundException e) {
			eMailContentObj.setErrorCode("FAILURE");
			eMailContentObj.setErrorMessage("Unable to sent email alert, reason for the failure is "+e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		catch (IOException e) {
			eMailContentObj.setErrorCode("FAILURE");
			eMailContentObj.setErrorMessage("Unable to sent email alert, reason for the failure is "+e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
	}
	
	return eMailContentObj; 
}

}

