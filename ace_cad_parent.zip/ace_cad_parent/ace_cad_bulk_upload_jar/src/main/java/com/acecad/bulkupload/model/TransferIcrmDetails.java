package com.acecad.bulkupload.model;

import java.sql.Date;
import java.util.List;

public class TransferIcrmDetails {
	
	private String srNumber;
	private String type;
	private String subSubType;
	private String subType;
	private String caseType;
	private String sourceAccountNumber;
	private String destinationAccountNumber;
	private String amount;
	private String reasonForTransfer;
	private String refNumber;
	private String errMsg;
	private String parentUserId;
	private String srcLob;
	private String desLob;
	private String fxAmount; 
	private String derivedB2bB2c;
	private String payMode;
	private String recordStatus;
	private String srCreatedBy;
	private String trackingId;
	private String trackingIdServ;
	private List<String> trackingIdList;
	private List<String> remarksList;
	private String srUpdatedBy;
	private String billDate;
	private String Remarks;
	private String transferPayMode;
	private String srCreatedTime;
	private Date updatedBy;
	private String chequeDate;
	 private String srcCurrency;
		private String desCurrency;
		private String sessionId;
		private String userId;
		private long recordId;
		private String recordType;
		private String billRefAssests;
		private String annotation;
		
	    private float exchange_rate;
	    private String receiverIFSC;
		private String remitterAcctNum;
		private String remitterBranch;
		private String srcServId;
		private String desServId;
		public String getSrcCurrency() {
			return srcCurrency;
		}
		public void setSrcCurrency(String srcCurrency) {
			this.srcCurrency = srcCurrency;
		}
		public String getDesCurrency() {
			return desCurrency;
		}
		public void setDesCurrency(String desCurrency) {
			this.desCurrency = desCurrency;
		}
		public String getSessionId() {
			return sessionId;
		}
		public void setSessionId(String sessionId) {
			this.sessionId = sessionId;
		}
		public String getUserId() {
			return userId;
		}
		public void setUserId(String userId) {
			this.userId = userId;
		}
		public long getRecordId() {
			return recordId;
		}
		public void setRecordId(long recordId) {
			this.recordId = recordId;
		}
		public String getRecordType() {
			return recordType;
		}
		public void setRecordType(String recordType) {
			this.recordType = recordType;
		}
		public String getBillRefAssests() {
			return billRefAssests;
		}
		public void setBillRefAssests(String billRefAssests) {
			this.billRefAssests = billRefAssests;
		}
		public String getAnnotation() {
			return annotation;
		}
		public void setAnnotation(String annotation) {
			this.annotation = annotation;
		}
		public String getBillCompany() {
			return billCompany;
		}
		public void setBillCompany(String billCompany) {
			this.billCompany = billCompany;
		}
		public String getSrStatus() {
			return srStatus;
		}
		public void setSrStatus(String srStatus) {
			this.srStatus = srStatus;
		}
		private String incomingTransRefNum;
		private float amountInINR;
		private String receivingAcctRbi1;
		private String srcLegalEntity;
		private String fxLegalEntity;
		private String fxValueType;
		private String fxVIPFlag;
		private String fxCustomerType;
		private String fxCustomerClass;
		private String srcPaymentCode;
		private String desPaymentCode;
		private String invoice;
		private String accountType;
		private float oldExchangeRate;
		//private String liuStatus;
		private String vendorName;
		private String origBillRefNo;
		private String origBillRefResets;
		private float effectivePaymentAmount;
		private String display;
		private String currency;
		private String delNumber;
		//private int liuValue;
		private int actedIn;
		private String fileName;
		private String marketCode;
		private String fxInternalAcctNum;
		private String billCompany;
		private String customerName;
		private String rejectionReason;
		private String errorReasonCode;
	private String srStatus;
	public String getSrcLob() {
		return srcLob;
	}
	public void setSrcLob(String srcLob) {
		this.srcLob = srcLob;
	}
	public String getDesLob() {
		return desLob;
	}
	public void setDesLob(String desLob) {
		this.desLob = desLob;
	}
	public String getFxAmount() {
		return fxAmount;
	}
	public void setFxAmount(String fxAmount) {
		this.fxAmount = fxAmount;
	}
	public String getParentUserId() {
		return parentUserId;
	}
	public void setParentUserId(String parentUserId) {
		this.parentUserId = parentUserId;
	}
	public String getErrMsg() {
		return errMsg;
	}
	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	public String getTrackingIdServ() {
		return trackingIdServ;
	}
	public void setTrackingIdServ(String trackingIdServ) {
		this.trackingIdServ = trackingIdServ;
	}
	
	public List<String> getRemarksList() {
		return remarksList;
	}
	public void setRemarksList(List<String> remarksList) {
		this.remarksList = remarksList;
	}
	public String getRemarks() {
		return Remarks;
	}
	public List<String> getTrackingIdList() {
		return trackingIdList;
	}
	public void setTrackingIdList(List<String> trackingIdList) {
		this.trackingIdList = trackingIdList;
	}
	public void setRemarks(String remarks) {
		Remarks = remarks;
	}
	
	
	public String getTransferPayMode() {
		return transferPayMode;
	}
	public void setTransferPayMode(String transferPayMode) {
		this.transferPayMode = transferPayMode;
	}
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSubSubType() {
		return subSubType;
	}
	public void setSubSubType(String subSubType) {
		this.subSubType = subSubType;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getCaseType() {
		return caseType;
	}
	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}
	public String getSourceAccountNumber() {
		return sourceAccountNumber;
	}
	public void setSourceAccountNumber(String sourceAccountNumber) {
		this.sourceAccountNumber = sourceAccountNumber;
	}
	public String getDestinationAccountNumber() {
		return destinationAccountNumber;
	}
	public void setDestinationAccountNumber(String destinationAccountNumber) {
		this.destinationAccountNumber = destinationAccountNumber;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getReasonForTransfer() {
		return reasonForTransfer;
	}
	public void setReasonForTransfer(String reasonForTransfer) {
		this.reasonForTransfer = reasonForTransfer;
	}
	public String getRefNumber() {
		return refNumber;
	}
	public void setRefNumber(String refNumber) {
		this.refNumber = refNumber;
	}
	public String getPayMode() {
		return payMode;
	}
	public void setPayMode(String payMode) {
		this.payMode = payMode;
	}
	public String getRecordStatus() {
		return recordStatus;
	}
	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}
	public String getSrCreatedBy() {
		return srCreatedBy;
	}
	public void setSrCreatedBy(String srCreatedBy) {
		this.srCreatedBy = srCreatedBy;
	}
	public String getSrUpdatedBy() {
		return srUpdatedBy;
	}
	public void setSrUpdatedBy(String srUpdatedBy) {
		this.srUpdatedBy = srUpdatedBy;
	}
	public String getBillDate() {
		return billDate;
	}
	public void setBillDate(String billDate) {
		this.billDate = billDate;
	}
	public String getSrCreatedTime() {
		return srCreatedTime;
	}
	public void setSrCreatedTime(String srCreatedTime) {
		this.srCreatedTime = srCreatedTime;
	}
	public Date getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(Date updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	public String getChequeDate() {
		return chequeDate;
	}
	public void setChequeDate(String chequeDate) {
		this.chequeDate = chequeDate;
	}
	
	
		public float getExchange_rate() {
			return exchange_rate;
		}
		public void setExchange_rate(float exchange_rate) {
			this.exchange_rate = exchange_rate;
		}
	

    
	public String getErrorReasonCode() {
		return errorReasonCode;
	}
	public void setErrorReasonCode(String errorReasonCode) {
		this.errorReasonCode = errorReasonCode;
	}
	public String getRejectionReason() {
		return rejectionReason;
	}
	public void setRejectionReason(String rejectionReason) {
		this.rejectionReason = rejectionReason;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public String getSrcLegalEntity() {
		return srcLegalEntity;
	}
	public void setSrcLegalEntity(String srcLegalEntity) {
		this.srcLegalEntity = srcLegalEntity;
	}
	public String getFxLegalEntity() {
		return fxLegalEntity;
	}
	public void setFxLegalEntity(String fxLegalEntity) {
		this.fxLegalEntity = fxLegalEntity;
	}
	public String getFxValueType() {
		return fxValueType;
	}
	public void setFxValueType(String fxValueType) {
		this.fxValueType = fxValueType;
	}
	public String getFxVIPFlag() {
		return fxVIPFlag;
	}
	public void setFxVIPFlag(String fxVIPFlag) {
		this.fxVIPFlag = fxVIPFlag;
	}
	public String getFxCustomerType() {
		return fxCustomerType;
	}
	public void setFxCustomerType(String fxCustomerType) {
		this.fxCustomerType = fxCustomerType;
	}
	public String getFxCustomerClass() {
		return fxCustomerClass;
	}
	public void setFxCustomerClass(String fxCustomerClass) {
		this.fxCustomerClass = fxCustomerClass;
	}
	
	public String getInvoice() {
		return invoice;
	}
	public String getDerivedB2bB2c() {
		return derivedB2bB2c;
	}
	public void setDerivedB2bB2c(String derivedB2bB2c) {
		this.derivedB2bB2c = derivedB2bB2c;
	}
	public String getSrcPaymentCode() {
		return srcPaymentCode;
	}
	public void setSrcPaymentCode(String srcPaymentCode) {
		this.srcPaymentCode = srcPaymentCode;
	}
	public String getDesPaymentCode() {
		return desPaymentCode;
	}
	public void setDesPaymentCode(String desPaymentCode) {
		this.desPaymentCode = desPaymentCode;
	}
	public void setInvoice(String invoice) {
		this.invoice = invoice;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public float getOldExchangeRate() {
		return oldExchangeRate;
	}
	public void setOldExchangeRate(float oldExchangeRate) {
		this.oldExchangeRate = oldExchangeRate;
	}
	
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getOrigBillRefNo() {
		return origBillRefNo;
	}
	public void setOrigBillRefNo(String origBillRefNo) {
		this.origBillRefNo = origBillRefNo;
	}
	public String getOrigBillRefResets() {
		return origBillRefResets;
	}
	public void setOrigBillRefResets(String origBillRefResets) {
		this.origBillRefResets = origBillRefResets;
	}
	public float getEffectivePaymentAmount() {
		return effectivePaymentAmount;
	}
	public void setEffectivePaymentAmount(float effectivePaymentAmount) {
		this.effectivePaymentAmount = effectivePaymentAmount;
	}
	public String getDisplay() {
		return display;
	}
	public void setDisplay(String display) {
		this.display = display;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getDelNumber() {
		return delNumber;
	}
	public void setDelNumber(String delNumber) {
		this.delNumber = delNumber;
	}
	
	public int getActedIn() {
		return actedIn;
	}
	public void setActedIn(int actedIn) {
		this.actedIn = actedIn;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getMarketCode() {
		return marketCode;
	}
	public void setMarketCode(String marketCode) {
		this.marketCode = marketCode;
	}
	public String getFxInternalAcctNum() {
		return fxInternalAcctNum;
	}
	public void setFxInternalAcctNum(String fxInternalAcctNum) {
		this.fxInternalAcctNum = fxInternalAcctNum;
	}
	
	public String getReceiverIFSC() {
		return receiverIFSC;
	}
	public void setReceiverIFSC(String receiverIFSC) {
		this.receiverIFSC = receiverIFSC;
	}
	public String getRemitterAcctNum() {
		return remitterAcctNum;
	}
	public void setRemitterAcctNum(String remitterAcctNum) {
		this.remitterAcctNum = remitterAcctNum;
	}
	public String getRemitterBranch() {
		return remitterBranch;
	}
	public void setRemitterBranch(String remitterBranch) {
		this.remitterBranch = remitterBranch;
	}
	public String getIncomingTransRefNum() {
		return incomingTransRefNum;
	}
	public void setIncomingTransRefNum(String incomingTransRefNum) {
		this.incomingTransRefNum = incomingTransRefNum;
	}
	public float getAmountInINR() {
		return amountInINR;
	}
	public void setAmountInINR(float amountInINR) {
		this.amountInINR = amountInINR;
	}
	public String getReceivingAcctRbi1() {
		return receivingAcctRbi1;
	}
	public void setReceivingAcctRbi1(String receivingAcctRbi1) {
		this.receivingAcctRbi1 = receivingAcctRbi1;
	}
	public String getSrcServId() {
		return srcServId;
	}
	public void setSrcServId(String srcServId) {
		this.srcServId = srcServId;
	}
	public String getDesServId() {
		return desServId;
	}
	public void setDesServId(String desServId) {
		this.desServId = desServId;
	}	
	

}
