package com.acecad.bulkupload.model;

import java.sql.Timestamp;
import java.util.Date;

public class PaymentBulkDetails {
	int requestId;
	String utrOrChqNumber;
	String targetFXAccountNumber;
	String invoiceNumber;
	Double invoiceAllocationAmount;
	String remarks;
	String bankVirtualNo;
	String paymentCurrency;

	
	public int getRequestId() {
		return requestId;
	}
	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}
	public String getUtrOrChqNumber() {
		return utrOrChqNumber;
	}
	public void setUtrOrChqNumber(String utrOrChqNumber) {
		this.utrOrChqNumber = utrOrChqNumber;
	}
	public String getTargetFXAccountNumber() {
		return targetFXAccountNumber;
	}
	public void setTargetFXAccountNumber(String targetFXAccountNumber) {
		this.targetFXAccountNumber = targetFXAccountNumber;
	}
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public Double getInvoiceAllocationAmount() {
		return invoiceAllocationAmount;
	}
	public void setInvoiceAllocationAmount(Double invoiceAllocationAmount) {
		this.invoiceAllocationAmount = invoiceAllocationAmount;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getBankVirtualNo() {
		return bankVirtualNo;
	}
	public void setBankVirtualNo(String bankVirtualNo) {
		this.bankVirtualNo = bankVirtualNo;
	}
	public String getPaymentCurrency() {
		return paymentCurrency;
	}
	public void setPaymentCurrency(String paymentCurrency) {
		this.paymentCurrency = paymentCurrency;
	}
	
	
}
