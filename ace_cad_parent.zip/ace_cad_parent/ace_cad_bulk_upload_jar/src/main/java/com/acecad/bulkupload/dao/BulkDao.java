package com.acecad.bulkupload.dao;

import java.util.List;
import java.util.Map;

import com.acecad.bulkupload.model.BulkDetails;
import com.acecad.bulkupload.model.FileDetails;
import com.acecad.bulkupload.model.PaymentAdviceDetails;
import com.acecad.bulkupload.model.PaymentAdviceFileDetails;
import com.acecad.bulkupload.model.PaymentTransferDTO;
import com.acecad.bulkupload.model.Transfer;
import com.acecad.bulkupload.model.UserEmailDetails;
import com.acecad.bulkupload.util.StopDeatils;

import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;

import java.sql.Connection;

public interface BulkDao {

	int activityLog(int object, String string, String string2, String object2, String string3);
	public FileDetails vendorDetailsNonBankable(FileDetails fileObj);
	FileDetails vendorDetails(FileDetails fileDetailsObj);
	FileDetails recordCheckxls(FileDetails fileDetailsObj, String downloadPath, String isFileValid);
	public FileDetails recordCheckxlsx(FileDetails fileObj, String downloadPath, String isFileValid);
	public int insertDetails(List<BulkDetails> bulkDetails, Connection connection, TransactionDefinition transDef,PlatformTransactionManager transMager, TransactionStatus transactionStatus);
	String rejectRequest(List<String> fileIdsList, String rejectComments,String userId);
	String headerProc(String fileType, String fileName, List<String> headersList);
	List<FileDetails> retreiveDetailsForSpoc(String userId, String role);
	List<FileDetails> retreiveDetailsForSpocbasedOnSearch(String fileId, 
	              String date, String useriD, String role);
	
	
	Map<Map<Integer, List<String>>, List<FileDetails>> retreiveDetailsForSpocp(
	   int page, String userId, String role);
	   
	   
	Map<Map<Integer, List<String>>, List<FileDetails>> retreiveDetailsForSpocbasedOnSearch(
	      int page, String fileId,String activeDate, String endDate, String userId,
		  String role, String paymentMode, String UserId);
	int insertNonBankableDetails(BulkDetails bd, Connection connection, TransactionDefinition transactionDefinition,PlatformTransactionManager platformTransactionManager, TransactionStatus transactionStatus);
	String getFileIds();
	Map<Map<Integer, List<String>>, List<BulkDetails>> getNonBankableList(String pagenum, String fileId,
	     String chequeNum, String micrCode, String startChequeDate, String endChequeDate);
	FileDetails recordCheckxlsxOthers(FileDetails fileDetailsObj,
	      String errorFilesPath, String extension);
	FileDetails recordCheckxlsOthers(FileDetails fileDetailsObj, 
	      String errorFilesPath, String extension);
	FileDetails reversalFileDetails(FileDetails fileDetailsObj);
	FileDetails recordCheckxlsReversal(FileDetails fileDetailsObj, 
	     String errorFilesPath, String extension);
	FileDetails recordCheckxlsxReversal(FileDetails fileDetailsObj, 
	     String errorFilesPath, String extension);
	FileDetails approveReversalFilePaymentCheck(FileDetails fileID, String errorFilesPath, String extension);
	// public FileDetails approveFileChequeBounce(FileDetails,fileDetailsObj,String errorFilesPath, String extension) ;
	public FileDetails recordCheckxlsChequeBounce(FileDetails fileDetailsObj,
	       String errorFilesPath, String extension);
	FileDetails recordCheckxlsBankStatement(FileDetails fileDetailsObj, 
	      String errorFilesPath, String extension);
	FileDetails recordCheckxlsxBankStatement(FileDetails fileDetailsObj,
	      String errorFilesPath, String extension);
	List<BulkDetails> getCustomerAccounts(String fileId);
	/*
	 * FileDetails approveReversalFile(FileDetails fileDetailsObj2, String
	 * errorFilesPath, String extension);
	 */
	FileDetails recordCheckxlsTransfer(FileDetails fileDetailsObj, 
	   String errorFilesPath, String extension);
	FileDetails transferFileDetails(FileDetails fileDetailsObj);
	// List<BulkDetails> getCustomerAccountsForFileId(String fileId);
	String getPaymentCode(List<BulkDetails> customerAccountsRecords);
	List<BulkDetails> getCustomerAccountsForFileId(String fileId, 
	     String sessionId, String userId);
	/* List<Transfer> test(); */
	String transferPushing(List<Transfer> transferList);
	BulkDetails getAccountDetails(BulkDetails bulkDetailsObj);
	List<String> retreiveListforDropDown(String role, String userId);
	Map<Map<Integer, List<String>>, List<FileDetails>> reversalTracking(
	   int page, String fileId, String reversalType,String userId, 
	   String role, String status, String fileName);
	List<String> getSupervisorEmailIds(String userId, String role);
	List<String> getUserMailIds(String userId, String role, 
	     String fileId);
	FileDetails getCountLiu(String fileId);
	FileDetails getEmailUser(String fileId1);
	Map<Map<Integer, List<String>>, List<FileDetails>> transferTracking(
	   int page, String fileID, String transferType,String userId, 
	   String role, String fxStatus, String fileName);
	FileDetails recordCheckxlsxChequeBounce(FileDetails fileDetailsObj,
	    String errorFilesPath, String extension);
	String approveRequestNeft(String fileId, String userId);
	String approveRequest(String fileId, String userId);
    FileDetails recordCheckxlsxTransfer(FileDetails fileDetailsObj, 
	   String errorFilesPath, String extension);
	Map<Map<Integer, List<String>>, List<FileDetails>> paymentTracking(
	     int page, String fileId, String paymentMode,String userId, 
		 String role, String status, String fileName);
	List<BulkDetails> getDirectRevTransLevelRecords(String fileID);
	List<BulkDetails> getChequeBounceTransLevelRecords(String fileID);
	List<BulkDetails> getPymntTransferErrorRecords(String fileId);
	List<String> getUserCircles();
	
	List<String> trackingFilenameList(String userId);
	// Added By APS Team
	public boolean checkCircle(String cir);
	// List<BulkDetails> getDummyAccounts(String accountNumber);
	
	//Added by Ritu
		PaymentTransferDTO getPaymentTransferWorkDetails(String roleId,PaymentTransferDTO paymentTransferDTO) throws Exception;
		public PaymentTransferDTO downloadPaymentTransferFile(String userId,String fileId,String requestFileName);	
	   // public String approvePaymentTransfer(List<String> checkedPTList,List<String> checkedRemarkList, String userId, String action,String rejectReasonDropdown,String rejectReason) throws Exception;
		public Object approvePaymentTransfer(List<String> checkedPTList,List<String> checkedRemarkList, String userId, String action,String rejectReasonDropdown,String rejectReason) throws Exception;
	    public void updatePTFDetails(String supportFile,String fileId);
	    public List<String> getRejectReasons();
	    PaymentTransferDTO searchPaymentTransferRecords(String roleId,String userId,PaymentTransferDTO paymentTransferDTO) throws Exception;
	    PaymentTransferDTO  downloadsPTReports(String roleId,String userId,PaymentTransferDTO paymentTransferDTO) throws Exception;;
	    public UserEmailDetails getEmailAddress(String  userId) ;
	    //adeed by sreekanth
	    public List<StopDeatils> allStopNeftFiles();
	    public String responseMsgforStopFiles(String fileId);
	    
}