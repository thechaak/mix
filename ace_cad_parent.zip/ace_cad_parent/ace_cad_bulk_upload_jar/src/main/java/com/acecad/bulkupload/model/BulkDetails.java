package com.acecad.bulkupload.model;
import java.sql.Date;
import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

public class BulkDetails implements SQLData {


    private String fileID;
	private String circle;
	private String sourceID;
	private String sNo;
	private String vendorTransactID;
	private String acctEXTID;
	private String delNO;
	private String bankVirtualAcctNo;
	private String invoiceNo;
	private String customerName;
	private String connectName;
	private String paymentAmt;
	private Date paymentDate;
	private String chequeNo;
	private String micrCode;
	private String bankName;
	private String annotation;
	private String lockboxID;
	private String remarks;
	private String custType;
	private String loadStatusPayment;
	private String loadErrorCode;
	private String isErrorRecord;
	private String errorReasonCode;
	private String changeWho;
	private Date changeDate;
	private Date insertDate;
	private String paymentMode;
	private String customerType;
	private String errorCodeDescription;
	private String serviceType;
	private String referenceId;
	private  Date chequeDate;
	private  Date receiptDate;
	private String ifscCode;
	private String bankGLCode;
	//private String exchangeRate;
	private String SRNo;
	private String orderNo;
	private String circuitId;
	private String serviceNo;
	private String depositSlipNo;
	private java.util.Date transDate;
	private String errorCode;
	private String errorMsg;
	private String reason;
	private String paymentCurrency;
	private String exchangeRate;
	private String bankBranchName;
	private String remitterName;
	private String trackingId;
	private String trackingIdServ;
	private String paymentCode;
	private String amountInr;
	private String accountNumberRBI1;
	private String receiverName;
	private String receiverIfsc;
	private String incomingTransactionNo;
	private String remitterAccNo;
	private String remitterBranch;
	private String remitterIfsc;
	private String refNo;
	private String productType;
	private String paymentDetails1;
	private String paymentDetails2;
	private String paymentDetails3;
	private String transferType;
	private String ticketNo;
	private String fxStatus;
	private String accountType;
	private String valueType;
	private String vipFlag;
	private String customerClass;
	private String segment;
	private String receivingRbI1;
	private String dummyAccntNo;
	private String legalEntity;
	private String b2brc;
	private String vendorId;
	private String userId;
	private String sessionId;
	private String fxAcctNo;
	private String customerCurrency;
	private String recordId;
	private String collectionManager;
	private String origBillRefNo;
	private String origBillRefResets;
	private String toDate;
	private String fromDate;
	private String bounceReason;
	private String vendorName;
	private String dateOnChq;
	private String initialUploadDate;
	private String initialPostedDate;
	private String bouncedDate;
	private String bouncedMisDate;
	private String revPostingFxDate;
	private String userName;
	private String fileUploadDate;
	//private String bounceReason;
	private String fileName;
	//private String paymentCode;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getFileUploadDate() {
		return fileUploadDate;
	}
	public void setFileUploadDate(String fileUploadDate) {
		this.fileUploadDate = fileUploadDate;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getDateOnChq() {
		return dateOnChq;
	}
	public void setDateOnChq(String dateOnChq) {
		this.dateOnChq = dateOnChq;
	}
	public String getInitialUploadDate() {
		return initialUploadDate;
	}
	public void setInitialUploadDate(String initialUploadDate) {
		this.initialUploadDate = initialUploadDate;
	}
	public String getInitialPostedDate() {
		return initialPostedDate;
	}
	public void setInitialPostedDate(String initialPostedDate) {
		this.initialPostedDate = initialPostedDate;
	}
	public String getBouncedDate() {
		return bouncedDate;
	}
	public void setBouncedDate(String bouncedDate) {
		this.bouncedDate = bouncedDate;
	}
	public String getBouncedMisDate() {
		return bouncedMisDate;
	}
	public void setBouncedMisDate(String bouncedMisDate) {
		this.bouncedMisDate = bouncedMisDate;
	}
	public String getRevPostingFxDate() {
		return revPostingFxDate;
	}
	public void setRevPostingFxDate(String revPostingFxDate) {
		this.revPostingFxDate = revPostingFxDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getFileID() {
		return fileID;
	}
	public void setFileID(String fileID) {
		this.fileID = fileID;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getSourceID() {
		return sourceID;
	}
	public void setSourceID(String sourceID) {
		this.sourceID = sourceID;
	}
	public String getVendorTransactID() {
		return vendorTransactID;
	}
	public void setVendorTransactID(String vendorTransactID) {
		this.vendorTransactID = vendorTransactID;
	}
	public String getAcctEXTID() {
		return acctEXTID;
	}
	public void setAcctEXTID(String acctEXTID) {
		this.acctEXTID = acctEXTID;
	}
	public String getDelNO() {
		return delNO;
	}
	public void setDelNO(String delNO) {
		this.delNO = delNO;
	}
	public String getBankVirtualAcctNo() {
		return bankVirtualAcctNo;
	}
	public void setBankVirtualAcctNo(String bankVirtualAcctNo) {
		this.bankVirtualAcctNo = bankVirtualAcctNo;
	}
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	/*public String getCircleCode() {
		return circleCode;
	}
	public void setCircleCode(String circleCode) {
		this.circleCode = circleCode;
	}*/
	public String getPaymentAmt() {
		return paymentAmt;
	}
	public void setPaymentAmt(String paymentAmt) {
		this.paymentAmt = paymentAmt;
	}
	public Date getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}
	public String getChequeNo() {
		return chequeNo;
	}
	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}
	public String getMicrCode() {
		return micrCode;
	}
	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
	public String getLockboxID() {
		return lockboxID;
	}
	public void setLockboxID(String lockboxID) {
		this.lockboxID = lockboxID;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getCustType() {
		return custType;
	}
	public void setCustType(String custType) {
		this.custType = custType;
	}
	
	public String getsNo() {
		return sNo;
	}
	public void setsNo(String d) {
		this.sNo = d;
	}
	public String getLoadStatusPayment() {
		return loadStatusPayment;
	}
	public void setLoadStatusPayment(String loadStatusPayment) {
		this.loadStatusPayment = loadStatusPayment;
	}
	public String getLoadErrorCode() {
		return loadErrorCode;
	}
	public void setLoadErrorCode(String loadErrorCode) {
		this.loadErrorCode = loadErrorCode;
	}
	public String getIsErrorRecord() {
		return isErrorRecord;
	}
	public void setIsErrorRecord(String isErrorRecord) {
		this.isErrorRecord = isErrorRecord;
	}
	public String getErrorReasonCode() {
		return errorReasonCode;
	}
	public void setErrorReasonCode(String errorReasonCode) {
		this.errorReasonCode = errorReasonCode;
	}
	public String getChangeWho() {
		return changeWho;
	}
	public void setChangeWho(String changeWho) {
		this.changeWho = changeWho;
	}
	public Date getChangeDate() {
		return changeDate;
	}
	public void setChangeDate(Date changeDate) {
		this.changeDate = changeDate;
	}
	public Date getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}
	public String getErrorCodeDescription() {
		return errorCodeDescription;
	}
	public void setErrorCodeDescription(String errorCodeDescription) {
		this.errorCodeDescription = errorCodeDescription;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getReferenceId() {
		return referenceId;
	}
	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}
	public Date getChequeDate() {
		return chequeDate;
	}
	public void setChequeDate(Date date) {
		this.chequeDate = date;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getConnectName() {
		return connectName;
	}
	public void setConnectName(String connectName) {
		this.connectName = connectName;
	}
	public String getAnnotation() {
		return annotation;
	}
	public void setAnnotation(String annotation) {
		this.annotation = annotation;
	}
	public String getBankGLCode() {
		return bankGLCode;
	}
	public void setBankGLCode(String bankGLCode) {
		this.bankGLCode = bankGLCode;
	}
	public String getExchangeRate() {
		return exchangeRate;
	}
	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}
	public String getSRNo() {
		return SRNo;
	}
	public void setSRNo(String sRNo) {
		SRNo = sRNo;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getCircuitId() {
		return circuitId;
	}
	public void setCircuitId(String circuitId) {
		this.circuitId = circuitId;
	}
	public String getServiceNo() {
		return serviceNo;
	}
	public void setServiceNo(String serviceNo) {
		this.serviceNo = serviceNo;
	}
	public String getDepositSlipNo() {
		return depositSlipNo;
	}
	public void setDepositSlipNo(String depositSlipNo) {
		this.depositSlipNo = depositSlipNo;
	}
	public java.util.Date getTransDate() {
		return  transDate;
	}
	public void setTransDate(java.util.Date date) {
		this.transDate = date;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getPaymentCurrency() {
		return paymentCurrency;
	}
	public void setPaymentCurrency(String paymentCurrency) {
		this.paymentCurrency = paymentCurrency;
	}
	public String getBankBranchName() {
		return bankBranchName;
	}
	public void setBankBranchName(String bankBranchName) {
		this.bankBranchName = bankBranchName;
	}
	public String getRemitterName() {
		return remitterName;
	}
	public void setRemitterName(String remitterName) {
		this.remitterName = remitterName;
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	public String getTrackingIdServ() {
		return trackingIdServ;
	}
	public void setTrackingIdServ(String trackingIdServ) {
		this.trackingIdServ = trackingIdServ;
	}
	public String getPaymentCode() {
		return paymentCode;
	}
	public void setPaymentCode(String d) {
		this.paymentCode = d;
	}
	public String getIncomingTransactionNo() {
		return incomingTransactionNo;
	}
	public void setIncomingTransactionNo(String incomingTransactionNo) {
		this.incomingTransactionNo = incomingTransactionNo;
	}
	public String getAmountInr() {
		return amountInr;
	}
	public void setAmountInr(String amountInr) {
		this.amountInr = amountInr;
	}
	public String getAccountNumberRBI1() {
		return accountNumberRBI1;
	}
	public void setAccountNumberRBI1(String accountNumberRBI1) {
		this.accountNumberRBI1 = accountNumberRBI1;
	}
	public String getReceiverName() {
		return receiverName;
	}
	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}
	public String getReceiverIfsc() {
		return receiverIfsc;
	}
	public void setReceiverIfsc(String receiverIfsc) {
		this.receiverIfsc = receiverIfsc;
	}
	public String getRemitterAccNo() {
		return remitterAccNo;
	}
	public void setRemitterAccNo(String remitterAccNo) {
		this.remitterAccNo = remitterAccNo;
	}
	public String getRemitterBranch() {
		return remitterBranch;
	}
	public void setRemitterBranch(String remitterBranch) {
		this.remitterBranch = remitterBranch;
	}
	public String getRemitterIfsc() {
		return remitterIfsc;
	}
	public void setRemitterIfsc(String remitterIfsc) {
		this.remitterIfsc = remitterIfsc;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getPaymentDetails1() {
		return paymentDetails1;
	}
	public void setPaymentDetails1(String paymentDetails1) {
		this.paymentDetails1 = paymentDetails1;
	}
	public String getPaymentDetails2() {
		return paymentDetails2;
	}
	public void setPaymentDetails2(String paymentDetails2) {
		this.paymentDetails2 = paymentDetails2;
	}
	public String getPaymentDetails3() {
		return paymentDetails3;
	}
	public void setPaymentDetails3(String paymentDetails3) {
		this.paymentDetails3 = paymentDetails3;
	}
	public String getTransferType() {
		return transferType;
	}
	public void setTransferType(String transferType) {
		this.transferType = transferType;
	}
	public String getTicketNo() {
		return ticketNo;
	}
	public void setTicketNo(String ticketNo) {
		this.ticketNo = ticketNo;
	}
	public String getFxStatus() {
		return fxStatus;
	}
	public void setFxStatus(String fxStatus) {
		this.fxStatus = fxStatus;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getValueType() {
		return valueType;
	}
	public void setValueType(String valueType) {
		this.valueType = valueType;
	}
	public String getVipFlag() {
		return vipFlag;
	}
	public void setVipFlag(String vipFlag) {
		this.vipFlag = vipFlag;
	}
	public String getCustomerClass() {
		return customerClass;
	}
	public void setCustomerClass(String customerClass) {
		this.customerClass = customerClass;
	}
	public String getSegment() {
		return segment;
	}
	public void setSegment(String segment) {
		this.segment = segment;
	}
	public String getReceivingRbI1() {
		return receivingRbI1;
	}
	public void setReceivingRbI1(String receivingRbI1) {
		this.receivingRbI1 = receivingRbI1;
	}
	public String getDummyAccntNo() {
		return dummyAccntNo;
	}
	public void setDummyAccntNo(String dummyAccntNo) {
		this.dummyAccntNo = dummyAccntNo;
	}
	public String getLegalEntity() {
		return legalEntity;
	}
	public void setLegalEntity(String legalEntity) {
		this.legalEntity = legalEntity;
	}
	public String getB2brc() {
		return b2brc;
	}
	public void setB2brc(String b2brc) {
		this.b2brc = b2brc;
	}
	public String getFxAcctNo() {
		return fxAcctNo;
	}
	public void setFxAcctNo(String fxAcctNo) {
		this.fxAcctNo = fxAcctNo;
	}
	@Override
	public String getSQLTypeName() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void writeSQL(SQLOutput stream) throws SQLException {
		// TODO Auto-generated method stub
		
	}
	public String getCustomerCurrency() {
		return customerCurrency;
	}
	public void setCustomerCurrency(String customerCurrency) {
		this.customerCurrency = customerCurrency;
	}
	public String getRecordId() {
		return recordId;
	}
	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}
	public String getCollectionManager() {
		return collectionManager;
	}
	public void setCollectionManager(String collectionManager) {
		this.collectionManager = collectionManager;
	}
	public String getOrigBillRefNo() {
		return origBillRefNo;
	}
	public void setOrigBillRefNo(String origBillRefNo) {
		this.origBillRefNo = origBillRefNo;
	}
	public String getOrigBillRefResets() {
		return origBillRefResets;
	}
	public void setOrigBillRefResets(String origBillRefResets) {
		this.origBillRefResets = origBillRefResets;
	}
	public String getBounceReason() {
		return bounceReason;
	}
	public void setBounceReason(String bounceReason) {
		this.bounceReason = bounceReason;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public Date getReceiptDate() {
		return receiptDate;
	}
	public void setReceiptDate(Date receiptDate) {
		this.receiptDate = receiptDate;
	}
	
	
	
}