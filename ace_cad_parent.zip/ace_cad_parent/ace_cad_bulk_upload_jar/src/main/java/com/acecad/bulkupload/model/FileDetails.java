package com.acecad.bulkupload.model;

import java.sql.Connection;
import java.util.Date;
import java.util.List;

import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;

public class FileDetails {

	private String fileID;
	private String VendorUserId;
	private String sourceID;
	private String Circle;
	private String OriginalFileName;
	private String FinalFileName;
	private int TotalRecords;
	private String FileUploadDate;
	private int FileAcceptanceStatus;
	private Date ChangeDate;
	private String ChangeWho;
	private int CountValidRecords;
	private int CountInvalidRecords;
	private String status;
	private String flag;
	private String errorReasonCode;
	private String paymentAmount;
	private int CountServiceMO;
	private int CountServiceFL;
	private int CountServiceAES;
	private int CountServiceISTM;
	private String errorCode;
	private String errorMsg;
	private String activeDate;
	private String inactiveDate;
	private String chequeNum;
	private String micrCode;
	private String fileTYpe;
	private String userId;
	private String sessionId;
	private String paymentMode;
	private String userName;
	private String emailId;
	private String mode;
	private String bankAccountNumber;
	private String roleId;
	private String rejectReason;
	private String requestStatus;
	private String RejectedRemarks;
	
	
	private List<PaymentTransferDTO> paymentTransferDetailsList;
	private int totalPages;
	private int totalResult;
	private int resultPerPage;
	
	public String getRejectReason() {
		return rejectReason;
	}
	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}
	
	
	public String getRejectedRemarks() {
		return RejectedRemarks;
	}
	public void setRejectedRemarks(String rejectedRemarks) {
		RejectedRemarks = rejectedRemarks;
	}
	public double getValidSum() {
		return validSum;
	}
	public void setValidSum(double validSum) {
		this.validSum = validSum;
	}
	public double getInValidSum() {
		return inValidSum;
	}
	public void setInValidSum(double inValidSum) {
		this.inValidSum = inValidSum;
	}
	
	
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	private double validSum;
	private double inValidSum;
	public String getMicrCode() {
		return micrCode;
	}
	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}
	public String getChequeNum() {
		return chequeNum;
	}
	public void setChequeNum(String chequeNum) {
		this.chequeNum = chequeNum;
	}
	public String getActiveDate() {
		return activeDate;
	}
	public void setActiveDate(String activeDate) {
		this.activeDate = activeDate;
	}
	public String getInactiveDate() {
		return inactiveDate;
	}
	public void setInactiveDate(String inactiveDate) {
		this.inactiveDate = inactiveDate;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	private String vendorType;
	private String vendorID;
	private TransactionStatus transaction;
	private Connection connection;
	private PlatformTransactionManager transactionManager;
	private TransactionDefinition transactionDef;
	private String trStatus;

	public TransactionDefinition getTransactionDef() {
		return transactionDef;
	}
	public void setTransactionDef(TransactionDefinition transactionDef) {
		this.transactionDef = transactionDef;
	}
	public PlatformTransactionManager getTransactionManager() {
		return transactionManager;
	}
	public void setTransactionManager(PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}
	public String getFileID() {
		return fileID;
	}
	public void setFileID(String fileID) {
		this.fileID = fileID;
	}
	public String getVendorUserId() {
		return VendorUserId;
	}
	public void setVendorUserId(String vendorUserId) {
		VendorUserId = vendorUserId;
	}
	public String getSourceID() {
		return sourceID;
	}
	public void setSourceID(String sourceID) {
		this.sourceID = sourceID;
	}
	public String getCircle() {
		return Circle;
	}
	public void setCircle(String circle) {
		Circle = circle;
	}
	public String getOriginalFileName() {
		return OriginalFileName;
	}
	public void setOriginalFileName(String originalFileName) {
		OriginalFileName = originalFileName;
	}
	public String getFinalFileName() {
		return FinalFileName;
	}
	public void setFinalFileName(String finalFileName) {
		FinalFileName = finalFileName;
	}
	public int getTotalRecords() {
		return TotalRecords;
	}
	public void setTotalRecords(int totalRecords) {
		TotalRecords = totalRecords;
	}
	public String getFileUploadDate() {
		return FileUploadDate;
	}
	public void setFileUploadDate(String fileUploadDate) {
		FileUploadDate = fileUploadDate;
	}
	public int getFileAcceptanceStatus() {
		return FileAcceptanceStatus;
	}
	public void setFileAcceptanceStatus(int fileAcceptanceStatus) {
		FileAcceptanceStatus = fileAcceptanceStatus;
	}
	
	public String getChangeWho() {
		return ChangeWho;
	}
	public void setChangeWho(String changeWho) {
		ChangeWho = changeWho;
	}
	public int getCountValidRecords() {
		return CountValidRecords;
	}
	public void setCountValidRecords(int countValidRecords) {
		CountValidRecords = countValidRecords;
	}
	public int getCountInvalidRecords() {
		return CountInvalidRecords;
	}
	public void setCountInvalidRecords(int countInvalidRecords) {
		CountInvalidRecords = countInvalidRecords;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getErrorReasonCode() {
		return errorReasonCode;
	}
	public void setErrorReasonCode(String errorReasonCode) {
		this.errorReasonCode = errorReasonCode;
	}
	public String getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public int getCountServiceMO() {
		return CountServiceMO;
	}
	public void setCountServiceMO(int countServiceMO) {
		CountServiceMO = countServiceMO;
	}
	public int getCountServiceFL() {
		return CountServiceFL;
	}
	public void setCountServiceFL(int countServiceFL) {
		CountServiceFL = countServiceFL;
	}
	public int getCountServiceAES() {
		return CountServiceAES;
	}
	public void setCountServiceAES(int countServiceAES) {
		CountServiceAES = countServiceAES;
	}
	public int getCountServiceISTM() {
		return CountServiceISTM;
	}
	public void setCountServiceISTM(int countServiceISTM) {
		CountServiceISTM = countServiceISTM;
	}
	
	public String getVendorType() {
		return vendorType;
	}
	public void setVendorType(String vendorType) {
		this.vendorType = vendorType;
	}
	public String getVendorID() {
		return vendorID;
	}
	public void setVendorID(String vendorID) {
		this.vendorID = vendorID;
	}
	public Date getChangeDate() {
		return ChangeDate;
	}
	public void setChangeDate(Date changeDate) {
		ChangeDate = changeDate;
	}
	public TransactionStatus getTransaction() {
		return transaction;
	}
	public void setTransaction(TransactionStatus status2) {
		this.transaction = status2;
	}
	public Connection getConnection() {
		return connection;
	}
	public void setConnection(Connection connection2) {
		this.connection = connection2;
	}
	public String getTrStatus() {
		return trStatus;
	}
	public void setTrStatus(String trStatus) {
		this.trStatus = trStatus;
	}
	public String getFileTYpe() {
		return fileTYpe;
	}
	public void setFileTYpe(String fileTYpe) {
		this.fileTYpe = fileTYpe;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getBankAccountNumber() {
		return bankAccountNumber;
	}
	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}
	
	public String getRoleId() {
		return roleId;
	}
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
	public List<PaymentTransferDTO> getPaymentTransferDetailsList() {
		return paymentTransferDetailsList;
	}
	public void setPaymentTransferDetailsList(List<PaymentTransferDTO> paymentTransferDetailsList) {
		this.paymentTransferDetailsList = paymentTransferDetailsList;
	}
	public int getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	public int getTotalResult() {
		return totalResult;
	}
	public void setTotalResult(int totalResult) {
		this.totalResult = totalResult;
	}
	public int getResultPerPage() {
		return resultPerPage;
	}
	public void setResultPerPage(int resultPerPage) {
		this.resultPerPage = resultPerPage;
	}
	
	
}