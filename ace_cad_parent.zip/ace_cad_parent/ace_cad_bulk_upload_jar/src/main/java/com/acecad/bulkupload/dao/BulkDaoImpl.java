package com.acecad.bulkupload.dao;
//Testing Bitbucket push
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
//import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
//import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
//import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
//import com.acecad.util.Writeexcel;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.acecad.bulkupload.model.BulkDetails;
import com.acecad.bulkupload.model.FileDetails;
import com.acecad.bulkupload.model.PaymentTransferDTO;
import com.acecad.bulkupload.model.Transfer;
import com.acecad.bulkupload.model.UserEmailDetails;
import com.acecad.bulkupload.util.StopDeatils;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;

public class BulkDaoImpl  implements BulkDao{
	@Autowired
  DataSource dataSource;
	@Autowired
	private PlatformTransactionManager transactionManager;
	final long startTime = System.nanoTime();
	
	private static Logger logger =LogManager.getLogger("bulkUploadLogger");
	private String homePath=System.getenv("ACE_CAD_HOME");
	public BulkDaoImpl()
	{
		
	}
	public BulkDaoImpl(DataSource dataSource) {
		this.dataSource = dataSource;
		setTransactionManager(transactionManager);
	}
	@Override
	public int activityLog(int object, String string, String string2,
			String object2, String string3) {
	
		return 0;
	}
	public void setTransactionManager(
		      PlatformTransactionManager transactionManager) {
		      this.transactionManager = transactionManager;
		   }
	
	public String headerProc(String fileType,String fileName,List<String> headersList) {
		
		final String procedureCall = "{call AIRTL_FILE_VALIDATIONS.AIRTL_FILE_VALIDATIONS_PROC(?,?,?,?,?)}";
		Connection connection = null;
	  String headerStatus=null;
		try {

			// Get Connection instance from dataSource
		//	logger.info("connect"+ "ion:" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			
			ArrayDescriptor des = ArrayDescriptor.createDescriptor("HEADER_CHECK_TYPE", connection); 
			 Object[] array=headersList.toArray();
			ARRAY array_to_pass = new ARRAY(des,connection,array);
			
			CallableStatement callableStatement = connection
					.prepareCall(procedureCall);
			
			callableStatement.setString(1,fileType);
			
			//callableStatement.setString(2,fileName);
		
			callableStatement.setArray(2,array_to_pass);
			
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.registerOutParameter(5, Types.VARCHAR);
			
			callableStatement.executeUpdate();
			headerStatus=callableStatement.getString(3);
			
		} catch (SQLException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);

		} finally {

			if (connection != null)
				try {
					connection.close();
				} catch (SQLException e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
		}
		return headerStatus;
		
	}
	public FileDetails vendorDetails(FileDetails fileObj) {
		TransactionDefinition def = new DefaultTransactionDefinition();
	    TransactionStatus status = transactionManager.getTransaction(def);
	    fileObj.setTransactionManager(transactionManager);
	    fileObj.setTransactionDef(def);
	    fileObj.setTransaction(status);
		final String procedureCall = "{call ACE_CAD_BULK_PAYMENT.ace_cad_file_details_insert(?,?,?,?,?,?,?,?,?,?,?,?,?)}";
		Connection connection = null;
		CallableStatement callableStatement=null;

		try {

			// Get Connection instance from dataSource
		//	System.out.println("connect"+ "ion:" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			fileObj.setConnection(connection);
			connection.setAutoCommit(false);
			 callableStatement = connection
					.prepareCall(procedureCall);

			callableStatement.setString(1, fileObj.getVendorUserId());
			callableStatement.setString(2, fileObj.getCircle());
			callableStatement.setString(3, fileObj.getOriginalFileName());
		
			callableStatement.setString(4, fileObj.getFinalFileName());
			callableStatement.setInt(5, fileObj.getTotalRecords());
		
		    callableStatement.setDouble(6,Double.parseDouble(fileObj.getPaymentAmount()));
		    callableStatement.setString(7,fileObj.getFileTYpe());
		    callableStatement.setString(8,fileObj.getPaymentMode());
		    callableStatement.setString(9, fileObj.getMode());
		  
			callableStatement.registerOutParameter(10, Types.VARCHAR);
			callableStatement.registerOutParameter(11, Types.VARCHAR);
			callableStatement.registerOutParameter(12, Types.VARCHAR);
			callableStatement.registerOutParameter(13, Types.VARCHAR);
			
			callableStatement.executeUpdate();
			
			fileObj.setFileID( callableStatement.getString(10));
			fileObj.setStatus(callableStatement.getString(11));
			fileObj.setErrorCode(callableStatement.getString(13));
			fileObj.setErrorMsg(callableStatement.getString(12));
			fileObj.setTrStatus("true");
			

			logger.info("file id is........ " + fileObj.getFileID());
		
			logger.info("Status ....." + fileObj.getStatus());
			
		
		} catch (SQLException e) {
			transactionManager.rollback(status);
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		  fileObj.setTrStatus("false");	

		} 
		catch (Exception e) {
			transactionManager.rollback(status);
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
			 fileObj.setTrStatus("false");	

		}
		finally
		{
			if(callableStatement!=null)
			{
				try {
					callableStatement.close();
				} catch (SQLException e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				
				}
			}
		}
		return fileObj;
	}
public String validateString(String val){
		
		try {
			if((val != null && val.contains("&")) || (val != null && val.contains("-"))){
				
				val=val.replace("&", "");
				val=val.replace("-", "");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return val;
	}
	public int insertDetails(List<BulkDetails> bulkDetailsList, Connection connection, TransactionDefinition transDef,PlatformTransactionManager transMager,TransactionStatus transactionStatus) {
		 //Connection conn = null;
		    PreparedStatement pstmt= null;
		    PreparedStatement pschq = null;
		    int b=0;
		    
		    try {
				// Get Connection instance from dataSource
				//logger.info("connection:" + dataSource.getConnection());
		      	String query= "insert into AIRTL_EPP_INIT_FILES_RECORDS(S_NO,FILE_ID,CIRCLE,SOURCE_ID,VENDOR_TRANSACTION_ID,ACCT_EXT_ID,DEL_NO,BANK_VIRTUAL_ACCOUNT_NO,INVOICE_NO,RECEIVER_NAME,PAYMENT_AMOUNT,PAYMENT_DATE,PAYMENT_MODE,REF_NUMBER,BANK_NAME,CHEQUE_DATE,LOCKBOX_ID,CUSTOMER_TYPE,LOAD_STATUS_PAYMENT_TABLE,LOAD_ERROR_CODE,CHANGE_WHO,REMARKS,IS_ERROR_RECORD,ERROR_REASON_CODE,SERVICE_TYPE,VC_REFERENCE_ID,IFSC_CODE,REMITTER_NAME,BANK_GL_CODE,EXCHANGE_RATE,SR_NUMBER,ORDER_NUMBER,CIRCUIT_ID,SERVICE_NUMBER,DEPOSIT_SLIP_NUMBER,PAYMENT_CURRENCY,ANNOTATION,ACCEPTANCE_STATUS,ORIG_TRACKING_ID_SERV,PAYMENT_CODE,ORIG_TRACKING_ID,INCOMING_TRANSACTION_REF_NO,AMOUNT_IN_INR,RECEIVING_ACC_RBI1,RECEIVER_IFSC,REMITTER_AC_NO,REMITTER_BRANCH,REMITTER_IFSC,REF_NO,PRODUCT_TYPE,PAYMENT_DETAILS_1,PAYMENT_DETAILS_2,PAYMENT_DETAILS_3,FX_VALIDATION_STATUS,TICKET_NO,COL_MANAGER_NAME,TRANSFER_TYPE,BOUNCE_REASON,RECEIPT_DATE,RECORD_ID)"
		    			+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CAD_VENDOR_REC_SEQ.NEXTVAL)";
		    	pstmt = connection.prepareStatement(query);
				for(int i=0;i<bulkDetailsList.size();i++)
				{
				//	logger.info("entered inside");
					BulkDetails bulkDetails=bulkDetailsList.get(i);
		    	//String query= "insert into airtl_epp_vendor_files_records values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			
		  
					if(bulkDetails.getsNo()==null)
						pstmt.setString(1, null);
					else
						pstmt.setInt(1,Integer.parseInt(bulkDetails.getsNo()));

					if(bulkDetails.getFileID()!=null && !bulkDetails.getFileID().isEmpty())
						pstmt.setString(2,bulkDetails.getFileID().trim());
					else
						pstmt.setString(2,bulkDetails.getFileID());
					if(bulkDetails.getCircle()!=null && !bulkDetails.getCircle().isEmpty())
						pstmt.setString(3, bulkDetails.getCircle().trim());
					else
					pstmt.setString(3, bulkDetails.getCircle());
					
					if(bulkDetails.getSourceID()!=null && !bulkDetails.getSourceID().isEmpty())
						pstmt.setString(4,bulkDetails.getSourceID().trim());
					else
						pstmt.setString(4,bulkDetails.getSourceID());
					
					
					
					if(bulkDetails.getVendorTransactID()!=null && !bulkDetails.getVendorTransactID().isEmpty())
						pstmt.setString(5,bulkDetails.getVendorTransactID().trim());
					else
						pstmt.setString(5,bulkDetails.getVendorTransactID());
					
					//pstmt.setString(5, bulkDetails.getVendorTransactID());
					if(bulkDetails.getAcctEXTID()!=null && !bulkDetails.getAcctEXTID().isEmpty())
						pstmt.setString(6,bulkDetails.getAcctEXTID().trim());
					else
						pstmt.setString(6,bulkDetails.getAcctEXTID());
					
					//pstmt.setString(6,bulkDetails.getAcctEXTID());
					
					if(bulkDetails.getDelNO()!=null && !bulkDetails.getDelNO().isEmpty())
						pstmt.setString(7,bulkDetails.getDelNO().trim());
					else
						pstmt.setString(7,bulkDetails.getDelNO());
					
					//pstmt.setString(7,bulkDetails.getDelNO());
					
					if(bulkDetails.getBankVirtualAcctNo()!=null && !bulkDetails.getBankVirtualAcctNo().isEmpty())
						pstmt.setString(8,bulkDetails.getBankVirtualAcctNo().trim());
					else
						pstmt.setString(8,bulkDetails.getBankVirtualAcctNo());
					
					//pstmt.setString(8, bulkDetails.getBankVirtualAcctNo());
					
					if(bulkDetails.getInvoiceNo()!=null && !bulkDetails.getInvoiceNo().isEmpty())
						pstmt.setString(9,bulkDetails.getInvoiceNo().trim());
					else
						pstmt.setString(9,bulkDetails.getInvoiceNo());
					
					//pstmt.setString(9,bulkDetails.getInvoiceNo());
					
					if(bulkDetails.getReceiverName()!=null && !bulkDetails.getReceiverName().isEmpty())
					{
						String receiverName=bulkDetails.getReceiverName().trim();
						receiverName=validateString(receiverName);
						pstmt.setString(10,receiverName);
						//pstmt.setString(10,bulkDetails.getReceiverName().trim());
					}
					else
						pstmt.setString(10,bulkDetails.getReceiverName());
					
					//pstmt.setString(10,bulkDetails.getReceiverName());
					if(bulkDetails.getPaymentAmt()==null)
						pstmt.setString(11, null);
					else
						pstmt.setDouble(11,Double.parseDouble(bulkDetails.getPaymentAmt()));
					
					pstmt.setDate(12, bulkDetails.getPaymentDate());
					
					if(bulkDetails.getPaymentMode()!=null && !bulkDetails.getPaymentMode().isEmpty())
						pstmt.setString(13,bulkDetails.getPaymentMode().trim());
					else
						pstmt.setString(13,bulkDetails.getPaymentMode());
					
					//pstmt.setString(13, bulkDetails.getPaymentMode());
					
					if(bulkDetails.getChequeNo()!=null && !bulkDetails.getChequeNo().isEmpty())
						pstmt.setString(14,bulkDetails.getChequeNo().trim());
					else
						pstmt.setString(14,bulkDetails.getChequeNo());
					
					//pstmt.setString(14, bulkDetails.getChequeNo());


					String bankName=bulkDetails.getBankName();

					if(bankName!=null && !bankName.isEmpty()){

						bankName=bankName.trim();
						if(bankName.length()>20 ){

							bankName=bankName.substring(0, 20);
							pstmt.setString(15,bankName);

						}
						else{
							pstmt.setString(15,bankName);
						}
					}
					else{
						pstmt.setString(15,bulkDetails.getBankName());
					}


					//pstmt.setString(15,bulkDetails.getBankName());
					pstmt.setDate(16,  bulkDetails.getChequeDate());
					
					
					if(bulkDetails.getLockboxID()!=null && !bulkDetails.getLockboxID().isEmpty())
						pstmt.setString(17,bulkDetails.getLockboxID().trim());
					else
						pstmt.setString(17,bulkDetails.getLockboxID());
					
					//pstmt.setString(17,bulkDetails.getLockboxID());
					
					
					if(bulkDetails.getCustomerType()!=null && !bulkDetails.getCustomerType().isEmpty())
						pstmt.setString(18,bulkDetails.getCustomerType().trim());
					else
						pstmt.setString(18,bulkDetails.getCustomerType());
					
					//pstmt.setString(18, bulkDetails.getCustomerType());
					if(bulkDetails.getLoadStatusPayment()==null)
						pstmt.setString(19, null);
					else
						pstmt.setInt(19,Integer.parseInt(bulkDetails.getLoadStatusPayment()));
					
					
					if(bulkDetails.getLoadErrorCode()!=null && !bulkDetails.getLoadErrorCode().isEmpty())
						pstmt.setString(20,bulkDetails.getLoadErrorCode().trim());
					else
						pstmt.setString(20,bulkDetails.getLoadErrorCode());
					
					//pstmt.setString(20,bulkDetails.getLoadErrorCode());
					
					
					if(bulkDetails.getChangeWho()!=null && !bulkDetails.getChangeWho().isEmpty())
						pstmt.setString(21,bulkDetails.getChangeWho().trim());
					else
						pstmt.setString(21,bulkDetails.getChangeWho());
					
					
					//pstmt.setString(21, bulkDetails.getChangeWho());
					/*	    pstmt.setDate(22, bulkDetails.getChangeDate());
				    pstmt.setDate(23, bulkDetails.getInsertDate());*/
					
					
					if(bulkDetails.getRemarks()!=null && !bulkDetails.getRemarks().isEmpty())
						pstmt.setString(22,bulkDetails.getRemarks().trim());
					else
						pstmt.setString(22,bulkDetails.getRemarks());
					
					
					//pstmt.setString(22, bulkDetails.getRemarks());
					

					if(bulkDetails.getIsErrorRecord()!=null && !bulkDetails.getIsErrorRecord().isEmpty())
						pstmt.setString(23,bulkDetails.getIsErrorRecord().trim());
					else
						pstmt.setString(23,bulkDetails.getIsErrorRecord());
					
					//pstmt.setString(23,bulkDetails.getIsErrorRecord());
					
					if(bulkDetails.getErrorReasonCode()!=null && !bulkDetails.getErrorReasonCode().isEmpty())
						pstmt.setString(24,bulkDetails.getErrorReasonCode().trim());
					else
						pstmt.setString(24,bulkDetails.getErrorReasonCode());
					
					//pstmt.setString(24,bulkDetails.getErrorReasonCode());
					
					if(bulkDetails.getServiceType()!=null && !bulkDetails.getServiceType().isEmpty())
						pstmt.setString(25,bulkDetails.getServiceType().trim());
					else
						pstmt.setString(25,bulkDetails.getServiceType());
					
					//pstmt.setString(25,bulkDetails.getServiceType());
					
					
					if(bulkDetails.getReferenceId()!=null && !bulkDetails.getReferenceId().isEmpty())
						pstmt.setString(26,bulkDetails.getReferenceId().trim());
					else
						pstmt.setString(26,bulkDetails.getReferenceId());
					
					//pstmt.setString(26,bulkDetails.getReferenceId());
					
					if(bulkDetails.getIfscCode()!=null && !bulkDetails.getIfscCode().isEmpty())
						pstmt.setString(27,bulkDetails.getIfscCode().trim());
					else
						pstmt.setString(27,bulkDetails.getIfscCode());
					
					//pstmt.setString(27,bulkDetails.getIfscCode());
					
					if(bulkDetails.getRemitterName()!=null && !bulkDetails.getRemitterName().isEmpty())
						
					{
						String remitterName=bulkDetails.getRemitterName().trim();
						remitterName=validateString(remitterName);
						remitterName=remitterName.replace("||", "|");
						pstmt.setString(28,remitterName);
						
					}
					else
						pstmt.setString(28,bulkDetails.getRemitterName());
					
					
					//pstmt.setString(28,bulkDetails.getRemitterName());
					
					if(bulkDetails.getBankGLCode()!=null && !bulkDetails.getBankGLCode().isEmpty())
						pstmt.setString(29,bulkDetails.getBankGLCode().trim());
					else
						pstmt.setString(29,bulkDetails.getBankGLCode());
					
					
					//pstmt.setString(29,bulkDetails.getBankGLCode());
					if(bulkDetails.getExchangeRate()==null)
						pstmt.setString(30,null);
					else
						pstmt.setDouble(30,Double.parseDouble(bulkDetails.getExchangeRate()));
					
					if(bulkDetails.getSRNo()!=null && !bulkDetails.getSRNo().isEmpty())
						pstmt.setString(31,bulkDetails.getSRNo().trim());
					else
						pstmt.setString(31,bulkDetails.getSRNo());
					
					//pstmt.setString(31,bulkDetails.getSRNo());
					if(bulkDetails.getOrderNo()==null)
						pstmt.setString(32,null);
					else
						pstmt.setDouble(32,Double.parseDouble(bulkDetails.getOrderNo()));
					if(bulkDetails.getCircuitId()==null)
						pstmt.setString(33,null);
					else
						pstmt.setDouble(33,Double.parseDouble(bulkDetails.getCircuitId()));
					if(bulkDetails.getServiceNo()==null)
						pstmt.setString(34,null);
					else
						pstmt.setDouble(34,Double.parseDouble(bulkDetails.getServiceNo()));
					
					
					if(bulkDetails.getDepositSlipNo()!=null && !bulkDetails.getDepositSlipNo().isEmpty())
						pstmt.setString(35,bulkDetails.getDepositSlipNo().trim());
					else
						pstmt.setString(35,bulkDetails.getDepositSlipNo());
					
					//pstmt.setString(35,bulkDetails.getDepositSlipNo());
					
					if(bulkDetails.getPaymentCurrency()!=null && !bulkDetails.getPaymentCurrency().isEmpty())
						pstmt.setString(36,bulkDetails.getPaymentCurrency().trim());
					else
						pstmt.setString(36,bulkDetails.getPaymentCurrency());
					
					
					//pstmt.setString(36, bulkDetails.getPaymentCurrency());
					
					if(bulkDetails.getAnnotation()!=null && !bulkDetails.getAnnotation().isEmpty())
					{
						//pstmt.setString(37,bulkDetails.getAnnotation().trim());
						String annotation=bulkDetails.getAnnotation().trim();
						annotation=validateString(annotation);
						pstmt.setString(37,annotation);
					}
					else
						pstmt.setString(37,bulkDetails.getAnnotation());
					
					//pstmt.setString(37, bulkDetails.getAnnotation());
					
					
					if(bulkDetails.getReason()!=null && !bulkDetails.getReason().isEmpty())
						pstmt.setString(38,bulkDetails.getReason().trim());
					else
						pstmt.setString(38,bulkDetails.getReason());
					
					//pstmt.setString(38,bulkDetails.getReason());
					if(bulkDetails.getTrackingIdServ()==null)
						pstmt.setString(39,null);
					else
						pstmt.setLong(39, Long.parseLong(bulkDetails.getTrackingIdServ()));
					if(bulkDetails.getPaymentCode()==null)
						pstmt.setString(40,null);
					else
						pstmt.setLong(40, Long.parseLong(bulkDetails.getPaymentCode()));
					if(bulkDetails.getTrackingId()==null)
						pstmt.setString(41,null);
					else
						pstmt.setLong(41,Long.parseLong(bulkDetails.getTrackingId()));
					
					
					if(bulkDetails.getIncomingTransactionNo()!=null && !bulkDetails.getIncomingTransactionNo().isEmpty())
						pstmt.setString(42,bulkDetails.getIncomingTransactionNo().trim());
					else
						pstmt.setString(42,bulkDetails.getIncomingTransactionNo());
					
					//pstmt.setString(42,bulkDetails.getIncomingTransactionNo());
					if(bulkDetails.getAmountInr()==null)
						pstmt.setString(43,null);
					else
						pstmt.setDouble(43,Double.parseDouble(bulkDetails.getAmountInr()));
					
					
					if(bulkDetails.getAccountNumberRBI1()!=null && !bulkDetails.getAccountNumberRBI1().isEmpty())
						pstmt.setString(44,bulkDetails.getAccountNumberRBI1().trim());
					else
						pstmt.setString(44,bulkDetails.getAccountNumberRBI1());
					
					//pstmt.setString(44,bulkDetails.getAccountNumberRBI1());
					
					if(bulkDetails.getReceiverIfsc()!=null && !bulkDetails.getReceiverIfsc().isEmpty())
						pstmt.setString(45,bulkDetails.getReceiverIfsc().trim());
					else
						pstmt.setString(45,bulkDetails.getReceiverIfsc());
					
				//	pstmt.setString(45,bulkDetails.getReceiverIfsc());
					
					if(bulkDetails.getRemitterAccNo()!=null && !bulkDetails.getRemitterAccNo().isEmpty())
						pstmt.setString(46,bulkDetails.getRemitterAccNo().trim());
					else
						pstmt.setString(46,bulkDetails.getRemitterAccNo());
					
					//pstmt.setString(46,bulkDetails.getRemitterAccNo());

					String bankRemBranch=bulkDetails.getRemitterBranch();
					

					if(bankRemBranch!=null && !bankRemBranch.isEmpty()){

						bankRemBranch=bankRemBranch.replace("\n","");
						bankRemBranch=validateString(bankRemBranch);
						bankRemBranch=bankRemBranch.trim();
						
						if(bankRemBranch.length()>20 ){

							bankRemBranch=bankRemBranch.substring(0, 20);
							bankRemBranch=bankRemBranch.trim();//added on 5thSep
							pstmt.setString(47,bankRemBranch);

						}
						else{
							pstmt.setString(47,bankRemBranch);
						}
					}
					else{
						pstmt.setString(47,bulkDetails.getRemitterBranch());
					}
					
					
					if(bulkDetails.getRemitterIfsc()!=null && !bulkDetails.getRemitterIfsc().isEmpty())
						pstmt.setString(48,bulkDetails.getRemitterIfsc().trim());
					else
						pstmt.setString(48,bulkDetails.getRemitterIfsc());
					
					//pstmt.setString(48,bulkDetails.getRemitterIfsc());
					
					
					if(bulkDetails.getRefNo()!=null && !bulkDetails.getRefNo().isEmpty())
						pstmt.setString(49,bulkDetails.getRefNo().trim());
					else
						pstmt.setString(49,bulkDetails.getRefNo());
					
					//pstmt.setString(49,bulkDetails.getRefNo());
					

					if(bulkDetails.getProductType()!=null && !bulkDetails.getProductType().isEmpty())
						pstmt.setString(50,bulkDetails.getProductType().trim());
					else
						pstmt.setString(50,bulkDetails.getProductType());
					
					
					//pstmt.setString(50,bulkDetails.getProductType());
					
					

					if(bulkDetails.getPaymentDetails1()!=null && !bulkDetails.getPaymentDetails1().isEmpty())
					{
						String paymentDetails1=bulkDetails.getPaymentDetails1().trim();
						paymentDetails1=validateString(paymentDetails1);
						pstmt.setString(51,paymentDetails1);
						
					}
					else
						pstmt.setString(51,bulkDetails.getPaymentDetails1());
					
					//pstmt.setString(51,bulkDetails.getPaymentDetails1());
					
					
					if(bulkDetails.getPaymentDetails2()!=null && !bulkDetails.getPaymentDetails2().isEmpty())
					{
						String paymentDetails2=bulkDetails.getPaymentDetails2().trim();
						paymentDetails2=validateString(paymentDetails2);
						pstmt.setString(52,paymentDetails2);
					}
					else
						pstmt.setString(52,bulkDetails.getPaymentDetails2());
					
					//pstmt.setString(52,bulkDetails.getPaymentDetails2());
					
					if(bulkDetails.getPaymentDetails3()!=null && !bulkDetails.getPaymentDetails3().isEmpty())
					{
						String paymentDetails3=bulkDetails.getPaymentDetails3().trim();
						paymentDetails3=validateString(paymentDetails3);
						pstmt.setString(53,paymentDetails3);
					}
					else
						pstmt.setString(53,bulkDetails.getPaymentDetails3());
					
					//pstmt.setString(53,bulkDetails.getPaymentDetails3());
					
					if(bulkDetails.getFxStatus()!=null && !bulkDetails.getFxStatus().isEmpty())
						pstmt.setString(54,bulkDetails.getFxStatus().trim());
					else
						pstmt.setString(54,bulkDetails.getFxStatus());
					
				//	pstmt.setString(54,bulkDetails.getFxStatus());
					if(bulkDetails.getTicketNo()==null)
						pstmt.setString(55,null);
					else
						pstmt.setLong(55, Long.parseLong(bulkDetails.getTicketNo()));
					

					if(bulkDetails.getCollectionManager()!=null && !bulkDetails.getCollectionManager().isEmpty())
						pstmt.setString(56,bulkDetails.getCollectionManager().trim());
					else
						pstmt.setString(56,bulkDetails.getCollectionManager());
					
				//	pstmt.setString(56, bulkDetails.getCollectionManager());
					
					if(bulkDetails.getTransferType()!=null && !bulkDetails.getTransferType().isEmpty())
						pstmt.setString(57,bulkDetails.getTransferType().trim());
					else
						pstmt.setString(57,bulkDetails.getTransferType());
					
					//pstmt.setString(57, bulkDetails.getTransferType());
					
					if(bulkDetails.getBounceReason()!=null && !bulkDetails.getBounceReason().isEmpty())
						pstmt.setString(58,bulkDetails.getBounceReason().trim());
					else
						pstmt.setString(58,bulkDetails.getBounceReason());
					
					//pstmt.setString(58,bulkDetails.getBounceReason());
					pstmt.setDate(59, bulkDetails.getReceiptDate());
					pstmt.addBatch();
			   // System.out.println("Records inserted into the database:;;;"+bulkDetails.getAcctEXTID());
				}
				 int[]  a=pstmt.executeBatch();
				    b=a.length;
			    logger.info("Records inserted into the database:"+a.length);
			    String chqBounce="{CALL CHQ_BOUNCE_POSTING_STATUS_APS(?)}";
				pschq=connection.prepareCall(chqBounce);
				for(int i=0;i<bulkDetailsList.size();i++)
				{
					//	logger.info("entered inside");
					BulkDetails bulkDetails=bulkDetailsList.get(i);
					pschq.setInt(1, Integer.valueOf(bulkDetails.getFileID()));
					pschq.executeQuery();
				}
		    }
		    catch (SQLException e) {
		    	StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				transactionManager.rollback(transactionStatus);
				return 0;
			} 
		    catch (Exception e) {
				transactionManager.rollback(transactionStatus);
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				return 0;

			}
		    finally
			{
				if(pstmt!=null)
				{
					try {
						pstmt.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
					}
				}
				if(pschq!=null)
				{
					try {
						pschq.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
					}
				}
			}

		return b;
	}

public FileDetails recordCheckxls(FileDetails fileObj,String errorFilesPath,String extension) {

	// CustomerDetails customerObj=new CustomerDetails();

	final String procedureCall = "{call ACE_CAD_BULK_PAYMENT.ace_cad_record_check(?,?,?,?,?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	CallableStatement callableStatement = null;
	String error_code;
	//List recordList=new ArrayList();
	//Writeexcel writeExcel=new Writeexcel();
	int i=1;
	
	BulkDetails recordDetailsObj=new BulkDetails();
	try {
      connection=fileObj.getConnection();
	
      callableStatement = connection
				.prepareCall(procedureCall);

		callableStatement.setString(1, fileObj.getFileID());
		callableStatement.setString(2,fileObj.getVendorType());
		callableStatement.registerOutParameter(3, Types.VARCHAR);
		callableStatement.registerOutParameter(4, Types.VARCHAR);
		callableStatement.registerOutParameter(5, Types.VARCHAR);
	
		callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
	
		callableStatement.executeUpdate();
	
		fileObj.setTrStatus("true");
		fileObj.setErrorMsg(callableStatement.getString(3));
		fileObj.setErrorCode(callableStatement.getString(4));
	
		fileObj.setStatus(callableStatement.getString(5));
		
		resSetBulkdetails = (ResultSet) callableStatement.getObject(6);
		
		logger.info("Status in out paramater....." + fileObj.getStatus());

		if(fileObj.getStatus()!=null){
		
		FileOutputStream fileOut = null;
	
		try {
			fileOut = new FileOutputStream(new File(errorFilesPath+File.separator+fileObj.getOriginalFileName()));
		} catch (FileNotFoundException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet worksheet = workbook.createSheet("Cheque Error Records");
		HSSFRow row1=null;
		row1 = worksheet.createRow(0);
		Cell cellA1 = row1.createCell((short) 0);
		        
				cellA1.setCellValue("Serial No.");
				
				Cell cellC1 = row1.createCell((short) 1);
				cellC1.setCellValue("LOB(MOB/FL/AES/ISTM)");

				Cell cellD1 = row1.createCell((short) 2);
				cellD1.setCellValue("Trans Date(MM/DD/YYYY)");
				//cellStyle = workbook.createCellStyle();
			
				Cell cellE1 = row1.createCell((short) 3);
		           
				cellE1.setCellValue("Payment Mode");
				Cell cellEE1 = row1.createCell((short) 4);
		           
				cellEE1.setCellValue("Deposit Circle");
				
				Cell cellF1 = row1.createCell((short) 5);
				cellF1.setCellValue("Acount No.(External_Account_No)");

				Cell cellG1 = row1.createCell((short) 6);
				cellG1.setCellValue("Mobile / Del no.");

				Cell cellH1 = row1.createCell((short) 7);
				cellH1.setCellValue("Invoice No");

				Cell cellI1 = row1.createCell((short) 8);
		           
				cellI1.setCellValue("Cheque Date(MM/DD/YYYY)");
				
				Cell cellJ1 = row1.createCell((short) 9);
				cellJ1.setCellValue("Cheque No");
				
				Cell cellK1 = row1.createCell((short) 10);
				cellK1.setCellValue("Bank Name");

				Cell cellL1 = row1.createCell((short) 11);
				cellL1.setCellValue("Receipt Amount");
				//cellStyle = workbook.createCellStyle();
			
				Cell cellM1 = row1.createCell((short) 12);
		           
				cellM1.setCellValue("Payment Currency");
				
				Cell cellN1 = row1.createCell((short) 13);
				cellN1.setCellValue("Exchange_rate");
				

				Cell cellO1 = row1.createCell((short) 14);
				cellO1.setCellValue("Bank Branch Name");

				Cell cellP1 = row1.createCell((short) 15);
				cellP1.setCellValue("Bank Account Number");
				//cellStyle = workbook.createCellStyle();
							
				Cell cellQ1 = row1.createCell((short) 16);
		           
				cellQ1.setCellValue("IFSC code");
				
				Cell cellS1 = row1.createCell((short) 17);
				cellS1.setCellValue("Source (Drop Box-id /TID)");

				Cell cellT1 = row1.createCell((short) 18);
				cellT1.setCellValue("Remitter Name");
				//cellStyle = workbook.createCellStyle();
				Cell cellU1 = row1.createCell((short) 19);
		        
				cellU1.setCellValue("Deposit Slip number");
				Cell cellV1 = row1.createCell((short) 20);
		        
				cellV1.setCellValue("Annotation");
				Cell cellW1 = row1.createCell((short) 21);
		        
				cellW1.setCellValue("SR Number");
				Cell cellX1 = row1.createCell((short) 22);
		        
				cellX1.setCellValue("Order number");
			Cell cellAA1 = row1.createCell((short) 23);
		        
				cellAA1.setCellValue("Circuit ID");
			Cell cellAB1 = row1.createCell((short) 24);
		        
				cellAB1.setCellValue("Service Number");
		    Cell cellAD1 = row1.createCell((short) 25);
		        
				cellAD1.setCellValue("Customer name");
				
				Cell cellZ1 = row1.createCell((short) 26);
				cellZ1.setCellValue("Error code description");
				
				if(resSetBulkdetails!=null)
				{
					while (resSetBulkdetails.next()) {
						//logger.info("invoice number is " +resSetBulkdetails.getString("invoice_no"));
						error_code = resSetBulkdetails.getString("error_reason_code");
					
						fileObj.setErrorReasonCode(error_code);
						
						recordDetailsObj.setsNo(resSetBulkdetails.getString(1));
						recordDetailsObj.setFileID(resSetBulkdetails.getString(2));
						recordDetailsObj.setServiceType(resSetBulkdetails.getString(27));
						recordDetailsObj.setAcctEXTID(resSetBulkdetails.getString(6));
						recordDetailsObj.setDelNO(resSetBulkdetails.getString(7));
						recordDetailsObj.setInvoiceNo(resSetBulkdetails.getString(9));
						recordDetailsObj.setPaymentMode(resSetBulkdetails.getString(13));
						recordDetailsObj.setChequeNo(resSetBulkdetails.getString(14));
						recordDetailsObj.setBankName(resSetBulkdetails.getString(49));
						recordDetailsObj.setPaymentAmt(resSetBulkdetails.getString(11));
						
						recordDetailsObj.setRemitterName(resSetBulkdetails.getString(30));
						
						recordDetailsObj.setLockboxID(resSetBulkdetails.getString(17));
                       	if(resSetBulkdetails.getString(16)!=null)
						recordDetailsObj.setChequeDate(resSetBulkdetails.getDate(16));
                      	else
							recordDetailsObj.setChequeDate(null);
						if(resSetBulkdetails.getString(12)!=null)
						recordDetailsObj.setPaymentDate(resSetBulkdetails.getDate(12));
                       	else
					    	recordDetailsObj.setPaymentDate(null);
						recordDetailsObj.setInsertDate(resSetBulkdetails.getDate(23));
						recordDetailsObj.setIfscCode(resSetBulkdetails.getString(50));
						
						recordDetailsObj.setAnnotation(resSetBulkdetails.getString(39));
						
						recordDetailsObj.setBankGLCode(resSetBulkdetails.getString(31));
						recordDetailsObj.setExchangeRate(resSetBulkdetails.getString(32));
						recordDetailsObj.setSRNo(resSetBulkdetails.getString(33));
						recordDetailsObj.setOrderNo(resSetBulkdetails.getString(34));
						
						recordDetailsObj.setCircuitId(resSetBulkdetails.getString(35));
						recordDetailsObj.setServiceNo(resSetBulkdetails.getString(36));
					//	recordDetailsObj.setInsertDate(resSetBulkdetails.getString(24));
						recordDetailsObj.setCustomerName(resSetBulkdetails.getString(10));
						recordDetailsObj.setDepositSlipNo(resSetBulkdetails.getString(37));
						recordDetailsObj.setRemarks(resSetBulkdetails.getString(24));
						recordDetailsObj.setIsErrorRecord(resSetBulkdetails.getString(25));
						recordDetailsObj.setErrorReasonCode(resSetBulkdetails.getString(26));
						//recordDetailsObj.setErrorCodeDescription(resSetBulkdetails.getString(38));
						
						recordDetailsObj.setPaymentCurrency(resSetBulkdetails.getString(38));
						recordDetailsObj.setCircle(resSetBulkdetails.getString(3));
					    recordDetailsObj.setBankBranchName(resSetBulkdetails.getString(54));
						recordDetailsObj.setBankVirtualAcctNo(resSetBulkdetails.getString(8));
				
							 row1 = worksheet.createRow(i);
						 
							Cell cellA2 = row1.createCell((short) 0);
			               
							cellA2.setCellValue(recordDetailsObj.getsNo());
						
							Cell cellC2 = row1.createCell((short) 1);
							cellC2.setCellValue(recordDetailsObj.getServiceType());

							Cell cellD2 = row1.createCell((short) 2);
							CellStyle cellStyle = workbook.createCellStyle();
							CreationHelper createHelper = workbook.getCreationHelper();
							cellStyle.setDataFormat(
							    createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
                            if(resSetBulkdetails.getString(12)!=null)
							cellD2.setCellValue(recordDetailsObj.getPaymentDate());
							cellD2.setCellStyle(cellStyle);
							worksheet.autoSizeColumn(2);
				
							Cell cellE2 = row1.createCell((short) 3);
						
							cellE2.setCellValue(recordDetailsObj.getPaymentMode());
							Cell cellE41 = row1.createCell((short) 4);
					           
							cellE41.setCellValue(recordDetailsObj.getCircle());
							
							Cell cellF2 = row1.createCell((short) 5);
							cellF2.setCellValue(recordDetailsObj.getAcctEXTID());
							
							
							Cell cellG2 = row1.createCell((short) 6);
							cellG2.setCellValue(recordDetailsObj.getDelNO());
							

							Cell cellH2 = row1.createCell((short) 7);
							cellH2.setCellValue(recordDetailsObj.getInvoiceNo());
							
							
																	
							Cell cellI2 = row1.createCell((short) 8);
							cellStyle.setDataFormat(
								    createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
                           	if(resSetBulkdetails.getString(16)!=null)
							cellI2.setCellValue(recordDetailsObj.getChequeDate());
							cellI2.setCellStyle(cellStyle);
							worksheet.autoSizeColumn(8);
							
				             Cell cellJ2 = row1.createCell((short) 9);
				             cellJ2.setCellValue(recordDetailsObj.getChequeNo());
							
							
							Cell cellK2 = row1.createCell((short) 10);
							cellK2.setCellValue(recordDetailsObj.getBankName());
							

							Cell cellL2 = row1.createCell((short) 11);
							cellL2.setCellValue(recordDetailsObj.getPaymentAmt());
							
												
							Cell cellM2 = row1.createCell((short) 12);
							cellM2.setCellValue(recordDetailsObj.getPaymentCurrency());
				               
							
							
							Cell cellN2 = row1.createCell((short) 13);
							cellN2.setCellValue(recordDetailsObj.getExchangeRate());
							
							Cell cellO2 = row1.createCell((short) 14);
							cellO2.setCellValue(recordDetailsObj.getBankBranchName());
							Cell cellOP2 = row1.createCell((short) 15);
							cellOP2.setCellValue(recordDetailsObj.getBankVirtualAcctNo());

							Cell cellP2 = row1.createCell((short) 16);
							cellP2.setCellValue(recordDetailsObj.getIfscCode());
							
							Cell cellQ2 = row1.createCell((short) 17);
							cellQ2.setCellValue(recordDetailsObj.getLockboxID());
				               
							Cell cellR2 = row1.createCell((short) 18);
							cellR2.setCellValue(recordDetailsObj.getRemitterName());
							
							Cell cellS2 = row1.createCell((short) 19);
							cellS2.setCellValue(recordDetailsObj.getDepositSlipNo());

							Cell cellT2 = row1.createCell((short) 20);
							cellT2.setCellValue(recordDetailsObj.getAnnotation());
						
						
							Cell cellU2 = row1.createCell((short) 21);
				               
							cellU2.setCellValue(recordDetailsObj.getSRNo());
							
							Cell cellV2 = row1.createCell((short) 22);
							cellV2.setCellValue(recordDetailsObj.getOrderNo());
					
							Cell cellW2 = row1.createCell((short) 23);
							cellW2.setCellValue(recordDetailsObj.getCircuitId());
							Cell cellX2 = row1.createCell((short) 24);
							cellX2.setCellValue(recordDetailsObj.getServiceNo());
							/*Cell cellY2 = row1.createCell((short) 24);
							cellY2.setCellValue(recordDetailsObj.getIsErrorRecord());*/
							Cell cellZ2 = row1.createCell((short) 25);
							cellZ2.setCellValue(recordDetailsObj.getCustomerName());
							Cell cellAA2 = row1.createCell((short) 26);
							cellAA2.setCellValue(recordDetailsObj.getErrorReasonCode());
							
							 i++;
					//		 System.out.println("i value is"+i);
					
				
				} 
					}
			try {
			workbook.write(fileOut);
			fileOut.flush();
			fileOut.close();
		} catch (IOException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}

		
	}} catch (SQLException e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	//	transactionManager.rollback(fileObj.getTransaction());
		fileObj.setTrStatus("false");

	}
	catch(Exception e)
	{
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	//	transactionManager.rollback(fileObj.getTransaction());
		fileObj.setTrStatus("false");
	}
	finally
	{
		if(callableStatement!=null)
		{
			try {
				callableStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}

		if(resSetBulkdetails!=null)
		{
	try {
		resSetBulkdetails.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	}
	final long duration = System.nanoTime() - startTime;
	//logger.info("total time of execution is" +duration);
	return fileObj;
}	
public FileDetails recordCheckxlsx(FileDetails fileObj,String errorFilesPath,String extension) {

	
	final String procedureCall = "{call ACE_CAD_BULK_PAYMENT.ace_cad_record_check(?,?,?,?,?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	String error_code;
	CallableStatement callableStatement=null;
	int i=1;
	
	BulkDetails recordDetailsObj=new BulkDetails();
	try {
      connection=fileObj.getConnection();
	
	 callableStatement = connection
				.prepareCall(procedureCall);

		callableStatement.setString(1, fileObj.getFileID());
		callableStatement.setString(2,fileObj.getVendorType());
		callableStatement.registerOutParameter(3, Types.VARCHAR);
		callableStatement.registerOutParameter(4, Types.VARCHAR);
		callableStatement.registerOutParameter(5, Types.VARCHAR);
	
		callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
	
		callableStatement.executeUpdate();
	
		fileObj.setTrStatus("true");
		fileObj.setErrorMsg(callableStatement.getString(3));
		fileObj.setErrorCode(callableStatement.getString(4));

		fileObj.setStatus(callableStatement.getString(5));
		
		resSetBulkdetails = (ResultSet) callableStatement.getObject(6);
	

		logger.info("flag is........ " + fileObj.getFlag());
	
		logger.info("Status in out paramater....." + fileObj.getStatus());
if(fileObj.getStatus()!=null){
	
		FileOutputStream fileOut = null;
	
		try {
			fileOut = new FileOutputStream(errorFilesPath+File.separator+fileObj.getOriginalFileName());
		} catch (FileNotFoundException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		Workbook workbook = new XSSFWorkbook();
		
	   org.apache.poi.ss.usermodel.Sheet worksheet = workbook.createSheet("Cheque Error Records");
		Row row1=null;
		row1 = worksheet.createRow(0);
		Cell cellA1 = row1.createCell((short) 0);
        
		cellA1.setCellValue("Serial No.");
		


		Cell cellC1 = row1.createCell((short) 1);
		cellC1.setCellValue("LOB(MOB/FL/AES/ISTM)");

		Cell cellD1 = row1.createCell((short) 2);
		cellD1.setCellValue("Trans Date(MM/DD/YYYY)");
		//cellStyle = workbook.createCellStyle();
	
		Cell cellE1 = row1.createCell((short) 3);
           
		cellE1.setCellValue("Payment Mode");
		Cell cellEE1 = row1.createCell((short) 4);
           
		cellEE1.setCellValue("Deposit Circle");
		
		

		Cell cellF1 = row1.createCell((short) 5);
		cellF1.setCellValue("Acount No.(External_Account_No)");

		Cell cellG1 = row1.createCell((short) 6);
		cellG1.setCellValue("Mobile / Del no.");

		Cell cellH1 = row1.createCell((short) 7);
		cellH1.setCellValue("Invoice No");

		
		Cell cellI1 = row1.createCell((short) 8);
           
		cellI1.setCellValue("Cheque Date");
		

		Cell cellJ1 = row1.createCell((short) 9);
		cellJ1.setCellValue("Cheque No");
		
		Cell cellK1 = row1.createCell((short) 10);
		cellK1.setCellValue("Bank Name");

		Cell cellL1 = row1.createCell((short) 11);
		cellL1.setCellValue("Receipt Amount");
		//cellStyle = workbook.createCellStyle();
		
		
		Cell cellM1 = row1.createCell((short) 12);
           
		cellM1.setCellValue("Payment Currency");
		

		Cell cellN1 = row1.createCell((short) 13);
		cellN1.setCellValue("Exchange_rate");
		

		Cell cellO1 = row1.createCell((short) 14);
		cellO1.setCellValue("Bank Branch Name");

		Cell cellP1 = row1.createCell((short) 15);
		cellP1.setCellValue("Bank Account Number");
		//cellStyle = workbook.createCellStyle();
		
		
		Cell cellQ1 = row1.createCell((short) 16);
           
		cellQ1.setCellValue("IFSC code");
		

		
		Cell cellS1 = row1.createCell((short) 17);
		cellS1.setCellValue("Source (Drop Box-id /TID)");

		Cell cellT1 = row1.createCell((short) 18);
		cellT1.setCellValue("Remitter Name");
		//cellStyle = workbook.createCellStyle();
		Cell cellU1 = row1.createCell((short) 19);
        
		cellU1.setCellValue("Deposit Slip number");
		Cell cellV1 = row1.createCell((short) 20);
        
		cellV1.setCellValue("Annotation");
		Cell cellW1 = row1.createCell((short) 21);
        
		cellW1.setCellValue("SR Number");
		Cell cellX1 = row1.createCell((short) 22);
        
		cellX1.setCellValue("Order number");
	Cell cellAA1 = row1.createCell((short) 23);
        
		cellAA1.setCellValue("Circuit ID");
	Cell cellAB1 = row1.createCell((short) 24);
        
		cellAB1.setCellValue("Service Number");
		Cell cellAD1 = row1.createCell((short) 25);
        
		cellAD1.setCellValue("Customer name");
		
		
		Cell cellZ1 = row1.createCell((short) 26);
		cellZ1.setCellValue("Error code description");

				if(resSetBulkdetails!=null)
				{
					while (resSetBulkdetails.next()) {
						//logger.info("invoice number is " +resSetBulkdetails.getString("invoice_no"));
						error_code = resSetBulkdetails.getString("error_reason_code");
					
						fileObj.setErrorReasonCode(error_code);
						
						recordDetailsObj.setsNo(resSetBulkdetails.getString(1));
						recordDetailsObj.setFileID(resSetBulkdetails.getString(2));
						recordDetailsObj.setServiceType(resSetBulkdetails.getString(27));
						recordDetailsObj.setAcctEXTID(resSetBulkdetails.getString(6));
						recordDetailsObj.setDelNO(resSetBulkdetails.getString(7));
						recordDetailsObj.setInvoiceNo(resSetBulkdetails.getString(9));
						recordDetailsObj.setPaymentMode(resSetBulkdetails.getString(13));
						recordDetailsObj.setChequeNo(resSetBulkdetails.getString(14));
						recordDetailsObj.setBankName(resSetBulkdetails.getString(49));
						recordDetailsObj.setPaymentAmt(resSetBulkdetails.getString(11));
						
						recordDetailsObj.setRemitterName(resSetBulkdetails.getString(30));
						
						recordDetailsObj.setLockboxID(resSetBulkdetails.getString(17));
						recordDetailsObj.setChequeDate(resSetBulkdetails.getDate(16));
						recordDetailsObj.setPaymentDate(resSetBulkdetails.getDate(12));
						recordDetailsObj.setInsertDate(resSetBulkdetails.getDate(23));
						recordDetailsObj.setIfscCode(resSetBulkdetails.getString(50));
						
						recordDetailsObj.setAnnotation(resSetBulkdetails.getString(39));
						
						recordDetailsObj.setBankGLCode(resSetBulkdetails.getString(31));
						recordDetailsObj.setExchangeRate(resSetBulkdetails.getString(32));
						recordDetailsObj.setSRNo(resSetBulkdetails.getString(33));
						recordDetailsObj.setOrderNo(resSetBulkdetails.getString(34));
						
						recordDetailsObj.setCircuitId(resSetBulkdetails.getString(35));
						recordDetailsObj.setServiceNo(resSetBulkdetails.getString(36));
					//	recordDetailsObj.setInsertDate(resSetBulkdetails.getString(24));
						recordDetailsObj.setCustomerName(resSetBulkdetails.getString(10));
						recordDetailsObj.setDepositSlipNo(resSetBulkdetails.getString(37));
						recordDetailsObj.setRemarks(resSetBulkdetails.getString(24));
						recordDetailsObj.setIsErrorRecord(resSetBulkdetails.getString(25));
						recordDetailsObj.setErrorReasonCode(resSetBulkdetails.getString(26));
						//recordDetailsObj.setErrorCodeDescription(resSetBulkdetails.getString(38));
						
						recordDetailsObj.setPaymentCurrency(resSetBulkdetails.getString(38));
						recordDetailsObj.setCircle(resSetBulkdetails.getString(3));
						recordDetailsObj.setBankBranchName(resSetBulkdetails.getString(54));
						recordDetailsObj.setBankVirtualAcctNo(resSetBulkdetails.getString(8));
				
							 row1 = worksheet.createRow(i);
							 
								Cell cellA2 = row1.createCell((short) 0);
					               
								cellA2.setCellValue(recordDetailsObj.getsNo());
								
								Cell cellC2 = row1.createCell((short) 1);
								
								cellC2.setCellValue(recordDetailsObj.getServiceType());

								Cell cellD2 = row1.createCell((short) 2);
								CellStyle cellStyle = workbook.createCellStyle();
								CreationHelper createHelper = workbook.getCreationHelper();
								cellStyle.setDataFormat(
									    createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
                               	if(resSetBulkdetails.getString(12)!=null)
								cellD2.setCellValue(recordDetailsObj.getPaymentDate());
								cellD2.setCellStyle(cellStyle);
								worksheet.autoSizeColumn(2);
					
								Cell cellE2 = row1.createCell((short) 3);
							
								cellE2.setCellValue(recordDetailsObj.getPaymentMode());
								Cell cellE41 = row1.createCell((short) 4);
						           
								cellE41.setCellValue(recordDetailsObj.getCircle());
								
								Cell cellF2 = row1.createCell((short) 5);
								cellF2.setCellValue(recordDetailsObj.getAcctEXTID());
								
								
								Cell cellG2 = row1.createCell((short) 6);
								cellG2.setCellValue(recordDetailsObj.getDelNO());
								

								Cell cellH2 = row1.createCell((short) 7);
								cellH2.setCellValue(recordDetailsObj.getInvoiceNo());
								
								cellStyle.setDataFormat(
								    createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
							
											
								Cell cellI2 = row1.createCell((short) 8);
                                if(resSetBulkdetails.getString(16)!=null)
								cellI2.setCellValue(recordDetailsObj.getChequeDate());
								cellI2.setCellStyle(cellStyle);
								worksheet.autoSizeColumn(8);
					             
								
					             Cell cellJ2 = row1.createCell((short) 9);
					             cellJ2.setCellValue(recordDetailsObj.getChequeNo());
								
								
								Cell cellK2 = row1.createCell((short) 10);
								cellK2.setCellValue(recordDetailsObj.getBankName());
								

								Cell cellL2 = row1.createCell((short) 11);
								cellL2.setCellValue(recordDetailsObj.getPaymentAmt());
								
													
								Cell cellM2 = row1.createCell((short) 12);
								cellM2.setCellValue(recordDetailsObj.getPaymentCurrency());
					               
								
								
								Cell cellN2 = row1.createCell((short) 13);
								cellN2.setCellValue(recordDetailsObj.getExchangeRate());
								
								Cell cellO2 = row1.createCell((short) 14);
								cellO2.setCellValue(recordDetailsObj.getBankBranchName());
								Cell cellOP2 = row1.createCell((short) 15);
								cellOP2.setCellValue(recordDetailsObj.getBankVirtualAcctNo());

								Cell cellP2 = row1.createCell((short) 16);
								cellP2.setCellValue(recordDetailsObj.getIfscCode());
								
								Cell cellQ2 = row1.createCell((short) 17);
								cellQ2.setCellValue(recordDetailsObj.getLockboxID());
					               
								Cell cellR2 = row1.createCell((short) 18);
								cellR2.setCellValue(recordDetailsObj.getRemitterName());
								
								Cell cellS2 = row1.createCell((short) 19);
								cellS2.setCellValue(recordDetailsObj.getDepositSlipNo());

								Cell cellT2 = row1.createCell((short) 20);
								cellT2.setCellValue(recordDetailsObj.getAnnotation());
							
							
								Cell cellU2 = row1.createCell((short) 21);
					               
								cellU2.setCellValue(recordDetailsObj.getSRNo());
								
								Cell cellV2 = row1.createCell((short) 22);
								cellV2.setCellValue(recordDetailsObj.getOrderNo());
						
								Cell cellW2 = row1.createCell((short) 23);
								cellW2.setCellValue(recordDetailsObj.getCircuitId());
								Cell cellX2 = row1.createCell((short) 24);
								cellX2.setCellValue(recordDetailsObj.getServiceNo());
								/*Cell cellY2 = row1.createCell((short) 24);
								cellY2.setCellValue(recordDetailsObj.getIsErrorRecord());*/
								Cell cellZ2 = row1.createCell((short) 25);
								cellZ2.setCellValue(recordDetailsObj.getCustomerName());
								Cell cellAA2 = row1.createCell((short) 26);
								cellAA2.setCellValue(recordDetailsObj.getErrorReasonCode());
								
								 
							 i++;
							
				
				} 
				}
			try {
			workbook.write(fileOut);
			fileOut.flush();
			fileOut.close();
		} catch (IOException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}

		
	} }catch (SQLException e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	//	transactionManager.rollback(fileObj.getTransaction());
		fileObj.setTrStatus("false");

	}
	catch(Exception e)
	{
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	//	transactionManager.rollback(fileObj.getTransaction());
		fileObj.setTrStatus("false");
	} 
	finally
	{
		if(callableStatement!=null)
		{
			try {
				callableStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}

		if(resSetBulkdetails!=null)
		{
	try {
		resSetBulkdetails.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	}
	final long duration = System.nanoTime() - startTime;
	//logger.info("total time of execution is" +duration);
	return fileObj;
}
	
@Override
public List<FileDetails> retreiveDetailsForSpocbasedOnSearch(String fileId,
		String date,String useriD,String role) {
	
	
	final String procedureCall = "{call AIRTL_PAYMENT_APPROVE_PKG.AIRTL_PAYMENT_FILE_DATE(?,?,?,?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	CallableStatement callableStatement=null;
	List<FileDetails> SpocFileList=new ArrayList<FileDetails>();

	try {

		// Get Connection instance from dataSource
		//logger.info("connect"+ "ion:" + dataSource.getConnection());
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
	//	logger.info("enterd into vendor insert");
		//logger.info("date in dao"+date);
	 callableStatement = connection
				.prepareCall(procedureCall);
		//System.out.println("spoc id"+fileObj.getVendorID());
		callableStatement.setString(1, useriD);
		callableStatement.setString(2, role);
		callableStatement.setString(3, fileId);
		callableStatement.setString(4,  date);
		
		logger.info(" User Id : "+useriD+", Role : "+role+", fileId : "+fileId+", date :"+date);
		
		//callableStatement.registerOutParameter(5,OracleTypes.INTEGER);
		callableStatement.registerOutParameter(5,OracleTypes.CURSOR);
		callableStatement.executeUpdate();
		
		//System.out.println("resSetBulkdetails size "+callableStatement.getInt(5));
		
		resSetBulkdetails = (ResultSet) callableStatement.getObject(5);
		
		
		
		if(resSetBulkdetails==null)
		{
			logger.info("resultset is null");
			return SpocFileList;
		}
		
		//System.out.println("filename resultset"+resSetBulkdetails.getString("FILE_NAME"));
		
		while (resSetBulkdetails.next()) {
			FileDetails spocDetails=new FileDetails();
			
			spocDetails.setOriginalFileName(resSetBulkdetails.getString("FILE_NAME"));
			spocDetails.setFileID(resSetBulkdetails.getString("FILE_ID"));
			spocDetails.setPaymentAmount(resSetBulkdetails.getString("TOTAL_AMOUNT"));
			spocDetails.setTotalRecords(resSetBulkdetails.getInt("TOTAL_RECORDS"));
			spocDetails.setCountServiceMO(resSetBulkdetails.getInt("MBL_COUNT"));
			spocDetails.setCountServiceFL(resSetBulkdetails.getInt("FL_COUNT"));
			spocDetails.setCountServiceAES(resSetBulkdetails.getInt("AES_COUNT"));
			spocDetails.setCountServiceISTM(resSetBulkdetails.getInt("ISTM_COUNT"));
			SpocFileList.add(spocDetails);
			
		}
	}
    catch (SQLException e) {
    	StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);

	} finally {
		if (connection != null)
			try {
				connection.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		if(callableStatement!=null)
		{
			try {
				callableStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}

		if(resSetBulkdetails!=null)
		{
	try {
		resSetBulkdetails.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	}

	
	return SpocFileList;
	
}

public List<FileDetails> retreiveDetailsForSpoc(String useriD,String role) {
	
	
	final String procedureCall = "{call AIRTL_PAYMENT_APPROVE_PKG.AIRTL_PAYMENT_APPROVE(?,?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	
	List<FileDetails> SpocFileList=new ArrayList<FileDetails>();
CallableStatement callableStatement=null;
	try {

		// Get Connection instance from dataSource
	//	logger.info("connect"+ "ion:" + dataSource.getConnection());
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
	//	System.out.println("enterd into vendor insert");
		
	 callableStatement = connection
				.prepareCall(procedureCall);
		//System.out.println("spoc id"+fileObj.getVendorID());
		callableStatement.setString(1, useriD);
		callableStatement.setString(2,role);
		callableStatement.registerOutParameter(3,OracleTypes.CURSOR);
		
		callableStatement.executeUpdate();
		
		resSetBulkdetails = (ResultSet) callableStatement.getObject(3);
		//System.out.println(" status is "+callableStatement.getString(3));
		if(resSetBulkdetails==null)
		{
			logger.info("resultset is null");
			return SpocFileList;
		}
		//logger.info("filename resultset"+resSetBulkdetails.getString("FILE_NAME"));
		while (resSetBulkdetails.next()) {
			
			FileDetails spocDetails=new FileDetails();
			
			spocDetails.setOriginalFileName(resSetBulkdetails.getString("FILE_NAME"));
			spocDetails.setFileID(resSetBulkdetails.getString("FILE_ID"));
			spocDetails.setPaymentAmount(resSetBulkdetails.getString("TOTAL_AMOUNT"));
			spocDetails.setTotalRecords(resSetBulkdetails.getInt("TOTAL_RECORDS"));
			spocDetails.setCountServiceMO(resSetBulkdetails.getInt("MBL_COUNT"));
			spocDetails.setCountServiceFL(resSetBulkdetails.getInt("FL_COUNT"));
			spocDetails.setCountServiceAES(resSetBulkdetails.getInt("AES_COUNT"));
			spocDetails.setCountServiceISTM(resSetBulkdetails.getInt("ISTM_COUNT"));
			SpocFileList.add(spocDetails);
			

		}
		
		
	
	}
    catch (SQLException e) {
    	StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);

	} finally {

		if (connection != null)
			try {
				connection.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		if(callableStatement!=null)
		{
			try {
				callableStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}

		if(resSetBulkdetails!=null)
		{
	try {
		resSetBulkdetails.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	}

	
	return SpocFileList;
	
}
public String rejectRequest(List<String> fileIdsList,String rejectComments,String userId)
{
	final String procedureCall = "{call POSTING_PAYMENT_REJECTION(?,?,?,?,?)}";
	Connection connection = null;
	TransactionDefinition def = new DefaultTransactionDefinition();
    TransactionStatus status = transactionManager.getTransaction(def);
    String approvestatus=null;
    CallableStatement callableStatement=null;
   
	try {

		// Get Connection instance from dataSource
	//	logger.info("connect"+ "ion:" + dataSource.getConnection());
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
		connection.setAutoCommit(false);
		
		
		ArrayDescriptor des = ArrayDescriptor.createDescriptor("ARRAY_FILEID_TABLE", connection); 
		Object[] array=fileIdsList.toArray();
        
         ARRAY array_to_pass = new ARRAY(des,connection,array);
          callableStatement = connection
 				.prepareCall(procedureCall);
        
     
        
         callableStatement.setArray(1, array_to_pass);
         
         callableStatement.setString(2,rejectComments);
         callableStatement.setString(3, userId);
         callableStatement.registerOutParameter(4, Types.VARCHAR);
         callableStatement.registerOutParameter(5, Types.VARCHAR);
         callableStatement.executeUpdate();
         logger.info("error msg"+callableStatement.getString(5));
         approvestatus=callableStatement.getString(5); 
        
        
         transactionManager.commit(status);
         connection.commit();
	}
	catch (SQLException e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		
		transactionManager.rollback(status);
      // return approvestatus;
	} 
	catch (Exception e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		
		transactionManager.rollback(status);
     //  return "false";
	}finally {

		if (connection != null)
			try {
				connection.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		if(callableStatement!=null)
		{
			try {
				callableStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}
	}

	return approvestatus;

}


@Override
public Map<Map<Integer, List<String>>, List<FileDetails>> retreiveDetailsForSpocp(
		int page, String userId, String role) {


	final String procedureCall = "{call AIRTL_PAYMENT_APPROVE_PKG.AIRTL_PAYMENT_APPROVE(?,?,?,?,?,?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	List<String> errorDetails=new ArrayList<String>();
	Map<Integer,List<String>> totaPagesAndErrorMap=new HashMap<Integer,List<String>>();
	List<FileDetails> fileList=new ArrayList<FileDetails>();
	CallableStatement callableStatement=null;
	Map<Map<Integer,List<String>>, List<FileDetails>> fileDetailsList=new HashMap<Map<Integer,List<String>>, List<FileDetails>>();
	
	try {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
		
		 callableStatement = connection
				.prepareCall(procedureCall);
		callableStatement.setInt(1,page);
		callableStatement.setString(2,userId);
		callableStatement.setString(3, role);
		
		callableStatement.registerOutParameter(4,OracleTypes.NUMBER);
		callableStatement.registerOutParameter(5,OracleTypes.VARCHAR);
		callableStatement.registerOutParameter(6,OracleTypes.VARCHAR);
		callableStatement.registerOutParameter(7,OracleTypes.CURSOR);
	
		callableStatement.executeUpdate();
		
		int totalPages=callableStatement.getInt(4);
		String errorCode=callableStatement.getString(5);
		String errorMessage=callableStatement.getString(6);
		errorDetails.add(errorCode);
		errorDetails.add(errorMessage);
		totaPagesAndErrorMap.put(totalPages, errorDetails);
		
		resSetBulkdetails = (ResultSet) callableStatement.getObject(7);
	
		
		while (resSetBulkdetails!=null&&resSetBulkdetails.next()) {
			
			FileDetails spocDetails=new FileDetails();
			
			spocDetails.setOriginalFileName(resSetBulkdetails.getString("FILE_NAME"));
			spocDetails.setFinalFileName(resSetBulkdetails.getString("FINAL_FILE_NAME"));
			spocDetails.setFileID(resSetBulkdetails.getString("FILE_ID"));
			spocDetails.setPaymentAmount(resSetBulkdetails.getString("TOTAL_AMOUNT"));
			spocDetails.setTotalRecords(resSetBulkdetails.getInt("TOTAL_RECORDS"));
			spocDetails.setCountServiceMO(resSetBulkdetails.getInt("MBL_COUNT"));
			spocDetails.setCountServiceFL(resSetBulkdetails.getInt("FL_COUNT"));
			spocDetails.setCountServiceAES(resSetBulkdetails.getInt("AES_COUNT"));
			spocDetails.setCountServiceISTM(resSetBulkdetails.getInt("ISTM_COUNT"));
			spocDetails.setFileUploadDate(resSetBulkdetails.getString("FILE_UPLOAD_DATE"));
			fileList.add(spocDetails);
		
		
		}
		fileDetailsList.put(totaPagesAndErrorMap, fileList);
	}
    catch (SQLException e) {
    	StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);

	} finally {

		if (connection != null)
			try {
				connection.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		if (callableStatement != null)
			try {
				callableStatement.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}

		if(resSetBulkdetails!=null)
		{
	try {
		resSetBulkdetails.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
		
	}

	return fileDetailsList;
	
}
@Override
public Map<Map<Integer, List<String>>, List<FileDetails>> retreiveDetailsForSpocbasedOnSearch(
		int page, String fileId, String activeDate, String endDate, String userId, String role,String paymentMode,String UserId) {

	
	final String procedureCall = "{call AIRTL_PAYMENT_APPROVE_PKG.AIRTL_PAYMENT_FILE_DATE(?,?,?,?,?,?,?,?,?,?,?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	List<String> errorDetails=new ArrayList<String>();
	Map<Integer,List<String>> totaPagesAndErrorMap=new HashMap<Integer,List<String>>();
	List<FileDetails> fileList=new ArrayList<FileDetails>();
	CallableStatement callableStatement=null;
	Map<Map<Integer,List<String>>, List<FileDetails>> fileDetailsList=new HashMap<Map<Integer,List<String>>, List<FileDetails>>();
	
	try {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
		
		 callableStatement = connection
				.prepareCall(procedureCall);
		callableStatement.setInt(1,page);
		callableStatement.setString(5,userId);
		callableStatement.setString(6, UserId);
		callableStatement.setString(7, role);
		callableStatement.setString(8,fileId);
		callableStatement.setString(9, paymentMode);
		callableStatement.setString(10, activeDate);
		callableStatement.setString(11, endDate);
		
		callableStatement.registerOutParameter(2,OracleTypes.NUMBER);
		callableStatement.registerOutParameter(3,OracleTypes.VARCHAR);
		callableStatement.registerOutParameter(4,OracleTypes.VARCHAR);
		callableStatement.registerOutParameter(12,OracleTypes.CURSOR);
	
		callableStatement.executeUpdate();
		
		int totalPages=callableStatement.getInt(2);
		String errorCode=callableStatement.getString(3);
		String errorMessage=callableStatement.getString(4);
		errorDetails.add(errorCode);
		errorDetails.add(errorMessage);
		totaPagesAndErrorMap.put(totalPages, errorDetails);
		
		resSetBulkdetails = (ResultSet) callableStatement.getObject(12);
	
		
		while (resSetBulkdetails!=null&&resSetBulkdetails.next()) {
			
			FileDetails spocDetails=new FileDetails();
			
			spocDetails.setOriginalFileName(resSetBulkdetails.getString("FILE_NAME"));
			spocDetails.setFinalFileName(resSetBulkdetails.getString("FINAL_FILE_NAME"));
			spocDetails.setFileID(resSetBulkdetails.getString("FILE_ID"));
			spocDetails.setPaymentAmount(resSetBulkdetails.getString("TOTAL_AMOUNT"));
			spocDetails.setTotalRecords(resSetBulkdetails.getInt("TOTAL_RECORDS"));
			spocDetails.setCountServiceMO(resSetBulkdetails.getInt("MBL_COUNT"));
			spocDetails.setCountServiceFL(resSetBulkdetails.getInt("FL_COUNT"));
			spocDetails.setCountServiceAES(resSetBulkdetails.getInt("AES_COUNT"));
			spocDetails.setCountServiceISTM(resSetBulkdetails.getInt("ISTM_COUNT"));
			//String date=resSetBulkdetails.getString("FILE_UPLOAD_DATE");
			//SimpleDateFormat dateString= new SimpleDateFormat("");
			String date=resSetBulkdetails.getString("FILE_UPLOAD_DATE");
			SimpleDateFormat dateString= new SimpleDateFormat("yyyy-MM-dd HH:mm:SS");
			SimpleDateFormat dateString1= new SimpleDateFormat("MM/dd/yyyy HH:mm:SS");
			String finalDate=dateString1.format(dateString.parse(date));
			spocDetails.setFileUploadDate(finalDate);
			spocDetails.setVendorUserId(resSetBulkdetails.getString("VENDOR_USERID"));
			spocDetails.setPaymentMode(resSetBulkdetails.getString("PAYMENT_MODE"));
			spocDetails.setUserName(resSetBulkdetails.getString("USER_NAME"));
			//spocDetails.setPaymentMode(resSetBulkdetails.getString("PAYMENT_MODE"));
			fileList.add(spocDetails);
					
		}
		fileDetailsList.put(totaPagesAndErrorMap, fileList);
	}
    catch (SQLException e) {
    	StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);

	} catch (ParseException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}  finally {

		if (connection != null)
			try {
				connection.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}

		if(resSetBulkdetails!=null)
		{
	try {
		resSetBulkdetails.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	}

	return fileDetailsList;
}
@Override
public int insertNonBankableDetails(BulkDetails bd, Connection connection, TransactionDefinition transactionDefinition, PlatformTransactionManager platformTransactionManager, TransactionStatus transactionStatus) 
{


	TransactionDefinition def = new DefaultTransactionDefinition();
    TransactionStatus status = transactionManager.getTransaction(def);
    CallableStatement callableStatement=null;
  
	final String procedureCall = "{call AIRTL_NON_BANKABLE_PKG.AIRTL_NON_BANKABLE_PROC(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
	

	try {
	
		
	 callableStatement = connection
				.prepareCall(procedureCall);
		callableStatement.setString(1, bd.getChangeWho());
      	if(bd.getsNo()==null)
			callableStatement.setString(2, null);
		else
		callableStatement.setInt(2, Integer.parseInt(bd.getsNo()));
		callableStatement.setString(3, bd.getChequeNo());
		callableStatement.setString(4, bd.getIfscCode());

		callableStatement.setString(5, bd.getRemitterBranch());
		callableStatement.setDate(6, (java.sql.Date) bd.getChequeDate());
     	 if(bd.getPaymentAmt()==null)
			callableStatement.setString(7, null);
		else
		callableStatement.setDouble(7,Double.parseDouble(bd.getPaymentAmt()));
		callableStatement.setString(8, bd.getReason());
		callableStatement.setString(9,bd.getFileID());
		
		callableStatement.setDate(10, bd.getChangeDate());
		callableStatement.setString(11,bd.getServiceType());
		callableStatement.setString(12,bd.getAcctEXTID());
		callableStatement.setString(13,bd.getDelNO());
		
		callableStatement.setString(14,bd.getInvoiceNo());
		callableStatement.setString(15,bd.getPaymentDetails2());
		callableStatement.setString(16,bd.getBankVirtualAcctNo());
		callableStatement.setString(17,bd.getIfscCode());
		callableStatement.setString(18,bd.getLockboxID());
		callableStatement.setString(19,bd.getRemitterName());
		callableStatement.setString(20,bd.getSRNo());
		
		callableStatement.setString(21,bd.getOrderNo());
		callableStatement.setString(22,bd.getServiceNo());
		callableStatement.setString(23,bd.getReceiverName());
		callableStatement.setString(24,bd.getPaymentMode());
		callableStatement.setDate(25,bd.getPaymentDate());
		
		
		
		callableStatement.registerOutParameter(26, Types.VARCHAR);
		callableStatement.registerOutParameter(27, Types.VARCHAR);
		
		callableStatement.executeUpdate();
		
			
		//transactionManager.commit(status);
		//connection.commit();
	
	} catch (SQLException e) {
	//	transactionManager.rollback(status);
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	
		return 0;
	} 
	catch (Exception e) {
	//	transactionManager.rollback(status);
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		return 0;

	}
	finally {

		if (callableStatement != null)
			try {
				callableStatement.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
	}
	
return 1;
}

@Override
public String getFileIds() {

	 PreparedStatement pstmt = null;
	   
	    Connection connection=null;
	    String fileId=null;
	    ResultSet rs=null;
	    try {
			
	    	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		 connection = jdbcTemplate.getDataSource().getConnection();
			String query= " select NON_BANKABLE_SEQ.nextval from dual";
			pstmt = connection.prepareStatement(query);
				    
		     rs=pstmt.executeQuery();
		     while(rs.next())
		     fileId=rs.getString(1);
		   
		
	    }
	    catch (SQLException e) {
	    	StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
			return null;
		} 
	    catch (Exception e) {
	    	StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
			return null;

		}
	    finally {

			if (connection != null)
				try {
					connection.close();
				} catch (SQLException e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
		}

	return fileId;
}
@Override
public Map<Map<Integer, List<String>>, List<BulkDetails>> getNonBankableList(String pagenum, String fileId,
		String chequeNum, String bankAccountNumber, String startChequeDate,String endChequeDate) {

	
	List<String> errorDetails=new ArrayList<String>();
	Map<Integer,List<String>> totaPagesAndErrorMap=new HashMap<Integer,List<String>>();
	List<BulkDetails> fileList=new ArrayList<BulkDetails>();
	Map<Map<Integer,List<String>>, List<BulkDetails>> fileDetailsList=new HashMap<Map<Integer,List<String>>, List<BulkDetails>>();
	final String procedureCall = "{call AIRTL_NON_BANKABLE_PKG.AIRTL_NON_BANKABLE_RETRIEVAL(?,?,?,?,?,?,?,?,?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	CallableStatement callableStatement=null;

	try {

		// Get Connection instance from dataSource
	//	System.out.println("connect"+ "ion:" + dataSource.getConnection());
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
		//fileObj.setConnection(connection);
	
		 callableStatement = connection
				.prepareCall(procedureCall);
		callableStatement.setString(1, pagenum);
		callableStatement.setString(3, fileId);
		callableStatement.setString(4, chequeNum);
		callableStatement.setString(5, bankAccountNumber);

		callableStatement.setString(6, startChequeDate);
		callableStatement.setString(7, endChequeDate);
		
		callableStatement.registerOutParameter(2, Types.INTEGER);
		callableStatement.registerOutParameter(8, OracleTypes.CURSOR);
		callableStatement.registerOutParameter(9, Types.VARCHAR);
		callableStatement.registerOutParameter(10, Types.VARCHAR);
		
		callableStatement.executeUpdate();
		int totalPages=callableStatement.getInt(2);
		String errorCode=callableStatement.getString(9);
		String errorMessage=callableStatement.getString(10);
		errorDetails.add(errorCode);
		errorDetails.add(errorMessage);
		totaPagesAndErrorMap.put(totalPages, errorDetails);
		resSetBulkdetails = (ResultSet) callableStatement.getObject(8);
		if(resSetBulkdetails==null)
		{
			logger.info("resultset is null");
		}
		
while (resSetBulkdetails!=null&&resSetBulkdetails.next()) {
			
	BulkDetails nonBankableDetails=new BulkDetails();
	
	nonBankableDetails.setFileID(resSetBulkdetails.getString("FILE_ID"));
	nonBankableDetails.setChequeNo(resSetBulkdetails.getString("CHEQUE_NUMBER"));
	nonBankableDetails.setBankVirtualAcctNo(resSetBulkdetails.getString("BANK_ACCOUNT_NUMBER"));
	nonBankableDetails.setBankName(resSetBulkdetails.getString("BANK_NAME"));
	nonBankableDetails.setChequeDate(resSetBulkdetails.getDate("CHEQUE_DATE"));
	nonBankableDetails.setPaymentAmt(resSetBulkdetails.getString("AMOUNT"));
	nonBankableDetails.setFileName(resSetBulkdetails.getString("ORIGINAL_FILE_NAME"));
	
			fileList.add(nonBankableDetails);
			
		
		}
		fileDetailsList.put(totaPagesAndErrorMap, fileList);
		
		connection.commit();
	//	System.out.println(" All details vendor file details inserted ");
	} catch (SQLException e) {
		
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	  //fileObj.setTrStatus("false");	

	} 
	catch (Exception e) {
		
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		// fileObj.setTrStatus("false");	

	}
	finally {

		if (connection != null)
			try {
				connection.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		if (callableStatement != null)
			try {
				callableStatement.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}

		if(resSetBulkdetails!=null)
		{
	try {
		resSetBulkdetails.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	}
	return fileDetailsList;
}
public FileDetails recordCheckxlsOthers(FileDetails fileObj,String errorFilesPath,String extension) {

	// CustomerDetails customerObj=new CustomerDetails();

	final String procedureCall = "{call ACE_CAD_BULK_PAYMENT.ace_cad_record_check(?,?,?,?,?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	String error_code;
	CallableStatement callableStatement=null;
	//List recordList=new ArrayList();
	//Writeexcel writeExcel=new Writeexcel();
	int i=1;
	
	BulkDetails recordDetailsObj=new BulkDetails();
	try {
      connection=fileObj.getConnection();
	
		 callableStatement = connection
				.prepareCall(procedureCall);

		callableStatement.setString(1, fileObj.getFileID());
		callableStatement.setString(2,fileObj.getVendorType());
		callableStatement.registerOutParameter(3, Types.VARCHAR);
		callableStatement.registerOutParameter(4, Types.VARCHAR);
		callableStatement.registerOutParameter(5, Types.VARCHAR);
	//	System.out.println("above");
		callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
	//	System.out.println("below");
		callableStatement.executeUpdate();
	//fileObj.getConnection().commit();
		fileObj.setTrStatus("true");
		fileObj.setErrorMsg(callableStatement.getString(3));
		fileObj.setErrorCode(callableStatement.getString(4));
	//	System.out.println((callableStatement.getString(3)));
		fileObj.setStatus(callableStatement.getString(5));
		
		resSetBulkdetails = (ResultSet) callableStatement.getObject(6);
	
	//	System.out.println("flag is........ " + fileObj.getFlag());
	
		logger.info("Status in out paramater....." + fileObj.getStatus());

		if(fileObj.getStatus()!=null){
		//resSetBulkdetails.getInt(1);
		FileOutputStream fileOut = null;
	//	System.out.println("final is" +fileObj.getFinalFileName());
		try {
			fileOut = new FileOutputStream(new File(errorFilesPath+File.separator+fileObj.getOriginalFileName()));
		} catch (FileNotFoundException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet worksheet = workbook.createSheet("Others Error Records");
		HSSFRow row1=null;
		row1 = worksheet.createRow(0);
	//	HSSFCellStyle cellStyle = workbook.createCellStyle();
       Cell cellA1 = row1.createCell((short) 0);
        
		cellA1.setCellValue("Serial No.");
	
		
	
		Cell cellC1 = row1.createCell((short) 1);
		cellC1.setCellValue("LOB(MOB/FL/AES/ISTM)");

		Cell cellD1 = row1.createCell((short) 2);
		cellD1.setCellValue("Trans Date(MM/DD/YYYY)");
		
	
		Cell cellE1 = row1.createCell((short) 3);
           
		cellE1.setCellValue("Payment Code");
		
		Cell cellF1 = row1.createCell((short) 4);
		cellF1.setCellValue("Acount No.(External_Account_No)");
		

		Cell cellG1 = row1.createCell((short) 5);
		cellG1.setCellValue("Mobile / Del no.");

		Cell cellH1 = row1.createCell((short) 6);
		cellH1.setCellValue("Invoice No");
	
		Cell cellI1 = row1.createCell((short) 7);
           
		cellI1.setCellValue("Amount");
		
		Cell cellJ1 = row1.createCell((short) 8);
		cellJ1.setCellValue("Receipt Date(MM/DD/YYYY)");
		
		Cell cellK1 = row1.createCell((short) 9);
		cellK1.setCellValue("Payment Ref Num (Receipt No / Cheque No / Credit Card Authorisation No.)");

		Cell cellL1 = row1.createCell((short) 10);
		cellL1.setCellValue("Bank Name");
		//cellStyle = workbook.createCellStyle();
		
		Cell cellM1 = row1.createCell((short) 11);
          
		cellM1.setCellValue("SR Number");
			
		//cellStyle = workbook.createCellStyle();
		
		Cell cellP1 = row1.createCell((short) 12);
		cellP1.setCellValue("Annotation");
		

		Cell cellZ1 = row1.createCell((short) 13);
		cellZ1.setCellValue("Error code description");
		

		

		if(resSetBulkdetails!=null)
		{
			while (resSetBulkdetails.next()) {
				//System.out.println("invoice number is " +resSetBulkdetails.getString("invoice_no"));
				error_code = resSetBulkdetails.getString("error_reason_code");
			
				fileObj.setErrorReasonCode(error_code);
				
				recordDetailsObj.setsNo(resSetBulkdetails.getString(1));
				recordDetailsObj.setFileID(resSetBulkdetails.getString(2));
				recordDetailsObj.setServiceType(resSetBulkdetails.getString(27));
				recordDetailsObj.setAcctEXTID(resSetBulkdetails.getString(6));
				recordDetailsObj.setDelNO(resSetBulkdetails.getString(7));
				recordDetailsObj.setInvoiceNo(resSetBulkdetails.getString(9));
				recordDetailsObj.setPaymentMode(resSetBulkdetails.getString(13));
				recordDetailsObj.setChequeNo(resSetBulkdetails.getString(14));
				recordDetailsObj.setBankName(resSetBulkdetails.getString(49));
				recordDetailsObj.setPaymentAmt(resSetBulkdetails.getString(11));
				
				recordDetailsObj.setPaymentCode(resSetBulkdetails.getString(42));
				recordDetailsObj.setInsertDate(resSetBulkdetails.getDate(23));
				recordDetailsObj.setPaymentDate(resSetBulkdetails.getDate(12));
			
				
				recordDetailsObj.setAnnotation(resSetBulkdetails.getString(39));
				
			//	recordDetailsObj.setBankGLCode(resSetBulkdetails.getString(31));
				recordDetailsObj.setExchangeRate(resSetBulkdetails.getString(32));
				recordDetailsObj.setSRNo(resSetBulkdetails.getString(33));
			
				recordDetailsObj.setRemarks(resSetBulkdetails.getString(24));
				recordDetailsObj.setIsErrorRecord(resSetBulkdetails.getString(25));
				recordDetailsObj.setErrorReasonCode(resSetBulkdetails.getString(26));
				recordDetailsObj.setCircle(resSetBulkdetails.getString(3));
				recordDetailsObj.setReceiptDate(resSetBulkdetails.getDate(62));
			//	recordDetailsObj.setErrorCodeDescription(resSetBulkdetails.getString(38));
				
		
					 row1 = worksheet.createRow(i);
					 
					 
					HSSFCell cellA2 = row1.createCell((short) 0);
	               
					cellA2.setCellValue(recordDetailsObj.getsNo());
					
					

					HSSFCell cellB2 = row1.createCell((short) 1);
					cellB2.setCellValue(recordDetailsObj.getServiceType());
					

					HSSFCell cellN2 = row1.createCell((short) 2);
					CellStyle cellStyle = workbook.createCellStyle();
					CreationHelper createHelper = workbook.getCreationHelper();
					cellStyle.setDataFormat(
						    createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
					if(resSetBulkdetails.getString(12)!=null)
					cellN2.setCellValue(recordDetailsObj.getPaymentDate());
					cellN2.setCellStyle(cellStyle);
					worksheet.autoSizeColumn(2);
					HSSFCell cellG2 = row1.createCell((short) 3);
					cellG2.setCellValue(recordDetailsObj.getPaymentCode());

					HSSFCell cellD2 = row1.createCell((short) 4);
					cellD2.setCellValue(recordDetailsObj.getAcctEXTID());
		
					HSSFCell cellE2 = row1.createCell((short) 5);
					cellE2.setCellValue(recordDetailsObj.getDelNO());
					
					HSSFCell cellF2 = row1.createCell((short) 6);
					cellF2.setCellValue(recordDetailsObj.getInvoiceNo());
					
					HSSFCell cellJ2 = row1.createCell((short) 7);
					cellJ2.setCellValue(recordDetailsObj.getPaymentAmt());
					HSSFCell cellM2 = row1.createCell((short) 8);
					//cellM2.setCellType(Cell.CELL_TYPE_FORMULA);
					//cellM2.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
					cellStyle.setDataFormat(
						    createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
					cellM2.setCellValue(recordDetailsObj.getReceiptDate());
					cellM2.setCellStyle(cellStyle);
					worksheet.autoSizeColumn(8);

					HSSFCell cellH2 = row1.createCell((short) 9);
					cellH2.setCellValue(recordDetailsObj.getChequeNo());
								
					HSSFCell cellI2 = row1.createCell((short) 10);
		             cellI2.setCellValue(recordDetailsObj.getBankName());
					
					
					
					HSSFCell cellK2 = row1.createCell((short) 11);
					cellK2.setCellValue(recordDetailsObj.getSRNo());

					HSSFCell cellL2 = row1.createCell((short) 12);
					cellL2.setCellValue(recordDetailsObj.getAnnotation());
										
							
					HSSFCell cellZ2 = row1.createCell((short) 13);
					cellZ2.setCellValue(recordDetailsObj.getErrorReasonCode());
									
					 i++;
					// System.out.println("i value is"+i);
				
				}
		}
			try {
			workbook.write(fileOut);
			fileOut.flush();
			fileOut.close();
		} catch (IOException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}

		
	}} catch (SQLException e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	//	transactionManager.rollback(fileObj.getTransaction());
		fileObj.setTrStatus("false");

	}
	catch(Exception e)
	{
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	//	transactionManager.rollback(fileObj.getTransaction());
		fileObj.setTrStatus("false");
	}
	finally
	{
		if(callableStatement!=null)
		{
			try {
				callableStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}

		if(resSetBulkdetails!=null)
		{
	try {
		resSetBulkdetails.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	}
	final long duration = System.nanoTime() - startTime;
	//logger.info("total time of execution is" +duration);
	return fileObj;
}	
public FileDetails recordCheckxlsxOthers(FileDetails fileObj,String errorFilesPath,String extension) {

	// CustomerDetails customerObj=new CustomerDetails();

	final String procedureCall = "{call ACE_CAD_BULK_PAYMENT.ace_cad_record_check(?,?,?,?,?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	String error_code;
	CallableStatement callableStatement=null;
	//List recordList=new ArrayList();
	//Writeexcel writeExcel=new Writeexcel();
	int i=1;
	
	BulkDetails recordDetailsObj=new BulkDetails();
	try {
      connection=fileObj.getConnection();
	
		 callableStatement = connection
				.prepareCall(procedureCall);

		callableStatement.setString(1, fileObj.getFileID());
		callableStatement.setString(2,fileObj.getVendorType());
		callableStatement.registerOutParameter(3, Types.VARCHAR);
		callableStatement.registerOutParameter(4, Types.VARCHAR);
		callableStatement.registerOutParameter(5, Types.VARCHAR);
	//	System.out.println("above");
		callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
	//	System.out.println("below");
		callableStatement.executeUpdate();
	//fileObj.getConnection().commit();
		fileObj.setTrStatus("true");
		fileObj.setErrorMsg(callableStatement.getString(3));
		fileObj.setErrorCode(callableStatement.getString(4));
	//	System.out.println((callableStatement.getString(3)));
		fileObj.setStatus(callableStatement.getString(5));
		
		resSetBulkdetails = (ResultSet) callableStatement.getObject(6);
	
	//	System.out.println("flag is........ " + fileObj.getFlag());
	
		logger.info("Status in out paramater....." + fileObj.getStatus());

		if(fileObj.getStatus()!=null){
		//resSetBulkdetails.getInt(1);
		FileOutputStream fileOut = null;
	//	System.out.println("final is" +fileObj.getFinalFileName());
		try {
			fileOut = new FileOutputStream(new File(errorFilesPath+File.separator+fileObj.getOriginalFileName()));
		} catch (FileNotFoundException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		Workbook workbook = new XSSFWorkbook();
		
		   org.apache.poi.ss.usermodel.Sheet worksheet = workbook.createSheet("Others Error Records");
		Row row1=null;
		row1 = worksheet.createRow(0);
	//	CellStyle cellStyle = workbook.createCellStyle();
		 Cell cellA1 = row1.createCell((short) 0);
	        
			cellA1.setCellValue("Serial No.");
		
			
		
			Cell cellC1 = row1.createCell((short) 1);
			cellC1.setCellValue("LOB(MOB/FL/AES/ISTM)");

			Cell cellD1 = row1.createCell((short) 2);
			cellD1.setCellValue("Trans Date(MM/DD/YYYY)");
			
		
			Cell cellE1 = row1.createCell((short) 3);
	           
			cellE1.setCellValue("Payment Code");
			
			Cell cellF1 = row1.createCell((short) 4);
			cellF1.setCellValue("Acount No.(External_Account_No)");
			

			Cell cellG1 = row1.createCell((short) 5);
			cellG1.setCellValue("Mobile / Del no.");

			Cell cellH1 = row1.createCell((short) 6);
			cellH1.setCellValue("Invoice No");
		
			Cell cellI1 = row1.createCell((short) 7);
	           
			cellI1.setCellValue("Amount");
			
			Cell cellJ1 = row1.createCell((short) 8);
			cellJ1.setCellValue("Receipt Date(MM/DD/YYYY)");
			
			Cell cellK1 = row1.createCell((short) 9);
			cellK1.setCellValue("Payment Ref Num (Receipt No / Cheque No / Credit Card Authorisation No.)");

			Cell cellL1 = row1.createCell((short) 10);
			cellL1.setCellValue("Bank Name");
			//cellStyle = workbook.createCellStyle();
			
			Cell cellM1 = row1.createCell((short) 11);
	          
			cellM1.setCellValue("SR Number");
				
			//cellStyle = workbook.createCellStyle();
			
			Cell cellP1 = row1.createCell((short) 12);
			cellP1.setCellValue("Annotation");
			

			Cell cellZ1 = row1.createCell((short) 13);
			cellZ1.setCellValue("Error code description");
		if(resSetBulkdetails!=null)
		{
			while (resSetBulkdetails.next()) {
				//System.out.println("invoice number is " +resSetBulkdetails.getString("invoice_no"));
				error_code = resSetBulkdetails.getString("error_reason_code");
			
				fileObj.setErrorReasonCode(error_code);
				
				recordDetailsObj.setsNo(resSetBulkdetails.getString(1));
				recordDetailsObj.setFileID(resSetBulkdetails.getString(2));
				recordDetailsObj.setServiceType(resSetBulkdetails.getString(27));
				recordDetailsObj.setAcctEXTID(resSetBulkdetails.getString(6));
				recordDetailsObj.setDelNO(resSetBulkdetails.getString(7));
				recordDetailsObj.setInvoiceNo(resSetBulkdetails.getString(9));
				recordDetailsObj.setPaymentMode(resSetBulkdetails.getString(13));
				recordDetailsObj.setChequeNo(resSetBulkdetails.getString(14));
				recordDetailsObj.setBankName(resSetBulkdetails.getString(49));
				recordDetailsObj.setPaymentAmt(resSetBulkdetails.getString(11));
				recordDetailsObj.setPaymentCode(resSetBulkdetails.getString(42));
			
				recordDetailsObj.setInsertDate(resSetBulkdetails.getDate(23));
				recordDetailsObj.setPaymentDate(resSetBulkdetails.getDate(12));
			
				
				recordDetailsObj.setAnnotation(resSetBulkdetails.getString(39));
				recordDetailsObj.setPaymentCode(resSetBulkdetails.getString(42));
				
			//	recordDetailsObj.setBankGLCode(resSetBulkdetails.getString(31));
				recordDetailsObj.setExchangeRate(resSetBulkdetails.getString(32));
				recordDetailsObj.setSRNo(resSetBulkdetails.getString(33));
			
				recordDetailsObj.setRemarks(resSetBulkdetails.getString(24));
				recordDetailsObj.setIsErrorRecord(resSetBulkdetails.getString(25));
				recordDetailsObj.setErrorReasonCode(resSetBulkdetails.getString(26));
			//	recordDetailsObj.setErrorCodeDescription(resSetBulkdetails.getString(38));
				
				recordDetailsObj.setCircle(resSetBulkdetails.getString(3));
				recordDetailsObj.setReceiptDate(resSetBulkdetails.getDate(62));
		
					 row1 = worksheet.createRow(i);
					 
					 
					Cell cellA2 = row1.createCell((short) 0);
	               
					cellA2.setCellValue(recordDetailsObj.getsNo());
					
					

					Cell cellB2 = row1.createCell((short) 1);
					cellB2.setCellValue(recordDetailsObj.getServiceType());
					

					Cell cellN2 = row1.createCell((short) 2);
					CellStyle cellStyle = workbook.createCellStyle();
					CreationHelper createHelper = workbook.getCreationHelper();
					cellStyle.setDataFormat(
						    createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
					if(resSetBulkdetails.getString(12)!=null)
					cellN2.setCellValue(recordDetailsObj.getPaymentDate());
					worksheet.autoSizeColumn(2);
					cellN2.setCellStyle(cellStyle);
					Cell cellG2 = row1.createCell((short) 3);
					cellG2.setCellValue(recordDetailsObj.getPaymentCode());

					Cell cellD2 = row1.createCell((short) 4);
					cellD2.setCellValue(recordDetailsObj.getAcctEXTID());
		
					Cell cellE2 = row1.createCell((short) 5);
					cellE2.setCellValue(recordDetailsObj.getDelNO());
					
					Cell cellF2 = row1.createCell((short) 6);
					cellF2.setCellValue(recordDetailsObj.getInvoiceNo());
					
					Cell cellJ2 = row1.createCell((short) 7);
					cellJ2.setCellValue(recordDetailsObj.getPaymentAmt());
					Cell cellM2 = row1.createCell((short) 8);
					//cellM2.setCellType(Cell.CELL_TYPE_FORMULA);
					//cellM2.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
					cellStyle.setDataFormat(
						    createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
					cellM2.setCellValue(recordDetailsObj.getReceiptDate());
					cellM2.setCellStyle(cellStyle);
					worksheet.autoSizeColumn(8);

					Cell cellH2 = row1.createCell((short) 9);
					cellH2.setCellValue(recordDetailsObj.getChequeNo());
								
					Cell cellI2 = row1.createCell((short) 10);
		             cellI2.setCellValue(recordDetailsObj.getBankName());
					
					
					
		             Cell cellK2 = row1.createCell((short) 11);
					cellK2.setCellValue(recordDetailsObj.getSRNo());

					Cell cellL2 = row1.createCell((short) 12);
					cellL2.setCellValue(recordDetailsObj.getAnnotation());
										
							
					Cell cellZ2 = row1.createCell((short) 13);
					cellZ2.setCellValue(recordDetailsObj.getErrorReasonCode());
					/*Cell cellAA2 = row1.createCell((short) 15);
					cellAA2.setCellValue(recordDetailsObj.getRemarks());
				*/
					 i++;
					// System.out.println("i value is"+i);
				
				} 
		}
			try {
			workbook.write(fileOut);
			fileOut.flush();
			fileOut.close();
		} catch (IOException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}

		
	}} catch (SQLException e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	//	transactionManager.rollback(fileObj.getTransaction());
		fileObj.setTrStatus("false");

	}
	catch(Exception e)
	{
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	//	transactionManager.rollback(fileObj.getTransaction());
		fileObj.setTrStatus("false");
	}
	finally
	{
		if(callableStatement!=null)
		{
			try {
				callableStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}

		if(resSetBulkdetails!=null)
		{
	try {
		resSetBulkdetails.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	}
	final long duration = System.nanoTime() - startTime;
	//logger.info("total time of execution is" +duration);
	return fileObj;
}
@Override
public FileDetails reversalFileDetails(FileDetails fileDetailsObj) {


	TransactionDefinition def = new DefaultTransactionDefinition();
    TransactionStatus status = transactionManager.getTransaction(def);
    fileDetailsObj.setTransactionManager(transactionManager);
    fileDetailsObj.setTransactionDef(def);
    fileDetailsObj.setTransaction(status);
	final String procedureCall = "{call ACE_CAD_REVERSAL_PACKAGE.ACE_CAD_REVERSAL_FILE_INSERT(?,?,?,?,?,?,?,?,?)}";
	Connection connection = null;
	CallableStatement callableStatement=null;

	try {

		// Get Connection instance from dataSource
	//	System.out.println("connect"+ "ion:" + dataSource.getConnection());
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
		fileDetailsObj.setConnection(connection);
		connection.setAutoCommit(false);
		 callableStatement = connection
				.prepareCall(procedureCall);

		callableStatement.setString(1, fileDetailsObj.getVendorUserId());
		///callableStatement.setString(2, fileDetailsObj.getCircle());
		callableStatement.setString(2, fileDetailsObj.getOriginalFileName());
	//	System.out.println("original file in dao"+fileObj.getOriginalFileName());
		//callableStatement.setString(4, fileDetailsObj.getFinalFileName());
		callableStatement.setInt(3, fileDetailsObj.getTotalRecords());
		callableStatement.setString(4,fileDetailsObj.getFileTYpe());
		if(fileDetailsObj.getPaymentAmount()==null)
			callableStatement.setString(5,null);
		else
		callableStatement.setDouble(5,Double.parseDouble(fileDetailsObj.getPaymentAmount()));
		
		
	
	
		callableStatement.registerOutParameter(6, Types.VARCHAR);
		callableStatement.registerOutParameter(7, Types.VARCHAR);
		callableStatement.registerOutParameter(8, Types.VARCHAR);
		callableStatement.registerOutParameter(9, Types.VARCHAR);
		
		callableStatement.executeUpdate();
		
		fileDetailsObj.setFileID( callableStatement.getString(6));
		fileDetailsObj.setStatus(callableStatement.getString(7));
		fileDetailsObj.setErrorCode(callableStatement.getString(9));
		fileDetailsObj.setErrorMsg(callableStatement.getString(8));
		fileDetailsObj.setTrStatus("true");
		//System.out.println((callableStatement.getString(14)));
		
	

		logger.info("file id is........ " + fileDetailsObj.getFileID());
		logger.info(fileDetailsObj.getErrorMsg());
	
		logger.info("Status of reversal file details ....." + fileDetailsObj.getStatus());
		
	
	} catch (SQLException e) {
		transactionManager.rollback(status);
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		fileDetailsObj.setTrStatus("false");	

	} 
	catch (Exception e) {
		transactionManager.rollback(status);
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		fileDetailsObj.setTrStatus("false");	

	}
	finally
	{
	if(callableStatement!=null)
	{
		try {
			callableStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
	}
	}
	return fileDetailsObj;

}
@Override
public FileDetails recordCheckxlsReversal(FileDetails fileDetailsObj,
		String errorFilesPath, String extension) {

	// CustomerDetails customerObj=new CustomerDetails();

	final String procedureCall = "{call ACE_CAD_REVERSAL_PACKAGE.ace_cad_record_check(?,?,?,?,?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	String error_code;
	CallableStatement callableStatement=null;
	//List recordList=new ArrayList();
	//Writeexcel writeExcel=new Writeexcel();
	int i=1;
	
	BulkDetails recordDetailsObj=new BulkDetails();
	try {
      connection=fileDetailsObj.getConnection();
	
		 callableStatement = connection
				.prepareCall(procedureCall);

		callableStatement.setString(1, fileDetailsObj.getFileID());
		callableStatement.setString(2,fileDetailsObj.getVendorType());
		callableStatement.registerOutParameter(3, Types.VARCHAR);
		callableStatement.registerOutParameter(4, Types.VARCHAR);
		callableStatement.registerOutParameter(5, Types.VARCHAR);
	//	System.out.println("above");
		callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
	//	System.out.println("below");
		callableStatement.executeUpdate();
	//fileObj.getConnection().commit();
		fileDetailsObj.setTrStatus("true");
		fileDetailsObj.setErrorMsg(callableStatement.getString(3));
		fileDetailsObj.setErrorCode(callableStatement.getString(4));
	//	System.out.println((callableStatement.getString(3)));
		fileDetailsObj.setStatus(callableStatement.getString(5));
		
		resSetBulkdetails = (ResultSet) callableStatement.getObject(6);
	
	//	System.out.println("flag is........ " + fileObj.getFlag());
	
		logger.info("Status in out paramater....." + fileDetailsObj.getStatus());

		if(fileDetailsObj.getStatus()!=null){
		//resSetBulkdetails.getInt(1);
		FileOutputStream fileOut = null;
	//	System.out.println("final is" +fileObj.getFinalFileName());
		try {
			fileOut = new FileOutputStream(new File(errorFilesPath+File.separator+fileDetailsObj.getOriginalFileName()));
		} catch (FileNotFoundException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet worksheet = workbook.createSheet("Reversal Error Records");
		HSSFRow row1=null;
		row1 = worksheet.createRow(0);
		Cell cellA1 = row1.createCell((short) 0);
        
		cellA1.setCellValue("ACCOUNT_NO");
		

		Cell cellB1 = row1.createCell((short) 1);
		cellB1.setCellValue("TRACKING_ID");
		

		Cell cellC1 = row1.createCell((short) 2);
		cellC1.setCellValue("TRACKING_ID_SERV");

		Cell cellD1 = row1.createCell((short) 3);
		cellD1.setCellValue("Payment code (BMF_TRANS_TYPE)");
		//cellStyle = workbook.createCellStyle();
	
		Cell cellE1 = row1.createCell((short) 4);
           
		cellE1.setCellValue("REVERSAL_DATE(MM/DD/YYYY)");
		

		Cell cellF1 = row1.createCell((short) 5);
		cellF1.setCellValue("SR Number");

		Cell cellG1 = row1.createCell((short) 6);
		cellG1.setCellValue("ANNOTATION");

		Cell cellZ1 = row1.createCell((short) 7);
		cellZ1.setCellValue("Error code description");
		

		

		if(resSetBulkdetails!=null)
		{
			while (resSetBulkdetails.next()) {
				//System.out.println("invoice number is " +resSetBulkdetails.getString("invoice_no"));
				error_code = resSetBulkdetails.getString("error_reason_code");
			
				fileDetailsObj.setErrorReasonCode(error_code);
				
				recordDetailsObj.setAcctEXTID(resSetBulkdetails.getString(6));
				recordDetailsObj.setTrackingId(resSetBulkdetails.getString(43));
			
				recordDetailsObj.setTrackingIdServ(resSetBulkdetails.getString(41));
				recordDetailsObj.setPaymentCode(resSetBulkdetails.getString(42));
				
				recordDetailsObj.setFileID(resSetBulkdetails.getString(2));
				recordDetailsObj.setPaymentDate(resSetBulkdetails.getDate(12));
				
				
			recordDetailsObj.setAnnotation(resSetBulkdetails.getString(39));
				
				
			
				recordDetailsObj.setSRNo(resSetBulkdetails.getString(33));
			
				recordDetailsObj.setServiceNo(resSetBulkdetails.getString(36));
			recordDetailsObj.setInsertDate(resSetBulkdetails.getDate(23));
			
								
			recordDetailsObj.setErrorCodeDescription(resSetBulkdetails.getString(26));
			
		
					 row1 = worksheet.createRow(i);
					 
					 
					Cell cellA2 = row1.createCell((short) 0);
	               
					cellA2.setCellValue(recordDetailsObj.getAcctEXTID());
					

					Cell cellB2 = row1.createCell((short) 1);
					
					cellB2.setCellValue(recordDetailsObj.getTrackingId());

					

					Cell cellC2 = row1.createCell((short) 2);
					cellC2.setCellValue(recordDetailsObj.getTrackingIdServ());

					Cell cellD2 = row1.createCell((short) 3);
					
					cellD2.setCellValue(recordDetailsObj.getPaymentCode());
		
					Cell cellE2 = row1.createCell((short) 4);
					CellStyle cellStyle = workbook.createCellStyle();
					CreationHelper createHelper = workbook.getCreationHelper();
					cellStyle.setDataFormat(
						    createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
					//	cellD2.setCellValue(recordDetailsObj.getPaymentDate());
					if(resSetBulkdetails.getString(12)!=null)
					cellE2.setCellValue(recordDetailsObj.getPaymentDate());
					cellE2.setCellStyle(cellStyle);
					worksheet.autoSizeColumn(4);
					
					Cell cellF2 = row1.createCell((short) 5);
					cellF2.setCellValue(recordDetailsObj.getSRNo());
					
					
					Cell cellG2 = row1.createCell((short) 6);
					cellG2.setCellValue(recordDetailsObj.getAnnotation());
					

					
					Cell cellAA2 = row1.createCell((short) 7);
					cellAA2.setCellValue(recordDetailsObj.getErrorCodeDescription());
					
					 i++;
					 //System.out.println("i value is"+i);
				
				} 
		}
			try {
			workbook.write(fileOut);
			fileOut.flush();
			fileOut.close();
		} catch (IOException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}

		
	}} catch (SQLException e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	//	transactionManager.rollback(fileDetailsObj.getTransaction());
		fileDetailsObj.setTrStatus("false");

	}
	catch(Exception e)
	{
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	//	transactionManager.rollback(fileDetailsObj.getTransaction());
		fileDetailsObj.setTrStatus("false");
	}
	finally
	{
	if(callableStatement!=null)
	{
		try {
			callableStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
	}

	if(resSetBulkdetails!=null)
	{
try {
	resSetBulkdetails.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);
}
	}

	}
	final long duration = System.nanoTime() - startTime;
	
	return fileDetailsObj;
}
@Override
public FileDetails recordCheckxlsxReversal(FileDetails fileDetailsObj,
		String errorFilesPath, String extension) {

	// CustomerDetails customerObj=new CustomerDetails();

	final String procedureCall = "{call ACE_CAD_REVERSAL_PACKAGE.ace_cad_record_check(?,?,?,?,?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	String error_code;
	CallableStatement callableStatement=null;
	//List recordList=new ArrayList();
	//Writeexcel writeExcel=new Writeexcel();
	int i=1;
	
	BulkDetails recordDetailsObj=new BulkDetails();
	try {
      connection=fileDetailsObj.getConnection();
	
		 callableStatement = connection
				.prepareCall(procedureCall);

		callableStatement.setString(1, fileDetailsObj.getFileID());
		callableStatement.setString(2,fileDetailsObj.getVendorType());
		callableStatement.registerOutParameter(3, Types.VARCHAR);
		callableStatement.registerOutParameter(4, Types.VARCHAR);
		callableStatement.registerOutParameter(5, Types.VARCHAR);
	//	System.out.println("above");
		callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
	//	System.out.println("below");
		callableStatement.executeUpdate();
	//fileObj.getConnection().commit();
		fileDetailsObj.setTrStatus("true");
		fileDetailsObj.setErrorMsg(callableStatement.getString(3));
		fileDetailsObj.setErrorCode(callableStatement.getString(4));
	//	System.out.println((callableStatement.getString(3)));
		fileDetailsObj.setStatus(callableStatement.getString(5));
		
		resSetBulkdetails = (ResultSet) callableStatement.getObject(6);
	
	//	System.out.println("flag is........ " + fileObj.getFlag());
	
		logger.info("Status in out paramater....." + fileDetailsObj.getStatus());

		if(fileDetailsObj.getStatus()!=null){
		//resSetBulkdetails.getInt(1);
		FileOutputStream fileOut = null;
	//	System.out.println("final is" +fileObj.getFinalFileName());
		try {
			fileOut = new FileOutputStream(new File(errorFilesPath+File.separator+fileDetailsObj.getOriginalFileName()));
		} catch (FileNotFoundException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		Workbook workbook = new XSSFWorkbook();
		
		   org.apache.poi.ss.usermodel.Sheet worksheet = workbook.createSheet("Reversal Error Records");
		Row row1=null;
		row1 = worksheet.createRow(0);
		Cell cellA1 = row1.createCell((short) 0);
        
		cellA1.setCellValue("ACCOUNT_NO");
		

		Cell cellB1 = row1.createCell((short) 1);
		cellB1.setCellValue("TRACKING_ID");
		

		Cell cellC1 = row1.createCell((short) 2);
		cellC1.setCellValue("TRACKING_ID_SERV");

		Cell cellD1 = row1.createCell((short) 3);
		cellD1.setCellValue("Payment code (BMF_TRANS_TYPE)");
		//cellStyle = workbook.createCellStyle();
	
		Cell cellE1 = row1.createCell((short) 4);
           
		cellE1.setCellValue("REVERSAL_DATE(MM/DD/YYYY)");
		

		Cell cellF1 = row1.createCell((short) 5);
		cellF1.setCellValue("SR Number");

		Cell cellG1 = row1.createCell((short) 6);
		cellG1.setCellValue("ANNOTATION");

		Cell cellZ1 = row1.createCell((short) 7);
		cellZ1.setCellValue("Error code description");
		

		
		if(resSetBulkdetails!=null)
		{
		
			while (resSetBulkdetails.next()) {
				//System.out.println("invoice number is " +resSetBulkdetails.getString("invoice_no"));
				error_code = resSetBulkdetails.getString("error_reason_code");
			
				fileDetailsObj.setErrorReasonCode(error_code);
				
				recordDetailsObj.setAcctEXTID(resSetBulkdetails.getString(6));
				recordDetailsObj.setTrackingId(resSetBulkdetails.getString(43));
			
				recordDetailsObj.setTrackingIdServ(resSetBulkdetails.getString(41));
				recordDetailsObj.setPaymentCode(resSetBulkdetails.getString(42));
				
				
				recordDetailsObj.setPaymentDate(resSetBulkdetails.getDate(12));
				
				recordDetailsObj.setFileID(resSetBulkdetails.getString(2));
				recordDetailsObj.setAnnotation(resSetBulkdetails.getString(39));
				
				
			
				recordDetailsObj.setSRNo(resSetBulkdetails.getString(33));
			
				recordDetailsObj.setServiceNo(resSetBulkdetails.getString(36));
				recordDetailsObj.setInsertDate(resSetBulkdetails.getDate(23));
			
				
		
			recordDetailsObj.setErrorCodeDescription(resSetBulkdetails.getString(26));
			
		
					 row1 = worksheet.createRow(i);
					 
					 
					Cell cellA2 = row1.createCell((short) 0);
	               
					cellA2.setCellValue(recordDetailsObj.getAcctEXTID());
					

					Cell cellB2 = row1.createCell((short) 1);
					
					cellB2.setCellValue(recordDetailsObj.getTrackingId());

					

					Cell cellC2 = row1.createCell((short) 2);
					cellC2.setCellValue(recordDetailsObj.getTrackingIdServ());

					Cell cellD2 = row1.createCell((short) 3);
					
					cellD2.setCellValue(recordDetailsObj.getPaymentCode());
					CellStyle cellStyle = workbook.createCellStyle();
					CreationHelper createHelper = workbook.getCreationHelper();
					cellStyle.setDataFormat(
						    createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
					//	cellD2.setCellValue(recordDetailsObj.getPaymentDate());
					worksheet.autoSizeColumn(3);
					
		
					Cell cellE2 = row1.createCell((short) 4);
				// cellE2.setCellValue(recordDetailsObj.getPaymentDate());
					
					if(resSetBulkdetails.getString(12)!=null)
					cellE2.setCellValue(recordDetailsObj.getPaymentDate());
					cellE2.setCellStyle(cellStyle);
					
					Cell cellF2 = row1.createCell((short) 5);
					cellF2.setCellValue(recordDetailsObj.getSRNo());
					
					
					Cell cellG2 = row1.createCell((short) 6);
					cellG2.setCellValue(recordDetailsObj.getAnnotation());
					

					
					Cell cellAA2 = row1.createCell((short) 7);
					cellAA2.setCellValue(recordDetailsObj.getErrorCodeDescription());
					
					
					 i++;
					
				
				} 
		}
			try {
			workbook.write(fileOut);
			fileOut.flush();
			fileOut.close();
		} catch (IOException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}

		
	}} catch (SQLException e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		//transactionManager.rollback(fileDetailsObj.getTransaction());
		fileDetailsObj.setTrStatus("false");

	}
	catch(Exception e)
	{
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		//transactionManager.rollback(fileDetailsObj.getTransaction());
		fileDetailsObj.setTrStatus("false");
	}
	finally
	{
		if(callableStatement!=null)
		{
			try {
				callableStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}

		if(resSetBulkdetails!=null)
		{
	try {
		resSetBulkdetails.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	}
	final long duration = System.nanoTime() - startTime;
	//logger.info("total time of execution is" +duration);
	return fileDetailsObj;
}
@Override
public FileDetails approveReversalFilePaymentCheck(FileDetails fileDetailsObj,String errorFilesPath, String extension) {

	

	
	final String procedureCall = "{call ACE_CAD_REVERSAL_PACKAGE.ACE_CAD_REVERSAL_PAYMENT_CHECK(?,?,?,?,?)}";
	Connection connection = null;
	ResultSet resultfailedAccounts=null;
	BulkDetails recordDetailsObj=new BulkDetails();
	int i=3;
	CallableStatement callableStatement=null;

	try {

		
		  connection=fileDetailsObj.getConnection();
		
		
		callableStatement = connection
				.prepareCall(procedureCall);

		callableStatement.setString(1, fileDetailsObj.getFileID());
				
		callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
	
		callableStatement.registerOutParameter(3, Types.VARCHAR);
		callableStatement.registerOutParameter(4, Types.VARCHAR);
		callableStatement.registerOutParameter(5, Types.VARCHAR);
		
		
		callableStatement.executeUpdate();
		
		resultfailedAccounts = (ResultSet) callableStatement.getObject(2);
		fileDetailsObj.setStatus(callableStatement.getString(3));
		fileDetailsObj.setErrorMsg(callableStatement.getString(4));
		fileDetailsObj.setErrorCode(callableStatement.getString(5));
	
		fileDetailsObj.setTrStatus("true");
		logger.info("error msg"+fileDetailsObj.getErrorMsg());
		logger.info("status of reversal"+fileDetailsObj.getStatus());
		if(fileDetailsObj.getStatus()!=null){
			//resSetBulkdetails.getInt(1);
			FileOutputStream fileOut = null;
		//	System.out.println("final is" +fileObj.getFinalFileName());
			try {
				fileOut = new FileOutputStream(new File(errorFilesPath+File.separator+fileDetailsObj.getFileID()+"."+extension));
			} catch (FileNotFoundException e) {
				
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
			HSSFWorkbook workbook = new HSSFWorkbook();
			HSSFSheet worksheet = workbook.createSheet("Reversal failure records");
			HSSFRow row1=null;
			row1 = worksheet.createRow(0);
			Cell cellAB1 = row1.createCell((short) 0);
	        
			cellAB1.setCellValue("S_No");
			Cell cellA1 = row1.createCell((short) 1);
	        
			cellA1.setCellValue("ACCOUNT_NO");
			

			Cell cellB1 = row1.createCell((short) 2);
			cellB1.setCellValue("TRACKING_ID");
			

			Cell cellC1 = row1.createCell((short) 3);
			cellC1.setCellValue("TRACKING_ID_SERV");

		

			Cell cellZ1 = row1.createCell((short) 4);
			cellZ1.setCellValue("Error code description");
			

			
			if(resultfailedAccounts!=null)
			{
				while (resultfailedAccounts.next()) {
					//System.out.println("invoice number is " +resSetBulkdetails.getString("invoice_no"));
				//	error_code = resultfailedAccounts.getString("error_reason_code");
				
				//	fileDetailsObj.setErrorReasonCode(error_code);
					recordDetailsObj.setFileID(resultfailedAccounts.getString(1));
					recordDetailsObj.setsNo(resultfailedAccounts.getString(2));
					recordDetailsObj.setAcctEXTID(resultfailedAccounts.getString(3));
					recordDetailsObj.setTrackingId(resultfailedAccounts.getString(4));
				
					recordDetailsObj.setTrackingIdServ(resultfailedAccounts.getString(5));

				
									
				recordDetailsObj.setErrorCodeDescription(resultfailedAccounts.getString(6));
				
			
						 row1 = worksheet.createRow(i);
						 
						 
						Cell cellA2 = row1.createCell((short) 0);
		               
						cellA2.setCellValue(recordDetailsObj.getsNo());
						

						Cell cellB2 = row1.createCell((short) 1);
						
						cellB2.setCellValue(recordDetailsObj.getAcctEXTID());

						

						Cell cellC2 = row1.createCell((short) 2);
						cellC2.setCellValue(recordDetailsObj.getTrackingId());

						Cell cellD2 = row1.createCell((short) 3);
						
						cellD2.setCellValue(recordDetailsObj.getTrackingIdServ());
			
										
						
						Cell cellAA2 = row1.createCell((short) 4);
						cellAA2.setCellValue(recordDetailsObj.getErrorCodeDescription());
						
						 i++;
						
					} 
			}
				try {
				workbook.write(fileOut);
				fileOut.flush();
				fileOut.close();
			} catch (IOException e) {
				
				e.printStackTrace();
			}

			
		}

		logger.info("file id is........ " + fileDetailsObj.getFileID());
	
		logger.info("Status ....." + fileDetailsObj.getStatus());
		
	
	} catch (SQLException e) {
		transactionManager.rollback(fileDetailsObj.getTransaction());
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		fileDetailsObj.setTrStatus("false");	

	} 
	catch (Exception e) {
		transactionManager.rollback(fileDetailsObj.getTransaction());
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		fileDetailsObj.setTrStatus("false");	

	}
	finally
	{
		if(callableStatement!=null)
		{
			try {
				callableStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}
	}
	return fileDetailsObj;

}

@Override
public FileDetails recordCheckxlsBankStatement(FileDetails fileDetailsObj,
		String errorFilesPath, String extension) {

		final String procedureCall = "{call ACE_CAD_BULK_PAYMENT.ace_cad_record_check(?,?,?,?,?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	String error_code;
	CallableStatement callableStatement=null;
	int i=1;
	
	BulkDetails recordDetailsObj=new BulkDetails();
	try {
      connection=fileDetailsObj.getConnection();
	
		 callableStatement = connection
				.prepareCall(procedureCall);

		callableStatement.setString(1, fileDetailsObj.getFileID());
		callableStatement.setString(2,fileDetailsObj.getVendorType());
		callableStatement.registerOutParameter(3, Types.VARCHAR);
		callableStatement.registerOutParameter(4, Types.VARCHAR);
		callableStatement.registerOutParameter(5, Types.VARCHAR);
	
		callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
	
		callableStatement.executeUpdate();
	
		fileDetailsObj.setTrStatus("true");
		fileDetailsObj.setErrorMsg(callableStatement.getString(3));
		fileDetailsObj.setErrorCode(callableStatement.getString(4));
	
		fileDetailsObj.setStatus(callableStatement.getString(5));
		
		resSetBulkdetails = (ResultSet) callableStatement.getObject(6);
	
		logger.info("error msg"+fileDetailsObj.getErrorMsg());
	
		logger.info("Status in out paramater....." + fileDetailsObj.getStatus());

		if(fileDetailsObj.getStatus()!=null){
		//resSetBulkdetails.getInt(1);
		FileOutputStream fileOut = null;
	
		try {
			fileOut = new FileOutputStream(new File(errorFilesPath+File.separator+fileDetailsObj.getOriginalFileName()));
		} catch (FileNotFoundException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet worksheet = workbook.createSheet("Neft Error Records");
		HSSFRow row1=null;
		row1 = worksheet.createRow(0);
		
		Cell cellA1 = row1.createCell((short) 0);
		        
				cellA1.setCellValue("UTR No");
					

				Cell cellB1 = row1.createCell((short) 1);
				cellB1.setCellValue("Incoming Transaction Ref No");
				

				Cell cellC1 = row1.createCell((short) 2);
				cellC1.setCellValue("Value date(MM/DD/YYYY)");

				Cell cellD1 = row1.createCell((short) 3);
				cellD1.setCellValue("Amount in INR");
				//cellStyle = workbook.createCellStyle();
			
				Cell cellE1 = row1.createCell((short) 4);
		           
				cellE1.setCellValue("Receiving account received from RBI 1");
				

				Cell cellF1 = row1.createCell((short) 5);
				cellF1.setCellValue("Receiving account received from RBI 2");
				Cell cellG1 = row1.createCell((short) 6);
				cellG1.setCellValue("Valid Prefix Received");
				Cell cellG11 = row1.createCell((short) 7);
				cellG11.setCellValue("Valid Length Received");
				Cell cellG21 = row1.createCell((short) 8);
				cellG21.setCellValue("Valid Remitter ID received");
				Cell cellG31 = row1.createCell((short) 9);
				cellG31.setCellValue("Valid Remitter account received");
				
				Cell cellG41 = row1.createCell((short) 10);
				cellG41.setCellValue("Funds Credited");
				Cell cellG51 = row1.createCell((short) 11);
				cellG51.setCellValue("Receiving A/c No");
				Cell cellG61 = row1.createCell((short) 12);
				cellG61.setCellValue("Receiving Name");
				Cell cellG71 = row1.createCell((short) 13);
				cellG71.setCellValue("Receiving A/c Type");
				Cell cellG81 = row1.createCell((short) 14);
				cellG81.setCellValue("GL");
				
				

				Cell cellH1 = row1.createCell((short) 15);
				cellH1.setCellValue("Receiver IFSC");

				
				Cell cellI1 = row1.createCell((short) 16);
		           
				cellI1.setCellValue("Upload Time");
				Cell cellG91 = row1.createCell((short) 17);
				cellG91.setCellValue("Status");
				
				

				Cell cellJ1 = row1.createCell((short) 18);
				cellJ1.setCellValue("Remitter A/c No");
				
				Cell cellK1 = row1.createCell((short) 19);
				cellK1.setCellValue("Remitter Branch");

				Cell cellL1 = row1.createCell((short) 20);
				cellL1.setCellValue("Remitter Name");
				//cellStyle = workbook.createCellStyle();
				Cell cell191 = row1.createCell((short) 21);
				cell191.setCellValue("Remitter A/c Type");
				
				
				Cell cellM1 = row1.createCell((short) 22);
		           
				cellM1.setCellValue("Remitter IFSC");
				

				Cell cellN1 = row1.createCell((short) 23);
				cellN1.setCellValue("Ref No");
				

				Cell cellO1 = row1.createCell((short) 24);
				cellO1.setCellValue("Product Type");

				Cell cellP1 = row1.createCell((short) 25);
				cellP1.setCellValue("Payment Details 1");
			
				
				Cell cellQ1 = row1.createCell((short) 26);
		           
				cellQ1.setCellValue("Payment Details 2");
				

				
				
				Cell cellS1 = row1.createCell((short) 27);
				cellS1.setCellValue("Payment Details 3");

				Cell cellT1 = row1.createCell((short) 28);
				cellT1.setCellValue("Actual Amount Received (Actual currency)");
				
				Cell cellU1 = row1.createCell((short) 29);
		        
				cellU1.setCellValue("Payment Exchange Rate");
				Cell cellV1 = row1.createCell((short) 30);
		        
				cellV1.setCellValue("Payment Currency");
				
		        
				
				

				Cell cellZ1 = row1.createCell((short) 31);
				cellZ1.setCellValue("Error code description");
				

				

				if(resSetBulkdetails!=null)
				{
					while (resSetBulkdetails.next()) {
					
						error_code = resSetBulkdetails.getString("error_reason_code");
					
						fileDetailsObj.setErrorReasonCode(error_code);
						
						recordDetailsObj.setsNo(resSetBulkdetails.getString(1));
						recordDetailsObj.setFileID(resSetBulkdetails.getString(2));
						recordDetailsObj.setBankVirtualAcctNo(resSetBulkdetails.getString(8));
						
						recordDetailsObj.setPaymentMode(resSetBulkdetails.getString(13));
						recordDetailsObj.setChequeNo(resSetBulkdetails.getString(14));
						
						recordDetailsObj.setPaymentAmt(resSetBulkdetails.getString(11));
						recordDetailsObj.setIncomingTransactionNo(resSetBulkdetails.getString(44));
						recordDetailsObj.setAmountInr(resSetBulkdetails.getString(45));
						recordDetailsObj.setRemitterName(resSetBulkdetails.getString(30));
						recordDetailsObj.setAccountNumberRBI1(resSetBulkdetails.getString(46));
						
						recordDetailsObj.setPaymentDate(resSetBulkdetails.getDate(12));
						recordDetailsObj.setInsertDate(resSetBulkdetails.getDate(23));
						
						
						
						recordDetailsObj.setReceiverIfsc(resSetBulkdetails.getString(47));
						recordDetailsObj.setRemitterIfsc(resSetBulkdetails.getString(50));
						recordDetailsObj.setRemitterAccNo(resSetBulkdetails.getString(48));
						recordDetailsObj.setRemitterBranch(resSetBulkdetails.getString(49));
						recordDetailsObj.setRefNo(resSetBulkdetails.getString(51));
						recordDetailsObj.setProductType(resSetBulkdetails.getString(52));
						recordDetailsObj.setPaymentDetails1(resSetBulkdetails.getString(53));
						recordDetailsObj.setPaymentDetails2(resSetBulkdetails.getString(54));
						recordDetailsObj.setPaymentDetails3(resSetBulkdetails.getString(55));
						
					
						recordDetailsObj.setInsertDate(resSetBulkdetails.getDate(23));
						recordDetailsObj.setCustomerName(resSetBulkdetails.getString(10));
					
						recordDetailsObj.setRemarks(resSetBulkdetails.getString(24));
					
						
						recordDetailsObj.setErrorCodeDescription(resSetBulkdetails.getString(26));
						
						recordDetailsObj.setPaymentCurrency(resSetBulkdetails.getString(38));
						recordDetailsObj.setCircle(resSetBulkdetails.getString(3));
						recordDetailsObj.setExchangeRate(resSetBulkdetails.getString(32));
					
				
							 row1 = worksheet.createRow(i);
							 
								

							Cell cellC2 = row1.createCell((short) 0);
							cellC2.setCellValue(recordDetailsObj.getChequeNo());

							Cell cellD2 = row1.createCell((short) 1);
							
							cellD2.setCellValue(recordDetailsObj.getIncomingTransactionNo());
				
							Cell cellE2 = row1.createCell((short) 2);
							CellStyle cellStyle = workbook.createCellStyle();
							CreationHelper createHelper = workbook.getCreationHelper();
							cellStyle.setDataFormat(
								    createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
							if(resSetBulkdetails.getString(12)!=null)
							cellE2.setCellValue(recordDetailsObj.getPaymentDate());
							cellE2.setCellStyle(cellStyle);
							worksheet.autoSizeColumn(2);
							
							Cell cellF2 = row1.createCell((short) 3);
							cellF2.setCellValue(recordDetailsObj.getAmountInr());
							
							
							Cell cellG2 = row1.createCell((short) 4);
							cellG2.setCellValue(recordDetailsObj.getAccountNumberRBI1());
							

							Cell cellH2 = row1.createCell((short) 5);
							cellH2.setCellValue(recordDetailsObj.getBankVirtualAcctNo());
							
										
							Cell cellI2 = row1.createCell((short) 12);
							cellI2.setCellValue(recordDetailsObj.getCustomerName());
				             
							
				             Cell cellJ2 = row1.createCell((short) 15);
				             cellJ2.setCellValue(recordDetailsObj.getReceiverIfsc());
							
							
							Cell cellK2 = row1.createCell((short) 16);
							if(resSetBulkdetails.getString(23)!=null)
							cellK2.setCellValue(recordDetailsObj.getInsertDate());
							cellK2.setCellStyle(cellStyle);
							

							Cell cellL2 = row1.createCell((short) 18);
							cellL2.setCellValue(recordDetailsObj.getRemitterAccNo());
							
												
							Cell cellM2 = row1.createCell((short) 19);
							cellM2.setCellValue(recordDetailsObj.getRemitterBranch());
				               
							
							
							Cell cellN2 = row1.createCell((short) 20);
							cellN2.setCellValue(recordDetailsObj.getRemitterName());
							
							Cell cellO2 = row1.createCell((short) 22);
							cellO2.setCellValue(recordDetailsObj.getRemitterIfsc());
							Cell cellOP2 = row1.createCell((short) 23);
							cellOP2.setCellValue(recordDetailsObj.getRefNo());

							Cell cellP2 = row1.createCell((short) 24);
							cellP2.setCellValue(recordDetailsObj.getProductType());
							
							Cell cellQ2 = row1.createCell((short) 25);
							cellQ2.setCellValue(recordDetailsObj.getPaymentDetails1());
				               
							Cell cellR2 = row1.createCell((short) 26);
							cellR2.setCellValue(recordDetailsObj.getPaymentDetails2());
							
							Cell cellS2 = row1.createCell((short) 27);
							cellS2.setCellValue(recordDetailsObj.getPaymentDetails3());

							Cell cellT2 = row1.createCell((short) 28);
							cellT2.setCellValue(recordDetailsObj.getPaymentAmt());
						
						
							Cell cellU2 = row1.createCell((short) 29);
				               
							cellU2.setCellValue(recordDetailsObj.getExchangeRate());
							
							Cell cellV2 = row1.createCell((short) 30);
							cellV2.setCellValue(recordDetailsObj.getPaymentCurrency());
							
							
							Cell cellAA2 = row1.createCell((short) 31);
							cellAA2.setCellValue(recordDetailsObj.getErrorCodeDescription());
							
							 i++;
					
					
				
				} 
				}
			try {
			workbook.write(fileOut);
			fileOut.flush();
			fileOut.close();
		} catch (IOException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}

		
	}} catch (SQLException e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		transactionManager.rollback(fileDetailsObj.getTransaction());
		fileDetailsObj.setTrStatus("false");

	}
	catch(Exception e)
	{
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		transactionManager.rollback(fileDetailsObj.getTransaction());
		fileDetailsObj.setTrStatus("false");
	}
	finally
	{
	if(callableStatement!=null)
	{
		try {
			callableStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
	}

	if(resSetBulkdetails!=null)
	{
try {
	resSetBulkdetails.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);
}
	}

	}
	final long duration = System.nanoTime() - startTime;
	//logger.info("total time of execution is" +duration);
	return fileDetailsObj;
}
@Override
public FileDetails recordCheckxlsxBankStatement(FileDetails fileDetailsObj,
		String errorFilesPath, String extension) {

	// CustomerDetails customerObj=new CustomerDetails();

	final String procedureCall = "{call ACE_CAD_BULK_PAYMENT.ace_cad_record_check(?,?,?,?,?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	String error_code;
	
	int i=1;
	CallableStatement callableStatement=null;
	BulkDetails recordDetailsObj=new BulkDetails();
	try {
      connection=fileDetailsObj.getConnection();
	
		 callableStatement = connection
				.prepareCall(procedureCall);

		callableStatement.setString(1, fileDetailsObj.getFileID());
		callableStatement.setString(2,fileDetailsObj.getVendorType());
		callableStatement.registerOutParameter(3, Types.VARCHAR);
		callableStatement.registerOutParameter(4, Types.VARCHAR);
		callableStatement.registerOutParameter(5, Types.VARCHAR);
	//	System.out.println("above");
		callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
	//	System.out.println("below");
		callableStatement.executeUpdate();
	//fileObj.getConnection().commit();
		fileDetailsObj.setTrStatus("true");
		fileDetailsObj.setErrorMsg(callableStatement.getString(3));
		fileDetailsObj.setErrorCode(callableStatement.getString(4));
	//	System.out.println((callableStatement.getString(3)));
		fileDetailsObj.setStatus(callableStatement.getString(5));
		
		resSetBulkdetails = (ResultSet) callableStatement.getObject(6);
	
	//	System.out.println("flag is........ " + fileObj.getFlag());
	
		logger.info("Status in out paramater....." + fileDetailsObj.getStatus());

		if(fileDetailsObj.getStatus()!=null){
		//resSetBulkdetails.getInt(1);
		FileOutputStream fileOut = null;
	//	System.out.println("final is" +fileObj.getFinalFileName());
		try {
			fileOut = new FileOutputStream(new File(errorFilesPath+File.separator+fileDetailsObj.getOriginalFileName()));
		} catch (FileNotFoundException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		Workbook workbook = new XSSFWorkbook();
		
		   org.apache.poi.ss.usermodel.Sheet worksheet = workbook.createSheet("Neft Error Records");
		Row row1=null;
		row1 = worksheet.createRow(0);
		Cell cellA1 = row1.createCell((short) 0);
        
		cellA1.setCellValue("UTR No");
			

		Cell cellB1 = row1.createCell((short) 1);
		cellB1.setCellValue("Incoming Transaction Ref No");
		

		Cell cellC1 = row1.createCell((short) 2);
		cellC1.setCellValue("Value date(MM/DD/YYYY)");

		Cell cellD1 = row1.createCell((short) 3);
		cellD1.setCellValue("Amount in INR");
		//cellStyle = workbook.createCellStyle();
	
		Cell cellE1 = row1.createCell((short) 4);
           
		cellE1.setCellValue("Receiving account received from RBI 1");
		

		Cell cellF1 = row1.createCell((short) 5);
		cellF1.setCellValue("Receiving account received from RBI 2");
		Cell cellG1 = row1.createCell((short) 6);
		cellG1.setCellValue("Valid Prefix Received");
		Cell cellG11 = row1.createCell((short) 7);
		cellG11.setCellValue("Valid Length Received");
		Cell cellG21 = row1.createCell((short) 8);
		cellG21.setCellValue("Valid Remitter ID received");
		Cell cellG31 = row1.createCell((short) 9);
		cellG31.setCellValue("Valid Remitter account received");
		
		Cell cellG41 = row1.createCell((short) 10);
		cellG41.setCellValue("Funds Credited");
		Cell cellG51 = row1.createCell((short) 11);
		cellG51.setCellValue("Receiving A/c No");
		Cell cellG61 = row1.createCell((short) 12);
		cellG61.setCellValue("Receiving Name");
		Cell cellG71 = row1.createCell((short) 13);
		cellG71.setCellValue("Receiving A/c Type");
		Cell cellG81 = row1.createCell((short) 14);
		cellG81.setCellValue("GL");
				
		Cell cellH1 = row1.createCell((short) 15);
		cellH1.setCellValue("Receiver IFSC");

		
		Cell cellI1 = row1.createCell((short) 16);
           
		cellI1.setCellValue("Upload Time");
		Cell cellG91 = row1.createCell((short) 17);
		cellG91.setCellValue("Status");
		
		

		Cell cellJ1 = row1.createCell((short) 18);
		cellJ1.setCellValue("Remitter A/c No");
		
		Cell cellK1 = row1.createCell((short) 19);
		cellK1.setCellValue("Remitter Branch");

		Cell cellL1 = row1.createCell((short) 20);
		cellL1.setCellValue("Remitter Name");
		//cellStyle = workbook.createCellStyle();
		Cell cell191 = row1.createCell((short) 21);
		cell191.setCellValue("Remitter A/c Type");
		
		
		Cell cellM1 = row1.createCell((short) 22);
           
		cellM1.setCellValue("Remitter IFSC");
		

		Cell cellN1 = row1.createCell((short) 23);
		cellN1.setCellValue("Ref No");
		

		Cell cellO1 = row1.createCell((short) 24);
		cellO1.setCellValue("Product Type");

		Cell cellP1 = row1.createCell((short) 25);
		cellP1.setCellValue("Payment Details 1");
	
		
		Cell cellQ1 = row1.createCell((short) 26);
           
		cellQ1.setCellValue("Payment Details 2");
		

		
		
		Cell cellS1 = row1.createCell((short) 27);
		cellS1.setCellValue("Payment Details 3");

		Cell cellT1 = row1.createCell((short) 28);
		cellT1.setCellValue("Actual Amount Received (Actual currency)");
		
		Cell cellU1 = row1.createCell((short) 29);
        
		cellU1.setCellValue("Payment Exchange Rate");
		Cell cellV1 = row1.createCell((short) 30);
        
		cellV1.setCellValue("Payment Currency");
		
        
		

		Cell cellZ1 = row1.createCell((short) 31);
		cellZ1.setCellValue("Error code description");

				if(resSetBulkdetails!=null)
				{
				
					while (resSetBulkdetails.next()) {
						//System.out.println("invoice number is " +resSetBulkdetails.getString("invoice_no"));
						error_code = resSetBulkdetails.getString("error_reason_code");
					
						fileDetailsObj.setErrorReasonCode(error_code);
						
						recordDetailsObj.setsNo(resSetBulkdetails.getString(1));
						recordDetailsObj.setFileID(resSetBulkdetails.getString(2));
						
						recordDetailsObj.setPaymentMode(resSetBulkdetails.getString(13));
						recordDetailsObj.setChequeNo(resSetBulkdetails.getString(14));
						
					recordDetailsObj.setPaymentAmt(resSetBulkdetails.getString(11));
					recordDetailsObj.setIncomingTransactionNo(resSetBulkdetails.getString(44));
						recordDetailsObj.setAmountInr(resSetBulkdetails.getString(45));
						recordDetailsObj.setRemitterName(resSetBulkdetails.getString(30));
						recordDetailsObj.setAccountNumberRBI1(resSetBulkdetails.getString(46));
						
						recordDetailsObj.setPaymentDate(resSetBulkdetails.getDate(12));
						recordDetailsObj.setInsertDate(resSetBulkdetails.getDate(23));
                      recordDetailsObj.setBankVirtualAcctNo(resSetBulkdetails.getString(8));
						
						
						
						recordDetailsObj.setReceiverIfsc(resSetBulkdetails.getString(47));
						recordDetailsObj.setRemitterIfsc(resSetBulkdetails.getString(50));
						recordDetailsObj.setRemitterAccNo(resSetBulkdetails.getString(48));
						recordDetailsObj.setRemitterBranch(resSetBulkdetails.getString(49));
						recordDetailsObj.setRefNo(resSetBulkdetails.getString(51));
						recordDetailsObj.setProductType(resSetBulkdetails.getString(52));
						recordDetailsObj.setPaymentDetails1(resSetBulkdetails.getString(53));
						recordDetailsObj.setPaymentDetails2(resSetBulkdetails.getString(54));
						recordDetailsObj.setPaymentDetails3(resSetBulkdetails.getString(55));
						
					
						recordDetailsObj.setInsertDate(resSetBulkdetails.getDate(23));
						recordDetailsObj.setCustomerName(resSetBulkdetails.getString(10));
					
						recordDetailsObj.setRemarks(resSetBulkdetails.getString(24));
					
					//	recordDetailsObj.setErrorReasonCode(resSetBulkdetails.getString(26));
						recordDetailsObj.setErrorCodeDescription(resSetBulkdetails.getString(26));
					//	fileDetailsObj.setStatus(resSetBulkdetails.getString(26));
						recordDetailsObj.setPaymentCurrency(resSetBulkdetails.getString(38));
						recordDetailsObj.setCircle(resSetBulkdetails.getString(3));
						recordDetailsObj.setExchangeRate(resSetBulkdetails.getString(32));
					
				
							 row1 = worksheet.createRow(i);
							 
							 
							 Cell cellC2 = row1.createCell((short) 0);
								cellC2.setCellValue(recordDetailsObj.getChequeNo());

								Cell cellD2 = row1.createCell((short) 1);
								
								cellD2.setCellValue(recordDetailsObj.getIncomingTransactionNo());
					
								Cell cellE2 = row1.createCell((short) 2);
								CellStyle cellStyle = workbook.createCellStyle();
								CreationHelper createHelper = workbook.getCreationHelper();
								cellStyle.setDataFormat(
									    createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
								if(resSetBulkdetails.getString(12)!=null)
								cellE2.setCellValue(recordDetailsObj.getPaymentDate());
								cellE2.setCellStyle(cellStyle);
								worksheet.autoSizeColumn(2);
								
								Cell cellF2 = row1.createCell((short) 3);
								cellF2.setCellValue(recordDetailsObj.getAmountInr());
								
								
								Cell cellG2 = row1.createCell((short) 4);
								cellG2.setCellValue(recordDetailsObj.getAccountNumberRBI1());
								

								Cell cellH2 = row1.createCell((short) 5);
								cellH2.setCellValue(recordDetailsObj.getBankVirtualAcctNo());
								
											
								Cell cellI2 = row1.createCell((short) 12);
								cellI2.setCellValue(recordDetailsObj.getCustomerName());
					             
								
					             Cell cellJ2 = row1.createCell((short) 15);
					             cellJ2.setCellValue(recordDetailsObj.getReceiverIfsc());
								
								
								Cell cellK2 = row1.createCell((short) 16);
								cellStyle.setDataFormat(
									    createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
								if(resSetBulkdetails.getString(23)!=null)
								cellK2.setCellValue(recordDetailsObj.getInsertDate());
								cellK2.setCellStyle(cellStyle);
								

								Cell cellL2 = row1.createCell((short) 18);
								cellL2.setCellValue(recordDetailsObj.getRemitterAccNo());
								
													
								Cell cellM2 = row1.createCell((short) 19);
								cellM2.setCellValue(recordDetailsObj.getRemitterBranch());
					               
								
								
								Cell cellN2 = row1.createCell((short) 20);
								cellN2.setCellValue(recordDetailsObj.getRemitterName());
								
								Cell cellO2 = row1.createCell((short) 22);
								cellO2.setCellValue(recordDetailsObj.getRemitterIfsc());
								Cell cellOP2 = row1.createCell((short) 23);
								cellOP2.setCellValue(recordDetailsObj.getRefNo());

								Cell cellP2 = row1.createCell((short) 24);
								cellP2.setCellValue(recordDetailsObj.getProductType());
								
								Cell cellQ2 = row1.createCell((short) 25);
								cellQ2.setCellValue(recordDetailsObj.getPaymentDetails1());
					               
								Cell cellR2 = row1.createCell((short) 26);
								cellR2.setCellValue(recordDetailsObj.getPaymentDetails2());
								
								Cell cellS2 = row1.createCell((short) 27);
								cellS2.setCellValue(recordDetailsObj.getPaymentDetails3());

								Cell cellT2 = row1.createCell((short) 28);
								cellT2.setCellValue(recordDetailsObj.getPaymentAmt());
							
							
								Cell cellU2 = row1.createCell((short) 29);
					               
								cellU2.setCellValue(recordDetailsObj.getExchangeRate());
								
								Cell cellV2 = row1.createCell((short) 30);
								cellV2.setCellValue(recordDetailsObj.getPaymentCurrency());
								
								
								Cell cellAA2 = row1.createCell((short) 31);
								cellAA2.setCellValue(recordDetailsObj.getErrorCodeDescription());
								
								 i++;
					//		 System.out.println("i value is"+i);
					
				
				} 
				}
			try {
			workbook.write(fileOut);
			fileOut.flush();
			fileOut.close();
		} catch (IOException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}

		
	}} catch (SQLException e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		transactionManager.rollback(fileDetailsObj.getTransaction());
		fileDetailsObj.setTrStatus("false");

	}
	catch(Exception e)
	{
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		transactionManager.rollback(fileDetailsObj.getTransaction());
		fileDetailsObj.setTrStatus("false");
	}
	finally
	{
		if(callableStatement!=null)
		{
			try {
				callableStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}

		if(resSetBulkdetails!=null)
		{
	try {
		resSetBulkdetails.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	}
	final long duration = System.nanoTime() - startTime;
	//logger.info("total time of execution is" +duration);
	return fileDetailsObj;
}
@Override
public List<BulkDetails> getCustomerAccounts(String fileId) {

	final String procedureCall = "{call AIRTL_NON_BANKABLE_PKG.AIRTL_NON_BANKABLE_PROC(?,?)}";
	Connection connection = null;
	ResultSet resultCustomerAccounts=null;
	List<BulkDetails> customerAccountsList=new ArrayList<BulkDetails>();
	CallableStatement callableStatement=null;

	try {
	
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
		//fileObj.setConnection(connection);
		connection.setAutoCommit(false);
		 callableStatement = connection
				.prepareCall(procedureCall);
		callableStatement.setString(1, fileId);
		
		
		callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
		
		
		callableStatement.executeUpdate();
		resultCustomerAccounts = (ResultSet) callableStatement.getObject(2);
		while(resultCustomerAccounts.next())
		{
			BulkDetails recordDetailsObj=new BulkDetails();
			recordDetailsObj.setsNo(resultCustomerAccounts.getString(1));
			recordDetailsObj.setFileID(resultCustomerAccounts.getString(2));
			recordDetailsObj.setCircle(resultCustomerAccounts.getString(3));
			recordDetailsObj.setAcctEXTID(resultCustomerAccounts.getString(6));
			recordDetailsObj.setDelNO(resultCustomerAccounts.getString(7));
			recordDetailsObj.setBankVirtualAcctNo(resultCustomerAccounts.getString(8));
			recordDetailsObj.setInvoiceNo(resultCustomerAccounts.getString(9));
			recordDetailsObj.setCustomerName(resultCustomerAccounts.getString(10));
			recordDetailsObj.setPaymentAmt(resultCustomerAccounts.getString(11));
			recordDetailsObj.setPaymentDate(resultCustomerAccounts.getDate(12));
			recordDetailsObj.setPaymentMode(resultCustomerAccounts.getString(13));
			recordDetailsObj.setChequeNo(resultCustomerAccounts.getString(14));
			recordDetailsObj.setBankName(resultCustomerAccounts.getString(15));
			recordDetailsObj.setChequeDate(resultCustomerAccounts.getDate(16));
			recordDetailsObj.setLockboxID(resultCustomerAccounts.getString(17));
			recordDetailsObj.setInsertDate(resultCustomerAccounts.getDate(23));
			recordDetailsObj.setRemarks(resultCustomerAccounts.getString(24));
			recordDetailsObj.setIsErrorRecord(resultCustomerAccounts.getString(25));
			recordDetailsObj.setErrorReasonCode(resultCustomerAccounts.getString(26));
			recordDetailsObj.setServiceType(resultCustomerAccounts.getString(27));
			
			recordDetailsObj.setIfscCode(resultCustomerAccounts.getString(29));
			recordDetailsObj.setRemitterName(resultCustomerAccounts.getString(30));
			
			recordDetailsObj.setBankGLCode(resultCustomerAccounts.getString(31));
			recordDetailsObj.setExchangeRate(resultCustomerAccounts.getString(32));
			recordDetailsObj.setSRNo(resultCustomerAccounts.getString(33));
			recordDetailsObj.setOrderNo(resultCustomerAccounts.getString(34));
			
			recordDetailsObj.setCircuitId(resultCustomerAccounts.getString(35));
			recordDetailsObj.setServiceNo(resultCustomerAccounts.getString(36));

			
			recordDetailsObj.setDepositSlipNo(resultCustomerAccounts.getString(37));
			recordDetailsObj.setPaymentCurrency(resultCustomerAccounts.getString(38));
			recordDetailsObj.setAnnotation(resultCustomerAccounts.getString(39));
			
			
			recordDetailsObj.setTrackingIdServ(resultCustomerAccounts.getString(41));
			recordDetailsObj.setPaymentCode(resultCustomerAccounts.getString(42));
			recordDetailsObj.setTrackingId(resultCustomerAccounts.getString(43));
			recordDetailsObj.setIncomingTransactionNo(resultCustomerAccounts.getString(44));
			recordDetailsObj.setAmountInr(resultCustomerAccounts.getString(45));
			
			recordDetailsObj.setAccountNumberRBI1(resultCustomerAccounts.getString(46));
			
			recordDetailsObj.setReceiverIfsc(resultCustomerAccounts.getString(47));
			recordDetailsObj.setRemitterAccNo(resultCustomerAccounts.getString(48));
			recordDetailsObj.setRemitterBranch(resultCustomerAccounts.getString(49));
			recordDetailsObj.setRemitterIfsc(resultCustomerAccounts.getString(50));
			
			recordDetailsObj.setRefNo(resultCustomerAccounts.getString(51));
			recordDetailsObj.setProductType(resultCustomerAccounts.getString(52));
			recordDetailsObj.setPaymentDetails1(resultCustomerAccounts.getString(53));
			recordDetailsObj.setPaymentDetails2(resultCustomerAccounts.getString(54));
			recordDetailsObj.setPaymentDetails3(resultCustomerAccounts.getString(55));
			
			customerAccountsList.add(recordDetailsObj);
		}
		
			
	//	transactionManager.commit(status);
		connection.commit();
	
	} catch (SQLException e) {
	//	transactionManager.rollback(status);
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	

	} 
	catch (Exception e) {
	//	transactionManager.rollback(status);
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		

	}
	finally {

		if (connection != null)
			try {
				connection.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		if(callableStatement!=null)
		{
			try {
				callableStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}

		if(resultCustomerAccounts!=null)
		{
	try {
		resultCustomerAccounts.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	}
	return customerAccountsList;
}

@Override
public FileDetails recordCheckxlsChequeBounce(FileDetails fileDetailsObj,
		String errorFilesPath, String extension) {

	// CustomerDetails customerObj=new CustomerDetails();

	final String procedureCall = "{call ACE_CAD_REVERSAL_PACKAGE.ace_cad_record_check(?,?,?,?,?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	String error_code;
	
	int i=1;
	CallableStatement callableStatement=null;
	
	BulkDetails recordDetailsObj=new BulkDetails();
	try {
      connection=fileDetailsObj.getConnection();
	
		 callableStatement = connection
				.prepareCall(procedureCall);

		callableStatement.setString(1, fileDetailsObj.getFileID());
		callableStatement.setString(2,fileDetailsObj.getVendorType());
		callableStatement.registerOutParameter(3, Types.VARCHAR);
		callableStatement.registerOutParameter(4, Types.VARCHAR);
		callableStatement.registerOutParameter(5, Types.VARCHAR);
	//	System.out.println("above");
		callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
	//	System.out.println("below");
		callableStatement.executeUpdate();
	//fileObj.getConnection().commit();
		fileDetailsObj.setTrStatus("true");
		fileDetailsObj.setErrorMsg(callableStatement.getString(3));
		fileDetailsObj.setErrorCode(callableStatement.getString(4));
	//	System.out.println((callableStatement.getString(3)));
		fileDetailsObj.setStatus(callableStatement.getString(5));
		
		resSetBulkdetails = (ResultSet) callableStatement.getObject(6);
	
	//	System.out.println("flag is........ " + fileObj.getFlag());
	
		logger.info("Status in out paramater....." + fileDetailsObj.getStatus());

		if(fileDetailsObj.getStatus()!=null){
		//resSetBulkdetails.getInt(1);
		FileOutputStream fileOut = null;
	//	System.out.println("final is" +fileObj.getFinalFileName());
		try {
			fileOut = new FileOutputStream(new File(errorFilesPath+File.separator+fileDetailsObj.getOriginalFileName()));
		} catch (FileNotFoundException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet worksheet = workbook.createSheet("Cheque Bounce Error Records");
		HSSFRow row1=null;
		row1 = worksheet.createRow(0);
		Cell cellA1 = row1.createCell((short) 0);
        
		cellA1.setCellValue("Serial No");
		

		Cell cellB1 = row1.createCell((short) 1);
		cellB1.setCellValue("Return Received dt(MM/DD/YYYY)");
		

		Cell cellC1 = row1.createCell((short) 2);
		cellC1.setCellValue("CHEQUE NO");

		Cell cellD1 = row1.createCell((short) 3);
		cellD1.setCellValue("CHEQUE DATE(MM/DD/YYYY)");
		
	
		Cell cellE1 = row1.createCell((short) 4);
           
		cellE1.setCellValue("BANK_NAME");
		
		Cell cellF11 = row1.createCell((short) 5);
		cellF11.setCellValue("Chq Amount");
		Cell cellF1 = row1.createCell((short) 6);
		cellF1.setCellValue("Bank Account Number");

		Cell cellG1 = row1.createCell((short) 7);
		cellG1.setCellValue("Return_Reason");

		Cell cellZ1 = row1.createCell((short) 8);
		cellZ1.setCellValue("Error code description");
		
		
		
		if(resSetBulkdetails!=null)
		{
			while (resSetBulkdetails.next()) {
				//System.out.println("invoice number is " +resSetBulkdetails.getString("invoice_no"));
				error_code = resSetBulkdetails.getString("error_reason_code");
			
				fileDetailsObj.setErrorReasonCode(error_code);
				recordDetailsObj.setsNo(resSetBulkdetails.getString(1));
				
				recordDetailsObj.setAcctEXTID(resSetBulkdetails.getString(6));
				recordDetailsObj.setTrackingId(resSetBulkdetails.getString(43));
			
				recordDetailsObj.setTrackingIdServ(resSetBulkdetails.getString(41));
				
				
				recordDetailsObj.setChequeNo(resSetBulkdetails.getString(14));
				recordDetailsObj.setChequeDate(resSetBulkdetails.getDate(16));
				recordDetailsObj.setBankName(resSetBulkdetails.getString(15));
				recordDetailsObj.setBankVirtualAcctNo(resSetBulkdetails.getString(8));
				recordDetailsObj.setRemarks(resSetBulkdetails.getString(24));
				recordDetailsObj.setPaymentDate(resSetBulkdetails.getDate(12));
				recordDetailsObj.setPaymentAmt(resSetBulkdetails.getString(11));
              recordDetailsObj.setBounceReason(resSetBulkdetails.getString(61));
			
								
			recordDetailsObj.setErrorCodeDescription(resSetBulkdetails.getString(26));
			
		
					 row1 = worksheet.createRow(i);
					 
					 
					Cell cellA2 = row1.createCell((short) 0);
	               
					cellA2.setCellValue(recordDetailsObj.getsNo());
					

					Cell cellB2 = row1.createCell((short) 1);
					CellStyle cellStyle = workbook.createCellStyle();
					CreationHelper createHelper = workbook.getCreationHelper();
					cellStyle.setDataFormat(
						    createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
				//	cellB2.setCellValue(recordDetailsObj.getChequeDate());
					cellB2.setCellStyle(cellStyle);
					if(resSetBulkdetails.getString(12)!=null)
					cellB2.setCellValue(recordDetailsObj.getPaymentDate());
					worksheet.autoSizeColumn(1);
					

					

					Cell cellC2 = row1.createCell((short) 2);
					cellC2.setCellValue(recordDetailsObj.getChequeNo());

					Cell cellD2 = row1.createCell((short) 3);
					//CellStyle cellStyle = workbook.createCellStyle();
				//	CreationHelper createHelper = workbook.getCreationHelper();
					cellStyle.setDataFormat(
						    createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
					if(resSetBulkdetails.getString(16)!=null)
					cellD2.setCellValue(recordDetailsObj.getChequeDate());
					cellD2.setCellStyle(cellStyle);
					worksheet.autoSizeColumn(3);
		
					Cell cellE2 = row1.createCell((short) 4);
				
					cellE2.setCellValue(recordDetailsObj.getBankName());
					Cell cellF12 = row1.createCell((short) 5);
					cellF12.setCellValue(recordDetailsObj.getPaymentAmt());
					
					Cell cellF2 = row1.createCell((short) 6);
					cellF2.setCellValue(recordDetailsObj.getBankVirtualAcctNo());
					
					
					Cell cellG2 = row1.createCell((short) 7);
					cellG2.setCellValue(recordDetailsObj.getBounceReason());
					

					
					Cell cellAA2 = row1.createCell((short) 8);
					cellAA2.setCellValue(recordDetailsObj.getErrorCodeDescription());
					
					
					 i++;
					 //System.out.println("i value is"+i);
				
				} 
		}
			try {
			workbook.write(fileOut);
			fileOut.flush();
			fileOut.close();
		} catch (IOException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}

		
	}} catch (SQLException e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	//	transactionManager.rollback(fileDetailsObj.getTransaction());
		fileDetailsObj.setTrStatus("false");

	}
	catch(Exception e)
	{
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	//	transactionManager.rollback(fileDetailsObj.getTransaction());
		fileDetailsObj.setTrStatus("false");
	}
	finally
	{
	if(callableStatement!=null)
	{
		try {
			callableStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
	}

	if(resSetBulkdetails!=null)
	{
try {
	resSetBulkdetails.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);
}
	}

	}
	final long duration = System.nanoTime() - startTime;
	
	return fileDetailsObj;
}
@Override
public FileDetails recordCheckxlsTransfer(FileDetails fileDetailsObj,
		String errorFilesPath, String extension) {
	final String procedureCall = "{call ACE_CAD_PAYMENT_TRANSFER_PKG.ACE_CAD_TRANSFER_RECORD_CHECK(?,?,?,?,?)}";
		Connection connection = null;
		ResultSet resSetBulkdetails = null;
		String error_code;
		//List recordList=new ArrayList();
		//Writeexcel writeExcel=new Writeexcel();
		int i=1;
		CallableStatement callableStatement=null;
		BulkDetails recordDetailsObj=new BulkDetails();
		try {
	      connection=fileDetailsObj.getConnection();
		
			 callableStatement = connection
					.prepareCall(procedureCall);

			callableStatement.setString(1, fileDetailsObj.getFileID());
			
			callableStatement.registerOutParameter(2, Types.VARCHAR);
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.registerOutParameter(4, Types.VARCHAR);
		
			callableStatement.registerOutParameter(5, OracleTypes.CURSOR);
		
			callableStatement.executeUpdate();
		
			fileDetailsObj.setErrorMsg(callableStatement.getString(2));
			fileDetailsObj.setErrorCode(callableStatement.getString(3));
			fileDetailsObj.setStatus(callableStatement.getString(4));
			resSetBulkdetails = (ResultSet) callableStatement.getObject(5);
		    logger.info("error code"+fileDetailsObj.getErrorMsg());
		
			logger.info("Status in out paramater....." + fileDetailsObj.getStatus());

			if(fileDetailsObj.getStatus()!=null){
			
			FileOutputStream fileOut = null;
			try {
				fileOut = new FileOutputStream(new File(errorFilesPath+File.separator+fileDetailsObj.getOriginalFileName()));
			} catch (FileNotFoundException e) {
				
				e.printStackTrace();
			}
			HSSFWorkbook workbook = new HSSFWorkbook();
			HSSFSheet worksheet = workbook.createSheet("Transfer Error Records");
			HSSFRow row1=null;
			row1 = worksheet.createRow(0);
			Cell cellA1 = row1.createCell((short) 0);
	        
			cellA1.setCellValue("TYPE");
			

			Cell cellB1 = row1.createCell((short) 1);
			cellB1.setCellValue("TRANSDATE");
			

			Cell cellC1 = row1.createCell((short) 2);
			cellC1.setCellValue("PAYMENTMODE");

			Cell cellD1 = row1.createCell((short) 3);
			cellD1.setCellValue("LOB");
			//cellStyle = workbook.createCellStyle();
		
			Cell cellE1 = row1.createCell((short) 4);
	           
			cellE1.setCellValue("ACCOUNT NO");
			

			Cell cellF1 = row1.createCell((short) 5);
			cellF1.setCellValue("INVOICE Number");

			Cell cellG1 = row1.createCell((short) 6);
			cellG1.setCellValue("AMOUNT");

			Cell cellZ1 = row1.createCell((short) 7);
			cellZ1.setCellValue("CHEQUE NO/TRANSACTION ID");
			

			Cell cellAC1 = row1.createCell((short) 8);
			cellAC1.setCellValue("TRACKING_ID");
			Cell cellAA1 = row1.createCell((short) 9);
			cellAA1.setCellValue("TRACKING_ID_SERV");

			Cell cellAB1 = row1.createCell((short) 10);
			cellAB1.setCellValue("COLLECTION MANAGER NAME");

			Cell cellAD1 = row1.createCell((short) 11);
			cellAD1.setCellValue("TICKET NO");
			Cell cellAE1 = row1.createCell((short) 12);
			cellAE1.setCellValue("ANNOTATION");

			Cell cellAG1 = row1.createCell((short) 13);
			cellAG1.setCellValue("ERROR DESCRIPTION");


			if(resSetBulkdetails!=null)
			{
				while (resSetBulkdetails.next()) {
					//System.out.println("invoice number is " +resSetBulkdetails.getString("invoice_no"));
				//	error_code = resSetBulkdetails.getString("error_reason_code");
				
				//	fileDetailsObj.setErrorReasonCode(error_code);
					
					recordDetailsObj.setAcctEXTID(resSetBulkdetails.getString(6));
					recordDetailsObj.setTrackingId(resSetBulkdetails.getString(43));
					recordDetailsObj.setTransferType(resSetBulkdetails.getString(59));
				    recordDetailsObj.setTransDate(resSetBulkdetails.getDate(12));
					recordDetailsObj.setTrackingIdServ(resSetBulkdetails.getString(41));
					recordDetailsObj.setPaymentMode(resSetBulkdetails.getString(13));
					recordDetailsObj.setServiceType(resSetBulkdetails.getString(27));
					recordDetailsObj.setInvoiceNo(resSetBulkdetails.getString(9));
					
					recordDetailsObj.setPaymentDate(resSetBulkdetails.getDate(12));
					recordDetailsObj.setPaymentAmt(resSetBulkdetails.getString(11));
					recordDetailsObj.setChequeNo(resSetBulkdetails.getString(14));
					
				    recordDetailsObj.setAnnotation(resSetBulkdetails.getString(39));
				    recordDetailsObj.setCustomerName(resSetBulkdetails.getString(58));
							
					recordDetailsObj.setTicketNo(resSetBulkdetails.getString(57));
				
					recordDetailsObj.setServiceNo(resSetBulkdetails.getString(36));
				recordDetailsObj.setInsertDate(resSetBulkdetails.getDate(23));
				
									
				recordDetailsObj.setErrorCodeDescription(resSetBulkdetails.getString(26));
				
			
						 row1 = worksheet.createRow(i);
						 
						 
						Cell cellA2 = row1.createCell((short) 0);
		               
						cellA2.setCellValue(recordDetailsObj.getTransferType());
						

						Cell cellB2 = row1.createCell((short) 1);
						CellStyle cellStyle = workbook.createCellStyle();
						CreationHelper createHelper = workbook.getCreationHelper();
						cellStyle.setDataFormat(
						    createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
					//	cellB2.setCellValue(recordDetailsObj.getPaymentDate());
						if(resSetBulkdetails.getString(12)!=null)
						cellB2.setCellValue(recordDetailsObj.getPaymentDate());
						cellB2.setCellStyle(cellStyle);
						worksheet.autoSizeColumn(1);
						

						Cell cellC2 = row1.createCell((short) 2);
						cellC2.setCellValue(recordDetailsObj.getPaymentMode());

						Cell cellD2 = row1.createCell((short) 3);
						
						cellD2.setCellValue(recordDetailsObj.getServiceType());
			
						Cell cellE2 = row1.createCell((short) 4);
					
						cellE2.setCellValue(recordDetailsObj.getAcctEXTID());
						
						Cell cellF2 = row1.createCell((short) 5);
						cellF2.setCellValue(recordDetailsObj.getInvoiceNo());
						
						
						Cell cellG2 = row1.createCell((short) 6);
						cellG2.setCellValue(recordDetailsObj.getPaymentAmt());
						
						Cell cellH2 = row1.createCell((short) 7);
						cellH2.setCellValue(recordDetailsObj.getChequeNo());
						Cell cellI2 = row1.createCell((short) 8);
						cellI2.setCellValue(recordDetailsObj.getTrackingId());
						Cell cellJ2 = row1.createCell((short) 9);
						cellJ2.setCellValue(recordDetailsObj.getTrackingIdServ());
						Cell cellK2 = row1.createCell((short) 10);
						cellK2.setCellValue(recordDetailsObj.getCustomerName());
						Cell cellAB2 = row1.createCell((short) 11);
						cellAB2.setCellValue(recordDetailsObj.getTicketNo());
						Cell cellAA2 = row1.createCell((short) 12);
						cellAA2.setCellValue(recordDetailsObj.getAnnotation());
						
						Cell cellAC2 = row1.createCell((short) 13);
						cellAC2.setCellValue(recordDetailsObj.getErrorCodeDescription());
						
						 i++;
						 //System.out.println("i value is"+i);
					
					} }
				try {
				workbook.write(fileOut);
				fileOut.flush();
				fileOut.close();
			} catch (IOException e) {
				
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}

			
		}} catch (SQLException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
			transactionManager.rollback(fileDetailsObj.getTransaction());
			fileDetailsObj.setTrStatus("false");

		}
		catch(Exception e)
		{
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
			transactionManager.rollback(fileDetailsObj.getTransaction());
			fileDetailsObj.setTrStatus("false");
		}
		finally
		{
		if(callableStatement!=null)
		{
			try {
				callableStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}

		if(resSetBulkdetails!=null)
		{
	try {
		resSetBulkdetails.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
		}
		final long duration = System.nanoTime() - startTime;
		
		return fileDetailsObj;
	}
@Override
public FileDetails transferFileDetails(FileDetails fileDetailsObj) {


	TransactionDefinition def = new DefaultTransactionDefinition();
    TransactionStatus status = transactionManager.getTransaction(def);
    fileDetailsObj.setTransactionManager(transactionManager);
    fileDetailsObj.setTransactionDef(def);
    fileDetailsObj.setTransaction(status);
	final String procedureCall = "{call ACE_CAD_PAYMENT_TRANSFER_PKG.ACE_CAD_TRANSFER_FILE_INSERT(?,?,?,?,?,?,?,?)}";
	Connection connection = null;
	CallableStatement callableStatement=null;

	try {

		// Get Connection instance from dataSource
	//	System.out.println("connect"+ "ion:" + dataSource.getConnection());
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
		fileDetailsObj.setConnection(connection);
		connection.setAutoCommit(false);
		 callableStatement = connection
				.prepareCall(procedureCall);

		callableStatement.setString(1, fileDetailsObj.getVendorUserId());
		///callableStatement.setString(2, fileDetailsObj.getCircle());
		callableStatement.setString(2, fileDetailsObj.getOriginalFileName());
	//	System.out.println("original file in dao"+fileObj.getOriginalFileName());
		//callableStatement.setString(4, fileDetailsObj.getFinalFileName());
		callableStatement.setInt(3, fileDetailsObj.getTotalRecords());
		callableStatement.setString(4,fileDetailsObj.getFileTYpe());
	
		
	
	
		callableStatement.registerOutParameter(5, Types.VARCHAR);
		callableStatement.registerOutParameter(6, Types.VARCHAR);
		callableStatement.registerOutParameter(7, Types.VARCHAR);
		callableStatement.registerOutParameter(8, Types.VARCHAR);
		
		callableStatement.executeUpdate();
		
		fileDetailsObj.setFileID( callableStatement.getString(5));
		fileDetailsObj.setStatus(callableStatement.getString(6));
		fileDetailsObj.setErrorCode(callableStatement.getString(8));
		fileDetailsObj.setErrorMsg(callableStatement.getString(7));
		

		logger.info("file id is........ " + fileDetailsObj.getFileID());
	
		logger.info("Status ....." + fileDetailsObj.getStatus());
		
	
	} catch (SQLException e) {
		transactionManager.rollback(status);
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		fileDetailsObj.setTrStatus("false");	

	} 
	catch (Exception e) {
		transactionManager.rollback(status);
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		fileDetailsObj.setTrStatus("false");	

	}
	finally
	{
	if(callableStatement!=null)
	{
		try {
			callableStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
	}
	}
	return fileDetailsObj;
}
@Override
public List<BulkDetails> getCustomerAccountsForFileId(String fileId,
		String sessionId, String userId) {

	final String procedureCall = "{call CUST_DUMMY_ACCOUNTS_PROC(?,?,?,?,?,?,?)}";
	Connection connection = null;
	ResultSet resultCustomerAccounts=null;
	List<BulkDetails> customerAccountsList=new ArrayList<BulkDetails>();
	
	/*TransactionDefinition def = new DefaultTransactionDefinition();
    TransactionStatus status = transactionManager.getTransaction(def);*/
   // fileObj.setTransactionManager(transactionManager);

	try {
	
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
		//fileObj.setConnection(connection);
		connection.setAutoCommit(false);
		OracleCallableStatement  callableStatement = (OracleCallableStatement) connection
				.prepareCall(procedureCall);
		callableStatement.setString(1, fileId);
		
		callableStatement.setString(2,sessionId);
		callableStatement.setString(3, userId);
		callableStatement.registerOutParameter(4, OracleTypes.CURSOR);
		callableStatement.registerOutParameter(5, Types.VARCHAR);
		callableStatement.registerOutParameter(6, Types.VARCHAR);
		callableStatement.registerOutParameter(7, OracleTypes.VARCHAR);
		callableStatement.executeUpdate();
		resultCustomerAccounts=(ResultSet) callableStatement.getObject(4);
		if(resultCustomerAccounts!=null)
		while(resultCustomerAccounts.next())
		{
			//customerAccountsList=(List<BulkDetails>) resultCustomerAccounts.getObject(1);
			
			BulkDetails bulkDetailsObj=new BulkDetails();
			bulkDetailsObj.setAcctEXTID(resultCustomerAccounts.getString("ACCT_EXT_ID"));
	
			bulkDetailsObj.setAmountInr(resultCustomerAccounts.getString("AMOUNT_IN_INR"));
			bulkDetailsObj.setBankVirtualAcctNo(resultCustomerAccounts.getString("BANK_VIRTUAL_ACCOUNT_NO"));
			bulkDetailsObj.setChangeDate(resultCustomerAccounts.getDate("CHANGE_DATE"));
			bulkDetailsObj.setChangeWho(resultCustomerAccounts.getString("CHANGE_WHO"));
			
			bulkDetailsObj.setChequeDate(resultCustomerAccounts.getDate("CHEQUE_DATE"));
			bulkDetailsObj.setCircle(resultCustomerAccounts.getString("CIRCLE"));
			bulkDetailsObj.setCustomerName(resultCustomerAccounts.getString("CUSTOMER_NAME"));
			bulkDetailsObj.setCustomerType(resultCustomerAccounts.getString("CUSTOMER_TYPE"));
			bulkDetailsObj.setDelNO(resultCustomerAccounts.getString("DEL_NO"));
			bulkDetailsObj.setFileID(resultCustomerAccounts.getString("FILE_ID"));
			bulkDetailsObj.setsNo(resultCustomerAccounts.getString("S_NO"));
			bulkDetailsObj.setIncomingTransactionNo(resultCustomerAccounts.getString("INCOMING_TRANSACTION_REF_NO"));
			bulkDetailsObj.setInvoiceNo(resultCustomerAccounts.getString("INVOICE_NO"));
			bulkDetailsObj.setPaymentAmt(resultCustomerAccounts.getString("PAYMENT_AMOUNT"));
			bulkDetailsObj.setPaymentDate(resultCustomerAccounts.getDate("PAYMENT_DATE"));
			bulkDetailsObj.setPaymentDetails1(resultCustomerAccounts.getString("PAYMENT_DETAILS_1"));
			bulkDetailsObj.setPaymentDetails2(resultCustomerAccounts.getString("PAYMENT_DETAILS_2"));
			bulkDetailsObj.setPaymentDetails3(resultCustomerAccounts.getString("PAYMENT_DETAILS_3"));
			bulkDetailsObj.setPaymentMode(resultCustomerAccounts.getString("PAYMENT_MODE"));
			bulkDetailsObj.setProductType(resultCustomerAccounts.getString("PRODUCT_TYPE"));
			bulkDetailsObj.setReceiverIfsc(resultCustomerAccounts.getString("RECEIVER_IFSC"));
			bulkDetailsObj.setPaymentCurrency(resultCustomerAccounts.getString("PAYMENT_CURRENCY"));
			bulkDetailsObj.setReceivingRbI1(resultCustomerAccounts.getString("RECEIVING_ACC_RBI1"));
			bulkDetailsObj.setChequeNo(resultCustomerAccounts.getString("REF_NUMBER"));
			bulkDetailsObj.setRefNo(resultCustomerAccounts.getString("REF_NO"));
			bulkDetailsObj.setRemitterAccNo(resultCustomerAccounts.getString("REMITTER_AC_NO"));
			bulkDetailsObj.setRemitterBranch(resultCustomerAccounts.getString("REMITTER_BRANCH"));
			bulkDetailsObj.setRemitterIfsc(resultCustomerAccounts.getString("REMITTER_IFSC"));
			bulkDetailsObj.setSourceID(resultCustomerAccounts.getString("SOURCE_ID"));
			bulkDetailsObj.setTransDate(resultCustomerAccounts.getDate("TRANS_DATE"));
			
			bulkDetailsObj.setVendorTransactID(resultCustomerAccounts.getString("VENDOR_TRANSACTION_ID"));
			bulkDetailsObj.setErrorCode(resultCustomerAccounts.getString("ERROR_REASON_CODE"));
			bulkDetailsObj.setOrderNo(resultCustomerAccounts.getString("ORDER_NUMBER"));
			bulkDetailsObj.setDummyAccntNo(resultCustomerAccounts.getString("DUMMY_ACCT_NO"));
			bulkDetailsObj.setAccountType(resultCustomerAccounts.getString("ACCOUNT_TYPE"));
			bulkDetailsObj.setServiceType(resultCustomerAccounts.getString("FX_DUMMY_ACCT_LOB"));
				
			bulkDetailsObj.setLegalEntity(resultCustomerAccounts.getString("FX_DUMMY_LEGAL_ENTITY"));
			bulkDetailsObj.setValueType(resultCustomerAccounts.getString("FX_DUMMY_VALUE_TYPE"));
			bulkDetailsObj.setVipFlag(resultCustomerAccounts.getString("FX_DUMMY_VIP_FLAG"));
			bulkDetailsObj.setCustomerType(resultCustomerAccounts.getString("FX_DUMMY_CUSTOMER_TYPE"));
			bulkDetailsObj.setCustomerClass(resultCustomerAccounts.getString("FX_DUMMY_CUSTOMER_CLASS"));
			bulkDetailsObj.setB2brc(resultCustomerAccounts.getString("DERIVED_SEGMENT_B2B_B2C"));
			bulkDetailsObj.setPaymentCode(resultCustomerAccounts.getString("DERIVED_PAYMENT_CODE"));
			bulkDetailsObj.setVendorTransactID(resultCustomerAccounts.getString("VENDOR_USER_ID"));
			bulkDetailsObj.setFxAcctNo(resultCustomerAccounts.getString("FX_ACCOUNT_NO"));
			
			bulkDetailsObj.setVendorId(resultCustomerAccounts.getString("VENDOR_ID"));
			bulkDetailsObj.setSessionId(resultCustomerAccounts.getString("SESSION_ID"));
			bulkDetailsObj.setUserId(resultCustomerAccounts.getString("USER_ID"));
			bulkDetailsObj.setRemarks(resultCustomerAccounts.getString("REMARKS"));
			bulkDetailsObj.setTransferType(resultCustomerAccounts.getString("TRANSFER_TYPE"));
			bulkDetailsObj.setRecordId(resultCustomerAccounts.getString("RECORD_ID"));
			bulkDetailsObj.setAnnotation(resultCustomerAccounts.getString("ANNOTATION"));
			bulkDetailsObj.setCustomerCurrency(resultCustomerAccounts.getString("FX_CUSTOMER_CURRENCY"));
			bulkDetailsObj.setExchangeRate(resultCustomerAccounts.getString("EXCHANGE_RATE"));
			
			customerAccountsList.add(bulkDetailsObj);
			
			
		}
		
	
	} catch (SQLException e) {
		//transactionManager.rollback(status);
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	

	} 
	catch (Exception e) {
		//transactionManager.rollback(status);
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		

	}
	finally {

		if (connection != null)
			try {
				connection.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}

		if(resultCustomerAccounts!=null)
		{
	try {
		resultCustomerAccounts.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	}
	return customerAccountsList;
}
@Override
public String getPaymentCode(List<BulkDetails> customerAccountsRecords) {
	
	final String procedureCall = "{call B2B_B2C_SEG_PROC(?,?,?,?)}";
	Connection connection = null;
  String headerStatus=null;
	try {

		// Get Connection instance from dataSource
		
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
		  StructDescriptor structDescriptor = StructDescriptor.createDescriptor("PAYMENT_POSTING_OBJ", connection);

	        STRUCT[] structs = new STRUCT[customerAccountsRecords.size()];
	        for (int index = 0; index < customerAccountsRecords.size(); index++)
	        {
	        	BulkDetails bulkDetailsObj = customerAccountsRecords.get(index);
	            Object[] params = new Object[62];
	            if(bulkDetailsObj.getErrorCode()==null)
	            {
	            	bulkDetailsObj.setErrorCode("");
	            }
	            params[0] = bulkDetailsObj.getAcctEXTID();
 	            params[1] = bulkDetailsObj.getAmountInr();
 	            params[2] = bulkDetailsObj.getBankVirtualAcctNo();
 	            params[3] = bulkDetailsObj.getChangeDate();
 	            params[4] = bulkDetailsObj.getChangeWho();
 	            params[5] = bulkDetailsObj.getChequeDate();
 	            params[6] = bulkDetailsObj.getCircle();
 	            params[7] = bulkDetailsObj.getCustomerName();
 	            params[8] = bulkDetailsObj.getCustomerType();
 	            params[9] = bulkDetailsObj.getDelNO();
 	            params[10] = bulkDetailsObj.getErrorCode();
 	            params[11] = bulkDetailsObj.getFileID();
 	            params[12] = bulkDetailsObj.getsNo();
 	            params[13] = bulkDetailsObj.getRefNo();
 	            params[14] = bulkDetailsObj.getInvoiceNo();
 	            params[15] = bulkDetailsObj.getOrderNo();
 	            params[16] = bulkDetailsObj.getPaymentAmt();
 	            params[17] = bulkDetailsObj.getPaymentDate();
 	            params[18] = bulkDetailsObj.getPaymentDetails1();
 	            params[19] = bulkDetailsObj.getPaymentDetails2();
 	            params[20] = bulkDetailsObj.getPaymentDetails3();
 	            params[21] = bulkDetailsObj.getPaymentMode();
 	            params[22] = bulkDetailsObj.getProductType();
 	            
 	            params[23] = bulkDetailsObj.getReceiverIfsc();
 	            params[24] = bulkDetailsObj.getReceivingRbI1();
 	            params[25] = bulkDetailsObj.getRefNo();
 	            params[26] = bulkDetailsObj.getChequeNo();
 	            params[27] = bulkDetailsObj.getRemitterAccNo();
 	            params[28] = bulkDetailsObj.getRemitterBranch();
 	            params[29] = bulkDetailsObj.getRemitterIfsc();
 	            params[30] = bulkDetailsObj.getSourceID();  
 	            params[31] = bulkDetailsObj.getTransDate();  
 	            params[32] = bulkDetailsObj.getVendorTransactID();
 	            params[33] = bulkDetailsObj.getPaymentCurrency();
 	            params[34] = bulkDetailsObj.getExchangeRate();
 	            params[35] = bulkDetailsObj.getDummyAccntNo();
 	            params[36] = bulkDetailsObj.getAccountType();
 	            params[37] = bulkDetailsObj.getServiceType();
 	            params[38] = bulkDetailsObj.getLegalEntity();
 	            params[39] = bulkDetailsObj.getValueType();
 	            params[40] = bulkDetailsObj.getVipFlag();
 	            params[41] = bulkDetailsObj.getCustomerType();
 	            
 	            params[42] = bulkDetailsObj.getCustomerClass();
 	            params[43] = bulkDetailsObj.getB2brc();
 	            params[44] = bulkDetailsObj.getPaymentCode();
 	            params[45] = bulkDetailsObj.getFxAcctNo();
 	            params[46] = bulkDetailsObj.getCustomerCurrency();
 	            params[47] = bulkDetailsObj.getVendorTransactID();
 	            params[48] = bulkDetailsObj.getVendorId();
 	            params[49] = bulkDetailsObj.getSessionId();
 	            params[50] = bulkDetailsObj.getUserId();
 	            params[51] = bulkDetailsObj.getRemarks();
 	            params[52] = bulkDetailsObj.getRecordId();
 	            params[53] = bulkDetailsObj.getTransferType();
 	            params[54] = bulkDetailsObj.getTrackingId();
 	            params[55] = bulkDetailsObj.getTrackingIdServ();
 	            params[56] = bulkDetailsObj.getCollectionManager();
 	            params[57] = bulkDetailsObj.getTicketNo();
 	            params[58] = bulkDetailsObj.getFxStatus();
 	            params[59] = bulkDetailsObj.getTransferType();
 	            params[60] = bulkDetailsObj.getOrigBillRefResets();
 	            params[61] = bulkDetailsObj.getAnnotation();
 	           
 	           	          
	            STRUCT struct = new STRUCT(structDescriptor, connection, params);
	           
	             structs[index] = struct;
	        }
	        logger.info("length of struct"+structs.length);
	        ArrayDescriptor desc = ArrayDescriptor.createDescriptor("PAYMENT_POSTING_TYPE",connection);
	        ARRAY oracleArray = new ARRAY(desc, connection, structs);
	       
			
		
		
		CallableStatement callableStatement = connection
				.prepareCall(procedureCall);
		
		//callableStatement.setString(1,fileType);
		
		//callableStatement.setString(2,fileName);
			
		callableStatement.setArray(1,oracleArray);
		callableStatement.setString(2, customerAccountsRecords.get(0).getPaymentMode());
		callableStatement.registerOutParameter(3, Types.VARCHAR);
		
		callableStatement.registerOutParameter(4, Types.VARCHAR);
		
		callableStatement.executeUpdate();
	
		headerStatus=callableStatement.getString(4);
		logger.info("status APPROVE"+headerStatus);
		
	} catch (SQLException e) {
		headerStatus="false";
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);

	}
	catch (Exception e) {
		headerStatus="false";
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);

	}finally {

		if (connection != null)
			try {
				connection.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
	}
	return headerStatus;
	
}

@Override
public BulkDetails getAccountDetails(BulkDetails bulkDetailsObj) {

	final String procedureCall = "select * from AIRTL_EAI_ACCT_DETAILS_TEMP  WHERE LOB=?";
	Connection connection = null;
	ResultSet resultCustomerAccounts=null;
	List<BulkDetails> customerAccountsList=new ArrayList<BulkDetails>();
	PreparedStatement callableStatement=null;
	/*TransactionDefinition def = new DefaultTransactionDefinition();
    TransactionStatus status = transactionManager.getTransaction(def);*/
   // fileObj.setTransactionManager(transactionManager);

	try {
	
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
		//fileObj.setConnection(connection);
		connection.setAutoCommit(false);
		  callableStatement = connection
				.prepareCall(procedureCall);
		callableStatement.setString(1, bulkDetailsObj.getServiceType());
		
		resultCustomerAccounts=callableStatement.executeQuery();
		while(resultCustomerAccounts.next()){
			
			bulkDetailsObj.setAccountType(resultCustomerAccounts.getString("ACCOUNT_TYPE"));
			bulkDetailsObj.setCustomerType(resultCustomerAccounts.getString("CUSTOMER_TYPE"));
			bulkDetailsObj.setValueType(resultCustomerAccounts.getString("VALUE_TYPE"));
			bulkDetailsObj.setVipFlag(resultCustomerAccounts.getString("VIP_FLAG"));
			bulkDetailsObj.setCustomerClass(resultCustomerAccounts.getString("CUSTOMER_CLASS"));
			bulkDetailsObj.setLegalEntity(resultCustomerAccounts.getString("LEGAL_ENTITY"));
			
}


	} catch (SQLException e) {
		//transactionManager.rollback(status);
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	

	} 
	catch (Exception e) {
		//transactionManager.rollback(status);
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		

	}
	finally
	{
		if(callableStatement!=null)
		{
	try {
		callableStatement.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}

		if(resultCustomerAccounts!=null)
		{
	try {
		resultCustomerAccounts.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	}
	return bulkDetailsObj;
}
public FileDetails vendorDetailsNonBankable(FileDetails fileObj) {
	TransactionDefinition def = new DefaultTransactionDefinition();
    TransactionStatus status = transactionManager.getTransaction(def);
    fileObj.setTransactionManager(transactionManager);
    fileObj.setTransactionDef(def);
    fileObj.setTransaction(status);
	final String procedureCall = "{call AIRTL_NON_BANKABLE_PKG.ace_cad_file_details_insert(?,?,?,?,?,?,?,?,?,?,?,?)}";
	Connection connection = null;
	CallableStatement callableStatement=null;
	try {

		// Get Connection instance from dataSource
	//	System.out.println("connect"+ "ion:" + dataSource.getConnection());
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
		fileObj.setConnection(connection);
		connection.setAutoCommit(false);
	 callableStatement = connection
				.prepareCall(procedureCall);

		callableStatement.setString(1, fileObj.getVendorUserId());
		callableStatement.setString(2, fileObj.getCircle());
		callableStatement.setString(3, fileObj.getOriginalFileName());
	
		callableStatement.setString(4, fileObj.getFinalFileName());
		callableStatement.setInt(5, fileObj.getTotalRecords());
	
	    callableStatement.setDouble(6,Double.parseDouble(fileObj.getPaymentAmount()));
	    callableStatement.setString(7,fileObj.getFileTYpe());
	    callableStatement.setString(8,fileObj.getPaymentMode());
		
	
	
		callableStatement.registerOutParameter(9, Types.VARCHAR);
		callableStatement.registerOutParameter(10, Types.VARCHAR);
		callableStatement.registerOutParameter(11, Types.VARCHAR);
		callableStatement.registerOutParameter(12, Types.VARCHAR);
		
		callableStatement.executeUpdate();
		
		fileObj.setFileID( callableStatement.getString(9));
		fileObj.setStatus(callableStatement.getString(10));
		fileObj.setErrorCode(callableStatement.getString(12));
		fileObj.setErrorMsg(callableStatement.getString(11));
		fileObj.setTrStatus("true");
	
		logger.info("file id is........ " + fileObj.getFileID());
	
		logger.info("Status ....." + fileObj.getStatus());
		
	
	} catch (SQLException e) {
		transactionManager.rollback(status);
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	  fileObj.setTrStatus("false");	

	} 
	catch (Exception e) {
		transactionManager.rollback(status);
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		 fileObj.setTrStatus("false");	

	}
	finally
	{

		if(callableStatement!=null)
		{
	try {
		callableStatement.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
		
	
	}
	return fileObj;
}
@Override
public String transferPushing(List<Transfer> transferList) {
	
	final String procedureCall = "{call TRANSFER_B2B_B2C_SEG_PROC(?,?,?,?)}";
	Connection connection = null;
  String headerStatus=null;
 // int objectSize=transferList.get(0).getListBulkDetails().size();
	try {

		// Get Connection instance from dataSource
	//	System.out.println("connect"+ "ion:" + dataSource.getConnection());
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
		  StructDescriptor structDescriptor = StructDescriptor.createDescriptor("TRANS_PAYMENT_POSTING_OBJ", connection);

	        STRUCT[] structs = new STRUCT[transferList.size()];
	        for(int i=0;i<transferList.size();i++)
	        {
	        
	        	StructDescriptor structDescriptor1 = StructDescriptor.createDescriptor("PAYMENT_POSTING_OBJ", connection);
	        	 STRUCT[] reversalStruct = new STRUCT[1];
	        	  BulkDetails bulkDetailsObj=transferList.get(i).getBulkObj();
	 	            Object[] params = new Object[59];
	 	            if(bulkDetailsObj.getErrorCode()==null)
	 	            {
	 	            	bulkDetailsObj.setErrorCode("");
	 	            }
	 	            params[0] = bulkDetailsObj.getAcctEXTID();
	 	            params[1] = bulkDetailsObj.getAmountInr();
	 	            params[2] = bulkDetailsObj.getBankVirtualAcctNo();
	 	            params[3] = bulkDetailsObj.getChangeDate();
	 	            params[4] = bulkDetailsObj.getChangeWho();
	 	            params[5] = bulkDetailsObj.getChequeDate();
	 	            params[6] = bulkDetailsObj.getCircle();
	 	            params[7] = bulkDetailsObj.getCustomerName();
	 	            params[8] = bulkDetailsObj.getCustomerType();
	 	            params[9] = bulkDetailsObj.getDelNO();
	 	            params[10] = bulkDetailsObj.getErrorCode();
	 	            params[11] = bulkDetailsObj.getFileID();
	 	            params[12] = bulkDetailsObj.getsNo();
	 	            params[13] = bulkDetailsObj.getRefNo();
	 	            params[14] = bulkDetailsObj.getInvoiceNo();
	 	            params[15] = bulkDetailsObj.getOrderNo();
	 	            params[16] = bulkDetailsObj.getPaymentAmt();
	 	            params[17] = bulkDetailsObj.getPaymentDate();
	 	            params[18] = bulkDetailsObj.getPaymentDetails1();
	 	            params[19] = bulkDetailsObj.getPaymentDetails2();
	 	            params[20] = bulkDetailsObj.getPaymentDetails3();
	 	            params[21] = bulkDetailsObj.getPaymentMode();
	 	            params[22] = bulkDetailsObj.getProductType();
	 	            
	 	            params[23] = bulkDetailsObj.getReceiverIfsc();
	 	            params[24] = bulkDetailsObj.getReceivingRbI1();
	 	            params[25] = bulkDetailsObj.getRefNo();
	 	            params[26] = bulkDetailsObj.getChequeNo();
	 	            params[27] = bulkDetailsObj.getRemitterAccNo();
	 	            params[28] = bulkDetailsObj.getRemitterBranch();
	 	            params[29] = bulkDetailsObj.getRemitterIfsc();
	 	            params[30] = bulkDetailsObj.getSourceID();  
	 	            params[31] = bulkDetailsObj.getTransDate();  
	 	            params[32] = bulkDetailsObj.getVendorTransactID();
	 	            params[33] = bulkDetailsObj.getPaymentCurrency();
	 	            params[34] = bulkDetailsObj.getExchangeRate();
	 	            params[35] = bulkDetailsObj.getDummyAccntNo();
	 	            params[36] = bulkDetailsObj.getAccountType();
	 	            params[37] = bulkDetailsObj.getServiceType();
	 	            params[38] = bulkDetailsObj.getLegalEntity();
	 	            params[39] = bulkDetailsObj.getValueType();
	 	            params[40] = bulkDetailsObj.getVipFlag();
	 	            params[41] = bulkDetailsObj.getCustomerType();
	 	            
	 	            params[42] = bulkDetailsObj.getCustomerClass();
	 	            params[43] = bulkDetailsObj.getB2brc();
	 	            params[44] = bulkDetailsObj.getPaymentCode();
	 	            params[45] = bulkDetailsObj.getFxAcctNo();
	 	            params[46] = bulkDetailsObj.getCustomerCurrency();
	 	            params[47] = bulkDetailsObj.getVendorTransactID();
	 	            params[48] = bulkDetailsObj.getVendorId();
	 	            params[49] = bulkDetailsObj.getSessionId();
	 	            params[50] = bulkDetailsObj.getUserId();
	 	            params[51] = bulkDetailsObj.getRemarks();
	 	            params[52] = bulkDetailsObj.getRecordId();
	 	            params[53] = bulkDetailsObj.getTransferType();
	 	            params[54] = bulkDetailsObj.getTrackingId();
	 	            params[55] = bulkDetailsObj.getTrackingIdServ();
	 	            params[56] = bulkDetailsObj.getCollectionManager();
	 	            params[57] = bulkDetailsObj.getTicketNo();
	 	            params[58] = bulkDetailsObj.getFxStatus();
	 	     //      	System.out.println("vip flag"+params[40]); 	        	 	            		
	 	            STRUCT struct = new STRUCT(structDescriptor1, connection, params);
	 	           reversalStruct[0] = struct;
	                
	        StructDescriptor structDescriptor2 = StructDescriptor.createDescriptor("PAYMENT_POSTING_OBJ", connection);
        	
        	 STRUCT[] paymentStruct = new STRUCT[transferList.get(i).getListBulkDetails().size()];
        	 for (int index = 0; index < transferList.get(i).getListBulkDetails().size(); index++)
		        {
		        	BulkDetails bulkDetailsObj1 = transferList.get(i).getListBulkDetails().get(index);
		            Object[] params1 = new Object[59];
	 	            if(bulkDetailsObj.getErrorCode()==null)
	 	            {
	 	            	bulkDetailsObj.setErrorCode("");
	 	            }
	 	            
	 	            params1[0] = bulkDetailsObj1.getAcctEXTID();
	 	            params1[1] = bulkDetailsObj1.getAmountInr();
	 	            params1[2] = bulkDetailsObj1.getBankVirtualAcctNo();
	 	            params1[3] = bulkDetailsObj1.getChangeDate();
	 	            params1[4] = bulkDetailsObj1.getChangeWho();
	 	            params1[5] = bulkDetailsObj1.getChequeDate();
	 	            params1[6] = bulkDetailsObj1.getCircle();
	 	            params1[7] = bulkDetailsObj1.getCustomerName();
	 	            params1[8] = bulkDetailsObj1.getCustomerType();
	 	            params1[9] = bulkDetailsObj1.getDelNO();
	 	            params1[10] = bulkDetailsObj1.getErrorCode();
	 	            params1[11] = bulkDetailsObj1.getFileID();
	 	            params1[12] = bulkDetailsObj1.getsNo();
	 	            params1[13] = bulkDetailsObj1.getRefNo();
	 	            params1[14] = bulkDetailsObj1.getInvoiceNo();
	 	            params1[15] = bulkDetailsObj1.getOrderNo();
	 	            params1[16] = bulkDetailsObj1.getPaymentAmt();
	 	            params1[17] = bulkDetailsObj1.getPaymentDate();
	 	            params1[18] = bulkDetailsObj1.getPaymentDetails1();
	 	            params1[19] = bulkDetailsObj1.getPaymentDetails2();
	 	            params1[20] = bulkDetailsObj1.getPaymentDetails3();
	 	            params1[21] = bulkDetailsObj1.getPaymentMode();
	 	            params1[22] = bulkDetailsObj1.getProductType();
	 	            
	 	            params1[23] = bulkDetailsObj1.getReceiverIfsc();
	 	            params1[24] = bulkDetailsObj1.getReceivingRbI1();
	 	            params1[25] = bulkDetailsObj1.getRefNo();
	 	            params1[26] = bulkDetailsObj1.getChequeNo();
	 	            params1[27] = bulkDetailsObj1.getRemitterAccNo();
	 	            params1[28] = bulkDetailsObj1.getRemitterBranch();
	 	            params1[29] = bulkDetailsObj1.getRemitterIfsc();
	 	            params1[30] = bulkDetailsObj1.getSourceID();  
	 	            params1[31] = bulkDetailsObj1.getTransDate();  
	 	            params1[32] = bulkDetailsObj1.getVendorTransactID();
	 	            params1[33] = bulkDetailsObj1.getPaymentCurrency();
	 	            params1[34] = bulkDetailsObj1.getExchangeRate();
	 	            params1[35] = bulkDetailsObj1.getDummyAccntNo();
	 	            params1[36] = bulkDetailsObj1.getAccountType();
	 	            params1[37] = bulkDetailsObj1.getServiceType();
	 	            params1[38] = bulkDetailsObj1.getLegalEntity();
	 	            params1[39] = bulkDetailsObj1.getValueType();
	 	            params1[40] = bulkDetailsObj1.getVipFlag();
	 	            params1[41] = bulkDetailsObj1.getCustomerType();
	 	            
	 	            params1[42] = bulkDetailsObj1.getCustomerClass();
	 	            params1[43] = bulkDetailsObj1.getB2brc();
	 	            params1[44] = bulkDetailsObj1.getPaymentCode();
	 	            params1[45] = bulkDetailsObj1.getFxAcctNo();
	 	            params1[46] = bulkDetailsObj1.getCustomerCurrency();
	 	            params1[47] = bulkDetailsObj1.getVendorTransactID();
	 	            params1[48] = bulkDetailsObj1.getVendorId();
	 	            params1[49] = bulkDetailsObj1.getSessionId();
	 	            params1[50] = bulkDetailsObj1.getUserId();
	 	            params1[51] = bulkDetailsObj1.getRemarks();
	 	            params1[52] = bulkDetailsObj1.getRecordId();
	 	            params1[53] = bulkDetailsObj1.getTransferType();
	 	            params1[54] = bulkDetailsObj1.getTrackingId();
	 	            params1[55] = bulkDetailsObj1.getTrackingIdServ();
	 	            params1[56] = bulkDetailsObj1.getCollectionManager();
	 	            params1[57] = bulkDetailsObj1.getTicketNo();
	 	            params1[58] = bulkDetailsObj1.getFxStatus();
	 	          
	 	    //     	System.out.println("vip flag"+params1[40]); 	     
		            STRUCT struct1= new STRUCT(structDescriptor2, connection, params1);
		        		            
		            paymentStruct[index] = struct1;
		        }
        	 ArrayDescriptor desc = ArrayDescriptor.createDescriptor("PAYMENT_POSTING_TYPE",connection);
		        ARRAY oracleArray = new ARRAY(desc, connection, paymentStruct);        
		        /*StructDescriptor structDescriptor3 = StructDescriptor.createDescriptor("TRANS_PAYMENT_POSTING_OBJ", connection);
	        	 STRUCT[] totalStruct = new STRUCT[2];   */

		        Object[] params1 = new Object[2];
		        params1[0]=reversalStruct[0];
		        params1[1]=oracleArray;
		        STRUCT struct4 = new STRUCT(structDescriptor, connection, params1);
		        structs[i]=struct4;
	        }
	               
	    //  System.out.println("length of entire struct"+structs.length);
	        ArrayDescriptor desc = ArrayDescriptor.createDescriptor("TRANS_PAYMENT_POSTING_TYPE",connection);
	        ARRAY oracleArray = new ARRAY(desc, connection, structs);
	        
	     
		CallableStatement callableStatement = connection
				.prepareCall(procedureCall);
			
		callableStatement.setArray(1,oracleArray);
		callableStatement.setString(2, "TRANSFER");
		callableStatement.registerOutParameter(3, Types.VARCHAR);
		
		callableStatement.registerOutParameter(4, Types.VARCHAR);
		
		callableStatement.executeUpdate();
	
		headerStatus=callableStatement.getString(3);
		logger.info(" status is"+headerStatus);
		
	} catch (SQLException e) {
		headerStatus="false";
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);

	}
	catch (Exception e) {
		headerStatus="false";
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);

	}finally {

		if (connection != null)
			try {
				connection.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
	}
	return headerStatus;
	
}
@Override
public List<String> retreiveListforDropDown(String role, String userId) {
	// TODO Auto-generated method stub

	List<String> retrieveList= new ArrayList<String>();
	final String procedureCall = "{call ACE_CAD_BULK_PAYMENT.GETDROPDOWNFORPAYMENTMODE(?,?,?,?)}";
	Connection connection = null;
  String headerStatus=null;
  ResultSet resultList=null;
  String dropdown= null;
  CallableStatement callableStatement=null;
	try {

		// Get Connection instance from dataSource
	
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
						
		 callableStatement = connection
				.prepareCall(procedureCall);
		
			
		callableStatement.setString(1,userId);
		
		callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
		callableStatement.registerOutParameter(3, Types.VARCHAR);
		callableStatement.registerOutParameter(4, Types.VARCHAR);
		
		
		callableStatement.executeUpdate();
		resultList= (ResultSet) callableStatement.getObject(2);
		while(resultList.next())
		{
			dropdown=resultList.getString("PAYMENT_MODE_ALLOWED");
								
			retrieveList.add(dropdown);
		}
		
		
	} catch (SQLException e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);

	} finally {

		if (connection != null)
			try {
				connection.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}

		if(callableStatement!=null)
		{
	try {
		callableStatement.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	}
	return retrieveList;
	

}
@Override
public Map<Map<Integer, List<String>>, List<FileDetails>> reversalTracking(
		int page, String fileId, String reversalType, String userId,
		String role, String status,String fileName) {

	
	final String procedureCall = "{call ACE_CAD_REVERSAL_PACKAGE.REVERSAL_TRACKING(?,?,?,?,?,?,?,?,?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	List<String> errorDetails=new ArrayList<String>();
	Map<Integer,List<String>> totaPagesAndErrorMap=new HashMap<Integer,List<String>>();
	List<FileDetails> fileList=new ArrayList<FileDetails>();
	CallableStatement callableStatement=null;
	Map<Map<Integer,List<String>>, List<FileDetails>> fileDetailsList=new HashMap<Map<Integer,List<String>>, List<FileDetails>>();
	
	try {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
		
	 callableStatement = connection
				.prepareCall(procedureCall);
		callableStatement.setInt(1,page);
		callableStatement.setString(2,fileId);
		callableStatement.setString(3, status);
		callableStatement.setString(4,userId);
		callableStatement.setString(5, reversalType);
		callableStatement.setString(6, fileName);
		
		callableStatement.registerOutParameter(7,OracleTypes.NUMBER);
		callableStatement.registerOutParameter(8,OracleTypes.VARCHAR);
		callableStatement.registerOutParameter(9,OracleTypes.VARCHAR);
		callableStatement.registerOutParameter(10,OracleTypes.CURSOR);
	
		callableStatement.executeUpdate();
		
		int totalPages=callableStatement.getInt(7);
		String errorCode=callableStatement.getString(8);
		String errorMessage=callableStatement.getString(9);
		errorDetails.add(errorCode);
		errorDetails.add(errorMessage);
		totaPagesAndErrorMap.put(totalPages, errorDetails);
		
		resSetBulkdetails = (ResultSet) callableStatement.getObject(10);
	
		
		while (resSetBulkdetails!=null&&resSetBulkdetails.next()) {
			
			FileDetails spocDetails=new FileDetails();
			
		//	spocDetails.setOriginalFileName(resSetBulkdetails.getString("FILE_NAME"));
		//	spocDetails.setFinalFileName(resSetBulkdetails.getString("FINAL_FILE_NAME"));
			spocDetails.setFileID(resSetBulkdetails.getString("FILE_ID"));
			spocDetails.setFileTYpe(resSetBulkdetails.getString("FILE_TYPE"));
			spocDetails.setVendorUserId(resSetBulkdetails.getString("VENDOR_USERID"));
			spocDetails.setUserName(resSetBulkdetails.getString("USER_NAME"));
			spocDetails.setOriginalFileName(resSetBulkdetails.getString("ORIGINAL_FILE_NAME"));
			spocDetails.setFileAcceptanceStatus(resSetBulkdetails.getInt("FILE_ACCEPTANCE_STATUS"));
			if(spocDetails.getFileAcceptanceStatus()==1)
				spocDetails.setStatus("IN PROGRESS");
			else if(spocDetails.getFileAcceptanceStatus()==3)
				spocDetails.setStatus("PROCESSED");
			spocDetails.setCountValidRecords(resSetBulkdetails.getInt("COUNT_VALID_RECORDS"));
			spocDetails.setCountInvalidRecords(resSetBulkdetails.getInt("COUNT_INVALID_RECORDS"));
			String date=resSetBulkdetails.getString("FILE_UPLOAD_DATE");
			SimpleDateFormat dateString= new SimpleDateFormat("yyyy-MM-dd HH:mm:SS");
			SimpleDateFormat dateString1= new SimpleDateFormat("MM/dd/yyyy HH:mm:SS");
			String finalDate=dateString1.format(dateString.parse(date));
			spocDetails.setFileUploadDate(finalDate);
			//spocDetails.setFileUploadDate(resSetBulkdetails.getString("FILE_UPLOAD_DATE"));
			//spocDetails.setPaymentMode(resSetBulkdetails.getString("PAYMENT_MODE"));
			fileList.add(spocDetails);
					
		}
		fileDetailsList.put(totaPagesAndErrorMap, fileList);
	}
    catch (SQLException e) {
    	StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);

	} catch (ParseException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	} finally {

		if (connection != null)
			try {
				connection.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}

		if(callableStatement!=null)
		{
	try {
		callableStatement.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}

		if(resSetBulkdetails!=null)
		{
	try {
		resSetBulkdetails.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	
	}

	return fileDetailsList;
}
@Override
public List<String> getSupervisorEmailIds(String userId, String role) {
	
	
	final String procedureCall = "{call EMAIL_SUPERVISORS(?,?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	
	List<String> emailIdList=new ArrayList<String>();
CallableStatement callableStatement=null;
	try {

		// Get Connection instance from dataSource
	//	logger.info("connect"+ "ion:" + dataSource.getConnection());
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
	//	System.out.println("enterd into vendor insert");
		
	callableStatement = connection
				.prepareCall(procedureCall);
		//System.out.println("spoc id"+fileObj.getVendorID());
		callableStatement.setString(1, userId);
		callableStatement.setString(2, role);
	 	
	  callableStatement.registerOutParameter(3,OracleTypes.CURSOR);
		callableStatement.executeUpdate();
		
	
		
		resSetBulkdetails = (ResultSet) callableStatement.getObject(3);
		
	
		
		logger.info("resSetBulkdetails "+resSetBulkdetails);
		
		if(resSetBulkdetails==null)
		{
			logger.info("resultset is null");
			return emailIdList;
		}
		
		
		while (resSetBulkdetails.next()) {
			//FileDetails spocDetails=new FileDetails();
			emailIdList.add(resSetBulkdetails.getString("emailid"));
			
			//emailIdList.add(spocDetails);
			
		}
	}
    catch (SQLException e) {
    	StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);

	} finally {
		if (connection != null)
			try {
				connection.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}

		if(callableStatement!=null)
		{
	try {
		callableStatement.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}

		if(resSetBulkdetails!=null)
		{
	try {
		resSetBulkdetails.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	
	}

	
	return emailIdList;
	
}
@Override
public List<String> getUserMailIds(String userId, String role,
		String fileId) {
	
	
	final String procedureCall = "{call EMAIL_CAD_USER_LIU(?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	
	List<String> emailIdList=new ArrayList<String>();
	CallableStatement callableStatement=null;

	try {

		// Get Connection instance from dataSource
	//	logger.info("connect"+ "ion:" + dataSource.getConnection());
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
	//	System.out.println("enterd into vendor insert");
		
		 callableStatement = connection
				.prepareCall(procedureCall);
		//System.out.println("spoc id"+fileObj.getVendorID());
	/*	ArrayDescriptor des = ArrayDescriptor.createDescriptor("HEADER_CHECK_TYPE", connection); 
		 Object[] array=fileIdsList.toArray();
		ARRAY array_to_pass = new ARRAY(des,connection,array);*/
		callableStatement.setString(1, userId);
	
	 	
	  callableStatement.registerOutParameter(2,OracleTypes.CURSOR);
		callableStatement.executeUpdate();
		
	
		
		resSetBulkdetails = (ResultSet) callableStatement.getObject(2);
		
	
		
		logger.info("resSetBulkdetails "+resSetBulkdetails);
		
		if(resSetBulkdetails==null)
		{
			logger.info("resultset is null");
			return emailIdList;
		}
		
		
		while (resSetBulkdetails.next()) {
			//FileDetails spocDetails=new FileDetails();
			//emailIdList.add(resSetBulkdetails.getString("emailid"));
		//	spocDetails.setFileID(resSetBulkdetails.getString("file_id"));
	//		spocDetails.setEmailId(resSetBulkdetails.getString("emailid"));
			emailIdList.add(resSetBulkdetails.getString("emailid"));
			
		}
	}
    catch (SQLException e) {
    	StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);

	} finally {
		if (connection != null)
			try {
				connection.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}

		if(callableStatement!=null)
		{
	try {
		callableStatement.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}

		if(resSetBulkdetails!=null)
		{
	try {
		resSetBulkdetails.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	
	}

	
	return emailIdList;
	
}
@Override
public FileDetails getCountLiu(String fileId) {
	
	
	final String procedureCall = "{call LIU_COUNT_SUM(?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	
	FileDetails mailDetails=new FileDetails();
	CallableStatement callableStatement=null;
	try {

		// Get Connection instance from dataSource
	//	logger.info("connect"+ "ion:" + dataSource.getConnection());
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
	//	System.out.println("enterd into vendor insert");
		
		 callableStatement = connection
				.prepareCall(procedureCall);
		//System.out.println("spoc id"+fileObj.getVendorID());
	/*	ArrayDescriptor des = ArrayDescriptor.createDescriptor("HEADER_CHECK_TYPE", connection); 
		 Object[] array=fileIdsList.toArray();
		ARRAY array_to_pass = new ARRAY(des,connection,array);*/
		callableStatement.setString(1, fileId);
	//	callableStatement.setString(2, fileId);
	 	
	  callableStatement.registerOutParameter(2,OracleTypes.CURSOR);
		callableStatement.executeUpdate();
		
	
		
		resSetBulkdetails = (ResultSet) callableStatement.getObject(2);
		
	
		
		logger.info("resSetBulkdetails "+resSetBulkdetails);
		
		if(resSetBulkdetails==null)
		{
			logger.info("resultset is null");
			return mailDetails;
		}
		
		
		while (resSetBulkdetails.next()) {
			
			mailDetails.setFileID(resSetBulkdetails.getString("FILE_ID"));
			mailDetails.setCountValidRecords(resSetBulkdetails.getInt("COUNT_VALID_RECORDS"));
			mailDetails.setCountInvalidRecords(resSetBulkdetails.getInt("COUNT_INVALID_RECORDS"));
			mailDetails.setValidSum(resSetBulkdetails.getDouble("VALID_SUM"));
			mailDetails.setInValidSum(resSetBulkdetails.getDouble("IN_VALID_SUM"));
			mailDetails.setPaymentMode(resSetBulkdetails.getString("PAYMENT_MODE"));
			mailDetails.setOriginalFileName(resSetBulkdetails.getString("ORIGINAL_FILE_NAME"));
			mailDetails.setTotalRecords(resSetBulkdetails.getInt("TOTAL_RECORDS"));
			mailDetails.setPaymentAmount(resSetBulkdetails.getString("N_TOTAL_AMOUNT"));
		//	emailIdList.add(mailDetails);
			//emailIdList.add(resSetBulkdetails.getString("emailid"));
		//	spocDetails.setFileID(resSetBulkdetails.getString("file_id"));
	//		spocDetails.setEmailId(resSetBulkdetails.getString("emailid"));
			//emailIdList.add(resSetBulkdetails.getString("emailid"));
			
		}
	}
    catch (SQLException e) {
    	StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);

	} finally {
		if (connection != null)
			try {
				connection.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}

		if(callableStatement!=null)
		{
	try {
		callableStatement.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}

		if(resSetBulkdetails!=null)
		{
	try {
		resSetBulkdetails.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	
	}

	
	return mailDetails;
	
}
@Override
public FileDetails getEmailUser(String fileId1) {
	
	
	final String procedureCall = "{call EMAIL_USER(?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	
	FileDetails emailDetails=new FileDetails();
	CallableStatement callableStatement=null;

	try {

		// Get Connection instance from dataSource
		//logger.info("connect"+ "ion:" + dataSource.getConnection());
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
	//	System.out.println("enterd into vendor insert");
		
		 callableStatement = connection
				.prepareCall(procedureCall);
		//System.out.println("spoc id"+fileObj.getVendorID());
		/*ArrayDescriptor des = ArrayDescriptor.createDescriptor("HEADER_CHECK_TYPE", connection); 
		 Object[] array=fileId1.toArray();
		ARRAY array_to_pass = new ARRAY(des,connection,array);*/
		callableStatement.setString(1, fileId1);
	
	 	
	  callableStatement.registerOutParameter(2,OracleTypes.CURSOR);
		callableStatement.executeUpdate();
		
	
		
		resSetBulkdetails = (ResultSet) callableStatement.getObject(2);
		
	
		
		logger.info("resSetBulkdetails "+resSetBulkdetails);
		
		if(resSetBulkdetails==null)
		{
			logger.info("resultset is null");
			return emailDetails;
		}
		
		
		while (resSetBulkdetails.next()) {
		//	FileDetails emailDetails=new FileDetails();
			emailDetails.setEmailId(resSetBulkdetails.getString("EMAILID"));
			//emailDetails.setFileID(resSetBulkdetails.getString("FILE_ID"));
			emailDetails.setOriginalFileName(resSetBulkdetails.getString("ORIGINAL_FILE_NAME"));
			//emailIdList.add(resSetBulkdetails.getString("emailid"));
		//	spocDetails.setFileID(resSetBulkdetails.getString("file_id"));
	//		spocDetails.setEmailId(resSetBulkdetails.getString("emailid"));
			//emailIdList.add(emailDetails);
			
		}
	}
    catch (SQLException e) {
    	StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);

	} finally {
		if (connection != null)
			try {
				connection.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}

		if(callableStatement!=null)
		{
	try {
		callableStatement.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}

		if(resSetBulkdetails!=null)
		{
	try {
		resSetBulkdetails.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	
	}

	
	return emailDetails;
	
}
@Override
public Map<Map<Integer, List<String>>, List<FileDetails>> transferTracking(
		int page, String fileID, String transferType, String userId,
		String role, String fxStatus,String fileName) {

	
	final String procedureCall = "{call TRANSFER_TRACKING(?,?,?,?,?,?,?,?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	List<String> errorDetails=new ArrayList<String>();
	Map<Integer,List<String>> totaPagesAndErrorMap=new HashMap<Integer,List<String>>();
	List<FileDetails> fileList=new ArrayList<FileDetails>();
	CallableStatement callableStatement=null;
	Map<Map<Integer,List<String>>, List<FileDetails>> fileDetailsList=new HashMap<Map<Integer,List<String>>, List<FileDetails>>();
	
	try {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
		
		 callableStatement = connection
				.prepareCall(procedureCall);
		callableStatement.setInt(1,page);
		callableStatement.setString(2,fileID);
		callableStatement.setString(3, fxStatus);
		callableStatement.setString(4,userId);
		callableStatement.setString(5, fileName);
		//callableStatement.setString(6, activeDate);
		
		callableStatement.registerOutParameter(6,OracleTypes.NUMBER);
		callableStatement.registerOutParameter(7,OracleTypes.VARCHAR);
		callableStatement.registerOutParameter(8,OracleTypes.VARCHAR);
		callableStatement.registerOutParameter(9,OracleTypes.CURSOR);
	
		callableStatement.executeUpdate();
		
		int totalPages=callableStatement.getInt(6);
		String errorCode=callableStatement.getString(7);
		String errorMessage=callableStatement.getString(8);
		errorDetails.add(errorCode);
		errorDetails.add(errorMessage);
		totaPagesAndErrorMap.put(totalPages, errorDetails);
		
		resSetBulkdetails = (ResultSet) callableStatement.getObject(9);
	
		
		while (resSetBulkdetails!=null&&resSetBulkdetails.next()) {
			
			FileDetails spocDetails=new FileDetails();
			
		//	spocDetails.setOriginalFileName(resSetBulkdetails.getString("FILE_NAME"));
		//	spocDetails.setFinalFileName(resSetBulkdetails.getString("FINAL_FILE_NAME"));
			spocDetails.setFileID(resSetBulkdetails.getString("FILE_ID"));
			spocDetails.setFileTYpe(resSetBulkdetails.getString("FILE_TYPE"));
			spocDetails.setVendorUserId(resSetBulkdetails.getString("VENDOR_USERID"));
			spocDetails.setUserName(resSetBulkdetails.getString("USER_NAME"));
			spocDetails.setOriginalFileName(resSetBulkdetails.getString("ORIGINAL_FILE_NAME"));
			spocDetails.setFileAcceptanceStatus(resSetBulkdetails.getInt("FILE_ACCEPTANCE_STATUS"));
			if(spocDetails.getFileAcceptanceStatus()==1)
				spocDetails.setStatus("IN PROGRESS");
			else if(spocDetails.getFileAcceptanceStatus()==3)
				spocDetails.setStatus("PROCESSED");
			spocDetails.setCountValidRecords(resSetBulkdetails.getInt("COUNT_VALID_RECORDS"));
			spocDetails.setCountInvalidRecords(resSetBulkdetails.getInt("COUNT_INVALID_RECORDS"));
			String date=resSetBulkdetails.getString("FILE_UPLOAD_DATE");
			SimpleDateFormat dateString= new SimpleDateFormat("yyyy-MM-dd HH:mm:SS");
			SimpleDateFormat dateString1= new SimpleDateFormat("MM/dd/yyyy HH:mm:SS");
			String finalDate=dateString1.format(dateString.parse(date));
			spocDetails.setFileUploadDate(finalDate);
			//spocDetails.setPaymentMode(resSetBulkdetails.getString("PAYMENT_MODE"));
			fileList.add(spocDetails);
					
		}
		fileDetailsList.put(totaPagesAndErrorMap, fileList);
	}
    catch (SQLException e) {
    	StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);

	} catch (ParseException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	} finally {

		if (connection != null)
			try {
				connection.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}

		if(callableStatement!=null)
		{
	try {
		callableStatement.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}

		if(resSetBulkdetails!=null)
		{
	try {
		resSetBulkdetails.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	
	}

	return fileDetailsList;
}
@Override
public FileDetails recordCheckxlsxChequeBounce(FileDetails fileDetailsObj,
		String errorFilesPath, String extension) {

	// CustomerDetails customerObj=new CustomerDetails();

	final String procedureCall = "{call ACE_CAD_REVERSAL_PACKAGE.ace_cad_record_check(?,?,?,?,?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	String error_code;
	//List recordList=new ArrayList();
	//Writeexcel writeExcel=new Writeexcel();
	CallableStatement callableStatement=null;
	int i=1;
	
	BulkDetails recordDetailsObj=new BulkDetails();
	try {
      connection=fileDetailsObj.getConnection();
	
     callableStatement = connection
				.prepareCall(procedureCall);

		callableStatement.setString(1, fileDetailsObj.getFileID());
		callableStatement.setString(2,fileDetailsObj.getVendorType());
		callableStatement.registerOutParameter(3, Types.VARCHAR);
		callableStatement.registerOutParameter(4, Types.VARCHAR);
		callableStatement.registerOutParameter(5, Types.VARCHAR);
	//	System.out.println("above");
		callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
	//	System.out.println("below");
		callableStatement.executeUpdate();
	//fileObj.getConnection().commit();
		fileDetailsObj.setTrStatus("true");
		fileDetailsObj.setErrorMsg(callableStatement.getString(3));
		fileDetailsObj.setErrorCode(callableStatement.getString(4));
	//	System.out.println((callableStatement.getString(3)));
		fileDetailsObj.setStatus(callableStatement.getString(5));
		
		resSetBulkdetails = (ResultSet) callableStatement.getObject(6);
	
	//	System.out.println("flag is........ " + fileObj.getFlag());
	
		logger.info("Status in out paramater....." + fileDetailsObj.getStatus());

		if(fileDetailsObj.getStatus()!=null){
		//resSetBulkdetails.getInt(1);
		FileOutputStream fileOut = null;
	//	System.out.println("final is" +fileObj.getFinalFileName());
		try {
			fileOut = new FileOutputStream(new File(errorFilesPath+File.separator+fileDetailsObj.getOriginalFileName()));
		} catch (FileNotFoundException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		Workbook workbook = new XSSFWorkbook();
		
		   org.apache.poi.ss.usermodel.Sheet worksheet = workbook.createSheet("Cheque Bounce error file");
		Row row1=null;
		row1 = worksheet.createRow(0);
			Cell cellA1 = row1.createCell((short) 0);
			        
			cellA1.setCellValue("Serial No");
			
			
			Cell cellB1 = row1.createCell((short) 1);
			cellB1.setCellValue("Return Received dt(MM/DD/YYYY)");
			
			
			Cell cellC1 = row1.createCell((short) 2);
			cellC1.setCellValue("CHEQUE NO");
			
			Cell cellD1 = row1.createCell((short) 3);
			cellD1.setCellValue("CHEQUE DATE(MM/DD/YYYY)");
			
			
			Cell cellE1 = row1.createCell((short) 4);
			   
			cellE1.setCellValue("BANK_NAME");
			
			Cell cellF11 = row1.createCell((short) 5);
			cellF11.setCellValue("Chq Amount");
			Cell cellF1 = row1.createCell((short) 6);
			cellF1.setCellValue("Bank Account Number");
			
			Cell cellG1 = row1.createCell((short) 7);
			cellG1.setCellValue("Return_Reason");
			
			Cell cellZ1 = row1.createCell((short) 8);
			cellZ1.setCellValue("Error code description");
			
		
		if(resSetBulkdetails!=null)
		{
			while (resSetBulkdetails.next()) {
				//System.out.println("invoice number is " +resSetBulkdetails.getString("invoice_no"));
				error_code = resSetBulkdetails.getString("error_reason_code");
			
				fileDetailsObj.setErrorReasonCode(error_code);
				recordDetailsObj.setsNo(resSetBulkdetails.getString(1));
				
				recordDetailsObj.setAcctEXTID(resSetBulkdetails.getString(6));
				recordDetailsObj.setTrackingId(resSetBulkdetails.getString(43));
			
				recordDetailsObj.setTrackingIdServ(resSetBulkdetails.getString(41));
				
				
				recordDetailsObj.setChequeNo(resSetBulkdetails.getString(14));
				recordDetailsObj.setChequeDate(resSetBulkdetails.getDate(16));
				recordDetailsObj.setBankName(resSetBulkdetails.getString(15));
				recordDetailsObj.setBankVirtualAcctNo(resSetBulkdetails.getString(8));
				recordDetailsObj.setRemarks(resSetBulkdetails.getString(24));
				recordDetailsObj.setPaymentDate(resSetBulkdetails.getDate(12));
		        recordDetailsObj.setPaymentAmt(resSetBulkdetails.getString(11));
              recordDetailsObj.setBounceReason(resSetBulkdetails.getString(61));
			
								
			recordDetailsObj.setErrorCodeDescription(resSetBulkdetails.getString(26));
			
		
					 row1 = worksheet.createRow(i);
					 
					 
					Cell cellA2 = row1.createCell((short) 0);
	               
					cellA2.setCellValue(recordDetailsObj.getsNo());
					

					Cell cellB2 = row1.createCell((short) 1);
					
					CreationHelper createHelper = workbook.getCreationHelper();
					CellStyle cellStyle = workbook.createCellStyle();
					cellStyle.setDataFormat(
						    createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
				//	cellD2.setCellValue(recordDetailsObj.getChequeDate());
					cellB2.setCellStyle(cellStyle);
					if(resSetBulkdetails.getString(12)!=null)
					cellB2.setCellValue(recordDetailsObj.getPaymentDate());
              		cellB2.setCellStyle(cellStyle);
					worksheet.autoSizeColumn(1);

					

					Cell cellC2 = row1.createCell((short) 2);
					cellC2.setCellValue(recordDetailsObj.getChequeNo());

					Cell cellD2 = row1.createCell((short) 3);
					cellStyle.setDataFormat(
						    createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
				//	cellD2.setCellValue(recordDetailsObj.getChequeDate());
					if(resSetBulkdetails.getString(16)!=null)
					cellD2.setCellValue(recordDetailsObj.getChequeDate());
					cellD2.setCellStyle(cellStyle);
					worksheet.autoSizeColumn(3);
		
					Cell cellE2 = row1.createCell((short) 4);
				
					cellE2.setCellValue(recordDetailsObj.getBankName());
					Cell cellF12 = row1.createCell((short) 5);
					cellF12.setCellValue(recordDetailsObj.getPaymentAmt());
					
					Cell cellF2 = row1.createCell((short) 6);
					cellF2.setCellValue(recordDetailsObj.getBankVirtualAcctNo());
					
					
					Cell cellG2 = row1.createCell((short) 7);
					cellG2.setCellValue(recordDetailsObj.getBounceReason());
					

					
					Cell cellAA2 = row1.createCell((short) 8);
					cellAA2.setCellValue(recordDetailsObj.getErrorCodeDescription());
					
					
					 i++;
					 //System.out.println("i value is"+i);
				
				} 
		}
			try {
			workbook.write(fileOut);
			fileOut.flush();
			fileOut.close();
		} catch (IOException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}

		
	}} catch (SQLException e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		//transactionManager.rollback(fileDetailsObj.getTransaction());
		fileDetailsObj.setTrStatus("false");

	}
	catch(Exception e)
	{
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		//transactionManager.rollback(fileDetailsObj.getTransaction());
		fileDetailsObj.setTrStatus("false");
	}
	
finally
{
	if(callableStatement!=null)
	{
try {
	callableStatement.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);
}
	}

	if(resSetBulkdetails!=null)
	{
try {
	resSetBulkdetails.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);
}
	}

	}

	final long duration = System.nanoTime() - startTime;
	
	return fileDetailsObj;
}
@Override
public String approveRequestNeft(String fileId,String userId) {
	final String procedureCall = "{call POSTING_PAYMENT_APPROVAL_NEFT(?,?,?,?)}";
	Connection connection = null;
	TransactionDefinition def = new DefaultTransactionDefinition();
    TransactionStatus status = transactionManager.getTransaction(def);
    String approvestatus=null;
    CallableStatement callableStatement=null;
   
	try {

		// Get Connection instance from dataSource
	//	logger.info("connect"+ "ion:" + dataSource.getConnection());
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
		connection.setAutoCommit(false);
		//System.out.println("fileId list is:"+fileIdsList.get(0));
		
		/*ArrayDescriptor des = ArrayDescriptor.createDescriptor("ARRAY_FILEID_TABLE", connection); 
		Object[] array=fileIdsList.toArray();
         System.out.println("Array Element "+array[0]);
         ARRAY array_to_pass = new ARRAY(des,connection,array);*/
          callableStatement = connection
 				.prepareCall(procedureCall);
        
      //    System.out.println("arrar"+array_to_pass.getArray().toString());
        
         callableStatement.setString(1, fileId);
         
         callableStatement.setString(2,userId);
         callableStatement.registerOutParameter(3, Types.VARCHAR);
         callableStatement.registerOutParameter(4, Types.VARCHAR);
         callableStatement.executeUpdate();
         logger.info("error msg"+callableStatement.getString(4));
         approvestatus=callableStatement.getString(4); 
        
        
         transactionManager.commit(status);
         connection.commit();
	}
	catch (SQLException e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		
		transactionManager.rollback(status);
      // return approvestatus;
	} 
	catch (Exception e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		
		transactionManager.rollback(status);
     //  return "false";
	}finally {

		if (connection != null)
			try {
				connection.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}

		if(callableStatement!=null)
		{
	try {
		callableStatement.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	}

	return approvestatus;

}
@Override
public String approveRequest(String fileId, String userId) {final String procedureCall = "{call POSTING_PAYMENT_APPROVAL(?,?,?,?)}";
Connection connection = null;
TransactionDefinition def = new DefaultTransactionDefinition();
TransactionStatus status = transactionManager.getTransaction(def);
String approvestatus=null;
CallableStatement callableStatement=null;

try {

	// Get Connection instance from dataSource
//	logger.info("connect"+ "ion:" + dataSource.getConnection());
	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
	connection = jdbcTemplate.getDataSource().getConnection();
	connection.setAutoCommit(false);
	//System.out.println("fileId list is:"+fileIdsList.get(0));
	
	/*ArrayDescriptor des = ArrayDescriptor.createDescriptor("ARRAY_FILEID_TABLE", connection); 
	Object[] array=fileIdsList.toArray();
     System.out.println("Array Element "+array[0]);
     ARRAY array_to_pass = new ARRAY(des,connection,array);*/
     callableStatement = connection
				.prepareCall(procedureCall);
    
  //    System.out.println("arrar"+array_to_pass.getArray().toString());
    
     callableStatement.setString(1, fileId);
     
     callableStatement.setString(2,userId);
     callableStatement.registerOutParameter(3, Types.VARCHAR);
     callableStatement.registerOutParameter(4, Types.VARCHAR);
     callableStatement.executeUpdate();
     logger.info("error msg"+callableStatement.getString(4));
     approvestatus=callableStatement.getString(4); 
     transactionManager.commit(status);
     connection.commit();
}
catch (SQLException e) {
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);
	
	transactionManager.rollback(status);
  // return approvestatus;
} 
catch (Exception e) {
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);
	
	transactionManager.rollback(status);
 //  return "false";
}finally {

	if (connection != null)
		try {
			connection.close();
		} catch (SQLException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}

	if(callableStatement!=null)
	{
try {
	callableStatement.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);
}
	}

}

return approvestatus;
}
@Override
public FileDetails recordCheckxlsxTransfer(FileDetails fileDetailsObj,
		String errorFilesPath, String extension) {

	// CustomerDetails customerObj=new CustomerDetails();

	final String procedureCall = "{call ACE_CAD_PAYMENT_TRANSFER_PKG.ACE_CAD_TRANSFER_RECORD_CHECK(?,?,?,?,?)}";
	Connection connection = null;
	ResultSet resSetBulkdetails = null;
	String error_code;
	//List recordList=new ArrayList();
	//Writeexcel writeExcel=new Writeexcel();
	int i=1;
	CallableStatement callableStatement=null;
	
	BulkDetails recordDetailsObj=new BulkDetails();
	try {
      connection=fileDetailsObj.getConnection();
	
 callableStatement = connection
				.prepareCall(procedureCall);

		callableStatement.setString(1, fileDetailsObj.getFileID());
		
		callableStatement.registerOutParameter(2, Types.VARCHAR);
		callableStatement.registerOutParameter(3, Types.VARCHAR);
		callableStatement.registerOutParameter(4, Types.VARCHAR);
	
		callableStatement.registerOutParameter(5, OracleTypes.CURSOR);
	
		callableStatement.executeUpdate();
	
		fileDetailsObj.setErrorMsg(callableStatement.getString(2));
		fileDetailsObj.setErrorCode(callableStatement.getString(3));
		fileDetailsObj.setStatus(callableStatement.getString(4));
		resSetBulkdetails = (ResultSet) callableStatement.getObject(5);
	    logger.info("error code"+fileDetailsObj.getErrorMsg());
	
		logger.info("Status in out paramater....." + fileDetailsObj.getStatus());

		if(fileDetailsObj.getStatus()!=null){
		
		FileOutputStream fileOut = null;
		try {
			fileOut = new FileOutputStream(new File(errorFilesPath+File.separator+fileDetailsObj.getOriginalFileName()));
		} catch (FileNotFoundException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		
		Workbook workbook = new XSSFWorkbook();
		
		   org.apache.poi.ss.usermodel.Sheet worksheet = workbook.createSheet("Transfer Error Records");
		
		Row row1=null;
		row1 = worksheet.createRow(0);
        Cell cellA1 = row1.createCell((short) 0);
        
		cellA1.setCellValue("TYPE");
		

		Cell cellB1 = row1.createCell((short) 1);
		cellB1.setCellValue("TRANSDATE");
		

		Cell cellC1 = row1.createCell((short) 2);
		cellC1.setCellValue("PAYMENTMODE");

		Cell cellD1 = row1.createCell((short) 3);
		cellD1.setCellValue("LOB");
		//cellStyle = workbook.createCellStyle();
	
		Cell cellE1 = row1.createCell((short) 4);
           
		cellE1.setCellValue("ACCOUNT NO");
		

		Cell cellF1 = row1.createCell((short) 5);
		cellF1.setCellValue("INVOICE Number");

		Cell cellG1 = row1.createCell((short) 6);
		cellG1.setCellValue("AMOUNT");

		Cell cellZ1 = row1.createCell((short) 7);
		cellZ1.setCellValue("CHEQUE NO/TRANSACTION ID");
		

		Cell cellAC1 = row1.createCell((short) 8);
		cellAC1.setCellValue("TRACKING_ID");
		Cell cellAA1 = row1.createCell((short) 9);
		cellAA1.setCellValue("TRACKING_ID_SERV");

		Cell cellAB1 = row1.createCell((short) 10);
		cellAB1.setCellValue("COLLECTION MANAGER NAME");

		Cell cellAD1 = row1.createCell((short) 11);
		cellAD1.setCellValue("TICKET NO");
		Cell cellAE1 = row1.createCell((short) 12);
		cellAE1.setCellValue("ANNOTATION");

		Cell cellAG1 = row1.createCell((short) 13);
		cellAG1.setCellValue("ERROR DESCRIPTION");


		if(resSetBulkdetails!=null)
		{
			while (resSetBulkdetails.next()) {
				//System.out.println("invoice number is " +resSetBulkdetails.getString("invoice_no"));
			//	error_code = resSetBulkdetails.getString("error_reason_code");
			
			//	fileDetailsObj.setErrorReasonCode(error_code);
				
				recordDetailsObj.setAcctEXTID(resSetBulkdetails.getString(6));
				recordDetailsObj.setTrackingId(resSetBulkdetails.getString(43));
				recordDetailsObj.setTransferType(resSetBulkdetails.getString(59));
			    recordDetailsObj.setTransDate(resSetBulkdetails.getDate(12));
				recordDetailsObj.setTrackingIdServ(resSetBulkdetails.getString(41));
				recordDetailsObj.setPaymentMode(resSetBulkdetails.getString(13));
				recordDetailsObj.setServiceType(resSetBulkdetails.getString(27));
				recordDetailsObj.setInvoiceNo(resSetBulkdetails.getString(9));
				
				recordDetailsObj.setPaymentDate(resSetBulkdetails.getDate(12));
				recordDetailsObj.setPaymentAmt(resSetBulkdetails.getString(11));
				recordDetailsObj.setChequeNo(resSetBulkdetails.getString(14));
				
			    recordDetailsObj.setAnnotation(resSetBulkdetails.getString(39));
			    recordDetailsObj.setCustomerName(resSetBulkdetails.getString(58));
						
				recordDetailsObj.setTicketNo(resSetBulkdetails.getString(57));
			
				recordDetailsObj.setServiceNo(resSetBulkdetails.getString(36));
			recordDetailsObj.setInsertDate(resSetBulkdetails.getDate(23));
			
								
			recordDetailsObj.setErrorCodeDescription(resSetBulkdetails.getString(26));
			
		
					 row1 = worksheet.createRow(i);
					 
					 
					Cell cellA2 = row1.createCell((short) 0);
	               
					cellA2.setCellValue(recordDetailsObj.getTransferType());
					

					Cell cellB2 = row1.createCell((short) 1);
					CellStyle cellStyle = workbook.createCellStyle();
					CreationHelper createHelper = workbook.getCreationHelper();
					cellStyle.setDataFormat(
					    createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
				//	cellB2.setCellValue(recordDetailsObj.getPaymentDate());
					if(resSetBulkdetails.getString(12)!=null)
					
					cellB2.setCellValue(recordDetailsObj.getPaymentDate());
					cellB2.setCellStyle(cellStyle);
					worksheet.autoSizeColumn(1);
					
					

					Cell cellC2 = row1.createCell((short) 2);
					cellC2.setCellValue(recordDetailsObj.getPaymentMode());

					Cell cellD2 = row1.createCell((short) 3);
					
					cellD2.setCellValue(recordDetailsObj.getServiceType());
		
					Cell cellE2 = row1.createCell((short) 4);
				
					cellE2.setCellValue(recordDetailsObj.getAcctEXTID());
					
					Cell cellF2 = row1.createCell((short) 5);
					cellF2.setCellValue(recordDetailsObj.getInvoiceNo());
					
					
					Cell cellG2 = row1.createCell((short) 6);
					cellG2.setCellValue(recordDetailsObj.getPaymentAmt());
					
					Cell cellH2 = row1.createCell((short) 7);
					cellH2.setCellValue(recordDetailsObj.getChequeNo());
					Cell cellI2 = row1.createCell((short) 8);
					cellI2.setCellValue(recordDetailsObj.getTrackingId());
					Cell cellJ2 = row1.createCell((short) 9);
					cellJ2.setCellValue(recordDetailsObj.getTrackingIdServ());
					Cell cellK2 = row1.createCell((short) 10);
					cellK2.setCellValue(recordDetailsObj.getCustomerName());
					Cell cellAB2 = row1.createCell((short) 11);
					cellAB2.setCellValue(recordDetailsObj.getTicketNo());
					Cell cellAA2 = row1.createCell((short) 12);
					cellAA2.setCellValue(recordDetailsObj.getAnnotation());
					
					Cell cellAC2 = row1.createCell((short) 13);
					cellAC2.setCellValue(recordDetailsObj.getErrorCodeDescription());
					
					 i++;
					
				
				} 
			}
			try {
			workbook.write(fileOut);
			fileOut.flush();
			fileOut.close();
		} catch (IOException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}

		
	}
} catch (SQLException e) {
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);
	//	transactionManager.rollback(fileDetailsObj.getTransaction());
		fileDetailsObj.setTrStatus("false");

	}
	catch(Exception e)
	{
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	//	transactionManager.rollback(fileDetailsObj.getTransaction());
		fileDetailsObj.setTrStatus("false");
	}
	finally
	{

		if(callableStatement!=null)
		{
	try {
		callableStatement.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}

		if(resSetBulkdetails!=null)
		{
	try {
		resSetBulkdetails.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	
	}
	final long duration = System.nanoTime() - startTime;
	
	return fileDetailsObj;
}
@Override
public Map<Map<Integer, List<String>>, List<FileDetails>> paymentTracking(
		int page, String fileId, String paymentMode, String userId,
		String role, String status,String fileName) {final String procedureCall = "{call PAYMENT_TRACKING(?,?,?,?,?,?,?,?,?,?)}";
		Connection connection = null;
		ResultSet resSetBulkdetails = null;
		List<String> errorDetails=new ArrayList<String>();
		Map<Integer,List<String>> totaPagesAndErrorMap=new HashMap<Integer,List<String>>();
		List<FileDetails> fileList=new ArrayList<FileDetails>();
		CallableStatement callableStatement=null;
		Map<Map<Integer,List<String>>, List<FileDetails>> fileDetailsList=new HashMap<Map<Integer,List<String>>, List<FileDetails>>();
		
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			
			 callableStatement = connection
					.prepareCall(procedureCall);
			callableStatement.setInt(1,page);
			callableStatement.setString(2,fileId);
			callableStatement.setString(3, status);
			callableStatement.setString(4,userId);
			callableStatement.setString(5, paymentMode);
			callableStatement.setString(6, fileName);
			
			callableStatement.registerOutParameter(7,OracleTypes.NUMBER);
			callableStatement.registerOutParameter(8,OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(9,OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(10,OracleTypes.CURSOR);
		
			callableStatement.executeUpdate();
			
			int totalPages=callableStatement.getInt(7);
			String errorCode=callableStatement.getString(8);
			String errorMessage=callableStatement.getString(9);
			errorDetails.add(errorCode);
			errorDetails.add(errorMessage);
			totaPagesAndErrorMap.put(totalPages, errorDetails);
			
			resSetBulkdetails = (ResultSet) callableStatement.getObject(10);
		
			
			while (resSetBulkdetails!=null&&resSetBulkdetails.next()) {
				
				FileDetails spocDetails=new FileDetails();
				
			//	spocDetails.setOriginalFileName(resSetBulkdetails.getString("FILE_NAME"));
			//	spocDetails.setFinalFileName(resSetBulkdetails.getString("FINAL_FILE_NAME"));
				spocDetails.setFileID(resSetBulkdetails.getString("FILE_ID"));
			//	spocDetails.setFileTYpe(resSetBulkdetails.getString("FILE_TYPE"));
				spocDetails.setPaymentMode(resSetBulkdetails.getString("PAYMENT_MODE"));
				spocDetails.setVendorUserId(resSetBulkdetails.getString("VENDOR_USERID"));
				spocDetails.setUserName(resSetBulkdetails.getString("USER_NAME"));
				spocDetails.setOriginalFileName(resSetBulkdetails.getString("ORIGINAL_FILE_NAME"));
				spocDetails.setFileAcceptanceStatus(resSetBulkdetails.getInt("FILE_ACCEPTANCE_STATUS"));
				if(spocDetails.getFileAcceptanceStatus()==1)
					spocDetails.setStatus("PENDING FOR APPROVAL");
				else if(spocDetails.getFileAcceptanceStatus()==3)
					spocDetails.setStatus("PROCESSED");
				else if(spocDetails.getFileAcceptanceStatus()==5||spocDetails.getFileAcceptanceStatus()==6)
					spocDetails.setStatus("PENDING FOR SYSTEM VALIDATIONS");
				else if(spocDetails.getFileAcceptanceStatus()==4)
					spocDetails.setStatus("REJECTED");
				spocDetails.setCountValidRecords(resSetBulkdetails.getInt("COUNT_VALID_RECORDS"));
				spocDetails.setCountInvalidRecords(resSetBulkdetails.getInt("COUNT_INVALID_RECORDS"));
				String date=resSetBulkdetails.getString("FILE_UPLOAD_DATE");
				SimpleDateFormat dateString= new SimpleDateFormat("yyyy-MM-dd HH:mm:SS");
				SimpleDateFormat dateString1= new SimpleDateFormat("MM/dd/yyyy HH:mm:SS");
				String finalDate=dateString1.format(dateString.parse(date));
				spocDetails.setFileUploadDate(finalDate);
				//spocDetails.setPaymentMode(resSetBulkdetails.getString("PAYMENT_MODE"));
				fileList.add(spocDetails);
						
			}
			fileDetailsList.put(totaPagesAndErrorMap, fileList);
		}
	    catch (SQLException e) {
	    	StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		} finally {

			if (connection != null)
				try {
					connection.close();
				} catch (SQLException e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}

			if(callableStatement!=null)
			{
		try {
			callableStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
			}

			if(resSetBulkdetails!=null)
			{
		try {
			resSetBulkdetails.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
			}
		
		
		}

		return fileDetailsList;
		}
@Override
public List<BulkDetails> getDirectRevTransLevelRecords(
		String fileID) {
	List<BulkDetails> PayDirectRevTransLevelDetailsList = new ArrayList<BulkDetails>();
	ResultSet resultset = null;
	Connection conn = null;
	CallableStatement callableStatement=null;
	try {
		
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		conn = jdbcTemplate.getDataSource().getConnection();
		logger.info("entered transRecords download file");
		final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_PAY_DIRECT_REV_DOWNLOAD(?,?,?)}";

		 callableStatement = conn
				.prepareCall(procedureCall);

		callableStatement.setString(1, fileID);
	

		callableStatement.registerOutParameter(2, OracleTypes.CURSOR);

		callableStatement.registerOutParameter(3, Types.VARCHAR);
		callableStatement.executeUpdate();

	

		resultset = (ResultSet) callableStatement.getObject(2);

		String statusMessage = callableStatement.getString(3);

		
		if (resultset == null) {
			logger.info("resultset is null");

		} else {

			while (resultset != null && resultset.next()) {
		
				BulkDetails PayDirectRevTransRecordsObj = new BulkDetails();
				PayDirectRevTransRecordsObj.setAcctEXTID(resultset
						.getString("ACCT_EXT_ID"));

				PayDirectRevTransRecordsObj.setTrackingId(resultset
						.getString("TRACKING_ID"));

				PayDirectRevTransRecordsObj.setTrackingIdServ(resultset
						.getString("TRACKING_ID_SERV"));
				PayDirectRevTransRecordsObj.setUserId(resultset
						.getString("VENDOR_USERID"));
				PayDirectRevTransRecordsObj.setUserName(resultset
						.getString("USER_NAME"));
				PayDirectRevTransRecordsObj.setFileID(resultset
						.getString("FILE_ID"));
				PayDirectRevTransRecordsObj.setFileName(resultset
						.getString("ORIGINAL_FILE_NAME"));
				
				String date = resultset.getString("FILE_UPLOAD_DATE");
				SimpleDateFormat dateString = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss");
				Date date1 = (Date) dateString.parse(date);
				SimpleDateFormat dateString1 = new SimpleDateFormat(
						"dd/MM/yyyy HH:mm:ss");
				String finalDate = dateString1.format(date1);
			
				PayDirectRevTransRecordsObj.setFileUploadDate(finalDate);
				
				PayDirectRevTransRecordsObj.setFxStatus(resultset
						.getString("STATUS"));
				PayDirectRevTransRecordsObj.setReason(resultset
						.getString("REASON_FOR_FAILURE"));
				
				PayDirectRevTransLevelDetailsList
						.add(PayDirectRevTransRecordsObj);

			}
		}
		

	} catch (Exception e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	} finally {
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}

		if(callableStatement!=null)
		{
	try {
		callableStatement.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}

		if(resultset!=null)
		{
	try {
		resultset.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	
	}
	return PayDirectRevTransLevelDetailsList;
}
@Override
public List<BulkDetails> getChequeBounceTransLevelRecords(String fileID) {
	
	List<BulkDetails> PayChequeBounceTransLevelDetailsList = new ArrayList<BulkDetails>();
	ResultSet resultset = null;
	Connection conn=null;
	CallableStatement callableStatement=null;
try {
	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
	conn = jdbcTemplate.getDataSource().getConnection();
	logger.info("entered transRecords download file");
	final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_PAY_REV_CHQ_BNC_DOWNLOAD(?,?,?)}";

	 callableStatement = conn
			.prepareCall(procedureCall);

	callableStatement.setString(1, fileID);
	

	callableStatement.registerOutParameter(2, OracleTypes.CURSOR);

	callableStatement.registerOutParameter(3, Types.VARCHAR);
	callableStatement.executeUpdate();

	

	resultset = (ResultSet) callableStatement.getObject(2);

	String statusMessage = callableStatement.getString(3);

	
	if (resultset == null) {
		logger.info("resultset is null");

	} else {

		while (resultset != null && resultset.next()) {
			BulkDetails PymntRevChqBounceRecordsDetailsObject = new BulkDetails();
			PymntRevChqBounceRecordsDetailsObject
			.setUserId(resultset
					.getString("VENDOR_USERID"));
	PymntRevChqBounceRecordsDetailsObject
			.setVendorName(resultset.getString("VENDOR_NAME"));
	int lob_mo = resultset.getInt("LOB_MO");
	int lob_fl = resultset.getInt("LOB_FL");
	int lob_istm = resultset.getInt("LOB_ISTM");
	
	
	if((lob_mo + lob_fl > 1) || (lob_fl + lob_istm) > 1
			|| (lob_istm + lob_mo) > 1){
		if(lob_mo>1&&lob_fl<1&&lob_istm<1){
			PymntRevChqBounceRecordsDetailsObject.setServiceType("MOB");
		}else if(lob_mo<1&&lob_fl>1&&lob_istm<1)
			PymntRevChqBounceRecordsDetailsObject.setServiceType("FL");
		else if(lob_mo<1&&lob_fl<1&&lob_istm>1)
			PymntRevChqBounceRecordsDetailsObject.setServiceType("ISTM");
		else
			PymntRevChqBounceRecordsDetailsObject.setServiceType("Multiple");
	
	}else if(lob_mo==1)
		PymntRevChqBounceRecordsDetailsObject.setServiceType("MOB");
	else if(lob_fl==1)
		PymntRevChqBounceRecordsDetailsObject.setServiceType("FL");
	else if(lob_istm==1)
		PymntRevChqBounceRecordsDetailsObject.setServiceType("ISTM");
	
	PymntRevChqBounceRecordsDetailsObject.setFileName(resultset
			.getString("REVERSAL_FILE_NAME"));
	PymntRevChqBounceRecordsDetailsObject.setRefNo(resultset
			.getString("REF_NUMBER"));
	PymntRevChqBounceRecordsDetailsObject.setBankName(resultset
			.getString("BANK_NAME"));

	String date = resultset.getString("CHEQUE_DATE");
	SimpleDateFormat dateStringChqDate = new SimpleDateFormat(
			"yyyy-MM-dd");
	SimpleDateFormat dateStringChqDate1 = new SimpleDateFormat(
			"dd/MM/yyyy");
	
	SimpleDateFormat dateString = new SimpleDateFormat(
			"yyyy-MM-dd HH:mm:ss");
	Date date1 = dateStringChqDate.parse(date);
	SimpleDateFormat dateString1 = new SimpleDateFormat(
			"dd/MM/yyyy HH:mm:ss");
	String finalDate = dateStringChqDate1.format(date1);

	PymntRevChqBounceRecordsDetailsObject
			.setDateOnChq(finalDate);

	PymntRevChqBounceRecordsDetailsObject
			.setPaymentAmt(resultset.getString("PAYMENT_AMOUNT"));

	if (resultset.getString("INITIAL_FILE_UPLOAD_DATE") != null)
			 {
		String initialUplddate = resultset
				.getString("INITIAL_FILE_UPLOAD_DATE");
		
		Date initialUplddate1 = dateString
				.parse(initialUplddate);
		
		String finalDate1 = dateString1
				.format(initialUplddate1);

		PymntRevChqBounceRecordsDetailsObject
				.setInitialUploadDate(finalDate1);
	} 

	if (resultset.getString("INITIAL_POSTED_DATE") != null)
			 {
		String initialPstddate = resultset
				.getString("INITIAL_POSTED_DATE");
		Date initialPstddate1 = dateString
				.parse(initialPstddate);
		String finalDate2 = dateString1
				.format(initialPstddate1);

		PymntRevChqBounceRecordsDetailsObject
				.setInitialPostedDate(finalDate2);
	} 	

	if (resultset.getString("BOUNCED_DATE") != null) {

		String bounceddate = resultset
				.getString("BOUNCED_DATE");
		Date bounceddate1 = dateStringChqDate.parse(bounceddate);
		String finalDate3 = dateStringChqDate1.format(bounceddate1);

		PymntRevChqBounceRecordsDetailsObject
				.setBouncedDate(finalDate3);
	} 

	if (resultset.getString("BOUNCED_MIS_DATE") != null) {

		String bouncedmisdate = resultset
				.getString("BOUNCED_MIS_DATE");
		Date bouncedmisdate1 = dateStringChqDate.parse(bouncedmisdate);
		String finalDate4 = dateStringChqDate1.format(bouncedmisdate1);

		PymntRevChqBounceRecordsDetailsObject
				.setBouncedMisDate(finalDate4);
	} 
	PymntRevChqBounceRecordsDetailsObject.setFxStatus(resultset
			.getString("CHQ_STATUS"));
			PayChequeBounceTransLevelDetailsList
					.add(PymntRevChqBounceRecordsDetailsObject);

		}
	}
	

} catch (Exception e) {
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);
} finally {
	try {
		conn.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}

	if(resultset!=null)
	{
try {
	resultset.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);
}
	}

	if(callableStatement!=null)
	{
try {
	callableStatement.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);
}
	}

}
return PayChequeBounceTransLevelDetailsList;
}
@Override
public List<BulkDetails> getPymntTransferErrorRecords(String FileId) {


	List<BulkDetails> PymntTransferErrorRecordsList = new ArrayList<BulkDetails>();
	ResultSet resultset = null;
	Connection conn=null;
	CallableStatement callableStatement=null;

	try {
		logger.info("entered PayTransferErrDetails");
		
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		conn = jdbcTemplate.getDataSource().getConnection();
		
		

		// call proc
		final String procedureCall = "{call ACE_CAD_PAGINATION_PKG.GET_PT_TRANS_DETAILS_DOWNLOAD(?,?,?)}";

		 callableStatement = conn
				.prepareCall(procedureCall);

		callableStatement.setString(1,FileId);
		callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
		callableStatement.registerOutParameter(3, Types.VARCHAR);
		
		
		callableStatement.executeUpdate();
		

		
		String statusMsg = callableStatement.getString(3);// msg

		resultset = (ResultSet) callableStatement.getObject(2);
		/* System.out.println("totalpages:" + totalPages); */
		if (resultset == null) {
			logger.info("resultset is null");

		} else {

			while (resultset != null && resultset.next()) {
				
				
				BulkDetails payTransferTransLevelBeanObject = new BulkDetails();
				payTransferTransLevelBeanObject.setChequeNo(resultset
						.getString("REF_NUMBER"));
				payTransferTransLevelBeanObject
						.setTrackingId(resultset
								.getString("TRACKING_ID"));
				payTransferTransLevelBeanObject
						.setTrackingIdServ(resultset
								.getString("TRACKING_ID_SERV"));
				payTransferTransLevelBeanObject.setTransferType(resultset
						.getString("TRANSFER_TYPE"));
				payTransferTransLevelBeanObject.setPaymentMode(resultset
						.getString("PAYMENT_MODE"));
				
				int lob_mo = resultset.getInt("LOB_MO");
				int lob_fl = resultset.getInt("LOB_FL");
				int lob_istm = resultset.getInt("LOB_ISTM");

				if((lob_mo + lob_fl > 1) || (lob_fl + lob_istm) > 1
						|| (lob_istm + lob_mo) > 1){
					if(lob_mo>1&&lob_fl<1&&lob_istm<1){
						payTransferTransLevelBeanObject.setServiceType("MOB");
					}else if(lob_mo<1&&lob_fl>1&&lob_istm<1)
						payTransferTransLevelBeanObject.setServiceType("FL");
					else if(lob_mo<1&&lob_fl<1&&lob_istm>1)
						payTransferTransLevelBeanObject.setServiceType("ISTM");
					else
						payTransferTransLevelBeanObject.setServiceType("Multiple");
				
				}else if(lob_mo==1)
					payTransferTransLevelBeanObject.setServiceType("MOB");
				else if(lob_fl==1)
					payTransferTransLevelBeanObject.setServiceType("FL");
				else if(lob_istm==1)
					payTransferTransLevelBeanObject.setServiceType("ISTM");
				
				payTransferTransLevelBeanObject.setServiceType(resultset
						.getString("ACCT_EXT_ID"));
				payTransferTransLevelBeanObject.setInvoiceNo(resultset
						.getString("INVOICE_NO"));
				payTransferTransLevelBeanObject.setPaymentAmt(resultset
						.getString("PAYMENT_AMOUNT"));
				payTransferTransLevelBeanObject
						.setUserId(resultset
								.getString("VENDOR_USERID"));
				payTransferTransLevelBeanObject.setUserName(resultset
						.getString("USER_NAME"));
				
				
				
				String date = resultset.getString("FILE_UPLOAD_DATE");
				SimpleDateFormat dateString = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss");
				Date date1 = dateString.parse(date);
				SimpleDateFormat dateString1 = new SimpleDateFormat(
						"dd/MM/yyyy HH:mm:ss");
				String finalDate = dateString1.format(date1);
				
				payTransferTransLevelBeanObject.setFileUploadDate(finalDate);
					
				payTransferTransLevelBeanObject.setFileID(resultset
						.getString("FILE_ID"));
				payTransferTransLevelBeanObject.setFileName(resultset
						.getString("ORIGINAL_FILE_NAME"));
				payTransferTransLevelBeanObject.setFxStatus(resultset
						.getString("STATUS"));
						
				
				payTransferTransLevelBeanObject
						.setReason(resultset
								.getString("REASON_FOR_FAILURE"));

				PymntTransferErrorRecordsList
						.add(payTransferTransLevelBeanObject);
			}
		}
		logger.info("list size:" + PymntTransferErrorRecordsList.size());

		
	} catch (Exception e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	} finally {
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}

		if(callableStatement!=null)
		{
	try {
		callableStatement.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}

		if(resultset!=null)
		{
	try {
		resultset.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	
	}
	return PymntTransferErrorRecordsList;

}
@Override
public List<String> getUserCircles() 
{
final String procedureCall = "{call USER_CIRCLES(?)}";
Connection connection = null;
String headerStatus=null;
ResultSet circlesSet=null;
List<String> userCircles=new ArrayList<String>();
CallableStatement callableStatement=null;
	try {

		// Get Connection instance from dataSource
		//logger.info("connect"+ "ion:" + dataSource.getConnection());
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
		
		
		 callableStatement = connection
				.prepareCall(procedureCall);
		
	
		callableStatement.registerOutParameter(1, OracleTypes.CURSOR);
		
		
		callableStatement.executeUpdate();
	
		circlesSet=(ResultSet) callableStatement.getObject(1);
		
		while(circlesSet.next())
		{
			userCircles.add(circlesSet.getString("CIRCLE"));
		}
		
	} catch (SQLException e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);

	} finally {

		if (connection != null)
			try {
				connection.close();
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}

		if(callableStatement!=null)
		{
	try {
		callableStatement.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}

		if(circlesSet!=null)
		{
	try {
		circlesSet.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
	}
		}
	
	
	}
	return userCircles;
	}
 
//Added By APS Team
	public boolean checkCircle(String cir){

		PreparedStatement prepareStatement = null;
		Connection con = null;
		ResultSet rs=null;

		StringBuffer sb = new StringBuffer("select * FROM circle_aps where market_code = '"+cir+"' and UPPER(STATUS) = 'ACTIVE'");

		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			con.setAutoCommit(false);
		} catch (Exception e) {
			//log.info(e);
		}

		boolean status = false;
		if (con != null) {
			try {
				prepareStatement = con.prepareStatement(sb.toString());
				rs = prepareStatement.executeQuery();
				try {
					if(rs!=null){
					if (rs.next()) {
						status = true;
					}
					else{
						status = false;
					}
					}
				} catch (Exception e) {
					
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
				finally{
					con.commit();
					prepareStatement.close();
					rs.close();
					con.close();
				}
			} catch (SQLException e1) {
				StringWriter errors= new StringWriter();
				e1.printStackTrace(new PrintWriter(errors));
				logger.error(errors);

			}
		}
		return status;
	}
	//Addition By APS Team Ends Here
	
	@Override
public List<String> trackingFilenameList(String userId) {
	
	List<String> trackingFilenameList=new ArrayList<String>();
	CallableStatement callableStatement=null;
	ResultSet fileNameResultSet=null;
	Connection conn=null;
	
	try 
	{
		logger.info("ENTERED FILE NAMES LIST");

		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		conn = jdbcTemplate.getDataSource().getConnection();

		final String procedureCall = "{call TRACKING_FILE_NAME_LIST(?,?,?,?)}";

		callableStatement = conn.prepareCall(procedureCall);
		callableStatement.setString(1, userId);
		callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
		callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
		callableStatement.registerOutParameter(4, OracleTypes.VARCHAR);

		callableStatement.executeUpdate();
		
		
		
	    String errorMsgFilename=callableStatement.getString(4);
	    logger.info("ERROR MESSAGE @ FILE NAME:"+errorMsgFilename);
		
		fileNameResultSet=(ResultSet) callableStatement.getObject(2);
		
		if (fileNameResultSet == null) 
        {
			logger.info("DB IS RETURNING NULL VALUES");
		}
		else
		{
	     while(fileNameResultSet.next())
	     {
	    	 trackingFilenameList.add(fileNameResultSet.getString(1));
	    	 
			      
	     }
		}
}catch (Exception e) {
	StringWriter errors= new StringWriter();
	e.printStackTrace(new PrintWriter(errors));
	logger.error(errors);
}
finally{
	if(fileNameResultSet!=null){
     	   try {
     		  fileNameResultSet.close();
			} catch (Exception e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
     	   }
	
	if(callableStatement!=null){
     	   try {
     		  callableStatement.close();
			} catch (Exception e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
     	   }
			
    	   if(conn!=null){
         	   try {
    				conn.close();
    			} catch (Exception e) {
    				StringWriter errors= new StringWriter();
    				e.printStackTrace(new PrintWriter(errors));
    				logger.error(errors);
    				}
         
         	   }
}
	return trackingFilenameList ;
}
	/*public static void main(String[] args) {
		
		String abc="asdajdh&jsdjdhbftgh";
		BulkDaoImpl b=new BulkDaoImpl();
		String a=b.validateString(abc);
		System.out.println(a);
	}*/
	//Added by Ritu
	@Override 
	public PaymentTransferDTO searchPaymentTransferRecords(String roleId,String userId,PaymentTransferDTO paymentTransferDTO) throws Exception{
		
		int totalRecords=0;
		int totalPages =0;
		int recordPerPage=10;
		ResultSet rs= null;
		Connection conn= null;
		CallableStatement callableStatement=null;
		ResultSet paymentTransferDetails =null;
		String errorCode=null; //Ritu
		String errorMsg=null; //Ritu
		List<PaymentTransferDTO> PaymentTransferList = new ArrayList<PaymentTransferDTO>();
		final String procedureCall = "{call AIRTL_PAYMENT_TRANSFER_PKG.FETCH_PAYMENT_TRANSFER_RECORDS(?,?,?,?,?,?,?,?,?,?,?,?)}";
		
		try{
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			
			callableStatement = conn.prepareCall(procedureCall);
						
			callableStatement.setString(1, paymentTransferDTO.getSearchFileId());
			callableStatement.setString(2, paymentTransferDTO.getAccountNo());
			callableStatement.setString(3, paymentTransferDTO.getLob());
			callableStatement.setString(4, paymentTransferDTO.getStatus());
			callableStatement.setString(5, paymentTransferDTO.getFile_upload_date());
			callableStatement.setInt(6, paymentTransferDTO.getCurrentPage());
			callableStatement.setString(7, userId);
			callableStatement.registerOutParameter(9, Types.INTEGER);
			callableStatement.registerOutParameter(10, Types.INTEGER);
			callableStatement.registerOutParameter(8, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(11, Types.VARCHAR);//rITU
			callableStatement.registerOutParameter(12, Types.VARCHAR);//RITU
			callableStatement.executeUpdate();
			totalRecords=  callableStatement.getInt(9);
			//recordPerPage=callableStatement.getInt(10);
			totalPages=callableStatement.getInt(10);
			rs= (ResultSet) callableStatement.getObject(8);
			errorCode = callableStatement.getString(11);//Ritu
			errorMsg = callableStatement.getString(12);//Ritu
			
			
			
			logger.info("totalPages====>"+totalPages+" totalRecords==>"+totalRecords);
		
			//paymentTransferDTO.setErrorMsg(errorMsg);
			
			paymentTransferDetails= (ResultSet) callableStatement.getObject(8);
			
			if(paymentTransferDetails ==null){
				logger.info("result set details are null ..DB is returning null values!!!");
			}else{
				
				 while (paymentTransferDetails.next()) 
				   {
					 PaymentTransferDTO paymentTransferDTO1 = new PaymentTransferDTO();					
					 String origMapString = null;
					 
					 paymentTransferDTO1.setFile_id(paymentTransferDetails.getString("FILE_ID"));
					/* paymentTransferDTO1.setFinal_file_name(paymentTransferDetails.getString("ORIGINAL_FILE_NAME"));*/						
					 paymentTransferDTO1.setFile_upload_date(paymentTransferDetails.getString("FILE_UPLOAD_DATE"));												
					 paymentTransferDTO1.setVendor_userId(paymentTransferDetails.getString("VENDOR_USERID"));
					 paymentTransferDTO1.setUploadedUserName(paymentTransferDetails.getString("USER_NAME"));
					 paymentTransferDTO1.setPayment_mode(paymentTransferDetails.getString("PAYMENT_MODE"));
					 paymentTransferDTO1.setOrigTrackingId(paymentTransferDetails.getString("ORIG_TRACKING_ID"));
					 paymentTransferDTO1.setOrigTrackingIdServ(paymentTransferDetails.getString("ORIG_TRACKING_ID_SERV"));
					 paymentTransferDTO1.setOrigTrackingTotalAmount(paymentTransferDetails.getString("TRANSFER_AMT"));
					 paymentTransferDTO1.setAccountNo(paymentTransferDetails.getString("ACCOUNT_NO"));
					 paymentTransferDTO1.setTransactionId(paymentTransferDetails.getString("TRANSACTION_ID")); //Ritu
					 paymentTransferDTO1.setB2b2c(paymentTransferDetails.getString("B2B_B2C"));
					 paymentTransferDTO1.setInvoiceNo(paymentTransferDetails.getString("INVOICE_NO"));
					 paymentTransferDTO1.setAttached_file(paymentTransferDetails.getString("ATTACHED_FILE")); 
					/* paymentTransferDTO1.setChequeNo(paymentTransferDetails.getString("UTR_NO"));*/
					 
						 paymentTransferDTO1.setAmount(paymentTransferDetails.getString("AMOUNT"));
					
					 paymentTransferDTO1.setLegalEntity(paymentTransferDetails.getString("LEGAL_ENTITY")); 
					 paymentTransferDTO1.setCadApprovalReceived(paymentTransferDetails.getString("CAD_APPROVAL_RECEIVED")); 
					 paymentTransferDTO1.setApprovedDate(paymentTransferDetails.getString("APPROVED_DATE")); 
					 paymentTransferDTO1.setApprovedBy(paymentTransferDetails.getString("APPROVED_BY")); 
					 paymentTransferDTO1.setApprovedByName(paymentTransferDetails.getString("APPROVED_NAME")); 
					 paymentTransferDTO1.setStatus(paymentTransferDetails.getString("STATUS")); 
					 paymentTransferDTO1.setStatusDesc(paymentTransferDetails.getString("STATUS_DESC")); 
					 paymentTransferDTO1.setFxPostedDate(paymentTransferDetails.getString("FX_POSTED_DATE")); 
					 paymentTransferDTO1.setFxStatus(paymentTransferDetails.getString("FX_STATUS")); 
					 paymentTransferDTO1.setFxStatusDesc(paymentTransferDetails.getString("FX_STATUS_DESC")); 
					
					 paymentTransferDTO1.setTotal_records(paymentTransferDetails.getInt("TOTAL_RECORDS"));	
					 paymentTransferDTO1.setTotalPages(totalPages);
					
					 PaymentTransferList.add(paymentTransferDTO1);
				   }
			 }
		
		}
		catch (SQLException e) {
			e.printStackTrace();
		}finally{
			if(paymentTransferDetails!=null){
				paymentTransferDetails.close();
			}
			if(callableStatement!=null)
				callableStatement.close();
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}
		}
		paymentTransferDTO.setResultPerPage(PaymentTransferList.size());
		paymentTransferDTO.setTotalResults(totalRecords);
		paymentTransferDTO.setTotalPages(totalPages);
		paymentTransferDTO.setPaymentTransferDetailList(PaymentTransferList);
		
		return paymentTransferDTO;
	
	}
	
	@Override 
	public PaymentTransferDTO downloadsPTReports(String roleId,String userId,PaymentTransferDTO paymentTransferDTO) throws Exception{
	 
		paymentTransferDTO = searchPaymentTransferRecords(roleId,userId,paymentTransferDTO);
		
		return paymentTransferDTO;
	}

		@Override 
		public PaymentTransferDTO getPaymentTransferWorkDetails(String roleId,PaymentTransferDTO paymentTransferDTO) throws Exception{		
			Connection conn = null;
			String procedureCall =null;
			int totalRecords=0;
			int totalPages =0,recordsPerPage=10;
			String errorcode = null;
			String errorMsg=null;
			boolean chkBoxStatus = false;
			String chkBoxEnabled=null;
			CallableStatement callableStatement=null;
			ResultSet paymentTransferDetails =null;
			List<PaymentTransferDTO> ApprovalDetailsList = new ArrayList<PaymentTransferDTO>();			
		
			try{
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				logger.info("connect" + "ion:" + dataSource.getConnection());
				conn = jdbcTemplate.getDataSource().getConnection();
				procedureCall = "{call AIRTL_PAYMENT_TRANSFER_PKG.PAYMENT_TRANSFER_DETAIL_SEARCH(?,?,?,?,?,?,?,?,?,?)}";

				callableStatement = conn.prepareCall(procedureCall);
				
				callableStatement.setInt(1, paymentTransferDTO.getCurrentPage());
				callableStatement.setString(2, paymentTransferDTO.getSearchUserId());
				callableStatement.setString(3, paymentTransferDTO.getSearchFileId());
				callableStatement.setString(4, paymentTransferDTO.getSearchFromDate());
				callableStatement.setString(5, paymentTransferDTO.getSearchEndDate());	
				/*callableStatement.setString(6, paymentTransferDTO.getSearchUtrNo());
				callableStatement.setString(7, paymentTransferDTO.getSearchOrigTrackingId());
				callableStatement.setString(8, paymentTransferDTO.getSearchOrigTrackingIdServ());*/
				
				callableStatement.registerOutParameter(7, Types.INTEGER);
				callableStatement.registerOutParameter(8, Types.CHAR);
				callableStatement.registerOutParameter(9, Types.CHAR);
				callableStatement.registerOutParameter(10, Types.INTEGER);
				
				callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
				callableStatement.executeUpdate();
				
				totalPages = callableStatement.getInt(7);
				errorcode= callableStatement.getString(8);
				errorMsg= callableStatement.getString(9);
				totalRecords= callableStatement.getInt(10);
				logger.info("totalPages====>"+totalPages+"   errorcode====>"+errorcode+"  errorMsg===>"+errorMsg+"  totalRecords==>"+totalRecords);
			
				paymentTransferDTO.setErrorMsg(errorMsg);
				
				paymentTransferDetails= (ResultSet) callableStatement.getObject(6);
				
				if(paymentTransferDetails ==null){
					logger.info("result set details are null ..DB is returning null values!!!");
				}else{
					
					 while (paymentTransferDetails.next())
					 {
						 PaymentTransferDTO paymentTransferDTO1 = new PaymentTransferDTO();
						 String origMapString = null;
						 
						 paymentTransferDTO1.setFile_id(paymentTransferDetails.getString("FILE_ID"));
						 paymentTransferDTO1.setFinal_file_name(paymentTransferDetails.getString("ORIGINAL_FILE_NAME"));						
						 paymentTransferDTO1.setFile_upload_date(paymentTransferDetails.getString("FILE_UPLOAD_DATE"));												
						 paymentTransferDTO1.setVendor_userId(paymentTransferDetails.getString("VENDOR_USERID"));
						 paymentTransferDTO1.setUploadedUserName(paymentTransferDetails.getString("USER_NAME"));
						// paymentTransferDTO1.setOrigTrackingId(paymentTransferDetails.getString("ORIG_TRACKING_ID"));
						// paymentTransferDTO1.setOrigTrackingIdServ(paymentTransferDetails.getString("ORIG_TRACKING_ID_SERV"));
						// paymentTransferDTO1.setChequeNo(paymentTransferDetails.getString("UTR_NO"));
						// paymentTransferDTO1.setPayment_mode(paymentTransferDetails.getString("PAYMENT_MODE"));
						 paymentTransferDTO1.setTotal_records(paymentTransferDetails.getInt("TOTAL_RECORDS"));						
						 paymentTransferDTO1.setOrigTrackingTotalAmount(paymentTransferDetails.getString("TOTAL_AMOUNT"));						 
						 paymentTransferDTO1.setAttached_file(paymentTransferDetails.getString("ATTACHED_FILE")); 
						 paymentTransferDTO1.setOrigStatus(paymentTransferDetails.getString("STATUS"));	
						// origMapString = paymentTransferDTO1.getFile_id()+"-"+paymentTransferDTO1.getOrigTrackingId()+"-"+paymentTransferDTO1.getOrigTrackingIdServ();
						 origMapString = paymentTransferDTO1.getFile_id();
						
						 paymentTransferDTO1.setOrigTrackingString(origMapString);
						 
						 chkBoxStatus = (paymentTransferDetails.getString("STATUS")).contains("APPROVAL PENDING");
						 if(chkBoxStatus)
							 chkBoxEnabled ="true";
						 else
							 chkBoxEnabled="false";
						 paymentTransferDTO1.setCheckBoxEnable(chkBoxEnabled);
						 logger.info("origMapString======>"+paymentTransferDTO1.getOrigTrackingString()
						 +":::chkBoxEnabled==>"+chkBoxEnabled+":::Status==>"+paymentTransferDTO1.getOrigStatus()+
						 ":: Final File Name===>"+paymentTransferDTO1.getFinal_file_name());
						 ApprovalDetailsList.add(paymentTransferDTO1);
					   }
					 /*  {
						 PaymentTransferDTO paymentTransferDTO1 = new PaymentTransferDTO();
						// Map <String, String> origTrackingIdMap = new HashMap <String, String>();
						 String origMapString = null;
						 
						 paymentTransferDTO1.setFile_id(paymentTransferDetails.getString("FILE_ID"));
						// paymentTransferDTO1.setFile_name(paymentTransferDetails.getString("FILE_NAME"));
						 paymentTransferDTO1.setFinal_file_name(paymentTransferDetails.getString("ORIGINAL_FILE_NAME"));						
						 paymentTransferDTO1.setFile_upload_date(paymentTransferDetails.getString("FILE_UPLOAD_DATE"));												
						 paymentTransferDTO1.setVendor_userId(paymentTransferDetails.getString("VENDOR_USERID"));
						 paymentTransferDTO1.setUploadedUserName(paymentTransferDetails.getString("USER_NAME"));
						// paymentTransferDTO1.setTotal_amount(paymentTransferDetails.getString("TOTAL_AMOUNT"));
						 paymentTransferDTO1.setOrigTrackingId(paymentTransferDetails.getString("ORIG_TRACKING_ID"));
						 paymentTransferDTO1.setOrigTrackingIdServ(paymentTransferDetails.getString("ORIG_TRACKING_ID_SERV"));
						 paymentTransferDTO1.setChequeNo(paymentTransferDetails.getString("UTR_NO"));
						 paymentTransferDTO1.setPayment_mode(paymentTransferDetails.getString("PAYMENT_MODE"));
						 paymentTransferDTO1.setTotal_records(paymentTransferDetails.getInt("TOTAL_RECORDS"));						
						 paymentTransferDTO1.setOrigTrackingTotalAmount(paymentTransferDetails.getString("TRANSFER_AMT"));						 
						 paymentTransferDTO1.setAttached_file(paymentTransferDetails.getString("ATTACHED_FILE")); 
						 paymentTransferDTO1.setOrigStatus(paymentTransferDetails.getString("STATUS"));	
						// paymentTransferDTO1.setPayMode(paymentTransferDetails.getString("PAY_MODE"));
						 
						 origMapString = paymentTransferDTO1.getFile_id()+"-"+paymentTransferDTO1.getOrigTrackingId()+"-"+paymentTransferDTO1.getOrigTrackingIdServ();
						// origTrackingIdMap.put(paymentTransferDetails.getString("ORIG_TRACKING_ID"),paymentTransferDetails.getString("ORIG_TRACKING_ID_SERV"));
						 //origTrackingIdMap.put(paymentTransferDTO1.getFile_id(),origMapString);
						// paymentTransferDTO1.setOrigTrackingMap(origTrackingIdMap);
						
						 paymentTransferDTO1.setOrigTrackingString(origMapString);
						 
						 chkBoxStatus = (paymentTransferDetails.getString("STATUS")).contains("APPROVAL PENDING");
						 if(chkBoxStatus)
							 chkBoxEnabled ="true";
						 else
							 chkBoxEnabled="false";
						 paymentTransferDTO1.setCheckBoxEnable(chkBoxEnabled);
						 logger.info("origMapString======>"+paymentTransferDTO1.getOrigTrackingString()
						 +":::chkBoxEnabled==>"+chkBoxEnabled+":::Status==>"+paymentTransferDTO1.getOrigStatus()+
						 ":: Final File Name===>"+paymentTransferDTO1.getFinal_file_name());
						 ApprovalDetailsList.add(paymentTransferDTO1);
					   }*/
				 }
			
			}
			catch (SQLException e) {
				throw new RuntimeException(e);
			}finally{
				if(paymentTransferDetails!=null){
					paymentTransferDetails.close();
				}
				if(callableStatement!=null)
					callableStatement.close();
				if (conn != null && !conn.isClosed()) {
					conn.close();
				}
			}
			paymentTransferDTO.setResultPerPage(ApprovalDetailsList.size());
			paymentTransferDTO.setTotalResults(totalRecords);
			paymentTransferDTO.setTotalPages(totalPages);
			paymentTransferDTO.setPaymentTransferDetailList(ApprovalDetailsList);
			
			return paymentTransferDTO;
		}
		
		public PaymentTransferDTO downloadPaymentTransferFile(String userId,String fileId,String requestFileName)
		{ResultSet resultsetdetails = null;
		Connection connection=null;
		CallableStatement callableStatement=null;
		int i=1;
		PaymentTransferDTO paymentTransferDownloadObj=new PaymentTransferDTO();	

		try {
		   
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		connection = jdbcTemplate.getDataSource().getConnection();
		final String procedureCall = "{call AIRTL_PAYMENT_TRANSFER_PKG.GET_FILE_RECORDS_DETAILS(?,?,?,?)}";

		callableStatement = connection.prepareCall(procedureCall);
		logger.info("File Id To be downloaded for Payment Transfer Approval==>" +"REQUEST ID" +fileId);
		callableStatement.setString(1, userId);
		callableStatement.setInt(2, Integer.parseInt(fileId));
		callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
		callableStatement.registerOutParameter(4,OracleTypes.VARCHAR);

		callableStatement.executeUpdate();

		String downloadStatus=callableStatement.getString(4);	
		paymentTransferDownloadObj.setDownloadStatus(downloadStatus);
		logger.info("status @ downloadPaymentTransferFile==>"+paymentTransferDownloadObj.getDownloadStatus());

		resultsetdetails = (ResultSet) callableStatement.getObject(3);

		if (resultsetdetails == null) 
		{
			logger.info("Db not returning any values");
		}

		FileOutputStream downloadFile = null;
		try 
		{
			if(requestFileName.endsWith(".xls")==true)
				
				requestFileName=requestFileName.replace(".xls",
						"_" +fileId + ".xls");
			
			else if(requestFileName.endsWith(".xlsx")==true)
				requestFileName=requestFileName.replace(".xlsx",
						"_" +fileId + ".xlsx");
			
				
				
			downloadFile = new FileOutputStream(new File(homePath+ File.separator+"UPLOADED_FILES"+File.separator+"PaymentTransfer"+File.separator+"InputFiles"+File.separator+requestFileName));
		    logger.info("downloadFile path for Payment Transfer Download===>"+downloadFile);
		 }

		catch (FileNotFoundException e) {
			
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}

		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet worksheet = workbook.createSheet("Payment Transfer");
		XSSFRow row=null;
		row = worksheet.createRow(0);
		XSSFCellStyle cellStyle = workbook.createCellStyle();

		Cell cellA1 = row.createCell((short) 0);
		cellA1.setCellValue("File Id");

		Cell cellB1 = row.createCell((short) 1);
		cellB1.setCellValue("Uploaded Date");

		Cell cellC1 = row.createCell((short) 2);
		cellC1.setCellValue("Uploaded by (ID)"); 

		Cell cellD1 = row.createCell((short) 3);
		cellD1.setCellValue("Uploaded by (Name)");		
		
		Cell cellE1 = row.createCell((short) 4);
		cellE1.setCellValue("CAD FILE RECEIVED DATE & TIME");
		
		Cell cellF1 = row.createCell((short) 5);
		cellF1.setCellValue("Type");


		Cell cellG1 = row.createCell((short) 6);
		cellG1.setCellValue("LOB");

		Cell cellH1 = row.createCell((short) 7);
		cellH1.setCellValue("Fx Account no");

		Cell cellI1 = row.createCell((short) 8);
		cellI1.setCellValue("Cheque No/ Txn id");
				
		Cell cellJ1 = row.createCell((short) 9);
		cellJ1.setCellValue("Payment posted Date");

		Cell cellK1 = row.createCell((short) 10);
		cellK1.setCellValue("Amount (Rs.)");

		Cell cellL1 = row.createCell((short) 11);
		cellL1.setCellValue("Posting Invoice No");

		Cell cellM1 = row.createCell((short) 12);
		cellM1.setCellValue("Remarks");

		Cell cellN1 = row.createCell((short) 13);
		cellN1.setCellValue("Orig Tracking id"); 

		Cell cellO1 = row.createCell((short) 14);
		cellO1.setCellValue("Orig Tracking id Serv");

		/*Cell cellNF1 = row.createCell((short) 14);
		cellNF1.setCellValue("Company Name");*/
		
		Cell cellP1 = row.createCell((short) 15);
		cellP1.setCellValue("Company Name");

		Cell cellQ1 = row.createCell((short) 16);
		cellQ1.setCellValue("Customer Name");

		Cell cellR1 = row.createCell((short) 17);
		cellR1.setCellValue("Circle Name");

		Cell cellS1 = row.createCell((short) 18);
		cellS1.setCellValue("Segment (B2B / B2C)");
				
		Cell cellT1 = row.createCell((short) 19);
		cellT1.setCellValue("Payment Transfer Exemption (Y/ N)");

		Cell cellU1 = row.createCell((short) 20);
		cellU1.setCellValue("Process Type");		
		
		Cell cellV1 = row.createCell((short) 21);
		cellV1.setCellValue("Customer Mail ID");

		/*Cell cellU1 = row.createCell((short) 21);
		cellU1.setCellValue("Account Status");*/

		Cell cellW1 = row.createCell((short) 22);
		cellW1.setCellValue("Payment Code");
				
		Cell cellX1 = row.createCell((short) 23);
		cellX1.setCellValue("Payment Description");

		Cell cellY1 = row.createCell((short) 24);
		cellY1.setCellValue("Annotation for Reversal/Posting");
				
		
		try{				
		if(resultsetdetails!=null){
			while (resultsetdetails.next()) {
				
				PaymentTransferDTO pTDownloadObj=new PaymentTransferDTO();
				
				pTDownloadObj.setFile_id(resultsetdetails.getString("FILE_ID"));
				pTDownloadObj.setFile_upload_date(resultsetdetails.getString("UPLOADED_DATE"));			
				pTDownloadObj.setVendor_userId(resultsetdetails.getString("UPLOADED_BY"));			
				pTDownloadObj.setUploadedUserName(resultsetdetails.getString("UPLOADED_NAME"));
				pTDownloadObj.setTransferType(resultsetdetails.getString("TRANSFER_TYPE"));
				pTDownloadObj.setLob(resultsetdetails.getString("LOB"));
				
				pTDownloadObj.setAccountNo(resultsetdetails.getString("ACCOUNT_NO"));
				pTDownloadObj.setUtrNo(resultsetdetails.getString("CHQ_TXN_NO"));
				pTDownloadObj.setPaymentPostDate(resultsetdetails.getString("PAYMENT_POSTED_DATE"));
				pTDownloadObj.setAmount(resultsetdetails.getString("AMOUNT"));
								
				pTDownloadObj.setInvoiceNo(resultsetdetails.getString("INVOICE_NO"));
				pTDownloadObj.setRemarks(resultsetdetails.getString("REMARKS"));	
				pTDownloadObj.setCadReceivedDate(resultsetdetails.getString("CAD_RECEIVED_DATE"));
				/////////////
				pTDownloadObj.setTrackingId(resultsetdetails.getString("TRACKING_ID"));			
				pTDownloadObj.setTrackingIdServ(resultsetdetails.getString("TRACKING_ID_SERV"));
				pTDownloadObj.setCompanyName(resultsetdetails.getString("COMPANY_NAME"));
				pTDownloadObj.setCustomerName(resultsetdetails.getString("CUSTOMER_NAME"));
				pTDownloadObj.setCircle(resultsetdetails.getString("CIRCLE_NAME"));
				pTDownloadObj.setSegment(resultsetdetails.getString("SEGMENT"));
				pTDownloadObj.setExemptionFlag(resultsetdetails.getString("TRANSFER_EXEMP_FLAG"));
				pTDownloadObj.setPayment_mode(resultsetdetails.getString("PAYMENT_MODE"));
				
								
				pTDownloadObj.setMailId(resultsetdetails.getString("MAIL_ID"));
				//pTDownloadObj.setAccountStatus(resultsetdetails.getString("ACCOUNT_STATUS"));			
				pTDownloadObj.setPaymentCode(resultsetdetails.getString("PAYMENT_CODE"));			
				pTDownloadObj.setPaymentDescription(resultsetdetails.getString("PAYMENT_DESCRIPTION"));
				pTDownloadObj.setAnnotation(resultsetdetails.getString("ANNOTATION"));
				
			
				row = worksheet.createRow(i);
					 
				//Columns to be mapped after query update in procedure
				
				XSSFCell cellA2 = row.createCell((short) 0);
				cellA2.setCellValue(pTDownloadObj.getFile_id());
						
				XSSFCell cellB2 = row.createCell((short) 1);
				CreationHelper createHelper = workbook.getCreationHelper();
				cellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
				cellB2.setCellValue(pTDownloadObj.getFile_upload_date());
				cellB2.setCellStyle(cellStyle);
				
				XSSFCell cellC2 = row.createCell((short) 2);
				cellC2.setCellValue(pTDownloadObj.getVendor_userId());
					
				XSSFCell cellD2 = row.createCell((short) 3);
				cellD2.setCellValue(pTDownloadObj.getUploadedUserName());
				
				XSSFCell cellE2 = row.createCell((short) 4);
				createHelper = workbook.getCreationHelper();
				cellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
				cellE2.setCellValue(pTDownloadObj.getCadReceivedDate());
				cellE2.setCellStyle(cellStyle);
				
				XSSFCell cellF2 = row.createCell((short) 5);
				cellF2.setCellValue(pTDownloadObj.getTransferType());
				
				XSSFCell cellG2 = row.createCell((short) 6);
				cellG2.setCellValue(pTDownloadObj.getLob());
				
				XSSFCell cellH2 = row.createCell((short) 7);
				cellH2.setCellValue(pTDownloadObj.getAccountNo());
				
				XSSFCell cellI2 = row.createCell((short) 8);
				cellI2.setCellValue(pTDownloadObj.getUtrNo());
											
				XSSFCell cellJ2 = row.createCell((short) 9);
				createHelper = workbook.getCreationHelper();
				cellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
				cellJ2.setCellValue(pTDownloadObj.getPaymentPostDate());
				cellJ2.setCellStyle(cellStyle);
				
				XSSFCell cellK2 = row.createCell((short) 10);
				cellK2.setCellValue(pTDownloadObj.getAmount());
								
				XSSFCell cellL2 = row.createCell((short) 11);
				cellL2.setCellValue(pTDownloadObj.getInvoiceNo());
					
				XSSFCell cellM2 = row.createCell((short) 12);
				cellM2.setCellValue(pTDownloadObj.getRemarks());
				
				XSSFCell cellN2 = row.createCell((short) 13);
				cellN2.setCellValue(pTDownloadObj.getTrackingId());
				
				XSSFCell cellO2 = row.createCell((short) 14);
				cellO2.setCellValue(pTDownloadObj.getTrackingIdServ());
				
				XSSFCell cellP2 = row.createCell((short) 15);
				cellP2.setCellValue(pTDownloadObj.getCompanyName());
				
				XSSFCell cellQ2 = row.createCell((short) 16);
				cellQ2.setCellValue(pTDownloadObj.getCustomerName());
				
				XSSFCell cellR2 = row.createCell((short) 17);
				cellR2.setCellValue(pTDownloadObj.getCircle());
				
				XSSFCell cellS2 = row.createCell((short) 18);
				cellS2.setCellValue(pTDownloadObj.getSegment());				

				XSSFCell cellT2 = row.createCell((short) 19);
				cellT2.setCellValue(pTDownloadObj.getExemptionFlag());
					
				XSSFCell cellU2 = row.createCell((short) 20);
				cellU2.setCellValue(pTDownloadObj.getPayment_mode());
				
				XSSFCell cellV2 = row.createCell((short) 21);
				cellV2.setCellValue(pTDownloadObj.getMailId());
				
			/*	XSSFCell cellV2 = row.createCell((short) 22);
				cellV2.setCellValue(pTDownloadObj.getAccountStatus());*/
				
				XSSFCell cellW2 = row.createCell((short) 22);
				cellW2.setCellValue(pTDownloadObj.getPaymentCode());
				
				XSSFCell cellX2 = row.createCell((short) 23);
				cellX2.setCellValue(pTDownloadObj.getPaymentDescription());
				
				XSSFCell cellY2 = row.createCell((short) 24);
				cellY2.setCellValue(pTDownloadObj.getAnnotation());
				
			
				i++;			
			}
			
			for(int j=0;j<10;j++){
		  		worksheet.autoSizeColumn(j);
			}
			
		  }
		    else{
		        logger.info("resultsetdetails are null for payment transfer download");
		     }

		}
		catch(Exception e){
		logger.info("exception when getting data for file");
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);

		}
	    try {
			workbook.write(downloadFile);
			downloadFile.flush();
			downloadFile.close();
		} catch (IOException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}				  
			    
	}catch(Exception e){
		logger.info("main try exception");
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);	
	}finally{			
			if(callableStatement!=null){
			try {
				callableStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
			}
				
		if(resultsetdetails!=null){
			try {
				resultsetdetails.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}			
		if(connection!=null){
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}
	}
	 return paymentTransferDownloadObj;
	 }	

	@Override 
	public Object approvePaymentTransfer(List<String> checkedPTList,List<String> checkedRemarkList, String userId, String action,String rejectReasonDropdown,String rejectReason) throws Exception{
		String status = null;
		Connection conn=null;	
		
		final String approvalProcedureCall = "{call AIRTL_PAYMENT_TRANSFER_PKG.FILE_IDS_APPROVAL_REJECTION(?,?,?,?,?,?,?)}";
		
		CallableStatement callableStatement=null;
		//Map <String, String> origTrackingIdMap = new HashMap <String, String>();
		String origTrackingId=null;
		String origTrackingIdServ = null;
		String fileId = null;
		String origStringValue=null;
		String remarks = "";
		ResultSet resulSetArray=null;
		List<FileDetails> approveFinalList=new ArrayList<FileDetails>();
		Object[] obj =new Object[2];
		try{
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			
			StructDescriptor structDescriptor = StructDescriptor.createDescriptor("PAY_TRANSFER_RECORDS_OBJ", conn);
            STRUCT[] approveRejectStructs = new STRUCT[checkedPTList.size()];

			
			callableStatement = conn.prepareCall(approvalProcedureCall);
			
			/*Object[] arrayPTFileId = checkedPTList.toArray();
			Object[] arrayRemarks = checkedRemarkList.toArray();*/
			
			if(checkedPTList!=null && !checkedPTList.isEmpty()){
				for(int i =0 ;i<checkedPTList.size();i++){
					origStringValue = checkedPTList.get(i);
					//Commenting as approval is file level wise and not orig tracking id wise
					/*String []origValueArray =origStringValue.split("-") ;
					fileId=origValueArray[0];
					origTrackingId=origValueArray[1];
					origTrackingIdServ =origValueArray[2];	*/
					fileId=checkedPTList.get(i);
					logger.info("fileId to be approved or reject===>"+fileId);
					//Commenting as approval is file level wise and not orig tracking id wise ends here
					
				/*	origTrackingIdMap = (Map <String, String>)checkedPTList.get(i);
					for (Map.Entry<String, String> entry : origTrackingIdMap.entrySet()) {
							
						fileId=entry.getKey();
						origMapValue=entry.getValue();
						logger.info("fileId==>"+fileId+":::origMapValue==>"+origMapValue);
						String []origValueArray =origMapValue.split(",") ;
						origTrackingId=origValueArray[0];
						origTrackingIdServ =origValueArray[1];		
						
				}	*/
				//remarks	
				if(checkedRemarkList!=null && !checkedRemarkList.isEmpty()){
					remarks=checkedRemarkList.get(i);
				}
				//logger.info("fileId==>"+fileId+"origTrackingId==>"+origTrackingId+":::origTrackingIdServ==>"+origTrackingIdServ+":::remarks===>"+remarks);
				logger.info("fileId==>"+fileId+":::remarks===>"+remarks);
				
				 //Object[] params = new Object[3];
				 Object[] params = new Object[4];
				 
				 params[0]=fileId;
				//Commenting as approval is file level wise and not orig tracking id wise
				/* params[1]=origTrackingId;
				  params[2]=origTrackingIdServ;
				  params[3]=userId;
				 params[4]=remarks;*/
				//Commenting as approval is file level wise and not orig tracking id wise ends here
				
				 params[1]=userId;
				 params[2]=remarks;
				 params[3]=null;
				 
								 				
				STRUCT struct = new STRUCT(structDescriptor, conn, params);		           
				approveRejectStructs[i] = struct;
				
			 }
			}	
			
			  ArrayDescriptor desc = ArrayDescriptor.createDescriptor("PAY_TRANSFER_RECORDS_TAB",conn);
		      ARRAY oracleArray = new ARRAY(desc, conn, approveRejectStructs);
		       
			/*ARRAY array_to_pass_pt_files = new ARRAY(fileDes, conn, arrayPTFileId);
			ARRAY array_to_pass_remarks = new ARRAY(remarksDes, conn, arrayRemarks);*/
			
		    callableStatement.setString(1,action );
			callableStatement.setArray(2, oracleArray);			
			callableStatement.setString(3, rejectReasonDropdown);
			callableStatement.setString(4, rejectReason);
			callableStatement.registerOutParameter(5, Types.VARCHAR);
			callableStatement.registerOutParameter(6, Types.VARCHAR);
			callableStatement.registerOutParameter(7, OracleTypes.CURSOR);
			
			callableStatement.executeUpdate();
			
			status = callableStatement.getString(5);
			obj[0]=status;
			resulSetArray=(ResultSet) callableStatement.getObject(7);
			logger.info("status in approve proc -->"+status);
			
			if (resulSetArray == null) 
	        {
				logger.info("DB RETURNING NULL VALUES");
				
			}	else
			{
			  while (resulSetArray.next())
			   {
				   FileDetails approveFinalObj = new FileDetails();
					
					logger.info("resulSetArray.getString(FILE_ID)" +resulSetArray.getString("FILE_ID"));
					logger.info("resulSetArray.getString(REQUEST_STATUS)" +resulSetArray.getString("REQUEST_STATUS"));
					approveFinalObj.setFileID(String.valueOf(resulSetArray.getInt("FILE_ID")));					
					approveFinalObj.setRequestStatus(resulSetArray.getString("REQUEST_STATUS"));
					approveFinalObj.setEmailId(resulSetArray.getString("USER_EMAIL_ID"));
					approveFinalObj.setTotalRecords(resulSetArray.getInt("TOTAL_RECORDS"));
					approveFinalObj.setValidSum(resulSetArray.getDouble("TOTAL_AMOUNT"));
					approveFinalObj.setRejectReason(resulSetArray.getString("REJECT_REASON"));
					approveFinalObj.setRejectedRemarks(resulSetArray.getString("REJECT_REASON_REMARKS"));
				 
					approveFinalList.add(approveFinalObj);
					
			}
			  obj[1]=approveFinalList;
			}
		
		}
		catch (SQLException e) {
			throw new RuntimeException(e);
		}finally{
			conn.commit();
			
			if (resulSetArray != null){
			 try {
					resulSetArray.close();
				} catch (SQLException e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null)
				callableStatement.close();
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}
			
		}
		return obj;
	 }
	public void updatePTFDetails(String supportFile,String fileId) {

		logger.info("Updating PTF Details");
		PreparedStatement ps =null;
		ResultSet fileNameResultSet=null;
		Connection conn=null;

		try 
		{
			logger.info("updatePTFDetails-> supportFile->"+supportFile+" fileId->"+fileId);

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
            //01-April-2019    
			//final String procedureCall = "update payment_status_aps set support_file=? where file_id=?";
			final String procedureCall = "update ADVICE_REQUEST_STATUS_APS set SUPPORT_FILE_NAME=? where I_REQUEST_ID=?";

			ps = conn.prepareCall(procedureCall);
			ps.setString(1, supportFile);
			ps.setString(2, fileId);

			ps.executeUpdate();


		}catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally{
			if(fileNameResultSet!=null){
				try {
					fileNameResultSet.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}


			if(conn!=null){
				try {
					conn.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}

			}
		}
		
	}
	@Override
	public List<StopDeatils> allStopNeftFiles() {
		logger.info("Start in to StopNeft DAO ");
		List<StopDeatils> response=new ArrayList<StopDeatils>();
		PreparedStatement ps =null;
		ResultSet rs=null;
		Connection conn=null;
		try 
		{
			//logger.info("updatePTFDetails-> supportFile->"+supportFile+" fileId->"+fileId);

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();

			final String qurey = "SELECT DISTINCT  P.FILE_ID,P.USER_NAME,A.USER_NAME USERID,P.ORIGINAL_FILE_NAME,"
       +"P.TOTAL_RECORDS,P.SUM_OF_AMOUNT,P.PROCESS_DATE FROM payment_status_aps P, NEFT_VENDOR_FILES_RECORDS B,"
       +"AIRTL_USER_DETAILS A WHERE     P.status = 5 and UPPER(P.USER_NAME)=UPPER(A.USERID) AND p.file_id = b.file_id"+
       " AND b.status_code > 0 AND  p.process_date >= TRUNC(SYSDATE) AND P.FILE_IDENTIFIER IN ('EFT')";
			
			logger.info("Qurey"+qurey);
			//System.out.println("sql qurey --------"+procedureCall);
			ps = conn.prepareCall(qurey);
			//ps.setString(1, supportFile);
			//ps.setString(2, fileId);

			rs=ps.executeQuery(qurey);
			if(rs!=null)
			{
				while(rs.next())
					
				{
					StopDeatils fd= new StopDeatils();
					fd.setFileID(rs.getString("FILE_ID"));
					//fd.setVendorUserId(rs.getString(2));
					fd.setUserId(rs.getString("USER_NAME"));
					fd.setUserName(rs.getString("USERID"));
					fd.setFinalFileName(rs.getString("ORIGINAL_FILE_NAME"));
					fd.setTotalRecords(rs.getInt("TOTAL_RECORDS"));
					fd.setPaymentAmount(rs.getString("SUM_OF_AMOUNT"));
					fd.setFileUploadDate(rs.getString("PROCESS_DATE"));
					fd.setPaymentMode("NEFT");
					logger.info("Records  "+fd.toString());
					response.add(fd);
				}
			}
			logger.info("Size of data"+response.size());

		}catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally{
			if(rs!=null){
				try {
					rs.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}


			if(conn!=null){
				try {
					conn.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}

			}
		}
		logger.info("End  StopNeft files Dao ");
		return response;
	}
	@Override
	public String responseMsgforStopFiles(String fileId) {
		logger.info("Start in to StopNeft DAO with fileid is"+fileId);
		String reponseMsg=null;
		Connection conn=null;
		//System.out.println(fileId);
		
		final String stopProcedureCall = "{call STOP_NEFT_FILE_RECORDS_UI(?,?)}";
		logger.info("The Procedure is "+stopProcedureCall);
		CallableStatement callableStatement=null;
		try{
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();	
			callableStatement = conn.prepareCall(stopProcedureCall);	
			
			//callableStatement.setArray(1, array_to_pass_pt_files);
			//callableStatement.setString(2,roleId );
			callableStatement.setString(1, fileId);
			callableStatement.registerOutParameter(2, Types.VARCHAR);
			 		callableStatement.executeUpdate();
			
			//status = callableStatement.getString(4);
			//logger.info("status in approve proc -->"+status);
			reponseMsg=callableStatement.getString(2);
			logger.info("Response msg from proc"+reponseMsg);
		}
		catch (SQLException e) {
			throw new RuntimeException(e);
		}finally{
			try{
			conn.commit();
			if(callableStatement!=null)
				callableStatement.close();
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}
		}
			catch(Exception e)
			{
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}
		
	
		return reponseMsg;
	}
	
	//Added to get rejection list
	public List<String> getRejectReasons() 
	{
		List<String> rejectReasonsList=new ArrayList<String>();
		Connection connection = null;
		CallableStatement callableStatement=null;
		ResultSet rejectionReasonResultSet=null;
		try 
		{
			logger.info("entered getRejecReason");
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();

			final String procedureCall = "{call AIRTL_PAYMENT_TRANSFER_PKG.getRejectionReasons(?,?,?)}";

			 callableStatement = connection.prepareCall(procedureCall);
			callableStatement.registerOutParameter(1, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(2, Types.CHAR);
			callableStatement.registerOutParameter(3, Types.CHAR);			
			
			callableStatement.executeUpdate();
			
			 rejectionReasonResultSet=(ResultSet) callableStatement.getObject(1);
			if (rejectionReasonResultSet == null) 
	        {
				logger.info("result set details are null ..DB is returning null values!!!");
			}
			else
			{
		     while(rejectionReasonResultSet!=null && rejectionReasonResultSet.next())
		      {
			   
		    	 rejectReasonsList.add(rejectionReasonResultSet.getString("rejection_reason"));
			    
		      }
		}
		
	}catch (Exception e) {
		StringWriter errors= new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		logger.error(errors);
		return null;
		}
	finally{
		
		if(callableStatement!=null){
		try {
			callableStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
	}
		
		if(rejectionReasonResultSet!=null){
			try {
				rejectionReasonResultSet.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}
		
		if(connection!=null){
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}
		
		
}
		return rejectReasonsList;
}

	//Added by Ritu on 14th June 2019
	public UserEmailDetails getEmailAddress(String  userId) {
		logger.info(" Starting execution of getEmailAddress() method");
		final String procedureCall = "{call AIRTL_PAYMENT_TRANSFER_PKG.getUserEmailAddress(?,?,?,?)}";
		Connection connection = null;
		ResultSet paymentAdivceFieldsResultSet = null;
		CallableStatement callableStatement=null;
		UserEmailDetails userDetailsObj = new UserEmailDetails();
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			logger.info(" Database connection has been established successfully !! ");
			callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setString(1,userId);
			callableStatement.registerOutParameter(2, OracleTypes.VARCHAR); 
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(4, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();
			logger.info(" Procedure "+procedureCall+" has been invoked successfully !! ");
			String emailId=callableStatement.getString(2);
			String errorCode=callableStatement.getString(3);
			String errorMessage=callableStatement.getString(4);
			userDetailsObj.setEmailAddress(emailId);
			userDetailsObj.setErrorCode(errorCode);
			userDetailsObj.setErrorMessage(errorMessage);
			logger.info("Email id is" +userDetailsObj.getEmailAddress());
			logger.info(" Procedure returned error code "+errorCode+", error message "+errorMessage);
		} catch (SQLException e) {
			userDetailsObj.setErrorCode("FAILURE");
			//userDetailsObj.setErrorMessage("Unable to retreive email address, reason for the failure is "+e.getLocalizedMessage());
			userDetailsObj.setErrorMessage("Unable to retreive email address");

			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally {
			if(paymentAdivceFieldsResultSet!=null){
				try {
					paymentAdivceFieldsResultSet.close();
					logger.info(" Result set has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing result set , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if(callableStatement!=null){
				try {
					callableStatement.close();
					logger.info(" Callable statement has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing callable statement , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
			
			if (connection != null){
				try {
					connection.close();
					logger.info(" Database connection has been closed successfully !! ");
				} catch (SQLException e) {
					logger.info(" Exception occured while closing database connection , error message is "+e.getLocalizedMessage());
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
			}
		}
		logger.info(" Execution of getEmailAddress() method has been completed");
		return userDetailsObj;
	}

	
	/*public static void main(String[] args) throws Exception {
		String ard ="INT_219_PASSED,INT_219_PASSED";
		
		boolean av =ard.contains("APPROVAL PENDING");
		System.out.println("av--->"+av);
	}*/
}