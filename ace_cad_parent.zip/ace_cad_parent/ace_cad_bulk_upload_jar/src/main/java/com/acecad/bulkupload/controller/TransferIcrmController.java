package com.acecad.bulkupload.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.acecad.bulkupload.dao.TransferIcrmDao;
import com.acecad.bulkupload.model.TransferIcrmDetails;

@Controller
public class TransferIcrmController {
	

	@Autowired
	TransferIcrmDao TransferIcrmDaoObj;
	private static Logger transferICRMLogger =LogManager.getLogger("transferICRMLogger");
	
	TransferIcrmDetails TransferIcrmDetailsObj = new TransferIcrmDetails();
	String errMsg = null;
	HttpServletRequest request;
	
	HttpSession session;

	@RequestMapping(value = "/transferIcrm")
	public ModelAndView transferIcrmHome() {
		transferICRMLogger.info("Transfer ICRM Controller");
		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("CadUserLogin");
		return modelAndViewObj;
	}
	
	@RequestMapping(value = "/cadUsergetTransferIcrm")
	public ModelAndView getTransferDetails(HttpServletRequest request,
			HttpServletResponse response) {

		transferICRMLogger.info("In controller to get Transfer ICRM  Details");
		ModelAndView modelAndViewObj = new ModelAndView();
		
		String parentUserId = request.getParameter("UserId");
		transferICRMLogger.info("Login User ID in Controller:"+parentUserId);

		/*int Role = TransferIcrmDaoObj.getRole(parentUserId);
		if(Role==-1)
		{
			modelAndViewObj.addObject("errMsg", "Data Base Issues");
			modelAndViewObj.setViewName("cadUserHome");
			return modelAndViewObj;
		}

		

		if ( (Role == 2)) {*/
            // call method from dao and get records based on parentuserId only.
			int page = 1;
			String errMsg = null;
			/* List<String> crmPayModeList=TransferIcrmDaoObj.CrmPayModeDropdown();*/
			 
			
			HashMap<Integer, List<TransferIcrmDetails>> TransferIcrmDetailsMap = new HashMap<Integer, List<TransferIcrmDetails>>();

			TransferIcrmDetailsMap = TransferIcrmDaoObj
					.getTransferIcrmDetailsMap(TransferIcrmDetailsObj,page);
			if(TransferIcrmDetailsMap==null)
			{
				modelAndViewObj.addObject("errMsg", "Data Base Issues");
				modelAndViewObj.setViewName("cadUserHome");
				return modelAndViewObj;
			}
			transferICRMLogger.info("Transfer ICRM Details map size in Controller"+TransferIcrmDetailsMap.size());
			
			errMsg=TransferIcrmDetailsObj.getErrMsg();
			
			transferICRMLogger.info("Error Msg in Transfer Icrm Details in Controller"+errMsg);
			
		 if(errMsg.equalsIgnoreCase("FAILURE. NO RECORDS FOUND"))
			{
				errMsg="No Records Pending For Approval";
			}
		 else if(errMsg.equalsIgnoreCase("NO_DATA_FOUND"))
				 {
			 errMsg="No Records Pending For Approval";
				 }
		 
		 
		 modelAndViewObj.addObject("TransferIcrmDetailsMap", TransferIcrmDetailsMap);
		/* modelAndViewObj.addObject("crmPayModeList", crmPayModeList);*/
          modelAndViewObj.addObject("errMsg", errMsg);
        
		  modelAndViewObj.addObject("currentPage", page);
         modelAndViewObj.setViewName("cadUserHome");
		

		
		return modelAndViewObj;
	}
	@RequestMapping(value = "/viewIcrmRecordswithPagination", method = RequestMethod.GET)
	public ModelAndView viewRecordswithPagination(HttpServletRequest request,
			HttpServletResponse response) {

		
		transferICRMLogger.info("Transfer Icrm Details  pagination in Controller");
		HashMap<Integer, List<TransferIcrmDetails>> TransferIcrmDetailsMap = new HashMap<Integer, List<TransferIcrmDetails>>();
		int page = Integer.parseInt(request.getParameter("pageNum"));
		String errMsg = null;
		ModelAndView modelAndViewObj = new ModelAndView();
		TransferIcrmDetailsMap = TransferIcrmDaoObj
				.getTransferIcrmDetailsMap(
						TransferIcrmDetailsObj, page);
		if(TransferIcrmDetailsMap==null)
		{
			modelAndViewObj.addObject("errMsg", "Data Base Issues");
			modelAndViewObj.setViewName("cadUserHome");
			return modelAndViewObj;
		}
		/* List<String> crmPayModeList=TransferIcrmDaoObj.CrmPayModeDropdown();*/
		
		transferICRMLogger.info("Transfer ICRM Details map size  pagination in Controller"+TransferIcrmDetailsMap.size());
		
		 errMsg=TransferIcrmDetailsObj.getErrMsg();
		 if(errMsg.equalsIgnoreCase("FAILURE. NO RECORDS FOUND"))
			{
				errMsg="No Records Pending For Approval";
			}
		 else if(errMsg.equalsIgnoreCase("NO_DATA_FOUND"))
				 {
			 errMsg="No Records Pending For Approval";
				 }
		 
		 transferICRMLogger.info("Error Msg in Transfer Icrm Details  pagination in Controller"+errMsg);
        modelAndViewObj.addObject("errMsg", errMsg);
		modelAndViewObj.addObject("TransferIcrmDetailsMap", TransferIcrmDetailsMap);
		
		/* modelAndViewObj.addObject("crmPayModeList", crmPayModeList);*/
		modelAndViewObj.addObject("currentPage", page);
		modelAndViewObj.setViewName("cadUserHome");
		
		return modelAndViewObj;
	}
	
	
	/*<-------------export to excel----------------->*/
	
	@RequestMapping(value = "/transferIcrmDetailsToExcel", method = RequestMethod.GET)
	public ModelAndView transferIcrmDetailsToExcel(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		
		
		transferICRMLogger.info("Transfer ICRM Details Excel download");
		String pageNum=null;
		
		List<TransferIcrmDetails> TransferIcrmDetailsExcelList=new ArrayList<TransferIcrmDetails>();
		TransferIcrmDetailsExcelList=TransferIcrmDaoObj.getTransferIcrmExcelList(TransferIcrmDetailsObj, pageNum);
		if(TransferIcrmDetailsExcelList==null)
		{
			modelAndViewObj.addObject("errMsg", "Data Base Issues");
			modelAndViewObj.setViewName("cadUserHome");
			return modelAndViewObj;
		}
			
		int rowNumber = 1;
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet();
		HSSFCell cell = null;
		HSSFRow row;
		HSSFCellStyle my_style = wb.createCellStyle();
		 HSSFFont my_font=wb.createFont();
		 my_font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		 my_style.setFont(my_font);
		 HSSFCellStyle rightAligned = wb.createCellStyle();
		 rightAligned.setAlignment(CellStyle.ALIGN_RIGHT);
		
		row = sheet.createRow(0);
		cell = row.createCell(0);
		cell.setCellValue("SR Number");
		cell.setCellStyle(my_style);
		cell = row.createCell(1);
		cell.setCellValue("SR Created Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(2);
		cell.setCellValue("Source Account No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(3);
		cell.setCellValue("Destination Account No.");
		cell.setCellStyle(my_style);
		cell = row.createCell(4);
		cell.setCellValue("Bill Date");
		cell.setCellStyle(my_style);
		cell = row.createCell(5);
		cell.setCellValue("Amount");
		cell.setCellStyle(my_style);
		cell = row.createCell(6);
		cell.setCellValue("Reason For Transfer");
		cell.setCellStyle(my_style);
		cell = row.createCell(7);
		cell.setCellValue("Transaction ID/Cheque Number");
		cell.setCellStyle(my_style);
		cell = row.createCell(8);
		cell.setCellValue("Cheque Date/Bank Name");
		cell.setCellStyle(my_style);
		cell = row.createCell(9);
		cell.setCellValue("Payment Mode");
		cell.setCellStyle(my_style);
		cell = row.createCell(10);
		cell.setCellValue("Tracking ID");
		cell.setCellStyle(my_style);
		cell = row.createCell(11);
		cell.setCellValue("Tracking ID Serv");
		cell.setCellStyle(my_style);
		for (int i = 0; i <TransferIcrmDetailsExcelList.size(); i++) {
			//transferICRMLogger.info("i value"+i);
			TransferIcrmDetails TransferIcrmDetailsObject =
					TransferIcrmDetailsExcelList.get(i);
				
					 row = sheet.createRow(rowNumber); 
					 cell = row.createCell(0);
					 cell.setCellValue(TransferIcrmDetailsObject.getSrNumber());
					 cell.setCellStyle(rightAligned);
					 cell = row.createCell(1);
					 cell.setCellValue(TransferIcrmDetailsObject.getSrCreatedTime());
					 cell.setCellStyle(rightAligned);
					// sheet.autoSizeColumn(0); 
					 
					 cell = row.createCell(2);
					 cell.setCellValue(TransferIcrmDetailsObject.getSourceAccountNumber());
					 cell.setCellStyle(rightAligned);
					 
					 cell = row.createCell(3);
					 cell.setCellValue(TransferIcrmDetailsObject.getDestinationAccountNumber());
					 cell.setCellStyle(rightAligned);
					// sheet.autoSizeColumn(2); 
					 
					 cell = row.createCell(4);
					 cell.setCellValue(TransferIcrmDetailsObject.getBillDate());
					 
					 cell = row.createCell(5);
					 cell.setCellValue(TransferIcrmDetailsObject.getAmount());
					 cell.setCellStyle(rightAligned);
					// sheet.autoSizeColumn(4); 
					 
					 cell = row.createCell(6);
					 cell.setCellValue(TransferIcrmDetailsObject.getReasonForTransfer());
					 
					 cell = row.createCell(7);
					 cell.setCellValue(TransferIcrmDetailsObject.getRefNumber());
					 //sheet.autoSizeColumn(6);
					 
					 cell = row.createCell(8);
					 cell.setCellValue(TransferIcrmDetailsObject.getChequeDate());
					 
					 cell = row.createCell(9);
					 cell.setCellValue(TransferIcrmDetailsObject.getPayMode());
					//sheet.autoSizeColumn(8);
					 
					 cell = row.createCell(10);
					 cell.setCellValue(TransferIcrmDetailsObject.getTrackingId());
					 cell.setCellStyle(rightAligned);
					 
					 cell = row.createCell(11);
					 cell.setCellValue(TransferIcrmDetailsObject.getTrackingIdServ());
					 cell.setCellStyle(rightAligned);
					// sheet.autoSizeColumn(10);
					 rowNumber++;
			
			 }
		for (int i = 0; i <= 11; i++) {
			sheet.autoSizeColumn(i);
		}
		
		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			transferICRMLogger.error(errors);
			/* logger.error(" Exception occured : "+e.getMessage()); */
		}
		byte[] outArray = outByteStream.toByteArray();

		String date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
		.format(new Date());

String fileName = "TransferIcrmDetails" + "_" + date + ".xls";

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			transferICRMLogger.error(errors);
			/* logger.error(" Exception occured : "+e.getMessage()); */
		}

		/* logger.info("End of failure records download "); */

		return modelAndViewObj;

	}
	
	
	
	@RequestMapping(value = "/updateCrmAccountDetails" ,method = RequestMethod.POST)
	public ModelAndView updateCrmAccountDetails(HttpServletRequest request, HttpServletResponse response) 
	{
		transferICRMLogger.info("Transfer Icrm Details  updateCrmAccountDetails mapping in Controller");

	      ModelAndView modelAndViewObj = new ModelAndView();
	      session=request.getSession(true);
			String userId=session.getAttribute("userid").toString();
			String role=session.getAttribute("user_role_id").toString();
              String action="UPDATE";
            //  String userId="A17W9V4JY";
              String sessionId=session.getId();
      		  int pageNumber=1;
      	      List<TransferIcrmDetails> crmList= new ArrayList<TransferIcrmDetails>();
              List<TransferIcrmDetails> crmRecordsListUpdated=new ArrayList<TransferIcrmDetails>();
             // List<TransferIcrmDetails> eCollectAccountMapList=new ArrayList<TransferIcrmDetails>();
              List<TransferIcrmDetails> crmInputFxList=new ArrayList<TransferIcrmDetails>();
              TransferIcrmDetails crmFinalFxObj=null;

    try 
	   {
		 
		 String[] keyValuePairs=request.getParameterValues("updatedValues");
		
		  List<String> UpdatedValues=new ArrayList<String>();
		  

		  
if(keyValuePairs!=null)
	    {
		  UpdatedValues=Arrays.asList(keyValuePairs);
		  for(String valuesObj: UpdatedValues)
		  {
			  
			  String[] arrayOfUpdatedValues=valuesObj.split("\\$");
			  
			  for(int i=0;i<arrayOfUpdatedValues.length;i++)
			  {
				  transferICRMLogger.info("ARRAY OF UPDATED VALUES:"+arrayOfUpdatedValues[i]);
			  }
			  TransferIcrmDetails crmObj=new TransferIcrmDetails();
			   DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
		      crmObj.setSrNumber(arrayOfUpdatedValues[0]);
			  crmObj.setSourceAccountNumber(arrayOfUpdatedValues[1]);
			  crmObj.setDestinationAccountNumber(arrayOfUpdatedValues[2]);
			 // Date d1 = df.parse(arrayOfUpdatedValues[4]);
			  crmObj.setBillDate(arrayOfUpdatedValues[3]);
			 
			  crmObj.setAmount(arrayOfUpdatedValues[4]);
			  crmObj.setReasonForTransfer(arrayOfUpdatedValues[5]);
			  crmObj.setRefNumber(arrayOfUpdatedValues[6]);
			  //Date d2 = df.parse(arrayOfUpdatedValues[8]);
			  crmObj.setChequeDate(arrayOfUpdatedValues[7]);
			  crmObj.setPayMode(arrayOfUpdatedValues[8]);
			  //crmObj.setTrackingId(arrayOfUpdatedValues[10]);
	         // crmObj.setTrackingIdServ(arrayOfUpdatedValues[10]);
			  String[] trackingIdValues=arrayOfUpdatedValues[9].split(",");
			  
			//  transferICRMLogger.info("trackinId values"+trackingIdValues);
			  List<String> TrackingIdList =new ArrayList<String>();
			  
			  for(int i=0;i<trackingIdValues.length;i++)
			  {
				  /*transferICRMLogger.info("tracking id values"+trackingIdValues[i]);*/
		//	  crmObj.setTrackingId(trackingIdValues[i]);
				  
			  TrackingIdList.add(trackingIdValues[i]);
			  }
			  crmObj.setTrackingIdList(TrackingIdList);
			  crmObj.setTrackingIdServ(arrayOfUpdatedValues[10]);
			  crmList.add(crmObj);
		  }
			  
			transferICRMLogger.info("Transfer ICRM Details crmList size in updateCrmAccountDetails mapping Controller"+crmList.size());

     for(TransferIcrmDetails crmInputFxObj:crmList)
			      {
			    	  
			  crmFinalFxObj=TransferIcrmDaoObj.validationsFromFX(crmInputFxObj);
			 /* transferICRMLogger.info("eneterd ouside");
			  transferICRMLogger.info("remarks"+crmFinalFxObj.getRemarks());
			  if(crmFinalFxObj.getRemarks().equalsIgnoreCase("Failed: Connectivity Issue..RETRY"))
			  {
				  transferICRMLogger.info("eneterd inside");
				  int page=1;
				 
				  if(!(request.getParameter("pageNum").equalsIgnoreCase(null)))
				  {
					  page = Integer.parseInt(request.getParameter("pageNum"));;
				  }
				 
					   
					String errMsg = null;
					HashMap<Integer, List<TransferIcrmDetails>> TransferIcrmDetailsMap = new HashMap<Integer, List<TransferIcrmDetails>>();
					TransferIcrmDetailsMap = TransferIcrmDaoObj
							.getTransferIcrmDetailsMap(
									TransferIcrmDetailsObj, page);
				  modelAndViewObj.addObject("errMsg", crmFinalFxObj.getRemarks());
				  modelAndViewObj.addObject("TransferIcrmDetailsMap", TransferIcrmDetailsMap);
				  
					modelAndViewObj.setViewName("cadUserHome");
					return modelAndViewObj;
			  }*/
			    		    
			    		    //transferICRMLogger.info("effective amount @eai call:"+crmFinalFxObj.getEffectivePaymentAmount());
			    		    
			    		   // transferICRMLogger.info("final track:"+crmFinalFxObj.getLiuTrackingID());
			    		    
			    		    crmInputFxList.add(crmFinalFxObj);

					   }			 
		      
		 crmRecordsListUpdated=TransferIcrmDaoObj.modifiedCrmDetails(crmInputFxList,userId,sessionId,action,pageNumber);
			
			transferICRMLogger.info("crmRecordsListUpdated size in updateCrmAccountDetails at Transfer ICRM Controller"+crmRecordsListUpdated.size());

	}// IF(  KEUVALUES PAIRS ARE NOT NULL VALUES)

	/* for(int i=0;i<crmRecordsListUpdated.size();i++)
             
         {

		 TransferIcrmDetails liuRecordDetailsObj=crmRecordsListUpdated.get(i);
         	
         	liuRecordDetailsObj.getRemarks();
         	transferICRMLogger.info("REMARKS:"+liuRecordDetailsObj.getRemarks());
         	
         	if(liuRecordDetailsObj.getRemarks()!=null && liuRecordDetailsObj.getRemarks().equalsIgnoreCase("SUCCESS"))
         	{
        		SNo=activityDao.insertActivityLog(SNo,userId,"UPDATE LIU RECORDS","SUCCESS","RECORD UPDATED");

         	}
         	else
         	{
        		SNo=activityDao.insertActivityLog(SNo,userId,"UPDATE LIU RECORDS","FAILURE","RECORD IS NOT UPDATED");
         	}
         	
         }*/
//transferICRMLogger.info("VALUES ARE UPDATED AND RETRIEVED AT CONTROLLER..");
		 
		if(UpdatedValues!=null)
		  {
			for(int i=0;i<UpdatedValues.size();i++)
			{
				transferICRMLogger.info("VALUES IN ROW "+(i+1)+" ARE:"+UpdatedValues.get(i));
			}
		  }
		
		
		modelAndViewObj.addObject("crmRecordsListUpdated",crmRecordsListUpdated);
		
		
   		modelAndViewObj.addObject("currentPage", pageNumber);
		modelAndViewObj.setViewName("successDetails");

	   }catch (Exception e) {
		   StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			transferICRMLogger.error(errors);
		}
    
	transferICRMLogger.info("Executed updateCrmAccountDetails mapping at Transfer ICRM Controller"+crmRecordsListUpdated.size());

		return modelAndViewObj;
	}

	
	
	
	@RequestMapping(value = "/rejectCRMDetails", method = RequestMethod.POST)
	public ModelAndView viewRejectedCrmDetails(HttpServletRequest request,
			HttpServletResponse response) {

		transferICRMLogger.info("In rejectCRMDetails mapping in Transfer Icrm Controller");
		 session=request.getSession(true);
			String userId=session.getAttribute("userid").toString();
			String role=session.getAttribute("user_role_id").toString();
              String action="REJECT";
            //  String userId="A17W9V4JY";
              String sessionId="crm";
      		  int pageNumber=1;
        	 ModelAndView modelAndViewObj = new ModelAndView();
  		  	 String rejectionStatus=null;
              List<String> CrmRejectedList= new ArrayList<String>();
              String rejectedReason=request.getParameter("rejectReason");

	 try 
	   {
			String[] keyValuePairs=request.getParameterValues("rejectedValues");
			
		    List<String> rejectedValues=new ArrayList<String>();
		 
		 if(keyValuePairs!=null)
		 {
			 rejectedValues=Arrays.asList(keyValuePairs);
		  
		  for(String valuesObj: rejectedValues)
		  {
			 
			  //crmRejectedObj.setRejectionReason(request.getParameter("reason"));
			
			  String[] arrayOfRejectedValues=valuesObj.split("\\$");
			 
			 
			  for(int i=0;i<arrayOfRejectedValues.length;i++)
			  {
				 transferICRMLogger.info("ARRAY OF DELETED VALUES IN TRANSFER CRM:"+arrayOfRejectedValues[i]);
			  }
			  
			 /* TransferIcrmDetails crmRejectedObj=new TransferIcrmDetails();
			 //  DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
			   crmRejectedObj.setSrNumber(arrayOfRejectedValues[0]);
			  crmRejectedObj.setSourceAccountNumber(arrayOfRejectedValues[1]);
			   crmRejectedObj.setDestinationAccountNumber(arrayOfRejectedValues[2]);
			 // Date d1 = df.parse(arrayOfRejectedValues[4]);
			  crmRejectedObj.setBillDate(arrayOfRejectedValues[3]);
			 
			  crmRejectedObj.setAmount(arrayOfRejectedValues[4]);
			  crmRejectedObj.setReasonForTransfer(arrayOfRejectedValues[5]);
			  crmRejectedObj.setRefNumber(arrayOfRejectedValues[6]);
			  //Date d2 = df.parse(arrayOfRejectedValues[8]);
			  crmRejectedObj.setChequeDate(arrayOfRejectedValues[7]);
			  crmRejectedObj.setPayMode(arrayOfRejectedValues[8]);
			  //crmObj.setTrackingId(arrayOfUpdatedValues[10]);
			  
			  String[] trackingIdValues=arrayOfRejectedValues[9].split(",");
			  List<String> TrackingIdList=null;
			  for(int i=0;i<trackingIdValues.length;i++)
			  {
				  crmRejectedObj.setTrackingId(trackingIdValues[i]);
			  TrackingIdList.add(crmRejectedObj.getTrackingId());
			  }
			  crmRejectedObj.setTrackingId(arrayOfRejectedValues[8]);
			  crmRejectedObj.setTrackingIdServ(arrayOfRejectedValues[10]);*/
			  CrmRejectedList.add(arrayOfRejectedValues[0]);
		  }
		  
		  rejectionStatus=TransferIcrmDaoObj.rejectedCrmDetails(CrmRejectedList,userId,sessionId,rejectedReason);
		  
		 }
		
	transferICRMLogger.info("Rejection Status in rejectCRMDetails mapping at Transfer CRM Controller:"+rejectionStatus);
	transferICRMLogger.info("Rejected List size n rejectCRMDetails mapping at Transfer CRM Controller:"+CrmRejectedList.size());
		
		modelAndViewObj.addObject("rejectionStatus",rejectionStatus.trim());
		modelAndViewObj.addObject("CrmRejectedList",CrmRejectedList);
		modelAndViewObj.addObject("rejectedReason",rejectedReason);
		
		modelAndViewObj.addObject("currentPage", pageNumber);
		modelAndViewObj.setViewName("RejectedDetailsPage");
	}
	   catch (Exception e) {
		   StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			transferICRMLogger.error(errors);
		}
		transferICRMLogger.info("Executed rejectCRMDetails mapping at Transfer CRM Controller:"+CrmRejectedList.size());

		return modelAndViewObj;
	}

}
