package com.acecad.bulkupload.controller;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

//Commented as per Hydb
//import com.acecad.airtel.eai.integration.model.Request_ResponseXMLDetails;
import com.acecad.bulkupload.dao.BulkDao;
import com.acecad.bulkupload.model.BulkDetails;
import com.acecad.bulkupload.model.FileDetails;
import com.acecad.bulkupload.model.PaymentTransferDTO;
import com.acecad.bulkupload.model.PaymentTransferTemplate;
import com.acecad.bulkupload.model.UserEmailDetails;
import com.acecad.bulkupload.util.BulkUtil;
import com.acecad.bulkupload.util.StopDeatils;

//import com.acecad.bulkupload.util.SampleCustomerAccount;
import com.airtel.acecad.UtilityJar.ActivityLog;
import com.airtel.acecad.bulkupload.dto.FileUploadResult;
import com.airtel.acecad.bulkupload.uploadfile.ExcelReader;
import com.airtel.acecad.bulkupload.util.CommonValidator;
/*import com.airtel.acecad.model.EMailContent;
import com.airtel.acecad.model.EmailAttachment;
import com.airtel.acecad.model.SmtpMailContent;
import com.airtel.acecad.utility.SmtpUtility;*/
//import com.airtel.login.util.CustomExceptionHandler;
import com.airtel.acecad.model.EMailContent;
import com.airtel.acecad.model.SmtpMailContent;
import com.airtel.acecad.utility.SmtpUtility;

@Controller
public class BulkController {
	/*@Autowired
	FileDetails fileDetailsObj;*/
	@Autowired
	BulkDao bulkDao;
	@Autowired
	ExcelReader excelReader;
	@Autowired
	ActivityLog activityLogDao;
	private String homePath=System.getenv("ACE_CAD_HOME");
	final long startTime = System.nanoTime();
	private static Logger logger =LogManager.getLogger("bulkUploadLogger");
	@Autowired
	BulkUtil bulkutil;
	
	@Autowired
	PaymentTransferDTO paymentTransferDTO;
	/*BulkUtil bulkutil=new BulkUtil();*/

	//@Value("${UPLOADED_SRC_HOME}")
	private String downloadpath=System.getenv("ACE_CAD_HOME")+File.separator+"UPLOADED_FILES";
	private String templatesPath=System.getenv("ACE_CAD_HOME")+File.separator+"Templates";
	//@Value("${ERROR_SRC_HOME}")
	private String errorFilesPath=System.getenv("ACE_CAD_HOME")+File.separator+"ERRORED_FILES";
	private String paymentAdviceHomePath = System.getenv("PAYMENT_ADVICE_HOME");

	private String transferFile=System.getenv("ACE_CAD_HOME")+File.separator+"UPLOADED_FILES"+File.separator+"PaymentTransfer"+File.separator+"InputFiles";
	private String transferSupportFile=System.getenv("ACE_CAD_HOME")+File.separator+"UPLOADED_FILES"+File.separator+"PaymentTransfer"+File.separator+"SupportFiles";

	HttpServletRequest request;

	HttpSession session;

	@RequestMapping(value = "/bulkupload")
	public ModelAndView ananymousLogin(HttpServletRequest request) {
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		List<String> uploadType=new ArrayList<String>();

		logger.info("ENTERED INTO BULKUPLOAD");

		if(role.equalsIgnoreCase("2"))
		{
			uploadType.add("CHEQUE");
			uploadType.add("NEFT BANK STATEMENT");
			uploadType.add("OTHERS");

		}

		else  if(role.equalsIgnoreCase("4"))
		{
			uploadType=bulkDao.retreiveListforDropDown(role,userId);
		}
		ModelAndView modelAndViewObj = new ModelAndView();
		session.setAttribute("uploadTypeList", uploadType);
		modelAndViewObj.addObject("uploadTypeList",uploadType);
		//if(role.equal)
		modelAndViewObj.setViewName("bulk");

		return modelAndViewObj;

	}
	@RequestMapping(value = "/bulkReversal")
	public ModelAndView bulkReversal(HttpServletRequest request) {
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		List<String> uploadType=new ArrayList<String>();
		logger.info("ENTERED INTO REVERSAL");
		if(role.equalsIgnoreCase("2"))
		{
			uploadType.add("Reversal");
			uploadType.add("ChequeBounce");

		}
		if(role.equalsIgnoreCase("3"))
		{

			uploadType.add("ChequeBounce");

		}

		ModelAndView modelAndViewObj = new ModelAndView();
		session.setAttribute("uploadTypeList", uploadType);
		modelAndViewObj.addObject("uploadTypeList",uploadType);
		modelAndViewObj.setViewName("reversal");
		return modelAndViewObj;

	}
	@RequestMapping(value = "/nonBankableUpload")
	public ModelAndView nonBankableUpload(HttpServletRequest request) {
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		List<String> uploadType=new ArrayList<String>();


		logger.info("ENTERED INTO nonBankableUpload");
		ModelAndView modelAndViewObj = new ModelAndView();
		session.setAttribute("uploadTypeList", uploadType);
		modelAndViewObj.addObject("uploadTypeList",uploadType);
		modelAndViewObj.setViewName("nonBankableUpload");

		return modelAndViewObj;

	}
	@RequestMapping(value = "/bulkTransfer")
	public ModelAndView bulkTransfer(HttpServletRequest request) {
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		String message ="";
		String type="";
		int page =0;
		List<String> uploadType=new ArrayList<String>();

		logger.info("ENTERED INTO BULKTRANSFER");
		ModelAndView modelAndViewObj = new ModelAndView();
		session.setAttribute("uploadTypeList", uploadType);
		modelAndViewObj.addObject("uploadTypeList",uploadType);
		modelAndViewObj.setViewName("bulkTransfer");
		
      try{
		 message= request.getParameter("message");
		 type=request.getParameter("type");
		 }
		 catch(Exception e){
			 message="";type="";
		 }
				
		 try{
			 try{
			page = Integer.parseInt(request.getParameter("pageNum"));
			 }
			 catch(Exception e){
				 page =1;
			 }
			 logger.info("page==>"+ page);
			 FileDetails fileDetailDto= new FileDetails();
			 
			logger.info("Payment Transfer records0==>"+ "current page==> "+page +" total records==> "+fileDetailDto.getTotalResult());
			logger.info("Payment Transfer records1==>"+ "resultsPerPage==> "+fileDetailDto.getResultPerPage() +" totalPages==> "+fileDetailDto.getTotalPages());
			
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.addObject("totalRecords",fileDetailDto.getTotalResult());
			modelAndViewObj.addObject("resultsPerPage",fileDetailDto.getResultPerPage());
			modelAndViewObj.addObject("totalPages", fileDetailDto.getTotalPages());
			modelAndViewObj.addObject("fileDetailList", fileDetailDto.getPaymentTransferDetailsList());
			modelAndViewObj.addObject("filtersearch", "true");
			modelAndViewObj.addObject("message", message);
			modelAndViewObj.addObject("fileId", "-1");
			modelAndViewObj.addObject("acctNo", "-1");
			modelAndViewObj.addObject("lob", "-1");
			modelAndViewObj.addObject("status", "-1");
			modelAndViewObj.addObject("uploadDate", "-1");
			modelAndViewObj.addObject("role", role);
			 
		 }
		 catch(Exception e1){
			 e1.printStackTrace();
			 page =1;
		 }
		 return modelAndViewObj;

	}
	
	@RequestMapping(value = "/searchBulkPaymentTransfer")
	public ModelAndView searchBulkPaymentTransfer(ModelMap model,HttpServletRequest request,HttpServletResponse response) throws IOException {
		logger.info("START ------>searchBulkPaymentTransfer");
		int page = 1;
		session = request.getSession(true);
		ModelAndView modelAndViewObj = new ModelAndView();	
		String roleId = session.getAttribute("user_role_id").toString();
		String userId=session.getAttribute("userid").toString();
		boolean noSearchCriteria=true;		
		String fileId= request.getParameter("fileId");
		String accountNo =  request.getParameter("accountNo");
		String lob = request.getParameter("lobSearch");
		String status = request.getParameter("status");
		String uploadDate= request.getParameter("fromDateId");
		logger.info("fileid==>accountNo==>"+ fileId+">>"+accountNo);		
		
		try {
			if(request.getParameter("pageNum")!=null){
				paymentTransferDTO.setCurrentPage(Integer.parseInt(request.getParameter("pageNum")));
				noSearchCriteria=false;
			}else
				paymentTransferDTO.setCurrentPage(page);
			
			if(request.getParameter("fileId")!=null){
				paymentTransferDTO.setSearchFileId(fileId);
				noSearchCriteria=false;
			}else
				paymentTransferDTO.setSearchFileId(null);
			
			if(request.getParameter("accountNo")!=null){
				paymentTransferDTO.setAccountNo(accountNo);
				noSearchCriteria=false;
			}else
				paymentTransferDTO.setAccountNo(null);
			
			if(request.getParameter("lobSearch")!=null){
				paymentTransferDTO.setLob(lob);
				noSearchCriteria=false;
			}else
				paymentTransferDTO.setLob(null);
			
			if(request.getParameter("status")!=null){
				paymentTransferDTO.setStatus(status);
				noSearchCriteria=false;
			}else
				paymentTransferDTO.setStatus(null);
			
			if(request.getParameter("fromDateId")!=null){
				paymentTransferDTO.setFile_upload_date(uploadDate);
				noSearchCriteria=false;
			}else
				paymentTransferDTO.setFile_upload_date(null);
		try{
			paymentTransferDTO = bulkDao.searchPaymentTransferRecords(roleId,userId,paymentTransferDTO);		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
					
		/*	modelAndViewObj.addObject("totalRecords",paymentTransferDTO.getTotalResults());
			modelAndViewObj.addObject("resultsPerPage",paymentTransferDTO.getResultPerPage());			
			modelAndViewObj.addObject("paymentTransferDetailList", paymentTransferDTO.getPaymentTransferDetailList());
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.addObject("totalPages", paymentTransferDTO.getTotalPages());
			modelAndViewObj.addObject("message", paymentTransferDTO.getErrorMsg());
			modelAndViewObj.addObject("paymentTransferDTO",new PaymentTransferDTO());			
			modelAndViewObj.addObject("rejectReasonList", rejectReasonList);
			modelAndViewObj.setViewName("paymentTransferApproval");*/
			
			modelAndViewObj.addObject("fileId",fileId );
			modelAndViewObj.addObject("accountNo", accountNo);
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.addObject("totalRecords",paymentTransferDTO.getTotalResults());
			modelAndViewObj.addObject("resultsPerPage",paymentTransferDTO.getResultPerPage());
			modelAndViewObj.addObject("totalPages", paymentTransferDTO.getTotalPages());
			modelAndViewObj.addObject("paymentTransferDetailList",  paymentTransferDTO.getPaymentTransferDetailList());
			modelAndViewObj.addObject("filtersearch", "false");
			modelAndViewObj.addObject("role", roleId);
            modelAndViewObj.setViewName("bulkTransfer");
			
			if(CommonValidator.isNull(fileId))
				modelAndViewObj.addObject("fileId","-1");
			else
				modelAndViewObj.addObject("fileId", fileId);
			
			if(CommonValidator.isNull(accountNo))
				modelAndViewObj.addObject("acctNo", "-1");
			else
				modelAndViewObj.addObject("acctNo", accountNo);
			
			if(CommonValidator.isNull(lob))
				modelAndViewObj.addObject("lob", "-1");
			else
				modelAndViewObj.addObject("lob", lob);
			
			if(CommonValidator.isNull(status))
				modelAndViewObj.addObject("status", "-1");
			else
				modelAndViewObj.addObject("status", status);
			
			if(CommonValidator.isNull(uploadDate))
				modelAndViewObj.addObject("uploadDate", "-1");
			else
				modelAndViewObj.addObject("uploadDate", uploadDate);
		} catch (Exception e) {
			logger.error(e);
		}
					
		return modelAndViewObj;
	}
	
	
	@RequestMapping(value="/downloadPTReportExcel",method=RequestMethod.GET)
	public void exportExcelSuspenseAllocationReport(HttpServletRequest request,HttpServletResponse response){
		 String[] columns = {"Payment Mode","File Id",
				 "File Upload Date", "Request Raised by (OLM ID)","Request Raised by (Name)","Orig Tracking Id","Orig Tracking Id Serv"	,"Total Orig Tracking Amount(Rs.)"	,
				 "Account No","Record Id",	"B2B/B2C" ,"Invoice no (Given by the User)","Payment Transfer Exemption (Yes/No)",
				 "Amount(Rs.)","Legal Entity"	,"Received for CAD Approval","Approved By(OLM ID)","Approved By(NAME)",
				 "Approval Date","Status","FX Updated Date" 
				 ,"Reason For Failure","FX Posting Status","FX Posting Error Description"};
		  
		  
		  String fileId="";
		  String acctNo ="";
		  String lob ="";
		  String status ="";
		  String uploadDate ="";
		  session=request.getSession(true);
	       String userId=session.getAttribute("userid").toString();
			String role=session.getAttribute("user_role_id").toString();

		  try{
			  
			  try{
				  
				  fileId= request.getParameter("fileId");
				  if(fileId!=null)
					  paymentTransferDTO.setSearchFileId(fileId);
				  acctNo= request.getParameter("acctNo");
				  if(acctNo!=null)
					  paymentTransferDTO.setAccountNo(acctNo);
				  lob= request.getParameter("lob");
				  if(lob!=null)
					  paymentTransferDTO.setLob(lob);
				  status= request.getParameter("status");
				  if(status!=null)
					  paymentTransferDTO.setStatus(status);
				  uploadDate= request.getParameter("uploadDate");
				  if(uploadDate!=null)
					  paymentTransferDTO.setFile_upload_date(uploadDate);
					logger.info("In download excel file for downloadPTReportExcel ==fileId==>"+ fileId+"==>acctNo:"+acctNo+"===lob:"+lob
							+"==status:"+status+"==uploadDate:"+uploadDate);
				 }
					 catch(Exception e){
						e.printStackTrace();
			 }
			
			  paymentTransferDTO= bulkDao.downloadsPTReports(role,userId,paymentTransferDTO);
			
		     List<PaymentTransferDTO> paymentTransferDetailList = null;	
		     response.setContentType("application/vnd.ms-excel");
		     response.setHeader("Content-Disposition", "attachment;filename=PaymentTransferTransLevelReport.xls");

		    if(paymentTransferDTO!= null)
		    	paymentTransferDetailList = paymentTransferDTO.getPaymentTransferDetailList();
		    
		Workbook workbook = new HSSFWorkbook();//new XSSFWorkbook();use for .xlsx file
		Sheet sheet = workbook.createSheet("PaymentTransfer Trans Level Report");
		Font headerFont = workbook.createFont();
		 headerFont.setBold(true);
	     headerFont.setFontHeightInPoints((short) 10);
	     headerFont.setColor(IndexedColors.GREEN.getIndex());
	     
	     CellStyle headerCellStyle = workbook.createCellStyle();
	     headerCellStyle.setFont(headerFont);
	     
	     Row headerRow = sheet.createRow(0);
	    
	  // Create cells
	        for(int i = 0; i < columns.length; i++) {
	            Cell cell = headerRow.createCell(i);
	            cell.setCellValue(columns[i]);
	            cell.setCellStyle(headerCellStyle);
	        }
	        
	        int rowNum = 1;
	        
	        for(PaymentTransferDTO xlsData: paymentTransferDetailList) {
	            Row row = sheet.createRow(rowNum++);
	            row.createCell(0).setCellValue(xlsData.getPayment_mode());
	            row.createCell(1).setCellValue(xlsData.getFile_id());
	            row.createCell(2).setCellValue(xlsData.getFile_upload_date());
	            row.createCell(3).setCellValue(xlsData.getVendor_userId());
	            row.createCell(4).setCellValue(xlsData.getUploadedUserName());
	            row.createCell(5).setCellValue(xlsData.getOrigTrackingId());
	            row.createCell(6).setCellValue(xlsData.getOrigTrackingIdServ());
	            row.createCell(7).setCellValue(xlsData.getOrigTrackingTotalAmount());
	            row.createCell(8).setCellValue(xlsData.getAccountNo());
	            row.createCell(9).setCellValue(xlsData.getTransactionId());
	            row.createCell(10).setCellValue(xlsData.getB2b2c());
	            row.createCell(11).setCellValue(xlsData.getInvoiceNo());
	            row.createCell(12).setCellValue(xlsData.getAttached_file());
	            row.createCell(13).setCellValue(xlsData.getAmount());
	            row.createCell(14).setCellValue(xlsData.getLegalEntity());
	            row.createCell(15).setCellValue(xlsData.getCadApprovalReceived());
	            row.createCell(16).setCellValue(xlsData.getApprovedBy());
	            row.createCell(17).setCellValue(xlsData.getApprovedByName());
	            row.createCell(18).setCellValue(xlsData.getApprovedDate());
	            row.createCell(19).setCellValue(xlsData.getStatus());
	            row.createCell(20).setCellValue(xlsData.getFxPostedDate());
	            row.createCell(21).setCellValue(xlsData.getStatusDesc());
	            row.createCell(22).setCellValue(xlsData.getFxStatus());
	            row.createCell(23).setCellValue(xlsData.getFxStatusDesc());
	         }
	        
	     // Resize all columns to fit the content size
	        for(int i = 0; i < columns.length; i++) {
	            sheet.autoSizeColumn(i);
	        }
	        workbook.write(response.getOutputStream());
	        response.getOutputStream().close();
	       
	        workbook.close();
		  }
		  catch(Exception e){
			  logger.error("Exception in ExcelDownload==="+ e.getMessage());
		  }

	}
	
	@RequestMapping(value = "/adviceBulk")
	public ModelAndView paymentAdviceBulk() {

		ModelAndView modelAndViewObj = new ModelAndView();
		modelAndViewObj.setViewName("paymentAdviceBulk");
		return modelAndViewObj;

	}
	@RequestMapping(value = "/bulkUploadCheque", method = RequestMethod.POST)
	public ModelAndView bulkProcessing(
			@RequestParam("xlsFile") MultipartFile file,
			HttpServletRequest request) throws Exception {
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();


		logger.info("ENTERED INTO Bulkupload Cheque format");

		ModelAndView modelAndViewObj = new ModelAndView();
		String filename = file.getOriginalFilename();
		if(filename.length()>=22)
		{
			//Commented by APS Team to implement Market Code
			/*String subString2= filename.substring(9, 11);
			String subString3= filename.substring(11, 13);*/
			//Added by APS Team
			String subString2= filename.substring(10, 12);//Date Check fields
			String subString3= filename.substring(12, 14);//Date Check fields

			boolean status1=true;
			boolean status2=true;
			boolean status=false;
			//Commented by APS Team to implement Market Code
			//String circleString=filename.substring(0,2);
			//Added by APS Team
			String circleString=filename.substring(0,3);

			List<String> circleList=new ArrayList<String>();
			//Commented by APS Team to implement Market Code
			/*	circleList=bulkDao.getUserCircles();

			for(String circle:circleList)
			{
				if(circle.equalsIgnoreCase(circleString))
				{
				  status=true;
				}
			 }*/

			//Added by APS Team
			boolean circleStatus = bulkDao.checkCircle(circleString);
			if(circleStatus){
				status=true;
			}
			try
			{
				if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
					status1=false;
				if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
					status2=false;
			}
			catch(Exception e)
			{
				modelAndViewObj.addObject("error",
						"File Name format - XXX_PMT_YYMMDD_CHQ_NNNN.xls.Please Correct the Name and upload again!");
				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
			}
			////Commented by APS Team to implement Market Code
			//if(filename.matches("^[0-9A-Za-z]{2}[_][P][M][T][_][0-9]{2}[0-1][0-9][0-3][0-9][_][A-Za-z0-9]{3}[_][0-9]{4}[.][x][l][s][x]?")&&status1&&status2&&status)
			if(filename.matches("^[0-9]{3}[_][P][M][T][_][0-9]{2}[0-1][0-9][0-3][0-9][_][A-Za-z0-9]{3}[_][0-9]{4}[.][x][l][s][x]?")&&status1&&status2&&status) 
				System.out.println("valid file name");
			else
			{
				modelAndViewObj.addObject("error",
						"File Name format - XXX_PMT_YYMMDD_CHQ_NNNN.xlsx,Please Correct the Name and upload again");
				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
				/*modelAndViewObj.addObject("error",
						"File Name format - XX_PMT_YYMMDD_CHQ_NNNN.xls,Please Correct the Name and upload again");
				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;*/
			}
		}
		else
		{
			modelAndViewObj.addObject("error",
					"File Name format - XXX_PMT_YYMMDD_CHQ_NNNN.xls,Please Correct the Name and upload again");
			modelAndViewObj.setViewName("bulk");
			return modelAndViewObj;
			/*
				modelAndViewObj.addObject("error",
						"File Name format - XX_PMT_YYMMDD_CHQ_NNNN.xls,Please Correct the Name and upload again");
				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;*/
		}

		String isFileValid = BulkUtil.validateUploadedFile(file);
		String fileName=file.getOriginalFilename();
		//ExcelReader excelReader=new ExcelReader();
		FileUploadResult fileUpload =null;
		InputStream inputStream = null;

		try {
			byte[] bytes = file.getBytes();
			inputStream = new ByteArrayInputStream(bytes);
		}catch (IOException e) {
			logger.error(e);
		}
		if (isFileValid.equalsIgnoreCase("xls"))

		{

			logger.info("  Cheque xls format");
			//SNo=activityLogDao.insertActivityLog(SNo,userId,"File validating","success","valid xls file");
			String type = request.getParameter("submit");

			if (type.equalsIgnoreCase("Upload File")) {
				logger.info("valid xls file");


				fileUpload = excelReader.readFromExcelfile(fileName,"CHQ", "UI", userId, "",inputStream,"Payments",null,null);
				logger.info("valid xls file ->"+fileUpload.getStatus());
				logger.info("valid xls file fileUpload.getStatusDescription() ->"+fileUpload.getStatusDescription());
				//modelAndViewObj=bulkutil.validatexls(file, request,downloadpath,errorFilesPath,isFileValid)	;
				//		System.out.println("modelobj"+modelAndViewObj.g);
				if(fileUpload.getStatus() == 1){
					logger.info("Inside Payment file transfer to done Folder->>"+downloadpath);
					logger.info("Inside Payment file transfer to done fileName->>"+fileName);

					fileUpload(file,downloadpath,fileName);

				}else{
					
					fileUpload(file,errorFilesPath,fileName);
				}

				if(fileUpload.getStatusDescription().contains("Records Successfully Inserted")){
					FileDetails fileDetailsObj=new FileDetails();

					fileDetailsObj.setFileID(fileUpload.getFileId());
					fileDetailsObj.setOriginalFileName(fileName);
					fileDetailsObj.setStatus("");


					modelAndViewObj.addObject("status",
							fileDetailsObj.getStatus());
					modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj);
					modelAndViewObj.addObject("extension", ".xls");
					modelAndViewObj.setViewName("bulkUploadSuccess");
					modelAndViewObj.setViewName("bulkUploadSuccess");
				}
				else{
					modelAndViewObj.addObject("error",fileUpload.getStatusDescription());
					modelAndViewObj.setViewName("bulk");
				}

				return modelAndViewObj;
			}

		}
		else if(isFileValid.equalsIgnoreCase("xlsx"))
		{
			logger.info("  Cheque xlsx format");
			String type = request.getParameter("submit");
			//SNo=activityLogDao.insertActivityLog(SNo,userId,"File Uploading","success","valid xlsx file");
			if (type.equalsIgnoreCase("Upload File")) {
				logger.info("valid xlsx file");


				logger.info("valid xls file");


				fileUpload = excelReader.readFromExcelfile(fileName,"CHQ", "UI", userId, "",inputStream,"Payments",null,null);

				//modelAndViewObj=bulkutil.validatexls(file, request,downloadpath,errorFilesPath,isFileValid)	;
				//		System.out.println("modelobj"+modelAndViewObj.g);
				if(fileUpload.getStatus() == 1){
					logger.info("Inside Payment file transfer to done Folder->>"+downloadpath);
					logger.info("Inside Payment file transfer to done fileName->>"+fileName);

					fileUpload(file,downloadpath,fileName);

				}else{
					
					fileUpload(file,errorFilesPath,fileName);
				}
				
				if(fileUpload.getStatusDescription().contains("Records Successfully Inserted")){
					FileDetails fileDetailsObj=new FileDetails();

					fileDetailsObj.setFileID(fileUpload.getFileId());
					fileDetailsObj.setOriginalFileName(fileName);
					fileDetailsObj.setStatus("");


					modelAndViewObj.addObject("status",
							fileDetailsObj.getStatus());
					modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj);
					modelAndViewObj.addObject("extension", ".xlsx");
					modelAndViewObj.setViewName("bulkUploadSuccess");
					modelAndViewObj.setViewName("bulkUploadSuccess");
				}
				else{
					modelAndViewObj.addObject("error",fileUpload.getStatusDescription());
					modelAndViewObj.setViewName("bulk");
				}

				return modelAndViewObj;



				//modelAndViewObj=bulkutil.validatexlsx(file, request,downloadpath,errorFilesPath,isFileValid);
				//return modelAndViewObj;

			}
		}

		else {
			Long SNo=0l;
			try{
				SNo=activityLogDao.insertActivityLog(0l,userId,"file upload",null,null,fileName,null,null);
			}
			catch(SQLException sqlexception)
			{
				StringWriter errors= new StringWriter();
				sqlexception.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("error","DB Connectivity issues");
				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
			}
			try{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","wrong file format",fileName,null,null);
			}
			catch(SQLException sqlexception)
			{
				sqlexception.printStackTrace();
				modelAndViewObj.addObject("error","DB Connectivity issues");
				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
			}
			//System.out.println("sno in activity log"+SNo);
			logger.info("File is not valid!!");

			modelAndViewObj.addObject("error",
					"Uploaded file is not  excel!!");
			modelAndViewObj.setViewName("bulk");
			return modelAndViewObj;

		}



		return modelAndViewObj;

	}
	public static String fileUpload(MultipartFile file,String downloadpath,String fileName)
	{

		try {
			file.transferTo(new java.io.File(downloadpath, fileName));


			// System.out.println("file name in BulkUtil..." + fileId);

		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	@RequestMapping(value = "/bankStatement", method = RequestMethod.POST)
	public ModelAndView bankStatementProcessing(
			@RequestParam("xlsFile") MultipartFile file,
			HttpServletRequest request) throws Exception {
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		//BulkUtil bulkutil=new BulkUtil();

		logger.info("Entered  into Neft ");
		String fileName=file.getOriginalFilename();

		ModelAndView modelAndViewObj = new ModelAndView();
		List<String> circleList=new ArrayList<String>();
		circleList=bulkDao.getUserCircles();

		String filename = file.getOriginalFilename();
		boolean status=false;
		//Commented By APS
		/*	String circleString=filename.substring(0,2);
		  for(String circle:circleList)
			{
				if(circle.equalsIgnoreCase(circleString))
				{
					 status=true;
				}
			}*/
		//Added By APS Team
		String circleString=filename.substring(0,3);
		boolean circleStatus = bulkDao.checkCircle(circleString);
		if(circleStatus){
			status=true;
		}
		if(filename.length()>=22)
		{
			//String subString2= filename.substring(9, 11);//Date Check fields
			//String subString3= filename.substring(11, 13);//Date Check fields 
			//Added by APS Team
			String subString2= filename.substring(10, 12);
			String subString3= filename.substring(12, 14);
			boolean status1=true;
			boolean status2=true;
			try
			{
				if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
					status1=false;
				if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
					status2=false;
			}
			catch(Exception e)
			{
				//Changes done by APS Team
				/*modelAndViewObj.addObject("error",
						"File Name format - XX_PMT_YYMMDD_CHQ_NNNN.xls,Please Correct the Name and upload again");*/

				modelAndViewObj.addObject("error",
						"File Name format - XXX_PMT_YYMMDD_EFT_NNNN.xls,Please Correct the Name and upload again");

				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
			}
			//Commented by APS Team	
			//	if(filename.matches("^[0-9A-Za-z]{2}[_][P][M][T][_][0-9]{2}[0-1][0-9][0-3][0-9][_][A-Za-z0-9]{3}[_][0-9]{4}[.][x][l][s][x]?")&&status1&&status2&&status)
			if(filename.matches("^[0-9]{3}[_][P][M][T][_][0-9]{2}[0-1][0-9][0-3][0-9][_][A-Za-z0-9]{3}[_][0-9]{4}[.][x][l][s][x]?")&&status1&&status2&&status)
				System.out.println("valid file name");
			else
			{
				//Changes done by APS Team
				/*modelAndViewObj.addObject("error",
						"File Name format - XX_PMT_YYMMDD_CHQ_NNNN.xls,Please Correct the Name and upload again");*/
				modelAndViewObj.addObject("error",
						"File Name format - XXX_PMT_YYMMDD_EFT_NNNN.xls,Please Correct the Name and upload again");
				modelAndViewObj.setViewName("bulk");
				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
			}
		}
		else
		{
			//Changes done by APS Team
			/*modelAndViewObj.addObject("error",
						"File Name format - XX_PMT_YYMMDD_CHQ_NNNN.xls,Please Correct the Name and upload again");*/

			modelAndViewObj.addObject("error",
					"File Name format - XXX_PMT_YYMMDD_EFT_NNNN.xls,Please Correct the Name and upload again");
			modelAndViewObj.setViewName("bulk");
			return modelAndViewObj;
		}
		//modelAndViewObj.addObject("uploadTypeList",uploadType);

		//int SNo=activityLogDao.insertActivityLog(0,userId,"file upload",null,null);

		String isFileValid = BulkUtil.validateUploadedFile(file);
		FileUploadResult fileUpload =null;
		InputStream inputStream = null;
		try {
			byte[] bytes = file.getBytes();
			inputStream = new ByteArrayInputStream(bytes);
		}catch (IOException e) {
			logger.error(e);
		}
		if (isFileValid.equalsIgnoreCase("xls"))

		{
			//SNo=activityLogDao.insertActivityLog(SNo,userId,"File validating","success","valid xls file");
			String type = request.getParameter("submit");

			if (type.equalsIgnoreCase("Upload File")) {
				logger.info("valid xls file");

				fileUpload = excelReader.readFromExcelfile(fileName,"EFT", "UI", userId, "",inputStream,"Payments",null,null);
				logger.info("valid xls file ->"+fileUpload.getStatus());
				logger.info("valid xls file fileUpload.getStatusDescription() ->"+fileUpload.getStatusDescription());

				//modelAndViewObj=bulkutil.validatexlsBankStatement(file, request,downloadpath,errorFilesPath,isFileValid);
				//		System.out.println("modelobj"+modelAndViewObj.g);
				if(fileUpload.getStatus() == 1){
					logger.info("Inside Payment file transfer to done Folder->>"+downloadpath);
					logger.info("Inside Payment file transfer to done fileName->>"+fileName);

					fileUpload(file,downloadpath,fileName);

				}else{
					
					fileUpload(file,errorFilesPath,fileName);
				}
				if(fileUpload.getStatusDescription().contains("Records Successfully Inserted")){
					FileDetails fileDetailsObj=new FileDetails();

					fileDetailsObj.setFileID(fileUpload.getFileId());
					fileDetailsObj.setOriginalFileName(fileName);
					fileDetailsObj.setStatus("");


					modelAndViewObj.addObject("status",
							fileDetailsObj.getStatus());
					modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj);
					modelAndViewObj.addObject("extension", ".xls");
					modelAndViewObj.setViewName("bulkUploadSuccess");
					modelAndViewObj.setViewName("bulkUploadSuccess");
				}
				else{
					modelAndViewObj.addObject("error",fileUpload.getStatusDescription());
					modelAndViewObj.setViewName("bulk");
				}

				return modelAndViewObj;

				//	modelAndViewObj.addObject("uploadTypeList",uploadType);
				//return modelAndViewObj;

			}

		}
		else if(isFileValid.equalsIgnoreCase("xlsx"))
		{
			String type = request.getParameter("submit");
			//SNo=activityLogDao.insertActivityLog(SNo,userId,"File Uploading","success","valid xlsx file");
			if (type.equalsIgnoreCase("Upload File")) {
				logger.info("valid xls file");

				fileUpload = excelReader.readFromExcelfile(fileName,"EFT", "UI", userId, "",inputStream,"Payments",null,null);
				logger.info("valid xls file ->"+fileUpload.getStatus());
				logger.info("valid xls file fileUpload.getStatusDescription() ->"+fileUpload.getStatusDescription());

				//modelAndViewObj=bulkutil.validatexlsBankStatement(file, request,downloadpath,errorFilesPath,isFileValid);
				//		System.out.println("modelobj"+modelAndViewObj.g);
				if(fileUpload.getStatus() == 1){
					logger.info("Inside Payment file transfer to done Folder->>"+downloadpath);
					logger.info("Inside Payment file transfer to done fileName->>"+fileName);

					fileUpload(file,downloadpath,fileName);

				}else{
					
					fileUpload(file,errorFilesPath,fileName);
				}
				if(fileUpload.getStatusDescription().contains("Records Successfully Inserted")){
					FileDetails fileDetailsObj=new FileDetails();

					fileDetailsObj.setFileID(fileUpload.getFileId());
					fileDetailsObj.setOriginalFileName(fileName);
					fileDetailsObj.setStatus("");


					modelAndViewObj.addObject("status",
							fileDetailsObj.getStatus());
					modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj);
					modelAndViewObj.addObject("extension", ".xlsx");
					modelAndViewObj.setViewName("bulkUploadSuccess");
					modelAndViewObj.setViewName("bulkUploadSuccess");
				}
				else{
					modelAndViewObj.addObject("error",fileUpload.getStatusDescription());
					modelAndViewObj.setViewName("bulk");
				}

				return modelAndViewObj;

				//	modelAndViewObj.addObject("uploadTypeList",uploadType);
				//return modelAndViewObj;

			}
		}

		else {
			Long SNo=0l;
			try{
				SNo=activityLogDao.insertActivityLog(0l,userId,"file upload",null,null,fileName,null,null);
			}
			catch(SQLException sqlexception)
			{
				StringWriter errors= new StringWriter();
				sqlexception.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("error","DB Connectivity issues");
				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
			}
			try{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","wrong file format",fileName,null,null);
			}
			catch(SQLException sqlexception)
			{
				StringWriter errors= new StringWriter();
				sqlexception.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("error","DB Connectivity issues");
				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
			}
			//System.out.println("sno in activity log"+SNo);
			logger.info("File is not valid!!");

			modelAndViewObj.addObject("error",
					"Uploaded file is not  excel!!");
			modelAndViewObj.setViewName("bulk");
			return modelAndViewObj;

		}


		final long duration = System.nanoTime() - startTime;

		return modelAndViewObj;

	}
	@RequestMapping(value = "/MISC", method = RequestMethod.POST)
	public ModelAndView OTHERSProcessing(
			@RequestParam("xlsFile") MultipartFile file,
			HttpServletRequest request) throws Exception {
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		List<String> uploadType=new ArrayList<String>();
		//BulkUtil bulkutil=new BulkUtil();
		String fileName=file.getOriginalFilename();

		ModelAndView modelAndViewObj = new ModelAndView();
		logger.info("Entered into MISC");

		//int SNo=activityLogDao.insertActivityLog(0,userId,"File validating",null,null);
		List<String> circleList=new ArrayList<String>();
		boolean status=false;

		String filename = file.getOriginalFilename();
		//Commented By APS Team
		/*circleList=bulkDao.getUserCircles();
			String circleString=filename.substring(0,2);
			for(String circle:circleList)
			{
				if(circle.equalsIgnoreCase(circleString))
				{
				 status=true;
				 }
			}*/
		String circleString=filename.substring(0,3);
		boolean circleStatus = bulkDao.checkCircle(circleString);
		if(circleStatus){
			status=true;
		}
		if(filename.length()>=22)
		{
			//Commented By APS Team
			/* String subString2= filename.substring(9, 11);
		 String subString3= filename.substring(11, 13);*/

			String subString2= filename.substring(10, 12);
			String subString3= filename.substring(12, 14);
			boolean status1=true;
			boolean status2=true;
			try
			{
				if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
					status1=false;
				if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
					status2=false;
			}
			catch(Exception e)
			{
				//Changes done by APS Team
				/*modelAndViewObj.addObject("error",
						"File Name format - XX_PMT_YYMMDD_CHQ_NNNN.xls,Please Correct the Name and upload again");*/

				modelAndViewObj.addObject("error",
						"File Name format - XXX_PMT_YYMMDD_MIS_NNNN.xls,Please Correct the Name and upload again");

				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
			}
			//Commented By APS Team
			//if(filename.matches("^[0-9A-Za-z]{2}[_][P][M][T][_][0-9]{2}[0-1][0-9][0-3][0-9][_][A-Za-z0-9]{3}[_][0-9]{4}[.][x][l][s][x]?")&&status1&&status2&&status)
			if(filename.matches("^[0-9]{3}[_][P][M][T][_][0-9]{2}[0-1][0-9][0-3][0-9][_][A-Za-z0-9]{3}[_][0-9]{4}[.][x][l][s][x]?")&&status1&&status2&&status) 
				System.out.println("valid file name");
			else
			{
				//Changes Done By APS Team
				/*modelAndViewObj.addObject("error",
						"File Name format - XX_PMT_YYMMDD_CHQ_NNNN.xls,Please Correct the Name and upload again");*/

				modelAndViewObj.addObject("error",
						"File Name format - XXX_PMT_YYMMDD_MIS_NNNN.xls,Please Correct the Name and upload again");

				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
			}
		}
		else
		{
			//Changed by APS Team
			/*modelAndViewObj.addObject("error",
				"File Name format - XX_PMT_YYMMDD_CHQ_NNNN.xls,Please Correct the Name and upload again");*/

			modelAndViewObj.addObject("error",
					"File Name format - XXX_PMT_YYMMDD_MIS_NNNN.xls,Please Correct the Name and upload again");

			modelAndViewObj.setViewName("bulk");
			return modelAndViewObj;
		}
		String isFileValid = BulkUtil.validateUploadedFile(file);
		FileUploadResult fileUpload =null;
		InputStream inputStream = null;
		try {
			byte[] bytes = file.getBytes();
			inputStream = new ByteArrayInputStream(bytes);
		}catch (IOException e) {
			logger.error(e);
		}
		if (isFileValid.equalsIgnoreCase("xls"))

		{
			//SNo=activityLogDao.insertActivityLog(SNo,userId,"File validating","success","valid xls file");
			String type = request.getParameter("submit");

			if (type.equalsIgnoreCase("Upload File")) {
				logger.info("valid xls file");

				fileUpload = excelReader.readFromExcelfile(fileName,"MIS", "UI", userId, "",inputStream,"Payments",null,null);
				logger.info("valid xls file ->"+fileUpload.getStatus());
				logger.info("valid xls file fileUpload.getStatusDescription() ->"+fileUpload.getStatusDescription());
				//modelAndViewObj=bulkutil.validatexlsOthers(file, request,downloadpath,errorFilesPath,isFileValid)	;
				//		System.out.println("modelobj"+modelAndViewObj.g);
				if(fileUpload.getStatus() == 1){
					logger.info("Inside Payment file transfer to done Folder->>"+downloadpath);
					logger.info("Inside Payment file transfer to done fileName->>"+fileName);

					fileUpload(file,downloadpath,fileName);

				}else{
					
					fileUpload(file,errorFilesPath,fileName);
				}
				if(fileUpload.getStatusDescription().contains("Records Successfully Inserted")){
					FileDetails fileDetailsObj=new FileDetails();

					fileDetailsObj.setFileID(fileUpload.getFileId());
					fileDetailsObj.setOriginalFileName(fileName);
					fileDetailsObj.setStatus("");


					modelAndViewObj.addObject("status",
							fileDetailsObj.getStatus());
					modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj);
					modelAndViewObj.addObject("extension", ".xls");
					modelAndViewObj.setViewName("bulkUploadSuccess");
					modelAndViewObj.setViewName("bulkUploadSuccess");
				}
				else{
					modelAndViewObj.addObject("error",fileUpload.getStatusDescription());
					modelAndViewObj.setViewName("bulk");
				}

				return modelAndViewObj;



				//return modelAndViewObj;

			}

		}
		else if(isFileValid.equalsIgnoreCase("xlsx"))
		{
			String type = request.getParameter("submit");
			//SNo=activityLogDao.insertActivityLog(SNo,userId,"File Uploading","success","valid xlsx file");
			if (type.equalsIgnoreCase("Upload File")) {
				logger.info("valid xls file");

				fileUpload = excelReader.readFromExcelfile(fileName,"MIS", "UI", userId, "",inputStream,"Payments",null,null);
				logger.info("valid xls file ->"+fileUpload.getStatus());
				logger.info("valid xls file fileUpload.getStatusDescription() ->"+fileUpload.getStatusDescription());
				//modelAndViewObj=bulkutil.validatexlsOthers(file, request,downloadpath,errorFilesPath,isFileValid)	;
				//		System.out.println("modelobj"+modelAndViewObj.g);
				if(fileUpload.getStatus() == 1){
					logger.info("Inside Payment file transfer to done Folder->>"+downloadpath);
					logger.info("Inside Payment file transfer to done fileName->>"+fileName);

					fileUpload(file,downloadpath,fileName);

				}else{
					
					fileUpload(file,errorFilesPath,fileName);
				}
				if(fileUpload.getStatusDescription().contains("Records Successfully Inserted")){
					FileDetails fileDetailsObj=new FileDetails();

					fileDetailsObj.setFileID(fileUpload.getFileId());
					fileDetailsObj.setOriginalFileName(fileName);
					fileDetailsObj.setStatus("");


					modelAndViewObj.addObject("status",
							fileDetailsObj.getStatus());
					modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj);
					modelAndViewObj.addObject("extension", ".xlsx");
					modelAndViewObj.setViewName("bulkUploadSuccess");
					modelAndViewObj.setViewName("bulkUploadSuccess");
				}
				else{
					modelAndViewObj.addObject("error",fileUpload.getStatusDescription());
					modelAndViewObj.setViewName("bulk");
				}

				return modelAndViewObj;


			}
		}

		else {
			Long SNo=0l;
			try{
				SNo=activityLogDao.insertActivityLog(0l,userId,"file upload",null,null,fileName,null,null);
			}
			catch(SQLException sqlexception)
			{
				StringWriter errors= new StringWriter();
				sqlexception.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("error","DB Connectivity issues");
				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
			}
			try{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","wrong file format",fileName,null,null);
			}
			catch(SQLException sqlexception)
			{
				StringWriter errors= new StringWriter();
				sqlexception.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("error","DB Connectivity issues");
				modelAndViewObj.setViewName("bulk");
				return modelAndViewObj;
			}
			//System.out.println("sno in activity log"+SNo);
			logger.info("File is not valid!!");

			modelAndViewObj.addObject("error",
					"Uploaded file is not  excel!!");
			modelAndViewObj.setViewName("bulk");
			return modelAndViewObj;

		}


		return modelAndViewObj;

	}


	/*@RequestMapping(value = "/paymentApproval")
	public ModelAndView paymentApproval(HttpServletRequest request) {

		List<PaymentAdviceFileDetails> adviceApprovalList = new ArrayList<PaymentAdviceFileDetails>();
		ModelAndView modelAndViewObj = new ModelAndView();
		session=request.getSession(true);
		int page = 1,totalPages = 0;
		String errorMessage,errorCode;
		String fileId=request.getParameter("FileIDSearch");
		String activeDate = request.getParameter("startDate");
		String endDate=request.getParameter("endDate");
		String paymentMode=request.getParameter("paymentMode");
		String userId=session.getAttribute("userid").toString();
		String vendorUserId=request.getParameter("UserId");
		String role=session.getAttribute("user_role_id").toString();
		logger.info("Entered into Payment Approval");


		Map<Map<Integer,List<String>>, List<FileDetails>> fileDetailsList=bulkDao.retreiveDetailsForSpocbasedOnSearch(page,fileId,activeDate,endDate,userId,role,paymentMode,vendorUserId);

		if(fileDetailsList!=null){
			Set mapSet = (Set) fileDetailsList.entrySet();
			Iterator mapIterator = mapSet.iterator();
			while (mapIterator.hasNext()) {
				Map.Entry<Map<Integer,List<String>>, List<FileDetails>> mapEntry = (Map.Entry<Map<Integer,List<String>>, List<FileDetails>>) mapIterator.next();
				Map<Integer,List<String>> totalPagesAndErrorDetailsList;
				totalPagesAndErrorDetailsList=mapEntry.getKey();
				Set totalPagesAndErrorsSet = (Set) totalPagesAndErrorDetailsList.entrySet();
				Iterator totalPagesAndErrorsIterator = totalPagesAndErrorsSet.iterator();
				while (totalPagesAndErrorsIterator.hasNext()) {
					Map.Entry<Integer,List<String>> totalPagesAndErrorsEntry = (Map.Entry<Integer,List<String>>) totalPagesAndErrorsIterator.next();
					totalPages=totalPagesAndErrorsEntry.getKey();
					errorCode=totalPagesAndErrorsEntry.getValue().get(0);
					errorMessage=totalPagesAndErrorsEntry.getValue().get(1);
				}
				List<FileDetails> fileDetails;
				fileDetails=(List<FileDetails>) mapEntry.getValue();
				modelAndViewObj.addObject("fileDetailsList", fileDetails);
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("totalPages", totalPages);
				modelAndViewObj.setViewName("SpocApproval");
			 }
		}
		else{
			logger.info("no records for approval to display");
			modelAndViewObj.addObject("error", "No records to display !!");
			modelAndViewObj.setViewName("SpocApproval");
			return modelAndViewObj;
		}

		return modelAndViewObj;

	}

	@RequestMapping(value = "/paymentApproval1")
	public ModelAndView paymentApproval1(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		List<FileDetails> adviceApprovalList = new ArrayList<FileDetails>();
		ModelAndView modelAndViewObj = new ModelAndView();
		session=request.getSession(true);
		int page = Integer.parseInt(request.getParameter("pageNum"));
		logger.info("page num "+page);
		logger.info("Entered into payment Approval with page Number"+page);
		String fileId=request.getParameter("FileIDSearch");
		String activeDate = request.getParameter("startDate");
		String endDate=request.getParameter("endDate");
		String paymentMode=request.getParameter("paymentMode");
		String vendorUserId=request.getParameter("UserId");
		int totalPages=0;
		String errorMessage,errorCode;
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		int SNo;
		SNo=activityLogDao.insertActivityLog(0,userId,"Retrieving files for Spocapproval ",null,null);
		Map<Map<Integer,List<String>>, List<FileDetails>> fileDetailsList=bulkDao.retreiveDetailsForSpocbasedOnSearch(page,fileId,activeDate,endDate,userId,role,paymentMode,vendorUserId);

		if(fileDetailsList!=null){
			Set mapSet = (Set) fileDetailsList.entrySet();
			Iterator mapIterator = mapSet.iterator();
			while (mapIterator.hasNext()) {
				Map.Entry<Map<Integer,List<String>>, List<FileDetails>> mapEntry = (Map.Entry<Map<Integer,List<String>>, List<FileDetails>>) mapIterator.next();
				Map<Integer,List<String>> totalPagesAndErrorDetailsList;
				totalPagesAndErrorDetailsList=mapEntry.getKey();
				Set totalPagesAndErrorsSet = (Set) totalPagesAndErrorDetailsList.entrySet();
				Iterator totalPagesAndErrorsIterator = totalPagesAndErrorsSet.iterator();
				while (totalPagesAndErrorsIterator.hasNext()) {
					Map.Entry<Integer,List<String>> totalPagesAndErrorsEntry = (Map.Entry<Integer,List<String>>) totalPagesAndErrorsIterator.next();
					totalPages=totalPagesAndErrorsEntry.getKey();
					errorCode=totalPagesAndErrorsEntry.getValue().get(0);
					errorMessage=totalPagesAndErrorsEntry.getValue().get(1);
				}
				List<FileDetails> fileDetails;
				fileDetails=(List<FileDetails>) mapEntry.getValue();
				modelAndViewObj.addObject("fileDetailsList", fileDetails);
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("totalPages", totalPages);
				modelAndViewObj.setViewName("SpocApproval");
			 }
		}
		else{
			logger.info("no records for approval to display");
			modelAndViewObj.addObject("error", "No records to display !!");
			modelAndViewObj.setViewName("SpocApproval");
			return modelAndViewObj;
		}

		return modelAndViewObj;

	}*/
	@RequestMapping(value = "/reversal", method = RequestMethod.POST)
	public ModelAndView reversalProcessing(
			@RequestParam("xlsFile") MultipartFile file,
			HttpServletRequest request) throws Exception {
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		logger.info("Entered into reversal ");
		String fileName=file.getOriginalFilename();


		ModelAndView modelAndViewObj = new ModelAndView();
		boolean status=false;
		List<String> circleList=new ArrayList<String>();

		String filename = file.getOriginalFilename();
		//Commented By APS Team
		/*  circleList=bulkDao.getUserCircles(); 
			String circleString=filename.substring(0,2);
			for(String circle:circleList)
			{
				if(circle.equalsIgnoreCase(circleString))
				{
				 status=true;
				}
			}*/
		//Added by APS Team
		String circleString=filename.substring(0,3);
		boolean circleStatus = bulkDao.checkCircle(circleString);
		if(circleStatus){
			status=true;
		}
		if(filename.length()>=22)
		{
			System.out.println("INSIDE ONE");
			//Commented by APS Team
			/* String subString2= filename.substring(9, 11);
			  String subString3= filename.substring(11, 13);*/
			String subString2= filename.substring(10, 12);
			String subString3= filename.substring(12, 14);
			boolean status1=true;
			boolean status2=true;
			try
			{
				if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
					status1=false;
				if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
					status2=false;
			}
			catch(Exception e)
			{
				/*	modelAndViewObj.addObject("error",
				"File Name format - XX_REV_YYMMDD_ABC_NNNN.xls,Please Correct the Name and upload again");*/
				modelAndViewObj.addObject("error",
						"File Name format - XXX_REV_YYMMDD_ABC_NNNN.xls,Please Correct the Name and upload again");

				modelAndViewObj.setViewName("reversal");
				return modelAndViewObj;
			}
			//	if(filename.matches("^[0-9A-Za-z]{2}[_][R][E][V][_][0-9]{2}[0-1][0-9][0-3][0-9][_][A-Za-z0-9]{3}[_][0-9]{4}[.][x][l][s][x]?")&&status1&&status2&&status)
			if(filename.matches("^[0-9]{3}[_][R][E][V][_][0-9]{2}[0-1][0-9][0-3][0-9][_][A-Za-z0-9]{3}[_][0-9]{4}[.][x][l][s][x]?")&&status1&&status2&&status)
				System.out.println("valid file name");
			else
			{

				/*modelAndViewObj.addObject("error",
						"File Name format - XX_REV_YYMMDD_ABC_NNNN.xls,Please Correct the Name and upload again");*/
				modelAndViewObj.addObject("error",
						"File Name format - XXX_REV_YYMMDD_ABC_NNNN.xls,Please Correct the Name and upload again");		
				modelAndViewObj.setViewName("reversal");
				return modelAndViewObj;
			}
		}
		else
		{

			modelAndViewObj.addObject("error",
					//	"File Name format - XX_REV_YYMMDD_ABC_NNNN.xls,Please Correct the Name and upload again");
					"File Name format - XXX_REV_YYMMDD_ABC_NNNN.xls,Please Correct the Name and upload again");
			modelAndViewObj.setViewName("reversal");
			return modelAndViewObj;
		}
		String isFileValid = BulkUtil.validateUploadedFile(file);
		FileUploadResult fileUpload =null;
		InputStream inputStream = null;
		try {
			byte[] bytes = file.getBytes();
			inputStream = new ByteArrayInputStream(bytes);
		}catch (IOException e) {
			logger.error(e);
		}
		if (isFileValid.equalsIgnoreCase("xls"))

		{
			//	SNo=activityLogDao.insertActivityLog(SNo,userId,"File validating","success","valid xls file");
			String type = request.getParameter("submit");

			if (type.equalsIgnoreCase("upload File")) {
				logger.info("valid xls file");


				logger.info("valid xls file");


				fileUpload = excelReader.readFromExcelfile(fileName,"DIR", "UI", userId, "",inputStream,"Payments",null,null);
				logger.info("valid xls file ->"+fileUpload.getStatus());
				logger.info("valid xls file fileUpload.getStatusDescription() ->"+fileUpload.getStatusDescription());
				//modelAndViewObj=bulkutil.validatexls(file, request,downloadpath,errorFilesPath,isFileValid)	;
				//		System.out.println("modelobj"+modelAndViewObj.g);
				if(fileUpload.getStatus() == 1){
					logger.info("Inside Payment file transfer to done Folder->>"+downloadpath);
					logger.info("Inside Payment file transfer to done fileName->>"+fileName);

					fileUpload(file,downloadpath,fileName);

				}else{
					
					fileUpload(file,errorFilesPath,fileName);
				}
				if(fileUpload.getStatusDescription().contains("Records Successfully Inserted")){
					FileDetails fileDetailsObj=new FileDetails();

					fileDetailsObj.setFileID(fileUpload.getFileId());
					fileDetailsObj.setOriginalFileName(fileName);
					fileDetailsObj.setStatus("");
					fileDetailsObj.setFlag("");


					modelAndViewObj.addObject("flag",
							fileDetailsObj.getFlag());
					modelAndViewObj.addObject("status",
							fileDetailsObj.getStatus());
					modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj);
					modelAndViewObj.addObject("extension", ".xls");
					modelAndViewObj.setViewName("reversalSuccess");

					/* modelAndViewObj.addObject("status",
								fileDetailsObj.getStatus());
						 modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj);
						 modelAndViewObj.addObject("extension", ".xls");
							modelAndViewObj.setViewName("bulkUploadSuccess");
					 modelAndViewObj.setViewName("bulkUploadSuccess");*/
				}
				else{
					modelAndViewObj.addObject("error",fileUpload.getStatusDescription());

					modelAndViewObj.setViewName("reversal");
				}

				return modelAndViewObj;

				//modelAndViewObj=bulkutil.validatexlsReversal(file, request,downloadpath,errorFilesPath,isFileValid)	;
				//modelAndViewObj.addObject("uploadTypeList",uploadType);
				//		System.out.println("model object values:"+modelAndViewObj.);
				//return modelAndViewObj;

			}

		}
		else if(isFileValid.equalsIgnoreCase("xlsx"))
		{
			String type = request.getParameter("submit");
			//	SNo=activityLogDao.insertActivityLog(SNo,userId,"File Uploading","success","valid xlsx file");
			if (type.equalsIgnoreCase("upload File")) {
				logger.info("valid xlsx file");

				// modelAndViewObj.setViewName("final");
				//BulkUtil bulkUtil=new BulkUtil();

				logger.info("valid xls file");


				fileUpload = excelReader.readFromExcelfile(fileName,"DIR", "UI", userId, "",inputStream,"Payments",null,null);
				logger.info("valid xls file ->"+fileUpload.getStatus());
				logger.info("valid xls file fileUpload.getStatusDescription() ->"+fileUpload.getStatusDescription());
				//modelAndViewObj=bulkutil.validatexls(file, request,downloadpath,errorFilesPath,isFileValid)	;
				//		System.out.println("modelobj"+modelAndViewObj.g);
				if(fileUpload.getStatus() == 1){
					logger.info("Inside Payment file transfer to done Folder->>"+downloadpath);
					logger.info("Inside Payment file transfer to done fileName->>"+fileName);

					fileUpload(file,downloadpath,fileName);

				}else{
					
					fileUpload(file,errorFilesPath,fileName);
				}
				if(fileUpload.getStatusDescription().contains("Records Successfully Inserted")){
					FileDetails fileDetailsObj=new FileDetails();

					fileDetailsObj.setFileID(fileUpload.getFileId());
					fileDetailsObj.setOriginalFileName(fileName);
					fileDetailsObj.setStatus("");
					fileDetailsObj.setFlag("");



					modelAndViewObj.addObject("flag",
							fileDetailsObj.getFlag());
					modelAndViewObj.addObject("status",
							fileDetailsObj.getStatus());
					modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj);
					modelAndViewObj.addObject("extension", ".xlsx");
					modelAndViewObj.setViewName("reversalSuccess");
				}
				else{
					modelAndViewObj.addObject("error",fileUpload.getStatusDescription());

					modelAndViewObj.setViewName("reversal");
				}

				return modelAndViewObj;

				//modelAndViewObj=bulkutil.validatexlsxReversal(file, request,downloadpath,errorFilesPath,isFileValid);
				//modelAndViewObj.addObject("uploadTypeList",uploadType);

				//return modelAndViewObj;

			}
		}

		else {
			Long SNo=0l;
			try{
				SNo=activityLogDao.insertActivityLog(0l,userId,"file upload",null,null,fileName,null,null);

			}
			catch(SQLException sqlexception)
			{
				StringWriter errors= new StringWriter();
				sqlexception.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("error","DB Connectivity issues");
				modelAndViewObj.setViewName("reversal");
				return modelAndViewObj;
			}
			try{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","wrong file format",fileName,null,null);
			}
			catch(SQLException sqlexception)
			{
				StringWriter errors= new StringWriter();
				sqlexception.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("error","DB Connectivity issues");
				modelAndViewObj.setViewName("reversal");
				return modelAndViewObj;
			}
			//	SNo=activityLogDao.insertActivityLog(SNo,userId,"File Uploading",null,"wrong file format");
			//System.out.println("sno in activity log"+SNo);
			logger.info("File is not valid!!");

			modelAndViewObj.addObject("error",
					"Uploaded file is not  excel!!");
			modelAndViewObj.setViewName("reversal");
			return modelAndViewObj;

		}
		//SNo=activityLogDao.insertActivityLog(0,userId,"File Uploading Checking whether the file is null or not",null, null);

		return modelAndViewObj;

	}
	@RequestMapping(value = "/chequeBounce", method = RequestMethod.POST)
	public ModelAndView chequeBounceProcessing(
			@RequestParam("xlsFile") MultipartFile file,
			HttpServletRequest request) throws Exception {
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		String fileName=file.getOriginalFilename();
		logger.info("Entered into Cheque Bounce");
		ModelAndView modelAndViewObj = new ModelAndView();
		//modelAndViewObj.addObject("uploadTypeList",uploadType);
		boolean status=false;
		//int SNo=activityLogDao.insertActivityLog(0,userId,"File validating",null,null);
		List<String> circleList=new ArrayList<String>();
		//Commented By APS Team
		/*	circleList=bulkDao.getUserCircles();
			String filename = file.getOriginalFilename();
			String circleString=filename.substring(0,2);
			for(String circle:circleList)
			{
				if(circle.equalsIgnoreCase(circleString))
				{
					 status=true;
				}
			}*/
		String filename = file.getOriginalFilename();
		String circleString=filename.substring(0,3);
		boolean circleStatus = bulkDao.checkCircle(circleString);
		if(circleStatus){
			status=true;
		}
		if(filename.length()>=22)
		{
			//Commented By APS Team
			/*String subString2= filename.substring(9, 11);
			  String subString3= filename.substring(11, 13);*/

			String subString2= filename.substring(10, 12);
			String subString3= filename.substring(12, 14);
			boolean status1=true;
			boolean status2=true;
			try
			{
				if(Integer.parseInt(subString2)>12||Integer.parseInt(subString2)<1)
					status1=false;
				if(Integer.parseInt(subString3)>31||Integer.parseInt(subString3)<1)
					status2=false;
			}
			catch(Exception e)
			{
				modelAndViewObj.addObject("error",
						//	"File Name format - XX_REV_YYMMDD_ABC_NNNN.xls,Please Check the  fileName and upload again");
						"File Name format - XXX_REV_YYMMDD_ABC_NNNN.xls,Please Check the  fileName and upload again");
				modelAndViewObj.setViewName("reversal");
				return modelAndViewObj;
			}
			//	if(filename.matches("^[0-9A-Za-z]{2}[_][R][E][V][_][0-9]{2}[0-1][0-9][0-3][0-9][_][A-Za-z0-9]{3}[_][0-9]{4}[.][x][l][s][x]?")&&status1&&status2&&status)
			if(filename.matches("^[0-9]{3}[_][R][E][V][_][0-9]{2}[0-1][0-9][0-3][0-9][_][A-Za-z0-9]{3}[_][0-9]{4}[.][x][l][s][x]?")&&status1&&status2&&status) 
				System.out.println("valid file name");
			else
			{
				modelAndViewObj.addObject("error",
						//	"File Name format - XX_REV_YYMMDD_ABC_NNNN.xls,Please Check the fileName and upload again");
						"File Name format - XXX_REV_YYMMDD_ABC_NNNN.xls,Please Check the fileName and upload again");
				modelAndViewObj.setViewName("reversal");
				return modelAndViewObj;
			}
		}
		else
		{
			modelAndViewObj.addObject("error",
					//"File Name format - XX_REV_YYMMDD_ABC_NNNN.xls,Please Correct the Name and upload again");
					"File Name format - XXX_REV_YYMMDD_ABC_NNNN.xls,Please Correct the Name and upload again");
			modelAndViewObj.setViewName("reversal");
			return modelAndViewObj;
		}

		String isFileValid = BulkUtil.validateUploadedFile(file);
		FileUploadResult fileUpload =null;
		InputStream inputStream = null;
		try {
			byte[] bytes = file.getBytes();
			inputStream = new ByteArrayInputStream(bytes);
		}catch (IOException e) {
			logger.error(e);
		}
		if (isFileValid.equalsIgnoreCase("xls"))

		{
			//	SNo=activityLogDao.insertActivityLog(SNo,userId,"File validating","success","valid xls file");
			String type = request.getParameter("submit");

			if (type.equalsIgnoreCase("upload File")) {
				logger.info("valid xls file");


				logger.info("valid xls file");


				fileUpload = excelReader.readFromExcelfile(fileName,"REVCHQ", "UI", userId, "",inputStream,"Payments",null,null);
				logger.info("valid xls file ->"+fileUpload.getStatus());
				logger.info("valid xls file fileUpload.getStatusDescription() ->"+fileUpload.getStatusDescription());
				//modelAndViewObj=bulkutil.validatexls(file, request,downloadpath,errorFilesPath,isFileValid)	;
				//		System.out.println("modelobj"+modelAndViewObj.g);
				if(fileUpload.getStatus() == 1){
					logger.info("Inside Payment file transfer to done Folder->>"+downloadpath);
					logger.info("Inside Payment file transfer to done fileName->>"+fileName);

					fileUpload(file,downloadpath,fileName);

				}else{
					
					fileUpload(file,errorFilesPath,fileName);
				}
				if(fileUpload.getStatusDescription().contains("Records Successfully Inserted")){
					FileDetails fileDetailsObj=new FileDetails();

					fileDetailsObj.setFileID(fileUpload.getFileId());
					fileDetailsObj.setOriginalFileName(fileName);
					fileDetailsObj.setStatus("");
					fileDetailsObj.setFlag("");


					modelAndViewObj.addObject("flag",
							fileDetailsObj.getFlag());
					modelAndViewObj.addObject("status",
							fileDetailsObj.getStatus());
					modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj);
					modelAndViewObj.addObject("extension", ".xls");
					modelAndViewObj.setViewName("reversalSuccess");

					/* modelAndViewObj.addObject("status",
								fileDetailsObj.getStatus());
						 modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj);
						 modelAndViewObj.addObject("extension", ".xls");
							modelAndViewObj.setViewName("bulkUploadSuccess");
					 modelAndViewObj.setViewName("bulkUploadSuccess");*/
				}
				else{
					modelAndViewObj.addObject("error",fileUpload.getStatusDescription());

					modelAndViewObj.setViewName("reversal");
				}


				return modelAndViewObj;

				//modelAndViewObj=bulkutil.validatexlsChequeBounce(file, request,downloadpath,errorFilesPath,isFileValid)	;
				//modelAndViewObj.addObject("uploadTypeList",uploadType);
				//		System.out.println("model object values:"+modelAndViewObj.);
				//return modelAndViewObj;

			}

		}
		else if(isFileValid.equalsIgnoreCase("xlsx"))
		{
			String type = request.getParameter("submit");
			//	SNo=activityLogDao.insertActivityLog(SNo,userId,"File Uploading","success","valid xlsx file");
			if (type.equalsIgnoreCase("upload File")) {
				logger.info("valid xlsx file");

				logger.info("valid xls file");


				fileUpload = excelReader.readFromExcelfile(fileName,"REVCHQ", "UI", userId, "",inputStream,"Payments",null,null);
				logger.info("valid xls file ->"+fileUpload.getStatus());
				logger.info("valid xls file fileUpload.getStatusDescription() ->"+fileUpload.getStatusDescription());
				//modelAndViewObj=bulkutil.validatexls(file, request,downloadpath,errorFilesPath,isFileValid)	;
				//		System.out.println("modelobj"+modelAndViewObj.g);
				if(fileUpload.getStatus() == 1){
					logger.info("Inside Payment file transfer to done Folder->>"+downloadpath);
					logger.info("Inside Payment file transfer to done fileName->>"+fileName);

					fileUpload(file,downloadpath,fileName);

				}else{
					
					fileUpload(file,errorFilesPath,fileName);
				}
				if(fileUpload.getStatusDescription().contains("Records Successfully Inserted")){
					FileDetails fileDetailsObj=new FileDetails();

					fileDetailsObj.setFileID(fileUpload.getFileId());
					fileDetailsObj.setOriginalFileName(fileName);
					fileDetailsObj.setStatus("");
					fileDetailsObj.setFlag("");


					modelAndViewObj.addObject("flag",
							fileDetailsObj.getFlag());
					modelAndViewObj.addObject("status",
							fileDetailsObj.getStatus());
					modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj);
					modelAndViewObj.addObject("extension", ".xlsx");
					modelAndViewObj.setViewName("reversalSuccess");

					/* modelAndViewObj.addObject("status",
								fileDetailsObj.getStatus());
						 modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj);
						 modelAndViewObj.addObject("extension", ".xls");
							modelAndViewObj.setViewName("bulkUploadSuccess");
					 modelAndViewObj.setViewName("bulkUploadSuccess");*/
				}
				else{
					modelAndViewObj.addObject("error",fileUpload.getStatusDescription());

					modelAndViewObj.setViewName("reversal");
				}


				return modelAndViewObj;
				// modelAndViewObj.setViewName("final");
				//BulkUtil bulkUtil=new BulkUtil();
				//modelAndViewObj=bulkutil.validatexlsxChequeBounce(file, request,downloadpath,errorFilesPath,isFileValid);
				//modelAndViewObj.addObject("uploadTypeList",uploadType);

				//return modelAndViewObj;

			}
		}

		else {
			//	SNo=activityLogDao.insertActivityLog(SNo,userId,"File Uploading",null,"wrong file format");
			//System.out.println("sno in activity log"+SNo);
			logger.info("File is not valid!!");
			Long SNo=0l;
			try{
				SNo=activityLogDao.insertActivityLog(0l,userId,"file upload",null,null,fileName,null,null);
			}
			catch(SQLException sqlexception)
			{
				StringWriter errors= new StringWriter();
				sqlexception.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("error","DB Connectivity issues");
				modelAndViewObj.setViewName("reversal");
				return modelAndViewObj;
			}
			try{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","wrong file format",fileName,null,null);
			}
			catch(SQLException sqlexception)
			{
				StringWriter errors= new StringWriter();
				sqlexception.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("error","DB Connectivity issues");
				modelAndViewObj.setViewName("reversal");
				return modelAndViewObj;
			}
			modelAndViewObj.addObject("error",
					"Uploaded file is not  excel!!");
			modelAndViewObj.setViewName("reversal");
			return modelAndViewObj;

		}
		//SNo=activityLogDao.insertActivityLog(0,userId,"File Uploading Checking whether the file is null or not",null, null);

		return modelAndViewObj;

	}
	@RequestMapping(value = "/transfer", method = RequestMethod.POST)
	public ModelAndView transferProcessing(
			@RequestParam("xlsFile") MultipartFile file,
			@RequestParam("paymentTransferSupportFile") MultipartFile paymentTransferSupportFile,
			HttpServletRequest request) throws Exception {

		File fileObj=new File(paymentAdviceHomePath+"/Conf/PaymentAdvice.properties");

		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		String fileName=file.getOriginalFilename();
		String supportFileName =null;
		//Added for Support File
		if(paymentTransferSupportFile!=null && !paymentTransferSupportFile.isEmpty()){
			supportFileName = paymentTransferSupportFile.getOriginalFilename();
		}

		FileUploadResult fileUpload =null;

		ModelAndView modelAndViewObj = new ModelAndView();
		//modelAndViewObj.addObject("uploadTypeList",uploadType);

		//int SNo=activityLogDao.insertActivityLog(0,userId,"File validating",null,null);

		String isFileValid = BulkUtil.validateUploadedFile(file);
		InputStream inputStream = null;
		InputStream supportInputStream = null;
		try {
			byte[] bytes = file.getBytes();
			inputStream = new ByteArrayInputStream(bytes);
		}catch (IOException e) {
			logger.error(e);
		}

		//Check Support File Size
		File paymentTransferSupportObj=new File(paymentAdviceHomePath+"/Conf/PaymentAdvice.properties");
		String maxSizeAlldForSupFile=null;
		float maxSizeAllowed,paymentTransferSupportFileInBytes, paymentTransferSupportFileInKBytes, paymentTransferSupportFileInMB;		
		FileDetails fileDetailsObj=new FileDetails();

		try {					
			supportInputStream = new FileInputStream(paymentTransferSupportObj);
			Properties properties=new Properties();
			properties.load(supportInputStream);		
			maxSizeAlldForSupFile=properties.getProperty("maxiumSizeAllowedForPaymentAdviceSupportFile");
		}
		catch(Exception e){
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}


		if(paymentTransferSupportFile !=null){
			paymentTransferSupportFileInBytes = paymentTransferSupportFile.getSize();
			paymentTransferSupportFileInKBytes = paymentTransferSupportFileInBytes / 1024;
			paymentTransferSupportFileInMB = paymentTransferSupportFileInKBytes / 1024;

			logger.info(" Payment Transfer Support File Original Name : "+paymentTransferSupportFile.getOriginalFilename()
			+" Payment Transfer Support File Size (in Bytes) : "+ paymentTransferSupportFileInBytes
			+ "  Payment Transfer Support File Size (in Kilo Bytes) : "+paymentTransferSupportFileInKBytes
			+"   Payment Transfer Support File Size (in Mega Bytes) : "+paymentTransferSupportFileInMB);

			maxSizeAllowed=Float.parseFloat(maxSizeAlldForSupFile);
			if(maxSizeAllowed<paymentTransferSupportFileInMB){
				logger.info(" Payment Transfer support file size "+paymentTransferSupportFileInMB+"is greater than allowed size "+maxSizeAllowed);
				fileDetailsObj.setErrorCode("FAILURE");
				fileDetailsObj.setErrorMsg(" Payment Transfer support file size "+paymentTransferSupportFileInMB+"is greater than allowed size "+maxSizeAllowed);

				modelAndViewObj.addObject("error",fileDetailsObj.getErrorMsg());
				modelAndViewObj.setViewName("bulkTransfer");
				return modelAndViewObj;
			}
		}

		if (isFileValid.equalsIgnoreCase("xls"))

		{
			//	SNo=activityLogDao.insertActivityLog(SNo,userId,"File validating","success","valid xls file");

			String type = request.getParameter("submit");

			if (type.equalsIgnoreCase("upload File")) 
			{
				logger.info("valid xls file");

				//modelAndViewObj=bulkutil.validatexlsTransfer(file, request,downloadpath,errorFilesPath,isFileValid)	;
				fileUpload = excelReader.readFromExcelfile(fileName,"PTF", "UI", userId, "",inputStream,"PAYMENT TRANSFER",null,null);


				///update query here
				bulkDao.updatePTFDetails(paymentTransferSupportFile.getOriginalFilename(), fileUpload.getFileId());

				//modelAndViewObj.addObject("uploadTypeList",uploadType);
				//		System.out.println("model object values:"+modelAndViewObj.);				

				if(fileUpload.getStatus() == 1){
					logger.info("excel file path->>"+transferFile);
					logger.info("support file path->>"+transferSupportFile);
					logger.info("Inside Payment file transfer to done fileName->>"+fileName);	
					logger.info("paymentTransferSupportFile.getOriginalFilename() fileName->>"+paymentTransferSupportFile.getOriginalFilename());	

					String renamedFileName=null;
					
					fileUpload(file,transferFile,fileName.replace(".xls",
							"_" +fileUpload.getFileId() + ".xls"));
					//transfering support file
					if(paymentTransferSupportFile.getOriginalFilename()!=null && paymentTransferSupportFile.getOriginalFilename()!=""){
						int lastIndexSupport=paymentTransferSupportFile.getOriginalFilename().lastIndexOf(".");
						renamedFileName=paymentTransferSupportFile.getOriginalFilename().replace(paymentTransferSupportFile.getOriginalFilename().substring(0, lastIndexSupport),"Payment_Transfer_Support_File_"+fileUpload.getFileId());

						logger.info("renamedFileName->>"+renamedFileName);	
						fileUpload(paymentTransferSupportFile,transferSupportFile,renamedFileName);
					}

				}else{

					logger.info("errorFilesPath file path->>"+errorFilesPath);
					logger.info("support file fileName->>"+paymentTransferSupportFile.getOriginalFilename()+" fileName->"+fileName);

					fileUpload(file,errorFilesPath,fileName);
					fileUpload(paymentTransferSupportFile,errorFilesPath,paymentTransferSupportFile.getOriginalFilename());

				}
				logger.info("fileUpload.getStatusDescription()->>"+fileUpload.getStatusDescription());

				if(fileUpload.getStatusDescription().contains("Records Successfully Inserted")){

					logger.info("fileUpload.getStatusDescription()->>"+fileUpload.getStatusDescription());				


					fileDetailsObj.setFileID(fileUpload.getFileId());
					fileDetailsObj.setOriginalFileName(fileName);
					fileDetailsObj.setStatus("");
					fileDetailsObj.setFlag("");
                   //Role to be included
					fileDetailsObj.setRoleId(role);
					
					modelAndViewObj.addObject("flag",
							fileDetailsObj.getFlag());
					modelAndViewObj.addObject("status",
							fileDetailsObj.getStatus());
					modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj);
					modelAndViewObj.addObject("extension", ".xls");
					modelAndViewObj.addObject("role",fileDetailsObj.getRoleId());
					
					modelAndViewObj.setViewName("transferSuccess");
					//Added by Ritu
					try{
					fileDetailsObj.setUserId(userId);
					logger.info("User ID"+fileDetailsObj.getUserId());
					EMailContent emailContentObj=BulkUtil.sendEmailAlert(bulkDao, fileDetailsObj,"FILE_LEVEL_VALIDATIONS_SUCCESS_ALERT");
					 logger.info("payment transfer email body is" +emailContentObj.getEmailBody());
					logger.info(" Email Status "+emailContentObj.getErrorCode()+", "+emailContentObj.getErrorMessage());
					}catch(Exception e){
						e.printStackTrace();
					}
					//Addition ends here on 14th June

					/* modelAndViewObj.addObject("status",
								fileDetailsObj.getStatus());
						 modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj);
						 modelAndViewObj.addObject("extension", ".xls");
							modelAndViewObj.setViewName("bulkUploadSuccess");
					 modelAndViewObj.setViewName("bulkUploadSuccess");*/
				}
				else{
					modelAndViewObj.addObject("error",fileUpload.getStatusDescription());

					modelAndViewObj.setViewName("bulkTransfer");
					modelAndViewObj.addObject("role",role);
				}


				return modelAndViewObj;
			}
		}
		else if(isFileValid.equalsIgnoreCase("xlsx"))
		{
			String type = request.getParameter("submit");
			//	SNo=activityLogDao.insertActivityLog(SNo,userId,"File Uploading","success","valid xlsx file");
			if (type.equalsIgnoreCase("upload File")) {
				logger.info("valid xlsx file");

				// modelAndViewObj.setViewName("final");
				//BulkUtil bulkUtil=new BulkUtil();
				//modelAndViewObj=bulkutil.validatexlsxTransfer(file, request,downloadpath,errorFilesPath,isFileValid);
				fileUpload = excelReader.readFromExcelfile(fileName,"PTF", "UI", userId, "",inputStream,"PAYMENT TRANSFER",null,null);
				///update query here
				bulkDao.updatePTFDetails(paymentTransferSupportFile.getOriginalFilename(), fileUpload.getFileId());

				//modelAndViewObj.addObject("uploadTypeList",uploadType);

				if(fileUpload.getStatus() == 1){
					logger.info("excel file path->>"+transferFile);
					logger.info("support file path->>"+transferSupportFile);
					logger.info("Inside Payment file transfer to done fileName->>"+fileName);	
					logger.info("paymentTransferSupportFile.getOriginalFilename() fileName->>"+paymentTransferSupportFile.getOriginalFilename());	

					String renamedFileName=null;
					
					fileUpload(file,transferFile,fileName.replace(".xlsx",
							"_" +fileUpload.getFileId() + ".xlsx"));
					//transfering support file
					if(paymentTransferSupportFile.getOriginalFilename()!=null && paymentTransferSupportFile.getOriginalFilename()!=""){
						int lastIndexSupport=paymentTransferSupportFile.getOriginalFilename().lastIndexOf(".");
						renamedFileName=paymentTransferSupportFile.getOriginalFilename().replace(paymentTransferSupportFile.getOriginalFilename().substring(0, lastIndexSupport),"Payment_Transfer_Support_File_"+fileUpload.getFileId());

						logger.info("renamedFileName->>"+renamedFileName);	
						fileUpload(paymentTransferSupportFile,transferSupportFile,renamedFileName);
					}

				}else{

					logger.info("errorFilesPath file path->>"+errorFilesPath);
					logger.info("support file fileName->>"+paymentTransferSupportFile.getOriginalFilename()+" fileName->"+fileName);

					fileUpload(file,errorFilesPath,fileName);
					fileUpload(paymentTransferSupportFile,errorFilesPath,paymentTransferSupportFile.getOriginalFilename());

				}
				logger.info("fileUpload.getStatusDescription()->>"+fileUpload.getStatusDescription());

				if(fileUpload.getStatusDescription().contains("Records Successfully Inserted")){

					logger.info("fileUpload.getStatusDescription()->>"+fileUpload.getStatusDescription());

					//FileDetails fileDetailsObj=new FileDetails();

					fileDetailsObj.setFileID(fileUpload.getFileId());
					fileDetailsObj.setOriginalFileName(fileName);
					fileDetailsObj.setStatus("");
					fileDetailsObj.setFlag("");
					//Role to be included
					fileDetailsObj.setRoleId(role);


					modelAndViewObj.addObject("flag",
							fileDetailsObj.getFlag());
					modelAndViewObj.addObject("status",
							fileDetailsObj.getStatus());
					modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj);
					modelAndViewObj.addObject("extension", ".xlsx");
					modelAndViewObj.addObject("role",fileDetailsObj.getRoleId());
					modelAndViewObj.setViewName("transferSuccess");

					/* modelAndViewObj.addObject("status",
								fileDetailsObj.getStatus());
						 modelAndViewObj.addObject("FileDetailsObj",fileDetailsObj);
						 modelAndViewObj.addObject("extension", ".xls");
							modelAndViewObj.setViewName("bulkUploadSuccess");
					 modelAndViewObj.setViewName("bulkUploadSuccess");*/
				}
				else{
					modelAndViewObj.addObject("error",fileUpload.getStatusDescription());

					modelAndViewObj.setViewName("bulkTransfer");
				}


				return modelAndViewObj;

			}
		}

		else {
			//	SNo=activityLogDao.insertActivityLog(SNo,userId,"File Uploading",null,"wrong file format");
			//System.out.println("sno in activity log"+SNo);
			logger.info("File is not valid!!");
			Long SNo=0l;
			try{
				SNo=activityLogDao.insertActivityLog(0l,userId,"file upload",null,null,fileName,null,null);
			}
			catch(SQLException sqlexception)
			{
				StringWriter errors= new StringWriter();
				sqlexception.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("error","DB Connectivity issues");
				modelAndViewObj.setViewName("bulkTransfer");
				return modelAndViewObj;
			}
			try{
				SNo=activityLogDao.insertActivityLog(SNo,userId,"file upload","failure","wrong file format",fileName,null,null);
			}
			catch(SQLException sqlexception)
			{
				StringWriter errors= new StringWriter();
				sqlexception.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				modelAndViewObj.addObject("error","DB Connectivity issues");
				modelAndViewObj.setViewName("bulkTransfer");
				return modelAndViewObj;
			}
			modelAndViewObj.addObject("error",
					"Uploaded file is not  excel!!");
			modelAndViewObj.setViewName("bulkTransfer");
			return modelAndViewObj;

		}
		//SNo=activityLogDao.insertActivityLog(0,userId,"File Uploading Checking whether the file is null or not",null, null);

		return modelAndViewObj;

	}
	@RequestMapping(value = "/ApproveRequest", method = RequestMethod.POST)
	public ModelAndView approveRequest(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		//Commented as per HYdb
		//	Request_ResponseXMLDetails Request_ResponseXMLDetails=new Request_ResponseXMLDetails();
		String statusApprove = null;
		statusApprove = "approve";
		session=request.getSession(true);
		String sessionId=session.getId();
		String responseForPaymentCode=null;
		String invoice=null;
		String paymentMode=null;
		//Commented as per HYdb
		//List<com.acecad.airtel.eai.integration.model.Invoice> invoiceList=null;
		String fileId=null;
		logger.info("Entered into Approve Request");
		String rejectedReason = request.getParameter("reason");
		String status="Approved";
		String[] fileIDs = request.getParameterValues("select");

		List<String> fileIdsList = Arrays.asList(fileIDs);
		List<String> fileidList= new ArrayList<String>();
		List<BulkDetails> customerAccountsRecords=new ArrayList<BulkDetails>();
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		System.out.println("file id size"+fileIdsList.size());
		Long SNo=0l;
		try{
			SNo=activityLogDao.insertActivityLog(0l,userId,"Files requested to approve by the Spoc ",null,null,null,null,null);
		}
		catch(SQLException sqlexception)
		{
			StringWriter errors= new StringWriter();
			sqlexception.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
			modelAndViewObj.addObject("message","DB Connectivity issues");
			modelAndViewObj.setViewName("Error");
			return modelAndViewObj;
		}
		try
		{
			for(String fileID:fileIdsList)
			{

				String[] arrayOfUpdatedValues=fileID.split("\\$");
				fileId=arrayOfUpdatedValues[0];
				paymentMode=arrayOfUpdatedValues[1];
				fileidList.add(fileId);
				if(!(paymentMode.equalsIgnoreCase("NEFT")))
				{
					String statusApproveResult = bulkDao.approveRequest(fileId,userId);
					modelAndViewObj.addObject("List", fileidList);
					modelAndViewObj.addObject("listSize", fileidList.size());
					modelAndViewObj.addObject("responsetype", "approved");
					modelAndViewObj.setViewName("SpocApproved");


					FileDetails mailObj=bulkDao.getEmailUser(fileId);
					File fileObj=new File(homePath+"/Conf/EmailAlertsTemplates/ApproveReject.properties");
					InputStream inputStream = null;
					Properties properties=new Properties();
					try {
						inputStream = new FileInputStream(fileObj);
						properties.load(inputStream);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					EMailContent emailContentObj=new EMailContent();

					emailContentObj.setEmailSubject(properties.getProperty("emailSubject").replace("<File Name>", mailObj.getOriginalFileName())+" "+getDateTime());
					emailContentObj.setEmailHeader(properties.getProperty("emailHeader"));
					emailContentObj.setEmailBody(properties.getProperty("emailBody").replace("<filename>",mailObj.getOriginalFileName()).replace("<Approved>",status).replace("<Reason>", ""));
					emailContentObj.setEmailFooter(properties.getProperty("emailFooter"));

					List<String> emailToList=new ArrayList<String>();
					emailToList.add(mailObj.getEmailId());

					emailContentObj.setEmailToList(emailToList);



					SmtpUtility.setLogger(logger);

					SmtpMailContent smtpMailContentObj=SmtpUtility.generateEmailAlert(emailContentObj);

				}
				else
				{
					String statusApproveResult = bulkDao.approveRequestNeft(fileId,userId);
					SNo=activityLogDao.insertActivityLog(SNo,userId,"Files requested to approve by the Spoc ","success","Files Aproved Successfully",null,null,null);
					logger.info("files approved succesfully");
					modelAndViewObj.addObject("List", fileidList);
					modelAndViewObj.addObject("listSize", fileidList.size());
					modelAndViewObj.addObject("responsetype", "approved");
					modelAndViewObj.setViewName("SpocApproved");

					FileDetails mailObj=bulkDao.getEmailUser(fileId);
					File fileObj=new File(homePath+"/Conf/EmailAlertsTemplates/ApproveReject.properties");
					InputStream inputStream = null;
					Properties properties=new Properties();
					try {
						inputStream = new FileInputStream(fileObj);
						properties.load(inputStream);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						StringWriter errors= new StringWriter();
						e1.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
					}	
					EMailContent emailContentObj=new EMailContent();

					emailContentObj.setEmailSubject(properties.getProperty("emailSubject").replace("<File Name>", mailObj.getOriginalFileName())+" "+getDateTime());
					emailContentObj.setEmailHeader(properties.getProperty("emailHeader"));
					emailContentObj.setEmailBody(properties.getProperty("emailBody").replace("<filename>",mailObj.getOriginalFileName()).replace("<Approved>",status).replace("<Reason>", ""));
					emailContentObj.setEmailFooter(properties.getProperty("emailFooter"));

					List<String> emailToList=new ArrayList<String>();
					emailToList.add(mailObj.getEmailId());

					emailContentObj.setEmailToList(emailToList);




					SmtpUtility.setLogger(logger);

					SmtpMailContent smtpMailContentObj=SmtpUtility.generateEmailAlert(emailContentObj);
				}
			}


		}

		catch(Exception e)
		{
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
			modelAndViewObj.addObject("error", "Error in connecting to Api");
			/*ADDED BY APS TEAM*/
			//	modelAndViewObj.setViewName("spocApprovalSearch");
			modelAndViewObj.setViewName("SpocApprovalSearch");
			/*END BY APS TEAM*/
			return modelAndViewObj;
		}
		try{
			SNo=activityLogDao.insertActivityLog(SNo,userId,"Files requested to Approve by the Spoc ","success","Files Approved Successfully",null,null,null);
		}
		catch(SQLException sqlexception)
		{
			StringWriter errors= new StringWriter();
			sqlexception.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
			modelAndViewObj.addObject("message","DB Connectivity issues");
			modelAndViewObj.setViewName("Error");
			return modelAndViewObj;
		}

		return modelAndViewObj;

	}

	@RequestMapping(value = "/RejectRequest", method = RequestMethod.POST)
	public ModelAndView rejectRequest(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		String statusApprove = null;
		statusApprove = "Rejected";
		session=request.getSession(true);
		String rejectedReason = request.getParameter("reason");
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		String[] fileIDs = request.getParameterValues("select");
		List<String> fileIdsList = Arrays.asList(fileIDs);
		List<String> fileIdList= new ArrayList<String>();
		String fileId=null;
		logger.info("Entered into reject request");
		Long SNo=0l;
		try{
			SNo=activityLogDao.insertActivityLog(0l,userId,"Files requested to Reject by the Spoc ",null,null,null,null,null);
		}
		catch(SQLException sqlexception)
		{
			StringWriter errors= new StringWriter();
			sqlexception.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
			modelAndViewObj.addObject("message","DB Connectivity issues");
			modelAndViewObj.setViewName("Error");
			return modelAndViewObj;
		}
		for(String fileID:fileIdsList)
		{

			String[] arrayOfUpdatedValues=fileID.split("\\$");

			fileId=arrayOfUpdatedValues[0];

			fileIdList.add(fileId);
		}
		String statusApproveResult = bulkDao.rejectRequest(fileIdList, rejectedReason,userId);

		if(!(statusApproveResult.equalsIgnoreCase("SUCCESS")))
		{
			logger.info("file has been not rejected because of data failure issues");
			modelAndViewObj.addObject("error", "data failure issues");
			/*ADDED BY APS TEAM*/
			modelAndViewObj.setViewName("SpocApprovalSearch");
			//modelAndViewObj.setViewName("spocApprovalSearch");
			/*END BY APS TEAM*/

			return modelAndViewObj;
		}
		try{
			SNo=activityLogDao.insertActivityLog(SNo,userId,"Files requested to Reject by the Spoc ","success","Files Rejected Successfully",null,null,null);
		}
		catch(SQLException sqlexception)
		{
			StringWriter errors= new StringWriter();
			sqlexception.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
			modelAndViewObj.addObject("message","DB Connectivity issues");
			modelAndViewObj.setViewName("Error");
			return modelAndViewObj;
		}
		logger.info("files rejected succesfully");
		for(String fileId1:fileIdList)
		{
			FileDetails mailObj=bulkDao.getEmailUser(fileId1);
			File fileObj=new File(homePath+File.separator+"Conf"+File.separator+"EmailAlertsTemplates"+File.separator+"ApproveReject.properties");
			InputStream inputStream = null;
			Properties properties=new Properties();
			try {
				inputStream = new FileInputStream(fileObj);
				properties.load(inputStream);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e1.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
			EMailContent emailContentObj=new EMailContent();

			emailContentObj.setEmailSubject(properties.getProperty("emailSubject").replace("<File Name>", mailObj.getOriginalFileName())+" "+getDateTime());
			emailContentObj.setEmailHeader(properties.getProperty("emailHeader"));
			emailContentObj.setEmailBody(properties.getProperty("emailBody").replace("<filename>", mailObj.getOriginalFileName()).replace("<Approved>",statusApprove).replace("<Reason>", "Please upload the file again against the reason given for rejection i.e "+rejectedReason));
			emailContentObj.setEmailFooter(properties.getProperty("emailFooter"));

			List<String> emailToList=new ArrayList<String>();
			emailToList.add(mailObj.getEmailId());

			emailContentObj.setEmailToList(emailToList);




			SmtpUtility.setLogger(logger);

			SmtpMailContent smtpMailContentObj=SmtpUtility.generateEmailAlert(emailContentObj);
		}	


		modelAndViewObj.addObject("List", fileIdList);
		modelAndViewObj.addObject("listSize", fileIdList.size());
		modelAndViewObj.addObject("responsetype", "has been rejected");
		modelAndViewObj.setViewName("SpocApproved");
		return modelAndViewObj;

	}

	@RequestMapping(value = "/paymentApproval")
	public ModelAndView searchBulkAproval(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		BulkDetails bulkObj=new BulkDetails();
		int SNo;
		session=request.getSession(true);
		String fileId=request.getParameter("FileIDSearch");
		logger.info("Entered into Payment Approval Search");
		String activeDate = request.getParameter("startDate");
		String endDate=request.getParameter("endDate");
		bulkObj.setFromDate(activeDate);
		bulkObj.setToDate(endDate);
		logger.info("Entered file id is"+fileId);
		logger.info("date is"+activeDate);
		String paymentMode=request.getParameter("paymentMode");
		bulkObj.setPaymentMode(paymentMode);
		//logger.info("payment mode is"+paymentMode);
		String vendorUserId=request.getParameter("UserId");
		bulkObj.setVendorTransactID(vendorUserId);
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		int page = 1,totalPages = 0;
		logger.info("userid is"+activeDate);
		logger.info("from date is"+activeDate);
		logger.info("payment mode is"+activeDate);
		logger.info("to date  is"+activeDate);
		String errorMessage,errorCode;

		Map<Map<Integer,List<String>>, List<FileDetails>> fileDetailsList=bulkDao.retreiveDetailsForSpocbasedOnSearch(page,fileId,activeDate,endDate,userId,role,paymentMode,vendorUserId);

		if(fileDetailsList!=null){

			Set mapSet = (Set) fileDetailsList.entrySet();
			Iterator mapIterator = mapSet.iterator();
			while (mapIterator.hasNext()) {
				Map.Entry<Map<Integer,List<String>>, List<FileDetails>> mapEntry = (Map.Entry<Map<Integer,List<String>>, List<FileDetails>>) mapIterator.next();
				Map<Integer,List<String>> totalPagesAndErrorDetailsList;
				totalPagesAndErrorDetailsList=mapEntry.getKey();
				Set totalPagesAndErrorsSet = (Set) totalPagesAndErrorDetailsList.entrySet();
				Iterator totalPagesAndErrorsIterator = totalPagesAndErrorsSet.iterator();
				while (totalPagesAndErrorsIterator.hasNext()) {
					Map.Entry<Integer,List<String>> totalPagesAndErrorsEntry = (Map.Entry<Integer,List<String>>) totalPagesAndErrorsIterator.next();
					totalPages=totalPagesAndErrorsEntry.getKey();
					errorCode=totalPagesAndErrorsEntry.getValue().get(0);
					errorMessage=totalPagesAndErrorsEntry.getValue().get(1);
				}
				List<FileDetails> fileDetails;
				fileDetails=(List<FileDetails>) mapEntry.getValue();
				modelAndViewObj.addObject("fileDetailsList", fileDetails);
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("totalPages", totalPages);
				modelAndViewObj.setViewName("SpocApprovalSearch");
				session.setAttribute("bulkObj", bulkObj);
			}
		}
		else{
			logger.info("no files to display based on search");

			modelAndViewObj.addObject("error", "No records to display !!");
			modelAndViewObj.setViewName("SpocApprovalSearch");
			return modelAndViewObj;
		}

		return modelAndViewObj;

	}
	@RequestMapping(value = "/stopNeftPayment")
	public ModelAndView StopNeftPayment(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		logger.info("Enter in to stopNeftPayment controller");
		ModelAndView modelAndViewObj = new ModelAndView();
		session=request.getSession(true);
		int page = 1,totalPages = 0;
		List<StopDeatils> fileDetailsList=new ArrayList<StopDeatils>();
		 fileDetailsList=bulkDao.allStopNeftFiles();
		if(fileDetailsList!=null){
			
			totalPages=fileDetailsList.size()/10;
				modelAndViewObj.addObject("response", fileDetailsList);
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("totalPages", totalPages+1);
				modelAndViewObj.setViewName("neftStopFiles");
				
			}
		
		
		else{
			logger.info("no files to display based on search");

			modelAndViewObj.addObject("error", "No records to display !!");
			modelAndViewObj.setViewName("neftStopFiles");
			return modelAndViewObj;
		}
		logger.info("End of  stopNeftPayment controller");
		return modelAndViewObj;
		
	}
	@RequestMapping(value = "/stopPayment")
	public ModelAndView StopNeftPayment1(
			HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		List<StopDeatils> fileDetailsList=new ArrayList<StopDeatils>();
		int page = 1,totalPages = 0;
		logger.info("Stoping fileid is"+request.getParameter("fileId"));
		String fileid=request.getParameter("fileId");
		String reponseMessage=null;
		reponseMessage=bulkDao.responseMsgforStopFiles(fileid);
		if(reponseMessage!=null)
		{
			fileDetailsList=bulkDao.allStopNeftFiles();
			modelAndViewObj.addObject("msg",reponseMessage );
			totalPages=fileDetailsList.size()/5;
			modelAndViewObj.addObject("response", fileDetailsList);
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.addObject("totalPages", totalPages+1);
			modelAndViewObj.setViewName("neftStopFiles");
			if(fileDetailsList==null)
			{
				modelAndViewObj.addObject("error", "No records to display !!");
			}
		}
		else
		{	fileDetailsList=bulkDao.allStopNeftFiles();
			modelAndViewObj.addObject("response", fileDetailsList);
			modelAndViewObj.setViewName("neftStopFiles");
			modelAndViewObj.addObject("msg","All Records Already Posted" );
			if(fileDetailsList==null)
			{
				modelAndViewObj.addObject("error", "No records to display !!");
			}
			
		}
		
		logger.info("response message is "+reponseMessage);
		return modelAndViewObj;

	}
	@RequestMapping(value = "/paymentApprovalp", method = RequestMethod.GET)
	public ModelAndView searchBulkAprovalp(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		session=request.getSession(true);
		BulkDetails bulkObj=(BulkDetails) session.getAttribute("bulkObj");
		int SNo;

		logger.info("Entered into Payment Approval Search");
		String fileId=request.getParameter("FileIDSearch");
		// String activeDate = request.getParameter("dateId");

		//String paymentMode=request.getParameter("paymentMode");
		int page=Integer.parseInt(request.getParameter("pageNum"));
		//	String vendorUserId=request.getParameter("UserId");
		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		int totalPages = 0;
		String errorMessage,errorCode;

		Map<Map<Integer,List<String>>, List<FileDetails>> fileDetailsList=bulkDao.retreiveDetailsForSpocbasedOnSearch(page,fileId,bulkObj.getFromDate(),bulkObj.getToDate(),userId,role,bulkObj.getPaymentMode(),bulkObj.getVendorTransactID());

		if(fileDetailsList!=null){

			Set mapSet = (Set) fileDetailsList.entrySet();
			Iterator mapIterator = mapSet.iterator();
			while (mapIterator.hasNext()) {
				Map.Entry<Map<Integer,List<String>>, List<FileDetails>> mapEntry = (Map.Entry<Map<Integer,List<String>>, List<FileDetails>>) mapIterator.next();
				Map<Integer,List<String>> totalPagesAndErrorDetailsList;
				totalPagesAndErrorDetailsList=mapEntry.getKey();
				Set totalPagesAndErrorsSet = (Set) totalPagesAndErrorDetailsList.entrySet();
				Iterator totalPagesAndErrorsIterator = totalPagesAndErrorsSet.iterator();
				while (totalPagesAndErrorsIterator.hasNext()) {
					Map.Entry<Integer,List<String>> totalPagesAndErrorsEntry = (Map.Entry<Integer,List<String>>) totalPagesAndErrorsIterator.next();
					totalPages=totalPagesAndErrorsEntry.getKey();
					errorCode=totalPagesAndErrorsEntry.getValue().get(0);
					errorMessage=totalPagesAndErrorsEntry.getValue().get(1);
				}
				List<FileDetails> fileDetails;
				fileDetails=(List<FileDetails>) mapEntry.getValue();
				modelAndViewObj.addObject("fileDetailsList", fileDetails);
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("totalPages", totalPages);
				modelAndViewObj.setViewName("SpocApprovalSearch");
			}
		}
		else{
			logger.info("no files to display based on search");

			modelAndViewObj.addObject("error", "No records to display !!");
			modelAndViewObj.setViewName("SpocApprovalSearch");
			return modelAndViewObj;
		}

		return modelAndViewObj;

	}
	@RequestMapping(value = "/fileDownload", method = RequestMethod.GET)
	public ModelAndView fileDownload(HttpServletRequest request,HttpServletResponse response) throws IOException {


		ModelAndView modelAndViewObj = new ModelAndView();
		String filepath=null;
		String Downloadfile=null;
		String type=request.getParameter("type");
		FileInputStream in=null;
		if(type!=null &&type.equalsIgnoreCase("error"))
		{
			Downloadfile =request.getParameter("FileName1");
			filepath =errorFilesPath+File.separator;
		}
		else if(type!=null && type.equalsIgnoreCase("templates"))
		{
			Downloadfile =request.getParameter("FileName1");
			filepath =templatesPath+File.separator;
		}  
		else
		{
			Downloadfile =request.getParameter("FileName1");
			filepath=downloadpath+File.separator;
		}

		String filename1=filepath+Downloadfile;

		logger.info("filename1 is..."+filename1);

		ServletOutputStream out = response.getOutputStream();
		try
		{
			in = new FileInputStream(filename1);
		}
		catch(Exception e)
		{

			modelAndViewObj.addObject("error", "File not found with particular name");
			modelAndViewObj.setViewName("spocApproval");
			return modelAndViewObj;
		}
		response.setContentType("APPLICATION/OCTET-STREAM");

		response.addHeader("content-disposition",
				"attachment; filename=" + Downloadfile);


		int octet;
		while((octet = in.read()) != -1)
			out.write(octet);

		in.close();
		out.flush();
		out.close();
		response.flushBuffer();

		return modelAndViewObj;

	}
	@RequestMapping(value = "/PTfileDownload", method = RequestMethod.POST)
	public ModelAndView PTfileDownload(HttpServletRequest request,HttpServletResponse response) throws IOException {


		session = request.getSession(true);
		ModelAndView modelAndViewObj=new ModelAndView();
		PaymentTransferTemplate paymentTransferTemplateObj = new PaymentTransferTemplate();
		String userId = session.getAttribute("userid").toString();
		paymentTransferTemplateObj.setUserId(userId);
		paymentTransferTemplateObj.setTemplatePath(paymentAdviceHomePath
				+ "/UploadTemplate/");
		String templateRequired=request.getParameter("templateName");
		if(templateRequired!=null&&templateRequired.equalsIgnoreCase("XLS")){
			paymentTransferTemplateObj.setTemplateName("Payment_transfer.xls");
			paymentTransferTemplateObj.setDownloadedFileName(paymentTransferTemplateObj
					.getTemplateName().replace(".xls",
							"_" + BulkUtil.getTimeAndDate() + ".xls"));

			ServletOutputStream out = null;
			FileInputStream in = null;
			try {
				out = response.getOutputStream();
				in = new FileInputStream(paymentTransferTemplateObj.getTemplatePath()
						+ paymentTransferTemplateObj.getTemplateName());

				response.setContentType("APPLICATION/OCTET-STREAM");

				response.addHeader("content-disposition", "attachment; filename="
						+ paymentTransferTemplateObj.getDownloadedFileName());
				int octet;
				while ((octet = in.read()) != -1)
					out.write(octet);
				in.close();
				out.flush();
				out.close();
				response.flushBuffer();
				paymentTransferTemplateObj.setErrorCode("SUCCESS");
				paymentTransferTemplateObj.setErrorMessage("Download template "+paymentTransferTemplateObj.getDownloadedFileName()+" has been downloaded successfully !!");
			} catch (FileNotFoundException e) {
				logger.info(e.getLocalizedMessage());
				paymentTransferTemplateObj.setErrorCode("FAILURE");
				paymentTransferTemplateObj.setErrorMessage(" Unable to download template file, because source file not found in the server ");
				modelAndViewObj.addObject("error", "Unable to download template file, because source file not found in the server ");
				// TODO Auto-generated catch block
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			} catch (IOException e) {
				logger.info(e.getLocalizedMessage());
				paymentTransferTemplateObj.setErrorCode("FAILURE");
				paymentTransferTemplateObj.setErrorMessage(" Unable to download template file, because IO Exception occured ");
				modelAndViewObj.addObject("error", "Unable to download template file, because IO Exception occured ");
				// TODO Auto-generated catch block
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
			paymentTransferTemplateObj.setErrorCode("SUCCESS");

		}
		else if(templateRequired!=null&&templateRequired.equalsIgnoreCase("XLSX")){
			paymentTransferTemplateObj.setTemplateName("Payment_transfer.xlsx");
			paymentTransferTemplateObj.setDownloadedFileName(paymentTransferTemplateObj
					.getTemplateName().replace(".xlsx",
							"_" + BulkUtil.getTimeAndDate()+ ".xlsx"));

			ServletOutputStream out = null;
			FileInputStream in = null;
			try {
				out = response.getOutputStream();
				in = new FileInputStream(paymentTransferTemplateObj.getTemplatePath()
						+ paymentTransferTemplateObj.getTemplateName());

				response.setContentType("APPLICATION/OCTET-STREAM");

				response.addHeader("content-disposition", "attachment; filename="
						+ paymentTransferTemplateObj.getDownloadedFileName());
				int octet;
				while ((octet = in.read()) != -1)
					out.write(octet);
				in.close();
				out.flush();
				out.close();
				response.flushBuffer();
				paymentTransferTemplateObj.setErrorCode("SUCCESS");
				paymentTransferTemplateObj.setErrorMessage("Download template "+paymentTransferTemplateObj.getDownloadedFileName()+" has been downloaded successfully !!");
			} catch (FileNotFoundException e) {
				logger.info(e.getLocalizedMessage());
				paymentTransferTemplateObj.setErrorCode("FAILURE");
				paymentTransferTemplateObj.setErrorMessage(" Unable to download template file, because source file not found in the server ");
				modelAndViewObj.addObject("error", "Unable to download template file, because source file not found in the server ");
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			} catch (IOException e) {
				logger.info(e.getLocalizedMessage());
				paymentTransferTemplateObj.setErrorCode("FAILURE");
				paymentTransferTemplateObj.setErrorMessage(" Unable to download template file, because IO Exception occured ");
				modelAndViewObj.addObject("error", "Unable to download template file, because IO Exception occured ");
				logger.info(e.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
			paymentTransferTemplateObj.setErrorCode("SUCCESS");

		}
		modelAndViewObj.setViewName("paymentAdviceHome");;
		logger.info(" Execution of downLoadPaymentAdviceUploadTemplate() method completed ");
		return modelAndViewObj;
	}

	@RequestMapping(value = "/templateDownload", method = RequestMethod.GET)
	public ModelAndView templateDownload(HttpServletRequest request,HttpServletResponse response) throws IOException {


		ModelAndView modelAndViewObj = new ModelAndView();
		String filepath=null;
		String Downloadfile=null;
		String type=request.getParameter("type");
		FileInputStream in=null;
		if(type!=null &&type.equalsIgnoreCase("error"))
		{
			Downloadfile =request.getParameter("FileName1");
			filepath =errorFilesPath+File.separator;
		}
		else if(type!=null && type.equalsIgnoreCase("templates"))
		{
			Downloadfile =request.getParameter("FileName1");
			filepath =templatesPath+File.separator;
		}  
		else
		{
			Downloadfile =request.getParameter("FileName1");
			filepath=downloadpath+File.separator;
		}

		String filename1=filepath+Downloadfile;

		logger.info("filename1 is..."+filename1);

		ServletOutputStream out = response.getOutputStream();
		try
		{
			in = new FileInputStream(filename1);
		}
		catch(Exception e)
		{

			modelAndViewObj.addObject("error", "File not found with particular name");
			modelAndViewObj.setViewName("bulk");
			return modelAndViewObj;
		}
		response.setContentType("APPLICATION/OCTET-STREAM");

		response.addHeader("content-disposition",
				"attachment; filename=" + Downloadfile);


		int octet;
		while((octet = in.read()) != -1)
			out.write(octet);

		in.close();
		out.flush();
		out.close();
		response.flushBuffer();
		modelAndViewObj.setViewName("bulk");
		return modelAndViewObj;

	}
@RequestMapping(value = "/nonBankable", method = RequestMethod.POST)
	public ModelAndView nonBankable(
			@RequestParam("xlsFile") MultipartFile file,
			HttpServletRequest request) throws IOException {

		ModelAndView modelAndViewObj=new ModelAndView();
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		
		//String extension="xls";
		String fileName=file.getOriginalFilename();

		Long SNo=0l;
		try {
			SNo = activityLogDao.insertActivityLog(0l,userId,"Non bankable file insert",null,null,fileName,null,null);
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		String isFileValid = BulkUtil.validateUploadedFile(file);
		FileUploadResult fileUpload =null;
		InputStream inputStream = null;
		try {
			byte[] bytes = file.getBytes();
			inputStream = new ByteArrayInputStream(bytes);
		}catch (IOException e) {
			logger.error(e);
		}
		logger.info("is file>>>>>>"+isFileValid);
		if(isFileValid.equalsIgnoreCase("xls") || isFileValid.equalsIgnoreCase("xlsx"))
		{

			try {


				fileUpload = excelReader.readFromExcelfile(fileName,"NONBANK", "UI", userId, "",inputStream,"Payments",null,null);
				logger.info(" nonBankableFileSuccess valid xls file ->"+fileUpload.getStatus());
				logger.info(" nonBankableFileSuccess valid xls file fileUpload.getStatusDescription() ->"+fileUpload.getStatusDescription());
				//modelAndViewObj=bulkutil.validatexls(file, request,downloadpath,errorFilesPath,isFileValid)	;
				//		System.out.println("modelobj"+modelAndViewObj.g);
				if(fileUpload.getStatus() == 1){
					logger.info(" nonBankableFileSuccess Inside Payment file transfer to done Folder->>"+downloadpath);
					logger.info(" nonBankableFileSuccess Inside Payment file transfer to done fileName->>"+fileName);

					fileUpload(file,downloadpath,fileName);

				}else{

					fileUpload(file,errorFilesPath,fileName);
				}
				if(fileUpload.getStatusDescription().contains("Records Successfully Inserted")){


					modelAndViewObj.addObject("fileId",fileUpload.getFileId());
					modelAndViewObj.addObject("filename",fileName);


					modelAndViewObj.setViewName("nonBankableFileSuccess");

					
				}
				else{

					modelAndViewObj.addObject("error", fileUpload.getStatusDescription());
					modelAndViewObj.setViewName("nonBankableUpload");

				}

				logger.info(" nonBankableUpload end");
				return modelAndViewObj;


			} // main if sumCountHeader==sum closed



			catch (Exception e) {
				modelAndViewObj.addObject("error", "invalid file with different format");
				modelAndViewObj.setViewName("nonBankableUpload");

				try {
					SNo=activityLogDao.insertActivityLog(SNo,userId,"Non bankable file insert","failure","file not uploaded because of data failure issuess",fileName,null,null);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					StringWriter errors= new StringWriter();
					e1.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
				}
				return modelAndViewObj;
			}

		}


		modelAndViewObj.setViewName("nonBankableFileSuccess");
		return modelAndViewObj;

	}			//return modelAndViewObj;


	@RequestMapping(value = "/nonBankableRetrieval", method = RequestMethod.GET)
	public ModelAndView nonBankableRetrieval(HttpServletRequest request,HttpServletResponse response) throws IOException {

		ModelAndView modelAndViewObj=new ModelAndView();
		FileDetails fileDetailsObj=new FileDetails();
		session=request.getSession(true);

		String pagenum="1";
		String errorMessage,errorCode;

		int totalPages=0;
		String fileId=request.getParameter("FileIDSearch");
		String chequeNum=request.getParameter("ChequeNum");
		String bankAccountNumber=request.getParameter("BankAccountNumber");
		String startchequeDate=request.getParameter("startDate");
		String endchequeDate=request.getParameter("endDate");
		fileDetailsObj.setFileID(fileId);
		fileDetailsObj.setChequeNum(chequeNum);
		fileDetailsObj.setBankAccountNumber(bankAccountNumber);
		fileDetailsObj.setActiveDate(startchequeDate);
		fileDetailsObj.setInactiveDate(endchequeDate);
		//System.out.println(chequeDate);

		Map<Map<Integer,List<String>>, List<BulkDetails>>	nonbankableList=bulkDao.getNonBankableList(pagenum,fileId,chequeNum,bankAccountNumber,startchequeDate,endchequeDate);
		if(nonbankableList!=null){
			Set mapSet = (Set) nonbankableList.entrySet();
			Iterator mapIterator = mapSet.iterator();
			while (mapIterator.hasNext()) {
				Map.Entry<Map<Integer,List<String>>, List<BulkDetails>> mapEntry = (Map.Entry<Map<Integer,List<String>>, List<BulkDetails>>) mapIterator.next();
				Map<Integer,List<String>> totalPagesAndErrorDetailsList;
				totalPagesAndErrorDetailsList=mapEntry.getKey();
				Set totalPagesAndErrorsSet = (Set) totalPagesAndErrorDetailsList.entrySet();
				Iterator totalPagesAndErrorsIterator = totalPagesAndErrorsSet.iterator();
				while (totalPagesAndErrorsIterator.hasNext()) {
					Map.Entry<Integer,List<String>> totalPagesAndErrorsEntry = (Map.Entry<Integer,List<String>>) totalPagesAndErrorsIterator.next();
					totalPages=totalPagesAndErrorsEntry.getKey();
					errorCode=totalPagesAndErrorsEntry.getValue().get(0);
					errorMessage=totalPagesAndErrorsEntry.getValue().get(1);
				}
				List<BulkDetails> fileDetails;
				fileDetails=(List<BulkDetails>) mapEntry.getValue();
				modelAndViewObj.addObject("fileDetailsList", fileDetails);
				modelAndViewObj.addObject("currentPage", pagenum);
				modelAndViewObj.addObject("totalPages", totalPages);
				modelAndViewObj.setViewName("nonBankableRetrieval");
				session.setAttribute("fileDetailsObj", fileDetailsObj);
			}
		}
		else{
			logger.info("no records for approval to display");
			modelAndViewObj.addObject("error", "No records to display !!");
			modelAndViewObj.setViewName("nonBankableRetrieval");
			return modelAndViewObj;
		}
		return modelAndViewObj;

	}
	@RequestMapping(value = "/nonBankableRetrieval1", method = RequestMethod.GET)
	public ModelAndView nonBankableRetrieval1(HttpServletRequest request,HttpServletResponse response) throws IOException {

		ModelAndView modelAndViewObj=new ModelAndView();
		session=request.getSession(true);
		FileDetails fileDetailsObj=(FileDetails)session.getAttribute("fileDetailsObj");
		String pagenum=request.getParameter("pageNum");
		//System.out.println(pagenum);
		String errorMessage,errorCode;
		int totalPages=0;


		Map<Map<Integer,List<String>>, List<BulkDetails>>	nonbankableList=bulkDao.getNonBankableList(pagenum,fileDetailsObj.getFileID(),fileDetailsObj.getChequeNum(),fileDetailsObj.getBankAccountNumber(),fileDetailsObj.getActiveDate(),fileDetailsObj.getInactiveDate());
		if(nonbankableList!=null){
			Set mapSet = (Set) nonbankableList.entrySet();
			Iterator mapIterator = mapSet.iterator();
			while (mapIterator.hasNext()) {
				Map.Entry<Map<Integer,List<String>>, List<BulkDetails>> mapEntry = (Map.Entry<Map<Integer,List<String>>, List<BulkDetails>>) mapIterator.next();
				Map<Integer,List<String>> totalPagesAndErrorDetailsList;
				totalPagesAndErrorDetailsList=mapEntry.getKey();
				Set totalPagesAndErrorsSet = (Set) totalPagesAndErrorDetailsList.entrySet();
				Iterator totalPagesAndErrorsIterator = totalPagesAndErrorsSet.iterator();
				while (totalPagesAndErrorsIterator.hasNext()) {
					Map.Entry<Integer,List<String>> totalPagesAndErrorsEntry = (Map.Entry<Integer,List<String>>) totalPagesAndErrorsIterator.next();
					totalPages=totalPagesAndErrorsEntry.getKey();
					errorCode=totalPagesAndErrorsEntry.getValue().get(0);
					errorMessage=totalPagesAndErrorsEntry.getValue().get(1);
				}
				List<BulkDetails> fileDetails;
				fileDetails=(List<BulkDetails>) mapEntry.getValue();
				modelAndViewObj.addObject("fileDetailsList", fileDetails);
				modelAndViewObj.addObject("currentPage", pagenum);
				modelAndViewObj.addObject("totalPages", totalPages);
				modelAndViewObj.setViewName("nonBankableRetrieval");
			}
		}
		else{
			logger.info("no records for approval to display");
			modelAndViewObj.addObject("error", "No records to display !!");
			modelAndViewObj.setViewName("nonBankableRetrieval");
			return modelAndViewObj;
		}
		return modelAndViewObj;

	}

	@RequestMapping(value = "/transferTracking")
	public ModelAndView transferTracking(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		int SNo;
		BulkDetails transferObj=new BulkDetails();
		session=request.getSession(true);
		String fileId=request.getParameter("FileIDSearch");
		transferObj.setFileID(fileId);
		logger.info("Entered into Payment Approval Search");
		String reversalType = request.getParameter("reversalType");
		transferObj.setTransferType(reversalType);
		logger.info("Entered file id is"+fileId);
		String status=request.getParameter("status");
		System.out.println(status);

		String fileName=request.getParameter("FileNameSearch");
		transferObj.setFileName(fileName);
		transferObj.setFxStatus(status);


		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		int page = 1,totalPages = 0;
		String errorMessage,errorCode;

		Map<Map<Integer,List<String>>, List<FileDetails>> fileDetailsList=bulkDao.transferTracking(page,fileId,reversalType,userId,role,status,fileName);

		if(fileDetailsList!=null){

			Set mapSet = (Set) fileDetailsList.entrySet();
			Iterator mapIterator = mapSet.iterator();
			while (mapIterator.hasNext()) {
				Map.Entry<Map<Integer,List<String>>, List<FileDetails>> mapEntry = (Map.Entry<Map<Integer,List<String>>, List<FileDetails>>) mapIterator.next();
				Map<Integer,List<String>> totalPagesAndErrorDetailsList;
				totalPagesAndErrorDetailsList=mapEntry.getKey();
				Set totalPagesAndErrorsSet = (Set) totalPagesAndErrorDetailsList.entrySet();
				Iterator totalPagesAndErrorsIterator = totalPagesAndErrorsSet.iterator();
				while (totalPagesAndErrorsIterator.hasNext()) {
					Map.Entry<Integer,List<String>> totalPagesAndErrorsEntry = (Map.Entry<Integer,List<String>>) totalPagesAndErrorsIterator.next();
					totalPages=totalPagesAndErrorsEntry.getKey();
					errorCode=totalPagesAndErrorsEntry.getValue().get(0);
					errorMessage=totalPagesAndErrorsEntry.getValue().get(1);
				}
				List<FileDetails> fileDetails;
				fileDetails=(List<FileDetails>) mapEntry.getValue();
				modelAndViewObj.addObject("fileDetailsList", fileDetails);
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("totalPages", totalPages);
				modelAndViewObj.setViewName("transferTracking");
				session.setAttribute("transferObj", transferObj);
			}
		}
		else{
			logger.info("no files to display based on search");

			modelAndViewObj.addObject("error", "No records to display !!");
			modelAndViewObj.setViewName("transferTracking");
			return modelAndViewObj;
		}

		return modelAndViewObj;

	}
	@RequestMapping(value = "/transferTrackingp", method = RequestMethod.GET)
	public ModelAndView transferTrackingp(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		int SNo;
		session=request.getSession(true);
		BulkDetails transferObj=(BulkDetails) session.getAttribute("transferObj");
		logger.info("Entered into reversal tracking ");

		int page=Integer.parseInt(request.getParameter("pageNum"));

		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		int totalPages = 0;
		String errorMessage,errorCode;

		Map<Map<Integer,List<String>>, List<FileDetails>> fileDetailsList=bulkDao.transferTracking(page,transferObj.getFileID(),transferObj.getTransferType(),userId,role,transferObj.getFxStatus(),transferObj.getFileName());

		if(fileDetailsList!=null){

			Set mapSet = (Set) fileDetailsList.entrySet();
			Iterator mapIterator = mapSet.iterator();
			while (mapIterator.hasNext()) {
				Map.Entry<Map<Integer,List<String>>, List<FileDetails>> mapEntry = (Map.Entry<Map<Integer,List<String>>, List<FileDetails>>) mapIterator.next();
				Map<Integer,List<String>> totalPagesAndErrorDetailsList;
				totalPagesAndErrorDetailsList=mapEntry.getKey();
				Set totalPagesAndErrorsSet = (Set) totalPagesAndErrorDetailsList.entrySet();
				Iterator totalPagesAndErrorsIterator = totalPagesAndErrorsSet.iterator();
				while (totalPagesAndErrorsIterator.hasNext()) {
					Map.Entry<Integer,List<String>> totalPagesAndErrorsEntry = (Map.Entry<Integer,List<String>>) totalPagesAndErrorsIterator.next();
					totalPages=totalPagesAndErrorsEntry.getKey();
					errorCode=totalPagesAndErrorsEntry.getValue().get(0);
					errorMessage=totalPagesAndErrorsEntry.getValue().get(1);
				}
				List<FileDetails> fileDetails;
				fileDetails=(List<FileDetails>) mapEntry.getValue();
				modelAndViewObj.addObject("fileDetailsList", fileDetails);
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("totalPages", totalPages);
				modelAndViewObj.setViewName("transferTracking");
			}
		}
		else{
			logger.info("no files to display based on search");

			modelAndViewObj.addObject("error", "No records to display !!");
			modelAndViewObj.setViewName("transferTracking");
			return modelAndViewObj;
		}

		return modelAndViewObj;

	}


	@RequestMapping(value = "/reversalTracking")
	public ModelAndView reversalTracking(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		int SNo;
		BulkDetails reversalObj=new BulkDetails();
		session=request.getSession(true);
		String fileId=request.getParameter("FileIDSearch");
		reversalObj.setFileID(fileId);
		logger.info("Entered into Payment Approval Search");
		String reversalType = request.getParameter("reversalType");
		reversalObj.setTransferType(reversalType);
		logger.info("Entered file id is"+fileId);
		String status=request.getParameter("status");

		String fileName=request.getParameter("FileNameSearch");
		reversalObj.setFileName(fileName);

		reversalObj.setFxStatus(status);

		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		int page = 1,totalPages = 0;
		String errorMessage,errorCode;

		Map<Map<Integer,List<String>>, List<FileDetails>> fileDetailsList=bulkDao.reversalTracking(page,fileId,reversalType,userId,role,status,fileName);

		if(fileDetailsList!=null){

			Set mapSet = (Set) fileDetailsList.entrySet();
			Iterator mapIterator = mapSet.iterator();
			while (mapIterator.hasNext()) {
				Map.Entry<Map<Integer,List<String>>, List<FileDetails>> mapEntry = (Map.Entry<Map<Integer,List<String>>, List<FileDetails>>) mapIterator.next();
				Map<Integer,List<String>> totalPagesAndErrorDetailsList;
				totalPagesAndErrorDetailsList=mapEntry.getKey();
				Set totalPagesAndErrorsSet = (Set) totalPagesAndErrorDetailsList.entrySet();
				Iterator totalPagesAndErrorsIterator = totalPagesAndErrorsSet.iterator();
				while (totalPagesAndErrorsIterator.hasNext()) {
					Map.Entry<Integer,List<String>> totalPagesAndErrorsEntry = (Map.Entry<Integer,List<String>>) totalPagesAndErrorsIterator.next();
					totalPages=totalPagesAndErrorsEntry.getKey();
					errorCode=totalPagesAndErrorsEntry.getValue().get(0);
					errorMessage=totalPagesAndErrorsEntry.getValue().get(1);
				}
				List<FileDetails> fileDetails;
				fileDetails=(List<FileDetails>) mapEntry.getValue();
				modelAndViewObj.addObject("fileDetailsList", fileDetails);
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("totalPages", totalPages);
				modelAndViewObj.setViewName("reversalTracking");
				session.setAttribute("reversalObj", reversalObj);
			}
		}
		else{
			logger.info("no files to display based on search");

			modelAndViewObj.addObject("error", "No records to display !!");
			modelAndViewObj.setViewName("reversalTracking");
			return modelAndViewObj;
		}

		return modelAndViewObj;

	}
	@RequestMapping(value = "/reversalTrackingp", method = RequestMethod.GET)
	public ModelAndView reversalTrackingp(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		int SNo;
		session=request.getSession(true);
		logger.info("Entered into reversal tracking ");
		BulkDetails reversalObj=(BulkDetails) session.getAttribute("reversalObj");
		int page=Integer.parseInt(request.getParameter("pageNum"));

		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		int totalPages = 0;
		String errorMessage,errorCode;

		Map<Map<Integer,List<String>>, List<FileDetails>> fileDetailsList=bulkDao.reversalTracking(page,reversalObj.getFileID(),reversalObj.getTransferType(),userId,role,reversalObj.getFxStatus(),reversalObj.getFileName());

		if(fileDetailsList!=null){

			Set mapSet = (Set) fileDetailsList.entrySet();
			Iterator mapIterator = mapSet.iterator();
			while (mapIterator.hasNext()) {
				Map.Entry<Map<Integer,List<String>>, List<FileDetails>> mapEntry = (Map.Entry<Map<Integer,List<String>>, List<FileDetails>>) mapIterator.next();
				Map<Integer,List<String>> totalPagesAndErrorDetailsList;
				totalPagesAndErrorDetailsList=mapEntry.getKey();
				Set totalPagesAndErrorsSet = (Set) totalPagesAndErrorDetailsList.entrySet();
				Iterator totalPagesAndErrorsIterator = totalPagesAndErrorsSet.iterator();
				while (totalPagesAndErrorsIterator.hasNext()) {
					Map.Entry<Integer,List<String>> totalPagesAndErrorsEntry = (Map.Entry<Integer,List<String>>) totalPagesAndErrorsIterator.next();
					totalPages=totalPagesAndErrorsEntry.getKey();
					errorCode=totalPagesAndErrorsEntry.getValue().get(0);
					errorMessage=totalPagesAndErrorsEntry.getValue().get(1);
				}
				List<FileDetails> fileDetails;
				fileDetails=(List<FileDetails>) mapEntry.getValue();
				modelAndViewObj.addObject("fileDetailsList", fileDetails);
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("totalPages", totalPages);
				modelAndViewObj.setViewName("reversalTracking");
			}
		}
		else{
			logger.info("no files to display based on search");

			modelAndViewObj.addObject("error", "No records to display !!");
			modelAndViewObj.setViewName("reversalTracking");
			return modelAndViewObj;
		}

		return modelAndViewObj;

	}


	@RequestMapping(value = "/paymentTrackingSearch")
	public ModelAndView paymentTrackingSearch(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		BulkDetails paymentObj1=new BulkDetails();
		int SNo = 0;
		session=request.getSession(true);
		String fileId=request.getParameter("FileIDSearch");
		paymentObj1.setFileID(fileId);
		logger.info("Entered into Payment Approval Search");
		String paymentMode = request.getParameter("PaymentModeSearch");
		paymentObj1.setPaymentMode(paymentMode);
		logger.info("Entered file id is"+fileId);
		String status=request.getParameter("status");
		System.out.println(status);
		String fileName=request.getParameter("fileName");
		paymentObj1.setFileName(fileName);

		paymentObj1.setFxStatus(status);
		//logger.info("date is"+activeDate);
		//	reversalObj.setPaymentMode(request.getParameter("paymentMode"));
		//logger.info("payment mode is"+paymentMode);

		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		int page = 1,totalPages = 0;
		String errorMessage,errorCode;


		List<String> trackingFileList=bulkDao.trackingFilenameList(userId);
		Map<Map<Integer,List<String>>, List<FileDetails>> fileDetailsList=bulkDao.paymentTracking(page,fileId,paymentMode,userId,role,status,fileName);

		if(fileDetailsList!=null){

			Set mapSet = (Set) fileDetailsList.entrySet();
			Iterator mapIterator = mapSet.iterator();
			while (mapIterator.hasNext()) {
				Map.Entry<Map<Integer,List<String>>, List<FileDetails>> mapEntry = (Map.Entry<Map<Integer,List<String>>, List<FileDetails>>) mapIterator.next();
				Map<Integer,List<String>> totalPagesAndErrorDetailsList;
				totalPagesAndErrorDetailsList=mapEntry.getKey();
				Set totalPagesAndErrorsSet = (Set) totalPagesAndErrorDetailsList.entrySet();
				Iterator totalPagesAndErrorsIterator = totalPagesAndErrorsSet.iterator();
				while (totalPagesAndErrorsIterator.hasNext()) {
					Map.Entry<Integer,List<String>> totalPagesAndErrorsEntry = (Map.Entry<Integer,List<String>>) totalPagesAndErrorsIterator.next();
					totalPages=totalPagesAndErrorsEntry.getKey();
					errorCode=totalPagesAndErrorsEntry.getValue().get(0);
					errorMessage=totalPagesAndErrorsEntry.getValue().get(1);
				}
				List<FileDetails> fileDetails;
				fileDetails=(List<FileDetails>) mapEntry.getValue();
				modelAndViewObj.addObject("fileDetailsList", fileDetails);
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("totalPages", totalPages);
				modelAndViewObj.addObject("trackingFileList", trackingFileList);  
				modelAndViewObj.setViewName("paymentTracking");
				session.setAttribute("paymentObj1", paymentObj1);
			}
		}
		else{
			logger.info("no files to display based on search");

			modelAndViewObj.addObject("error", "No records to display !!");
			modelAndViewObj.setViewName("paymentTracking");
			return modelAndViewObj;
		}

		return modelAndViewObj;

	}
	@RequestMapping(value = "/paymentTrackingSearchp", method = RequestMethod.GET)
	public ModelAndView paymentTrackingSearchp(ModelMap model,
			HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		int SNo = 0;
		session=request.getSession(true);
		BulkDetails paymentObj1=(BulkDetails) session.getAttribute("paymentObj1");
		logger.info("Entered into payment tracking Search");

		int page=Integer.parseInt(request.getParameter("pageNum"));

		String userId=session.getAttribute("userid").toString();
		String role=session.getAttribute("user_role_id").toString();
		int totalPages = 0;
		String errorMessage,errorCode;

		Map<Map<Integer,List<String>>, List<FileDetails>> fileDetailsList=bulkDao.paymentTracking(page,paymentObj1.getFileID(),paymentObj1.getPaymentMode(),userId,role,paymentObj1.getFxStatus(),paymentObj1.getFileName());

		if(fileDetailsList!=null){

			Set mapSet = (Set) fileDetailsList.entrySet();
			Iterator mapIterator = mapSet.iterator();
			while (mapIterator.hasNext()) {
				Map.Entry<Map<Integer,List<String>>, List<FileDetails>> mapEntry = (Map.Entry<Map<Integer,List<String>>, List<FileDetails>>) mapIterator.next();
				Map<Integer,List<String>> totalPagesAndErrorDetailsList;
				totalPagesAndErrorDetailsList=mapEntry.getKey();
				Set totalPagesAndErrorsSet = (Set) totalPagesAndErrorDetailsList.entrySet();
				Iterator totalPagesAndErrorsIterator = totalPagesAndErrorsSet.iterator();
				while (totalPagesAndErrorsIterator.hasNext()) {
					Map.Entry<Integer,List<String>> totalPagesAndErrorsEntry = (Map.Entry<Integer,List<String>>) totalPagesAndErrorsIterator.next();
					totalPages=totalPagesAndErrorsEntry.getKey();
					errorCode=totalPagesAndErrorsEntry.getValue().get(0);
					errorMessage=totalPagesAndErrorsEntry.getValue().get(1);
				}
				List<FileDetails> fileDetails;
				fileDetails=(List<FileDetails>) mapEntry.getValue();
				modelAndViewObj.addObject("fileDetailsList", fileDetails);
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("totalPages", totalPages);
				modelAndViewObj.setViewName("paymentTracking");
			}
		}
		else{
			logger.info("no files to display based on search");

			modelAndViewObj.addObject("error", "No records to display !!");
			modelAndViewObj.setViewName("paymentTracking");
			return modelAndViewObj;
		}

		return modelAndViewObj;

	}
	@RequestMapping(value = "/PaymentReversalTransRecordsFileDownload",method=RequestMethod.GET)
	public ModelAndView payReversalTransRecordsFileDownload(
			HttpServletRequest request, HttpServletResponse response)
					throws IOException {
		System.out.println("inside download controller");

		List<BulkDetails> PayDirectRevTransLevelDetailsList = new ArrayList<BulkDetails>();
		List<BulkDetails> PayChequeBounceTransLevelDetailsList = new ArrayList<BulkDetails>();
		ModelAndView modelAndViewObj = new ModelAndView();
		String fileID = request.getParameter("FileId");
		String reversalType = request.getParameter("ReversalType1");
		int rowNumber = 1;


		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet();
		HSSFCell cell = null;
		HSSFRow row;
		if (reversalType.equalsIgnoreCase("DIRECT_REVERSAL")) {
			PayDirectRevTransLevelDetailsList = bulkDao.getDirectRevTransLevelRecords(fileID);
			// System.out.println("failure record list size"+PayPostingTransLevelDetailsList.size());

			row = sheet.createRow(0);
			cell = row.createCell(0);
			cell.setCellValue("Account Number");
			cell = row.createCell(1);
			cell.setCellValue("Tracking ID");
			cell = row.createCell(2);
			cell.setCellValue("Tracking ID serv");
			cell = row.createCell(3);
			cell.setCellValue("Uploaded By (OLM ID)");
			cell = row.createCell(4);
			cell.setCellValue("Uploaded by (Name)");
			cell = row.createCell(5);
			cell.setCellValue("File ID");
			cell = row.createCell(6);
			cell.setCellValue("File Name");
			cell = row.createCell(7);
			cell.setCellValue("Upload Date Time");
			cell = row.createCell(8);
			cell.setCellValue("Status");
			/*cell = row.createCell(9);
		cell.setCellValue("FX update time");*/
			cell = row.createCell(9);
			cell.setCellValue("Reason for Failure");

			for (int i = 0; i < PayDirectRevTransLevelDetailsList.size(); i++) {

				BulkDetails PayDirectRevTransRecordsObj = PayDirectRevTransLevelDetailsList
						.get(i);

				row = sheet.createRow(rowNumber);
				cell = row.createCell(0);
				cell.setCellValue(PayDirectRevTransRecordsObj
						.getAcctEXTID());
				sheet.autoSizeColumn(0);
				cell = row.createCell(1);
				cell.setCellValue(PayDirectRevTransRecordsObj.getTrackingId());
				sheet.autoSizeColumn(1);
				cell = row.createCell(2);
				cell.setCellValue(PayDirectRevTransRecordsObj
						.getTrackingIdServ());
				sheet.autoSizeColumn(2);
				cell = row.createCell(3);
				cell.setCellValue(PayDirectRevTransRecordsObj
						.getUserId());
				sheet.autoSizeColumn(3);
				cell = row.createCell(4);
				cell.setCellValue(PayDirectRevTransRecordsObj
						.getUserName());
				sheet.autoSizeColumn(4);
				cell = row.createCell(5);
				cell.setCellValue(PayDirectRevTransRecordsObj.getFileID());
				sheet.autoSizeColumn(5);
				cell = row.createCell(6);
				cell.setCellValue(PayDirectRevTransRecordsObj.getFileName());
				sheet.autoSizeColumn(6);
				cell = row.createCell(7);
				CellStyle cellStyle = wb.createCellStyle();
				CreationHelper createHelper = wb.getCreationHelper();

				cellStyle.setDataFormat(createHelper.createDataFormat()
						.getFormat("dd/mm/yyyy HH:mm:SS"));
				cell.setCellValue(PayDirectRevTransRecordsObj
						.getFileUploadDate());
				cell.setCellStyle(cellStyle);
				sheet.autoSizeColumn(7);
				cell = row.createCell(8);
				cell.setCellValue(PayDirectRevTransRecordsObj.getFxStatus());
				sheet.autoSizeColumn(8);

				cell = row.createCell(9);
				cell.setCellValue(PayDirectRevTransRecordsObj
						.getReason());

				sheet.autoSizeColumn(9);
				rowNumber = rowNumber + 1;

			}
		} else if (reversalType.equalsIgnoreCase("CHEQUE_BOUNCE")) {
			PayChequeBounceTransLevelDetailsList = bulkDao
					.getChequeBounceTransLevelRecords(fileID);


			row = sheet.createRow(0);
			cell = row.createCell(0);
			cell.setCellValue("Vendor");
			cell = row.createCell(1);
			cell.setCellValue("LOB");
			cell = row.createCell(2);
			cell.setCellValue("Upload File Name");
			cell = row.createCell(3);
			cell.setCellValue("Chq No");
			cell = row.createCell(4);
			cell.setCellValue("Bank Name");
			cell = row.createCell(5);
			cell.setCellValue("Cheque Date");

			cell = row.createCell(6);
			cell.setCellValue("Total Chq Value");
			cell = row.createCell(7);
			cell.setCellValue("Initial Uploaded date");
			cell = row.createCell(8);
			cell.setCellValue("Initial Posted date");
			cell = row.createCell(9);
			cell.setCellValue("Bounced date");
			cell = row.createCell(10);
			cell.setCellValue("Bounce MIS date");


			cell = row.createCell(11);
			cell.setCellValue("Status");

			for (int i = 0; i < PayChequeBounceTransLevelDetailsList.size(); i++) {

				BulkDetails PymntRevChqBounceRecordsDetailsObj = PayChequeBounceTransLevelDetailsList
						.get(i);

				row = sheet.createRow(rowNumber);
				cell = row.createCell(0);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getVendorName());
				sheet.autoSizeColumn(0);
				cell = row.createCell(1);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj.getServiceType());
				sheet.autoSizeColumn(1);
				cell = row.createCell(2);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getFileName());
				sheet.autoSizeColumn(2);
				cell = row.createCell(3);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj.getRefNo());
				sheet.autoSizeColumn(3);
				cell = row.createCell(4);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getBankName());
				sheet.autoSizeColumn(4);
				cell = row.createCell(5);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getDateOnChq());
				sheet.autoSizeColumn(5);

				cell = row.createCell(6);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getPaymentAmt());
				sheet.autoSizeColumn(6);
				cell = row.createCell(7);
				CellStyle cellStyle = wb.createCellStyle();
				CreationHelper createHelper = wb.getCreationHelper();

				cellStyle.setDataFormat(createHelper.createDataFormat()
						.getFormat("dd/mm/yyyy"));
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getInitialUploadDate());
				cell.setCellStyle(cellStyle);
				sheet.autoSizeColumn(7);
				cell = row.createCell(8);
				cellStyle.setDataFormat(createHelper.createDataFormat()
						.getFormat("dd/mm/yyyy"));
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getInitialPostedDate());
				cell.setCellStyle(cellStyle);
				sheet.autoSizeColumn(8);
				cell = row.createCell(9);
				cellStyle.setDataFormat(createHelper.createDataFormat()
						.getFormat("dd/mm/yyyy"));
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getBouncedDate());
				cell.setCellStyle(cellStyle);
				sheet.autoSizeColumn(9);
				cell = row.createCell(10);
				cellStyle.setDataFormat(createHelper.createDataFormat()
						.getFormat("dd/mm/yyyy"));
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getBouncedMisDate());
				cell.setCellStyle(cellStyle);
				sheet.autoSizeColumn(10);

				cell = row.createCell(11);
				cell.setCellValue(PymntRevChqBounceRecordsDetailsObj
						.getFxStatus());
				sheet.autoSizeColumn(11);

				rowNumber = rowNumber + 1;

			}
		}

		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		try {
			wb.write(outByteStream);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);

		}
		byte[] outArray = outByteStream.toByteArray();

		String fileName = fileID +"_"+reversalType+ ".xls";

		String mimeType = "application/ms-excel";
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				fileName);
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setContentLength(outArray.length);
		response.setContentType(mimeType);
		response.setHeader(headerKey, headerValue);
		OutputStream outStream;
		try {
			outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
			logger.error(" Exception occured : " + e.getMessage());
		}

		logger.info("End of failure records download ");
		// modelAndViewObj.setViewName("viewTracking");
		return modelAndViewObj;
	}
	@RequestMapping(value = "/downloadFailureRecordsInPayTransfer",method=RequestMethod.GET)
	public ModelAndView downloadFailureRecords(HttpServletRequest request,
			HttpServletResponse response) throws IOException {

		{

			List<BulkDetails> PaymentTranferErrorRecordsList = new ArrayList<BulkDetails>();
			ModelAndView modelAndViewObj = new ModelAndView();
			String FileId = request.getParameter("FileId");
			int rowNumber = 1;



			PaymentTranferErrorRecordsList = bulkDao
					.getPymntTransferErrorRecords(FileId);


			HSSFWorkbook wb = new HSSFWorkbook();
			HSSFSheet sheet = wb.createSheet();
			HSSFCell cell = null;
			HSSFRow row;

			row = sheet.createRow(0);
			cell = row.createCell(0);
			cell.setCellValue("Cheque/TransId");
			cell = row.createCell(1);
			cell.setCellValue("Source Tracking Id");
			cell = row.createCell(2);
			cell.setCellValue("Source Tracking Id Serv");
			cell = row.createCell(3);
			cell.setCellValue("Type ");
			cell = row.createCell(4);
			cell.setCellValue("Payment Mode");
			cell = row.createCell(5);
			cell.setCellValue("LOB");
			cell = row.createCell(6);
			cell.setCellValue("Account No");
			cell = row.createCell(7);
			cell.setCellValue("Invoice No");
			cell = row.createCell(8);
			cell.setCellValue("Amount");
			cell = row.createCell(9);
			cell.setCellValue("Uploaded By (OLM ID) ");
			cell = row.createCell(10);
			cell.setCellValue("Uploaded by (Name)");
			cell = row.createCell(11);
			cell.setCellValue("Upload Time");
			cell = row.createCell(12);
			cell.setCellValue("FileName");
			cell = row.createCell(13);
			cell.setCellValue("FileID");
			cell = row.createCell(14);
			cell.setCellValue("Status");

			cell = row.createCell(15);
			cell.setCellValue("Reason for Failure");


			for (int i = 0; i <PaymentTranferErrorRecordsList.size(); i++) 
			{

				BulkDetails PayTransferTransLevelBeanObj = PaymentTranferErrorRecordsList.get(i);

				row = sheet.createRow(rowNumber);
				cell = row.createCell(0);
				cell.setCellValue(PayTransferTransLevelBeanObj.getChequeNo());
				sheet.autoSizeColumn(0);
				cell = row.createCell(1);
				cell.setCellValue(PayTransferTransLevelBeanObj.getTrackingId());
				sheet.autoSizeColumn(1);
				cell = row.createCell(2);
				cell.setCellValue(PayTransferTransLevelBeanObj.getTrackingIdServ());
				sheet.autoSizeColumn(2);
				cell = row.createCell(3);
				cell.setCellValue(PayTransferTransLevelBeanObj.getTransferType());
				sheet.autoSizeColumn(3);
				cell = row.createCell(4);
				cell.setCellValue(PayTransferTransLevelBeanObj.getPaymentMode());
				sheet.autoSizeColumn(4);
				cell = row.createCell(5);
				cell.setCellValue(PayTransferTransLevelBeanObj.getServiceType());
				sheet.autoSizeColumn(5);

				cell = row.createCell(6);
				cell.setCellValue(PayTransferTransLevelBeanObj.getAcctEXTID());
				sheet.autoSizeColumn(6);
				cell = row.createCell(7);
				cell.setCellValue(PayTransferTransLevelBeanObj.getInvoiceNo());
				sheet.autoSizeColumn(7);
				cell = row.createCell(8);
				cell.setCellValue(PayTransferTransLevelBeanObj.getPaymentAmt());
				sheet.autoSizeColumn(8);

				cell = row.createCell(9);
				cell.setCellValue(PayTransferTransLevelBeanObj.getUserId());
				sheet.autoSizeColumn(9);
				cell = row.createCell(10);
				cell.setCellValue(PayTransferTransLevelBeanObj.getUserName());
				sheet.autoSizeColumn(10);
				cell = row.createCell(11);
				CellStyle cellStyle = wb.createCellStyle();
				CreationHelper createHelper = wb.getCreationHelper();

				cellStyle.setDataFormat(
						createHelper.createDataFormat().getFormat("dd/mm/yyyy"));
				if(PayTransferTransLevelBeanObj.getFileUploadDate()!=null)
				{
					cell.setCellValue(PayTransferTransLevelBeanObj.getFileUploadDate());
					cell.setCellStyle(cellStyle);
				}
				else
					cell.setCellValue("");	

				sheet.autoSizeColumn(11);
				cell = row.createCell(12);
				cell.setCellValue(PayTransferTransLevelBeanObj.getFileName());
				sheet.autoSizeColumn(12);
				cell = row.createCell(13);
				cell.setCellValue(PayTransferTransLevelBeanObj.getFileID());
				sheet.autoSizeColumn(13);
				cell = row.createCell(14);
				cell.setCellValue(PayTransferTransLevelBeanObj.getFxStatus());
				sheet.autoSizeColumn(14);
				cell = row.createCell(15);

				cell = row.createCell(15);
				if(PayTransferTransLevelBeanObj.getReason()==null||PayTransferTransLevelBeanObj.getReason().equalsIgnoreCase("NA"))
					cell.setCellValue("");
				else
					cell.setCellValue(PayTransferTransLevelBeanObj.getReason());
				sheet.autoSizeColumn(15);

				rowNumber=rowNumber+1;

			}


			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
			try {
				wb.write(outByteStream);

			} catch (IOException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				/* logger.error(" Exception occured : "+e.getMessage()); */
			}
			byte[] outArray = outByteStream.toByteArray();

			String fileName = FileId +"_failure_records"+".xls";

			String mimeType = "application/ms-excel";
			String headerKey = "Content-Disposition";
			String headerValue = String.format("attachment; filename=\"%s\"",
					fileName);
			response.setHeader("Content-Transfer-Encoding", "binary");
			response.setHeader("Expires:", "0"); // eliminates browser caching
			response.setContentLength(outArray.length);
			response.setContentType(mimeType);
			response.setHeader(headerKey, headerValue);
			OutputStream outStream;
			try {
				outStream = response.getOutputStream();
				outStream.write(outArray);
				outStream.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);

			}



			return modelAndViewObj;
		}

	}
	public static String getDateTime() {
		Date today = Calendar.getInstance().getTime();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		return formatter.format(today);
	}
	
	@RequestMapping(value = "/loadPaymentTransfer")
	public ModelAndView searchPaymentTransfer(ModelMap model,HttpServletRequest request,HttpServletResponse response) throws IOException {
		logger.info("START ------>loadPaymentTransfer");
		int page = 1;
		session = request.getSession(true);
		ModelAndView modelAndViewObj = new ModelAndView();	
		String roleId = session.getAttribute("user_role_id").toString();
		String searchUserId=null;
		String searchFileId = null;
		String searchFromDate =null;
		String searchEndDate =null;
		boolean noSearchCriteria=true;
		try {
			if(request.getParameter("pageNum")!=null){
				paymentTransferDTO.setCurrentPage(Integer.parseInt(request.getParameter("pageNum")));
				noSearchCriteria=false;
			}else
				paymentTransferDTO.setCurrentPage(page);
			
			if(request.getParameter("ticketId")!=null){
				paymentTransferDTO.setSearchFileId(request.getParameter("ticketId"));
				noSearchCriteria=false;
			}else
				paymentTransferDTO.setSearchFileId(searchFileId);
			
			if(request.getParameter("uploadedUser")!=null){
				paymentTransferDTO.setSearchUserId(request.getParameter("uploadedUser"));
			}else
				paymentTransferDTO.setSearchUserId(searchUserId);
			
			if(request.getParameter("fromDate")!=null){
				paymentTransferDTO.setSearchFromDate(request.getParameter("fromDate"));
				noSearchCriteria=false;
			}else
				paymentTransferDTO.setSearchFromDate(searchFromDate);
			
			if(request.getParameter("endDate")!=null){
				paymentTransferDTO.setSearchEndDate(request.getParameter("endDate"));
				noSearchCriteria=false;
			}else
				paymentTransferDTO.setSearchEndDate(searchEndDate);			
			
			List<String> rejectReasonList=bulkDao.getRejectReasons();
			if(rejectReasonList==null)
			 {
				 modelAndViewObj.addObject("error", "Problem with Backend System");
				 modelAndViewObj.setViewName("paymentTransferApproval");
				 return modelAndViewObj;
			 }
			paymentTransferDTO = bulkDao.getPaymentTransferWorkDetails(roleId, paymentTransferDTO);
		    
			if(noSearchCriteria){
				modelAndViewObj.addObject("filtersearch", "true");	
			}else
			modelAndViewObj.addObject("filtersearch", "false");	
			
			modelAndViewObj.addObject("totalRecords",paymentTransferDTO.getTotalResults());
			modelAndViewObj.addObject("resultsPerPage",paymentTransferDTO.getResultPerPage());			
			modelAndViewObj.addObject("paymentTransferDetailList", paymentTransferDTO.getPaymentTransferDetailList());
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.addObject("totalPages", paymentTransferDTO.getTotalPages());
			modelAndViewObj.addObject("message", paymentTransferDTO.getErrorMsg());
			modelAndViewObj.addObject("paymentTransferDTO",new PaymentTransferDTO());			
			modelAndViewObj.addObject("rejectReasonList", rejectReasonList);
			modelAndViewObj.setViewName("paymentTransferApproval");
		} catch (Exception e) {
			logger.error(e);
		}
					
		return modelAndViewObj;
	}
	
/*	@RequestMapping(value = "/searchPaymentTransfer", method = RequestMethod.GET)
	public ModelAndView searchPaymentTransfer(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("Reaching search controller method");
		int page = 0;
		session = request.getSession(true);
		String ticketId = null,fromDate = null,endDate = null,olmId=null;
		ModelAndView modelAndViewObj = new ModelAndView();
	
	
		modelAndViewObj.setViewName("paymentTransferApproval");			
		return modelAndViewObj;
		
	}*/
	
	@RequestMapping(value = "/paymentTransferDownload", method = RequestMethod.GET)
	public void paymentTransferDownload(HttpServletRequest request,
			HttpServletResponse response) throws IOException {

		try{
	    	  
	    	    logger.info("ENTERED INTO paymentTransferDownload EXPORT TO EXCEL METHOD @ CONTROLLER");
	    		//String extension="xlsx";
	    		String requestFileIdId = request.getParameter("FileId");
	    		String requestFileName = request.getParameter("FileName");
		    	
	            logger.info("requested fileid is===>" +requestFileIdId+"requestFileName is=========>"+requestFileName);
	    	   
	    		session = request.getSession(true);
	    		String userId = session.getAttribute("userid").toString();
	    		String role = session.getAttribute("user_role_id").toString();
	    		
		        PaymentTransferDTO paymenTransferDownloadObj=bulkDao.downloadPaymentTransferFile(userId,requestFileIdId,requestFileName);	
		    
	          //*****create empty zip --->get payment transfer file --->get support file ---> add files to zip ---> download zip******	        
		        
		        
		       //********************creating empty zip***************************** 
		        String zipFile = "Payment_Transfer_"+requestFileIdId+"."+"zip";
		        ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(zipFile));
		        zip.putNextEntry(new ZipEntry(zipFile));
		        zip.closeEntry();
		        zip.flush();
		        zip.close();
				logger.info("successfully generated an empty zip file");
			  //*********************creating empty zip completed******************** 

				
			 //********************get payment transfer file************************	
				logger.info("homePath==>" +homePath);				
				
				if(requestFileName.endsWith(".xls")==true)
					
					requestFileName=requestFileName.replace(".xls",
							"_" +requestFileIdId + ".xls");
				
				else if(requestFileName.endsWith(".xlsx")==true)
					requestFileName=requestFileName.replace(".xlsx",
							"_" +requestFileIdId + ".xlsx");
				
				String filename=homePath+ File.separator+"UPLOADED_FILES"+File.separator+"PaymentTransfer"+File.separator+"InputFiles"+File.separator+requestFileName;
				logger.info("Uploaded Filename====>"+filename);	
			 //********************get payment advice file completed*******************	
               
				       
		    //******************get support file************************       
				String supportFileName="";
				File supportFilesFolder = new File(homePath+File.separator+"UPLOADED_FILES"+File.separator+"PaymentTransfer"+File.separator+"SupportFiles"+File.separator);
				File[] listOfSupportFiles = supportFilesFolder.listFiles();
				
				logger.info("supportFilesFolder=====>"+supportFilesFolder+" listOfSupportFiles==>"+listOfSupportFiles.length);

			for (int i = 0; i < listOfSupportFiles.length; i++) {
				if (listOfSupportFiles[i].isFile()) {
					logger.info("support file found");
					supportFileName = "Payment_Transfer_Support_File_"+ requestFileIdId;
					if (listOfSupportFiles[i].getName().contains(supportFileName)) {
						logger.info("contains Payment_Transfer_Support_File_ in name==>" + listOfSupportFiles[i].getName());
						supportFileName = homePath+ File.separator+"UPLOADED_FILES"+File.separator+"PaymentTransfer"+File.separator+"SupportFiles"+File.separator+listOfSupportFiles[i].getName();
						
						logger.info("support file after mentioning path is"+ supportFileName);
						break;
					} else {
						logger.info("file not found");
						supportFileName ="FILE_NOT_FOUND";
					}
				}
			}
				//**********************get support file completed******************************		
			    
				logger.info("final payment transfer file name is......" +filename +"  final support file name is............."+supportFileName);
				
				//****************************adding files to zip********************************		
			List<String> srcFiles = new ArrayList<String>();
			srcFiles.add(filename);
			if (!(supportFileName.equalsIgnoreCase("FILE_NOT_FOUND"))) {
				srcFiles.add(supportFileName);
			}
			logger.info("src files size is" +srcFiles.size());
			byte[] buffer = new byte[10240];
			FileOutputStream fos = new FileOutputStream(zipFile);
			ZipOutputStream zos = new ZipOutputStream(fos);
			try {
				for (int i = 0; i < srcFiles.size(); i++) {
					File srcFile = new File(srcFiles.get(i));
					FileInputStream fis = new FileInputStream(srcFile);
					zos.putNextEntry(new ZipEntry(srcFile.getName()));
					int length;
					while ((length = fis.read(buffer)) > 0) {
						zos.write(buffer, 0, length);
					}
					zos.closeEntry();
					fis.close();
					/*if (!(srcFile.getName().contains("Payment_Transfer_Support_File_"))) {
						srcFile.delete();
					}*/
					logger.info("successfully zipped the file");
				}
				zos.close();
			} catch (IOException ioe) {
				logger.info("Error creating zip file: " + ioe);
				logger.info(ioe.getLocalizedMessage());
				StringWriter errors= new StringWriter();
				ioe.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
	//********************************adding files to zip completed*******************************
				
	//********************************download zip************************************************			
			ServletOutputStream out = response.getOutputStream();
			FileInputStream in = new FileInputStream(zipFile);
			logger.info("zip Input File name:" + in);
			response.setContentType("APPLICATION/OCTET-STREAM");
			response.addHeader("content-disposition", "attachment; filename="+ zipFile);
			logger.info("PROCESS COMPLETED AND FETCHED THE FILE @ CONTROLLER");
			int octet = 0;
			while ((octet = in.read()) != -1)
			out.write(octet);
			in.close();
			out.flush();
			out.close();
			response.flushBuffer();
			logger.info("finished execution of payment transfer download");

		} catch (Exception e) {
			logger.info(e.getLocalizedMessage());
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
	//********************************download zip completed*********************************	

	}
	
	@RequestMapping(value = "/paymentTransferApproval", method = RequestMethod.GET)
	public ModelAndView paymentTransferApprove (@RequestParam String action,@ModelAttribute ("paymentTransferDTO") PaymentTransferDTO paymentTransferDTO,HttpServletRequest request)
	{
		ModelAndView modelAndViewObj = new ModelAndView();
		session=request.getSession(true);
		String message = "";
		int page = 1;
		String userId=session.getAttribute("userid").toString();
		String roleId=session.getAttribute("user_role_id").toString();
		
		String rejectReasonRemarks= request.getParameter("reason");
		paymentTransferDTO.setRejectReason(rejectReasonRemarks);
		
		
		action = request.getParameter("action");
		List<String>checkedPTList =paymentTransferDTO.getCheckedPTList();
		Object[] obj =new Object[2];
		List<FileDetails> approveFinalList=new ArrayList<FileDetails>();
		
		logger.info("Remarks List called===>"+paymentTransferDTO.getCheckedRemarkList().size());
		logger.info("File List called===>"+checkedPTList+":::userId===>"+userId);
		logger.info("Rejection List===>"+paymentTransferDTO.getRejectReasonDropDown()+"::Reject Reason==>"+paymentTransferDTO.getRejectReason());

		try {
			String status = null;
			paymentTransferDTO.setCurrentPage(page);
			/*if (action.equals("A")) {
				status = bulkDao.approvePaymentTransfer(paymentTransferDTO.getCheckedPTList(),paymentTransferDTO.getCheckedRemarkList(),roleId,action);
			} else if (action.equals("R")) {
				status = bulkDao.approvePaymentTransfer(paymentTransferDTO.getCheckedPTList(),paymentTransferDTO.getCheckedRemarkList(),roleId,action);
			}*/
			
			
			obj = (Object[]) bulkDao.approvePaymentTransfer(paymentTransferDTO.getCheckedPTList(),paymentTransferDTO.getCheckedRemarkList(),userId,action,paymentTransferDTO.getRejectReasonDropDown(),paymentTransferDTO.getRejectReason());
			status= (String) obj[0];
			
			if (status.equalsIgnoreCase("Success") && action.equals("A")) {
				message = "Payment Transfer File Approved.";

			} else if (status.equalsIgnoreCase("Success") && action.equals("R")) {
				message = "Payment Transfer File Rejected.";
			}
			if (!status.equalsIgnoreCase("Success")) {
				message =  status;
			}
			logger.info("Inside approve button click method");
			
			//Commentetd on 21st August 2019
			
			/*List<String> rejectReasonList=bulkDao.getRejectReasons();
			
			paymentTransferDTO = bulkDao.getPaymentTransferWorkDetails(roleId, paymentTransferDTO);
			
			logger.info("List Size is " + paymentTransferDTO.getPaymentTransferDetailList().size());
			
			modelAndViewObj.addObject("filtersearch", "true");
			modelAndViewObj.addObject("paymentTransferDetailList", paymentTransferDTO.getPaymentTransferDetailList());
			modelAndViewObj.addObject("resultsPerPage",paymentTransferDTO.getResultPerPage());	
			modelAndViewObj.addObject("currentPage", page);
			modelAndViewObj.addObject("totalPages", paymentTransferDTO.getTotalPages());
			modelAndViewObj.addObject("totalRecords",paymentTransferDTO.getTotalResults());
			modelAndViewObj.addObject("message", message);
			modelAndViewObj.addObject("paymentTransferDTO",new PaymentTransferDTO());
			modelAndViewObj.addObject("approveRejectMessage", message);
			modelAndViewObj.addObject("rejectReasonList", rejectReasonList);
			modelAndViewObj.setViewName("paymentTransferApproval");*/
			
			//Added by Ritu on 14th June
			//Mail
			modelAndViewObj.addObject("message", message);
			modelAndViewObj.addObject("approveRejectMessage", message);
			
			//Added on 21st Aug 2019
			approveFinalList = (List<FileDetails>) obj[1];
			modelAndViewObj.addObject("approveFinalListDetails", approveFinalList);
			modelAndViewObj.setViewName("paymentTransferApproved");
			
			
			 File fileObj;
			if(action.equals("A"))
			{
				fileObj =new File(homePath+"/Conf/EmailAlertsTemplates/PaymentTransferApprovalApprove.properties");
			}
			else
			{
			  fileObj=new File(homePath+"/Conf/EmailAlertsTemplates/PaymentTransferApprovalReject.properties");
			}
				
			InputStream inputStream=new FileInputStream(fileObj);
			Properties properties=new Properties();
			properties.load(inputStream);
			
			UserEmailDetails userEmailDetails = new UserEmailDetails();
			String origStringValue=null;
			String fileIdStr = null;
			userEmailDetails=bulkDao.getEmailAddress(userId);
			
			for(int i=0;i<approveFinalList.size();i++){	
				logger.info("approveFinalList.get(i).getFileID()>>" +approveFinalList.get(i).getFileID());
				logger.info("approveFinalList.get(i).getRequestStatus()>>" +approveFinalList.get(i).getRequestStatus());
				if((approveFinalList.get(i).getRequestStatus())!=null
						&& !((approveFinalList.get(i).getRequestStatus()).contains("Action already taken by some other user"))){
					EMailContent emailContentObj=new EMailContent();
					
					emailContentObj.setEmailSubject(properties.getProperty("EmailSubject").replace("Ticket no.:", (approveFinalList.get(i).getFileID())));
					emailContentObj.setEmailHeader(properties.getProperty("EmailHeader"));
					
					if(action.equals("A")){
					 emailContentObj.setEmailBody(properties.getProperty("EmailBody").replace("Ticket no.:","Ticket no.:"+""+(approveFinalList.get(i).getFileID()))
							.replace("Total Records:","Total Records :"+""+approveFinalList.get(i).getTotalRecords()).replace("Total Value:", "Total Value: "+""+approveFinalList.get(i).getValidSum()));
					}
					
					if(action.equals("R")){
					  emailContentObj.setEmailBody(properties.getProperty("EmailBody").replace("Ticket no.:","Ticket no.:"+""+(approveFinalList.get(i).getFileID()))
							.replace("reason:","reason :"+""+approveFinalList.get(i).getRejectReason())
							.replace("rejectionRemarks:","rejectionRemarks :"+""+approveFinalList.get(i).getRejectedRemarks())
							.replace("Total Records:","Total Records :"+""+approveFinalList.get(i).getTotalRecords()).replace("Total Value:", "Total Value: "+""+approveFinalList.get(i).getValidSum()));
					}
					
					emailContentObj.setEmailFooter(properties.getProperty("EmailFooter"));

					logger.info("email subject is " +emailContentObj.getEmailSubject());
					logger.info("email body is " +emailContentObj.getEmailBody());
					List<String> emailToList=new ArrayList<String>();
					emailToList.add(approveFinalList.get(i).getEmailId());
					logger.info("uploaded email id" +approveFinalList.get(i).getEmailId());
					emailContentObj.setEmailToList(emailToList);


					List<String> emailCCList=new ArrayList<String>();
					emailCCList.add(userEmailDetails.getEmailAddress());

					emailContentObj.setEmailCCList(emailCCList);

					//emailContentObj.setEmailBCCList(emailCCList);

					emailContentObj.setAttachmentRequired(false);

					SmtpUtility.setLogger(logger);

					SmtpMailContent smtpMailContentObj=SmtpUtility.generateEmailAlert(emailContentObj);
					logger.info("Error Code "+smtpMailContentObj.getErrorCode());
					logger.info(" Error Message "+smtpMailContentObj.getErrorMessage());
				}
			}
			
			//Concatenating File Id -OrigTrackingID
			/*if(checkedPTList!=null && !checkedPTList.isEmpty()){
				for(int i =0 ;i<checkedPTList.size();i++){
					origStringValue = checkedPTList.get(i);
					
					String []origValueArray =origStringValue.split("-") ;
					
					if(fileIdStr!=null)
					   fileIdStr = fileIdStr+","+origValueArray[0]+"-"+origValueArray[1];
					else
						fileIdStr= origValueArray[0]+"-"+origValueArray[1];
				
				logger.info("fileIdStr for sending Email==>"+fileIdStr);
			 }
				
		   if (status.equalsIgnoreCase("Success") && action.equals("A")) {
					message = "Payment Transfer File Approved.";

			} else if (status.equalsIgnoreCase("Success") && action.equals("R")) {
					message = "Payment Transfer File Rejected.";
				}
			
		*/
           
			
		} catch (Exception e) {
			logger.error(e);
		}
		return modelAndViewObj;
	}
	



}