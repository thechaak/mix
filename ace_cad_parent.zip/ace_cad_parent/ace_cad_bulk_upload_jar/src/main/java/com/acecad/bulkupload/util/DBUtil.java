package com.acecad.bulkupload.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DBUtil {

	/**
	 * @param args
	 */

	private String userName;
	private String password;
	private String dbUrl;
	private String driverName;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDbUrl() {
		return dbUrl;
	}

	public void setDbUrl(String dbUrl) {
		this.dbUrl = dbUrl;
	}

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public static Connection getConnection() {
		String driverName = "oracle.jdbc.driver.OracleDriver";
		String dbUrl = "jdbc:oracle:thin:@172.25.129.211:1521:CAD_LOCAL_DB";
		String userName = "CAD_USER";
		String password = "CAD_USER";
		Connection dbConnection = null;
		try {
			Class.forName(driverName);
			dbConnection = DriverManager.getConnection(dbUrl,
					userName, password);
			System.out.println("DB Connection Established !!!!");

		} catch (SQLException e) {
			e.printStackTrace();

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return dbConnection;
	}

	public static void closeConnection(Connection dbConnection) {
		try {
			if (dbConnection != null) {
				dbConnection.close();
				System.out.println("DB Connection Closed !!!!");
			}

		} catch (SQLException e) {
			e.printStackTrace();

		}
	}

	public static void main(String[] args) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String formattedDate=dateFormat.format(date);
		System.out.println(formattedDate);


		}
}
	 

