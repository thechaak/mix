package com.acecad.bulkupload.dao;

import java.util.HashMap;
import java.util.List;

import com.acecad.bulkupload.model.TransferIcrmDetails;


public interface TransferIcrmDao {

	
	int getRole(String parentUser);
	/*public List<String> CrmPayModeDropdown();*/
	HashMap<Integer, List<TransferIcrmDetails>> getTransferIcrmDetailsMap(TransferIcrmDetails TransferIcrmDetailsObj,int page);

	List<TransferIcrmDetails> getTransferIcrmExcelList(
			TransferIcrmDetails transferIcrmDetailsObj, String pageNum);
public List<TransferIcrmDetails> modifiedCrmDetails(List<TransferIcrmDetails> modifiedAccountsRecords,String userId,String sessionId,String action,int pageNumber);
public TransferIcrmDetails validationsFromFX(TransferIcrmDetails crmInputFxObj);
String rejectedCrmDetails(
		List<String> crmRejectedList, String userId,
		String sessionId, String rejectedReason);
	

}
