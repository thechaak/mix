package com.acecad.bulkupload.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class PaymentTransferDTO implements Serializable{

	private static final long serialVersionUID = -335821662408768190L;
	private String searchUserId;
	private String searchFileId;
	private String searchFromDate;
	private String searchEndDate;
	private int totalResults; 
	private int resultPerPage;
	private int totalPages;
	private String errorMsg;
	private int currentPage;
	
	//Return parameters from Cursor
	private String file_id;
	private String file_name;
	private String final_file_name;
	private int total_records;
	private String file_upload_date;
	private String payment_mode;
	private String vendor_userId;
	private String uploadedUserName;
	private String total_amount;
	private String attached_file;
	private int mbl_count;
	private int fl_count;
	private int aes_count; 
	private int istm_count;
	private String origTrackingId;
	private String origTrackingIdServ;
	private String origTrackingTotalAmount;
	private String origStatus;
	private String checkBoxEnable;
	private String status;
	private String payMode;
	private String b2b2c;
	private String legalEntity;
	private String cadApprovalReceived;
	private String approvedDate;
	private String approvedBy;
	private String approvedByName;
	private String fxStatus;
	private String fxStatusDesc;
	private String fxPostedDate;
	private String statusDesc;
	private String transactionId; //Ritu
		
	//private String utrNo;
	
	//Parameters from cursor ends here	
	
	
	//Parameters for Download Payment Transfer and Support File
	 private String downloadStatus;
	 private String accountNo;
	 private String transDate;
	 private String chequeNo;
	 private String utrNo;
	 private String amount;
	 private String invoiceNo;
	 private String billRefResets;
	 private String lob;
	 private String transferType;
	 private String annotation;
	 private String cadReceivedDate;
	 private String origTrackingString;
	//Parameters for Download Payment Transfer and Support File Ends here
	 
	 //Passing Values to Controller
	 private List<String>checkedRemarkList ;
	 private List<String>checkedPTList;
	 private String rejectReasonDropDown;
	 private String rejectReason;
	// private List<Map<String, String>>checkedPTList;
	 //private Map<String, String> origTrackingMap ;
	 
	 
	 private String paymentPostDate;
	 private String remarks;
	 
	 private String trackingId;
	 private String trackingIdServ;
	 
	 private String companyName;
	 private String customerName;
	 
	 
	 private String circle;
	 private String segment;
	 
	 private String exemptionFlag;
	 private String mailId;
	 
	 
	 private String accountStatus;
	 private String paymentCode;
	 
	 
	 private String paymentDescription;	 
	 
	 
	 //Passing Values to Controller ends here
	 
	
	public String getCadApprovalReceived() {
		return cadApprovalReceived;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getLegalEntity() {
		return legalEntity;
	}
	public void setCadApprovalReceived(String cadApprovalReceived) {
		this.cadApprovalReceived = cadApprovalReceived;
	}
	public String getApprovedDate() {
		return approvedDate;
	}
	public void setApprovedDate(String approvedDate) {
		this.approvedDate = approvedDate;
	}
	public String getApprovedBy() {
		return approvedBy;
	}
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}
	public String getApprovedByName() {
		return approvedByName;
	}
	public void setApprovedByName(String approvedByName) {
		this.approvedByName = approvedByName;
	}
	public String getFxStatus() {
		return fxStatus;
	}
	public void setFxStatus(String fxStatus) {
		this.fxStatus = fxStatus;
	}
	public String getFxStatusDesc() {
		return fxStatusDesc;
	}
	public void setFxStatusDesc(String fxStatusDesc) {
		this.fxStatusDesc = fxStatusDesc;
	}
	public String getFxPostedDate() {
		return fxPostedDate;
	}
	public void setFxPostedDate(String fxPostedDate) {
		this.fxPostedDate = fxPostedDate;
	}
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	public void setLegalEntity(String legalEntity) {
		this.legalEntity = legalEntity;
	}
	public String getPaymentPostDate() {
		return paymentPostDate;
	}
	public void setPaymentPostDate(String paymentPostDate) {
		this.paymentPostDate = paymentPostDate;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	public String getTrackingIdServ() {
		return trackingIdServ;
	}
	public void setTrackingIdServ(String trackingIdServ) {
		this.trackingIdServ = trackingIdServ;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getSegment() {
		return segment;
	}
	public void setSegment(String segment) {
		this.segment = segment;
	}
	public String getExemptionFlag() {
		return exemptionFlag;
	}
	public void setExemptionFlag(String exemptionFlag) {
		this.exemptionFlag = exemptionFlag;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	public String getPaymentCode() {
		return paymentCode;
	}
	public void setPaymentCode(String paymentCode) {
		this.paymentCode = paymentCode;
	}
	public String getPaymentDescription() {
		return paymentDescription;
	}
	public void setPaymentDescription(String paymentDescription) {
		this.paymentDescription = paymentDescription;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	List<PaymentTransferDTO> paymentTransferDetailList = new ArrayList<PaymentTransferDTO>();	
	
	public List<PaymentTransferDTO> getPaymentTransferDetailList() {
		return paymentTransferDetailList;
	}
	public void setPaymentTransferDetailList(List<PaymentTransferDTO> paymentTransferDetailList) {
		this.paymentTransferDetailList = paymentTransferDetailList;
	}
	
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	
	public String getSearchUserId() {
		return searchUserId;
	}
	public void setSearchUserId(String searchUserId) {
		this.searchUserId = searchUserId;
	}
	public String getSearchFileId() {
		return searchFileId;
	}
	public void setSearchFileId(String searchFileId) {
		this.searchFileId = searchFileId;
	}
	public String getSearchFromDate() {
		return searchFromDate;
	}
	public void setSearchFromDate(String searchFromDate) {
		this.searchFromDate = searchFromDate;
	}
	public String getSearchEndDate() {
		return searchEndDate;
	}
	public void setSearchEndDate(String searchEndDate) {
		this.searchEndDate = searchEndDate;
	}
	public int getTotalResults() {
		return totalResults;
	}
	public void setTotalResults(int totalResults) {
		this.totalResults = totalResults;
	}
	public int getResultPerPage() {
		return resultPerPage;
	}
	public void setResultPerPage(int resultPerPage) {
		this.resultPerPage = resultPerPage;
	}
	public int getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	
	//Return parameters from Cursor
	public String getFile_id() {
		return file_id;
	}
	public void setFile_id(String file_id) {
		this.file_id = file_id;
	}
	public String getFile_name() {
		return file_name;
	}
	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}
	public String getFinal_file_name() {
		return final_file_name;
	}
	public void setFinal_file_name(String final_file_name) {
		this.final_file_name = final_file_name;
	}
	public int getTotal_records() {
		return total_records;
	}
	public void setTotal_records(int total_records) {
		this.total_records = total_records;
	}
	public String getFile_upload_date() {
		return file_upload_date;
	}
	public void setFile_upload_date(String file_upload_date) {
		this.file_upload_date = file_upload_date;
	}
	public String getPayment_mode() {
		return payment_mode;
	}
	public void setPayment_mode(String payment_mode) {
		this.payment_mode = payment_mode;
	}
	public String getVendor_userId() {
		return vendor_userId;
	}
	public void setVendor_userId(String vendor_userId) {
		this.vendor_userId = vendor_userId;
	}
	public String getUploadedUserName() {
		return uploadedUserName;
	}
	public void setUploadedUserName(String uploadedUserName) {
		this.uploadedUserName = uploadedUserName;
	}
	public String getTotal_amount() {
		return total_amount;
	}
	public void setTotal_amount(String total_amount) {
		this.total_amount = total_amount;
	}
	public String getAttached_file() {
		return attached_file;
	}
	public void setAttached_file(String attached_file) {
		this.attached_file = attached_file;
	}
	public int getMbl_count() {
		return mbl_count;
	}
	public void setMbl_count(int mbl_count) {
		this.mbl_count = mbl_count;
	}
	public int getFl_count() {
		return fl_count;
	}
	public void setFl_count(int fl_count) {
		this.fl_count = fl_count;
	}
	public int getAes_count() {
		return aes_count;
	}
	public void setAes_count(int aes_count) {
		this.aes_count = aes_count;
	}
	public int getIstm_count() {
		return istm_count;
	}
	public void setIstm_count(int istm_count) {
		this.istm_count = istm_count;
	}
	
	public String getDownloadStatus() {
		return downloadStatus;
	}
	public void setDownloadStatus(String downloadStatus) {
		this.downloadStatus = downloadStatus;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getTransDate() {
		return transDate;
	}
	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}
	public String getChequeNo() {
		return chequeNo;
	}
	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}
	public String getUtrNo() {
		return utrNo;
	}
	public void setUtrNo(String utrNo) {
		this.utrNo = utrNo;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public String getBillRefResets() {
		return billRefResets;
	}
	public void setBillRefResets(String billRefResets) {
		this.billRefResets = billRefResets;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getTransferType() {
		return transferType;
	}
	public void setTransferType(String transferType) {
		this.transferType = transferType;
	}
	public String getAnnotation() {
		return annotation;
	}
	public void setAnnotation(String annotation) {
		this.annotation = annotation;
	}
	
	public String getOrigTrackingId() {
		return origTrackingId;
	}
	public void setOrigTrackingId(String origTrackingId) {
		this.origTrackingId = origTrackingId;
	}
	public String getOrigTrackingIdServ() {
		return origTrackingIdServ;
	}
	public void setOrigTrackingIdServ(String origTrackingIdServ) {
		this.origTrackingIdServ = origTrackingIdServ;
	}
	public String getOrigTrackingTotalAmount() {
		return origTrackingTotalAmount;
	}
	public void setOrigTrackingTotalAmount(String origTrackingTotalAmount) {
		this.origTrackingTotalAmount = origTrackingTotalAmount;
	}
	
	public String getOrigStatus() {
		return origStatus;
	}
	public void setOrigStatus(String origStatus) {
		this.origStatus = origStatus;
	}
	/*public List<String> getCheckedPTList() {
		return checkedPTList;
	}
	public void setCheckedPTList(List<String> checkedPTList) {
		this.checkedPTList = checkedPTList;
	}*/
	
	
	public List<String> getCheckedRemarkList() {
		return checkedRemarkList;
	}
	
	public void setCheckedRemarkList(List<String> checkedRemarkList) {
		this.checkedRemarkList = checkedRemarkList;
	}
	
	
	/*public Map<String, String> getOrigTrackingMap() {
		return origTrackingMap;
	}
	public void setOrigTrackingMap(Map<String, String> origTrackingMap) {
		this.origTrackingMap = origTrackingMap;
	}*/
	
	public List<String> getCheckedPTList() {
		return checkedPTList;
	}
	public void setCheckedPTList(List<String> checkedPTList) {
		this.checkedPTList = checkedPTList;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCheckBoxEnable() {
		return checkBoxEnable;
	}
	public void setCheckBoxEnable(String checkBoxEnable) {
		this.checkBoxEnable = checkBoxEnable;
	}
	
	public String getCadReceivedDate() {
		return cadReceivedDate;
	}
	public void setCadReceivedDate(String cadReceivedDate) {
		this.cadReceivedDate = cadReceivedDate;
	}
	public String getOrigTrackingString() {
		return origTrackingString;
	}
	public void setOrigTrackingString(String origTrackingString) {
		this.origTrackingString = origTrackingString;
	}
	
	public String getPayMode() {
		return payMode;
	}
	public void setPayMode(String payMode) {
		this.payMode = payMode;
	}
	public String getRejectReasonDropDown() {
		return rejectReasonDropDown;
	}
	public void setRejectReasonDropDown(String rejectReasonDropDown) {
		this.rejectReasonDropDown = rejectReasonDropDown;
	}
	public String getRejectReason() {
		return rejectReason;
	}
	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}
	public String getB2b2c() {
		return b2b2c;
	}
	public void setB2b2c(String b2b2c) {
		this.b2b2c = b2b2c;
	}	
	
	
			
	/*public String getSearchUtrNo() {
		return searchUtrNo;
	}
	public void setSearchUtrNo(String searchUtrNo) {
		this.searchUtrNo = searchUtrNo;
	}
	public String getSearchOrigTrackingId() {
		return searchOrigTrackingId;
	}
	public void setSearchOrigTrackingId(String searchOrigTrackingId) {
		this.searchOrigTrackingId = searchOrigTrackingId;
	}
	public String getSearchOrigTrackingIdServ() {
		return searchOrigTrackingIdServ;
	}
	public void setSearchOrigTrackingIdServ(String searchOrigTrackingIdServ) {
		this.searchOrigTrackingIdServ = searchOrigTrackingIdServ;
	}	*/	
	
	
	
}
