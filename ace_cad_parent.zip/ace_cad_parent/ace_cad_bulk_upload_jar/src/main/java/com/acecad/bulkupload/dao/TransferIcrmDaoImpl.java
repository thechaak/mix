package com.acecad.bulkupload.dao;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.jms.JMSException;
import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.acecad.airtel.eai.integration.model.Request_ResponseXMLDetails;
import com.acecad.airtel.eai.integration.msg.ECCEAIAccountDetailsIntegration;
import com.acecad.bulkupload.model.TransferIcrmDetails;


public class TransferIcrmDaoImpl implements TransferIcrmDao {

	private static Logger transferICRMLogger =LogManager.getLogger("transferICRMLogger");
	private DataSource dataSource;
	Connection conn = null;
	ResultSet resultset = null;

public TransferIcrmDaoImpl(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
public TransferIcrmDaoImpl() {
	// TODO Auto-generated constructor stub
}

public int getRole(String parentUser) {
		int Role = 0;
		try {
			transferICRMLogger.info(" Entered Get Role method at TransferIcrmDaoImpl");
			/*//transferICRMLogger.info("entered getRole method ");
			//transferICRMLogger.info("connection" + dataSource.getConnection());*/
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			/*//transferICRMLogger.info("connection established");*/
			String functionCall = "{? = call GETUSERROLE(?)}";
			
			CallableStatement callableStatement=conn.prepareCall(functionCall);
			
			callableStatement.registerOutParameter(1,Types.INTEGER);
			callableStatement.setString(2,parentUser);
			callableStatement.execute();
			
			 Role=callableStatement.getInt(1);
			 
				transferICRMLogger.info(" Role in Get Role method at TransferIcrmDaoImpl:"+Role);
		}
		
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			transferICRMLogger.error(errors);	
			return -1;
		}
		return Role;
	}

/*public List<String> CrmPayModeDropdown() 
{
	
	List<String> crmPayModeList=new ArrayList<String>();
	
	try 
	{
		//transferICRMLogger.info("ENTERED PAY MODE DROP DOWN @ LIURecordsDaoIMPL");

		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		conn = jdbcTemplate.getDataSource().getConnection();

		final String procedureCall = "{call ACE_CAD_BULK_PAYMENT.ACE_CAD_LIU_DROP_DOWN_PAY_MODE(?,?,?)}";

		CallableStatement callableStatement = conn.prepareCall(procedureCall);
		callableStatement.registerOutParameter(1, OracleTypes.CURSOR);
		callableStatement.registerOutParameter(2, OracleTypes.VARCHAR);
		callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
		callableStatement.executeUpdate();
	
	      String errorMsgCrmPayMode=callableStatement.getString(3);
	      //transferICRMLogger.info("ERROR MESSAGE @ LIUDAOIMPL IN PAY MODE DROP DOWN"+errorMsgCrmPayMode);
		  
		
		ResultSet crmPayModeResultSet=(ResultSet) callableStatement.getObject(1);
		
		if (crmPayModeResultSet == null) 
        {
			//transferICRMLogger.info("DB IS RETURNING NULL VALUES");
		}
		else
		{
	    while(crmPayModeResultSet.next())
	     {
	    	crmPayModeList.add(crmPayModeResultSet.getString(1));
		    //transferICRMLogger.info("LIU PAYMODE LIST @ IMPL:"+crmPayModeList);
	     }
		}
}catch (Exception e) {
	e.printStackTrace();
}
finally{
	try {
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	}
}
	return crmPayModeList ;
}*/
	@Override
	public HashMap<Integer, List<TransferIcrmDetails>> getTransferIcrmDetailsMap(TransferIcrmDetails TransferIcrmDetailsObj,
			int page) {
		   HashMap<Integer, List<TransferIcrmDetails>> TransferIcrmDetailsMap = new HashMap<Integer, List<TransferIcrmDetails>>();
			List<TransferIcrmDetails> DetailsList = new ArrayList<TransferIcrmDetails>();
			ResultSet resultset=null;
			CallableStatement callableStatement=null;
			transferICRMLogger.info(" Entered getTransferIcrmDetailsMap method at TransferIcrmDaoImpl");
			
			//transferICRMLogger.info("page number in dao:"+page);
		
			try {
				//transferICRMLogger.info("entered method in daoimpl");
				//transferICRMLogger.info("connection:" + dataSource.getConnection());
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				conn = jdbcTemplate.getDataSource().getConnection();
				//transferICRMLogger.info("connection established");
                final String procedureCall = "{call TRANSFER_CRM_DETAILS_RETRIEVAL(?,?,?,?,?)}";

				 callableStatement = conn
						.prepareCall(procedureCall);

				callableStatement.setInt(1,page);
				callableStatement.registerOutParameter(2,Types.INTEGER);
				callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
			    callableStatement.registerOutParameter(4, Types.VARCHAR);
				callableStatement.registerOutParameter(5, Types.VARCHAR);
				callableStatement.executeUpdate();
				
				//transferICRMLogger.info("callable statements executed");
				int totalPages = callableStatement.getInt(2);
				//transferICRMLogger.info("totalpages got from proc:" + totalPages);
				
				resultset=(ResultSet) callableStatement.getObject(3);
				TransferIcrmDetailsObj.setErrMsg(callableStatement.getString(4));
				
				transferICRMLogger.info("Error Msg in getTransferIcrmDetailsMap method at TransferIcrmDaoImpl:"+TransferIcrmDetailsObj.getErrMsg());

	           
				
	if(resultset==null)
	{
		transferICRMLogger.info("Result set is NULL in getTransferIcrmDetailsMap method at TransferIcrmDaoImpl");
		
	}
	else
	{
                 while (resultset!=null &&resultset.next()) {
						
						TransferIcrmDetails TransferIcrmDetailsObject = new TransferIcrmDetails();
						TransferIcrmDetailsObject.setSrNumber(resultset.getString("SR_NUMBER"));
						TransferIcrmDetailsObject.setSourceAccountNumber(resultset.getString("SOURCE_ACCOUNT_NUMBER"));
						TransferIcrmDetailsObject.setDestinationAccountNumber(resultset.getString("DESTINATION_ACCOUNT_NUMBER"));
						
						
						TransferIcrmDetailsObject.setBillDate(resultset.getString("BILL_DATE"));
						TransferIcrmDetailsObject.setAmount(resultset.getString("AMOUNT"));
						TransferIcrmDetailsObject.setReasonForTransfer(resultset.getString("REASON_FOR_TRANSFER"));
						TransferIcrmDetailsObject.setRefNumber(resultset.getString("REF_NUMBER"));
						TransferIcrmDetailsObject.setChequeDate(resultset.getString("CHQ_DATE_BANK_NAME"));			
						TransferIcrmDetailsObject.setPayMode(resultset.getString("PAYMENT_MODE"));
						TransferIcrmDetailsObject.setRecordStatus(resultset.getString("RECORD_STATUS"));
						//TransferIcrmDetailsObject.setSrCreatedTime(resultset.getString("SR_CREATED_TIME"));
						String date = resultset.getString("SR_CREATED_TIME");
						SimpleDateFormat dateString = new SimpleDateFormat(
								"yyyy-MM-dd HH:mm:ss");
						Date date1 = dateString.parse(date);
						SimpleDateFormat dateString1 = new SimpleDateFormat(
								"dd/MM/yyyy HH:mm:ss");
						String finalDate = dateString1.format(date1);

						TransferIcrmDetailsObject.setSrCreatedTime(finalDate);
						
						
			            DetailsList.add(TransferIcrmDetailsObject);
				}
	}
	
	transferICRMLogger.info("Size of DetailsList in getTransferIcrmDetailsMap method at TransferIcrmDaoImpl:"+DetailsList.size());
				
                TransferIcrmDetailsMap.put(totalPages, DetailsList);
			}
			catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				transferICRMLogger.error(errors);
				return null;
			}
			catch (Exception e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				transferICRMLogger.error(errors);
				return null;
			}
			finally {
				if(resultset!=null){
			     	   try {
			     		  resultset.close();
						} catch (Exception e) {
							StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							transferICRMLogger.error(errors);					}
			     	   }
				
				if(callableStatement!=null){
			     	   try {
			     		  callableStatement.close();
						} catch (Exception e) {
							StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							transferICRMLogger.error(errors);					}
			     	   }
						
			    	   if(conn!=null){
			         	   try {
			    				conn.close();
			    			} catch (Exception e) {
			    				StringWriter errors= new StringWriter();
			    				e.printStackTrace(new PrintWriter(errors));
			    				transferICRMLogger.error(errors);		    			}
			         
			         	   }
			}
			transferICRMLogger.info("Executed getTransferIcrmDetailsMap method at TransferIcrmDaoImpl");

			return TransferIcrmDetailsMap;

		}

	@Override
	public List<TransferIcrmDetails> getTransferIcrmExcelList(
			TransferIcrmDetails transferIcrmDetailsObj, String pageNum) {
		List<TransferIcrmDetails> DetailsList = new ArrayList<TransferIcrmDetails>();
		ResultSet resultset=null;
		CallableStatement callableStatement =null;
		transferICRMLogger.info(" Entered getTransferIcrmExcelList method at TransferIcrmDaoImpl");
		
	
		try {
			
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			
            final String procedureCall = "{call TRANSFER_CRM_DETAILS_RETRIEVAL(?,?,?,?,?)}";

			callableStatement = conn
					.prepareCall(procedureCall);

			callableStatement.setString(1,pageNum);
			callableStatement.registerOutParameter(2,Types.INTEGER);
			callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
		    callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.registerOutParameter(5, Types.VARCHAR);
			callableStatement.executeUpdate();
			
			
			int totalPages = callableStatement.getInt(2);
		
			
			resultset=(ResultSet) callableStatement.getObject(3);
			transferIcrmDetailsObj.setErrMsg(callableStatement.getString(4));
			transferICRMLogger.info("Error Msg in getTransferIcrmExcelList method at TransferIcrmDaoImpl:"+transferIcrmDetailsObj.getErrMsg());

        
			
if(resultset==null)
{
	transferICRMLogger.info("Result set is NULL in getTransferIcrmExcelList method at TransferIcrmDaoImpl");
	
}
else
{
             while (resultset!=null &&resultset.next()) {
					
					TransferIcrmDetails TransferIcrmDetailsObject = new TransferIcrmDetails();
					TransferIcrmDetailsObject.setSrNumber(resultset.getString("SR_NUMBER"));
					TransferIcrmDetailsObject.setSourceAccountNumber(resultset.getString("SOURCE_ACCOUNT_NUMBER"));
					TransferIcrmDetailsObject.setDestinationAccountNumber(resultset.getString("DESTINATION_ACCOUNT_NUMBER"));
					TransferIcrmDetailsObject.setBillDate(resultset.getString("BILL_DATE"));
					TransferIcrmDetailsObject.setAmount(resultset.getString("AMOUNT"));
					TransferIcrmDetailsObject.setReasonForTransfer(resultset.getString("REASON_FOR_TRANSFER"));
					TransferIcrmDetailsObject.setRefNumber(resultset.getString("REF_NUMBER"));
					TransferIcrmDetailsObject.setChequeDate(resultset.getString("CHQ_DATE_BANK_NAME"));			
					TransferIcrmDetailsObject.setPayMode(resultset.getString("PAYMENT_MODE"));
					TransferIcrmDetailsObject.setRecordStatus(resultset.getString("RECORD_STATUS"));
					String date = resultset.getString("SR_CREATED_TIME");
					SimpleDateFormat dateString = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					Date date1 = dateString.parse(date);
					SimpleDateFormat dateString1 = new SimpleDateFormat(
							"dd/MM/yyyy HH:mm:ss");
					String finalDate = dateString1.format(date1);

					
					//testing
					TransferIcrmDetailsObject.setSrCreatedTime(finalDate);
					
					
		            DetailsList.add(TransferIcrmDetailsObject);
					
					
		           
			}
}
transferICRMLogger.info("Size of DetailsList in getTransferIcrmExcelList method at TransferIcrmDaoImpl:"+DetailsList.size());

			
		}
		 catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				transferICRMLogger.error(errors);
				return null;
			}
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			transferICRMLogger.error(errors);
			return null;
		}
		finally {
			if(resultset!=null){
		     	   try {
		     		  resultset.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						transferICRMLogger.error(errors);					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						transferICRMLogger.error(errors);					}
		     	   }
					
		    	   if(conn!=null){
		         	   try {
		    				conn.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				transferICRMLogger.error(errors);		    			}
		         
		         	   }
		}
		transferICRMLogger.info("Executed getTransferIcrmExcelList method at TransferIcrmDaoImpl");

		return DetailsList;

	}

	@Override
	public List<TransferIcrmDetails> modifiedCrmDetails(List<TransferIcrmDetails> modifiedAccountsRecords,String userId,String sessionId,String action,int pageNumber) {
		final String procedureCall = "{call TRANSFER_ICRM_B2B_B2C_SEG_PROC(?,?,?,?,?)}";
		Connection connection = null;
		List<TransferIcrmDetails> crmRecordsListUpdated=new ArrayList<TransferIcrmDetails>();
	  ResultSet transfercrmdetails=null;
	  CallableStatement callableStatement=null;
	  transferICRMLogger.info(" Entered modifiedCrmDetails method at TransferIcrmDaoImpl");
		try {
             
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			  StructDescriptor structDescriptor = StructDescriptor.createDescriptor("TRANSFER_CRM_POSTING_OBJ", connection);

		        STRUCT[] structs = new STRUCT[modifiedAccountsRecords.size()];
		        for (int index = 0; index < modifiedAccountsRecords.size(); index++)
		        {
		        	TransferIcrmDetails modifiedRecordsObj = modifiedAccountsRecords.get(index);
		            Object[] params = new Object[42];

		            params[0] = modifiedRecordsObj.getSrNumber();
		            transferICRMLogger.info(" SR NUMBER 0:"+modifiedRecordsObj.getSrNumber());
		            
	 	            params[1] = modifiedRecordsObj.getSourceAccountNumber();
	 	           transferICRMLogger.info("SRC ACC NUM 1:"+modifiedRecordsObj.getSourceAccountNumber());
		            
	 	            params[2] = modifiedRecordsObj.getDestinationAccountNumber();
	 	           transferICRMLogger.info(" DES ACC NUM 2:"+modifiedRecordsObj.getDestinationAccountNumber());
	 	          SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
	 	         /* String startDate=modifiedRecordsObj.getChequeDate();
	 	        
	 	         java.util.Date date = sdf1.parse(startDate);
	 	         java.sql.Date sqlStartDate = new Date(date.getTime()); 
	 	           
	 	           
	 	           
	 	           
	 	           
	 	          DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
	 	          java.util.Date d1=  df.parse(modifiedRecordsObj.getChequeDate());
	 	          java.sql.Date sqlDate = new java.sql.Date(d1.getDate());
	 	          //transferICRMLogger.info("date in passing..."+sqlStartDate);
	 	          params[3] = sqlStartDate;
	 	           //transferICRMLogger.info("CHEQUE DATE 3:"+modifiedRecordsObj.getChequeDate());*/
	 	         params[3] = modifiedRecordsObj.getChequeDate();
	 	        transferICRMLogger.info("CHEQUE DATE 3:"+modifiedRecordsObj.getChequeDate());
	 	          params[4] = modifiedRecordsObj.getReasonForTransfer();
	 	           transferICRMLogger.info("REASON FOR TRANSFER 4:"+modifiedRecordsObj.getReasonForTransfer());
	 	          params[5] = modifiedRecordsObj.getAmount();
  	               transferICRMLogger.info(" AMOUNT 5:"+modifiedRecordsObj.getAmount());
  	            // DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
  	           /*  String startDate1=modifiedRecordsObj.getBillDate();
 	 	        
	 	         java.util.Date date1 = sdf1.parse(startDate1);
	 	         java.sql.Date sqlStartDate1 = new Date(date1.getTime());
  	             
	 	         transferICRMLogger.info("bill date in passing..."+sqlStartDate1);*/
  	             params[6] = modifiedRecordsObj.getSrCreatedTime();;
	 	          transferICRMLogger.info("Sr created time 6:"+modifiedRecordsObj.getSrCreatedTime());
  	             params[7] = modifiedRecordsObj.getPayMode();
	 	           transferICRMLogger.info("PAYMENT MODE 7:"+modifiedRecordsObj.getPayMode());

	 	            params[8] = modifiedRecordsObj.getRefNumber();
	 	           transferICRMLogger.info("REF NUMBER 8:"+modifiedRecordsObj.getRefNumber());
	 	          ArrayDescriptor des = ArrayDescriptor.createDescriptor("ARRAY_FILEID_TABLE", connection); 
	 				Object[] array=modifiedRecordsObj.getTrackingIdList().toArray();
	 		        
	 		         ARRAY array_to_pass = new ARRAY(des,connection,array);
	 	          params[9] = array_to_pass;
		            transferICRMLogger.info("TRACKING ID 9:"+modifiedRecordsObj.getTrackingIdList());
		            params[10] = modifiedRecordsObj.getTrackingIdServ();  
		            transferICRMLogger.info("TRACKING ID SERV 10:"+modifiedRecordsObj.getTrackingIdServ());
		            params[11] = modifiedRecordsObj.getErrorReasonCode();
		            transferICRMLogger.info("ERROR REASON CODE 11:"+modifiedRecordsObj.getErrorReasonCode());

	 	            params[12] = modifiedRecordsObj.getTransferPayMode();
	 	           transferICRMLogger.info("TRANSFER PAY MODE 12:"+modifiedRecordsObj.getTransferPayMode());

		           
	 	          params[13] = modifiedRecordsObj.getInvoice();
	 	           transferICRMLogger.info("INVOICE 13:"+modifiedRecordsObj.getInvoice());
		            
	 	          params[14] = modifiedRecordsObj.getRemitterBranch();
	 	           transferICRMLogger.info("REMITTER BRANCH 14:"+modifiedRecordsObj.getRemitterBranch());
	 	           
	 	           
	 	          params[15] = modifiedRecordsObj.getAccountType();
	 	           transferICRMLogger.info("ACCOUNT TYPE 15:"+modifiedRecordsObj.getAccountType());
	 	         

	 	            params[16] = modifiedRecordsObj.getSrcLob();
		            transferICRMLogger.info("source lob 16:"+modifiedRecordsObj.getSrcLob());
		            
		            params[17] = modifiedRecordsObj.getDesLob();
		            transferICRMLogger.info("desc lob 17:"+modifiedRecordsObj.getDesLob());
		            
		            params[18] = modifiedRecordsObj.getSrcLegalEntity();
		            transferICRMLogger.info("SOURCE LEGAL ENTITY 18:"+modifiedRecordsObj.getSrcLegalEntity());
		            params[19] = modifiedRecordsObj.getFxLegalEntity();
		            transferICRMLogger.info("DESTINATION LEGAL ENTITY 19:"+modifiedRecordsObj.getFxLegalEntity());
		             params[20] = modifiedRecordsObj.getFxValueType();
		            transferICRMLogger.info("FX VALUE TYPE 20:"+modifiedRecordsObj.getFxValueType());

	 	            params[21] = modifiedRecordsObj.getFxVIPFlag();
		            transferICRMLogger.info("FX VIP FLAG 21:"+modifiedRecordsObj.getFxVIPFlag());

	 	            params[22] = modifiedRecordsObj.getFxCustomerType();
		            transferICRMLogger.info("FX CUSTOMER TYPE 22:"+modifiedRecordsObj.getFxCustomerType());
	 	            
	 	            params[23] = modifiedRecordsObj.getFxCustomerClass();
		            transferICRMLogger.info("CUSTOMER CLASS 23:"+modifiedRecordsObj.getFxCustomerClass());
		            
		            params[24] = modifiedRecordsObj.getCustomerName();
		            transferICRMLogger.info("CUSTOMER NAME 24:"+modifiedRecordsObj.getCustomerName());
		            params[25] = modifiedRecordsObj.getDerivedB2bB2c();
		            transferICRMLogger.info("DERIVED B2B B2C 25:"+modifiedRecordsObj.getDerivedB2bB2c());
		            params[26] = modifiedRecordsObj.getSrcPaymentCode();
		            transferICRMLogger.info(" SRC PAYMENT CODE 26:"+modifiedRecordsObj.getSrcPaymentCode());
		            
		            params[27] = modifiedRecordsObj.getDesPaymentCode();
		            transferICRMLogger.info("DES PAYMENT CODE 27:"+modifiedRecordsObj.getDesPaymentCode());
		           
		            params[28] = modifiedRecordsObj.getFxInternalAcctNum();
		            transferICRMLogger.info("FX INTERNAL ACC NUMBER 28:"+modifiedRecordsObj.getFxInternalAcctNum());
		            params[29] = modifiedRecordsObj.getSrcCurrency();
		            transferICRMLogger.info(" SRC CURRENCY 29:"+modifiedRecordsObj.getSrcCurrency());
		            
		            params[30] = modifiedRecordsObj.getDesCurrency();
		            transferICRMLogger.info("DES CURRENCY 30:"+modifiedRecordsObj.getDesCurrency());
		            params[31] = modifiedRecordsObj.getSessionId();
		            transferICRMLogger.info("SESSION ID 31:"+modifiedRecordsObj.getSessionId());
		            params[32] = userId;
		            transferICRMLogger.info("USER ID 32:"+userId);
		            params[33] = modifiedRecordsObj.getRemarks();
		            transferICRMLogger.info("REMARKS 33:"+modifiedRecordsObj.getRemarks());
		            params[34] = modifiedRecordsObj.getRecordId();
		            transferICRMLogger.info("RECORD ID 34:"+modifiedRecordsObj.getRecordId());
		            params[35] = modifiedRecordsObj.getRecordType();
		            transferICRMLogger.info("RECORD TYPE 35:"+modifiedRecordsObj.getRecordType());
		            params[36] = modifiedRecordsObj.getBillRefAssests();
		            transferICRMLogger.info("BILL REF ASSESTS 36:"+modifiedRecordsObj.getBillRefAssests());
		            params[37] = modifiedRecordsObj.getAnnotation();
		            transferICRMLogger.info("ANNAOTATION 37:"+modifiedRecordsObj.getAnnotation());
		            params[38] = modifiedRecordsObj.getBillCompany();
		            transferICRMLogger.info("BILL COMPANY 38:"+modifiedRecordsObj.getBillCompany());
		            params[39] = modifiedRecordsObj.getMarketCode();
		            transferICRMLogger.info("MARKET CODE 39:"+modifiedRecordsObj.getMarketCode());
		            params[40] = modifiedRecordsObj.getSrStatus();
		            transferICRMLogger.info("SR STATUS 40:"+modifiedRecordsObj.getSrStatus());
		            params[41] = modifiedRecordsObj.getBillDate();
		            transferICRMLogger.info("Bill Date 41:"+modifiedRecordsObj.getBillDate());
		            
		            
		           
		            
		         transferICRMLogger.info("Input values to Proc in modifiedCrmDetails method at TransferIcrmDaoImpl::");
		            for(int i=0;i<params.length;i++)
		            {
	 	            
	 	           transferICRMLogger.info(i+":"+params[i]+" ,");
		            }
		            
		            STRUCT struct = new STRUCT(structDescriptor, connection, params);
		          
		            structs[index] = struct;
		        }
		        transferICRMLogger.info("Length of struct in modifiedCrmDetails method at TransferIcrmDaoImpl::"+structs.length);
		        
		        ArrayDescriptor desc = ArrayDescriptor.createDescriptor("TRANSFER_CRM_POSTING_TYPE",connection);
		        
		        ARRAY oracleArray = new ARRAY(desc, connection, structs);


			 callableStatement = connection.prepareCall(procedureCall);
			callableStatement.setArray(1, oracleArray);
		//	callableStatement.setString(1,action);
			callableStatement.setString(2,userId);
		//	callableStatement.setString(3,sessionId);	
			
			callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.registerOutParameter(5, Types.VARCHAR);
			
			callableStatement.executeUpdate(); 
			transfercrmdetails=(ResultSet) callableStatement.getObject(3);
			
			if(transfercrmdetails!=null)
			{
			while(transfercrmdetails.next())
			{
				TransferIcrmDetails transferObj=new TransferIcrmDetails();
				transferObj.setSrNumber(transfercrmdetails.getString("SR_NO"));
				transferObj.setRemarks(transfercrmdetails.getString("ERROR_REASON_CODE"));
				crmRecordsListUpdated.add(transferObj);
			//	transferObj.setStatus(transfercrmdetails.getString(""));
				transferICRMLogger.info("Remarks"+transferObj.getRemarks());
				
			}
			}
			
			transferICRMLogger.info("Size of crmRecordsListUpdated in getTransferIcrmDetailsMap method at TransferIcrmDaoImpl:"+crmRecordsListUpdated.size());

			
			 String errorMsg=callableStatement.getString(4);
			 String errorCode=callableStatement.getString(5);
			 

			 transferICRMLogger.info("Error Msg in modifiedCrmDetails method at TransferIcrmDaoImpl:"+errorMsg);
			 transferICRMLogger.info("Error Code in modifiedCrmDetails method at TransferIcrmDaoImpl:"+errorCode);
			 //transferICRMLogger.info("ERROR CODE:"+errorCode );

	            //transferICRMLogger.info("SESSION ID:"+sessionId);
	            
	          /*  ResultSet modifiedResulSetArray=(ResultSet) callableStatement.getObject(5);
				
				if (modifiedResulSetArray == null) 
		        {
					//transferICRMLogger.info("DB RETURNING NULL VALUES");
				}
				
				else
				{
					
				   while (modifiedResulSetArray.next())
				   {
					   TransferIcrmDetails modifiedLIUDetailsObj = new TransferIcrmDetails();

					   modifiedLIUDetailsObj.setSrNumber(resultset.getString("SR_NUMBER"));
					   modifiedLIUDetailsObj.setSourceAccountNumber(resultset.getString("SOURCE_ACCOUNT_NUMBER"));
					   modifiedLIUDetailsObj.setDestinationAccountNumber(resultset.getString("DESTINATION_ACCOUNT_NUMBER"));
					   modifiedLIUDetailsObj.setBillDate(resultset.getString("BILL_DATE"));
					   modifiedLIUDetailsObj.setAmount(resultset.getString("AMOUNT"));
					   modifiedLIUDetailsObj.setReasonForTransfer(resultset.getString("REASON_FOR_TRANSFER"));
					   modifiedLIUDetailsObj.setRefNumber(resultset.getString("REF_NUMBER"));
					   modifiedLIUDetailsObj.setChequeDate(resultset.getString("CHEQUE_DATE"));			
					   modifiedLIUDetailsObj.setPayMode(resultset.getString("PAYMENT_MODE"));
					   modifiedLIUDetailsObj.setRecordStatus(resultset.getString("RECORD_STATUS"));
					   modifiedLIUDetailsObj.setTrackingId(resultset.getString("TRACKING_ID"));
					   modifiedLIUDetailsObj.setTrackingIdServ(resultset.getString("TRACKING_ID_SERV"));
					   modifiedLIUDetailsObj.setRemarks(resultset.getString("REMARKS"));
					   
					   
					   
					   //transferICRMLogger.info("REMARKS AT IMPL:"+resultset.getString("REMARKS"));
					   //transferICRMLogger.info(" TRACKING ID at IMPL:"+resultset.getString("TRACKING_ID"));
					   //transferICRMLogger.info("Sr number:"+resultset.getString("SR_NUMBER"));
					 
					   
		            modifiedLIUDetailsObj.setErrMsg(errorMsg);
		          
					
		            crmRecordsListUpdated.add(modifiedLIUDetailsObj);
						
				}
			}*/
				//transferICRMLogger.info("EXECUTED MODIFIED CRM DETAILS PROC @LIUDAOIMPL");
		          
			
		} catch (SQLException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			transferICRMLogger.error(errors);	
			return null;
		}
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			transferICRMLogger.error(errors);	
			return null;

		}finally {
			if(transfercrmdetails!=null){
		     	   try {
		     		  transfercrmdetails.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						transferICRMLogger.error(errors);					}
		     	   }
			
			if(callableStatement!=null){
		     	   try {
		     		  callableStatement.close();
					} catch (Exception e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						transferICRMLogger.error(errors);					}
		     	   }
					
		    	   if(connection!=null){
		         	   try {
		         		  connection.close();
		    			} catch (Exception e) {
		    				StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				transferICRMLogger.error(errors);		    			}
		         
		         	   }
		}
		
		transferICRMLogger.info("Executed modifiedCrmDetails method at TransferIcrmDaoImpl");

		return crmRecordsListUpdated;
	}

	@Override
	public TransferIcrmDetails validationsFromFX(TransferIcrmDetails crmInputFxObj) {

		TransferIcrmDetails crmOutputFxObj=new TransferIcrmDetails();
		Double sum=0.0;
	      //List<com.acecad.airtel.eai.integration.model.Invoice> invoiceList=null;
		try{
		  
			transferICRMLogger.info(" Entered validationsFromFX method at TransferIcrmDaoImpl");

		  String invoice=null;
		  Request_ResponseXMLDetails Request_ResponseXMLDetails=new Request_ResponseXMLDetails();
		  ECCEAIAccountDetailsIntegration ECCEAIAccountDetailsIntegration=new ECCEAIAccountDetailsIntegration();

		 //transferICRMLogger.info("ACCOUNT NUMBER:"+crmOutputFxObj.getAccountExtID());
		  //transferICRMLogger.info("INVOICE INPUT:"+crmOutputFxObj.getInvoiceNumber());
		  //transferICRMLogger.info("PAYMENT CURRENCY INPUT:"+crmOutputFxObj.getPayment_currency());
		
		  // ****************************EAI INTEGRATION CODE for Source account**************************************
		  
			//transferICRMLogger.info("IN LOB EAI CALL @ CONTROLLER");
		  transferICRMLogger.info("In EAI call");
		 
				Request_ResponseXMLDetails.setAccountExternalId(crmInputFxObj.getSourceAccountNumber());
				//Request_ResponseXMLDetails.setTrackingID(crmOutputFxObj.getTrackingId());
				Request_ResponseXMLDetails.setXMLFileName("LOB_FIND");
				
				
				try {
					Request_ResponseXMLDetails=ECCEAIAccountDetailsIntegration.eaiCall(Request_ResponseXMLDetails);
				} catch (JMSException e) {
					// TODO Auto-generated catch block
					crmInputFxObj.setErrorReasonCode("Failed: Connectivity Issue..RETRY");
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					transferICRMLogger.error(errors);
					return crmInputFxObj;
					
				}
				
				
				if(Request_ResponseXMLDetails.getErrorMessage()==null||Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("0"))
				{
					transferICRMLogger.info("ENTERED LOB CALL");
					crmInputFxObj.setSrcLob(Request_ResponseXMLDetails.getLOB());
					//liuInputFxObj.setAccountExtID(Request_ResponseXMLDetails.getAccountExternalId());
					transferICRMLogger.info("FINISHED LOB CALL");

				}
				else if(Request_ResponseXMLDetails.getErrorMessage()!=null||!(Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("0")))
				{
					if(Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("BEAI50050E")||Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("EAI_FAILURE")||Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("EAI_NO_RESPONSE"))
					{
						crmInputFxObj.setErrorReasonCode("Failed: Connectivity Issue..RETRY");
							return crmInputFxObj;
					}
					if(Request_ResponseXMLDetails.getServ_ID()!=null)
					{
						if(Request_ResponseXMLDetails.getServ_ID().length()==0)
							Request_ResponseXMLDetails.setServ_ID(null);
					}
					if((Request_ResponseXMLDetails.getLOB()==null||Request_ResponseXMLDetails.getLOB().equalsIgnoreCase(""))&&(Request_ResponseXMLDetails.getServ_ID()!=null))
					{
						//TransferIcrmDaoImpl TransferIcrmDaoImplLObj=new TransferIcrmDaoImpl();
						String lob=getLobByServId(Request_ResponseXMLDetails.getServ_ID());
						if(lob==null)
						{
							crmInputFxObj.setErrorReasonCode("Failed: Invalid Source Account");
							return crmInputFxObj;
						}
							else
								crmInputFxObj.setSrcLob(lob);
					}
					else if((Request_ResponseXMLDetails.getLOB()==null||Request_ResponseXMLDetails.getLOB().equalsIgnoreCase(""))&&(Request_ResponseXMLDetails.getServ_ID()==null||Request_ResponseXMLDetails.getServ_ID().equalsIgnoreCase("")))
					{
						
						/*crmInputFxObj.setErrorReasonCode("Failed: Invalid Account");
						return crmInputFxObj;//After aes lob uncomment
*/					//bulkDetailsObj.setErrorCode("INVALID ACCOUNT");

						
						/*	liuInputFxObj.setRemarks("Failed: Invalid Account");
							return liuInputFxObj;//After aes lob uncomment
		*/			

							//bulkDetailsObj.setErrorCode("Invalid Account");
							
							
						Request_ResponseXMLDetails.setAccountExternalId(crmInputFxObj.getSourceAccountNumber());
							Request_ResponseXMLDetails.setLOB("AES");
						Request_ResponseXMLDetails.setXMLFileName("LOB_FIND");
						try {
							Request_ResponseXMLDetails=ECCEAIAccountDetailsIntegration.eaiCall(Request_ResponseXMLDetails);
						} catch (JMSException e) {
							// TODO Auto-generated catch block
							crmInputFxObj.setErrorReasonCode("Failed: Connectivity Issue..RETRY");
							StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							transferICRMLogger.error(errors);
							return crmInputFxObj;
						}
						if(Request_ResponseXMLDetails.getErrorMessage()==null||Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("0"))
						{
							crmInputFxObj.setSrcLob(Request_ResponseXMLDetails.getLOB());
						//	liuInputFxObj.setAccountExtID(Request_ResponseXMLDetails.getAccountExternalId());
					//	bulkDetailsObj.setServId(Request_ResponseXMLDetails.getServ_ID());
						}
						else
						{
							if(Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("BEAI50050E")||Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("EAI_FAILURE")||Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("EAI_NO_RESPONSE"))
							{
								crmInputFxObj.setErrorReasonCode("Failed: Connectivity Issue..RETRY");
									return crmInputFxObj;
							}
							crmInputFxObj.setErrorReasonCode("Failed: Invalid  Source Account");
							return crmInputFxObj;
							
						}
						
							//bulkDetailsObj.setErrorCode("INVALID ACCOUNT");
					
						
				
					}
					
					//liuInputFxObj.setRemarks("Failed: Invalid Account");
					//transferICRMLogger.info(liuInputFxObj.getRemarks());
					
					transferICRMLogger.info(Request_ResponseXMLDetails.getErrorMessage());
					transferICRMLogger.info("ERROR MESSAGE @ LOB FIND:"+Request_ResponseXMLDetails.getErrorMessage());
					
			}
			
				else 
				{
					crmInputFxObj.setErrorReasonCode("Failed: Connectivity Issue..RETRY..");
					transferICRMLogger.info(crmInputFxObj.getErrorReasonCode());
					
					//transferICRMLogger.info(Request_ResponseXMLDetails.getErrorMessage());
					//transferICRMLogger.info("ERROR MESSAGE @ LOB FIND:"+Request_ResponseXMLDetails.getErrorMessage());
					
					return crmInputFxObj;
				}
				
				
			//EAI CALL FOR PAYMENT FIND	
				
				
				
				if((Request_ResponseXMLDetails.getErrorMessage()==null||Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("0"))||(Request_ResponseXMLDetails.getLOB().trim()==null||Request_ResponseXMLDetails.getLOB().equalsIgnoreCase(""))&&(Request_ResponseXMLDetails.getServ_ID()!=null||!(Request_ResponseXMLDetails.getServ_ID().equalsIgnoreCase(""))))
				  {
					
					transferICRMLogger.info("ENTERED ACCOUNT EXTERNAL ID EAI CALL");
					for(int i=0;i<crmInputFxObj.getTrackingIdList().size();i++)
					{
				     
					Request_ResponseXMLDetails.setLOB(crmInputFxObj.getSrcLob());
						transferICRMLogger.info(" DETAILS FROM FX:"+Request_ResponseXMLDetails.getLOB());
				    
					Request_ResponseXMLDetails.setAccountExternalId(crmInputFxObj.getSourceAccountNumber());
						transferICRMLogger.info(" DETAILS FROM FX:"+Request_ResponseXMLDetails.getAccountExternalId());
						//Request_ResponseXMLDetails.setAccountExternalId(bulkDetailsObj.getAcctEXTID());
						
						Request_ResponseXMLDetails.setTrackingID(crmInputFxObj.getTrackingIdList().get(i));
						Request_ResponseXMLDetails.setTrackingIDServ(crmInputFxObj.getTrackingIdServ());
						//Request_ResponseXMLDetails.setLOB(crmInputFxObj.getSrcLob());
																		
						
						Request_ResponseXMLDetails.setXMLFileName("PAYMENT_FIND");
						try {
							Request_ResponseXMLDetails=ECCEAIAccountDetailsIntegration.eaiCall(Request_ResponseXMLDetails);
						} catch (JMSException e) {
							crmInputFxObj.setErrorReasonCode("Failed: Connectivity Issue..RETRY");
							StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							transferICRMLogger.error(errors);
							return crmInputFxObj;
						}
						

						if(Request_ResponseXMLDetails.getErrorMessage()==null||Request_ResponseXMLDetails.getErrorMessage().equals(""))
						{
							if(Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("EAI_FAILURE")||Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("EAI_NO_RESPONSE")||Request_ResponseXMLDetails.getErrorMessage().equalsIgnoreCase("TUX ERROR"))
							{
								crmInputFxObj.setErrorReasonCode("Failed: Connectivity Issue..RETRY");
							//	bulkDetailsObj.setRemarks(Request_ResponseXMLDetails.getErrorMessage());
								return crmInputFxObj;
							}
							if(Request_ResponseXMLDetails.getPaymentFindOutput().getPaymentTrackingIdCountDetails().getTotalCount().equalsIgnoreCase("0"))
							{
								crmInputFxObj.setErrorReasonCode("Invalid Tracking Id for Account Number");
								transferICRMLogger.info("remarks"+crmInputFxObj.getRemarks());
								//crmInputFxObj.setErrorReasonCode("Invalid Tracking Id for Account Number");
							}
							else if(Request_ResponseXMLDetails.getPaymentFindOutput().getPaymentTrackingIdCountDetails().getTotalCount().equalsIgnoreCase("1"))
							{
								//bulkDetailsObj.setFxStatus("SUCCESS");
																					
								
								if(Request_ResponseXMLDetails.getPaymentFindOutput().getPaymentList().getPaymentTrackingId().getDetails().get(0).getActionCode().trim().equalsIgnoreCase("APP"))
								{
									
									String amount=Request_ResponseXMLDetails.getPaymentFindOutput().getPaymentList().getPaymentTrackingId().getDetails().get(0).getTransAmount();
									 sum=sum+Double.parseDouble(amount)/100;
									 //transferICRMLogger.info("amount inside"+sum);
									//crmInputFxObj.setFxStatus("SUCCESS");
									 crmInputFxObj.setSrcCurrency(Request_ResponseXMLDetails.getPaymentFindOutput().getPaymentList().getPaymentTrackingId().getDetails().get(0).getCurrencyCode());
									//crmInputFxObj.setCustomerCurrency(Request_ResponseXMLDetails.getPaymentFindOutput().getPaymentList().getPaymentTrackingId().getDetails().get(0).getCurrencyCode());
									Request_ResponseXMLDetails.setLOB(crmInputFxObj.getSrcLob());
									Request_ResponseXMLDetails.setAccountExternalId(crmInputFxObj.getSourceAccountNumber());
									if(crmInputFxObj.getSrcLob().equalsIgnoreCase("AES"))
									{
										Request_ResponseXMLDetails.setXMLFileName("ACCOUNT_PROFILE_FIND");
										try {
											Request_ResponseXMLDetails=ECCEAIAccountDetailsIntegration.eaiCall(Request_ResponseXMLDetails);
										} catch (JMSException e) {
											crmInputFxObj.setErrorReasonCode("Failed: Connectivity Issue..RETRY");
											StringWriter errors= new StringWriter();
											e.printStackTrace(new PrintWriter(errors));
											transferICRMLogger.error(errors);
											return crmInputFxObj;
										}
										if(Request_ResponseXMLDetails.getErrorMessage()==null||Request_ResponseXMLDetails.getErrorMessage().equalsIgnoreCase(""))
										{
											crmInputFxObj.setSrcLegalEntity(Request_ResponseXMLDetails.getLegal_Entity());
										}
									}
								
								 
																						
								}
								else
								{
									crmInputFxObj.setErrorReasonCode("Invalid Tracking Id for Account Number");
									transferICRMLogger.info("Remarks in Account Profile Find:"+crmInputFxObj.getErrorReasonCode());
								//	bulkDetailsObj.setErrorCode("Invalid Tracking Id for Account Numbe");
								}	
							}
							else if(Request_ResponseXMLDetails.getPaymentFindOutput().getPaymentTrackingIdCountDetails().getTotalCount().equalsIgnoreCase("2"))
							{
								crmInputFxObj.setErrorReasonCode("Reversal Already Done");
								transferICRMLogger.info("Remarks in Account Profile Find:"+crmInputFxObj.getErrorReasonCode());
								//bulkDetailsObj.setErrorCode("Reversal already done");
								/*if(Request_ResponseXMLDetails.getPaymentFindOutput().getPaymentList().getPaymentTrackingId().getDetails().get(0).getActionCode().trim().equalsIgnoreCase("APP"))
								{
									if(Request_ResponseXMLDetails.getPaymentFindOutput().getPaymentList().getPaymentOrigTrackingId().get(0).getActionCode().trim().equalsIgnoreCase("REV"))
									{
										bulkDetailsObj.setFxStatus("REVERSAL ALREADY DONE");
										bulkDetailsObj.setErrorCode("Reversal already done");
									}
									
								}*/
								
							}
							else
							{
								crmInputFxObj.setErrorReasonCode("Invalid Tracking Id for Account Number");
								transferICRMLogger.info("Remarks in Account Profile Find:"+crmInputFxObj.getErrorReasonCode());
								//bulkDetailsObj.setErrorReasonCode(Request_ResponseXMLDetails.getErrorMessage());
							}
							
						}
						else
						{
							crmInputFxObj.setErrorReasonCode("Invalid Tracking Id for Account Number");
							transferICRMLogger.info("Remarks in Account Profile Find:"+crmInputFxObj.getErrorReasonCode());
							//bulkDetailsObj.setErrorReasonCode(Request_ResponseXMLDetails.getErrorMessage());
						}
					}
					crmInputFxObj.setFxAmount(Double.toString(sum));
					 transferICRMLogger.info("FX Amount:"+crmInputFxObj.getFxAmount());
					 //transferICRMLogger.info("amount outside"+crmInputFxObj.getAmount());
					 crmInputFxObj.setAmount(Double.toString(Double.parseDouble(crmInputFxObj.getAmount())));
					//if(crmInputFxObj.getRemarks().equalsIgnoreCase(null)||crmInputFxObj.getRemarks().equalsIgnoreCase(""))
					 if(crmInputFxObj.getErrorReasonCode()==null)
					if(!(crmInputFxObj.getFxAmount().equalsIgnoreCase(crmInputFxObj.getAmount())))
					{
						crmInputFxObj.setErrorReasonCode("Amount mismatch ");
						transferICRMLogger.info("Remarks:"+crmInputFxObj.getErrorReasonCode());
					}
				  }
					
			// ****************************EAI INTEGRATION CODE for destination account*****************************
				if(crmInputFxObj.getErrorReasonCode()==null ||crmInputFxObj.getErrorReasonCode().equalsIgnoreCase(""))
				{
					 Request_ResponseXMLDetails Request_ResponseXMLDetails1=new Request_ResponseXMLDetails();
					transferICRMLogger.info("IN EAI CALL for Destintion Account");
				 
					Request_ResponseXMLDetails1.setAccountExternalId(crmInputFxObj.getDestinationAccountNumber());
						//Request_ResponseXMLDetails.setTrackingID(crmOutputFxObj.getTrackingId());
					Request_ResponseXMLDetails1.setXMLFileName("LOB_FIND");
						
						
					try {
						Request_ResponseXMLDetails1=ECCEAIAccountDetailsIntegration.eaiCall(Request_ResponseXMLDetails1);
					} catch (JMSException e) {
						crmInputFxObj.setErrorReasonCode("Failed: Connectivity Issue..RETRY");
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						transferICRMLogger.error(errors);
						return crmInputFxObj;
					}
						
						
						if(Request_ResponseXMLDetails1.getErrorMessage()==null||Request_ResponseXMLDetails1.getErrorCode().equalsIgnoreCase("0"))
						{
							
							crmInputFxObj.setDesLob(Request_ResponseXMLDetails1.getLOB());
							crmInputFxObj.setDesServId(Request_ResponseXMLDetails1.getServ_ID());
							

						}
						else if(Request_ResponseXMLDetails1.getErrorMessage()!=null||!(Request_ResponseXMLDetails1.getErrorCode().equalsIgnoreCase("0")))
						{
							if(Request_ResponseXMLDetails1.getServ_ID()!=null)
							{
								if(Request_ResponseXMLDetails1.getServ_ID().length()==0)
									Request_ResponseXMLDetails1.setServ_ID(null);
							}
							if((Request_ResponseXMLDetails1.getLOB().trim()==null||Request_ResponseXMLDetails1.getLOB().equalsIgnoreCase(""))&&(Request_ResponseXMLDetails1.getServ_ID()!=null))
							{
							
								crmInputFxObj.setDesServId(Request_ResponseXMLDetails1.getServ_ID());
								String lob=getLobByServId(Request_ResponseXMLDetails1.getServ_ID());
								if(lob==null)
								{
									crmInputFxObj.setErrorReasonCode("Failed: Invalid Account");
									return crmInputFxObj;
								}
									else
										crmInputFxObj.setDesLob(lob);
							}
							else if((Request_ResponseXMLDetails1.getLOB()==null||Request_ResponseXMLDetails1.getLOB().equalsIgnoreCase(""))&&(Request_ResponseXMLDetails1.getServ_ID()==null||Request_ResponseXMLDetails1.getServ_ID().equalsIgnoreCase("")))
							{
								
					
									
								Request_ResponseXMLDetails1.setAccountExternalId(crmInputFxObj.getDestinationAccountNumber());
								Request_ResponseXMLDetails1.setLOB("AES");
								Request_ResponseXMLDetails1.setXMLFileName("LOB_FIND");
								try {
									Request_ResponseXMLDetails1=ECCEAIAccountDetailsIntegration.eaiCall(Request_ResponseXMLDetails1);
								} catch (JMSException e) {
									crmInputFxObj.setErrorReasonCode("Failed: Connectivity Issue..RETRY");
									StringWriter errors= new StringWriter();
									e.printStackTrace(new PrintWriter(errors));
									transferICRMLogger.error(errors);
									return crmInputFxObj;
								}
								if(Request_ResponseXMLDetails1.getErrorMessage()==null||Request_ResponseXMLDetails1.getErrorCode().equalsIgnoreCase("0"))
								{
									crmInputFxObj.setDesLob(Request_ResponseXMLDetails1.getLOB());
								//	liuInputFxObj.setAccountExtID(Request_ResponseXMLDetails.getAccountExternalId());
							//	bulkDetailsObj.setServId(Request_ResponseXMLDetails.getServ_ID());
								}
								else
								{
									if(Request_ResponseXMLDetails1.getErrorCode().equalsIgnoreCase("BEAI50050E")||Request_ResponseXMLDetails1.getErrorCode().equalsIgnoreCase("EAI_FAILURE")||Request_ResponseXMLDetails1.getErrorCode().equalsIgnoreCase("EAI_NO_RESPONSE"))
									{
										crmInputFxObj.setErrorReasonCode("Failed: Connectivity Issue..RETRY");
											return crmInputFxObj;
									}
									crmInputFxObj.setErrorReasonCode("Failed: Invalid  Destination Account");
									return crmInputFxObj;
									
								}
								
									//bulkDetailsObj.setErrorCode("INVALID ACCOUNT");
							
								
						
							
							//bulkDetailsObj.setErrorCode("INVALID ACCOUNT");
						
							}
							
							/*liuInputFxObj.setRemarks("Failed: Invalid Account");
							//transferICRMLogger.info(liuInputFxObj.getRemarks());
							
							//transferICRMLogger.info(Request_ResponseXMLDetails.getErrorMessage());
							//transferICRMLogger.info("ERROR MESSAGE @ LOB FIND:"+Request_ResponseXMLDetails.getErrorMessage());*/
							
					}
					
						else 
						{
							crmInputFxObj.setErrorReasonCode("Failed: Connectivity Issue..RETRY..");
							transferICRMLogger.info("Remarks:"+crmInputFxObj.getErrorReasonCode());
							
							//transferICRMLogger.info(Request_ResponseXMLDetails.getErrorMessage());
							//transferICRMLogger.info("ERROR MESSAGE @ LOB FIND:"+Request_ResponseXMLDetails.getErrorMessage());
							
							return crmInputFxObj;
						}
				  
//EAI CALL FOR ACCOUNT PROFILE FIND	
						Request_ResponseXMLDetails1.setLOB(crmInputFxObj.getDesLob());
						Request_ResponseXMLDetails1.setAccountExternalId(crmInputFxObj.getDestinationAccountNumber());
						Request_ResponseXMLDetails1.setXMLFileName("ACCOUNT_PROFILE_FIND");
				     
						try {
							Request_ResponseXMLDetails1=ECCEAIAccountDetailsIntegration.eaiCall(Request_ResponseXMLDetails1);
						} catch (JMSException e) {
							crmInputFxObj.setErrorReasonCode("Failed: Connectivity Issue..RETRY");
							StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							transferICRMLogger.error(errors);
							return crmInputFxObj;
						}
				     
				   //transferICRMLogger.info("Error message from EAI for Account Profile:"+Request_ResponseXMLDetails.getErrorMessage());
				   //transferICRMLogger.info("Error code message from EAI for Account Profile:"+Request_ResponseXMLDetails.getErrorCode());
				   
				   if(Request_ResponseXMLDetails1.getErrorMessage()==null||Request_ResponseXMLDetails1.getErrorMessage().equalsIgnoreCase(""))
				      {
					   
						//transferICRMLogger.info("ENTERED EAI CALL IN DETAILS");
					    //transferICRMLogger.info("CUSTOMER NAME FROM KENAN:"+Request_ResponseXMLDetails.getCustomer_Name());
				   
					   if((Request_ResponseXMLDetails1.getBillable_Flag().equalsIgnoreCase("0")&&(crmInputFxObj.getDesLob().equalsIgnoreCase("MOB")||crmInputFxObj.getDesLob().equalsIgnoreCase("BTS"))))
				           {
						   Request_ResponseXMLDetails1.setLOB(crmInputFxObj.getDesLob());
							Request_ResponseXMLDetails1.setFXInternalAccount(Request_ResponseXMLDetails1.getFxInternalAccountNumber());
							Request_ResponseXMLDetails1.setServ_ID(crmInputFxObj.getDesServId());
							
							Request_ResponseXMLDetails1.setXMLFileName("BILLABLE_FIND");
							try {
								Request_ResponseXMLDetails1=ECCEAIAccountDetailsIntegration.eaiCall(Request_ResponseXMLDetails1);
							} catch (JMSException e) {
								crmInputFxObj.setErrorReasonCode("Failed: Connectivity Issue..RETRY");
								StringWriter errors= new StringWriter();
								e.printStackTrace(new PrintWriter(errors));
								transferICRMLogger.error(errors);
								return crmInputFxObj;
							}
							transferICRMLogger.info("Error message in billable find"+Request_ResponseXMLDetails1.getBillableFind().getErrorInfo().getErrorMessage());
							if(Request_ResponseXMLDetails1.getBillableFind().getErrorInfo().getErrorMessage()==null||Request_ResponseXMLDetails1.getBillableFind().getErrorInfo().getErrorMessage().equalsIgnoreCase(""))
							{
								transferICRMLogger.info("Error message in billable find"+Request_ResponseXMLDetails1.getBillableFind().getErrorInfo().getErrorMessage());
								crmInputFxObj.setDestinationAccountNumber(Request_ResponseXMLDetails1.getBillableFind().getBillableFindOutput().getBillableAccount());
							}
								else if(Request_ResponseXMLDetails1.getBillableFind().getErrorInfo().getErrorMessage().equalsIgnoreCase("TUX ERROR")||Request_ResponseXMLDetails1.getErrorCode().equalsIgnoreCase("EAI_FAILURE")||Request_ResponseXMLDetails1.getErrorCode().equalsIgnoreCase("EAI_NO_RESPONSE"))
							{
								crmInputFxObj.setErrorReasonCode("Failed: Connectivity Issue..RETRY");
								return crmInputFxObj;
							}
															
							if(Request_ResponseXMLDetails1.getBillableFind().getErrorInfo().getErrorMessage()==null||Request_ResponseXMLDetails1.getBillableFind().getErrorInfo().getErrorMessage().equalsIgnoreCase(""))
							{
				        	   crmOutputFxObj.setDestinationAccountNumber(crmInputFxObj.getDestinationAccountNumber());
				        	   Request_ResponseXMLDetails1.setAccountExternalId(crmOutputFxObj.getDestinationAccountNumber());
				        	   Request_ResponseXMLDetails1.setLOB(crmOutputFxObj.getDesLob());
				        	   Request_ResponseXMLDetails1.setXMLFileName("ACCOUNT_PROFILE_FIND");
							     
				        	   try {
								Request_ResponseXMLDetails1=ECCEAIAccountDetailsIntegration.eaiCall(Request_ResponseXMLDetails1);
							} catch (JMSException e) {
								// TODO Auto-generated catch block
								crmInputFxObj.setErrorReasonCode("Failed: Connectivity Issue..RETRY");
								StringWriter errors= new StringWriter();
								e.printStackTrace(new PrintWriter(errors));
								transferICRMLogger.error(errors);
								return crmInputFxObj;
							}
					         if(Request_ResponseXMLDetails1.getErrorMessage().equalsIgnoreCase(""))
					         {
					        	 crmOutputFxObj.setAccountType("CUSTOMER");
					           crmOutputFxObj.setFxCustomerType(Request_ResponseXMLDetails1.getCustomer_Type());
					           crmOutputFxObj.setFxValueType(Request_ResponseXMLDetails1.getValue_Type());
					           crmOutputFxObj.setFxVIPFlag(Request_ResponseXMLDetails1.getVIP_Flag());
					           crmOutputFxObj.setFxCustomerClass(Request_ResponseXMLDetails1.getCustomer_Clasification());
					           crmOutputFxObj.setFxLegalEntity(Request_ResponseXMLDetails1.getLegal_Entity());
					           crmOutputFxObj.setDesCurrency(Request_ResponseXMLDetails1.getCustomer_Currency());
					           crmOutputFxObj.setCustomerName(Request_ResponseXMLDetails1.getCustomer_Name());
					           crmOutputFxObj.setMarketCode(Request_ResponseXMLDetails1.getMktCode());
					           crmOutputFxObj.setFxInternalAcctNum(Request_ResponseXMLDetails1.getFxInternalAccountNumber());
					           crmOutputFxObj.setBillCompany(Request_ResponseXMLDetails1.getBillCompany());
					           //invoiceList=Request_ResponseXMLDetails.getInvoice();
					         }
					         else
					         {
									crmInputFxObj.setRemarks(Request_ResponseXMLDetails1.getErrorMessage());
									transferICRMLogger.info("ERROR MESSAGE FROM FX:"+Request_ResponseXMLDetails1.getErrorMessage());
					         }
							}
					        }
				           else
				           {
				           crmOutputFxObj.setAccountType("CUSTOMER");
				           crmOutputFxObj.setFxCustomerType(Request_ResponseXMLDetails1.getCustomer_Type());
				           crmOutputFxObj.setFxValueType(Request_ResponseXMLDetails1.getValue_Type());
				           crmOutputFxObj.setFxVIPFlag(Request_ResponseXMLDetails1.getVIP_Flag());
				           crmOutputFxObj.setFxCustomerClass(Request_ResponseXMLDetails1.getCustomer_Clasification());
				           crmOutputFxObj.setFxLegalEntity(Request_ResponseXMLDetails1.getLegal_Entity());
				           crmOutputFxObj.setDesCurrency(Request_ResponseXMLDetails1.getCustomer_Currency());
				           crmOutputFxObj.setCustomerName(Request_ResponseXMLDetails1.getCustomer_Name());
				           crmOutputFxObj.setMarketCode(Request_ResponseXMLDetails1.getMktCode());
						   crmOutputFxObj.setFxInternalAcctNum(Request_ResponseXMLDetails1.getFxInternalAccountNumber());
						   crmOutputFxObj.setBillCompany(Request_ResponseXMLDetails1.getBillCompany());
				           //invoiceList=Request_ResponseXMLDetails.getInvoice();
				           }
				        
				           //transferICRMLogger.info("CUSTOMER CURRENCY CODE FROM FX:"+Request_ResponseXMLDetails.getCustomer_Currency());
				           
				            //transferICRMLogger.info("INVOICE INPUT IS:"+invoice);			
				            //transferICRMLogger.info("CUSTOMER TYPE:"+Request_ResponseXMLDetails.getCustomer_Type());
				            //transferICRMLogger.info("VALUE TYPE:"+Request_ResponseXMLDetails.getValue_Type());
				            //transferICRMLogger.info("VIP FLAG:"+Request_ResponseXMLDetails.getVIP_Flag());
				            //transferICRMLogger.info("CUSTOMER CLASSIFICATION:"+Request_ResponseXMLDetails.getCustomer_Clasification());
				            //transferICRMLogger.info("ACCOUNT TYPE:"+crmOutputFxObj.getAccountType());
				            
				       	
			      }// IF (CHECK TO FIND ACCOUNT IN FX IN CASE OF ERROR MESSAGE IS NULL)
			    
				   
		    else if(Request_ResponseXMLDetails1.getErrorMessage().equalsIgnoreCase("TUX ERROR")||Request_ResponseXMLDetails1.getErrorCode().equalsIgnoreCase("EAI_FAILURE")||Request_ResponseXMLDetails1.getErrorCode().equalsIgnoreCase("EAI_NO_RESPONSE"))
			{
							crmInputFxObj.setErrorReasonCode("Failed: Connectivity Issue..RETRY");
							return crmInputFxObj;
			}		
				   
				   
				else 
				{
					crmInputFxObj.setErrorReasonCode("Failed: Invalid Account");
				}
					
			
				
				
	  /* else if(Request_ResponseXMLDetails.getErrorMessage().equalsIgnoreCase("TUX ERROR"))
			{
					liuInputFxObj.setRemarks("Failed: Connectivity Issue..RETRY");
					return liuInputFxObj;
			}		
				*/
				
	
		  crmInputFxObj.setFxCustomerClass(crmOutputFxObj.getFxCustomerClass());
		  crmInputFxObj.setFxCustomerType(crmOutputFxObj.getFxCustomerType());
		  crmInputFxObj.setFxLegalEntity(crmOutputFxObj.getFxLegalEntity());
		  crmInputFxObj.setFxValueType(crmOutputFxObj.getFxValueType());
		  crmInputFxObj.setFxVIPFlag(crmOutputFxObj.getFxVIPFlag());
		  crmInputFxObj.setOrigBillRefNo(crmOutputFxObj.getOrigBillRefNo());
		  crmInputFxObj.setOrigBillRefResets(crmOutputFxObj.getOrigBillRefResets());
		  //transferICRMLogger.info("bill ref no:"+crmInputFxObj.getOrigBillRefResets());
		  crmInputFxObj.setCustomerName(crmOutputFxObj.getCustomerName());
		  crmInputFxObj.setBillCompany(crmOutputFxObj.getBillCompany());
		  crmInputFxObj.setFxInternalAcctNum(crmOutputFxObj.getFxInternalAcctNum());
		  crmInputFxObj.setMarketCode(crmOutputFxObj.getMarketCode());
		  crmInputFxObj.setDesCurrency(crmOutputFxObj.getDesCurrency());
		
	  
	  
				}
				}// TRY BLOCK 
	  catch (Exception e) {
		  StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			transferICRMLogger.error(errors);	
		  //transferICRMLogger.info("in catch");
		//  crmInputFxObj.setErrorReasonCode("Failed: Connectivity Issue..RETRY");
			return crmInputFxObj;
			
		}
		finally{
			try {
				if(conn!=null)
				conn.close();
			} catch (Exception e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				transferICRMLogger.error(errors);	
			}
		}
		transferICRMLogger.info(" Executed validationsFromFX  method at TransferIcrmDaoImpl");

	  return crmInputFxObj;

	}

	private  String getLobByServId(String serv_ID) {
		// TODO Auto-generated method stub
		final String procedureCall = "{call LOB_SERV_ID(?,?)}";
		Connection connection = null;
		
		String lob=null;
		try
		{

			transferICRMLogger.info(" Entered getLobByServId  method at TransferIcrmDaoImpl");
			
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			//fileObj.setConnection(connection);
			connection.setAutoCommit(false);
		CallableStatement  callableStatement = (CallableStatement) connection
					.prepareCall(procedureCall);
			callableStatement.setString(1, serv_ID);
			
			
			callableStatement.registerOutParameter(2, Types.VARCHAR);
			
			callableStatement.executeUpdate();
			lob=callableStatement.getString(2);
		
			transferICRMLogger.info(" LOB from getLobByServId method at TransferIcrmDaoImpl:"+lob);

			transferICRMLogger.info(" Executed getLobByServId method at TransferIcrmDaoImpl");

		
		}
		catch(Exception e)
		{
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			transferICRMLogger.error(errors);
		}
		finally{
			try {
				if(conn!=null)
				conn.close();
			} catch (Exception e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				transferICRMLogger.error(errors);	
			}
		}
		return lob;

	}// METHOD END

	@Override
	public String rejectedCrmDetails(List<String> crmRejectedList, String userId,String sessionId, String rejectedReason) {
		final String procedureCall = "{call CRM_REJECTION(?,?,?,?,?)}";
		Connection connection = null;
		String rejectionStatus=null;
		transferICRMLogger.info(" Entered rejectedCrmDetails method at TransferIcrmDaoImpl");

		try {

			// Get Connection instance from dataSource
			//transferICRMLogger.info("connect"+ "ion:" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			connection.setAutoCommit(false);
			//transferICRMLogger.info("crm list list is:"+crmRejectedList.get(0));
			
			ArrayDescriptor des = ArrayDescriptor.createDescriptor("ARRAY_FILEID_TABLE", connection); 
			Object[] array=crmRejectedList.toArray();
	         //transferICRMLogger.info("Array Element "+array[0]);
	         ARRAY array_to_pass = new ARRAY(des,connection,array);
	         CallableStatement callableStatement = connection
	 				.prepareCall(procedureCall);
	        
	      //    //transferICRMLogger.info("arrar"+array_to_pass.getArray().toString());
	        
	         callableStatement.setArray(1, array_to_pass);
	         
	         callableStatement.setString(2,rejectedReason);
	         callableStatement.setString(3,userId);
	         callableStatement.registerOutParameter(4, Types.VARCHAR);
	         callableStatement.registerOutParameter(5, Types.VARCHAR);
	         callableStatement.executeUpdate();
	         //transferICRMLogger.info("error msg"+callableStatement.getString(5));
	         rejectionStatus=callableStatement.getString(5); 
	        
	 		transferICRMLogger.info(" Rejection Status in rejectedCrmDetails method at TransferIcrmDaoImpl:"+rejectionStatus);

	      
	         connection.commit();
		}
		catch (SQLException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			transferICRMLogger.error(errors);
			
			
	      // return approvestatus;
		} 
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			transferICRMLogger.error(errors);
			
		
	     //  return "false";
		}finally {

			if (connection != null)
				try {
					connection.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					transferICRMLogger.error(errors);
				}
		}
		transferICRMLogger.info(" Executed rejectedCrmDetails method at TransferIcrmDaoImpl");

		return rejectionStatus;

	}

	}

	


