package com.acecad.liu.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
/*import java.util.logging.LogManager;
import java.util.logging.Logger;*/
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.acecad.liu.dao.LIURecordsDAO;
import com.acecad.liu.model.LIURecordDetails;
import com.airtel.acecad.UtilityJar.ActivityLog;
import com.airtel.acecad.bulkupload.dto.FileUploadResult;
import com.airtel.acecad.bulkupload.uploadfile.ExcelReader;

@Controller
public class LiuController {

	@Autowired
	ActivityLog activityDao;
	@Autowired
	ExcelReader excelReader;
	@Autowired
	LIURecordsDAO liuRecordsDaoObj;
	private static Logger LIUlogger =LogManager.getLogger("liuLogger");
	//private static Logger LIUlogger = LogManager.getLogger("liuLogger");

	public HttpSession session;
	private String downloadpath=System.getenv("ACE_CAD_HOME")+File.separator+"UPLOADED_FILES"+File.separator+"LIU";
	private String errorFilesPath=System.getenv("ACE_CAD_HOME")+File.separator+"UPLOADED_FILES"+File.separator+"LIU_Error";
	private String downloadedFilesPath = System.getenv("ACE_CAD_HOME") + "\\DOWNLOADED_FILES";
	private String LIUFilepath="";
	HashMap<Integer, List<LIURecordDetails>> liuRecordDetailsMap = new HashMap<Integer, List<LIURecordDetails>>();

	String extension = "xlsx";

	int SNo;

	// LIURecordDetails defaultRecordsObj=new LIURecordDetails();

	// PAGINATION OF LIU RECORDS

	@RequestMapping(value = "/caduserLIU")
	public ModelAndView showLiuCases(ModelMap model, HttpServletRequest request, HttpServletResponse response)

	{
		ModelAndView modelAndViewObj = new ModelAndView();
		LIURecordDetails defaultRecordsObj1 = new LIURecordDetails();

		try {
			LIUlogger.info("Entered into caduserLIU mapping at CONTROLLER)");
			int pageNumber = 1;
			LIUlogger.info("PageNumber at showLiuCases:" + pageNumber);

			List<String> liuReasonList = liuRecordsDaoObj.liuReasonDropdown();
			if (liuReasonList == null) {
				LIUlogger.info("Data Base Issues For ReasonList");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuPayModeList = liuRecordsDaoObj.liuPayModeDropdown();
			if (liuPayModeList == null) {
				LIUlogger.info("Data Base Issues For Payment Mode!");

				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuStatusList = liuRecordsDaoObj.liuStatusDropdown();
			if (liuStatusList == null) {
				LIUlogger.info("Data Base Issues For Status!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<LIURecordDetails> liuPaymentCurrencyList = liuRecordsDaoObj.liuPaymentCurrency();
			if (liuPaymentCurrencyList == null) {
				LIUlogger.info("Data Base Issues For Payment Currency!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuFileList = liuRecordsDaoObj.liuFilenameList();
			if (liuFileList == null) {
				LIUlogger.info("Data Base Issues For File List!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			defaultRecordsObj1.setLiuStatus("LIU PENDING");

			String liuStatus = "LIU PENDING";

			String paymentMode = request.getParameter("paymentMode");
			// System.out.println("PAYMENT MODE FROM JSP:"+
			// request.getParameter("paymentMode"));

			String remitterIfsc = request.getParameter("ifscCode");
			String referenceId = request.getParameter("refID");
			String acctNum = request.getParameter("accountNumber");
			String liuReason = request.getParameter("liuReason");
			String fromDate = request.getParameter("startDate");
			String toDate = request.getParameter("endDate");
			String liu_Status = request.getParameter("liuStatus");
			String userId = request.getParameter("userID");
			String fileName = request.getParameter("fileName");

			defaultRecordsObj1.setPaymentMode(paymentMode);

			if (referenceId == null || referenceId.equals(""))
				defaultRecordsObj1.setReferenceID(null);
			else
				defaultRecordsObj1.setReferenceID(referenceId.trim());

			if (paymentMode != null) {
				if (paymentMode.equalsIgnoreCase("CHEQUE")) {
					if (remitterIfsc == null || remitterIfsc.equals(""))
						defaultRecordsObj1.setRemitterIFSC(null);
					else
						defaultRecordsObj1.setRemitterIFSC(remitterIfsc.trim());
				}

				else
					defaultRecordsObj1.setRemitterIFSC(null);
			}

			if (acctNum == null || acctNum.equals(""))
				defaultRecordsObj1.setAccountExtID(null);
			else
				defaultRecordsObj1.setAccountExtID(acctNum.trim());

			defaultRecordsObj1.setLiuReason(liuReason);

			if (fromDate == null || fromDate.equals(""))
				defaultRecordsObj1.setFromDate(null);
			else
				defaultRecordsObj1.setFromDate(fromDate);

			if (toDate == null || toDate.equals(""))
				defaultRecordsObj1.setToDate(null);
			else
				defaultRecordsObj1.setToDate(toDate);

			if (liu_Status != null)
				defaultRecordsObj1.setLiuStatus(liu_Status);

			if (fileName != null)
				defaultRecordsObj1.setFileName(fileName.trim());

			if (userId == null || userId.equals(""))
				defaultRecordsObj1.setUserID(null);
			else
				defaultRecordsObj1.setUserID(userId.trim());

			LIUlogger.info("UTR NUMBER FROM JSP:" + request.getParameter("refID"));
			LIUlogger.info(" IFSC CODE FROM JSP:" + request.getParameter("ifscCode"));
			LIUlogger.info("ACCOUNT NUMBER FROM JSP:" + request.getParameter("accountNumber"));
			LIUlogger.info("LIU REASON FROM JSP:" + request.getParameter("liuReason"));
			LIUlogger.info("START DATE FROM JSP:" + request.getParameter("startDate"));
			LIUlogger.info("END DATE FROM JSP:" + request.getParameter("endDate"));
			LIUlogger.info(" LIU STATUS FROM JSP:" + request.getParameter("liuStatus"));
			LIUlogger.info(" FILE NAME FROM JSP:" + request.getParameter("fileName"));
			LIUlogger.info("PAYMENT MODE FROM JSP:" + request.getParameter("paymentMode"));
			LIUlogger.info(" USER ID FROM JSP:" + request.getParameter("userID"));

			HashMap<Integer, List<LIURecordDetails>> liuDetailsMap = liuRecordsDaoObj
					.liuRecordSearchFirstPage(pageNumber, defaultRecordsObj1);

			String errorMsg = defaultRecordsObj1.getErrorMsg();
			LIUlogger.info("Error message in caduserLIU mapping is" + errorMsg);

			if (errorMsg != null) {
				if (errorMsg.equalsIgnoreCase("SUCCESS")) {
					errorMsg = "";
				} else
					errorMsg = "No records Found";
			} else
				errorMsg = "Connectivity Issues..Retry..";

			if (liuDetailsMap == null) {
				LIUlogger.info("Data Base Issues...Exception in caduserLIU");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("liuReasonList", liuReasonList);
				modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
				modelAndViewObj.addObject("liuStatusList", liuStatusList);
				modelAndViewObj.addObject("liuFileList", liuFileList);
				modelAndViewObj.addObject("liuStatusMsg", liuStatus);
				modelAndViewObj.setViewName("viewLiuDetailsWithpage");
				return modelAndViewObj;
			}

			modelAndViewObj.addObject("liuDetailsMap", liuDetailsMap);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("liuReasonList", liuReasonList);
			modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
			modelAndViewObj.addObject("liuStatusList", liuStatusList);
			modelAndViewObj.addObject("liuPaymentCurrencyList", liuPaymentCurrencyList);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			modelAndViewObj.addObject("liuFileList", liuFileList);
			modelAndViewObj.addObject("liuStatusMsg", liuStatus);
			modelAndViewObj.setViewName("viewLiuDetailsWithpage");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return modelAndViewObj;
	}

	@RequestMapping(value = "/liuDetailsList")
	public ModelAndView getLIUDetails(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		LIURecordDetails defaultRecordsObj2 = new LIURecordDetails();
		int pageNumber = Integer.parseInt(request.getParameter("pageNumber"));

		LIUlogger.info(" Page Number at getLIUDetails:" + pageNumber);

		try {
			LIUlogger.info("Entered into GETLIUDETAILS @controller");

			List<String> liuReasonList = liuRecordsDaoObj.liuReasonDropdown();
			if (liuReasonList == null) {
				LIUlogger.info("Data Base Issues For ReasonList");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuPayModeList = liuRecordsDaoObj.liuPayModeDropdown();
			if (liuPayModeList == null) {
				LIUlogger.info("Data Base Issues For Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuStatusList = liuRecordsDaoObj.liuStatusDropdown();
			if (liuStatusList == null) {
				LIUlogger.info("Data Base Issues For Status List!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<LIURecordDetails> liuPaymentCurrencyList = liuRecordsDaoObj.liuPaymentCurrency();
			if (liuPaymentCurrencyList == null) {
				LIUlogger.info("Data Base Issues For Payment Currency!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuFileList = liuRecordsDaoObj.liuFilenameList();
			if (liuFileList == null) {
				LIUlogger.info("Data Base Issues For File List!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			defaultRecordsObj2.setLiuStatus("LIU PENDING");

			String paymentMode = request.getParameter("paymentMode");
			String referenceId = request.getParameter("refID");
			String remitterIfsc = request.getParameter("ifscCode");
			String acctNum = request.getParameter("accountNumber");
			String liuReason = request.getParameter("liuReason");
			String fromDate = request.getParameter("startDate");
			String toDate = request.getParameter("endDate");
			String liu_Status = request.getParameter("liuStatus");
			String userId = request.getParameter("userID");
			String fileName = request.getParameter("fileName");

			defaultRecordsObj2.setPaymentMode(paymentMode);

			if (referenceId == null || referenceId.equals(""))
				defaultRecordsObj2.setReferenceID(null);
			else
				defaultRecordsObj2.setReferenceID(referenceId.trim());

			if (paymentMode != null) {
				if (paymentMode.equalsIgnoreCase("CHEQUE")) {
					if (remitterIfsc == null || remitterIfsc.equals(""))
						defaultRecordsObj2.setRemitterIFSC(null);
					else
						defaultRecordsObj2.setRemitterIFSC(remitterIfsc.trim());
				}

				else
					defaultRecordsObj2.setRemitterIFSC(null);
			}

			if (acctNum == null || acctNum.equals(""))
				defaultRecordsObj2.setAccountExtID(null);
			else
				defaultRecordsObj2.setAccountExtID(acctNum.trim());

			defaultRecordsObj2.setLiuReason(liuReason);

			if (fromDate == null || fromDate.equals(""))
				defaultRecordsObj2.setFromDate(null);
			else
				defaultRecordsObj2.setFromDate(fromDate);

			if (toDate == null || toDate.equals(""))
				defaultRecordsObj2.setToDate(null);
			else
				defaultRecordsObj2.setToDate(toDate);

			if (liu_Status != null)
				defaultRecordsObj2.setLiuStatus(liu_Status);

			if (fileName != null)
				defaultRecordsObj2.setFileName(fileName.trim());

			if (userId == null || userId.equals(""))
				defaultRecordsObj2.setUserID(null);
			else
				defaultRecordsObj2.setUserID(userId.trim());

			LIUlogger.info("UTR NUMBER FROM JSP:" + request.getParameter("refID"));
			LIUlogger.info(" IFSC CODE FROM JSP:" + request.getParameter("ifscCode"));
			LIUlogger.info("ACCOUNT NUMBER FROM JSP:" + request.getParameter("accountNumber"));
			LIUlogger.info("LIU REASON FROM JSP:" + request.getParameter("liuReason"));
			LIUlogger.info("START DATE FROM JSP:" + request.getParameter("startDate"));
			LIUlogger.info("END DATE FROM JSP:" + request.getParameter("endDate"));
			LIUlogger.info(" LIU STATUS FROM JSP:" + request.getParameter("liuStatus"));
			LIUlogger.info(" FILE NAME FROM JSP:" + request.getParameter("fileName"));
			LIUlogger.info("PAYMENT MODE FROM JSP:" + request.getParameter("paymentMode"));
			LIUlogger.info(" USER ID FROM JSP:" + request.getParameter("userID"));

			HashMap<Integer, List<LIURecordDetails>> liuDetailsMap = liuRecordsDaoObj
					.liuRecordSearchFirstPage(pageNumber, defaultRecordsObj2);

			String errorMsg = defaultRecordsObj2.getErrorMsg();
			String liuStatus = "LIU PENDING";

			LIUlogger.info("Error message in liuDetailsList mapping is" + errorMsg);

			if (errorMsg != null) {
				if (errorMsg.equalsIgnoreCase("SUCCESS")) {
					errorMsg = "";
				} else
					errorMsg = "No records Found";
			} else
				errorMsg = "Connectivity Issues..Retry..";

			if (liuDetailsMap == null) {
				LIUlogger.info("Data Base Issues...Exception in caduserLIU");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("liuReasonList", liuReasonList);
				modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
				modelAndViewObj.addObject("liuStatusList", liuStatusList);
				modelAndViewObj.addObject("liuFileList", liuFileList);
				modelAndViewObj.addObject("liuStatusMsg", liuStatus);
				modelAndViewObj.setViewName("viewLiuDetailsWithpage");
				return modelAndViewObj;
			}

			modelAndViewObj.addObject("liuDetailsMap", liuDetailsMap);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("liuReasonList", liuReasonList);
			modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
			modelAndViewObj.addObject("liuStatusList", liuStatusList);
			modelAndViewObj.addObject("liuStatusMsg", liuStatus);
			modelAndViewObj.addObject("liuPaymentCurrencyList", liuPaymentCurrencyList);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			modelAndViewObj.addObject("liuFileList", liuFileList);
			modelAndViewObj.setViewName("viewLiuDetailsWithpage");

		} catch (Exception e) {
			e.printStackTrace();
		}
		LIUlogger.info("EXECUTED GETLIUDETAILS (@controller)");

		return modelAndViewObj;
	}

	@RequestMapping(value = "/exportToExcelDefault", method = RequestMethod.POST)
	public ModelAndView exportToExcelDefault(ModelMap model, HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		LIURecordDetails defaultRecordsObj3 = new LIURecordDetails();

		try {

			LIUlogger.info("ENTERED INTO EXPORT TO EXCEL METHOD DEFAULT AT CONTROLLER");

			String page = null;

			List<String> liuReasonList = liuRecordsDaoObj.liuReasonDropdown();
			if (liuReasonList == null) {
				LIUlogger.info("Data Base Issues For ReasonList");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuPayModeList = liuRecordsDaoObj.liuPayModeDropdown();
			if (liuPayModeList == null) {
				LIUlogger.info("Data Base Issues For Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuStatusList = liuRecordsDaoObj.liuStatusDropdown();
			if (liuStatusList == null) {
				LIUlogger.info("Data Base Issues For Status List!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuFileList = liuRecordsDaoObj.liuFilenameList();
			if (liuFileList == null) {
				LIUlogger.info("Data Base Issues For File List!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			String paymentMode = request.getParameter("paymentMode");
			String referenceId = request.getParameter("refID");
			String remitterIfsc = request.getParameter("ifscCode");
			String acctNum = request.getParameter("accountNumber");
			String liuReason = request.getParameter("liuReason");
			String fromDate = request.getParameter("startDate");
			String toDate = request.getParameter("endDate");
			String liu_Status = request.getParameter("liuStatus");
			String userId = request.getParameter("userID");
			String fileName = request.getParameter("fileName");

			defaultRecordsObj3.setPaymentMode(paymentMode);

			if (referenceId == null || referenceId.equals(""))
				defaultRecordsObj3.setReferenceID(null);
			else
				defaultRecordsObj3.setReferenceID(referenceId.trim());

			if (paymentMode != null) {
				if (paymentMode.equalsIgnoreCase("CHEQUE")) {
					if (remitterIfsc == null || remitterIfsc.equals(""))
						defaultRecordsObj3.setRemitterIFSC(null);
					else
						defaultRecordsObj3.setRemitterIFSC(remitterIfsc.trim());
				}

				else
					defaultRecordsObj3.setRemitterIFSC(null);
			}

			if (acctNum == null || acctNum.equals(""))
				defaultRecordsObj3.setAccountExtID(null);
			else
				defaultRecordsObj3.setAccountExtID(acctNum.trim());

			defaultRecordsObj3.setLiuReason(liuReason);

			if (fromDate == null || fromDate.equals(""))
				defaultRecordsObj3.setFromDate(null);
			else
				defaultRecordsObj3.setFromDate(fromDate);

			if (toDate == null || toDate.equals(""))
				defaultRecordsObj3.setToDate(null);
			else
				defaultRecordsObj3.setToDate(toDate);

			if (liu_Status != null)
				defaultRecordsObj3.setLiuStatus(liu_Status);

			if (fileName != null)
				defaultRecordsObj3.setFileName(fileName.trim());

			if (userId == null || userId.equals(""))
				defaultRecordsObj3.setUserID(null);
			else
				defaultRecordsObj3.setUserID(userId.trim());

			LIUlogger.info("UTR NUMBER FROM JSP:" + request.getParameter("refID"));
			LIUlogger.info(" IFSC CODE FROM JSP:" + request.getParameter("ifscCode"));
			LIUlogger.info("ACCOUNT NUMBER FROM JSP:" + request.getParameter("accountNumber"));
			LIUlogger.info("LIU REASON FROM JSP:" + request.getParameter("liuReason"));
			LIUlogger.info("START DATE FROM JSP:" + request.getParameter("startDate"));
			LIUlogger.info("END DATE FROM JSP:" + request.getParameter("endDate"));
			LIUlogger.info(" LIU STATUS FROM JSP:" + request.getParameter("liuStatus"));
			LIUlogger.info(" FILE NAME FROM JSP:" + request.getParameter("fileName"));
			LIUlogger.info("PAYMENT MODE FROM JSP:" + request.getParameter("paymentMode"));
			LIUlogger.info(" USER ID FROM JSP:" + request.getParameter("userID"));

			LIURecordDetails liuFileObj = liuRecordsDaoObj.downloadedFile(defaultRecordsObj3,
					/* downloadedFilesPath, */ extension, page);

			LIUlogger.info("Liu Status:" + defaultRecordsObj3.getLiuStatus());

			/*
			 * String filePath=downloadedFilesPath;
			 * LIUlogger.info("Filepath is:"+filePath);
			 */

			String errorMsg = defaultRecordsObj3.getErrorMsg();
			LIUlogger.info("Error Message in exportToExcelDefault mapping at controller " + errorMsg);

			if (errorMsg != null) {
				if (errorMsg.equalsIgnoreCase("SUCCESS")) {
					errorMsg = "";
				} else
					errorMsg = "No records Found";
			} else
				errorMsg = "Connectivity Issues..Retry..";

			if (liuFileObj == null) {
				LIUlogger.info("Data Base Issues...Exception in exportToExcel");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("liuReasonList", liuReasonList);
				modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
				modelAndViewObj.addObject("liuStatusList", liuStatusList);
				modelAndViewObj.addObject("liuFileList", liuFileList);
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			String filename = "APS_" + liuFileObj.getLiuStatus() + "_" + liuRecordsDaoObj.getDateTime() + "."
					+ extension;
			LIUlogger.info("Filename:" + filename);

			// String finalPath=/*filePath+"\\"+*/filename;

			ServletOutputStream out = response.getOutputStream();
			FileInputStream in = new FileInputStream(filename);
			LIUlogger.info("File Name:" + in);

			response.setContentType("APPLICATION/OCTET-STREAM");

			response.addHeader("content-disposition", "attachment; filename=" + filename);

			LIUlogger.info("PROCESS COMPLETED AND FETCHED THE FILE @ CONTROLLER");

			int octet;
			while ((octet = in.read()) != -1)
				out.write(octet);

			in.close();
			out.flush();
			out.close();
			response.flushBuffer();
			LIUlogger.info("FINISHED EXECUTION OF EXPORT TO EXCEL DEFAULT METHOD");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return modelAndViewObj;
	}

	// LIURecordDetails searchDetailsObj=new LIURecordDetails();

	@RequestMapping(value = "/liuRecordSearchFirstPage"/*
	 * , method =
	 * RequestMethod.GET
	 */)
	public ModelAndView liuRecordSearchFirstPage(ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		LIURecordDetails searchDetailsObj1 = new LIURecordDetails();
		LIUlogger.info("ENTERED INTO LIU RECORD SEARCH FIRST PAGE (@CONTROLLER)");
		ModelAndView modelAndViewObj = new ModelAndView();
		int pageNumber = 1;

		try {

			String paymentMode = request.getParameter("paymentMode");
			String referenceId = request.getParameter("refID");
			String remitterIfsc = request.getParameter("ifscCode");
			String acctNum = request.getParameter("accountNumber");
			String liuReason = request.getParameter("liuReason");
			String fromDate = request.getParameter("startDate");
			String toDate = request.getParameter("endDate");
			String liu_Status = request.getParameter("liuStatus");
			String userId = request.getParameter("userID");
			String fileName = request.getParameter("fileName");

			searchDetailsObj1.setPaymentMode(paymentMode);

			if (referenceId == null || referenceId.equals(""))
				searchDetailsObj1.setReferenceID(null);
			else
				searchDetailsObj1.setReferenceID(referenceId.trim());

			if (paymentMode != null) {
				if (paymentMode.equalsIgnoreCase("CHEQUE")) {
					if (remitterIfsc == null || remitterIfsc.equals(""))
						searchDetailsObj1.setRemitterIFSC(null);
					else
						searchDetailsObj1.setRemitterIFSC(remitterIfsc.trim());
				}

				else
					searchDetailsObj1.setRemitterIFSC(null);
			}

			if (acctNum == null || acctNum.equals(""))
				searchDetailsObj1.setAccountExtID(null);
			else
				searchDetailsObj1.setAccountExtID(acctNum.trim());

			searchDetailsObj1.setLiuReason(liuReason);

			if (fromDate == null || fromDate.equals(""))
				searchDetailsObj1.setFromDate(null);
			else
				searchDetailsObj1.setFromDate(fromDate);

			if (toDate == null || toDate.equals(""))
				searchDetailsObj1.setToDate(null);
			else
				searchDetailsObj1.setToDate(toDate);

			if (liu_Status != null)
				searchDetailsObj1.setLiuStatus(liu_Status);

			if (fileName != null)
				searchDetailsObj1.setFileName(fileName.trim());

			if (userId == null || userId.equals(""))
				searchDetailsObj1.setUserID(null);
			else
				searchDetailsObj1.setUserID(userId.trim());

			LIUlogger.info("UTR NUMBER FROM JSP:" + request.getParameter("refID"));
			LIUlogger.info(" IFSC CODE FROM JSP:" + request.getParameter("ifscCode"));
			LIUlogger.info("ACCOUNT NUMBER FROM JSP:" + request.getParameter("accountNumber"));
			LIUlogger.info("LIU REASON FROM JSP:" + request.getParameter("liuReason"));
			LIUlogger.info("START DATE FROM JSP:" + request.getParameter("startDate"));
			LIUlogger.info("END DATE FROM JSP:" + request.getParameter("endDate"));
			LIUlogger.info(" LIU STATUS FROM JSP:" + request.getParameter("liuStatus"));
			LIUlogger.info(" FILE NAME FROM JSP:" + request.getParameter("fileName"));
			LIUlogger.info("PAYMENT MODE FROM JSP:" + request.getParameter("paymentMode"));
			LIUlogger.info(" USER ID FROM JSP:" + request.getParameter("userID"));

			List<String> liuReasonList = liuRecordsDaoObj.liuReasonDropdown();
			if (liuReasonList == null) {
				LIUlogger.info("Data Base Issues For ReasonList");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuPayModeList = liuRecordsDaoObj.liuPayModeDropdown();
			if (liuPayModeList == null) {
				LIUlogger.info("Data Base Issues For Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuStatusList = liuRecordsDaoObj.liuStatusDropdown();
			if (liuStatusList == null) {
				LIUlogger.info("Data Base Issues For  liuStatus!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<LIURecordDetails> liuPaymentCurrencyList = liuRecordsDaoObj.liuPaymentCurrency();
			if (liuPaymentCurrencyList == null) {
				LIUlogger.info("Data Base Issues For  Payment Currency!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuFileList = liuRecordsDaoObj.liuFilenameList();
			if (liuFileList == null) {
				LIUlogger.info("Data Base Issues For File List!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			liuRecordDetailsMap = liuRecordsDaoObj.liuRecordSearchFirstPage(pageNumber, searchDetailsObj1);

			String errorMsg = searchDetailsObj1.getErrorMsg();
			LIUlogger.info("Error message at liuRecordSearchFirstPage requestMapping in controller:" + errorMsg);

			String liuStatus = searchDetailsObj1.getLiuStatus();

			if (errorMsg != null) {
				if (errorMsg.equalsIgnoreCase("SUCCESS")) {
					errorMsg = "";
				} else
					errorMsg = "No records Found";
			} else
				errorMsg = "Connectivity Issues..Retry..";

			if (liuRecordDetailsMap == null) {
				LIUlogger.info("Data Base Issues...Exception in caduserLIU");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("liuReasonList", liuReasonList);
				modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
				modelAndViewObj.addObject("liuStatusList", liuStatusList);
				modelAndViewObj.addObject("liuFileList", liuFileList);
				modelAndViewObj.addObject("liuStatusMsg", liuStatus);
				modelAndViewObj.setViewName("liuSearchPage");
				return modelAndViewObj;
			}

			modelAndViewObj.addObject("liuRecordDetailsMap", liuRecordDetailsMap);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("liuReasonList", liuReasonList);
			modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
			modelAndViewObj.addObject("liuStatusList", liuStatusList);
			modelAndViewObj.addObject("liuPaymentCurrencyList", liuPaymentCurrencyList);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			modelAndViewObj.addObject("liuStatusMsg", liuStatus);
			modelAndViewObj.addObject("liuFileList", liuFileList);
			modelAndViewObj.addObject("liuRecordDetailsObjJsp", searchDetailsObj1);
			modelAndViewObj.setViewName("liuSearchPage");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return modelAndViewObj;
	}

	@RequestMapping(value = "/liuRecordsForNextAndPrevious")
	public ModelAndView liuRecordsForNextAndPrevious(ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		LIURecordDetails searchDetailsObj2 = new LIURecordDetails();

		ModelAndView modelAndViewObj = new ModelAndView();
		LIUlogger.info("Entered liuRecordsForNextAndPrevious mapping at LIU controller");

		try {

			int pageNumber = Integer.parseInt(request.getParameter("pageNumber"));

			List<String> liuReasonList = liuRecordsDaoObj.liuReasonDropdown();
			if (liuReasonList == null) {
				LIUlogger.info("Data Base Issues For ReasonList");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuPayModeList = liuRecordsDaoObj.liuPayModeDropdown();
			if (liuPayModeList == null) {
				LIUlogger.info("Data Base Issues For  Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuStatusList = liuRecordsDaoObj.liuStatusDropdown();
			if (liuStatusList == null) {
				LIUlogger.info("Data Base Issues For  Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<LIURecordDetails> liuPaymentCurrencyList = liuRecordsDaoObj.liuPaymentCurrency();
			if (liuPaymentCurrencyList == null) {
				LIUlogger.info("Data Base Issues For Payment Currency!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuFileList = liuRecordsDaoObj.liuFilenameList();
			if (liuFileList == null) {
				LIUlogger.info("Data Base Issues For File List!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			String paymentMode = request.getParameter("paymentMode");
			String referenceId = request.getParameter("refID");
			String remitterIfsc = request.getParameter("ifscCode");
			String acctNum = request.getParameter("accountNumber");
			String liuReason = request.getParameter("liuReason");
			String fromDate = request.getParameter("startDate");
			String toDate = request.getParameter("endDate");
			String liu_Status = request.getParameter("liuStatus");
			String userId = request.getParameter("userID");
			String fileName = request.getParameter("fileName");

			LIUlogger.info("UTR NUMBER FROM JSP:" + request.getParameter("refID"));
			LIUlogger.info(" IFSC CODE FROM JSP:" + request.getParameter("ifscCode"));
			LIUlogger.info("ACCOUNT NUMBER FROM JSP:" + request.getParameter("accountNumber"));
			LIUlogger.info("LIU REASON FROM JSP:" + request.getParameter("liuReason"));
			LIUlogger.info("START DATE FROM JSP:" + request.getParameter("startDate"));
			LIUlogger.info("END DATE FROM JSP:" + request.getParameter("endDate"));
			LIUlogger.info(" LIU STATUS FROM JSP:" + request.getParameter("liuStatus"));
			LIUlogger.info(" FILE NAME FROM JSP:" + request.getParameter("fileName"));
			LIUlogger.info("PAYMENT MODE FROM JSP:" + request.getParameter("paymentMode"));
			LIUlogger.info(" USER ID FROM JSP:" + request.getParameter("userID"));

			searchDetailsObj2.setPaymentMode(paymentMode);

			if (referenceId == null || referenceId.equals(""))
				searchDetailsObj2.setReferenceID(null);
			else
				searchDetailsObj2.setReferenceID(referenceId.trim());

			if (paymentMode != null) {
				if (paymentMode.equalsIgnoreCase("CHEQUE")) {
					if (remitterIfsc == null || remitterIfsc.equals(""))
						searchDetailsObj2.setRemitterIFSC(null);
					else
						searchDetailsObj2.setRemitterIFSC(remitterIfsc.trim());
				}

				else
					searchDetailsObj2.setRemitterIFSC(null);
			}

			if (acctNum == null || acctNum.equals(""))
				searchDetailsObj2.setAccountExtID(null);
			else
				searchDetailsObj2.setAccountExtID(acctNum.trim());

			searchDetailsObj2.setLiuReason(liuReason);

			if (fromDate == null || fromDate.equals(""))
				searchDetailsObj2.setFromDate(null);
			else
				searchDetailsObj2.setFromDate(fromDate);

			if (toDate == null || toDate.equals(""))
				searchDetailsObj2.setToDate(null);
			else
				searchDetailsObj2.setToDate(toDate);

			if (liu_Status != null)
				searchDetailsObj2.setLiuStatus(liu_Status);

			if (fileName != null)
				searchDetailsObj2.setFileName(fileName.trim());

			if (userId == null || userId.equals(""))
				searchDetailsObj2.setUserID(null);
			else
				searchDetailsObj2.setUserID(userId.trim());

			LIUlogger.info("UTR NUMBER FROM JSP:" + request.getParameter("refID"));
			LIUlogger.info(" IFSC CODE FROM JSP:" + request.getParameter("ifscCode"));
			LIUlogger.info("ACCOUNT NUMBER FROM JSP:" + request.getParameter("accountNumber"));
			LIUlogger.info("LIU REASON FROM JSP:" + request.getParameter("liuReason"));
			LIUlogger.info("START DATE FROM JSP:" + request.getParameter("startDate"));
			LIUlogger.info("END DATE FROM JSP:" + request.getParameter("endDate"));
			LIUlogger.info(" LIU STATUS FROM JSP:" + request.getParameter("liuStatus"));
			LIUlogger.info(" FILE NAME FROM JSP:" + request.getParameter("fileName"));
			LIUlogger.info("PAYMENT MODE FROM JSP:" + request.getParameter("paymentMode"));
			LIUlogger.info(" USER ID FROM JSP:" + request.getParameter("userID"));

			HashMap<Integer, List<LIURecordDetails>> liuRecordDetailsMap = liuRecordsDaoObj
					.liuRecordSearchFirstPage(pageNumber, searchDetailsObj2);

			String errorMsg = searchDetailsObj2.getErrorMsg();
			LIUlogger.info("Error message at liuRecordsForNextAndPrevious requestMapping in controller:" + errorMsg);

			String liuStatus = searchDetailsObj2.getLiuStatus();

			if (errorMsg != null) {
				if (errorMsg.equalsIgnoreCase("SUCCESS")) {
					errorMsg = "";
				} else
					errorMsg = "No records Found";
			} else
				errorMsg = "Connectivity Issues..Retry..";

			if (liuRecordDetailsMap == null) {
				LIUlogger.info("Data Base Issues...Exception in caduserLIU");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("liuReasonList", liuReasonList);
				modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
				modelAndViewObj.addObject("liuStatusList", liuStatusList);
				modelAndViewObj.addObject("liuFileList", liuFileList);
				modelAndViewObj.addObject("liuStatusMsg", liuStatus);
				modelAndViewObj.setViewName("liuSearchPage");
				return modelAndViewObj;
			}

			modelAndViewObj.addObject("liuRecordDetailsMap", liuRecordDetailsMap);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("liuReasonList", liuReasonList);
			modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
			modelAndViewObj.addObject("liuStatusList", liuStatusList);
			modelAndViewObj.addObject("liuPaymentCurrencyList", liuPaymentCurrencyList);
			modelAndViewObj.addObject("liuRecordDetailsObjJsp", searchDetailsObj2);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			modelAndViewObj.addObject("liuFileList", liuFileList);
			modelAndViewObj.addObject("liuStatusMsg", liuStatus);
			modelAndViewObj.setViewName("liuSearchPage");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return modelAndViewObj;
	}

	@RequestMapping(value = "/updateLIUAccountDetails", method = RequestMethod.POST)
	public ModelAndView updateLIUAccountDetails(ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		LIUlogger.info("Entered updateLIUAccountDetails at LIU controller");

		ModelAndView modelAndViewObj = new ModelAndView();

		String action = "UPDATE";
		int pageNumber = 1;
		Long SNo = 0l;
		session = request.getSession(true);
		String userId = session.getAttribute("userid").toString();
		String sessionId = session.getId();

		LIUlogger.info("SessionId from updateLIUAccountDetails at LIU controller:" + sessionId);

		List<LIURecordDetails> liuList = new ArrayList<LIURecordDetails>();
		List<LIURecordDetails> liuRecordsListUpdated = new ArrayList<LIURecordDetails>();
		List<LIURecordDetails> eCollectAccountMapList = new ArrayList<LIURecordDetails>();
		List<LIURecordDetails> liuInputFxList = new ArrayList<LIURecordDetails>();
		LIURecordDetails liuFinalFxObj = null;

		try {

			// int SNo=activityDao.insertActivityLog(0,userId,"Updating LIU
			// Record",null,null,original,null,null);

			LIUlogger.info("Entered updateLIUAccountDetails at LIU controller ");

			List<String> liuReasonList = liuRecordsDaoObj.liuReasonDropdown();
			if (liuReasonList == null) {

				LIUlogger.info("Data Base Issues For ReasonList");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuPayModeList = liuRecordsDaoObj.liuPayModeDropdown();
			if (liuPayModeList == null) {
				LIUlogger.info("Data Base Issues For  Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}
			List<String> liuStatusList = liuRecordsDaoObj.liuStatusDropdown();
			if (liuStatusList == null) {
				LIUlogger.info("Data Base Issues For  Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<LIURecordDetails> liuPaymentCurrencyList = liuRecordsDaoObj.liuPaymentCurrency();
			if (liuPaymentCurrencyList == null) {
				LIUlogger.info("Data Base Issues For  Payment Currency!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuFileList = liuRecordsDaoObj.liuFilenameList();
			if (liuFileList == null) {
				LIUlogger.info("Data Base Issues For File List!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			String[] keyValuePairs = request.getParameterValues("updatedValues");

			LIUlogger.info("KEY VALUES NUMBER:" + keyValuePairs.length);

			List<String> UpdatedValues = new ArrayList<String>();

			if (keyValuePairs != null) {
				UpdatedValues = Arrays.asList(keyValuePairs);

				for (String valuesObj : UpdatedValues) {

					String[] arrayOfUpdatedValues = valuesObj.split("\\$");
					LIUlogger.info("Length Of Updated Values:" + arrayOfUpdatedValues.length);
					for (int i = 0; i < arrayOfUpdatedValues.length; i++) {
						LIUlogger.info("ARRAY OF UPDATED VALUES:" + arrayOfUpdatedValues[i]);
					}
					LIURecordDetails liuObj = new LIURecordDetails();
					liuObj.setLiuTrackingID(Long.parseLong(arrayOfUpdatedValues[0]));
					liuObj.setRemitterIFSC(arrayOfUpdatedValues[1]);
					liuObj.setB2b_b2c_Segment(arrayOfUpdatedValues[2]);
					liuObj.setPaymentAmount(Double.parseDouble(arrayOfUpdatedValues[3]));
					liuObj.setPaymentMode(arrayOfUpdatedValues[4]);
					liuObj.setOldExchangeRate(Double.parseDouble(arrayOfUpdatedValues[5]));
					liuObj.setAccountExtID(arrayOfUpdatedValues[6]);
					liuObj.setInvoiceNumber(arrayOfUpdatedValues[7]);
					liuObj.setPayment_currency(arrayOfUpdatedValues[8]);
					liuObj.setExchange_rate(Double.parseDouble(arrayOfUpdatedValues[9]));
					liuObj.setOrderNumber(Long.parseLong(arrayOfUpdatedValues[10]));
					liuObj.setFileID(arrayOfUpdatedValues[11]);
					liuObj.setRecordId(Long.parseLong(arrayOfUpdatedValues[12]));
					liuObj.setReferenceID(arrayOfUpdatedValues[13]);
					liuObj.setCustBankAccNo(arrayOfUpdatedValues[14]);
					liuObj.setLiuReason(arrayOfUpdatedValues[15]);
					liuObj.setPaymentCode(Long.parseLong(arrayOfUpdatedValues[16]));
					liuObj.setAmountInINR(Double.parseDouble(arrayOfUpdatedValues[17]));
					liuObj.setIncomingTransRefNum(arrayOfUpdatedValues[18]);
					liuObj.setRemitterBranch(arrayOfUpdatedValues[19]);
					liuObj.setReceiverIFSC(arrayOfUpdatedValues[20]);
					liuObj.setRemitterAcctNum(arrayOfUpdatedValues[21]);
					// liuObj.setEffectivePaymentAmount(Float.parseFloat(arrayOfUpdatedValues[22]));

					liuList.add(liuObj);
				}

				eCollectAccountMapList = liuRecordsDaoObj.eCollectAccountMapNeftCheck(liuList, action, pageNumber);

				if (eCollectAccountMapList == null) {
					LIUlogger.info("Data Base Issues...Exception in caduserLIU");
					modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
					modelAndViewObj.addObject("currentPage", pageNumber);
					modelAndViewObj.addObject("liuReasonList", liuReasonList);
					modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
					modelAndViewObj.addObject("liuStatusList", liuStatusList);
					modelAndViewObj.addObject("liuFileList", liuFileList);
					modelAndViewObj.setViewName("liuResultPage");
					return modelAndViewObj;
				}

				/*
				 * for(LIURecordDetails liuInputFxObj:eCollectAccountMapList) {
				 * 
				 * liuFinalFxObj=liuRecordsDaoObj.validationsFromFX(
				 * liuInputFxObj); liuInputFxList.add(liuFinalFxObj); }
				 */

				for (LIURecordDetails liuInputFxObj : eCollectAccountMapList) {

					LIUlogger.info("Paymode and Remarks from DB for tracking_id:" + liuInputFxObj.getLiuTrackingID()
					+ " are:" + liuInputFxObj.getPaymentMode() + "," + liuInputFxObj.getRemarks() + ""
					+ liuInputFxObj.getEffectivePaymentAmount());

					if ((liuInputFxObj.getPaymentMode().equalsIgnoreCase("NEFT")
							&& liuInputFxObj.getRemarks().equalsIgnoreCase("SUCCESS")) ||

							liuInputFxObj.getPaymentMode().equalsIgnoreCase("CHEQUE") ||

							liuInputFxObj.getPaymentMode().equalsIgnoreCase("OTHERS"))

						/*
						 * if((liuInputFxObj.getPaymentMode().equalsIgnoreCase(
						 * "NEFT") &&
						 * liuInputFxObj.getRemarks().equalsIgnoreCase("SUCCESS")))
						 */

					{
						LIUlogger.info("In if loop of for in fx hitting");

						liuFinalFxObj = liuRecordsDaoObj.validationsFromFX(liuInputFxObj);

						LIUlogger.info("Effective amount in eai call @ Controller:"
								+ liuFinalFxObj.getEffectivePaymentAmount());

						LIUlogger.info("Final tracking Id:" + liuFinalFxObj.getLiuTrackingID());

						liuInputFxList.add(liuFinalFxObj);

					}

					else {
						LIUlogger.info("TRACKING ID IN ELSE CONDITION OF FX HITTING LOOP::"
								+ liuInputFxObj.getLiuTrackingID());
						LIUlogger.info("REMARKS IN ELSE CONDITION OF FX HITTING LOOP::" + liuInputFxObj.getRemarks());

						liuInputFxList.add(liuInputFxObj);

					}

				}

				liuRecordsListUpdated = liuRecordsDaoObj.modifiedLIUDetails(liuInputFxList, userId, sessionId, action,
						pageNumber);

				if (liuRecordsListUpdated == null) {
					LIUlogger.info("Data Base Issues...Exception in caduserLIU");
					modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
					modelAndViewObj.addObject("currentPage", pageNumber);
					modelAndViewObj.addObject("liuReasonList", liuReasonList);
					modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
					modelAndViewObj.addObject("liuStatusList", liuStatusList);
					modelAndViewObj.addObject("liuFileList", liuFileList);
					modelAndViewObj.setViewName("liuResultPage");
					return modelAndViewObj;
				}

				LIURecordDetails errorObj = null;
				for (int i = 0; i < liuRecordsListUpdated.size(); i++)

				{
					errorObj = liuRecordsListUpdated.get(i);
					errorObj.getErrorMsg();
				}
				String errorMsg = errorObj.getErrorMsg();

				if (errorMsg != null) {
					if (errorMsg.equalsIgnoreCase("SUCCESS")) {
						errorMsg = "";
					} else
						errorMsg = "No records Found";
				} else
					errorMsg = "Connectivity Issues..Retry..";

			} // IF( KEUVALUES PAIRS ARE NOT NULL VALUES)

			for (int i = 0; i < liuRecordsListUpdated.size(); i++)

			{

				LIURecordDetails liuRecordDetailsObj = liuRecordsListUpdated.get(i);

				liuRecordDetailsObj.getRemarks();
				LIUlogger.info("REMARKS:" + liuRecordDetailsObj.getRemarks());

				if (liuRecordDetailsObj.getRemarks() != null
						&& liuRecordDetailsObj.getRemarks().equalsIgnoreCase("SUCCESS")) {
					SNo = activityDao.insertActivityLog(0l, userId, "Updating LIU Record", null, null, null, null,
							null);
					SNo = activityDao.insertActivityLog(SNo, userId, "Updating LIU Record", "Success", "Record Updated",
							null, null, null);

				} else {
					SNo = activityDao.insertActivityLog(0l, userId, "Updating LIU Record", null, null, null, null,
							null);
					SNo = activityDao.insertActivityLog(SNo, userId, "Updating LIU Record", "Failure",
							"Record is NOT Updated", null, null, null);

				}

			}

			LIUlogger.info("VALUES ARE UPDATED AND RETRIEVED AT CONTROLLER..");

			if (UpdatedValues != null) {
				for (int i = 0; i < UpdatedValues.size(); i++) {
					LIUlogger.info("VALUES IN ROW " + (i + 1) + " ARE:" + UpdatedValues.get(i));
				}
			}

			modelAndViewObj.addObject("liuReasonList", liuReasonList);
			modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
			modelAndViewObj.addObject("liuStatusList", liuStatusList);
			modelAndViewObj.addObject("liuPaymentCurrencyList", liuPaymentCurrencyList);
			modelAndViewObj.addObject("liuRecordsListModified", liuRecordsListUpdated);
			modelAndViewObj.addObject("errorMsg", "");
			modelAndViewObj.addObject("liuFileList", liuFileList);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.setViewName("liuResultPage");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return modelAndViewObj;
	}

	@RequestMapping(value = "/deleteLIUAccountDetails", method = RequestMethod.POST)
	public ModelAndView deleteLIUAccountDetails(ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		String action = "DELETE";
		int pageNumber = 1;
		session = request.getSession(true);
		String userId = session.getAttribute("userid").toString();
		String sessionId = session.getId();

		ModelAndView modelAndViewObj = new ModelAndView();
		List<LIURecordDetails> liuRecordsListDeleted = new ArrayList<LIURecordDetails>();
		List<LIURecordDetails> liuDeleteList = new ArrayList<LIURecordDetails>();
		Long SNo = 0l;
		try {
			// int SNo=activityDao.insertActivityLog(0,userId,"Deleting LIU
			// Record",null,null);

			LIUlogger.info("ENTERED INTO DELETE ACCOUNT DETAILS AT CONTROLLER");

			List<String> liuReasonList = liuRecordsDaoObj.liuReasonDropdown();
			if (liuReasonList == null) {
				LIUlogger.info("Data Base Issues For ReasonList");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuPayModeList = liuRecordsDaoObj.liuPayModeDropdown();
			if (liuPayModeList == null) {
				LIUlogger.info("Data Base Issues For  Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuStatusList = liuRecordsDaoObj.liuStatusDropdown();
			if (liuStatusList == null) {
				LIUlogger.info("Data Base Issues For  Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<LIURecordDetails> liuPaymentCurrencyList = liuRecordsDaoObj.liuPaymentCurrency();
			if (liuPaymentCurrencyList == null) {
				LIUlogger.info("Data Base Issues For  Payment Currency!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuFileList = liuRecordsDaoObj.liuFilenameList();
			if (liuFileList == null) {
				LIUlogger.info("Data Base Issues For File List!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			String[] keyValuePairs = request.getParameterValues("deletedValues");
			List<String> deletedValues = new ArrayList<String>();

			if (keyValuePairs != null) {
				deletedValues = Arrays.asList(keyValuePairs);

				for (String valuesObj : deletedValues) {
					LIURecordDetails liuDeleteObj = new LIURecordDetails();
					String[] arrayOfDeletedValues = valuesObj.split("\\$");

					LIUlogger.info("LENGTH:" + arrayOfDeletedValues.length);
					for (int i = 0; i < arrayOfDeletedValues.length; i++) {
						LIUlogger.info("ARRAY OF DELETED VALUES:" + arrayOfDeletedValues[i]);
					}

					liuDeleteObj.setLiuTrackingID(Long.parseLong(arrayOfDeletedValues[0]));
					liuDeleteObj.setRemitterIFSC(arrayOfDeletedValues[1]);
					liuDeleteObj.setB2b_b2c_Segment(arrayOfDeletedValues[2]);
					liuDeleteObj.setPaymentAmount(Double.parseDouble(arrayOfDeletedValues[3]));
					liuDeleteObj.setPaymentMode(arrayOfDeletedValues[4]);
					liuDeleteObj.setOldExchangeRate(Double.parseDouble(arrayOfDeletedValues[5]));
					liuDeleteObj.setAccountExtID(arrayOfDeletedValues[6]);
					liuDeleteObj.setInvoiceNumber(arrayOfDeletedValues[7]);
					liuDeleteObj.setPayment_currency(arrayOfDeletedValues[8]);
					liuDeleteObj.setExchange_rate(Double.parseDouble(arrayOfDeletedValues[9]));
					liuDeleteObj.setOrderNumber(Long.parseLong(arrayOfDeletedValues[10]));
					liuDeleteObj.setFileID(arrayOfDeletedValues[11]);
					liuDeleteObj.setRecordId(Long.parseLong(arrayOfDeletedValues[12]));
					liuDeleteObj.setReferenceID(arrayOfDeletedValues[13]);
					liuDeleteObj.setCustBankAccNo(arrayOfDeletedValues[14]);
					liuDeleteObj.setLiuReason(arrayOfDeletedValues[15]);
					liuDeleteObj.setPaymentCode(Long.parseLong(arrayOfDeletedValues[16]));
					liuDeleteObj.setAmountInINR(Double.parseDouble(arrayOfDeletedValues[17]));
					liuDeleteObj.setIncomingTransRefNum(arrayOfDeletedValues[18]);
					liuDeleteObj.setRemitterBranch(arrayOfDeletedValues[19]);
					liuDeleteObj.setReceiverIFSC(arrayOfDeletedValues[20]);
					liuDeleteObj.setRemitterAcctNum(arrayOfDeletedValues[21]);
					// liuDeleteObj.setEffectivePaymentAmount(Float.parseFloat(arrayOfDeletedValues[22]));

					liuDeleteList.add(liuDeleteObj);

				}
			}
			liuRecordsListDeleted = liuRecordsDaoObj.modifiedLIUDetails(liuDeleteList, userId, sessionId, action,
					pageNumber);
			if (liuRecordsListDeleted == null) {
				LIUlogger.info("Data Base Issues...Exception in caduserLIU");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("liuReasonList", liuReasonList);
				modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
				modelAndViewObj.addObject("liuStatusList", liuStatusList);
				modelAndViewObj.addObject("liuFileList", liuFileList);
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			LIURecordDetails errorObj = null;
			for (int i = 0; i < liuRecordsListDeleted.size(); i++)

			{
				errorObj = liuRecordsListDeleted.get(i);
				errorObj.getErrorMsg();
			}
			String errorMsg = errorObj.getErrorMsg();

			if (errorMsg != null) {
				if (errorMsg.equalsIgnoreCase("SUCCESS")) {
					errorMsg = "";
				} else
					errorMsg = "No records Found";
			} else
				errorMsg = "Connectivity Issues..Retry..";

			for (int i = 0; i < liuRecordsListDeleted.size(); i++)

			{

				LIURecordDetails liuRecordDetailsObj = liuRecordsListDeleted.get(i);

				liuRecordDetailsObj.getRemarks();
				LIUlogger.info("Remarks at DeleteLiuDetails:" + liuRecordDetailsObj.getRemarks());

				if (liuRecordDetailsObj.getRemarks().equalsIgnoreCase("DELETE SUCCESS")) {
					SNo = activityDao.insertActivityLog(0l, userId, "Deleting LIU Record", null, null, null, null,
							null);
					SNo = activityDao.insertActivityLog(SNo, userId, "Deleting LIU Record", "Success", "Record Deleted",
							null, null, null);

				} else {
					SNo = activityDao.insertActivityLog(0l, userId, "Deleting LIU Record", null, null, null, null,
							null);
					SNo = activityDao.insertActivityLog(SNo, userId, "Deleting LIU Record", "Failure",
							"Record is not Deleted", null, null, null);

				}

			}

			LIUlogger.info("Values are deleted and retrieved @contoller!!!!");
			if (deletedValues != null) {
				for (int i = 0; i < deletedValues.size(); i++) {
					LIUlogger.info("VALUES IN ROW " + (i + 1) + " are::" + deletedValues.get(i));
				}
			}
			modelAndViewObj.addObject("liuReasonList", liuReasonList);
			modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
			modelAndViewObj.addObject("liuStatusList", liuStatusList);
			modelAndViewObj.addObject("liuPaymentCurrencyList", liuPaymentCurrencyList);
			modelAndViewObj.addObject("liuRecordsListModified", liuRecordsListDeleted);
			modelAndViewObj.addObject("errorMsg", "");
			modelAndViewObj.addObject("liuFileList", liuFileList);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.setViewName("liuResultPage");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return modelAndViewObj;
	}

	@RequestMapping(value = "/exportToExcel", method = RequestMethod.POST)
	public ModelAndView exportToExcel(ModelMap model, HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndViewObj = new ModelAndView();
		LIURecordDetails searchDetailsObj3 = new LIURecordDetails();

		try {

			LIUlogger.info("Entered exportToExcel mapping at controller");

			String page = null;

			List<String> liuReasonList = liuRecordsDaoObj.liuReasonDropdown();
			if (liuReasonList == null) {
				LIUlogger.info("Data Base Issues For ReasonList");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuPayModeList = liuRecordsDaoObj.liuPayModeDropdown();
			if (liuPayModeList == null) {
				LIUlogger.info("Data Base Issues For  Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuStatusList = liuRecordsDaoObj.liuStatusDropdown();
			if (liuStatusList == null) {
				LIUlogger.info("Data Base Issues For  Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			List<String> liuFileList = liuRecordsDaoObj.liuFilenameList();
			if (liuFileList == null) {
				LIUlogger.info("Data Base Issues For File List!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			String paymentMode = request.getParameter("paymentMode");
			String referenceId = request.getParameter("refID");
			String remitterIfsc = request.getParameter("ifscCode");
			String acctNum = request.getParameter("accountNumber");
			String liuReason = request.getParameter("liuReason");
			String fromDate = request.getParameter("startDate");
			String toDate = request.getParameter("endDate");
			String liu_Status = request.getParameter("liuStatus");
			String userId = request.getParameter("userID");
			String fileName = request.getParameter("fileName");

			searchDetailsObj3.setPaymentMode(paymentMode);

			if (referenceId == null || referenceId.equals(""))
				searchDetailsObj3.setReferenceID(null);
			else
				searchDetailsObj3.setReferenceID(referenceId.trim());

			if (paymentMode != null) {
				if (paymentMode.equalsIgnoreCase("CHEQUE")) {
					if (remitterIfsc == null || remitterIfsc.equals(""))
						searchDetailsObj3.setRemitterIFSC(null);
					else
						searchDetailsObj3.setRemitterIFSC(remitterIfsc.trim());
				}

				else
					searchDetailsObj3.setRemitterIFSC(null);
			}

			if (acctNum == null || acctNum.equals(""))
				searchDetailsObj3.setAccountExtID(null);
			else
				searchDetailsObj3.setAccountExtID(acctNum.trim());

			searchDetailsObj3.setLiuReason(liuReason);

			if (fromDate == null || fromDate.equals(""))
				searchDetailsObj3.setFromDate(null);
			else
				searchDetailsObj3.setFromDate(fromDate);

			if (toDate == null || toDate.equals(""))
				searchDetailsObj3.setToDate(null);
			else
				searchDetailsObj3.setToDate(toDate);

			if (liu_Status != null)
				searchDetailsObj3.setLiuStatus(liu_Status);

			if (fileName != null)
				searchDetailsObj3.setFileName(fileName.trim());

			if (userId == null || userId.equals(""))
				searchDetailsObj3.setUserID(null);
			else
				searchDetailsObj3.setUserID(userId.trim());

			LIUlogger.info("UTR NUMBER FROM JSP:" + request.getParameter("refID"));
			LIUlogger.info(" IFSC CODE FROM JSP:" + request.getParameter("ifscCode"));
			LIUlogger.info("ACCOUNT NUMBER FROM JSP:" + request.getParameter("accountNumber"));
			LIUlogger.info("LIU REASON FROM JSP:" + request.getParameter("liuReason"));
			LIUlogger.info("START DATE FROM JSP:" + request.getParameter("startDate"));
			LIUlogger.info("END DATE FROM JSP:" + request.getParameter("endDate"));
			LIUlogger.info(" LIU STATUS FROM JSP:" + request.getParameter("liuStatus"));
			LIUlogger.info(" FILE NAME FROM JSP:" + request.getParameter("fileName"));
			LIUlogger.info("PAYMENT MODE FROM JSP:" + request.getParameter("paymentMode"));
			LIUlogger.info(" USER ID FROM JSP:" + request.getParameter("userID"));

			LIURecordDetails liuFileObj = liuRecordsDaoObj.downloadedFile(searchDetailsObj3,
					/* downloadedFilesPath, */ extension, page);

			String errorMsg = searchDetailsObj3.getErrorMsg();
			LIUlogger.info("Error Message in exportToExcel mapping at controller " + errorMsg);

			if (errorMsg != null) {
				if (errorMsg.equalsIgnoreCase("SUCCESS")) {
					errorMsg = "";
				} else
					errorMsg = "No records Found";
			} else
				errorMsg = "Connectivity Issues..Retry..";

			if (liuFileObj == null) {
				LIUlogger.info("Data Base Issues...Exception in exportToExcel");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("liuReasonList", liuReasonList);
				modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
				modelAndViewObj.addObject("liuStatusList", liuStatusList);
				modelAndViewObj.addObject("liuFileList", liuFileList);
				modelAndViewObj.setViewName("liuResultPage");
				return modelAndViewObj;
			}

			/*
			 * String filePath=downloadedFilesPath;
			 * logger.info("Filepath is:"+filePath);
			 */

			String filename = "APS_" + liuFileObj.getLiuStatus() + "_" + liuRecordsDaoObj.getDateTime() + "."
					+ extension;
			LIUlogger.info("Filename:" + filename);

			// String finalPath=/*filePath+"\\"+*/filename;

			ServletOutputStream out = response.getOutputStream();
			FileInputStream in = new FileInputStream(filename);
			LIUlogger.info("File name:" + in);

			response.setContentType("APPLICATION/OCTET-STREAM");

			response.addHeader("content-disposition", "attachment; filename=" + filename);

			LIUlogger.info("Process completed and fetched file at controller");

			int octet;
			while ((octet = in.read()) != -1)
				out.write(octet);

			in.close();
			out.flush();
			out.close();
			response.flushBuffer();
			LIUlogger.info("Finished execution of export to excel in liu controller ");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return modelAndViewObj;
	}

	/***************************Aps homes liu changes****************************************************/

	@RequestMapping(value = "/apsLiu", method = RequestMethod.GET)
	public ModelAndView getApsLiu(HttpServletRequest request) {

		ModelAndView modelAndViewObj= new ModelAndView();

		LIURecordDetails defaultRecordsObj1=new LIURecordDetails();

		try
		{
			LIUlogger.info("Entered into caduserLIU mapping at CONTROLLER)");			    
			int pageNumber = 1;
			LIUlogger.info("PageNumber at showLiuCases:"+pageNumber);

			List<String> liuReasonList=liuRecordsDaoObj.liuReasonDropdown();
			if(liuReasonList==null)
			{
				LIUlogger.info("Data Base Issues For ReasonList");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}

			List<String> liuPayModeList=liuRecordsDaoObj.liuPayModeDropdown();
			if(liuPayModeList==null)
			{
				LIUlogger.info("Data Base Issues For Payment Mode!");

				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}

			List<String> liuStatusList=liuRecordsDaoObj.liuStatusDropdown();
			if(liuStatusList==null)
			{
				LIUlogger.info("Data Base Issues For Status!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}

			List<LIURecordDetails> liuPaymentCurrencyList=liuRecordsDaoObj.liuPaymentCurrency();
			if(liuPaymentCurrencyList==null)
			{
				LIUlogger.info("Data Base Issues For Payment Currency!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}

			List<String> liuFileList=liuRecordsDaoObj.liuApsFilenameList(); 
			if(liuFileList==null)
			{
				LIUlogger.info("Data Base Issues For File List!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}


			defaultRecordsObj1.setLiuStatus("LIU PENDING");

			String liuStatus="LIU PENDING";

			String paymentMode = request.getParameter("paymentMode");
			//System.out.println("PAYMENT MODE FROM JSP:"+ request.getParameter("paymentMode"));


			String remitterIfsc= request.getParameter("ifscCode");
			String referenceId= request.getParameter("refID");
			String acctNum=request.getParameter("accountNumber");
			String liuReason=request.getParameter("liuReason");
			String fromDate=request.getParameter("startDate");
			String toDate=request.getParameter("endDate");
			String liu_Status=request.getParameter("liuStatus");
			String userId=request.getParameter("userID");
			String fileName=request.getParameter("fileName");


			defaultRecordsObj1.setPaymentMode(paymentMode);

			if(referenceId == null || referenceId.equals(""))
				defaultRecordsObj1.setReferenceID(null);
			else
				defaultRecordsObj1.setReferenceID(referenceId.trim());

			if(paymentMode!=null)
			{
				if(paymentMode.equalsIgnoreCase("CHEQUE"))
				{
					if(remitterIfsc == null || remitterIfsc.equals(""))     
						defaultRecordsObj1.setRemitterIFSC(null);
					else
						defaultRecordsObj1.setRemitterIFSC(remitterIfsc.trim());
				}

				else
					defaultRecordsObj1.setRemitterIFSC(null);
			}

			if(acctNum == null || acctNum.equals(""))
				defaultRecordsObj1.setAccountExtID(null);
			else
				defaultRecordsObj1.setAccountExtID(acctNum.trim());

			defaultRecordsObj1.setLiuReason(liuReason);

			if(fromDate == null|| fromDate.equals(""))   
				defaultRecordsObj1.setFromDate(null);
			else
				defaultRecordsObj1.setFromDate(fromDate);

			if(toDate == null|| toDate.equals(""))   
				defaultRecordsObj1.setToDate(null);
			else
				defaultRecordsObj1.setToDate(toDate);   

			if(liu_Status != null)    
				defaultRecordsObj1.setLiuStatus(liu_Status);


			if(fileName != null)
				defaultRecordsObj1.setFileName(fileName.trim());   

			if(userId == null || userId.equals(""))
				defaultRecordsObj1.setUserID(null);  
			else
				defaultRecordsObj1.setUserID(userId.trim());   



			LIUlogger.info("UTR NUMBER FROM JSP:"+ request.getParameter("refID"));
			LIUlogger.info(" IFSC CODE FROM JSP:"+ request.getParameter("ifscCode"));
			LIUlogger.info("ACCOUNT NUMBER FROM JSP:"+ request.getParameter("accountNumber"));
			LIUlogger.info("LIU REASON FROM JSP:"+ request.getParameter("liuReason"));
			LIUlogger.info("START DATE FROM JSP:"+ request.getParameter("startDate"));
			LIUlogger.info("END DATE FROM JSP:"+ request.getParameter("endDate"));
			LIUlogger.info(" LIU STATUS FROM JSP:"+ request.getParameter("liuStatus"));
			LIUlogger.info(" FILE NAME FROM JSP:"+ request.getParameter("fileName"));
			LIUlogger.info("PAYMENT MODE FROM JSP:"+ request.getParameter("paymentMode"));
			LIUlogger.info(" USER ID FROM JSP:"+ request.getParameter("userID"));


			HashMap<Integer, List<LIURecordDetails>> liuDetailsMap = liuRecordsDaoObj.liuApsRecordSearchFirstPage(pageNumber,defaultRecordsObj1);

			String errorMsg=defaultRecordsObj1.getErrorMsg();
			LIUlogger.info("Error message in caduserLIU mapping is"+errorMsg);


			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(liuDetailsMap==null)
			{
				LIUlogger.info("Data Base Issues...Exception in caduserLIU");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("liuReasonList", liuReasonList);
				modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
				modelAndViewObj.addObject("liuStatusList",liuStatusList);
				modelAndViewObj.addObject("liuFileList",liuFileList);
				modelAndViewObj.addObject("liuStatusMsg", liuStatus);
				modelAndViewObj.setViewName("viewApsLiuDetailsWithpage");
				return modelAndViewObj;
			}


			modelAndViewObj.addObject("liuDetailsMap", liuDetailsMap);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("liuReasonList", liuReasonList);
			modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
			modelAndViewObj.addObject("liuStatusList",liuStatusList);
			modelAndViewObj.addObject("liuPaymentCurrencyList",liuPaymentCurrencyList);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			modelAndViewObj.addObject("liuFileList",liuFileList);
			modelAndViewObj.addObject("liuStatusMsg", liuStatus);
			modelAndViewObj.setViewName("viewApsLiuDetailsWithpage");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return modelAndViewObj;
	}
	
	//Added by Danish for LIU upload
	@RequestMapping(value = "/uploadLIUFile"/*, method = RequestMethod.GET*/)
	public ModelAndView uploadLIUFile(ModelMap model,HttpServletRequest request, HttpServletResponse response,
			@RequestParam("file") MultipartFile file) 
	{
		LIUlogger.info("START ---->uploadLIUFile");
		MultipartFile multipartFile = file;
		ModelAndView modelAndViewObj = new ModelAndView("redirect:/apsLiu");
		InputStream inputStream = null;
		String fileName="",fileIdentifier = "LIU";
		String user = session.getAttribute("userid").toString();
		try {
		if(multipartFile!=null){
			fileName = multipartFile.getOriginalFilename();
			//fileIdentifier = fileName.substring(3, 6);
			LIUlogger.info("LIU controller File Name is "+fileName +" and file Identifier is "+fileIdentifier);
		        try {
		        	byte[] bytes = file.getBytes();
		        	inputStream = new ByteArrayInputStream(bytes);
		        }catch (IOException e) {
		        	LIUlogger.info(e);
		        }
		}
		LIUlogger.info("LIU controller fileName from UI"+fileName);
		String path = "";//salFilePath+File.separator+fileName;//getPath(fileIdentifier,"input","0",fileName);
		LIUlogger.info("LIU controller fileName to go in filestatus aps "+path);
		FileUploadResult fileUpload = excelReader.readFromExcelfile(fileName,fileIdentifier, "UI", user, "",inputStream,"Bulk",null,null);
		if(fileUpload.getStatus() == 1){
			//String filepath = getPath(fileIdentifier,"done",fileUpload.getFileId(),fileName);
			
			path =downloadpath+File.separator+fileName ;
			LIUlogger.info("LIU controller success file path is "+path);
			file.transferTo(new File(path));
		}
		else{
			path =errorFilesPath+File.separator+fileName ;
			LIUlogger.info("LIU controller error file path is "+path);
			file.transferTo(new File(path));
			
		}
		modelAndViewObj.addObject("message",fileUpload.getStatusDescription());
		/*modelAndViewObj.setViewName("viewFileAPS");*/
		//return new ModelAndView("redirect:/suspenseAllocation?message="+fileUpload.getStatusDescription());
		 return modelAndViewObj;
		}catch(Exception e) {
			LIUlogger.info(e);
		}
		 return modelAndViewObj;
	}

	public String getPath(String fileIdentifier,String folder,String fileId,String fileName){
		String path = "" ; String parentFolder ="";
		if(fileIdentifier.equalsIgnoreCase("LIU")){
			path = LIUFilepath + File.separator;
		}
		if(folder.equalsIgnoreCase("input")){
			fileName = ""+fileName;
		}else if(folder.equalsIgnoreCase("error")){
			fileName = fileName.substring(0,(fileName.lastIndexOf("."))+1);
			fileName = fileName+"xls";
			fileName = fileId+"_"+fileName;
		}else if(folder.equalsIgnoreCase("ctrl")){
			fileName = fileName.substring(0,(fileName.lastIndexOf("."))+1);
			fileName = fileName+"ctrl";
			fileName = fileId+"_"+fileName;
		}else if(folder.equalsIgnoreCase("FX1.2")){
			fileName = fileName.substring(0,(fileName.lastIndexOf("."))+1);
			fileName = fileName+"xls";
			fileName = fileId+"_"+fileName;
		}else{
			fileName = fileId+"_"+fileName;
		}
		String filepath = path+File.separator+fileName;
		return filepath;
	}
	
	
	@RequestMapping(value = "/liuApsRecordSearchFirstPage"/*, method = RequestMethod.GET*/)
	public ModelAndView liuApsRecordSearchFirstPage(ModelMap model,HttpServletRequest request, HttpServletResponse response) 
	{
		LIURecordDetails searchDetailsObj1=new LIURecordDetails();
		LIUlogger.info("ENTERED INTO LIU RECORD SEARCH FIRST PAGE (@CONTROLLER)");
		ModelAndView modelAndViewObj = new ModelAndView();
		int pageNumber=1;

		try {

			String paymentMode = request.getParameter("paymentMode");
			String referenceId= request.getParameter("refID");
			String remitterIfsc= request.getParameter("ifscCode");
			String acctNum=request.getParameter("accountNumber");
			String liuReason=request.getParameter("liuReason");
			String fromDate=request.getParameter("startDate");
			String toDate=request.getParameter("endDate");
			String liu_Status=request.getParameter("liuStatus");
			String userId=request.getParameter("userID");
			String fileName=request.getParameter("fileName");


			searchDetailsObj1.setPaymentMode(paymentMode);

			if(referenceId == null || referenceId.equals(""))
				searchDetailsObj1.setReferenceID(null);
			else
				searchDetailsObj1.setReferenceID(referenceId.trim());

			if(paymentMode!=null)
			{		
				if(paymentMode.equalsIgnoreCase("CHEQUE"))
				{
					if(remitterIfsc == null || remitterIfsc.equals(""))     
						searchDetailsObj1.setRemitterIFSC(null);
					else
						searchDetailsObj1.setRemitterIFSC(remitterIfsc.trim());
				}

				else
					searchDetailsObj1.setRemitterIFSC(null);
			}

			if(acctNum == null || acctNum.equals(""))
				searchDetailsObj1.setAccountExtID(null);
			else
				searchDetailsObj1.setAccountExtID(acctNum.trim());

			searchDetailsObj1.setLiuReason(liuReason);

			if(fromDate == null|| fromDate.equals(""))   
				searchDetailsObj1.setFromDate(null);
			else
				searchDetailsObj1.setFromDate(fromDate);

			if(toDate == null|| toDate.equals(""))   
				searchDetailsObj1.setToDate(null);
			else
				searchDetailsObj1.setToDate(toDate);   

			if(liu_Status != null)    
				searchDetailsObj1.setLiuStatus(liu_Status);


			if(fileName != null)
				searchDetailsObj1.setFileName(fileName.trim());   

			if(userId == null || userId.equals(""))
				searchDetailsObj1.setUserID(null);  
			else
				searchDetailsObj1.setUserID(userId.trim());   



			LIUlogger.info("UTR NUMBER FROM JSP:"+ request.getParameter("refID"));
			LIUlogger.info(" IFSC CODE FROM JSP:"+ request.getParameter("ifscCode"));
			LIUlogger.info("ACCOUNT NUMBER FROM JSP:"+ request.getParameter("accountNumber"));
			LIUlogger.info("LIU REASON FROM JSP:"+ request.getParameter("liuReason"));
			LIUlogger.info("START DATE FROM JSP:"+ request.getParameter("startDate"));
			LIUlogger.info("END DATE FROM JSP:"+ request.getParameter("endDate"));
			LIUlogger.info(" LIU STATUS FROM JSP:"+ request.getParameter("liuStatus"));
			LIUlogger.info(" FILE NAME FROM JSP:"+ request.getParameter("fileName"));
			LIUlogger.info("PAYMENT MODE FROM JSP:"+ request.getParameter("paymentMode"));
			LIUlogger.info(" USER ID FROM JSP:"+ request.getParameter("userID"));


			List<String> liuReasonList=liuRecordsDaoObj.liuReasonDropdown();
			if(liuReasonList==null)
			{
				LIUlogger.info("Data Base Issues For ReasonList");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}

			List<String> liuPayModeList=liuRecordsDaoObj.liuPayModeDropdown(); 
			if(liuPayModeList==null)
			{
				LIUlogger.info("Data Base Issues For Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}

			List<String> liuStatusList=liuRecordsDaoObj.liuStatusDropdown();
			if(liuStatusList==null)
			{
				LIUlogger.info("Data Base Issues For  liuStatus!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}


			List<LIURecordDetails> liuPaymentCurrencyList=liuRecordsDaoObj.liuPaymentCurrency();
			if(liuPaymentCurrencyList==null)
			{
				LIUlogger.info("Data Base Issues For  Payment Currency!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}


			List<String> liuFileList=liuRecordsDaoObj.liuApsFilenameList(); 
			if(liuFileList==null)
			{
				LIUlogger.info("Data Base Issues For File List!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}

			liuRecordDetailsMap=liuRecordsDaoObj.liuApsRecordSearchFirstPage(pageNumber, searchDetailsObj1);

			String errorMsg=searchDetailsObj1.getErrorMsg();
			LIUlogger.info("Error message at liuRecordSearchFirstPage requestMapping in controller:"+errorMsg);

			String liuStatus=searchDetailsObj1.getLiuStatus();

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(liuRecordDetailsMap==null)
			{
				LIUlogger.info("Data Base Issues...Exception in caduserLIU");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("liuReasonList", liuReasonList);
				modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
				modelAndViewObj.addObject("liuStatusList",liuStatusList);
				modelAndViewObj.addObject("liuFileList",liuFileList);
				modelAndViewObj.addObject("liuStatusMsg", liuStatus);
				modelAndViewObj.setViewName("liuApsSearchPage");
				return modelAndViewObj;
			}


			modelAndViewObj.addObject("liuRecordDetailsMap",liuRecordDetailsMap);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("liuReasonList", liuReasonList);
			modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
			modelAndViewObj.addObject("liuStatusList",liuStatusList);
			modelAndViewObj.addObject("liuPaymentCurrencyList",liuPaymentCurrencyList);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			modelAndViewObj.addObject("liuStatusMsg", liuStatus);
			modelAndViewObj.addObject("liuFileList",liuFileList);
			modelAndViewObj.addObject("liuRecordDetailsObjJsp", searchDetailsObj1);
			modelAndViewObj.setViewName("liuApsSearchPage");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return modelAndViewObj;
	}

	@RequestMapping(value = "/liuApsRecordsForNextAndPrevious")
	public ModelAndView liuApsRecordsForNextAndPrevious(ModelMap model,HttpServletRequest request, HttpServletResponse response) 
	{
		LIURecordDetails searchDetailsObj2=new LIURecordDetails();

		ModelAndView modelAndViewObj = new ModelAndView();
		LIUlogger.info("Entered liuRecordsForNextAndPrevious mapping at LIU controller");

		try {

			int pageNumber = Integer.parseInt(request.getParameter("pageNumber"));

			List<String> liuReasonList=liuRecordsDaoObj.liuReasonDropdown();
			if(liuReasonList==null)
			{
				LIUlogger.info("Data Base Issues For ReasonList");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}

			List<String> liuPayModeList=liuRecordsDaoObj.liuPayModeDropdown();
			if(liuPayModeList==null)
			{
				LIUlogger.info("Data Base Issues For  Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}

			List<String> liuStatusList=liuRecordsDaoObj.liuStatusDropdown();
			if(liuStatusList==null)
			{
				LIUlogger.info("Data Base Issues For  Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}



			List<LIURecordDetails> liuPaymentCurrencyList=liuRecordsDaoObj.liuPaymentCurrency();
			if(liuPaymentCurrencyList==null)
			{
				LIUlogger.info("Data Base Issues For Payment Currency!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}

			List<String> liuFileList=liuRecordsDaoObj.liuApsFilenameList(); 
			if(liuFileList==null)
			{
				LIUlogger.info("Data Base Issues For File List!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}

			String paymentMode = request.getParameter("paymentMode");
			String referenceId= request.getParameter("refID");
			String remitterIfsc= request.getParameter("ifscCode");
			String acctNum=request.getParameter("accountNumber");
			String liuReason=request.getParameter("liuReason");
			String fromDate=request.getParameter("startDate");
			String toDate=request.getParameter("endDate");
			String liu_Status=request.getParameter("liuStatus");
			String userId=request.getParameter("userID");
			String fileName=request.getParameter("fileName");


			LIUlogger.info("UTR NUMBER FROM JSP:"+ request.getParameter("refID"));
			LIUlogger.info(" IFSC CODE FROM JSP:"+ request.getParameter("ifscCode"));
			LIUlogger.info("ACCOUNT NUMBER FROM JSP:"+ request.getParameter("accountNumber"));
			LIUlogger.info("LIU REASON FROM JSP:"+ request.getParameter("liuReason"));
			LIUlogger.info("START DATE FROM JSP:"+ request.getParameter("startDate"));
			LIUlogger.info("END DATE FROM JSP:"+ request.getParameter("endDate"));
			LIUlogger.info(" LIU STATUS FROM JSP:"+ request.getParameter("liuStatus"));
			LIUlogger.info(" FILE NAME FROM JSP:"+ request.getParameter("fileName"));
			LIUlogger.info("PAYMENT MODE FROM JSP:"+ request.getParameter("paymentMode"));
			LIUlogger.info(" USER ID FROM JSP:"+ request.getParameter("userID"));

			searchDetailsObj2.setPaymentMode(paymentMode);

			if(referenceId == null || referenceId.equals(""))
				searchDetailsObj2.setReferenceID(null);
			else
				searchDetailsObj2.setReferenceID(referenceId.trim());


			if(paymentMode!=null)
			{				
				if(paymentMode.equalsIgnoreCase("CHEQUE"))
				{
					if(remitterIfsc == null || remitterIfsc.equals(""))     
						searchDetailsObj2.setRemitterIFSC(null);
					else
						searchDetailsObj2.setRemitterIFSC(remitterIfsc.trim());
				}

				else
					searchDetailsObj2.setRemitterIFSC(null);
			}	

			if(acctNum == null || acctNum.equals(""))
				searchDetailsObj2.setAccountExtID(null);
			else
				searchDetailsObj2.setAccountExtID(acctNum.trim());

			searchDetailsObj2.setLiuReason(liuReason);

			if(fromDate == null|| fromDate.equals(""))   
				searchDetailsObj2.setFromDate(null);
			else
				searchDetailsObj2.setFromDate(fromDate);

			if(toDate == null|| toDate.equals(""))   
				searchDetailsObj2.setToDate(null);
			else
				searchDetailsObj2.setToDate(toDate);   

			if(liu_Status != null)    
				searchDetailsObj2.setLiuStatus(liu_Status);


			if(fileName != null)
				searchDetailsObj2.setFileName(fileName.trim());   

			if(userId == null || userId.equals(""))
				searchDetailsObj2.setUserID(null);  
			else
				searchDetailsObj2.setUserID(userId.trim());   



			LIUlogger.info("UTR NUMBER FROM JSP:"+ request.getParameter("refID"));
			LIUlogger.info(" IFSC CODE FROM JSP:"+ request.getParameter("ifscCode"));
			LIUlogger.info("ACCOUNT NUMBER FROM JSP:"+ request.getParameter("accountNumber"));
			LIUlogger.info("LIU REASON FROM JSP:"+ request.getParameter("liuReason"));
			LIUlogger.info("START DATE FROM JSP:"+ request.getParameter("startDate"));
			LIUlogger.info("END DATE FROM JSP:"+ request.getParameter("endDate"));
			LIUlogger.info(" LIU STATUS FROM JSP:"+ request.getParameter("liuStatus"));
			LIUlogger.info(" FILE NAME FROM JSP:"+ request.getParameter("fileName"));
			LIUlogger.info("PAYMENT MODE FROM JSP:"+ request.getParameter("paymentMode"));
			LIUlogger.info(" USER ID FROM JSP:"+ request.getParameter("userID"));


			HashMap<Integer, List<LIURecordDetails>> liuRecordDetailsMap=liuRecordsDaoObj.liuApsRecordSearchFirstPage(pageNumber, searchDetailsObj2);

			String errorMsg=searchDetailsObj2.getErrorMsg();
			LIUlogger.info("Error message at liuRecordsForNextAndPrevious requestMapping in controller:"+errorMsg);

			String liuStatus=searchDetailsObj2.getLiuStatus();

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(liuRecordDetailsMap==null)
			{
				LIUlogger.info("Data Base Issues...Exception in caduserLIU");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("liuReasonList", liuReasonList);
				modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
				modelAndViewObj.addObject("liuStatusList",liuStatusList);
				modelAndViewObj.addObject("liuFileList",liuFileList);
				modelAndViewObj.addObject("liuStatusMsg", liuStatus);
				modelAndViewObj.setViewName("liuApsSearchPage");
				return modelAndViewObj;
			}


			modelAndViewObj.addObject("liuRecordDetailsMap",liuRecordDetailsMap);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.addObject("liuReasonList", liuReasonList);
			modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
			modelAndViewObj.addObject("liuStatusList",liuStatusList);
			modelAndViewObj.addObject("liuPaymentCurrencyList",liuPaymentCurrencyList);
			modelAndViewObj.addObject("liuRecordDetailsObjJsp", searchDetailsObj2);
			modelAndViewObj.addObject("errorMsg", errorMsg);
			modelAndViewObj.addObject("liuFileList",liuFileList);
			modelAndViewObj.addObject("liuStatusMsg", liuStatus);
			modelAndViewObj.setViewName("liuApsSearchPage");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return modelAndViewObj;
	}


	@RequestMapping(value = "/updateApsLIUAccountDetails" ,method = RequestMethod.POST)
	public ModelAndView updateApsLIUAccountDetails(ModelMap model,HttpServletRequest request, HttpServletResponse response) 
	{
		LIUlogger.info("Entered updateLIUAccountDetails at LIU controller");
		System.out.println("in update aps liu my code");

		ModelAndView modelAndViewObj = new ModelAndView();
		String errorMsg="";
		String action="UPDATE";
		int pageNumber=1;
		Long SNo=0l;      		
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String sessionId=session.getId();

		LIUlogger.info("SessionId from updateLIUAccountDetails at LIU controller:"+sessionId);

		List<LIURecordDetails> liuList= new ArrayList<LIURecordDetails>();
		List<LIURecordDetails> liuRecordsListUpdated=null;

		LIURecordDetails LIURecordDetails=new LIURecordDetails();
		List<LIURecordDetails> eCollectAccountMapList=new ArrayList<LIURecordDetails>();
		List<LIURecordDetails> liuInputFxList=new ArrayList<LIURecordDetails>();
		List<String> liuReasons=new ArrayList();
		LIURecordDetails liuFinalFxObj=null;
		LIURecordDetails liuObj=null;


		try 
		{

			//	 int SNo=activityDao.insertActivityLog(0,userId,"Updating LIU Record",null,null,original,null,null);

			LIUlogger.info("Entered updateLIUAccountDetails at LIU controller ");

			List<String> liuReasonList=liuRecordsDaoObj.liuReasonDropdown();
			if(liuReasonList==null)
			{

				LIUlogger.info("Data Base Issues For ReasonList");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}

			List<String> liuPayModeList=liuRecordsDaoObj.liuPayModeDropdown();
			if(liuPayModeList==null)
			{
				LIUlogger.info("Data Base Issues For  Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}
			List<String> liuStatusList=liuRecordsDaoObj.liuStatusDropdown();
			if(liuStatusList==null)
			{
				LIUlogger.info("Data Base Issues For  Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}


			List<LIURecordDetails> liuPaymentCurrencyList=liuRecordsDaoObj.liuPaymentCurrency();
			if(liuPaymentCurrencyList==null)
			{
				LIUlogger.info("Data Base Issues For  Payment Currency!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}

			List<String> liuFileList=liuRecordsDaoObj.liuApsFilenameList(); 
			if(liuFileList==null)
			{
				LIUlogger.info("Data Base Issues For File List!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}


			String[] keyValuePairs=request.getParameterValues("updatedValues");

			LIUlogger.info("KEY VALUES NUMBER:" +keyValuePairs.length);

			List<String> UpdatedValues=new ArrayList<String>();


			
			if(keyValuePairs!=null)
			{
				UpdatedValues=Arrays.asList(keyValuePairs);
				LIUlogger.info("list size=>"+UpdatedValues.size());
				LIUlogger.info("list ->> "+UpdatedValues);
				liuRecordsListUpdated=new ArrayList<LIURecordDetails>();
				for(String valuesObj: UpdatedValues)
				{

					String[] arrayOfUpdatedValues=valuesObj.split("\\$");
					LIUlogger.info("Length Of Updated Values:"+arrayOfUpdatedValues.length);
					for(int i=0;i<arrayOfUpdatedValues.length;i++)
					{
						LIUlogger.info("ARRAY OF UPDATED VALUES:"+arrayOfUpdatedValues[i]);
					}
					liuObj=new LIURecordDetails();
					liuObj.setLiuTrackingID(Long.parseLong(arrayOfUpdatedValues[0]));
					liuObj.setRemitterIFSC(arrayOfUpdatedValues[1]);
					liuObj.setB2b_b2c_Segment(arrayOfUpdatedValues[2]);
					liuObj.setPaymentAmount(Double.parseDouble(arrayOfUpdatedValues[3]));
					liuObj.setPaymentMode(arrayOfUpdatedValues[4]);
					liuObj.setOldExchangeRate(Double.parseDouble(arrayOfUpdatedValues[5]));
					liuObj.setAccountExtID(arrayOfUpdatedValues[6]);
					liuObj.setInvoiceNumber(arrayOfUpdatedValues[7]);
					liuObj.setPayment_currency(arrayOfUpdatedValues[8]);
					liuObj.setExchange_rate(Double.parseDouble(arrayOfUpdatedValues[9]));
					liuObj.setOrderNumber(Long.parseLong(arrayOfUpdatedValues[10]));
					liuObj.setFileID(arrayOfUpdatedValues[11]);
					liuObj.setRecordId(Long.parseLong(arrayOfUpdatedValues[12]));
					liuObj.setReferenceID(arrayOfUpdatedValues[13]);
					liuObj.setCustBankAccNo(arrayOfUpdatedValues[14]);
					liuObj.setLiuReason(arrayOfUpdatedValues[15]);
					liuObj.setPaymentCode(Long.parseLong(arrayOfUpdatedValues[16]));
					liuObj.setAmountInINR(Double.parseDouble(arrayOfUpdatedValues[17]));
					liuObj.setIncomingTransRefNum(arrayOfUpdatedValues[18]);
					liuObj.setRemitterBranch(arrayOfUpdatedValues[19]);
					liuObj.setReceiverIFSC(arrayOfUpdatedValues[20]);
					liuObj.setRemitterAcctNum(arrayOfUpdatedValues[21]);
					liuObj.setDelNumber(arrayOfUpdatedValues[22]);

					//	  liuObj.setEffectivePaymentAmount(Float.parseFloat(arrayOfUpdatedValues[22]));
					System.out.println("liu reason is------------>>>>>>>>>>>>>>>>>"+liuObj.getLiuReason());
					System.out.println("record id is-------------->>>>>>>>>>>>>>"+liuObj.getRecordId());
					liuReasons.add(liuObj.getLiuReason());
					liuList.add(liuObj);

					
					String liuReason=liuObj.getLiuReason();
					if(liuReason.equalsIgnoreCase("INVALID ACCOUNT/MOBILE NO")||
							liuReason.equalsIgnoreCase("SEGMENT MAPPING NOT AVAILABLE")){
						for(LIURecordDetails liuInputFxObj:liuList)
						{
							liuFinalFxObj=liuRecordsDaoObj.validationsFromFXAps(liuInputFxObj);
							liuInputFxList.add(liuFinalFxObj);
						}


						LIURecordDetails=liuRecordsDaoObj.modifiedApsLIURecords(liuInputFxList, userId,"YES");
						liuRecordsListUpdated.add(LIURecordDetails);
					}
					else{

						liuInputFxList.add(liuObj);
						LIURecordDetails=liuRecordsDaoObj.modifiedApsLIURecords(liuInputFxList, userId,"NO");
						liuRecordsListUpdated.add(LIURecordDetails);
					}


				}

				System.out.println("liu object list is--------->>>>>>>>>>>>>"+liuObj);
				System.out.println("liu list is--------->>>>>>>>>>>>>"+liuList);
			
				/*for(int i=0;i<UpdatedValues.size();i++){
	    	 String liuReason=liuObj.getLiuReason();
		  if(liuReason.equalsIgnoreCase("INVALID ACCOUNT")||liuReason.equalsIgnoreCase("SEGMENT MAPPING NOT AVAILABLE")){
		  for(LIURecordDetails liuInputFxObj:liuList)
		  {
			  liuFinalFxObj=liuRecordsDaoObj.validationsFromFX(liuInputFxObj);

		  }

		  liuInputFxList.add(liuFinalFxObj);
		  liuRecordsListUpdated=liuRecordsDaoObj.modifiedApsLIUDetails(liuInputFxList,userId,sessionId,action,pageNumber);
		  }
		  else{
			  System.out.println("i am in else block a proc will be called");
		  }
		 }*/

				/*eCollectAccountMapList=liuRecordsDaoObj.eCollectAccountMapNeftCheck(liuList,action,pageNumber) ;


		  if(eCollectAccountMapList==null)
		  {
			  LIUlogger.info("Data Base Issues...Exception in caduserLIU");
				 modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				 modelAndViewObj.addObject("currentPage", pageNumber);
					modelAndViewObj.addObject("liuReasonList", liuReasonList);
					modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
					modelAndViewObj.addObject("liuStatusList",liuStatusList);
					  modelAndViewObj.addObject("liuFileList",liuFileList);
					modelAndViewObj.setViewName("apsLiu");
					return modelAndViewObj;
		  }


		  for(LIURecordDetails liuInputFxObj:eCollectAccountMapList)
		  {

	    	  liuFinalFxObj=liuRecordsDaoObj.validationsFromFX(liuInputFxObj);
	    	  liuInputFxList.add(liuFinalFxObj);
		  }	 */


				/*	  
			      for(LIURecordDetails liuInputFxObj:eCollectAccountMapList)
			      {

			    	  LIUlogger.info("Paymode and Remarks from DB for tracking_id:"+liuInputFxObj.getLiuTrackingID()+" are:"+liuInputFxObj.getPaymentMode()+","+liuInputFxObj.getRemarks()+""+liuInputFxObj.getEffectivePaymentAmount());

			    	  if(    (liuInputFxObj.getPaymentMode().equalsIgnoreCase("NEFT")&&liuInputFxObj.getRemarks().equalsIgnoreCase("SUCCESS") ) || 

			    			  liuInputFxObj.getPaymentMode().equalsIgnoreCase("CHEQUE")  || 

			    		       liuInputFxObj.getPaymentMode().equalsIgnoreCase("OTHERS") )



			    	  if((liuInputFxObj.getPaymentMode().equalsIgnoreCase("NEFT") && liuInputFxObj.getRemarks().equalsIgnoreCase("SUCCESS")))

			    		{
			    		  LIUlogger.info("In if loop of for in fx hitting");

			    		    liuFinalFxObj=liuRecordsDaoObj.validationsFromFX(liuInputFxObj);

			    		    LIUlogger.info("Effective amount in eai call @ Controller:"+liuFinalFxObj.getEffectivePaymentAmount());

			    		    LIUlogger.info("Final tracking Id:"+liuFinalFxObj.getLiuTrackingID());

				    		  liuInputFxList.add(liuFinalFxObj);


			    		} 
			    	 else
			    	     {
			    		  LIUlogger.info("TRACKING ID IN ELSE CONDITION OF FX HITTING LOOP::"+liuInputFxObj.getLiuTrackingID());
			    		  LIUlogger.info("REMARKS IN ELSE CONDITION OF FX HITTING LOOP::"+liuInputFxObj.getRemarks());

			    		  liuInputFxList.add(liuInputFxObj);


			    	     }



			      }	*/		




				/*if(liuRecordsListUpdated==null)
				{
					LIUlogger.info("Data Base Issues...Exception in caduserLIU");
					modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
					modelAndViewObj.addObject("currentPage", pageNumber);
					modelAndViewObj.addObject("liuReasonList", liuReasonList);
					modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
					modelAndViewObj.addObject("liuStatusList",liuStatusList);
					modelAndViewObj.addObject("liuFileList",liuFileList);
					modelAndViewObj.setViewName("apsLiu");
					return modelAndViewObj;
				}*/


				LIURecordDetails errorObj=null;
				for(int i=0;i<liuRecordsListUpdated.size();i++)

				{
					errorObj=liuRecordsListUpdated.get(i);
					errorMsg=errorObj.getErrorMsg();
				}

				// String errorMsg=errorObj.getErrorMsg();

				if(errorMsg!=null)
				{
					if(errorMsg.equalsIgnoreCase("SUCCESS"))
					{
						errorMsg="";
					}
					else
						errorMsg="No records Found";
				}
				else
					errorMsg="Connectivity Issues..Retry..";




			}// IF(  KEUVALUES PAIRS ARE NOT NULL VALUES)

			for(int i=0;i<liuRecordsListUpdated.size();i++)

			{

				LIURecordDetails liuRecordDetailsObj=liuRecordsListUpdated.get(i);

				/*liuRecordDetailsObj.getRemarks();
         	LIUlogger.info("REMARKS:"+liuRecordDetailsObj.getRemarks());*/


				SNo=activityDao.insertActivityLog(0l,userId,"Updating LIU Record",null,null,null,null,null);
				SNo=activityDao.insertActivityLog(SNo,userId,"Updating LIU Record","Failure","Record is NOT Updated",null,null,null);



			}


			LIUlogger.info("VALUES ARE UPDATED AND RETRIEVED AT CONTROLLER..");

			if(UpdatedValues!=null)
			{
				for(int i=0;i<UpdatedValues.size();i++)
				{
					LIUlogger.info("VALUES IN ROW "+(i+1)+" ARE:"+UpdatedValues.get(i));
				}
			}
			
			
          LIUlogger.info("before loading page------------>>>>>>>>");
 			modelAndViewObj.addObject("liuReasonList", liuReasonList);
			modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
			modelAndViewObj.addObject("liuStatusList",liuStatusList);
			modelAndViewObj.addObject("liuPaymentCurrencyList",liuPaymentCurrencyList);
			modelAndViewObj.addObject("liuRecordsListModified",liuRecordsListUpdated);
			modelAndViewObj.addObject("errorMsg", "");
			modelAndViewObj.addObject("liuFileList",liuFileList);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.setViewName("apsLiu");

		}catch (Exception e) {
			e.printStackTrace();
		}
		return modelAndViewObj;
	}




	@RequestMapping(value = "/deleteApsLIUAccountDetails", method = RequestMethod.POST)
	public ModelAndView deleteApsLIUAccountDetails(ModelMap model,HttpServletRequest request, HttpServletResponse response) 
	{
		String action="DELETE";
		int pageNumber=1;
		session=request.getSession(true);
		String userId=session.getAttribute("userid").toString();
		String sessionId=session.getId();


		ModelAndView modelAndViewObj = new ModelAndView();
		List<LIURecordDetails> liuRecordsListDeleted=new ArrayList<LIURecordDetails>();
		List<LIURecordDetails> liuDeleteList= new ArrayList<LIURecordDetails>();
		Long SNo=0l;
		try 
		{
			//int SNo=activityDao.insertActivityLog(0,userId,"Deleting LIU Record",null,null);

			LIUlogger.info("ENTERED INTO DELETE ACCOUNT DETAILS AT CONTROLLER");

			List<String> liuReasonList=liuRecordsDaoObj.liuReasonDropdown();
			if(liuReasonList==null)
			{
				LIUlogger.info("Data Base Issues For ReasonList");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}

			List<String> liuPayModeList=liuRecordsDaoObj.liuPayModeDropdown();
			if(liuPayModeList==null)
			{
				LIUlogger.info("Data Base Issues For  Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}

			List<String> liuStatusList=liuRecordsDaoObj.liuStatusDropdown();
			if(liuStatusList==null)
			{
				LIUlogger.info("Data Base Issues For  Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}

			List<LIURecordDetails> liuPaymentCurrencyList=liuRecordsDaoObj.liuPaymentCurrency();
			if(liuPaymentCurrencyList==null)
			{
				LIUlogger.info("Data Base Issues For  Payment Currency!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}

			List<String> liuFileList=liuRecordsDaoObj.liuApsFilenameList(); 
			if(liuFileList==null)
			{
				LIUlogger.info("Data Base Issues For File List!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}		  


			String[] keyValuePairs=request.getParameterValues("deletedValues");
			List<String> deletedValues=new ArrayList<String>();

			if(keyValuePairs!=null)
			{
				deletedValues=Arrays.asList(keyValuePairs);

				for(String valuesObj: deletedValues)
				{
					LIURecordDetails liuDeleteObj=new LIURecordDetails();
					String[] arrayOfDeletedValues=valuesObj.split("\\$");

					LIUlogger.info("LENGTH:"+arrayOfDeletedValues.length);
					for(int i=0;i<arrayOfDeletedValues.length;i++)
					{
						LIUlogger.info("ARRAY OF DELETED VALUES:"+arrayOfDeletedValues[i]);
					}

					liuDeleteObj.setLiuTrackingID(Long.parseLong(arrayOfDeletedValues[0]));
					liuDeleteObj.setRemitterIFSC(arrayOfDeletedValues[1]);
					liuDeleteObj.setB2b_b2c_Segment(arrayOfDeletedValues[2]);			  
					liuDeleteObj.setPaymentAmount(Double.parseDouble(arrayOfDeletedValues[3]));
					liuDeleteObj.setPaymentMode(arrayOfDeletedValues[4]);
					liuDeleteObj.setOldExchangeRate(Double.parseDouble(arrayOfDeletedValues[5]));
					liuDeleteObj.setAccountExtID(arrayOfDeletedValues[6]);
					liuDeleteObj.setInvoiceNumber(arrayOfDeletedValues[7]);
					liuDeleteObj.setPayment_currency(arrayOfDeletedValues[8]);
					liuDeleteObj.setExchange_rate(Double.parseDouble(arrayOfDeletedValues[9]));
					liuDeleteObj.setOrderNumber(Long.parseLong(arrayOfDeletedValues[10]));
					liuDeleteObj.setFileID(arrayOfDeletedValues[11]);
					liuDeleteObj.setRecordId(Long.parseLong(arrayOfDeletedValues[12]));
					liuDeleteObj.setReferenceID(arrayOfDeletedValues[13]);
					liuDeleteObj.setCustBankAccNo(arrayOfDeletedValues[14]);
					liuDeleteObj.setLiuReason(arrayOfDeletedValues[15]);
					liuDeleteObj.setPaymentCode(Long.parseLong(arrayOfDeletedValues[16]));
					liuDeleteObj.setAmountInINR(Double.parseDouble(arrayOfDeletedValues[17]));
					liuDeleteObj.setIncomingTransRefNum(arrayOfDeletedValues[18]);
					liuDeleteObj.setRemitterBranch(arrayOfDeletedValues[19]);
					liuDeleteObj.setReceiverIFSC(arrayOfDeletedValues[20]);
					liuDeleteObj.setRemitterAcctNum(arrayOfDeletedValues[21]);
					// liuDeleteObj.setEffectivePaymentAmount(Float.parseFloat(arrayOfDeletedValues[22]));

					liuDeleteList.add(liuDeleteObj);

				}
			} 
			liuRecordsListDeleted=liuRecordsDaoObj.modifiedApsLIUDetails(liuDeleteList,userId,sessionId,action,pageNumber);
			if(liuRecordsListDeleted==null)
			{
				LIUlogger.info("Data Base Issues...Exception in caduserLIU");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("currentPage", pageNumber);
				modelAndViewObj.addObject("liuReasonList", liuReasonList);
				modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
				modelAndViewObj.addObject("liuStatusList",liuStatusList);
				modelAndViewObj.addObject("liuFileList",liuFileList);
				modelAndViewObj.setViewName("apsLiu");
				return modelAndViewObj;
			}

			LIURecordDetails errorObj=null;
			for(int i=0;i<liuRecordsListDeleted.size();i++)

			{
				errorObj=liuRecordsListDeleted.get(i);
				errorObj.getErrorMsg();
			}
			String errorMsg=errorObj.getErrorMsg();

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";


			for(int i=0;i<liuRecordsListDeleted.size();i++)

			{

				LIURecordDetails liuRecordDetailsObj=liuRecordsListDeleted.get(i);

				/*liuRecordDetailsObj.getRemarks();
         	LIUlogger.info("Remarks at DeleteLiuDetails:"+liuRecordDetailsObj.getRemarks());*/

				/*if(liuRecordDetailsObj.getRemarks().equalsIgnoreCase("LIU DELETED"))
         	{
         		SNo=activityDao.insertActivityLog(0l,userId,"Deleting LIU Record",null,null,null,null,null);	
         		SNo=activityDao.insertActivityLog(SNo,userId,"Deleting LIU Record","Success","Record Deleted",null,null,null);

         	}
         	else
         	{*/
				SNo=activityDao.insertActivityLog(0l,userId,"Deleting LIU Record",null,null,null,null,null);
				SNo=activityDao.insertActivityLog(SNo,userId,"Deleting LIU Record","Failure","Record is not Deleted",null,null,null);

				/*}*/

			}


			LIUlogger.info("Values are deleted and retrieved @contoller!!!!");
			if(deletedValues!=null)
			{
				for(int i=0;i<deletedValues.size();i++)
				{
					LIUlogger.info("VALUES IN ROW "+(i+1)+" are::"+deletedValues.get(i));
				}
			}
			modelAndViewObj.addObject("liuReasonList", liuReasonList);
			modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
			modelAndViewObj.addObject("liuStatusList",liuStatusList);
			modelAndViewObj.addObject("liuPaymentCurrencyList",liuPaymentCurrencyList);
			modelAndViewObj.addObject("liuRecordsListModified",liuRecordsListDeleted);
			modelAndViewObj.addObject("errorMsg", "");
			modelAndViewObj.addObject("liuFileList",liuFileList);
			modelAndViewObj.addObject("currentPage", pageNumber);
			modelAndViewObj.setViewName("apsLiu");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return modelAndViewObj;
	}

	@RequestMapping(value = "/exportToExcelDefaultAps", method = RequestMethod.POST)
	public ModelAndView exportToExcelDefaultAps(ModelMap model,HttpServletRequest request, HttpServletResponse response) 
	{
		ModelAndView modelAndViewObj = new ModelAndView();
		LIURecordDetails defaultRecordsObj3=new LIURecordDetails();

		try{

			LIUlogger.info("ENTERED INTO EXPORT TO EXCEL METHOD DEFAULT AT CONTROLLER");

			String page = null;

			List<String> liuReasonList=liuRecordsDaoObj.liuReasonDropdown();
			if(liuReasonList==null)
			{
				LIUlogger.info("Data Base Issues For ReasonList");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuApsResultPage");
				return modelAndViewObj;
			}

			List<String> liuPayModeList=liuRecordsDaoObj.liuPayModeDropdown();
			if(liuPayModeList==null)
			{
				LIUlogger.info("Data Base Issues For Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuApsResultPage");
				return modelAndViewObj;
			}

			List<String> liuStatusList=liuRecordsDaoObj.liuStatusDropdown();
			if(liuStatusList==null)
			{
				LIUlogger.info("Data Base Issues For Status List!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuApsResultPage");
				return modelAndViewObj;
			}

			List<String> liuFileList=liuRecordsDaoObj.liuApsFilenameList(); 
			if(liuFileList==null)
			{
				LIUlogger.info("Data Base Issues For File List!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuApsResultPage");
				return modelAndViewObj;
			}


			String paymentMode = request.getParameter("paymentMode");
			String referenceId= request.getParameter("refID");
			String remitterIfsc= request.getParameter("ifscCode");
			String acctNum=request.getParameter("accountNumber");
			String liuReason=request.getParameter("liuReason");
			String fromDate=request.getParameter("startDate");
			String toDate=request.getParameter("endDate");
			String liu_Status=request.getParameter("liuStatus");
			String userId=request.getParameter("userID");
			String fileName=request.getParameter("fileName");


			defaultRecordsObj3.setPaymentMode(paymentMode);

			if(referenceId == null || referenceId.equals(""))
				defaultRecordsObj3.setReferenceID(null);
			else
				defaultRecordsObj3.setReferenceID(referenceId.trim());

			if(paymentMode!=null)
			{	
				if(paymentMode.equalsIgnoreCase("CHEQUE"))
				{
					if(remitterIfsc == null || remitterIfsc.equals(""))     
						defaultRecordsObj3.setRemitterIFSC(null);
					else
						defaultRecordsObj3.setRemitterIFSC(remitterIfsc.trim());
				}

				else
					defaultRecordsObj3.setRemitterIFSC(null);
			}

			if(acctNum == null || acctNum.equals(""))
				defaultRecordsObj3.setAccountExtID(null);
			else
				defaultRecordsObj3.setAccountExtID(acctNum.trim());

			defaultRecordsObj3.setLiuReason(liuReason);

			if(fromDate == null|| fromDate.equals(""))   
				defaultRecordsObj3.setFromDate(null);
			else
				defaultRecordsObj3.setFromDate(fromDate);

			if(toDate == null|| toDate.equals(""))   
				defaultRecordsObj3.setToDate(null);
			else
				defaultRecordsObj3.setToDate(toDate);   

			if(liu_Status != null)    
				defaultRecordsObj3.setLiuStatus(liu_Status);


			if(fileName != null)
				defaultRecordsObj3.setFileName(fileName.trim());   

			if(userId == null || userId.equals(""))
				defaultRecordsObj3.setUserID(null);  
			else
				defaultRecordsObj3.setUserID(userId.trim());   



			LIUlogger.info("UTR NUMBER FROM JSP:"+ request.getParameter("refID"));
			LIUlogger.info(" IFSC CODE FROM JSP:"+ request.getParameter("ifscCode"));
			LIUlogger.info("ACCOUNT NUMBER FROM JSP:"+ request.getParameter("accountNumber"));
			LIUlogger.info("LIU REASON FROM JSP:"+ request.getParameter("liuReason"));
			LIUlogger.info("START DATE FROM JSP:"+ request.getParameter("startDate"));
			LIUlogger.info("END DATE FROM JSP:"+ request.getParameter("endDate"));
			LIUlogger.info(" LIU STATUS FROM JSP:"+ request.getParameter("liuStatus"));
			LIUlogger.info(" FILE NAME FROM JSP:"+ request.getParameter("fileName"));
			LIUlogger.info("PAYMENT MODE FROM JSP:"+ request.getParameter("paymentMode"));
			LIUlogger.info(" USER ID FROM JSP:"+ request.getParameter("userID"));


			LIURecordDetails liuFileObj=liuRecordsDaoObj.downloadedFileAps(defaultRecordsObj3,/* downloadedFilesPath,*/ extension, page);	 

			LIUlogger.info("Liu Status:"+defaultRecordsObj3.getLiuStatus());

			/*String filePath=downloadedFilesPath;
				LIUlogger.info("Filepath is:"+filePath);*/

			String errorMsg=defaultRecordsObj3.getErrorMsg();
			LIUlogger.info("Error Message in exportToExcelDefault mapping at controller "+errorMsg);


			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(liuFileObj==null)
			{
				LIUlogger.info("Data Base Issues...Exception in exportToExcel");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("liuReasonList", liuReasonList);
				modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
				modelAndViewObj.addObject("liuStatusList",liuStatusList);
				modelAndViewObj.addObject("liuFileList",liuFileList);
				modelAndViewObj.setViewName("liuApsResultPage");
				return modelAndViewObj;
			}

			String filename="APS_"+liuFileObj.getLiuStatus()+"_"+liuRecordsDaoObj.getDateTime()+"."+extension;
			LIUlogger.info("Filename:"+filename);

			//  String finalPath=/*filePath+"\\"+*/filename;

			ServletOutputStream out = response.getOutputStream();
			FileInputStream in = new FileInputStream(filename);
			LIUlogger.info("File Name:"+in);

			response.setContentType("APPLICATION/OCTET-STREAM");

			response.addHeader("content-disposition",
					"attachment; filename=" +filename);


			LIUlogger.info("PROCESS COMPLETED AND FETCHED THE FILE @ CONTROLLER");

			int octet;
			while((octet = in.read()) != -1)
				out.write(octet);

			in.close();
			out.flush();
			out.close();
			response.flushBuffer();
			LIUlogger.info("FINISHED EXECUTION OF EXPORT TO EXCEL DEFAULT METHOD");

		}catch (Exception e) {
			e.printStackTrace();
		}
		return modelAndViewObj;
	}

	@RequestMapping(value = "/exportToExcelAps", method = RequestMethod.POST)
	public ModelAndView exportToExcelAps(ModelMap model,HttpServletRequest request, HttpServletResponse response) 
	{
		ModelAndView modelAndViewObj = new ModelAndView();
		LIURecordDetails searchDetailsObj3=new LIURecordDetails();

		try{

			LIUlogger.info("Entered exportToExcel mapping at controller");

			String page = null;

			List<String> liuReasonList=liuRecordsDaoObj.liuReasonDropdown();
			if(liuReasonList==null)
			{
				LIUlogger.info("Data Base Issues For ReasonList");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuApsResultPage");
				return modelAndViewObj;
			}

			List<String> liuPayModeList=liuRecordsDaoObj.liuPayModeDropdown();
			if(liuPayModeList==null)
			{
				LIUlogger.info("Data Base Issues For  Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuApsResultPage");
				return modelAndViewObj;
			}

			List<String> liuStatusList=liuRecordsDaoObj.liuStatusDropdown();
			if(liuStatusList==null)
			{
				LIUlogger.info("Data Base Issues For  Payment Mode!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuApsResultPage");
				return modelAndViewObj;
			}

			List<String> liuFileList=liuRecordsDaoObj.liuFilenameList(); 
			if(liuFileList==null)
			{
				LIUlogger.info("Data Base Issues For File List!");
				modelAndViewObj.addObject("searchError", "Data Base Issues..Retry..");
				modelAndViewObj.setViewName("liuApsResultPage");
				return modelAndViewObj;
			}


			String paymentMode = request.getParameter("paymentMode");
			String referenceId= request.getParameter("refID");
			String remitterIfsc= request.getParameter("ifscCode");
			String acctNum=request.getParameter("accountNumber");
			String liuReason=request.getParameter("liuReason");
			String fromDate=request.getParameter("startDate");
			String toDate=request.getParameter("endDate");
			String liu_Status=request.getParameter("liuStatus");
			String userId=request.getParameter("userID");
			String fileName=request.getParameter("fileName");


			searchDetailsObj3.setPaymentMode(paymentMode);

			if(referenceId == null || referenceId.equals(""))
				searchDetailsObj3.setReferenceID(null);
			else
				searchDetailsObj3.setReferenceID(referenceId.trim());


			if(paymentMode!=null)
			{			
				if(paymentMode.equalsIgnoreCase("CHEQUE"))
				{
					if(remitterIfsc == null || remitterIfsc.equals(""))     
						searchDetailsObj3.setRemitterIFSC(null);
					else
						searchDetailsObj3.setRemitterIFSC(remitterIfsc.trim());
				}

				else
					searchDetailsObj3.setRemitterIFSC(null);
			}	

			if(acctNum == null || acctNum.equals(""))
				searchDetailsObj3.setAccountExtID(null);
			else
				searchDetailsObj3.setAccountExtID(acctNum.trim());

			searchDetailsObj3.setLiuReason(liuReason);

			if(fromDate == null|| fromDate.equals(""))   
				searchDetailsObj3.setFromDate(null);
			else
				searchDetailsObj3.setFromDate(fromDate);

			if(toDate == null|| toDate.equals(""))   
				searchDetailsObj3.setToDate(null);
			else
				searchDetailsObj3.setToDate(toDate);   

			if(liu_Status != null)    
				searchDetailsObj3.setLiuStatus(liu_Status);


			if(fileName != null)
				searchDetailsObj3.setFileName(fileName.trim());   

			if(userId == null || userId.equals(""))
				searchDetailsObj3.setUserID(null);  
			else
				searchDetailsObj3.setUserID(userId.trim());   



			LIUlogger.info("UTR NUMBER FROM JSP:"+ request.getParameter("refID"));
			LIUlogger.info(" IFSC CODE FROM JSP:"+ request.getParameter("ifscCode"));
			LIUlogger.info("ACCOUNT NUMBER FROM JSP:"+ request.getParameter("accountNumber"));
			LIUlogger.info("LIU REASON FROM JSP:"+ request.getParameter("liuReason"));
			LIUlogger.info("START DATE FROM JSP:"+ request.getParameter("startDate"));
			LIUlogger.info("END DATE FROM JSP:"+ request.getParameter("endDate"));
			LIUlogger.info(" LIU STATUS FROM JSP:"+ request.getParameter("liuStatus"));
			LIUlogger.info(" FILE NAME FROM JSP:"+ request.getParameter("fileName"));
			LIUlogger.info("PAYMENT MODE FROM JSP:"+ request.getParameter("paymentMode"));
			LIUlogger.info(" USER ID FROM JSP:"+ request.getParameter("userID"));


			LIURecordDetails liuFileObj=liuRecordsDaoObj.downloadedFileAps(searchDetailsObj3,/* downloadedFilesPath,*/ extension, page);	  

			String errorMsg=searchDetailsObj3.getErrorMsg();
			LIUlogger.info("Error Message in exportToExcel mapping at controller "+errorMsg);

			if(errorMsg!=null)
			{
				if(errorMsg.equalsIgnoreCase("SUCCESS"))
				{
					errorMsg="";
				}
				else
					errorMsg="No records Found";
			}
			else
				errorMsg="Connectivity Issues..Retry..";

			if(liuFileObj==null)
			{
				LIUlogger.info("Data Base Issues...Exception in exportToExcel");
				modelAndViewObj.addObject("errorMsg", "Data Base Issues..Retry..");
				modelAndViewObj.addObject("currentPage", page);
				modelAndViewObj.addObject("liuReasonList", liuReasonList);
				modelAndViewObj.addObject("liuPayModeList", liuPayModeList);
				modelAndViewObj.addObject("liuStatusList",liuStatusList);
				modelAndViewObj.addObject("liuFileList",liuFileList);
				modelAndViewObj.setViewName("liuApsResultPage");
				return modelAndViewObj;
			}



			/*String filePath=downloadedFilesPath;
				logger.info("Filepath is:"+filePath);*/

			String filename="APS_"+liuFileObj.getLiuStatus()+"_"+liuRecordsDaoObj.getDateTime()+"."+extension;
			LIUlogger.info("Filename:"+filename);

			//  String finalPath=/*filePath+"\\"+*/filename;

			ServletOutputStream out = response.getOutputStream();
			FileInputStream in = new FileInputStream(filename);
			LIUlogger.info("File name:"+in);

			response.setContentType("APPLICATION/OCTET-STREAM");

			response.addHeader("content-disposition",
					"attachment; filename=" +filename);


			LIUlogger.info("Process completed and fetched file at controller");

			int octet;
			while((octet = in.read()) != -1)
				out.write(octet);

			in.close();
			out.flush();
			out.close();
			response.flushBuffer();
			LIUlogger.info("Finished execution of export to excel in liu controller ");

		}catch (Exception e) {
			e.printStackTrace();
		}
		return modelAndViewObj;
	}
	
	
	public static void main(String[] args) {
		String a="ABCD IJKL";
		String[] str =a.split(" ");
		String result="";
		for(int i=0;i<str.length;i++){
			String wrd = str[i];
			for(int j=wrd.length()-1;i>=0;i--){
				result +=wrd.charAt(j)+"";
			}
				
			
		}
		
		System.out.println("tesf="+result);
		
	}
}
