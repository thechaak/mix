package com.acecad.liu.model;

import java.sql.Date;
import java.util.HashMap;
import java.util.List;

public class LIURecordDetails {

	
	private int count;
	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	private String paymentMode;
	private double paymentAmount;
	private Date chequeDate;
	private String custBankAccNo;
	private String paymentReceivedDate;
	private long liuTrackingID;
	private String sourceOfRecord;
	private String fileID;
	private String modifiedCustAcctID;
	private String modifiedDelNo;
	private String liuReason;
	private String vendorID;
	private String userID;
	private String circle;
	private String lbxLocationID;
	private String lbxSourceID;
	private String sourceRefID;
	private String changeWho;
	private Date changeDate;
	private Date insertDate;
	private int status;
	private String referenceID;
	private String remitterIFSC;
	private String accountExtID;
	private String invoiceNumber;
	private String b2b_b2c_Segment;
	private String remarks;
	private String errorMsg;
	private String errorCode;
	private String cust_currency;
	private String payment_currency;
	private double exchange_rate;
	private String lob;
	private String toDate;
	private String fromDate;
	private String fileUploadDate;
	private int pendingSince;
	private String customerName;
	private long orderNumber;
	private long recordId;
	private String fxLegalEntity;
	private String fxValueType;
	private String fxVIPFlag;
	private String fxCustomerType;
	private String fxCustomerClass;
	private long paymentCode;
	private String validInvoice;
	private String accountType;
	private double oldExchangeRate;
	private String liuStatus;
	private String vendorName;
	private String origBillRefNo;
	private double origBillRefResets;
	private double effectivePaymentAmount;
	private String display;
	private String currency;
	private String delNumber;
	private int liuValue;
	private int actedIn;
	private String fileName;
	private String marketCode;
	private String fxInternalAcctNum;
	private String companyName; 
	private String receiverIFSC;
	private String remitterAcctNum;
	private String remitterBranch;
	private String incomingTransRefNum;
	private double amountInINR;
	private String receivingAcctRbi1;
	private String servId;
	private String anchorId;
	
	

	public String getAnchorId() {
		return anchorId;
	}

	public void setAnchorId(String anchorId) {
		this.anchorId = anchorId;
	}

	//added to handel msisdn case
	private String parentAcctNo;

	
	public String getParentAcctNo() {
		return parentAcctNo;
	}

	public void setParentAcctNo(String parentAcctNo) {
		this.parentAcctNo = parentAcctNo;
	}

	//Added By APS Team
	private String apsFlag;

	public String getApsFlag() {
		return apsFlag;
	}

	public void setApsFlag(String apsFlag) {
		this.apsFlag = apsFlag;
	}
    
	
	public String getReceiverIFSC() {
		return receiverIFSC;
	}

	public void setReceiverIFSC(String receiverIFSC) {
		this.receiverIFSC = receiverIFSC;
	}

	public String getRemitterAcctNum() {
		return remitterAcctNum;
	}

	public void setRemitterAcctNum(String remitterAcctNum) {
		this.remitterAcctNum = remitterAcctNum;
	}

	public String getRemitterBranch() {
		return remitterBranch;
	}

	public void setRemitterBranch(String remitterBranch) {
		this.remitterBranch = remitterBranch;
	}

	public String getIncomingTransRefNum() {
		return incomingTransRefNum;
	}

	public void setIncomingTransRefNum(String incomingTransRefNum) {
		this.incomingTransRefNum = incomingTransRefNum;
	}

	public double getAmountInINR() {
		return amountInINR;
	}

	public void setAmountInINR(double amountInINR) {
		this.amountInINR = amountInINR;
	}

	public String getReceivingAcctRbi1() {
		return receivingAcctRbi1;
	}

	public void setReceivingAcctRbi1(String receivingAcctRbi1) {
		this.receivingAcctRbi1 = receivingAcctRbi1;
	}

	public String getMarketCode() {
		return marketCode;
	}

	public void setMarketCode(String marketCode) {
		this.marketCode = marketCode;
	}

	public String getFxInternalAcctNum() {
		return fxInternalAcctNum;
	}

	public void setFxInternalAcctNum(String fxInternalAcctNum) {
		this.fxInternalAcctNum = fxInternalAcctNum;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getOrigBillRefNo() {
		return origBillRefNo;
	}

	public void setOrigBillRefNo(String origBillRefNo) {
		this.origBillRefNo = origBillRefNo;
	}

	public double getOrigBillRefResets() {
		return origBillRefResets;
	}

	public void setOrigBillRefResets(double origBillRefResets) {
		this.origBillRefResets = origBillRefResets;
	}

	public long getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(long orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getLiuStatus() {
		return liuStatus;
	}

	public void setLiuStatus(String liuStatus) {
		this.liuStatus = liuStatus;
	}

	public double getOldExchangeRate() {
		return oldExchangeRate;
	}

	public void setOldExchangeRate(double oldExchangeRate) {
		this.oldExchangeRate = oldExchangeRate;
	}

	public long getPaymentCode() {
		return paymentCode;
	}

	public void setPaymentCode(long paymentCode) {
		this.paymentCode = paymentCode;
	}

	public String getValidInvoice() {
		return validInvoice;
	}

	public void setValidInvoice(String validInvoice) {
		this.validInvoice = validInvoice;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getFileUploadDate() {
		return fileUploadDate;
	}

	public void setFileUploadDate(String fileUploadDate) {
		this.fileUploadDate = fileUploadDate;
	}

	public int getPendingSince() {
		return pendingSince;
	}

	public void setPendingSince(int pendingSince) {
		this.pendingSince = pendingSince;
	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public String getCust_currency() {
		return cust_currency;
	}

	public void setCust_currency(String cust_currency) {
		this.cust_currency = cust_currency;
	}

	public String getPayment_currency() {
		return payment_currency;
	}

	public void setPayment_currency(String payment_currency) {
		this.payment_currency = payment_currency;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public double getExchange_rate() {
		return exchange_rate;
	}

	public void setExchange_rate(double exchange_rate) {
		this.exchange_rate = exchange_rate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public double getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public Date getChequeDate() {
		return chequeDate;
	}

	public void setChequeDate(Date chequeDate) {
		this.chequeDate = chequeDate;
	}

	public String getCustBankAccNo() {
		return custBankAccNo;
	}

	public void setCustBankAccNo(String custBankAccNo) {
		this.custBankAccNo = custBankAccNo;
	}

	public String getPaymentReceivedDate() {
		return paymentReceivedDate;
	}

	public void setPaymentReceivedDate(String paymentReceivedDate) {
		this.paymentReceivedDate = paymentReceivedDate;
	}

	public long getLiuTrackingID() {
		return liuTrackingID;
	}

	public void setLiuTrackingID(long liuTrackingID) {
		this.liuTrackingID = liuTrackingID;
	}

	public String getSourceOfRecord() {
		return sourceOfRecord;
	}

	public void setSourceOfRecord(String sourceOfRecord) {
		this.sourceOfRecord = sourceOfRecord;
	}

	public String getFileID() {
		return fileID;
	}

	public void setFileID(String fileID) {
		this.fileID = fileID;
	}

	public String getModifiedCustAcctID() {
		return modifiedCustAcctID;
	}

	public void setModifiedCustAcctID(String modifiedCustAcctID) {
		this.modifiedCustAcctID = modifiedCustAcctID;
	}

	public String getModifiedDelNo() {
		return modifiedDelNo;
	}

	public void setModifiedDelNo(String modifiedDelNo) {
		this.modifiedDelNo = modifiedDelNo;
	}

	public String getLiuReason() {
		return liuReason;
	}

	public void setLiuReason(String liuReason) {
		this.liuReason = liuReason;
	}

	public String getVendorID() {
		return vendorID;
	}

	public void setVendorID(String vendorID) {
		this.vendorID = vendorID;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getCircle() {
		return circle;
	}

	public void setCircle(String circle) {
		this.circle = circle;
	}

	public String getLbxLocationID() {
		return lbxLocationID;
	}

	public void setLbxLocationID(String lbxLocationID) {
		this.lbxLocationID = lbxLocationID;
	}

	public String getLbxSourceID() {
		return lbxSourceID;
	}

	public void setLbxSourceID(String lbxSourceID) {
		this.lbxSourceID = lbxSourceID;
	}

	public String getSourceRefID() {
		return sourceRefID;
	}

	public void setSourceRefID(String sourceRefID) {
		this.sourceRefID = sourceRefID;
	}

	public String getChangeWho() {
		return changeWho;
	}

	public void setChangeWho(String changeWho) {
		this.changeWho = changeWho;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Date getChangeDate() {
		return changeDate;
	}

	public void setChangeDate(Date changeDate) {
		this.changeDate = changeDate;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getReferenceID() {
		return referenceID;
	}

	public void setReferenceID(String referenceID) {
		this.referenceID = referenceID;
	}

	public String getAccountExtID() {
		return accountExtID;
	}

	public void setAccountExtID(String accountExtID) {
		this.accountExtID = accountExtID;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getB2b_b2c_Segment() {
		return b2b_b2c_Segment;
	}

	public void setB2b_b2c_Segment(String b2b_b2c_Segment) {
		this.b2b_b2c_Segment = b2b_b2c_Segment;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public long getRecordId() {
		return recordId;
	}

	public void setRecordId(long recordId) {
		this.recordId = recordId;
	}

	public String getFxLegalEntity() {
		return fxLegalEntity;
	}

	public void setFxLegalEntity(String fxLegalEntity) {
		this.fxLegalEntity = fxLegalEntity;
	}

	public String getFxValueType() {
		return fxValueType;
	}

	public void setFxValueType(String fxValueType) {
		this.fxValueType = fxValueType;
	}

	public String getFxVIPFlag() {
		return fxVIPFlag;
	}

	public void setFxVIPFlag(String fxVIPFlag) {
		this.fxVIPFlag = fxVIPFlag;
	}

	public String getFxCustomerType() {
		return fxCustomerType;
	}

	public void setFxCustomerType(String fxCustomerType) {
		this.fxCustomerType = fxCustomerType;
	}

	public String getFxCustomerClass() {
		return fxCustomerClass;
	}

	public void setFxCustomerClass(String fxCustomerClass) {
		this.fxCustomerClass = fxCustomerClass;
	}

	public double getEffectivePaymentAmount() {
		return effectivePaymentAmount;
	}

	public void setEffectivePaymentAmount(double effectivePaymentAmount) {
		this.effectivePaymentAmount = effectivePaymentAmount;
	}

	public String getDisplay() {
		return display;
	}

	public void setDisplay(String display) {
		this.display = display;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getRemitterIFSC() {
		return remitterIFSC;
	}

	public void setRemitterIFSC(String remitterIFSC) {
		this.remitterIFSC = remitterIFSC;
	}

	public String getDelNumber() {
		return delNumber;
	}

	public void setDelNumber(String delNumber) {
		this.delNumber = delNumber;
	}

	public int getLiuValue() {
		return liuValue;
	}

	public void setLiuValue(int liuValue) {
		this.liuValue = liuValue;
	}

	public int getActedIn() {
		return actedIn;
	}

	public void setActedIn(int actedIn) {
		this.actedIn = actedIn;
	}

	public String getServId() {
		return servId;
	}

	public void setServId(String servId) {
		this.servId = servId;
	}

}
