package com.acecad.liu.dao;
//testing liurecordsdaoimpl-hyd


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
//import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.jms.JMSException;
import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.acecad.airtel.eai.integration.model.Request_ResponseXMLDetails;
import com.acecad.airtel.eai.integration.msg.ECCEAIAccountDetailsIntegration;
import com.acecad.liu.model.LIURecordDetails;
//import com.acecad.liu.model.LIURecordDetails;
import com.airtel.acecad.client.CustomerAccountSummaryClient;
import com.airtel.acecad.client.GetCustomerInvoiceSummaryV5;
import com.airtel.acecad.client.OptimusClient;
import com.airtel.acecad.client.dto.BulkDetails;
import com.airtel.acecad.client.util.CommonValidator;
import com.airtel.acecad.client.util.NDSClient;
import com.airtel.acecad.client.util.NDSConfiguration;
//import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import com.airtel.acecad.util.OptimusDetailsDto;

import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;


public class LIURecordsDaoIMPL implements LIURecordsDAO {

	private static Logger LIUlogger = LogManager.getLogger("liuLogger");

	@Autowired
	private PlatformTransactionManager transactionManager;

	public void setTransactionManager(
			PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}

	public LIURecordsDaoIMPL(DataSource dataSource) {
		this.dataSource = dataSource;
		setTransactionManager(transactionManager);
	}

	private DataSource dataSource;
	Connection conn = null;
	ResultSet resultsetshowdetails = null;

	public LIURecordsDaoIMPL() {

	}


	public String getDateTime() 
	{
		LIUlogger.info("Entered getDateTime Proc in LIURecordsDaoIMPL");	
		Date today = (Date) Calendar.getInstance().getTime();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		return formatter.format(today);
	} 

	public List<String> liuReasonDropdown() 
	{

		List<String> liuReasonDropdownList=new ArrayList<String>();
		CallableStatement callableStatement=null;
		ResultSet liuReasonResultSet=null;

		try 
		{
			LIUlogger.info("Entered liuReasonDropdown method in LIURecordsDaoIMPL");	
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();

			final String procedureCall = "{call ACE_CAD_BULK_PAYMENT.ACE_CAD_LIU_DROP_DOWN_REASON(?,?,?)}";

			callableStatement = conn.prepareCall(procedureCall);
			callableStatement.registerOutParameter(1, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(2, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);

			callableStatement.executeUpdate();

			String errorMsgLIUReason=callableStatement.getString(3);
			LIUlogger.info("Error message at liuReasonDropdown method in LIURecordsDaoIMPL:"+errorMsgLIUReason);

			liuReasonResultSet=(ResultSet) callableStatement.getObject(1);
			if (liuReasonResultSet == null) 
			{
				LIUlogger.info("DB returning NULL values at liuReasonDropdown method in LIURecordsDaoIMPL");
			}
			else
			{
				while(liuReasonResultSet!=null && liuReasonResultSet.next())
				{

					/* LIURecordDetails LIUReasonObj=new LIURecordDetails();
		    	 LIUReasonObj.setLiuReason(liuReasonResultSet.getString("MASTER_PARAM_NAME"));
		    	 LIUReasonObj.setLiuValue(liuReasonResultSet.getInt("MASTER_PARAM_VALUE"));
					 */

					liuReasonDropdownList.add(liuReasonResultSet.getString(1));
				}
				LIUlogger.info("Size of liuReasonDropdownList at liuReasonDropdownList method in LIURecordsDaoIMPL:"+liuReasonDropdownList);

			}

		}catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);
			return null;
		}
		finally{
			if(liuReasonResultSet!=null){
				try {
					liuReasonResultSet.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(callableStatement!=null){
				try {
					callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(conn!=null){
				try {
					conn.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}

			}
		}

		LIUlogger.info("executed liuReasonDropdownList method in LIURecordsDaoIMPL");	

		return liuReasonDropdownList ;
	}



	public List<String> liuPayModeDropdown() 
	{

		List<String> liuPayModeList=new ArrayList<String>();
		CallableStatement callableStatement=null;
		ResultSet liuPayModeResultSet=null;

		try 
		{
			LIUlogger.info("Entered liuPayModeDropdown Proc in LIURecordsDaoIMPL");	

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();

			final String procedureCall = "{call ACE_CAD_BULK_PAYMENT.ACE_CAD_LIU_DROP_DOWN_PAY_MODE(?,?,?)}";

			callableStatement = conn.prepareCall(procedureCall);
			callableStatement.registerOutParameter(1, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(2, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();

			String errorMsgLIUPayMode=callableStatement.getString(3);

			LIUlogger.info("Error message at liuPayModeDropdown method in LIURecordsDaoIMPL:"+errorMsgLIUPayMode);


			liuPayModeResultSet=(ResultSet) callableStatement.getObject(1);

			if (liuPayModeResultSet == null) 
			{
				LIUlogger.info("DB returning NULL values at liuPayModeDropdown method in LIURecordsDaoIMPL");
			}
			else
			{
				while(liuPayModeResultSet.next())
				{
					liuPayModeList.add(liuPayModeResultSet.getString(1));
					//  LIUlogger.info("Liu paymode list at liuPayModeDropdown method in LIURecordsDaoIMPL: "+liuPayModeList);
				}
				LIUlogger.info("Size of liuPayModeList at liuPayModeDropdown method in LIURecordsDaoIMPL:"+liuPayModeList);
			}
		}catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);
			return null;
		}
		finally{
			if(liuPayModeResultSet!=null){
				try {
					liuPayModeResultSet.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(callableStatement!=null){
				try {
					callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(conn!=null){
				try {
					conn.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}

			}
		}
		LIUlogger.info("executed liuPayModeDropdown method in LIURecordsDaoIMPL");	

		return liuPayModeList ;
	}


	public List<String> liuStatusDropdown() 
	{

		List<String> liuStatusList=new ArrayList<String>();
		CallableStatement callableStatement=null;
		ResultSet liuStatusResultSet=null;

		try 
		{
			LIUlogger.info("Entered liuStatusDropdown method in LIURecordsDaoIMPL");	

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();

			final String procedureCall = "{call ACE_CAD_BULK_PAYMENT.GET_LIU_STATUSES(?,?,?)}";

			callableStatement = conn.prepareCall(procedureCall);
			callableStatement.registerOutParameter(1, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(2, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			callableStatement.executeUpdate();


			String errorMsgLIUStatus=callableStatement.getString(3);
			LIUlogger.info("Error message at liuStatusDropdown method in LIURecordsDaoIMPL:"+errorMsgLIUStatus);

			liuStatusResultSet=(ResultSet) callableStatement.getObject(1);

			if (liuStatusResultSet == null) 
			{
				LIUlogger.info("DB returning NULL values at liuStatusDropdown method in LIURecordsDaoIMPL");
			}
			else
			{
				while(liuStatusResultSet.next())
				{
					liuStatusList.add(liuStatusResultSet.getString(1));
					// LIUlogger.info("Liu status list at liuStatusDropdown proc in LIURecordsDaoIMPL:"+liuStatusList);
				}
				LIUlogger.info("Size of liuStatusList at liuStatusDropdown method in LIURecordsDaoIMPL:"+liuStatusList);


			}
		}catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);
			return null;
		}
		finally{
			if(liuStatusResultSet!=null){
				try {
					liuStatusResultSet.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(callableStatement!=null){
				try {
					callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(conn!=null){
				try {
					conn.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}

			}
		}
		LIUlogger.info("executed liuStatusDropdown method in LIURecordsDaoIMPL");	

		return liuStatusList ;
	}

	public List<String> liuFilenameList() 
	{

		List<String> liuFilenameList=new ArrayList<String>();
		CallableStatement callableStatement=null;
		ResultSet fileNameResultSet=null;

		try 
		{
			LIUlogger.info("Entered liuFilenameList method in LIURecordsDaoIMPL");	

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();

			final String procedureCall = "{call ACE_CAD_BULK_PAYMENT.ACE_CAD_LIU_FILE_NAME(?,?,?)}";

			callableStatement = conn.prepareCall(procedureCall);
			callableStatement.registerOutParameter(1, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(2, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);

			callableStatement.executeUpdate();

			String errorMsgFilename=callableStatement.getString(3);
			LIUlogger.info("Error message at liuFilenameList method in LIURecordsDaoIMPL:"+errorMsgFilename);

			fileNameResultSet=(ResultSet) callableStatement.getObject(1);

			if (fileNameResultSet == null) 
			{
				LIUlogger.info("DB returning NULL values at liuFilenameList method in LIURecordsDaoIMPL");
			}
			else
			{
				while(fileNameResultSet.next())
				{
					liuFilenameList.add(fileNameResultSet.getString(1));
				}
				LIUlogger.info("Size of liuFilenameList at liuFilenameList method in LIURecordsDaoIMPL:"+liuFilenameList);


			}
		}catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);
			return null;
		}
		finally{
			if(fileNameResultSet!=null){
				try {
					fileNameResultSet.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(callableStatement!=null){
				try {
					callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(conn!=null){
				try {
					conn.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}

			}
		}
		LIUlogger.info("executed liuFilenameList method in LIURecordsDaoIMPL");	


		return liuFilenameList ;
	}



	public List<LIURecordDetails> liuPaymentCurrency() 
	{

		List<LIURecordDetails> liuPaymentCurrencyList=new ArrayList<LIURecordDetails>();
		CallableStatement callableStatement=null;
		ResultSet liuCurrencyResultSet=null;

		try 
		{
			LIUlogger.info("Entered liuPaymentCurrency method in LIURecordsDaoIMPL");	

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();

			final String procedureCall = "{call ACE_CAD_BULK_PAYMENT.ACE_CAD_LIU_CURRENCY_DROP_DOWN(?,?,?)}";

			callableStatement = conn.prepareCall(procedureCall);
			callableStatement.registerOutParameter(1, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(2, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);

			callableStatement.executeUpdate();

			String errorMsgLIUCurrency=callableStatement.getString(3);
			LIUlogger.info("Error message at liuPaymentCurrency method in LIURecordsDaoIMPL:"+errorMsgLIUCurrency);

			liuCurrencyResultSet=(ResultSet) callableStatement.getObject(1);

			if (liuCurrencyResultSet == null) 
			{
				LIUlogger.info("DB returning NULL values at liuPaymentCurrency method in LIURecordsDaoIMPL");
			}
			else
			{
				while(liuCurrencyResultSet.next())
				{
					LIURecordDetails LIUCurrencyObj=new LIURecordDetails();
					LIUCurrencyObj.setDisplay(liuCurrencyResultSet.getString("DISPLAY"));
					LIUCurrencyObj.setCurrency(liuCurrencyResultSet.getString("CURRENCY"));

					liuPaymentCurrencyList.add(LIUCurrencyObj);
				}
				LIUlogger.info("Size of liuPaymentCurrencyList at liuPaymentCurrency method in LIURecordsDaoIMPL:"+liuPaymentCurrencyList);

			}
		}catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);
			return null;
		}
		finally{
			if(liuCurrencyResultSet!=null){
				try {
					liuCurrencyResultSet.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(callableStatement!=null){
				try {
					callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(conn!=null){
				try {
					conn.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}

			}
		}

		LIUlogger.info("executed liuPaymentCurrency method in LIURecordsDaoIMPL");	

		return liuPaymentCurrencyList ;
	}




	public HashMap<Integer, List<LIURecordDetails>> liuRecordSearchFirstPage(int pageNumber,LIURecordDetails liuRecordDetailsObj) throws SQLException 
	{
		// NumberFormat formatter = new DecimalFormat("#0.00");
		ResultSet resultsetdetails = null;
		CallableStatement callableStatement=null;
		HashMap<Integer, List<LIURecordDetails>> liuRecordDetailsMap=new HashMap<Integer, List<LIURecordDetails>>();
		List<LIURecordDetails> liuRecordDetailsListObj = new ArrayList<LIURecordDetails>();
		try {

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();

			LIUlogger.info("Entered liuRecordSearchFirstPage method in LIURecordsDaoIMPL");	

			final String procedureCall = "{call ACE_CAD_LIU_RECORDS_SEARCH_111(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";

			callableStatement = conn.prepareCall(procedureCall);

			callableStatement.setString(1, liuRecordDetailsObj.getPaymentMode());
			callableStatement.setString(2, liuRecordDetailsObj.getReferenceID());
			callableStatement.setString(3, liuRecordDetailsObj.getRemitterIFSC());
			callableStatement.setString(4, liuRecordDetailsObj.getAccountExtID());	
			//		callableStatement.setString(5, liuRecordDetailsObj.getFileID());
			callableStatement.setString(5, liuRecordDetailsObj.getFileName());
			callableStatement.setString(6, liuRecordDetailsObj.getLiuReason());

			callableStatement.setInt(7, pageNumber);
			callableStatement.setString(8,  liuRecordDetailsObj.getFromDate());
			callableStatement.setString(9, liuRecordDetailsObj.getToDate());
			callableStatement.setString(10,liuRecordDetailsObj.getLiuStatus());
			callableStatement.setString(11, liuRecordDetailsObj.getUserID());


			LIUlogger.info("Liu status liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+liuRecordDetailsObj.getLiuStatus());
			LIUlogger.info("Reference Id is liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getReferenceID());
			LIUlogger.info("Payment Mode is liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getPaymentMode());
			LIUlogger.info("Cheque MICR liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getRemitterIFSC());
			LIUlogger.info("Account Ext Id liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getAccountExtID());
			LIUlogger.info("File Name liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getFileName());
			LIUlogger.info("LIU Reason liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getLiuReason());
			LIUlogger.info("User Id liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getUserID());
			LIUlogger.info("To Date liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getToDate());
			LIUlogger.info("From Date liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getFromDate());

			LIUlogger.info("details entered into callable statement of liuRecordSearchFirstPage @IMPL ");

			callableStatement.registerOutParameter(12, Types.INTEGER);
			callableStatement.registerOutParameter(13, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(14,OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(15,OracleTypes.VARCHAR);


			callableStatement.executeUpdate();
			int totalPages=callableStatement.getInt(12);
			String errorMsg=callableStatement.getString(14);

			LIUlogger.info("Error message at liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+errorMsg);
			liuRecordDetailsObj.setErrorMsg(errorMsg);

			resultsetdetails = (ResultSet) callableStatement.getObject(13);

			if (resultsetdetails == null) 
			{
				LIUlogger.info("DB returning NULL values at liuRecordSearchFirstPage method in LIURecordsDaoIMPL");
			}

			else
			{
				while (resultsetdetails.next()) 
				{
					LIURecordDetails liuRecordDetailsObj1 = new LIURecordDetails();

					liuRecordDetailsObj1.setPaymentMode(resultsetdetails.getString("PAYMENT_MODE"));
					liuRecordDetailsObj1.setPaymentAmount(resultsetdetails.getDouble("PAYMENT_AMOUNT"));
					/*
					formatter.format(liuRecordDetailsObj1.getPaymentAmount());
					 LIUlogger.info("formatted Date:"+formatter.format(liuRecordDetailsObj1.getPaymentAmount()));


					BigDecimal bd = new BigDecimal(Float.toString(liuRecordDetailsObj1.getPaymentAmount()));
				    bd = bd.setScale(2, BigDecimal.ROUND_UP);
				    System.out.println("bd value:"+bd);
				    System.out.println("float value:"+bd.floatValue());

				    DecimalFormat df = new DecimalFormat("#.####");
				    df.setRoundingMode(RoundingMode.CEILING);
				    System.out.println("bd value:"+df.format(liuRecordDetailsObj1.getPaymentAmount()));*/

					liuRecordDetailsObj1.setChequeDate(resultsetdetails.getDate("CHEQUE_DATE"));
					liuRecordDetailsObj1.setCustBankAccNo(resultsetdetails.getString("CUSTOMER_BANK_ACCOUNT_NO"));
					liuRecordDetailsObj1.setPaymentReceivedDate(resultsetdetails.getString("PAYMENT_RECIEVED_DATE"));
					liuRecordDetailsObj1.setLiuTrackingID(resultsetdetails.getLong("LIU_TRACKING_ID"));
					liuRecordDetailsObj1.setSourceOfRecord(resultsetdetails.getString("SOURCE_OF_RECORD"));
					liuRecordDetailsObj1.setFileID(resultsetdetails.getString("FILE_ID"));
					liuRecordDetailsObj1.setRecordId(resultsetdetails.getLong("RECORD_ID"));					
					liuRecordDetailsObj1.setLiuReason(resultsetdetails.getString("LIU_REASON"));

					if(resultsetdetails.getString("VENDOR_ID")== null)
					{
						liuRecordDetailsObj1.setVendorID("");
					}

					else
					{
						liuRecordDetailsObj1.setVendorID(resultsetdetails.getString("VENDOR_ID"));
					}

					liuRecordDetailsObj1.setUserID(resultsetdetails.getString("USER_ID"));
					liuRecordDetailsObj1.setCircle(resultsetdetails.getString("CIRCLE"));
					liuRecordDetailsObj1.setLbxLocationID(resultsetdetails.getString("LBX_LOCATION_ID"));
					liuRecordDetailsObj1.setLbxSourceID(resultsetdetails.getString("LBX_SOURCE_ID"));
					liuRecordDetailsObj1.setSourceRefID(resultsetdetails.getString("SOURCE_REFERENCE_ID"));
					liuRecordDetailsObj1.setChangeWho(resultsetdetails.getString("CHANGE_WHO"));
					liuRecordDetailsObj1.setChangeDate(resultsetdetails.getDate("CHANGE_DATE"));
					liuRecordDetailsObj1.setInsertDate(resultsetdetails.getDate("INSERT_DATE"));
					liuRecordDetailsObj1.setStatus(resultsetdetails.getInt("STATUS"));
					liuRecordDetailsObj1.setReferenceID(resultsetdetails.getString("REF_NUMBER"));					
					liuRecordDetailsObj1.setRemitterIFSC(resultsetdetails.getString("REMITTER_IFSC"));					
					liuRecordDetailsObj1.setAccountExtID(resultsetdetails.getString("ACCT_EXT_ID"));
					liuRecordDetailsObj1.setInvoiceNumber(resultsetdetails.getString("VC_INVOICE_NO"));
					liuRecordDetailsObj1.setB2b_b2c_Segment(resultsetdetails.getString("B2B_B2C_SEGMENT"));
					liuRecordDetailsObj1.setCust_currency(resultsetdetails.getString("FX_CUSTOMER_CURRENCY"));
					liuRecordDetailsObj1.setPayment_currency(resultsetdetails.getString("PAYMENT_CURRENCY"));	
					if(liuRecordDetailsObj1.getPaymentMode().equalsIgnoreCase("OTHERS"))
					{
						liuRecordDetailsObj1.setExchange_rate(1);
					}
					else
					{
						liuRecordDetailsObj1.setExchange_rate(resultsetdetails.getDouble("EXCHANGE_RATE"));
					}
					liuRecordDetailsObj1.setFileUploadDate(resultsetdetails.getString("FILE_UPLOAD_DATE"));
					liuRecordDetailsObj1.setPendingSince(resultsetdetails.getInt("PENDING_SINCE"));
					liuRecordDetailsObj1.setDelNumber(resultsetdetails.getString("DEL_NO"));
					liuRecordDetailsObj1.setAccountType(resultsetdetails.getString("ACCOUNT_TYPE"));
					liuRecordDetailsObj1.setPaymentCode(resultsetdetails.getLong("PAYMENT_CODE"));
					liuRecordDetailsObj1.setActedIn(resultsetdetails.getInt("ACTED_IN"));
					liuRecordDetailsObj1.setEffectivePaymentAmount(resultsetdetails.getDouble("EFFECTIVE_PAYMENT_AMOUNT"));
					liuRecordDetailsObj1.setAmountInINR(resultsetdetails.getDouble("AMOUNT_IN_INR"));
					liuRecordDetailsObj1.setIncomingTransRefNum(resultsetdetails.getString("INCOMING_TRANSACTION_REF_NO"));
					liuRecordDetailsObj1.setRemitterBranch(resultsetdetails.getString("REMITTER_BRANCH"));
					liuRecordDetailsObj1.setReceiverIFSC(resultsetdetails.getString("RECEIVER_IFSC"));
					liuRecordDetailsObj1.setReceivingAcctRbi1(resultsetdetails.getString("RECEIVING_ACC_RBI1"));
					liuRecordDetailsObj1.setRemitterAcctNum(resultsetdetails.getString("REMITTER_AC_NO"));
					liuRecordDetailsObj1.setFileName(resultsetdetails.getString("FILE_NAME"));

					if(resultsetdetails.getString("VENDOR_NAME")== null)
					{
						liuRecordDetailsObj1.setVendorName("");
					}

					else
					{
						liuRecordDetailsObj1.setVendorName(resultsetdetails.getString("VENDOR_NAME"));
					}	
					liuRecordDetailsListObj.add(liuRecordDetailsObj1);
				}
			}

			liuRecordDetailsMap.put(totalPages,liuRecordDetailsListObj);
			LIUlogger.info("Size of liuRecordDetailsMap at liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+liuRecordDetailsMap);
		} catch (SQLException e) 
		{
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);
			return null;
		}
		catch(Exception e)
		{
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);
			return null;
		}
		finally{
			if(resultsetdetails!=null){
				try {
					resultsetdetails.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);			
				}
			}

			if(callableStatement!=null){
				try {
					callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(conn!=null){
				try {
					conn.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}

			}
		}
		LIUlogger.info("executed liuRecordSearchFirstPage method in LIURecordsDaoIMPL");	
		return liuRecordDetailsMap;

	}






	public LIURecordDetails downloadedFile(LIURecordDetails liuDownloadObj,/*String downloadedFilesPath,*/String extension,String pageNumber) throws SQLException
	{

		ResultSet resultsetdetails = null;
		CallableStatement callableStatement=null;

		int i=1;

		try {

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();

			LIUlogger.info("Entered downloadedFile method in LIURecordsDaoIMPL");	

			final String procedureCall = "{call ACE_CAD_LIU_RECORDS_SEARCH_111(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";

			callableStatement = conn.prepareCall(procedureCall);

			callableStatement.setString(1, liuDownloadObj.getPaymentMode());
			callableStatement.setString(2, liuDownloadObj.getReferenceID());
			callableStatement.setString(3, liuDownloadObj.getRemitterIFSC());
			callableStatement.setString(4, liuDownloadObj.getAccountExtID());	
			//			callableStatement.setString(5, liuDownloadObj.getFileID());
			callableStatement.setString(5, liuDownloadObj.getFileName());
			callableStatement.setString(6, liuDownloadObj.getLiuReason());
			callableStatement.setString(7, pageNumber);
			callableStatement.setString(8, liuDownloadObj.getFromDate());
			callableStatement.setString(9, liuDownloadObj.getToDate());
			callableStatement.setString(10,liuDownloadObj.getLiuStatus());
			callableStatement.setString(11, liuDownloadObj.getUserID());



			LIUlogger.info("FILE ID at downloadedFile method in LIURecordsDaoIMPL :"+liuDownloadObj.getFileName());
			LIUlogger.info("LIU STATUS at downloadedFile method in LIURecordsDaoIMPL:"+ liuDownloadObj.getLiuStatus());
			LIUlogger.info("Reference Id at downloadedFile method in LIURecordsDaoIMPL:"+ liuDownloadObj.getReferenceID());
			LIUlogger.info("Payment Mode at downloadedFile method in LIURecordsDaoIMPL:"+ liuDownloadObj.getPaymentMode());
			LIUlogger.info("Cheque MICR at downloadedFile method in LIURecordsDaoIMPL:"+ liuDownloadObj.getRemitterIFSC());

			LIUlogger.info("details entered into callable statement of downloadedFile @IMPL ");

			callableStatement.registerOutParameter(12, Types.INTEGER);
			callableStatement.registerOutParameter(13, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(14,OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(15,OracleTypes.VARCHAR);


			callableStatement.executeUpdate();
			int totalPages=callableStatement.getInt(12);
			String errorMsg=callableStatement.getString(14);

			LIUlogger.info("Error message at downloadedFile method in LIURecordsDaoIMPL:"+errorMsg);
			LIUlogger.info("Total No.Of Pages  at downloadedFile method in LIURecordsDaoIMPL:"+totalPages);
			liuDownloadObj.setErrorMsg(errorMsg);

			resultsetdetails = (ResultSet) callableStatement.getObject(13);

			if (resultsetdetails == null) 
			{
				LIUlogger.info("DB returning NULL values at downloadedFile method in LIURecordsDaoIMPL");
			}

			FileOutputStream downloadFile = null;

			try 
			{
				downloadFile = new FileOutputStream(new File("APS_"+liuDownloadObj.getLiuStatus()+"_"+getDateTime()+"."+extension));

				LIUlogger.info("PAYMENT MODE:"+liuDownloadObj.getPaymentMode());
				LIUlogger.info("FILE NAME:"+liuDownloadObj.getFileName());
				LIUlogger.info("LIU STATUS:"+liuDownloadObj.getLiuStatus());


				XSSFWorkbook workbook = new XSSFWorkbook();
				XSSFSheet worksheet = workbook.createSheet("LIU REPORTS");
				XSSFRow row=null;
				row = worksheet.createRow(0);
				//			HSSFCellStyle cellStyle = workbook.createCellStyle();

				XSSFCellStyle my_style = workbook.createCellStyle();
				XSSFFont my_font=workbook.createFont();
				my_font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				my_style.setFont(my_font);

				XSSFCellStyle rightAligned = workbook.createCellStyle();
				rightAligned.setAlignment(XSSFCellStyle.ALIGN_RIGHT);



				Cell cellA1 = row.createCell((short) 0);
				cellA1.setCellValue("PAYMENT MODE");
				cellA1.setCellStyle(my_style);

				Cell cellB1 = row.createCell((short) 1);
				cellB1.setCellValue("REFERENCE ID/CHEQUE/UTR");
				cellB1.setCellStyle(my_style);

				Cell cellC1 = row.createCell((short) 2);
				cellC1.setCellValue("ACCOUNT EXTERNAL ID");
				//cellStyle = workbook.createCellStyle();
				cellC1.setCellStyle(my_style);


				Cell cellD1 = row.createCell((short) 3);
				cellD1.setCellValue("DEL NUMBER");
				cellD1.setCellStyle(my_style);

				Cell cellE1 = row.createCell((short) 4);
				cellE1.setCellValue("INVOICE NUMBER");
				cellE1.setCellStyle(my_style);

				Cell cellF1 = row.createCell((short) 5);
				cellF1.setCellValue("PAYMENT AMOUNT");
				cellF1.setCellStyle(my_style);

				Cell cellG1 = row.createCell((short) 6);
				cellG1.setCellValue("PAYMENT CURRENCY");
				cellG1.setCellStyle(my_style);

				Cell cellH1 = row.createCell((short) 7);
				cellH1.setCellValue("EXCHANGE RATE");
				cellH1.setCellStyle(my_style);

				Cell cellI1 = row.createCell((short) 8);
				cellI1.setCellValue("EFFECTIVE PAYMENT AMOUNT");
				cellI1.setCellStyle(my_style);

				Cell cellJ1 = row.createCell((short) 9);
				cellJ1.setCellValue("REMITTER IFSC");
				cellJ1.setCellStyle(my_style);

				Cell cellK1 = row.createCell((short) 10);
				cellK1.setCellValue("CUSTOMER BANK ACCOUNT NO.");
				cellK1.setCellStyle(my_style);

				Cell cellL1 = row.createCell((short) 11);
				cellL1.setCellValue("LIU REASON");
				cellL1.setCellStyle(my_style);

				Cell cellM1 = row.createCell((short) 12);
				cellM1.setCellValue("FILE ID");
				cellM1.setCellStyle(my_style);

				Cell cellN1 = row.createCell((short) 13);
				cellN1.setCellValue("FILE NAME");
				cellN1.setCellStyle(my_style);

				Cell cellO1 = row.createCell((short) 14);	           
				cellO1.setCellValue("VENDOR ID");
				cellO1.setCellStyle(my_style);

				Cell cellP1 = row.createCell((short) 15);	           
				cellP1.setCellValue("VENDOR NAME");
				cellP1.setCellStyle(my_style);

				Cell cellQ1 = row.createCell((short) 16);
				cellQ1.setCellValue("USER OLM-ID");
				cellQ1.setCellStyle(my_style);

				Cell cellR1 = row.createCell((short) 17);
				cellR1.setCellValue("UPLOADED DATE");
				cellR1.setCellStyle(my_style);

				if(liuDownloadObj.getLiuStatus().equalsIgnoreCase("LIU PENDING"))
				{
					Cell cellS1 = row.createCell((short) 18);
					cellS1.setCellValue("PENDING SINCE");
					cellS1.setCellStyle(my_style);

				}
				else
				{
					Cell cellS1 = row.createCell((short) 18);
					cellS1.setCellValue("ACTED IN (DAYS)");
					cellS1.setCellStyle(my_style);

				}


				//cellStyle = workbook.createCellStyle();




				if(resultsetdetails!=null){
					while (resultsetdetails.next()) {


						LIURecordDetails liuRecordDownloadObj=new LIURecordDetails();

						if(resultsetdetails.getString("PAYMENT_MODE").equalsIgnoreCase("OTHERS"))
						{
							liuRecordDownloadObj.setPaymentMode("MISCELLANEOUS");
						}
						else
						{
							liuRecordDownloadObj.setPaymentMode(resultsetdetails.getString("PAYMENT_MODE"));
						}
						liuRecordDownloadObj.setPaymentAmount(resultsetdetails.getDouble("PAYMENT_AMOUNT"));
						liuRecordDownloadObj.setFileID(resultsetdetails.getString("FILE_ID"));
						liuRecordDownloadObj.setLiuReason(resultsetdetails.getString("LIU_REASON"));
						liuRecordDownloadObj.setVendorID(resultsetdetails.getString("VENDOR_ID"));
						liuRecordDownloadObj.setUserID(resultsetdetails.getString("USER_ID"));
						liuRecordDownloadObj.setCircle(resultsetdetails.getString("CIRCLE"));
						liuRecordDownloadObj.setReferenceID(resultsetdetails.getString("REF_NUMBER"));
						liuRecordDownloadObj.setRemitterIFSC(resultsetdetails.getString("REMITTER_IFSC"));					
						liuRecordDownloadObj.setAccountExtID(resultsetdetails.getString("ACCT_EXT_ID"));
						liuRecordDownloadObj.setInvoiceNumber(resultsetdetails.getString("VC_INVOICE_NO"));
						liuRecordDownloadObj.setB2b_b2c_Segment(resultsetdetails.getString("B2B_B2C_SEGMENT"));
						liuRecordDownloadObj.setCust_currency(resultsetdetails.getString("FX_CUSTOMER_CURRENCY"));
						liuRecordDownloadObj.setPayment_currency(resultsetdetails.getString("DISPLAY"));
						liuRecordDownloadObj.setExchange_rate(resultsetdetails.getDouble("EXCHANGE_RATE"));
						liuRecordDownloadObj.setFileUploadDate(resultsetdetails.getString("FILE_UPLOAD_DATE"));
						if(resultsetdetails.getString("VENDOR_NAME")=="")
						{
							liuRecordDownloadObj.setVendorName("");
						}
						else					
							liuRecordDownloadObj.setVendorName(resultsetdetails.getString("VENDOR_NAME"));

						liuRecordDownloadObj.setPendingSince(resultsetdetails.getInt("PENDING_SINCE"));
						liuRecordDownloadObj.setCustBankAccNo(resultsetdetails.getString("CUSTOMER_BANK_ACCOUNT_NO"));
						liuRecordDownloadObj.setVendorID(resultsetdetails.getString("VENDOR_ID"));
						liuRecordDownloadObj.setActedIn(resultsetdetails.getInt("ACTED_IN"));
						liuRecordDownloadObj.setDelNumber(resultsetdetails.getString("DEL_NO"));
						liuRecordDownloadObj.setEffectivePaymentAmount(resultsetdetails.getDouble("EFFECTIVE_PAYMENT_AMOUNT"));
						liuRecordDownloadObj.setFileName(resultsetdetails.getString("FILE_NAME"));

						row = worksheet.createRow(i);


						//	 worksheet.autoSizeColumn(0); 
						XSSFCell cellA2 = row.createCell((short) 0);
						cellA2.setCellValue(liuRecordDownloadObj.getPaymentMode());

						//	 worksheet.autoSizeColumn(1); 
						XSSFCell cellB2 = row.createCell((short) 1);
						cellB2.setCellValue(liuRecordDownloadObj.getReferenceID());

						//	 worksheet.autoSizeColumn(2); 
						XSSFCell cellC2 = row.createCell((short) 2);
						cellC2.setCellValue(liuRecordDownloadObj.getAccountExtID());

						//	worksheet.autoSizeColumn(3); 
						XSSFCell cellD2 = row.createCell((short) 3);
						cellD2.setCellValue(liuRecordDownloadObj.getDelNumber());
						cellD2.setCellStyle(rightAligned);


						//	worksheet.autoSizeColumn(4);
						XSSFCell cellE2 = row.createCell((short) 4);
						cellE2.setCellValue(liuRecordDownloadObj.getInvoiceNumber());

						//	worksheet.autoSizeColumn(5);
						XSSFCell cellF2 = row.createCell((short) 5);
						cellF2.setCellValue(liuRecordDownloadObj.getPaymentAmount());

						//		worksheet.autoSizeColumn(6);
						XSSFCell cellG2 = row.createCell((short) 6);
						cellG2.setCellValue(liuRecordDownloadObj.getPayment_currency());

						if(liuRecordDownloadObj.getPaymentMode().equalsIgnoreCase("MISCELLANEOUS"))
						{
							//  worksheet.autoSizeColumn(7);
							XSSFCell cellH2 = row.createCell((short) 7);
							cellH2.setCellValue("1.0");
						}
						else
						{
							//	    worksheet.autoSizeColumn(7);
							XSSFCell cellH2 = row.createCell((short) 7);
							cellH2.setCellValue(liuRecordDownloadObj.getExchange_rate());
						}

						if(liuRecordDownloadObj.getPaymentMode().equalsIgnoreCase("MISCELLANEOUS"))
						{
							//	worksheet.autoSizeColumn(8);
							XSSFCell cellI2 = row.createCell((short) 8);
							cellI2.setCellValue(liuRecordDownloadObj.getPaymentAmount());
						}

						else
						{
							//	worksheet.autoSizeColumn(8);
							XSSFCell cellI2 = row.createCell((short) 8);
							cellI2.setCellValue(liuRecordDownloadObj.getEffectivePaymentAmount());
						}

						//	worksheet.autoSizeColumn(9);
						XSSFCell cellJ2 = row.createCell((short) 9);
						cellJ2.setCellValue(liuRecordDownloadObj.getRemitterIFSC());

						//	worksheet.autoSizeColumn(10);
						XSSFCell cellK2 = row.createCell((short) 10);
						cellK2.setCellValue(liuRecordDownloadObj.getCustBankAccNo());

						//	worksheet.autoSizeColumn(11);
						XSSFCell cellL2 = row.createCell((short) 11);
						cellL2.setCellValue(liuRecordDownloadObj.getLiuReason());

						//	worksheet.autoSizeColumn(12);
						XSSFCell cellM2 = row.createCell((short) 12);
						cellM2.setCellValue(liuRecordDownloadObj.getFileID());

						//	worksheet.autoSizeColumn(13);
						XSSFCell cellN2 = row.createCell((short) 13);
						cellN2.setCellValue(liuRecordDownloadObj.getFileName());

						//	worksheet.autoSizeColumn(14);
						XSSFCell cellO2 = row.createCell((short) 14);
						cellO2.setCellValue(liuRecordDownloadObj.getVendorID());

						//    worksheet.autoSizeColumn(15);
						XSSFCell cellP2 = row.createCell((short) 15);
						cellP2.setCellValue(liuRecordDownloadObj.getVendorName());

						//     worksheet.autoSizeColumn(16);
						XSSFCell cellQ2 = row.createCell((short) 16);
						cellQ2.setCellValue(liuRecordDownloadObj.getUserID());

						//	worksheet.autoSizeColumn(17);
						XSSFCell cellR2 = row.createCell((short) 17);
						cellR2.setCellValue(liuRecordDownloadObj.getFileUploadDate());

						//	worksheet.autoSizeColumn(18);

						if(liuDownloadObj.getLiuStatus().equalsIgnoreCase("LIU PENDING"))
						{
							XSSFCell cellS2 = row.createCell((short) 18);
							cellS2.setCellValue(liuRecordDownloadObj.getPendingSince());
						}
						else
						{   
							XSSFCell cellS2 = row.createCell((short) 18);
							cellS2.setCellValue(liuRecordDownloadObj.getActedIn());
						}  
						i++;

					} 

					for(int j=0;j<19;j++)
					{
						worksheet.autoSizeColumn(j);

					}


					try {
						workbook.write(downloadFile);
						downloadFile.flush();
						downloadFile.close();
					} catch (IOException e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						LIUlogger.error(errors);
						return null;
					}
				}	

			}

			catch (FileNotFoundException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				LIUlogger.error(errors);
				return null;
			}
			catch (Exception e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				LIUlogger.error(errors);
				return null;

			}


		}

		finally{
			if(resultsetdetails!=null){
				try {
					resultsetdetails.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(callableStatement!=null){
				try {
					callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(conn!=null){
				try {
					conn.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);	
				}

			}
		}

		LIUlogger.info("executed downloadedFile method in LIURecordsDaoIMPL");	

		return liuDownloadObj;


	}

	public List<LIURecordDetails> modifiedLIUDetails(List<LIURecordDetails> modifiedAccountsRecords,String userId,String sessionId,String action,int pageNumber) {

		final String procedureCall = "{call ACE_CAD_BULK_PAYMENT.ACE_CAD_LIU_BULK_UPDATE_DELETE(?,?,?,?,?,?,?)}";
		CallableStatement callableStatement=null;
		ResultSet modifiedResulSetArray = null;

		List<LIURecordDetails> liuRecordsListUpdated=new ArrayList<LIURecordDetails>();

		try {

			// Get Connection instance from dataSource
			LIUlogger.info("Entered modifiedLIUDetails method in LIURecordsDaoIMPL");	

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			StructDescriptor structDescriptor = StructDescriptor.createDescriptor("LIU_UPDATE_REC_OBJ", conn);

			STRUCT[] structs = new STRUCT[modifiedAccountsRecords.size()];
			for (int index = 0; index < modifiedAccountsRecords.size(); index++)
			{
				LIURecordDetails modifiedRecordsObj = modifiedAccountsRecords.get(index);
				Object[] params = new Object[40];

				params[0] = modifiedRecordsObj.getLiuTrackingID();
				LIUlogger.info("TRACKING ID 0:"+modifiedRecordsObj.getLiuTrackingID());

				params[1] = modifiedRecordsObj.getRemitterIFSC();
				LIUlogger.info("CHEQUE IFSC 1:"+modifiedRecordsObj.getRemitterIFSC());

				params[2] = modifiedRecordsObj.getAccountExtID();
				LIUlogger.info(" ACCOUNT EXT ID 2:"+modifiedRecordsObj.getAccountExtID());

				params[3] = modifiedRecordsObj.getInvoiceNumber();
				LIUlogger.info("INVOICE NUMBER 3:"+modifiedRecordsObj.getInvoiceNumber());

				params[4] = modifiedRecordsObj.getPaymentAmount();
				LIUlogger.info("PAYMENT AMOUNT 4:"+modifiedRecordsObj.getPaymentAmount());

				params[5] = modifiedRecordsObj.getOldExchangeRate();
				LIUlogger.info("OLD EXCHANGE RATE 5:"+modifiedRecordsObj.getOldExchangeRate());

				params[6] = modifiedRecordsObj.getPayment_currency();
				LIUlogger.info("PAYMENT CURRENCY 6:"+modifiedRecordsObj.getPayment_currency());

				params[7] = modifiedRecordsObj.getExchange_rate();
				LIUlogger.info("EXCHANGE RATE 7:"+modifiedRecordsObj.getExchange_rate());

				if(modifiedRecordsObj.getPaymentMode()== null)
				{
					params[8]="";
					LIUlogger.info("PAYMENT MODE 8: payment mode is set to null");
				}
				else
				{
					params[8] = modifiedRecordsObj.getPaymentMode();
					LIUlogger.info("PAYMENT MODE 8:"+modifiedRecordsObj.getPaymentMode());


				}
				params[9] = modifiedRecordsObj.getCustomerName();
				LIUlogger.info("CUSTOMER NAME 9:"+modifiedRecordsObj.getCustomerName());

				params[10] = modifiedRecordsObj.getOrderNumber();
				LIUlogger.info("ORDER NUMBER 10:"+modifiedRecordsObj.getOrderNumber());

				if(modifiedRecordsObj.getLiuReason()==null)
				{
					params[11] ="";
					LIUlogger.info("LIU REASON 11: LIU REASON IS SET TO NULL");
				}
				else
				{
					params[11] = modifiedRecordsObj.getLiuReason();		           
					LIUlogger.info("LIU REASON 11:"+modifiedRecordsObj.getLiuReason());

				}

				params[12] = modifiedRecordsObj.getStatus();
				LIUlogger.info("STATUS 12:"+modifiedRecordsObj.getStatus());


				if(modifiedRecordsObj.getAccountType()==null)
				{
					params[13] ="";
					LIUlogger.info("ACCOUNT TYPE 13: ACCOUNT TYPE IS SET TO NULL");
				}
				else
				{
					params[13] = modifiedRecordsObj.getAccountType();
					LIUlogger.info("ACCOUNT TYPE 13:"+modifiedRecordsObj.getAccountType());
				}

				params[14] = modifiedRecordsObj.getLob();  
				LIUlogger.info("LOB 14:"+modifiedRecordsObj.getLob());

				params[15] = modifiedRecordsObj.getFxLegalEntity();  
				LIUlogger.info("LEGAL ENTITY 15:"+modifiedRecordsObj.getFxLegalEntity());

				params[16] = modifiedRecordsObj.getFxValueType();
				LIUlogger.info("FX VALUE TYPE 16:"+modifiedRecordsObj.getFxValueType());

				params[17] = modifiedRecordsObj.getFxVIPFlag();
				LIUlogger.info("FX VIP FLAG 17:"+modifiedRecordsObj.getFxVIPFlag());

				params[18] = modifiedRecordsObj.getFxCustomerType();
				LIUlogger.info("FX CUSTOMER TYPE 18:"+modifiedRecordsObj.getFxCustomerType());

				params[19] = modifiedRecordsObj.getFxCustomerClass();
				LIUlogger.info("CUSTOMER CLASS 19:"+modifiedRecordsObj.getFxCustomerClass());

				if(modifiedRecordsObj.getB2b_b2c_Segment()==null)
				{
					params[20] ="";
					LIUlogger.info("B2B B2C 20: B2B B2C IS SET TO NULL 20:");

				} 
				else
				{
					params[20] = modifiedRecordsObj.getB2b_b2c_Segment();
					LIUlogger.info("B2B B2C 20:"+modifiedRecordsObj.getB2b_b2c_Segment());
				}


				/*  params[21] = modifiedRecordsObj.getPaymentCode();
	 	           LIUlogger.info("PAYMENT CODE 21:"+modifiedRecordsObj.getPaymentCode());
				 */
				if(modifiedRecordsObj.getPaymentCode()==0)
				{
					params[21]=0;
					LIUlogger.info("PAYMENT CODE 21 : is set to null");

				}
				else
				{ 
					params[21] =modifiedRecordsObj.getPaymentCode();
					LIUlogger.info("PAYMENT CODE 21:"+modifiedRecordsObj.getPaymentCode());
				} 


				if(modifiedRecordsObj.getCust_currency()==null)
				{ 
					params[22] ="";
					LIUlogger.info(" CUST CURRENCY 22:is set to null");

				}
				else
				{
					params[22] = modifiedRecordsObj.getCust_currency();
					LIUlogger.info("CUST CURRENCY 22:"+modifiedRecordsObj.getCust_currency());

				}

				params[23] = modifiedRecordsObj.getValidInvoice();
				LIUlogger.info("VALID INVOICE 23:"+modifiedRecordsObj.getValidInvoice());

				params[24] = modifiedRecordsObj.getFileID();
				LIUlogger.info("FILE ID 24:"+modifiedRecordsObj.getFileID());

				params[25] = modifiedRecordsObj.getRecordId();
				LIUlogger.info("RECORD ID 25:"+modifiedRecordsObj.getRecordId());

				params[26] = modifiedRecordsObj.getReferenceID();
				LIUlogger.info("REFERENCE ID 26:"+modifiedRecordsObj.getReferenceID());

				params[27] = modifiedRecordsObj.getCustBankAccNo();
				LIUlogger.info("CUSTOMER BANK ACCOUNT NUMBER 27:"+modifiedRecordsObj.getCustBankAccNo());

				params[28] = modifiedRecordsObj.getRemarks();
				LIUlogger.info("REMARKS 28:"+modifiedRecordsObj.getRemarks());

				params[29] = modifiedRecordsObj.getOrigBillRefResets();
				LIUlogger.info("OrigBillRefResets 29:"+modifiedRecordsObj.getOrigBillRefResets());

				params[30] = modifiedRecordsObj.getMarketCode();
				LIUlogger.info("Market Code 30:"+modifiedRecordsObj.getMarketCode());

				params[31] = modifiedRecordsObj.getFxInternalAcctNum();
				LIUlogger.info("Fx Internal Acct Num 31:"+modifiedRecordsObj.getFxInternalAcctNum());

				params[32] = modifiedRecordsObj.getCompanyName();
				LIUlogger.info("Company Name 32:"+modifiedRecordsObj.getCompanyName());

				params[33] =modifiedRecordsObj.getPaymentCode();
				LIUlogger.info("Payment Code 33:"+modifiedRecordsObj.getPaymentCode());

				params[34] = modifiedRecordsObj.getAmountInINR();
				LIUlogger.info("Amount iN INR 34:"+modifiedRecordsObj.getAmountInINR());

				params[35] = modifiedRecordsObj.getIncomingTransRefNum();
				LIUlogger.info(" IncomingTransRefNum 35:"+modifiedRecordsObj.getIncomingTransRefNum());

				params[36] = modifiedRecordsObj.getRemitterBranch();
				LIUlogger.info("RemitterBranch 36:"+modifiedRecordsObj.getRemitterBranch());

				params[37] = modifiedRecordsObj.getReceiverIFSC();
				LIUlogger.info("ReceiverIFSC 37:"+modifiedRecordsObj.getReceiverIFSC());

				params[38] = modifiedRecordsObj.getRemitterAcctNum();
				LIUlogger.info("RemitterAcctNum 38:"+modifiedRecordsObj.getRemitterAcctNum());

				// Added By APS TEAM 
				params[39] = modifiedRecordsObj.getApsFlag();


				LIUlogger.info("Input values to Proc:");
				for(int i=0;i<params.length;i++)
				{

					LIUlogger.info(i+":"+params[i]+" ,");
				}

				STRUCT struct = new STRUCT(structDescriptor, conn, params);

				structs[index] = struct;
			}
			LIUlogger.info("Length of struct at modifiedLIUDetails method in LIURecordsDaoIMPL"+structs.length);

			ArrayDescriptor desc = ArrayDescriptor.createDescriptor("LIU_UPDATE_REC_TAB_TYPE",conn);

			ARRAY oracleArray = new ARRAY(desc, conn, structs);


			callableStatement = conn.prepareCall(procedureCall);

			callableStatement.setString(1,action);
			callableStatement.setString(2,userId);
			callableStatement.setString(3,sessionId);	
			callableStatement.setArray(4, oracleArray);
			// callableStatement.setString(5, apsFlag);

			callableStatement.registerOutParameter(5, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(6, Types.VARCHAR);
			callableStatement.registerOutParameter(7, Types.VARCHAR);

			callableStatement.executeUpdate(); 


			String errorMsg=callableStatement.getString(6);
			String errorCode=callableStatement.getString(7);

			LIUlogger.info("Error message at modifiedLIUDetails method in LIURecordsDaoIMPL:"+errorMsg );
			LIUlogger.info("Error code at modifiedLIUDetails method in LIURecordsDaoIMPL:"+errorCode );

			LIUlogger.info("Session ID at modifiedLIUDetails method in LIURecordsDaoIMPL:"+sessionId);

			modifiedResulSetArray=(ResultSet) callableStatement.getObject(5);

			if (modifiedResulSetArray == null) 
			{
				LIUlogger.info("DB returning NULL values at modifiedLIUDetails method in LIURecordsDaoIMPL");
			}

			else
			{

				while (modifiedResulSetArray.next())
				{
					LIURecordDetails modifiedLIUDetailsObj = new LIURecordDetails();

					modifiedLIUDetailsObj.setErrorMsg(errorMsg);
					modifiedLIUDetailsObj.setLiuTrackingID(modifiedResulSetArray.getInt("LIU_TRACKING_ID"));
					modifiedLIUDetailsObj.setPaymentMode(modifiedResulSetArray.getString("PAYMENT_MODE"));
					modifiedLIUDetailsObj.setRemitterIFSC(modifiedResulSetArray.getString("REMITTER_IFSC"));

					if ( (modifiedResulSetArray.getString("ACCT_EXT_ID")==null && modifiedLIUDetailsObj.getPaymentMode().equalsIgnoreCase("NEFT") ))
					{
						modifiedLIUDetailsObj.setAccountExtID("-");
					}
					else if(modifiedResulSetArray.getString("ACCT_EXT_ID")==null)
						modifiedLIUDetailsObj.setAccountExtID("-");
					else
						modifiedLIUDetailsObj.setAccountExtID(modifiedResulSetArray.getString("ACCT_EXT_ID"));

					if( (modifiedResulSetArray.getString("DERIVED_SEGMENT_B2B_B2C")==null && modifiedLIUDetailsObj.getPaymentMode().equalsIgnoreCase("NEFT") ))
					{
						modifiedLIUDetailsObj.setB2b_b2c_Segment("-");
					}
					else if(modifiedResulSetArray.getString("DERIVED_SEGMENT_B2B_B2C")==null)
						modifiedLIUDetailsObj.setB2b_b2c_Segment("-");
					else
						modifiedLIUDetailsObj.setB2b_b2c_Segment(modifiedResulSetArray.getString("DERIVED_SEGMENT_B2B_B2C"));


					if( (modifiedResulSetArray.getString("VC_INVOICE_NO")==null && modifiedLIUDetailsObj.getPaymentMode().equalsIgnoreCase("NEFT") ))
					{
						modifiedLIUDetailsObj.setInvoiceNumber("-");
					}
					else if(modifiedResulSetArray.getString("VC_INVOICE_NO")==null)
						modifiedLIUDetailsObj.setInvoiceNumber("-");
					else
						modifiedLIUDetailsObj.setInvoiceNumber(modifiedResulSetArray.getString("VC_INVOICE_NO"));


					if(modifiedLIUDetailsObj.getPaymentMode().equalsIgnoreCase("OTHERS") && modifiedResulSetArray.getString("DISPLAY")==null)
					{
						modifiedLIUDetailsObj.setPayment_currency("-");
					}
					else
					{
						modifiedLIUDetailsObj.setPayment_currency(modifiedResulSetArray.getString("DISPLAY"));
					}
					modifiedLIUDetailsObj.setExchange_rate(modifiedResulSetArray.getDouble("EXCHANGE_RATE"));
					modifiedLIUDetailsObj.setLiuReason(modifiedResulSetArray.getString("LIU_REASON"));
					modifiedLIUDetailsObj.setReferenceID(modifiedResulSetArray.getString("REF_NUMBER"));
					modifiedLIUDetailsObj.setRemarks(modifiedResulSetArray.getString("REMARKS"));
					modifiedLIUDetailsObj.setPaymentAmount(modifiedResulSetArray.getDouble("PAYMENT_AMOUNT"));
					//   modifiedLIUDetailsObj.setEffectivePaymentAmount(modifiedResulSetArray.getFloat("EFFECTIVE_PAYMENT_AMOUNT"));
					modifiedLIUDetailsObj.setFileID(modifiedResulSetArray.getString("FILE_ID"));
					modifiedLIUDetailsObj.setRecordId(modifiedResulSetArray.getLong("RECORD_ID"));
					modifiedLIUDetailsObj.setCustBankAccNo(modifiedResulSetArray.getString("CUSTOMER_BANK_ACCOUNT_NO"));

					modifiedLIUDetailsObj.setErrorMsg(errorMsg);
					modifiedLIUDetailsObj.setErrorCode(errorCode);

					liuRecordsListUpdated.add(modifiedLIUDetailsObj);

				}

			}
			LIUlogger.info("Size of liuRecordsListUpdated at modifiedLIUDetails method in LIURecordsDaoIMPL:"+liuRecordsListUpdated);


		} catch (SQLException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);
			return null;
		}
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);
			return null;
		}finally {

			if(modifiedResulSetArray!=null){
				try {
					modifiedResulSetArray.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(callableStatement!=null){
				try {
					callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(conn!=null){
				try {
					conn.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}

			}
		}
		LIUlogger.info("executed modifiedLIUDetails method in LIURecordsDaoIMPL");	

		return liuRecordsListUpdated;

	}


	public List<LIURecordDetails> eCollectAccountMapNeftCheck(List<LIURecordDetails> eCollectAccountMapRecords,String action,int pageNumber) {

		final String procedureCall = "{call ACE_CAD_LIU_NEFT_ACCT_MAP_PROC(?,?,?,?)}";
		CallableStatement callableStatement=null;
		ResultSet eCollectResulSetArray = null;

		List<LIURecordDetails> eCollectAccountMapList=new ArrayList<LIURecordDetails>();

		try {

			// Get Connection instance from dataSource
			LIUlogger.info("Entered eCollectAccountMapNeftCheck method in LIURecordsDaoIMPL");	
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();

			StructDescriptor structDescriptor = StructDescriptor.createDescriptor("LIU_UPDATE_REC_OBJ", conn);

			STRUCT[] structs = new STRUCT[eCollectAccountMapRecords.size()];
			for (int index = 0; index < eCollectAccountMapRecords.size(); index++)
			{
				LIURecordDetails eCollectAccountsMapObj = eCollectAccountMapRecords.get(index);
				//Added by APS team
				Object[] params = new Object[40];

				params[0] = eCollectAccountsMapObj.getLiuTrackingID();
				LIUlogger.info("TRACKING ID 0:"+eCollectAccountsMapObj.getLiuTrackingID());

				params[1] = eCollectAccountsMapObj.getRemitterIFSC();
				LIUlogger.info("CHEQUE IFSC 1:"+eCollectAccountsMapObj.getRemitterIFSC());

				params[2] = eCollectAccountsMapObj.getAccountExtID();
				LIUlogger.info(" ACCOUNT EXT ID 2:"+eCollectAccountsMapObj.getAccountExtID());

				params[3] = eCollectAccountsMapObj.getInvoiceNumber();
				LIUlogger.info("INVOICE NUMBER 3:"+eCollectAccountsMapObj.getInvoiceNumber());

				params[4] = eCollectAccountsMapObj.getPaymentAmount();
				LIUlogger.info("PAYMENT AMOUNT 4:"+eCollectAccountsMapObj.getPaymentAmount());

				params[5] = eCollectAccountsMapObj.getOldExchangeRate();
				LIUlogger.info("OLD EXCHANGE RATE 5:"+eCollectAccountsMapObj.getOldExchangeRate());

				params[6] = eCollectAccountsMapObj.getPayment_currency();
				LIUlogger.info("PAYMENT CURRENCY 6:"+eCollectAccountsMapObj.getPayment_currency());

				params[7] = eCollectAccountsMapObj.getExchange_rate();
				LIUlogger.info("EXCHANGE RATE 7:"+eCollectAccountsMapObj.getExchange_rate());

				if(eCollectAccountsMapObj.getPaymentMode()== null)
				{
					params[8]="";
					LIUlogger.info("PAYMENT MODE 8: payment mode is set to null");
				}
				else
				{
					params[8] = eCollectAccountsMapObj.getPaymentMode();
					LIUlogger.info("PAYMENT MODE 8:"+eCollectAccountsMapObj.getPaymentMode());


				}
				params[9] = eCollectAccountsMapObj.getCustomerName();
				LIUlogger.info("CUSTOMER NAME 9:"+eCollectAccountsMapObj.getCustomerName());

				params[10] = eCollectAccountsMapObj.getOrderNumber();
				LIUlogger.info("ORDER NUMBER 10:"+eCollectAccountsMapObj.getOrderNumber());

				if(eCollectAccountsMapObj.getLiuReason()==null)
				{
					params[11] ="";
					LIUlogger.info("LIU REASON 11: LIU REASON IS SET TO NULL");
				}
				else
				{
					params[11] = eCollectAccountsMapObj.getLiuReason();		           
					LIUlogger.info("LIU REASON 11:"+eCollectAccountsMapObj.getLiuReason());

				}

				params[12] = eCollectAccountsMapObj.getStatus();
				LIUlogger.info("STATUS 12:"+eCollectAccountsMapObj.getStatus());


				if(eCollectAccountsMapObj.getAccountType()==null)
				{
					params[13] ="";
					LIUlogger.info("ACCOUNT TYPE 13: ACCOUNT TYPE IS SET TO NULL");
				}
				else
				{
					params[13] = eCollectAccountsMapObj.getAccountType();
					LIUlogger.info("ACCOUNT TYPE 13:"+eCollectAccountsMapObj.getAccountType());
				}

				params[14] = eCollectAccountsMapObj.getLob();  
				LIUlogger.info("LOB 14:"+eCollectAccountsMapObj.getLob());

				params[15] = eCollectAccountsMapObj.getFxLegalEntity();  
				LIUlogger.info("LEGAL ENTITY 15:"+eCollectAccountsMapObj.getFxLegalEntity());

				params[16] = eCollectAccountsMapObj.getFxValueType();
				LIUlogger.info("FX VALUE TYPE 16:"+eCollectAccountsMapObj.getFxValueType());

				params[17] = eCollectAccountsMapObj.getFxVIPFlag();
				LIUlogger.info("FX VIP FLAG 17:"+eCollectAccountsMapObj.getFxVIPFlag());

				params[18] = eCollectAccountsMapObj.getFxCustomerType();
				LIUlogger.info("FX CUSTOMER TYPE 18:"+eCollectAccountsMapObj.getFxCustomerType());

				params[19] = eCollectAccountsMapObj.getFxCustomerClass();
				LIUlogger.info("CUSTOMER CLASS 19:"+eCollectAccountsMapObj.getFxCustomerClass());

				if(eCollectAccountsMapObj.getB2b_b2c_Segment()==null)
				{
					params[20] ="";
					LIUlogger.info("B2B B2C 20: B2B B2C IS SET TO NULL 20:");

				} 
				else
				{
					params[20] = eCollectAccountsMapObj.getB2b_b2c_Segment();
					LIUlogger.info(" B2B B2C 20:"+eCollectAccountsMapObj.getB2b_b2c_Segment());
				}


				/* params[21] = eCollectAccountsMapObj.getPaymentCode();
	            LIUlogger.info("PAYMENT CODE 21:"+eCollectAccountsMapObj.getPaymentCode());*/

				if(eCollectAccountsMapObj.getPaymentCode()==0)
				{
					params[21]=0;
					LIUlogger.info("Payment Code 33:"+eCollectAccountsMapObj.getPaymentCode());

				}
				else
				{ 
					params[21] =eCollectAccountsMapObj.getPaymentCode();
					LIUlogger.info("PaymentCode 33:"+eCollectAccountsMapObj.getPaymentCode());
				}


				if(eCollectAccountsMapObj.getCust_currency()==null)
				{ 
					params[22] ="";
					LIUlogger.info("CUST CURRENCY 22:: CUST CURRENCY 22 is set to null");

				}
				else
				{
					params[22] = eCollectAccountsMapObj.getCust_currency();
					LIUlogger.info("CUST CURRENCY 22:"+eCollectAccountsMapObj.getCust_currency());

				}

				params[23] = eCollectAccountsMapObj.getValidInvoice();
				LIUlogger.info("VALID INVOICE 23:"+eCollectAccountsMapObj.getValidInvoice());

				params[24] = eCollectAccountsMapObj.getFileID();
				LIUlogger.info("FILE ID 24:"+eCollectAccountsMapObj.getFileID());

				params[25] = eCollectAccountsMapObj.getRecordId();
				LIUlogger.info("RECORD ID 25:"+eCollectAccountsMapObj.getRecordId());

				params[26] = eCollectAccountsMapObj.getReferenceID();
				LIUlogger.info("REFERENCE ID 26:"+eCollectAccountsMapObj.getReferenceID());

				params[27] = eCollectAccountsMapObj.getCustBankAccNo();
				LIUlogger.info("CUSTOMER BANK ACCOUNT NUMBER 27:"+eCollectAccountsMapObj.getCustBankAccNo());

				params[28] = eCollectAccountsMapObj.getRemarks();
				LIUlogger.info("Remarks 28:"+eCollectAccountsMapObj.getRemarks());  		            

				params[29] = eCollectAccountsMapObj.getOrigBillRefResets();
				LIUlogger.info("OrigBillRefResets 29:"+eCollectAccountsMapObj.getOrigBillRefResets());

				params[30] = eCollectAccountsMapObj.getMarketCode();
				LIUlogger.info("MarketCode 30:"+eCollectAccountsMapObj.getMarketCode());

				params[31] = eCollectAccountsMapObj.getFxInternalAcctNum();
				LIUlogger.info("FxInternalAcctNum 31:"+eCollectAccountsMapObj.getFxInternalAcctNum());

				params[32] = eCollectAccountsMapObj.getCompanyName();
				LIUlogger.info("CompanyName 32:"+eCollectAccountsMapObj.getCompanyName());

				params[33] =eCollectAccountsMapObj.getPaymentCode();
				LIUlogger.info("Payment Code 33:"+eCollectAccountsMapObj.getPaymentCode());

				params[34] = eCollectAccountsMapObj.getAmountInINR();
				LIUlogger.info("AmountInINR 34:"+eCollectAccountsMapObj.getAmountInINR());

				params[35] = eCollectAccountsMapObj.getIncomingTransRefNum();
				LIUlogger.info("IncomingTransRefNum() 35:"+eCollectAccountsMapObj.getIncomingTransRefNum());

				params[36] = eCollectAccountsMapObj.getRemitterBranch();
				LIUlogger.info("RemitterBranch() 36:"+eCollectAccountsMapObj.getRemitterBranch());

				params[37] = eCollectAccountsMapObj.getReceiverIFSC();
				LIUlogger.info("ReceiverIFSC() 37:"+eCollectAccountsMapObj.getReceiverIFSC());

				params[38] = eCollectAccountsMapObj.getRemitterAcctNum();
				LIUlogger.info("RemitterAcctNum() 38:"+eCollectAccountsMapObj.getRemitterAcctNum());

				// Added By APS TEAM 
				params[39] = eCollectAccountsMapObj.getApsFlag();


				STRUCT struct = new STRUCT(structDescriptor, conn, params);

				structs[index] = struct;
			}
			System.out.println("Length of struct at eCollectAccountMapNeftCheck method in LIURecordsDaoIMPL:"+structs.length);

			ArrayDescriptor desc = ArrayDescriptor.createDescriptor("LIU_UPDATE_REC_TAB_TYPE",conn);

			ARRAY oracleArray = new ARRAY(desc, conn, structs);


			callableStatement = conn.prepareCall(procedureCall);

			callableStatement.setArray(1, oracleArray);
			callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.registerOutParameter(4, Types.VARCHAR);

			callableStatement.executeUpdate(); 


			String errorMsg=callableStatement.getString(3);
			String errorCode=callableStatement.getString(4);

			LIUlogger.info("Error message at eCollectAccountMapNeftCheck method in LIURecordsDaoIMPL:"+errorMsg );
			LIUlogger.info("Error code at eCollectAccountMapNeftCheck method in LIURecordsDaoIMPL:"+errorCode );



			eCollectResulSetArray=(ResultSet) callableStatement.getObject(2);

			if (eCollectResulSetArray == null) 
			{
				LIUlogger.info("DB returning NULL values at eCollectAccountMapNeftCheck method in LIURecordsDaoIMPL");
			}

			else
			{

				while (eCollectResulSetArray.next())
				{
					LIURecordDetails eCollectAccountMapObj = new LIURecordDetails();

					eCollectAccountMapObj.setLiuTrackingID(eCollectResulSetArray.getLong("LIU_TRACKING_ID"));
					eCollectAccountMapObj.setRemitterIFSC(eCollectResulSetArray.getString("REMITTER_IFSC"));
					eCollectAccountMapObj.setAccountExtID(eCollectResulSetArray.getString("ACCT_EXT_ID"));
					eCollectAccountMapObj.setB2b_b2c_Segment(eCollectResulSetArray.getString("DERIVED_SEGMENT_B2B_B2C"));
					eCollectAccountMapObj.setInvoiceNumber(eCollectResulSetArray.getString("VC_INVOICE_NO"));
					eCollectAccountMapObj.setPayment_currency(eCollectResulSetArray.getString("PAYMENT_CURRENCY"));
					eCollectAccountMapObj.setExchange_rate(eCollectResulSetArray.getDouble("EXCHANGE_RATE"));
					eCollectAccountMapObj.setPaymentMode(eCollectResulSetArray.getString("PAYMENT_MODE"));					   
					eCollectAccountMapObj.setLiuReason(eCollectResulSetArray.getString("LIU_REASON"));
					eCollectAccountMapObj.setReferenceID(eCollectResulSetArray.getString("REF_NUMBER"));
					eCollectAccountMapObj.setRemarks(eCollectResulSetArray.getString("REMARKS"));
					eCollectAccountMapObj.setPaymentAmount(eCollectResulSetArray.getDouble("PAYMENT_AMOUNT"));
					eCollectAccountMapObj.setFileID(eCollectResulSetArray.getString("FILE_ID"));
					eCollectAccountMapObj.setRecordId(eCollectResulSetArray.getLong("RECORD_ID"));
					eCollectAccountMapObj.setCustBankAccNo(eCollectResulSetArray.getString("CUSTOMER_BANK_ACCOUNT_NO"));
					eCollectAccountMapObj.setFxLegalEntity(eCollectResulSetArray.getString("FX_DUMMY_LEGAL_ENTITY"));
					eCollectAccountMapObj.setRemarks(eCollectResulSetArray.getString("REMARKS"));   
					eCollectAccountMapObj.setPaymentCode(eCollectResulSetArray.getLong("PAYMENT_CODE"));
					eCollectAccountMapObj.setOrderNumber(eCollectResulSetArray.getLong("ORDER_NUMBER"));
					eCollectAccountMapObj.setStatus(eCollectResulSetArray.getInt("STATUS"));
					eCollectAccountMapObj.setAccountType(eCollectResulSetArray.getString("ACCOUNT_TYPE"));
					eCollectAccountMapObj.setFileID(eCollectResulSetArray.getString("FILE_ID"));
					eCollectAccountMapObj.setAmountInINR(eCollectResulSetArray.getDouble("AMOUNT_IN_INR"));
					eCollectAccountMapObj.setIncomingTransRefNum(eCollectResulSetArray.getString("INCOMING_TRANSACTION_REF_NO"));
					eCollectAccountMapObj.setRemitterBranch(eCollectResulSetArray.getString("REMITTER_BRANCH"));
					eCollectAccountMapObj.setReceiverIFSC(eCollectResulSetArray.getString("RECEIVER_IFSC"));
					eCollectAccountMapObj.setRemitterAcctNum(eCollectResulSetArray.getString("REMITTER_AC_NO"));
					//eCollectAccountMapObj.setEffectivePaymentAmount(eCollectResulSetArray.getFloat("EFFECTIVE_PAYMENT_AMOUNT"));

					LIUlogger.info("Account Number fetched for Customer Bank Account number in NEFT case:"+eCollectAccountMapObj.getAccountExtID());
					LIUlogger.info("REMARKS eCollectAccountMapNeftCheck method in LIURecordsDaoIMPL:"+eCollectResulSetArray.getString("REMARKS"));
					LIUlogger.info("LIU TRACKING ID eCollectAccountMapNeftCheck method in LIURecordsDaoIMPL:"+eCollectResulSetArray.getString("LIU_TRACKING_ID"));
					LIUlogger.info("reason eCollectAccountMapNeftCheck method in LIURecordsDaoIMPL"+eCollectAccountMapObj.getLiuReason());

					eCollectAccountMapObj.setErrorMsg(errorMsg);
					eCollectAccountMapObj.setErrorCode(errorCode);

					eCollectAccountMapList.add(eCollectAccountMapObj);

				}
			}

			LIUlogger.info("Size of eCollectAccountMapList at eCollectAccountMapNeftCheck method in LIURecordsDaoIMPL:"+eCollectAccountMapList);


		} catch (SQLException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);
			return null;
		}
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);
			return null;
		}finally {

			if(eCollectResulSetArray!=null){
				try {
					eCollectResulSetArray.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(callableStatement!=null){
				try {
					callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(conn!=null){
				try {
					conn.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}

			}
		}
		LIUlogger.info("executed eCollectAccountMapNeftCheck method in LIURecordsDaoIMPL");	

		return eCollectAccountMapList;

	}


	public void updateNDSDetails(String accountNo, String errMsg) {

		LIUlogger.info(
				" Start:: Inside updateNDSDetails inerting into nds_acount_aps when getting read and connect time exception");
		Connection con = null;




		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			con = jdbcTemplate.getDataSource().getConnection();

			String query = "insert into NDS_accounts_aps(account_no,nds_date,error_description) values(?,sysdate,?)";
			PreparedStatement ps = con.prepareStatement(query);

			ps.setString(1, accountNo);
			ps.setString(2, errMsg);
			ps.executeQuery();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			LIUlogger.info("Exception", e);
		} finally {
			try {
				if(con!=null){
					con.close();

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				LIUlogger.info("Exception", e);
			}

		}
		LIUlogger.info(
				" END:: Inside updateNDSDetails inerting into nds_acount_aps when getting read and connect time exception");

	}

	public String getAPSFlagFromFunctions( String accountNo){

		String apsVal=null;
		try {

			Connection conn=null;
			ResultSet rs=null;
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();

			String query="Select NVL(derive_apsflag(?),derive_acctprofile_flag(?) ) from dual";

			PreparedStatement ps=conn.prepareStatement(query);
			ps.setString(1, accountNo);
			ps.setString(2, accountNo);
			rs=ps.executeQuery();
			if(rs!=null && rs.next()){
				apsVal=rs.getString(1);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			LIUlogger.info("Exception", e);
		}finally {
			try {
				if(conn!=null){
					conn.close();

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				LIUlogger.info("Exception", e);
			}

		}
		return apsVal;
	}

	public LIURecordDetails validationsFromFX(LIURecordDetails liuInputFxObj)
	{

		LIURecordDetails liuOutputFxObj = new LIURecordDetails();
		List<com.acecad.airtel.eai.integration.model.Invoice> invoiceList = null;
		//Addition By APS Team Starts
		String apsFlag = "";
		String APS = "APS";
		String CAD = "CAD";
		String aps = "";
		String accountNum = "";
		String firstVal="";
		String accountApsResponse = getAccountAps(String.valueOf(liuInputFxObj.getRecordId()));
		firstVal=liuInputFxObj.getAccountExtID().substring(0, 1);

		String[] accountAps = accountApsResponse.split(":");
		if (accountAps.length > 0) {
			accountNum = accountAps[0];
			if (accountAps.length > 1) {
				aps = accountAps[1];
			}
		}

		if (APS.equalsIgnoreCase(aps)) {
			apsFlag = "APS";
		}
		else if(CAD.equalsIgnoreCase(aps)){
			apsFlag = "CAD";
		}




		//Addition by APS Team Ends Here
		try {

			// Addition By APS Team Starts Here for NDS Dip
			if (accountNum != null && !accountNum.isEmpty() /*&& !"APS".equalsIgnoreCase(apsFlag) && !"CAD".equalsIgnoreCase(apsFlag) */) {
				if (aps.equalsIgnoreCase("NOTMENTIONED")
						|| !accountNum.equalsIgnoreCase(liuInputFxObj.getAccountExtID())) {


					//calling deriveAPS flag and account profile  Function to chack APS flag in cache tables
					//if not found then cal INT619(NDS QI) and INT632(FX QI if getting error from NDS)
					apsFlag=getAPSFlagFromFunctions(liuInputFxObj.getAccountExtID());
					//					String ndsAcctApsResponse = getApsFlag(liuInputFxObj.getAccountExtID());
					/*
					if (APS.equalsIgnoreCase(ndsAcctApsResponse)) {
						apsFlag = APS;
						updateApsFlagInDB(liuInputFxObj.getAccountExtID(), "APS1", "CHEQUE_BOUNCE");
					} else if (CAD.equalsIgnoreCase(ndsAcctApsResponse)) {

						apsFlag = CAD;
						updateApsFlagInDB(liuInputFxObj.getAccountExtID(), "CAD1", "CHEQUE_BOUNCE");
					} else {*/
					/*LIUlogger.info("NDS Call in LIURecordsDaoImpl");
					ApplicationContext context = new AnnotationConfigApplicationContext(NDSConfiguration.class);
					NDSClient ndsClient = context.getBean(NDSClient.class);
					String ndsResponse = null;

					ndsResponse = ndsClient.getNDSServiceResponse(liuInputFxObj.getAccountExtID(),null);*/

					//	apsFlag = updateApsFlagInDB(liuInputFxObj.getAccountExtID(), ndsResponse, "CHEQUE_BOUNCE");

					/*if(!apsFlag.equalsIgnoreCase("APS")){
                        apsFlag=CAD;
                        }
					}*/


					//applying NDS dip as didnt get any cache result

					if(CommonValidator.isNull(apsFlag)||(!apsFlag.equalsIgnoreCase("APS") && !apsFlag.equalsIgnoreCase("CAD")))
					{
						LIUlogger.info("NDS Call in LIURecordsDaoImpl");
						ApplicationContext context = new AnnotationConfigApplicationContext(NDSConfiguration.class);
						NDSClient ndsClient = context.getBean(NDSClient.class);
						String ndsResponse = null;

						ndsResponse = ndsClient.getNDSServiceResponse(liuInputFxObj.getAccountExtID(),null);

						LIUlogger.info("NDS Response-->> "+ndsResponse);

						String CONNECT_TEXT = "connect timed out";
						String READ_TEXT = "Read timed out";
						if (CONNECT_TEXT.equalsIgnoreCase(ndsResponse) || READ_TEXT.equalsIgnoreCase(ndsResponse)) {
							apsFlag = null;
							// UPDATE nds_ACCOUNT_aps
							String errMsg = ndsResponse;
							updateNDSDetails(liuInputFxObj.getAccountExtID(), errMsg);

						} else {

							//apsFlag = updateApsFlagInDB(liuInputFxObj.getAccountExtID(), ndsResponse, "CHEQUE_BOUNCE");
							apsFlag = updateApsFlagInDB(liuInputFxObj, null, "LIU_UPDATE");
							if("APS2".equalsIgnoreCase(apsFlag)){
								apsFlag="APS";
							}
						}
					}
				}
			}
			liuInputFxObj.setApsFlag(apsFlag);
			if (apsFlag.equalsIgnoreCase("APS")) {

				CustomerAccountSummaryClient custAccountSummaryClient = new CustomerAccountSummaryClient();
				BulkDetails fileRecords = new BulkDetails();
				fileRecords.setAcctEXTID(liuInputFxObj.getAccountExtID());
				BulkDetails bulkobjRes = custAccountSummaryClient.postCustomerAccountSummaryToFX(fileRecords,"true",null);
				//.createRequestJSONForPostCustAccountSummaryToFX(fileRecords);
				if (bulkobjRes != null) {

					if (CommonValidator.isNull(bulkobjRes.getErrorMsg())) {
						liuInputFxObj.setLob("MOB");
						liuInputFxObj.setRemarks("SUCCESS");
						liuInputFxObj.setFxLegalEntity(bulkobjRes.getLegalEntity());
						liuInputFxObj.setMarketCode(bulkobjRes.getMktCode());
						liuInputFxObj.setAccountType("CUSTOMER");
						liuInputFxObj.setB2b_b2c_Segment(bulkobjRes.getB2b2c());
						if(bulkobjRes.getB2b2c()!=null ||  !bulkobjRes.getB2b2c().isEmpty()){
							if("B2B".equalsIgnoreCase(bulkobjRes.getB2b2c())){ //invoice list
								GetCustomerInvoiceSummaryV5 customerInvoiceDetailsClient = new GetCustomerInvoiceSummaryV5();
								fileRecords =customerInvoiceDetailsClient.postUpdateCustomerInvoiceToFX(fileRecords,"");
							}	
						}
						String inr = "1";
						if(!inr.equalsIgnoreCase(liuInputFxObj.getPayment_currency())){
							liuInputFxObj.setRemarks("Currency Discrepancy");
						}

					}else{
						liuInputFxObj.setRemarks(liuInputFxObj.getLiuReason());
					}

				}

			} else {

				LIUlogger.info("Entered validationsFromFX method in LIURecordsDaoIMPL");	

				String invoice=liuInputFxObj.getInvoiceNumber();
				Request_ResponseXMLDetails Request_ResponseXMLDetails=new Request_ResponseXMLDetails();
				ECCEAIAccountDetailsIntegration ECCEAIAccountDetailsIntegration=new ECCEAIAccountDetailsIntegration();

				LIUlogger.info("ACCOUNT NUMBER at validationsFromFX method in LIURecordsDaoIMPL:"+liuInputFxObj.getAccountExtID());
				LIUlogger.info("INVOICE INPUT at validationsFromFX method in LIURecordsDaoIMPL:"+liuInputFxObj.getInvoiceNumber());
				LIUlogger.info("PAYMENT CURRENCY INPUT at validationsFromFX method in LIURecordsDaoIMPL:"+liuInputFxObj.getPayment_currency());

				// EAI INTEGRATION CODE



				LIUlogger.info("Entered EAI call for LOB at validationsFromFX method in LIURecordsDaoIMPL");

				Request_ResponseXMLDetails.setAccountExternalId(liuInputFxObj.getAccountExtID());
				Request_ResponseXMLDetails.setXMLFileName("LOB_FIND");


				try {
					Request_ResponseXMLDetails=ECCEAIAccountDetailsIntegration.eaiCall(Request_ResponseXMLDetails);
				} catch (JMSException e) {
					// TODO Auto-generated catch block
					liuInputFxObj.setRemarks("Failed: Connectivity Issue..RETRY");
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
					return liuInputFxObj;
				}


				if(Request_ResponseXMLDetails.getErrorMessage()==null||Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("0"))
				{
					LIUlogger.info("Entered LOB call at validationsFromFX method in LIURecordsDaoIMPL");
					liuInputFxObj.setLob(Request_ResponseXMLDetails.getLOB());
					liuInputFxObj.setAccountExtID(Request_ResponseXMLDetails.getAccountExternalId());
					LIUlogger.info("Finished LOB call at validationsFromFX method in LIURecordsDaoIMPL");

				}
				else if(Request_ResponseXMLDetails.getErrorMessage()!=null||!(Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("0")))
				{
					if(Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("BEAI50050E")||Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("EAI_FAILURE")||Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("EAI_NO_RESPONSE"))
					{
						liuInputFxObj.setRemarks("Failed: Connectivity Issue..RETRY");
						return liuInputFxObj;
					}
					if(Request_ResponseXMLDetails.getServ_ID()!=null)
					{
						if(Request_ResponseXMLDetails.getServ_ID().length()==0)
							Request_ResponseXMLDetails.setServ_ID(null);
					}

					if((Request_ResponseXMLDetails.getLOB().trim()==null||Request_ResponseXMLDetails.getLOB().equalsIgnoreCase(""))&&(Request_ResponseXMLDetails.getServ_ID()!=null))
					{

						//LIURecordsDaoIMPL LIURecordsDaoIMPLObj=new LIURecordsDaoIMPL();

						String lob=getLobByServId(Request_ResponseXMLDetails.getServ_ID());

						if(lob==null)
						{
							liuInputFxObj.setRemarks("Failed: INVALID ACCOUNT/MOBILE NO");
							return liuInputFxObj;
						}
						else
							liuInputFxObj.setLob(lob);
					}
					else if((Request_ResponseXMLDetails.getLOB()==null||Request_ResponseXMLDetails.getLOB().equalsIgnoreCase(""))&&(Request_ResponseXMLDetails.getServ_ID()==null||Request_ResponseXMLDetails.getServ_ID().equalsIgnoreCase("")))
					{
						LIUlogger.info("Entered to account check lenth 13 or b and account number starting with 7");
						if(liuInputFxObj.getAccountExtID().length()>13 ||(liuInputFxObj.getAccountExtID().length()==8 && "7".equals(firstVal))) {

							LIUlogger.info("in if loop of account length check");

							/*	liuInputFxObj.setRemarks("Failed: Invalid Account");
								return liuInputFxObj;//After aes lob uncomment
							 */			

							//bulkDetailsObj.setErrorCode("Invalid Account");


							Request_ResponseXMLDetails.setAccountExternalId(liuInputFxObj.getAccountExtID());
							Request_ResponseXMLDetails.setLOB("AES");
							Request_ResponseXMLDetails.setXMLFileName("LOB_FIND");
							try {
								Request_ResponseXMLDetails=ECCEAIAccountDetailsIntegration.eaiCall(Request_ResponseXMLDetails);
							} catch (JMSException e) {
								// TODO Auto-generated catch block
								liuInputFxObj.setRemarks("Failed: Connectivity Issue..RETRY");
								StringWriter errors= new StringWriter();
								e.printStackTrace(new PrintWriter(errors));
								LIUlogger.error(errors);
								return liuInputFxObj;
							}
							if(Request_ResponseXMLDetails.getErrorMessage()==null||Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("0"))
							{
								liuInputFxObj.setLob(Request_ResponseXMLDetails.getLOB());
								liuInputFxObj.setAccountExtID(Request_ResponseXMLDetails.getAccountExternalId());
								//	bulkDetailsObj.setServId(Request_ResponseXMLDetails.getServ_ID());
							}
							else
							{
								if(Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("BEAI50050E")||Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("EAI_FAILURE")||Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("EAI_NO_RESPONSE"))
								{
									liuInputFxObj.setRemarks("Failed: Connectivity Issue..RETRY");
									return liuInputFxObj;
								}
								liuInputFxObj.setRemarks("Failed: INVALID ACCOUNT/MOBILE NO");
								return liuInputFxObj;

							}

							//bulkDetailsObj.setErrorCode("INVALID ACCOUNT/MOBILE NO");

						}
						else{

							LIUlogger.info("in else block of account check conditions are failing");
							liuInputFxObj.setRemarks("Failed: INVALID ACCOUNT/MOBILE NO");
							return liuInputFxObj;
						}
					}
					/*liuInputFxObj.setRemarks("Failed: Invalid Account");
							LIUlogger.info(liuInputFxObj.getRemarks());

							LIUlogger.info(Request_ResponseXMLDetails.getErrorMessage());
							LIUlogger.info("ERROR MESSAGE @ LOB FIND:"+Request_ResponseXMLDetails.getErrorMessage());*/



				}



				//EAI CALL FOR ACCOUNT PROFILE FIND	

				if((Request_ResponseXMLDetails.getErrorMessage()==null||Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("0"))||(Request_ResponseXMLDetails.getLOB().trim()==null||Request_ResponseXMLDetails.getLOB().equalsIgnoreCase(""))&&(Request_ResponseXMLDetails.getServ_ID()!=null||!(Request_ResponseXMLDetails.getServ_ID().equalsIgnoreCase(""))))
				{

					LIUlogger.info("Entered EAI call for Account Profile Find at validationsFromFX method in LIURecordsDaoIMPL");

					Request_ResponseXMLDetails.setLOB(liuInputFxObj.getLob());
					LIUlogger.info(" LOB from FX:"+Request_ResponseXMLDetails.getLOB());

					Request_ResponseXMLDetails.setAccountExternalId(liuInputFxObj.getAccountExtID());
					LIUlogger.info(" Account Number From FX:"+Request_ResponseXMLDetails.getAccountExternalId());

					Request_ResponseXMLDetails.setXMLFileName("ACCOUNT_PROFILE_FIND");

					try {
						Request_ResponseXMLDetails=ECCEAIAccountDetailsIntegration.eaiCall(Request_ResponseXMLDetails);
					} catch (JMSException e) {
						// TODO Auto-generated catch block
						liuInputFxObj.setRemarks("Failed: Connectivity Issue..RETRY");
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						LIUlogger.error(errors);
						return liuInputFxObj;
					}

					LIUlogger.info("Error message from EAI for Account Profile:"+Request_ResponseXMLDetails.getErrorMessage());
					LIUlogger.info("Error code message from EAI for Account Profile:"+Request_ResponseXMLDetails.getErrorCode());

					if(Request_ResponseXMLDetails.getErrorMessage().equalsIgnoreCase("")||Request_ResponseXMLDetails.getErrorMessage()==null)
					{

						LIUlogger.info("Entered account profile find EAI CALL");
						LIUlogger.info("CUSTOMER NAME FROM KENAN:"+Request_ResponseXMLDetails.getCustomer_Name());

						if(Request_ResponseXMLDetails.getBillable_Flag().equalsIgnoreCase("0")&&(liuInputFxObj.getLob().equalsIgnoreCase("MOB")||liuInputFxObj.getLob().equalsIgnoreCase("BTS")))
						{
							Request_ResponseXMLDetails.setLOB(liuInputFxObj.getLob());
							Request_ResponseXMLDetails.setFXInternalAccount(Request_ResponseXMLDetails.getFxInternalAccountNumber());
							Request_ResponseXMLDetails.setServ_ID(liuInputFxObj.getServId());

							Request_ResponseXMLDetails.setXMLFileName("BILLABLE_FIND");
							try {
								Request_ResponseXMLDetails=ECCEAIAccountDetailsIntegration.eaiCall(Request_ResponseXMLDetails);
							} catch (JMSException e) {
								// TODO Auto-generated catch block
								liuInputFxObj.setRemarks("Failed: Connectivity Issue..RETRY");
								StringWriter errors= new StringWriter();
								e.printStackTrace(new PrintWriter(errors));
								LIUlogger.error(errors);
								return liuInputFxObj;
							}
							if(Request_ResponseXMLDetails.getBillableFind().getErrorInfo().getErrorMessage()==null||Request_ResponseXMLDetails.getBillableFind().getErrorInfo().getErrorMessage().equalsIgnoreCase(""))
								liuOutputFxObj.setAccountExtID(Request_ResponseXMLDetails.getBillableFind().getBillableFindOutput().getBillableAccount());
							else if(Request_ResponseXMLDetails.getBillableFind().getErrorInfo().getErrorMessage().equalsIgnoreCase("TUX ERROR"))
							{
								liuInputFxObj.setRemarks("Failed: Connectivity Issue..RETRY");
								return liuInputFxObj;
							}

							if(Request_ResponseXMLDetails.getBillableFind().getErrorInfo().getErrorMessage()==null||Request_ResponseXMLDetails.getBillableFind().getErrorInfo().getErrorMessage().equalsIgnoreCase(""))
							{
								liuOutputFxObj.setAccountExtID(liuOutputFxObj.getAccountExtID());
								Request_ResponseXMLDetails.setAccountExternalId(liuOutputFxObj.getAccountExtID());
								Request_ResponseXMLDetails.setXMLFileName("ACCOUNT_PROFILE_FIND");

								try {
									Request_ResponseXMLDetails=ECCEAIAccountDetailsIntegration.eaiCall(Request_ResponseXMLDetails);
								} catch (JMSException e) {
									// TODO Auto-generated catch block
									liuInputFxObj.setRemarks("Failed: Connectivity Issue..RETRY");
									StringWriter errors= new StringWriter();
									e.printStackTrace(new PrintWriter(errors));
									LIUlogger.error(errors);
									return liuInputFxObj;
								}
								if(Request_ResponseXMLDetails.getErrorMessage()==null||Request_ResponseXMLDetails.getErrorMessage().equalsIgnoreCase(""))
								{
									liuOutputFxObj.setAccountType("CUSTOMER");
									liuOutputFxObj.setFxCustomerType(Request_ResponseXMLDetails.getCustomer_Type());
									liuOutputFxObj.setFxValueType(Request_ResponseXMLDetails.getValue_Type());
									liuOutputFxObj.setFxVIPFlag(Request_ResponseXMLDetails.getVIP_Flag());
									liuOutputFxObj.setFxCustomerClass(Request_ResponseXMLDetails.getCustomer_Clasification());
									liuOutputFxObj.setFxLegalEntity(Request_ResponseXMLDetails.getLegal_Entity());
									liuOutputFxObj.setCust_currency(Request_ResponseXMLDetails.getCustomer_Currency());
									liuOutputFxObj.setCustomerName(Request_ResponseXMLDetails.getCustomer_Name());
									liuOutputFxObj.setMarketCode(Request_ResponseXMLDetails.getMktCode());
									liuOutputFxObj.setFxInternalAcctNum(Request_ResponseXMLDetails.getFxInternalAccountNumber());
									liuOutputFxObj.setCompanyName(Request_ResponseXMLDetails.getBillCompany());
									invoiceList=Request_ResponseXMLDetails.getInvoice();
								}
								else
								{
									liuInputFxObj.setRemarks(Request_ResponseXMLDetails.getErrorMessage());
									LIUlogger.info("Error message from FX:"+Request_ResponseXMLDetails.getErrorMessage());
								}

							}
						}		
						else
						{
							liuOutputFxObj.setAccountType("CUSTOMER");
							liuOutputFxObj.setFxCustomerType(Request_ResponseXMLDetails.getCustomer_Type());
							liuOutputFxObj.setFxValueType(Request_ResponseXMLDetails.getValue_Type());
							liuOutputFxObj.setFxVIPFlag(Request_ResponseXMLDetails.getVIP_Flag());
							liuOutputFxObj.setFxCustomerClass(Request_ResponseXMLDetails.getCustomer_Clasification());
							liuOutputFxObj.setFxLegalEntity(Request_ResponseXMLDetails.getLegal_Entity());
							liuOutputFxObj.setCust_currency(Request_ResponseXMLDetails.getCustomer_Currency());
							liuOutputFxObj.setCustomerName(Request_ResponseXMLDetails.getCustomer_Name());
							liuOutputFxObj.setMarketCode(Request_ResponseXMLDetails.getMktCode());
							liuOutputFxObj.setFxInternalAcctNum(Request_ResponseXMLDetails.getFxInternalAccountNumber());
							liuOutputFxObj.setCompanyName(Request_ResponseXMLDetails.getBillCompany());
							invoiceList=Request_ResponseXMLDetails.getInvoice();
						}

						LIUlogger.info("CUSTOMER CURRENCY CODE FROM FX:"+Request_ResponseXMLDetails.getCustomer_Currency());

						LIUlogger.info("INVOICE INPUT IS:"+invoice);			
						LIUlogger.info("CUSTOMER TYPE:"+Request_ResponseXMLDetails.getCustomer_Type());
						LIUlogger.info("VALUE TYPE:"+Request_ResponseXMLDetails.getValue_Type());
						LIUlogger.info("VIP FLAG:"+Request_ResponseXMLDetails.getVIP_Flag());
						LIUlogger.info("CUSTOMER CLASSIFICATION:"+Request_ResponseXMLDetails.getCustomer_Clasification());
						LIUlogger.info("ACCOUNT TYPE:"+liuOutputFxObj.getAccountType());

						LIUlogger.info("Payment Mode:"+liuInputFxObj.getPaymentMode());

						if(liuInputFxObj.getPaymentMode().equalsIgnoreCase("neft") || liuInputFxObj.getPaymentMode().equalsIgnoreCase("cheque"))
						{
							LIUlogger.info("In case of NEFT and CHEQUE Payment Modes");
							if(liuInputFxObj.getPayment_currency().equals(liuOutputFxObj.getCust_currency()))

							{     
								liuInputFxObj.setValidInvoice("SUCCESS");
								liuInputFxObj.setRemarks("SUCCESS");

								LIUlogger.info("PAYMENT CURRENCY AND CUST CURRENCY ARE SAME..");
							}

							else
							{
								if(liuInputFxObj.getPaymentMode().equalsIgnoreCase("NEFT"))
								{
									liuInputFxObj.setValidInvoice("FAILURE");
									liuInputFxObj.setRemarks("Failed: Payment currency mismatch to mapped E-Collect account");

									LIUlogger.info("PAYMENT CURRENCY IS NOT VALID(IN CASE OF NEFT PAYMENT MODE)");

								}
								else
								{
									liuInputFxObj.setValidInvoice("FAILURE");
									liuInputFxObj.setRemarks("Failed: Customer currency and payment currency mismatch");
									LIUlogger.info("PAYMENT CURRENCY IS NOT VALID");
								}
							}

						}
						else if (liuInputFxObj.getPaymentMode().equalsIgnoreCase("OTHERS"))
						{
							LIUlogger.info("in case of others");

							liuInputFxObj.setValidInvoice("SUCCESS");
							liuInputFxObj.setRemarks("SUCCESS");

							LIUlogger.info("In case of payment mode:OTHERS currency is not compared");
						}



						for(int i=0;i<invoiceList.size();i++)
						{
							System.out.println("INVOICE LIST"+i+" :"+invoiceList);
						}


						for(com.acecad.airtel.eai.integration.model.Invoice inv:invoiceList)
						{
							LIUlogger.info("In invoice loop");
							LIUlogger.info("Invoice numbers fromFX:"+inv.getBillRefNo());

							if(inv.getBillRefNo()==invoice)
							{
								LIUlogger.info("Entered EAI call for invoice");
								liuOutputFxObj.setInvoiceNumber(inv.getBillRefNo());
								LIUlogger.info("INVOICE FROM FX:"+liuOutputFxObj.getInvoiceNumber());

								liuOutputFxObj.setOrigBillRefNo(inv.getBillRefNo());
								liuOutputFxObj.setOrigBillRefResets(Double.parseDouble(inv.getBillRefResets()));
								LIUlogger.info("BILL REF NUMBER RESETS FROM FX:"+liuOutputFxObj.getOrigBillRefResets());
								liuInputFxObj.setInvoiceNumber(liuOutputFxObj.getInvoiceNumber());

							}

							else
							{
								liuInputFxObj.setInvoiceNumber("0");
								LIUlogger.info("INVOICE POSTED WITH 0.. INVOICE NOT FOUND");
								liuOutputFxObj.setOrigBillRefResets(0);
								LIUlogger.info("BILL REF NUMBER RESETS FROM FX:"+liuOutputFxObj.getOrigBillRefResets());
							}	

						}//FOR LOOP (INVOICE CHECK IN FX)


					}// IF (CHECK TO FIND ACCOUNT IN FX IN CASE OF ERROR MESSAGE IS NULL)


					else if(Request_ResponseXMLDetails.getErrorMessage().equalsIgnoreCase("TUX ERROR")||Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("EAI_FAILURE")||Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("EAI_NO_RESPONSE"))
					{
						liuInputFxObj.setRemarks("Failed: Connectivity Issue..RETRY");
						return liuInputFxObj;
					}		


					else 
					{
						liuInputFxObj.setRemarks("Failed: INVALID ACCOUNT/MOBILE NO");
					}

				}// END IF (CHECK TO FIND ACCOUNT IN FX AT EAI CALL)


				else if(Request_ResponseXMLDetails.getErrorMessage().equalsIgnoreCase("TUX ERROR")||Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("EAI_FAILURE")||Request_ResponseXMLDetails.getErrorCode().equalsIgnoreCase("EAI_NO_RESPONSE"))
				{
					liuInputFxObj.setRemarks("Failed: Connectivity Issue..RETRY");
					return liuInputFxObj;
				}		

				else
				{
					if(liuInputFxObj.getPaymentMode().equalsIgnoreCase("NEFT"))
					{
						liuInputFxObj.setRemarks("Failed: Mapped E-Collect account is invalid");
					}
					else
					{
						//Remarks should be changed in this case..

						LIUlogger.info("Error at validationsFromFx:"+Request_ResponseXMLDetails.getErrorMessage());

						liuInputFxObj.setRemarks("Failed: INVALID ACCOUNT/MOBILE NO");
					}
					return liuInputFxObj;
				}

				liuInputFxObj.setFxCustomerClass(liuOutputFxObj.getFxCustomerClass());
				liuInputFxObj.setFxCustomerType(liuOutputFxObj.getFxCustomerType());
				liuInputFxObj.setFxLegalEntity(liuOutputFxObj.getFxLegalEntity());
				liuInputFxObj.setFxValueType(liuOutputFxObj.getFxValueType());
				liuInputFxObj.setFxVIPFlag(liuOutputFxObj.getFxVIPFlag());
				liuInputFxObj.setOrigBillRefNo(liuOutputFxObj.getOrigBillRefNo());
				liuInputFxObj.setOrigBillRefResets(liuOutputFxObj.getOrigBillRefResets());
				liuInputFxObj.setCustomerName(liuOutputFxObj.getCustomerName());
				liuInputFxObj.setCompanyName(liuOutputFxObj.getCompanyName());
				liuInputFxObj.setFxInternalAcctNum(liuOutputFxObj.getFxInternalAcctNum());
				liuInputFxObj.setMarketCode(liuOutputFxObj.getMarketCode());

				if(liuInputFxObj.getPaymentMode().equalsIgnoreCase("OTHERS"))
				{
					// liuInputFxObj.setCust_currency("-");
					liuInputFxObj.setCust_currency(liuOutputFxObj.getCust_currency());

				}
				else
				{
					liuInputFxObj.setCust_currency(liuOutputFxObj.getCust_currency());
				}
				liuInputFxObj.setAccountType(liuOutputFxObj.getAccountType());

			}// TRY BLOCK 
		} 
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);
			liuInputFxObj.setRemarks("Failed: Connectivity Issue..RETRY..");
			LIUlogger.info(liuInputFxObj.getRemarks());
			LIUlogger.info("In catch block exception handling.. ");
			return liuInputFxObj;

		}


		return liuInputFxObj;

	}

	private String getLobByServId(String serv_ID) {
		// TODO Auto-generated method stub
		final String procedureCall = "{call LOB_SERV_ID(?,?)}";

		CallableStatement callableStatement=null;
		String lob=null;
		try
		{
			LIUlogger.info("Entered getLobByServId method in LIURecordsDaoIMPL");	

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			// fileObj.setConnection(connection);
			conn.setAutoCommit(false);
			callableStatement = (CallableStatement) conn
					.prepareCall(procedureCall);
			callableStatement.setString(1, serv_ID);

			callableStatement.registerOutParameter(2, Types.VARCHAR);

			callableStatement.executeUpdate();
			lob = callableStatement.getString(2);

		} catch (Exception e) {

		}
		finally{
			try {
				if(callableStatement!=null)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if(conn!=null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return lob;
	}// METHOD END


	// by ***************** APS team *****************************

	/**
	 * This method update APS Flag in DB after getting the response from NDS
	 * Service.
	 * 
	 * @param accountNumber-
	 *            Input
	 * @param ndsResponse
	 *            - Response from NDS Service as input
	 * @param multi_Service-
	 *            Comma separated values
	 * @param con
	 *            -Connection Object
	 */

	public void updateINT632Details(String accountNo, String apsflagval,String errMsg,String b2b,String mktCode,String legrlEntity,String msisdnVal,String parentAccount) {

		LIUlogger.info(
				" Start:: Inside updateINT632Details inerting into nds_acount_aps when getting read and connect time exception");
		Connection con = null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			con = jdbcTemplate.getDataSource().getConnection();

			if(!CommonValidator.isNull(errMsg)){
				LIUlogger.info("inside error descri");

				String query = "insert into ACCOUNT_PROFILE_APS(account_no,inthit_date,aps_flag,error_description,msisdn) values(?,systimestamp,?,?,?)";
				PreparedStatement ps = con.prepareStatement(query);

				ps.setString(1, accountNo);
				ps.setString(2, apsflagval);
				ps.setString(3, errMsg);
				ps.setString(4, msisdnVal);

				ps.executeQuery();
			}

			else{

				String query = "insert into ACCOUNT_PROFILE_APS(account_no,inthit_date,aps_flag,b2b_b2c,legal_entity,mkt_code,msisdn,parent_account_no) values(?,systimestamp,?,?,?,?,?,?)";
				PreparedStatement ps = con.prepareStatement(query);

				ps.setString(1, accountNo);
				ps.setString(2, apsflagval);
				ps.setString(3, b2b);
				ps.setString(4, legrlEntity);
				ps.setString(5, mktCode);
				ps.setString(6, msisdnVal);
				ps.setString(7, parentAccount);


				ps.executeQuery();

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			LIUlogger.info("Exception", e);
		} finally {
			try {
				if(con!=null){
					con.close();

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				LIUlogger.info("Exception", e);
			}

		}
		LIUlogger.info(
				" END:: Inside updateINT632Details inerting into nds_acount_aps when getting read and connect time exception");

	}

	/*	public String updateApsFlagInDB(LIURecordDetails liuInputFxObj, String ndsResponse, String multi_Service) {




		LIUlogger.info("START----in updateApsFlagInDB method of AccountDetailsClientThread");
		String errorCodeAndDescription = null;
		Connection con = null;
		String retValue = null;
		boolean flag =true;

		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			con = jdbcTemplate.getDataSource().getConnection();

			LIUlogger.info("connection updateApsFlagInDB  __________" + con);
			con.setAutoCommit(false);
		} catch (Exception e) {
			LIUlogger.info("Connection not established  updateApsFlagInDB", e);
		}

		try {
			if (ndsResponse.equalsIgnoreCase("true")) {

				ndsResponse = "APS";
				retValue = ndsResponse;

			} else if (ndsResponse.equalsIgnoreCase("false") || ndsResponse.isEmpty() || ndsResponse.equals("")) {
				ndsResponse = "CAD";
				retValue = ndsResponse;
			} else {
				//call here 632

				BulkDetails bulkDetails = new BulkDetails();
				//	accountNumber="1739810440";
				if(!CommonValidator.isNull(accountNumber)){
					bulkDetails.setAcctEXTID(accountNumber);
				}

				CustAccountSummaryClient custAccountSummaryClient = new CustAccountSummaryClient();
				LIUlogger.info("Before calling INT_632 and account no is --->>" + accountNumber
						+ " in AccountDetailsClientThread");
				BulkDetails bulkdetails1 = custAccountSummaryClient
						.createRequestJSONForPostCustAccountSummaryToFX(bulkDetails);
				LIUlogger.info("After calling INT_632 fx_outstanding_amount is in Call method---->>>"
						+ bulkdetails1.getFxOutstandingAmount() + "and accountNo is-->>" + accountNumber
						+ " in AccountDetailsClientThread");

				LIUlogger.info("ERROR from 632Int in MULITHREADCALLL-->> "+bulkdetails1.getErrorMsg());



				String CONNECT_TEXT = "connect timed out";
				String READ_TEXT = "Read timed out";

				if(bulkdetails1.getErrorMsg() != null){

					if(READ_TEXT.equalsIgnoreCase(bulkdetails1.getErrorMsg()) || 
							CONNECT_TEXT.equalsIgnoreCase(bulkdetails1.getErrorMsg())){


						flag=false;
						updateINT632Details(accountNumber,null ,bulkdetails1.getErrorMsg(),null,null,null,null,null);
					}
					else{

						LIUlogger.info("Eror MSG for INT 632-->> "+bulkdetails1.getErrorMsg());

						errorCodeAndDescription="Error from INT 632-> "+bulkdetails1.getErrorMsg();
						retValue="ERROR";
						updateINT632Details(accountNumber,"ERROR" ,bulkdetails1.getErrorMsg(),null,null,null,null,null);
					}

				}
				else{

					String b2b=bulkdetails1.getB2b2c();
					String mktCode=bulkdetails1.getMktCode();
					String legelEntity=bulkdetails1.getLegalEntity();

					if(!CommonValidator.isNull(bulkdetails1.getAcctEXTID()) || !CommonValidator.isNull(bulkdetails1.getParentAccountNumber())){


						if(!CommonValidator.isNull(accountNumber)){
							//accountNumber=bulkdetails1.getAcctEXTID();

							ndsResponse="APS2";
							retValue = ndsResponse;
							updateINT632Details(accountNumber, "APS", null,b2b,mktCode,legelEntity,bulkdetails1.getDelNO(),null);

						}


					}
					else{

						ndsResponse="CAD";
						retValue = ndsResponse;
						updateINT632Details(accountNumber, "CAD", null,b2b,mktCode,legelEntity,null,null);
						//int632Flag=ndsResponse;

					}

				}
			}
			LIUlogger.info("ndsResponse  in updateApsFlagInDB method,---->" + ndsResponse);

			if (!CommonValidator.isNull(multi_Service) && con != null  && flag==true) {
				LIUlogger.info("When accountNumber and  multi_Service is not null msisdn val->"+multi_Service);
				String procStr = "{call UPDATE_APS_FLAG_PROC_APS(?,?,?,?,?)}";
				CallableStatement callableStatement = con.prepareCall(procStr);
				callableStatement.setString(1, accountNumber);
				callableStatement.setString(2, null);
				callableStatement.setString(3, multi_Service);
				if (CommonValidator.isNull(errorCodeAndDescription)) {
					callableStatement.setString(4, null);
					callableStatement.setString(5, ndsResponse);
				} else {
					callableStatement.setString(4, errorCodeAndDescription);
					callableStatement.setString(5, null);
				}

				callableStatement.registerOutParameter(5, Types.VARCHAR);
				callableStatement.executeUpdate();
				ndsResponse = callableStatement.getString(5);
				LIUlogger.info("ndsResponse-->>"+ndsResponse);
				// retValue="APS";

			} else {
				retValue = "Failure :: One of the Input argument is null";
			}

		} catch (Exception e) {
			LIUlogger.info("Exception  in updateApsFlagInDB method", e);
		} finally {

			if (con != null)
				try {
					con.commit();
					con.close();
				} catch (Exception e) {
					LIUlogger.info("Exception  in updateApsFlagInDB method", e);
				}
		}
		LIUlogger.info("END----in updateApsFlagInDB method of AccountDetailsClientThread  RESULT FROM retValue------>"
				+ retValue);
		return retValue;


		/*

		LIUlogger.info("START:updateApsFlagInDB  ");
		String errorCodeAndDescription = null;
		String retValue = null;
		Connection connection = null;
		try {
			try {
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				connection = jdbcTemplate.getDataSource().getConnection();
				LIUlogger.info("aps flag from nds service-->> " + ndsResponse);
			} catch (Exception e) {
				// e.printStackTrace();
				LIUlogger.info("Conection :: ", e);
			}
			if (ndsResponse.equalsIgnoreCase("true")) {

				ndsResponse = "APS";
				retValue = ndsResponse;

			} else if (ndsResponse.equalsIgnoreCase("false") || ndsResponse.isEmpty() || ndsResponse.equals("")) {

				ndsResponse = "CAD";
				retValue = ndsResponse;

			} else {

				errorCodeAndDescription = ndsResponse;
				retValue = ndsResponse;

			}

			if (!CommonValidator.isNull(accountNumber) && !CommonValidator.isNull(multi_Service)
					&& connection != null) {

				String procStr = "{call UPDATE_APS_FLAG_PROC_APS(?,?,?,?,?)}";
				CallableStatement callableStatement = connection.prepareCall(procStr);
				callableStatement.setString(1, accountNumber);
				callableStatement.setString(2, null);
				callableStatement.setString(3, multi_Service);
				if (CommonValidator.isNull(errorCodeAndDescription)) {
					callableStatement.setString(4, null);
					callableStatement.setString(5, ndsResponse);
				} else {
					callableStatement.setString(4, errorCodeAndDescription);
					callableStatement.setString(5, null);
				}

				callableStatement.registerOutParameter(5, Types.VARCHAR);
				callableStatement.executeQuery();
				ndsResponse = callableStatement.getString(5);
				// retValue="APS";

			} else {
				retValue = "Failure :: One of the Input argument is null";
			}

		} catch (BeansException e) {
			// e.printStackTrace();
			LIUlogger.info("Exception :: ", e);
		} catch (SQLException e) {
			// e.printStackTrace();
			LIUlogger.info("Exception :: ", e);
		} finally {

			if (connection != null)
				try {
					connection.close();
				} catch (Exception e) {
					// e.printStackTrace();
					LIUlogger.info("Exception :: ", e);
				}
		}
		LIUlogger.info("END :updateApsFlagInDB retValue------  " + retValue);
		return retValue;
	 */
	public String updateApsFlagInDB(LIURecordDetails liuInputFxObj, String ndsResponse, String multi_Service) {

		LIUlogger.info("START----in updateApsFlagInDB method of AccountDetailsClientThread");
		String errorCodeAndDescription = null;
		Connection con = null;
		String retValue = null;
		boolean flag =true;
		BulkDetails bulkdetails1 =null;
		String accountNumber=liuInputFxObj.getAccountExtID();
		String msisdn=liuInputFxObj.getDelNumber();

		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			con = jdbcTemplate.getDataSource().getConnection();
			LIUlogger.info("connection updateApsFlagInDB  __________" + con);
			con.setAutoCommit(false);
		} catch (Exception e) {
			LIUlogger.info("Connection not established  updateApsFlagInDB", e);
		}

		try {

			//call here 632

			BulkDetails bulkDetails = new BulkDetails();
			//	accountNumber="1739810440";
			if(!CommonValidator.isNull(accountNumber)){
				bulkDetails.setAcctEXTID(accountNumber);
			}
			else{
				bulkDetails.setDelNO(msisdn);
			}
			CustomerAccountSummaryClient custAccountSummaryClient = new CustomerAccountSummaryClient();
			LIUlogger.info("Before calling INT_632 and account no is --->>" + accountNumber
					+ " in AccountDetailsClientThread");
			bulkdetails1 = custAccountSummaryClient
					.postCustomerAccountSummaryToFX(bulkDetails,"false",null);
			LIUlogger.info("After calling INT_632 fx_outstanding_amount is in Call method---->>>"
					+ bulkdetails1.getFxOutstandingAmount() + "and accountNo is-->>" + accountNumber
					+ " in AccountDetailsClientThread");

			LIUlogger.info("Error from INT 632-->>"+bulkdetails1.getErrorMsg());

			if(bulkdetails1.getErrorMsg() != null){

				if("Read timed out".equalsIgnoreCase(bulkdetails1.getErrorMsg()) || 
						"connect timed out".equalsIgnoreCase(bulkdetails1.getErrorMsg())){


					flag=false;
					updateINT632Details(accountNumber,null ,msisdn,bulkdetails1);
					retValue=null;
				}
				else{

					LIUlogger.info("Error MSG for INT 632-->> "+bulkdetails1.getErrorMsg());

					errorCodeAndDescription="Error from INT 632-> "+bulkdetails1.getErrorMsg();
					retValue="ERROR";
					updateINT632Details(accountNumber,"ERROR" ,msisdn,bulkdetails1);
					//retValue=retValue;
				}

			}
			else{

				String b2b=bulkdetails1.getB2b2c();
				String mktCode=bulkdetails1.getMktCode();
				String legelEntity=bulkdetails1.getLegalEntity();



				LIUlogger.info("account_number--->>"+bulkdetails1.getAcctEXTID()+" legelEntity-->>"+legelEntity+ "b2b-->>"+b2b+" mktCode-->>"+mktCode);
				if(!CommonValidator.isNull(bulkdetails1.getAcctEXTID()) || !CommonValidator.isNull(bulkdetails1.getParentAccountNumber())){


					if(!CommonValidator.isNull(accountNumber)){
						//accountNumber=bulkdetails1.getAcctEXTID();

						ndsResponse="APS2";
						retValue = ndsResponse;
						updateINT632Details(accountNumber, "APS",bulkdetails1.getDelNO(),bulkdetails1);
						//int632Flag=ndsResponse;

					}
					else{

						if(CommonValidator.isNull(accountNumber) && !CommonValidator.isNull(msisdn)){


							ndsResponse="APS2";
							retValue = ndsResponse;
							updateINT632Details(accountNumber, "APS",msisdn,bulkdetails1);
							//	int632Flag=ndsResponse;

						}
					}

				}
				else{

					ndsResponse="CAD";
					retValue = ndsResponse;
					updateINT632Details(accountNumber, "CAD",msisdn,bulkdetails1);
					//int632Flag=ndsResponse;

				}

			}

			LIUlogger.info("ndsResponse  in updateApsFlagInDB method,---->" + ndsResponse);

			if (!CommonValidator.isNull(multi_Service) && con != null  && flag==true) {
				LIUlogger.info("error description-->>"+errorCodeAndDescription+" accountval--->> "+accountNumber+"  msisdn val-> "+msisdn+"  multi service-->> "+multi_Service);
				String procStr = "{call UPDATE_APS_FLAG_PROC_APS(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
				CallableStatement callableStatement = con.prepareCall(procStr);
				callableStatement.setString(1, accountNumber);
				callableStatement.setString(2, msisdn);
				callableStatement.setString(3, multi_Service);
				if (CommonValidator.isNull(errorCodeAndDescription)) {
					callableStatement.setString(4, null);
					callableStatement.setString(5, ndsResponse);
				} else {
					callableStatement.setString(4, errorCodeAndDescription);
					callableStatement.setString(5, null);
				}

				callableStatement.registerOutParameter(5, Types.VARCHAR);

				//

				callableStatement.setString(6, bulkdetails1.getB2b2c());
				callableStatement.setString(7, bulkdetails1.getLegalEntity());
				callableStatement.setString(8, bulkdetails1.getParentAccountNumber());
				callableStatement.setString(9, bulkdetails1.getPrimaryContactNumber());
				callableStatement.setString(10, bulkdetails1.getCustomerType());
				callableStatement.setString(11, bulkdetails1.getCustomerClass());
				callableStatement.setString(12, bulkdetails1.getVipFlag());
				callableStatement.setString(13, bulkdetails1.getAccountCategory());
				callableStatement.setString(14, bulkdetails1.getGivenName()+" "+bulkdetails1.getFamilyName());
				callableStatement.setString(15, bulkdetails1.getOrigBillRefNo());
				callableStatement.setString(16, bulkdetails1.getOrigBillRefResets());


				callableStatement.executeUpdate();
				ndsResponse = callableStatement.getString(5);
				LIUlogger.info("response->"+ndsResponse+"  msisdn val-->>"+msisdn);
				// retValue="APS";

			} else {
				retValue = "Failure :: One of the Input argument is null";
			}

		} catch (Exception e) {
			LIUlogger.info("Exception  in updateApsFlagInDB method", e);
		} finally {

			if (con != null)
				try {
					con.commit();
					con.close();
				} catch (Exception e) {
					LIUlogger.info("Exception  in updateApsFlagInDB method", e);
				}
		}
		LIUlogger.info("END----in updateApsFlagInDB method of AccountDetailsClientThread  RESULT FROM retValue------>"
				+ retValue);
		return retValue;
	}

	public void updateINT632Details(String accountNo, String apsflagval,String msisdnVal,BulkDetails bulkdetails1) {

		LIUlogger.info(
				" Start:: Inserting account profile aps details");
		Connection con = null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			con = jdbcTemplate.getDataSource().getConnection();
			if(!CommonValidator.isNull(bulkdetails1.getErrorMsg())){
				LIUlogger.info("inside error descri");

				String query = "insert into ACCOUNT_PROFILE_APS(account_no,inthit_date,aps_flag,error_description,msisdn) values(?,systimestamp,?,?,?)";
				PreparedStatement ps = con.prepareStatement(query);

				ps.setString(1, accountNo);
				ps.setString(2, apsflagval);
				ps.setString(3, bulkdetails1.getErrorMsg());
				ps.setString(4, msisdnVal);

				ps.executeQuery();
			}

			else{

				String query = "insert into ACCOUNT_PROFILE_APS(account_no,aps_flag,b2b_b2c,"
						+ "legal_entity,mkt_code,msisdn,parent_account_no,"
						+ "PRIMARY_CONTACT_NUMBER,ALTERNATE_CONTACT,CUSTOMER_TYPE,CUSTOMER_CLASS,VIP_FLAG,"
						+ "ACCOUNT_CATEGORY,INDIVIDUAL_NAME,BILL_REF_NUMBER,BILL_REF_RESETS,inthit_date) "
						+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,systimestamp)";
				PreparedStatement ps = con.prepareStatement(query);

				ps.setString(1, accountNo);
				ps.setString(2, apsflagval);
				ps.setString(3, bulkdetails1.getB2b2c());
				ps.setString(4, bulkdetails1.getLegalEntity());
				ps.setInt(5, Integer.parseInt(bulkdetails1.getMktCode()));
				ps.setString(6, msisdnVal);
				ps.setString(7, bulkdetails1.getParentAccountNumber());
				ps.setString(8, bulkdetails1.getPrimaryContactNumber());
				ps.setString(9,bulkdetails1.getAlternateContactNumber());
				if(bulkdetails1.getCustomerType()!=null){
					ps.setInt(10, Integer.parseInt(bulkdetails1.getCustomerType()));
				}
				else
					ps.setNull(10,java.sql.Types.INTEGER);


				if(bulkdetails1.getCustomerClass()!=null){
					ps.setInt(11, Integer.parseInt(bulkdetails1.getCustomerClass()));
				}
				else
					ps.setNull(11,java.sql.Types.INTEGER);

				if(bulkdetails1.getVipFlag()!=null){
					ps.setInt(12, Integer.parseInt(bulkdetails1.getVipFlag()));
				}
				else
					ps.setNull(12,java.sql.Types.INTEGER);

				if(bulkdetails1.getAccountCategory()!=null){
					ps.setInt(13, Integer.parseInt(bulkdetails1.getAccountCategory()));
				}
				else
					ps.setNull(13,java.sql.Types.INTEGER);


				ps.setString(14, bulkdetails1.getGivenName()+" "+bulkdetails1.getFamilyName());
				ps.setString(15, bulkdetails1.getOrigBillRefNo());
				ps.setString(16, bulkdetails1.getOrigBillRefResets());
				ps.executeQuery();

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			LIUlogger.info("Exception", e);
		} finally {
			try {
				if(con!=null){
					con.close();

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				LIUlogger.info("Exception", e);
			}

		}
		LIUlogger.info(
				" END:: Inserting account profile aps details");

	}


	public String getApsFlag(String accountNumber) {
		LIUlogger.info("START:getApsFlag  ");
		Connection connection = null;
		CallableStatement callableStatement = null;
		String aps = "";
		try {
			if (accountNumber != null) {
				try {
					JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
					connection = jdbcTemplate.getDataSource().getConnection();
				} catch (Exception e) {
					LIUlogger.info("Conection :: ", e);
				}
				String procStr = "{call GET_APS_FLAG(?,?,?)}";
				callableStatement = connection.prepareCall(procStr);
				callableStatement.setString(1, accountNumber);
				callableStatement.registerOutParameter(2, Types.VARCHAR);
				callableStatement.registerOutParameter(3, Types.VARCHAR);
				callableStatement.executeQuery();
				try {
					String response = callableStatement.getString(2);
					if (response != null && !response.isEmpty()) {
						aps = response;
					}
				} catch (Exception e) {
					LIUlogger.info("Exception  response fetched from nds", e);
					return aps;
				}

			}
		} catch (Exception e) {
			LIUlogger.info("Exception", e);
		} finally {

			try {
				callableStatement.close();
				connection.close();
			} catch (Exception e) {
				LIUlogger.info("Exception", e);
			}
		}

		LIUlogger.info("END:getApsFlag aps--  " + aps);
		return aps;
	}

	public String getAccountAps(String recordId) {

		LIUlogger.info("START:getAccountAps recordId--  " + recordId);
		String accountAps = "";
		String accountNum = "";
		String aps = "";
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String sql = "Select ACCT_EXT_ID,APS_FLAG from AIRTL_EPP_VENDOR_FILES_RECORDS where RECORD_ID = '" + recordId
				+ "'";

		try {
			try {
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				connection = jdbcTemplate.getDataSource().getConnection();

			} catch (Exception e) {
				LIUlogger.info("Exception while making connection", e);
			}
			if (connection != null) {
				preparedStatement = connection.prepareStatement(sql);
				rs = preparedStatement.executeQuery();
				LIUlogger.info("resultset-->" + rs);
				if (rs.next()) {
					accountNum = rs.getString(1);

					if ((rs.getString(2) == null || rs.getString(2).isEmpty()) || rs.getString(2).equalsIgnoreCase("ERROR")) {
						aps = "NOTMENTIONED";
					} else {
						aps = rs.getString(2);
					}

					accountAps = accountNum + ":" + aps;

				}
			}

		} catch (Exception e) {
			LIUlogger.info("Exception", e);
		} finally {
			try {
				preparedStatement.close();
				rs.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		LIUlogger.info("END:getAccountAps aps--  " + accountAps);
		return accountAps;
	}
	// ***************** APS team *****************************

	// ***************************************************** APS liu homes  **************************************************************//
	public HashMap<Integer, List<LIURecordDetails>> liuApsRecordSearchFirstPage(int pageNumber,LIURecordDetails liuRecordDetailsObj) throws SQLException 
	{
		// NumberFormat formatter = new DecimalFormat("#0.00");
		ResultSet resultsetdetails = null;
		CallableStatement callableStatement=null;
		HashMap<Integer, List<LIURecordDetails>> liuRecordDetailsMap=new HashMap<Integer, List<LIURecordDetails>>();
		List<LIURecordDetails> liuRecordDetailsListObj = new ArrayList<LIURecordDetails>();
		try {

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();

			LIUlogger.info("Entered liuRecordSearchFirstPage method in LIURecordsDaoIMPL");	

			final String procedureCall = "{call ACE_CAD_LIU_RECORDS_SEARCH_APS(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";

			callableStatement = conn.prepareCall(procedureCall);

			callableStatement.setString(1, liuRecordDetailsObj.getPaymentMode());
			callableStatement.setString(2, liuRecordDetailsObj.getReferenceID());
			callableStatement.setString(3, liuRecordDetailsObj.getRemitterIFSC());
			callableStatement.setString(4, liuRecordDetailsObj.getAccountExtID());	
			//		callableStatement.setString(5, liuRecordDetailsObj.getFileID());
			callableStatement.setString(5, liuRecordDetailsObj.getFileName());
			callableStatement.setString(6, liuRecordDetailsObj.getLiuReason());

			callableStatement.setInt(7, pageNumber);
			callableStatement.setString(8,  liuRecordDetailsObj.getFromDate());
			callableStatement.setString(9, liuRecordDetailsObj.getToDate());
			callableStatement.setString(10,liuRecordDetailsObj.getLiuStatus());
			callableStatement.setString(11, liuRecordDetailsObj.getUserID());


			LIUlogger.info("Liu status liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+liuRecordDetailsObj.getLiuStatus());
			LIUlogger.info("Reference Id is liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getReferenceID());
			LIUlogger.info("Payment Mode is liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getPaymentMode());
			LIUlogger.info("Cheque MICR liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getRemitterIFSC());
			LIUlogger.info("Account Ext Id liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getAccountExtID());
			LIUlogger.info("File Name liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getFileName());
			LIUlogger.info("LIU Reason liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getLiuReason());
			LIUlogger.info("User Id liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getUserID());
			LIUlogger.info("To Date liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getToDate());
			LIUlogger.info("From Date liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getFromDate());

			System.out.println("Liu status liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+liuRecordDetailsObj.getLiuStatus());
			System.out.println("Reference Id is liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getReferenceID());
			System.out.println("Payment Mode is liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getPaymentMode());
			System.out.println("Cheque MICR liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getRemitterIFSC());
			System.out.println("Account Ext Id liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getAccountExtID());
			System.out.println("File Name liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getFileName());
			System.out.println("LIU Reason liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getLiuReason());
			System.out.println("User Id liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getUserID());
			System.out.println("To Date liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getToDate());
			System.out.println("From Date liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+ liuRecordDetailsObj.getFromDate());

			LIUlogger.info("details entered into callable statement of liuRecordSearchFirstPage @IMPL ");

			callableStatement.registerOutParameter(12, Types.INTEGER);
			callableStatement.registerOutParameter(13, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(14,OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(15,OracleTypes.VARCHAR);


			callableStatement.executeUpdate();
			int totalPages=callableStatement.getInt(12);
			String errorMsg=callableStatement.getString(14);

			LIUlogger.info("Error message at liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+errorMsg);
			liuRecordDetailsObj.setErrorMsg(errorMsg);

			resultsetdetails = (ResultSet) callableStatement.getObject(13);

			if (resultsetdetails == null) 
			{
				LIUlogger.info("DB returning NULL values at liuRecordSearchFirstPage method in LIURecordsDaoIMPL");
			}

			else
			{
				while (resultsetdetails.next()) 
				{
					LIURecordDetails liuRecordDetailsObj1 = new LIURecordDetails();

					liuRecordDetailsObj1.setPaymentMode(resultsetdetails.getString("PAYMENT_MODE"));
					liuRecordDetailsObj1.setPaymentAmount(resultsetdetails.getDouble("PAYMENT_AMOUNT"));
					liuRecordDetailsObj1.setChequeDate(resultsetdetails.getDate("CHEQUE_DATE"));/*?????*/
					liuRecordDetailsObj1.setCustBankAccNo(resultsetdetails.getString("CUSTOMER_BANK_ACCOUNT_NO"));
					liuRecordDetailsObj1.setPaymentReceivedDate(resultsetdetails.getString("PAYMENT_RECIEVED_DATE"));/*?????*/
					liuRecordDetailsObj1.setLiuTrackingID(resultsetdetails.getLong("LIU_TRACKING_ID"));
					liuRecordDetailsObj1.setSourceOfRecord(resultsetdetails.getString("SOURCE_OF_RECORD"));
					liuRecordDetailsObj1.setFileID(resultsetdetails.getString("FILE_ID"));
					liuRecordDetailsObj1.setRecordId(resultsetdetails.getLong("RECORD_ID"));					
					liuRecordDetailsObj1.setLiuReason(resultsetdetails.getString("LIU_REASON"));

					if(resultsetdetails.getString("VENDOR_ID")== null)/*?????*/
					{
						liuRecordDetailsObj1.setVendorID("");
					}

					else
					{
						liuRecordDetailsObj1.setVendorID(resultsetdetails.getString("VENDOR_ID"));
					}

					liuRecordDetailsObj1.setUserID(resultsetdetails.getString("USER_ID"));/*is it vendor_userid*/
					liuRecordDetailsObj1.setCircle(resultsetdetails.getString("CIRCLE"));/*circle from where*/
					liuRecordDetailsObj1.setLbxLocationID(resultsetdetails.getString("LBX_LOCATION_ID"));/*?????*/
					liuRecordDetailsObj1.setLbxSourceID(resultsetdetails.getString("LBX_SOURCE_ID"));/*?????*/
					liuRecordDetailsObj1.setSourceRefID(resultsetdetails.getString("SOURCE_REFERENCE_ID"));
					liuRecordDetailsObj1.setChangeWho(resultsetdetails.getString("CHANGE_WHO"));
					liuRecordDetailsObj1.setChangeDate(resultsetdetails.getDate("CHANGE_DATE"));/*modified date*/
					liuRecordDetailsObj1.setInsertDate(resultsetdetails.getDate("INSERT_DATE"));
					liuRecordDetailsObj1.setStatus(resultsetdetails.getInt("STATUS"));/*Status Code*/
					liuRecordDetailsObj1.setReferenceID(resultsetdetails.getString("REF_NUMBER"));					
					liuRecordDetailsObj1.setRemitterIFSC(resultsetdetails.getString("REMITTER_IFSC"));					
					liuRecordDetailsObj1.setAccountExtID(resultsetdetails.getString("ACCT_EXT_ID"));
					liuRecordDetailsObj1.setInvoiceNumber(resultsetdetails.getString("VC_INVOICE_NO"));
					liuRecordDetailsObj1.setB2b_b2c_Segment(resultsetdetails.getString("B2B_B2C_SEGMENT"));
					liuRecordDetailsObj1.setCust_currency(resultsetdetails.getString("FX_CUSTOMER_CURRENCY"));/*???*/
					liuRecordDetailsObj1.setPayment_currency(resultsetdetails.getString("PAYMENT_CURRENCY"));	
					if(liuRecordDetailsObj1.getPaymentMode().equalsIgnoreCase("OTHERS"))
					{
						liuRecordDetailsObj1.setExchange_rate(1);
					}
					else
					{
						liuRecordDetailsObj1.setExchange_rate(resultsetdetails.getDouble("EXCHANGE_RATE"));
					}
					liuRecordDetailsObj1.setFileUploadDate(resultsetdetails.getString("FILE_UPLOAD_DATE"));
					liuRecordDetailsObj1.setPendingSince(resultsetdetails.getInt("PENDING_SINCE"));
					liuRecordDetailsObj1.setDelNumber(resultsetdetails.getString("DEL_NO"));
					liuRecordDetailsObj1.setAccountType(resultsetdetails.getString("ACCOUNT_TYPE"));/*OTHERS?*/
					liuRecordDetailsObj1.setPaymentCode(resultsetdetails.getLong("PAYMENT_CODE"));
					liuRecordDetailsObj1.setActedIn(resultsetdetails.getInt("ACTED_IN"));
					liuRecordDetailsObj1.setEffectivePaymentAmount(resultsetdetails.getDouble("EFFECTIVE_PAYMENT_AMOUNT"));
					liuRecordDetailsObj1.setAmountInINR(resultsetdetails.getDouble("AMOUNT_IN_INR"));
					liuRecordDetailsObj1.setIncomingTransRefNum(resultsetdetails.getString("INCOMING_TRANSACTION_REF_NO"));
					liuRecordDetailsObj1.setRemitterBranch(resultsetdetails.getString("REMITTER_BRANCH"));
					liuRecordDetailsObj1.setReceiverIFSC(resultsetdetails.getString("RECEIVER_IFSC"));
					liuRecordDetailsObj1.setReceivingAcctRbi1(resultsetdetails.getString("RECEIVING_ACC_RBI1"));
					liuRecordDetailsObj1.setRemitterAcctNum(resultsetdetails.getString("REMITTER_AC_NO"));
					liuRecordDetailsObj1.setFileName(resultsetdetails.getString("FILE_NAME"));

					if(resultsetdetails.getString("VENDOR_NAME")== null)
					{
						liuRecordDetailsObj1.setVendorName("");
					}

					else
					{
						liuRecordDetailsObj1.setVendorName(resultsetdetails.getString("VENDOR_NAME"));
					}	
					liuRecordDetailsListObj.add(liuRecordDetailsObj1);
				}
			}

			liuRecordDetailsMap.put(totalPages,liuRecordDetailsListObj);
			LIUlogger.info("Size of liuRecordDetailsMap at liuRecordSearchFirstPage method in LIURecordsDaoIMPL:"+liuRecordDetailsMap);
		} catch (SQLException e) 
		{
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);
			return null;
		}
		catch(Exception e)
		{
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);
			return null;
		}
		finally{
			if(resultsetdetails!=null){
				try {
					resultsetdetails.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);			
				}
			}

			if(callableStatement!=null){
				try {
					callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(conn!=null){
				try {
					conn.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}

			}
		}
		LIUlogger.info("executed liuRecordSearchFirstPage method in LIURecordsDaoIMPL");	
		return liuRecordDetailsMap;

	}

	/********************************************aps liu home changes**************************/
	public List<String> liuApsFilenameList() 
	{

		List<String> liuFilenameList=new ArrayList<String>();
		CallableStatement callableStatement=null;
		ResultSet fileNameResultSet=null;

		try 
		{
			LIUlogger.info("Entered liuFilenameList method in LIURecordsDaoIMPL");	

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();

			final String procedureCall = "{call ACE_CAD_LIU_FILE_NAME_APS(?,?,?)}";

			callableStatement = conn.prepareCall(procedureCall);
			callableStatement.registerOutParameter(1, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(2, OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);

			callableStatement.executeUpdate();

			String errorMsgFilename=callableStatement.getString(3);
			LIUlogger.info("Error message at liuFilenameList method in LIURecordsDaoIMPL:"+errorMsgFilename);

			fileNameResultSet=(ResultSet) callableStatement.getObject(1);

			if (fileNameResultSet == null) 
			{
				LIUlogger.info("DB returning NULL values at liuFilenameList method in LIURecordsDaoIMPL");
			}
			else
			{
				while(fileNameResultSet.next())
				{
					liuFilenameList.add(fileNameResultSet.getString(1));
				}
				LIUlogger.info("Size of liuFilenameList at liuFilenameList method in LIURecordsDaoIMPL:"+liuFilenameList);


			}
		}catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);
			return null;
		}
		finally{
			if(fileNameResultSet!=null){
				try {
					fileNameResultSet.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(callableStatement!=null){
				try {
					callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(conn!=null){
				try {
					conn.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}

			}
		}
		LIUlogger.info("executed liuFilenameList method in LIURecordsDaoIMPL");	


		return liuFilenameList ;
	}


	public List<LIURecordDetails> modifiedApsLIUDetails(List<LIURecordDetails> modifiedAccountsRecords,String userId,String sessionId,String action,int pageNumber) {

		final String procedureCall = "{call APS_LIU_UPDATE_DELETE(?,?,?,?,?,?,?)}";
		CallableStatement callableStatement=null;
		ResultSet modifiedResulSetArray = null;

		List<LIURecordDetails> liuRecordsListUpdated=new ArrayList<LIURecordDetails>();

		try {

			// Get Connection instance from dataSource
			LIUlogger.info("Entered modifiedLIUDetails method in LIURecordsDaoIMPL");	

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			StructDescriptor structDescriptor = StructDescriptor.createDescriptor("LIU_UPDATE_REC_OBJECT", conn);

			STRUCT[] structs = new STRUCT[modifiedAccountsRecords.size()];
			for (int index = 0; index < modifiedAccountsRecords.size(); index++)
			{
				LIURecordDetails modifiedRecordsObj = modifiedAccountsRecords.get(index);
				Object[] params = new Object[8];

				params[0] = modifiedRecordsObj.getAccountExtID();
				LIUlogger.info(" ACCOUNT EXT ID 1:"+modifiedRecordsObj.getAccountExtID());
				params[1] = modifiedRecordsObj.getInvoiceNumber();
				LIUlogger.info("INVOICE NUMBER 2:"+modifiedRecordsObj.getInvoiceNumber());

				params[2] = modifiedRecordsObj.getPaymentMode();
				LIUlogger.info("PAYMENT MODE 3:"+modifiedRecordsObj.getPaymentMode());

				params[3] = modifiedRecordsObj.getLiuReason();		           
				LIUlogger.info("LIU REASON 4:"+modifiedRecordsObj.getLiuReason());

				params[4] = modifiedRecordsObj.getStatus();
				LIUlogger.info("STATUS 5:"+modifiedRecordsObj.getStatus());

				params[5] = modifiedRecordsObj.getFileID();
				LIUlogger.info("FILE ID 6:"+modifiedRecordsObj.getFileID());

				params[6] = modifiedRecordsObj.getRecordId();
				LIUlogger.info("RECORD ID 7:"+modifiedRecordsObj.getRecordId());


				params[7] = userId;
				LIUlogger.info("USER IS 8:"+userId);

				/*params[0] = modifiedRecordsObj.getLiuTrackingID();
		            LIUlogger.info("TRACKING ID 0:"+modifiedRecordsObj.getLiuTrackingID());

	 	            params[1] = modifiedRecordsObj.getRemitterIFSC();
	 	           LIUlogger.info("CHEQUE IFSC 1:"+modifiedRecordsObj.getRemitterIFSC());

	 	            params[2] = modifiedRecordsObj.getAccountExtID();
	 	           LIUlogger.info(" ACCOUNT EXT ID 2:"+modifiedRecordsObj.getAccountExtID());

	 	            params[3] = modifiedRecordsObj.getInvoiceNumber();
	 	           LIUlogger.info("INVOICE NUMBER 3:"+modifiedRecordsObj.getInvoiceNumber());

   	               params[4] = modifiedRecordsObj.getPaymentAmount();
   	               LIUlogger.info("PAYMENT AMOUNT 4:"+modifiedRecordsObj.getPaymentAmount());

   	               params[5] = modifiedRecordsObj.getOldExchangeRate();
	 	           LIUlogger.info("OLD EXCHANGE RATE 5:"+modifiedRecordsObj.getOldExchangeRate());

	 	            params[6] = modifiedRecordsObj.getPayment_currency();
	 	           LIUlogger.info("PAYMENT CURRENCY 6:"+modifiedRecordsObj.getPayment_currency());

	 	            params[7] = modifiedRecordsObj.getExchange_rate();
	 	           LIUlogger.info("EXCHANGE RATE 7:"+modifiedRecordsObj.getExchange_rate());

		            if(modifiedRecordsObj.getPaymentMode()== null)
		            {
		            	params[8]="";
		 	 	           LIUlogger.info("PAYMENT MODE 8: payment mode is set to null");
		            }
		            else
		            {
	       	            params[8] = modifiedRecordsObj.getPaymentMode();
	 	 	           LIUlogger.info("PAYMENT MODE 8:"+modifiedRecordsObj.getPaymentMode());


		            }
	 	            params[9] = modifiedRecordsObj.getCustomerName();
	 	           LIUlogger.info("CUSTOMER NAME 9:"+modifiedRecordsObj.getCustomerName());

	 	            params[10] = modifiedRecordsObj.getOrderNumber();
	 	           LIUlogger.info("ORDER NUMBER 10:"+modifiedRecordsObj.getOrderNumber());

		            if(modifiedRecordsObj.getLiuReason()==null)
		            {
		            	   params[11] ="";
		 	 	           LIUlogger.info("LIU REASON 11: LIU REASON IS SET TO NULL");
		            }
		            else
		            {
		      	            params[11] = modifiedRecordsObj.getLiuReason();		           
				            LIUlogger.info("LIU REASON 11:"+modifiedRecordsObj.getLiuReason());

		            }

	 	            params[12] = modifiedRecordsObj.getStatus();
	 	           LIUlogger.info("STATUS 12:"+modifiedRecordsObj.getStatus());


		            if(modifiedRecordsObj.getAccountType()==null)
		            {
		            	   params[13] ="";
				            LIUlogger.info("ACCOUNT TYPE 13: ACCOUNT TYPE IS SET TO NULL");
		            }
		            else
		            {
		      	            params[13] = modifiedRecordsObj.getAccountType();
				            LIUlogger.info("ACCOUNT TYPE 13:"+modifiedRecordsObj.getAccountType());
		            }

	 	            params[14] = modifiedRecordsObj.getLob();  
	 	           LIUlogger.info("LOB 14:"+modifiedRecordsObj.getLob());

	 	            params[15] = modifiedRecordsObj.getFxLegalEntity();  
	 	           LIUlogger.info("LEGAL ENTITY 15:"+modifiedRecordsObj.getFxLegalEntity());

	 	            params[16] = modifiedRecordsObj.getFxValueType();
	 	           LIUlogger.info("FX VALUE TYPE 16:"+modifiedRecordsObj.getFxValueType());

	 	            params[17] = modifiedRecordsObj.getFxVIPFlag();
	 	           LIUlogger.info("FX VIP FLAG 17:"+modifiedRecordsObj.getFxVIPFlag());

	 	            params[18] = modifiedRecordsObj.getFxCustomerType();
	 	           LIUlogger.info("FX CUSTOMER TYPE 18:"+modifiedRecordsObj.getFxCustomerType());

	 	            params[19] = modifiedRecordsObj.getFxCustomerClass();
	 	           LIUlogger.info("CUSTOMER CLASS 19:"+modifiedRecordsObj.getFxCustomerClass());

		            if(modifiedRecordsObj.getB2b_b2c_Segment()==null)
		            {
		            	  params[20] ="";
		            	  LIUlogger.info("B2B B2C 20: B2B B2C IS SET TO NULL 20:");

		            } 
		            else
		            {
		      	          params[20] = modifiedRecordsObj.getB2b_b2c_Segment();
		      	        LIUlogger.info("B2B B2C 20:"+modifiedRecordsObj.getB2b_b2c_Segment());
		            }


	 	            params[21] = modifiedRecordsObj.getPaymentCode();
	 	           LIUlogger.info("PAYMENT CODE 21:"+modifiedRecordsObj.getPaymentCode());

	 	          if(modifiedRecordsObj.getPaymentCode()==0)
		            {
		            	params[21]=0;
	            		LIUlogger.info("PAYMENT CODE 21 : is set to null");

		            }
		            	else
		            	{ 
		            		params[21] =modifiedRecordsObj.getPaymentCode();
		            		LIUlogger.info("PAYMENT CODE 21:"+modifiedRecordsObj.getPaymentCode());
		            	} 


		            if(modifiedRecordsObj.getCust_currency()==null)
		            { 
		            	params[22] ="";
		            	LIUlogger.info(" CUST CURRENCY 22:is set to null");

		            }
		            else
		            {
		            	params[22] = modifiedRecordsObj.getCust_currency();
		            	LIUlogger.info("CUST CURRENCY 22:"+modifiedRecordsObj.getCust_currency());

		            }

	 	            params[23] = modifiedRecordsObj.getValidInvoice();
	 	           LIUlogger.info("VALID INVOICE 23:"+modifiedRecordsObj.getValidInvoice());

		            params[24] = modifiedRecordsObj.getFileID();
		            LIUlogger.info("FILE ID 24:"+modifiedRecordsObj.getFileID());

		            params[25] = modifiedRecordsObj.getRecordId();
		            LIUlogger.info("RECORD ID 25:"+modifiedRecordsObj.getRecordId());

		            params[26] = modifiedRecordsObj.getReferenceID();
		            LIUlogger.info("REFERENCE ID 26:"+modifiedRecordsObj.getReferenceID());

		            params[27] = modifiedRecordsObj.getCustBankAccNo();
		            LIUlogger.info("CUSTOMER BANK ACCOUNT NUMBER 27:"+modifiedRecordsObj.getCustBankAccNo());

		            params[28] = modifiedRecordsObj.getRemarks();
		            LIUlogger.info("REMARKS 28:"+modifiedRecordsObj.getRemarks());

		            params[29] = modifiedRecordsObj.getOrigBillRefResets();
		            LIUlogger.info("OrigBillRefResets 29:"+modifiedRecordsObj.getOrigBillRefResets());

		            params[30] = modifiedRecordsObj.getMarketCode();
		            LIUlogger.info("Market Code 30:"+modifiedRecordsObj.getMarketCode());

		            params[31] = modifiedRecordsObj.getFxInternalAcctNum();
		            LIUlogger.info("Fx Internal Acct Num 31:"+modifiedRecordsObj.getFxInternalAcctNum());

		            params[32] = modifiedRecordsObj.getCompanyName();
		            LIUlogger.info("Company Name 32:"+modifiedRecordsObj.getCompanyName());

		            params[33] =modifiedRecordsObj.getPaymentCode();
		            LIUlogger.info("Payment Code 33:"+modifiedRecordsObj.getPaymentCode());

		            params[34] = modifiedRecordsObj.getAmountInINR();
		            LIUlogger.info("Amount iN INR 34:"+modifiedRecordsObj.getAmountInINR());

		            params[35] = modifiedRecordsObj.getIncomingTransRefNum();
		            LIUlogger.info(" IncomingTransRefNum 35:"+modifiedRecordsObj.getIncomingTransRefNum());

		            params[36] = modifiedRecordsObj.getRemitterBranch();
		            LIUlogger.info("RemitterBranch 36:"+modifiedRecordsObj.getRemitterBranch());

		            params[37] = modifiedRecordsObj.getReceiverIFSC();
		            LIUlogger.info("ReceiverIFSC 37:"+modifiedRecordsObj.getReceiverIFSC());

		            params[38] = modifiedRecordsObj.getRemitterAcctNum();
		            LIUlogger.info("RemitterAcctNum 38:"+modifiedRecordsObj.getRemitterAcctNum());

		         // Added By APS TEAM 
				    params[39] = modifiedRecordsObj.getApsFlag();
				 */

				LIUlogger.info("Input values to Proc:");
				for(int i=0;i<params.length;i++)
				{

					LIUlogger.info(i+":"+params[i]+" ,");
				}

				STRUCT struct = new STRUCT(structDescriptor, conn, params);

				structs[index] = struct;
			}
			LIUlogger.info("Length of struct at modifiedLIUDetails method in LIURecordsDaoIMPL"+structs.length);

			ArrayDescriptor desc = ArrayDescriptor.createDescriptor("LIU_UPDATE_REC_TYPE",conn);

			ARRAY oracleArray = new ARRAY(desc, conn, structs);


			callableStatement = conn.prepareCall(procedureCall);

			callableStatement.setString(1,action);
			callableStatement.setString(2,userId);
			callableStatement.setString(3,sessionId);	
			callableStatement.setArray(4, oracleArray);
			// callableStatement.setString(5, apsFlag);

			callableStatement.registerOutParameter(5, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(6, Types.VARCHAR);
			callableStatement.registerOutParameter(7, Types.VARCHAR);

			callableStatement.executeUpdate(); 


			String errorMsg=callableStatement.getString(6);
			String errorCode=callableStatement.getString(7);

			LIUlogger.info("Error message at modifiedLIUDetails method in LIURecordsDaoIMPL:"+errorMsg );
			LIUlogger.info("Error code at modifiedLIUDetails method in LIURecordsDaoIMPL:"+errorCode );

			LIUlogger.info("Session ID at modifiedLIUDetails method in LIURecordsDaoIMPL:"+sessionId);

			modifiedResulSetArray=(ResultSet) callableStatement.getObject(5);

			if (modifiedResulSetArray == null) 
			{
				LIUlogger.info("DB returning NULL values at modifiedLIUDetails method in LIURecordsDaoIMPL");
			}

			else
			{

				while (modifiedResulSetArray.next())
				{
					LIURecordDetails modifiedLIUDetailsObj = new LIURecordDetails();

					modifiedLIUDetailsObj.setErrorMsg(errorMsg);
					/*modifiedLIUDetailsObj.setLiuTrackingID(modifiedResulSetArray.getInt("LIU_TRACKING_ID"));*/
					modifiedLIUDetailsObj.setPaymentMode(modifiedResulSetArray.getString("PAYMENT_MODE"));
					/* modifiedLIUDetailsObj.setRemitterIFSC(modifiedResulSetArray.getString("REMITTER_IFSC"));*/

					if ( (modifiedResulSetArray.getString("ACCT_EXT_ID")==null && modifiedLIUDetailsObj.getPaymentMode().equalsIgnoreCase("NEFT") ))
					{
						modifiedLIUDetailsObj.setAccountExtID("-");
					}
					else if(modifiedResulSetArray.getString("ACCT_EXT_ID")==null)
						modifiedLIUDetailsObj.setAccountExtID("-");
					else
						modifiedLIUDetailsObj.setAccountExtID(modifiedResulSetArray.getString("ACCT_EXT_ID"));

					if( (modifiedResulSetArray.getString("DERIVED_SEGMENT_B2B_B2C")==null && modifiedLIUDetailsObj.getPaymentMode().equalsIgnoreCase("NEFT") ))
					{
						modifiedLIUDetailsObj.setB2b_b2c_Segment("-");
					}
					else if(modifiedResulSetArray.getString("DERIVED_SEGMENT_B2B_B2C")==null)
						modifiedLIUDetailsObj.setB2b_b2c_Segment("-");
					else
						modifiedLIUDetailsObj.setB2b_b2c_Segment(modifiedResulSetArray.getString("DERIVED_SEGMENT_B2B_B2C"));


					if( (modifiedResulSetArray.getString("INVOICE_NO")==null && modifiedLIUDetailsObj.getPaymentMode().equalsIgnoreCase("NEFT") ))
					{
						modifiedLIUDetailsObj.setInvoiceNumber("-");
					}
					else if(modifiedResulSetArray.getString("INVOICE_NO")==null)
						modifiedLIUDetailsObj.setInvoiceNumber("-");
					else
						modifiedLIUDetailsObj.setInvoiceNumber(modifiedResulSetArray.getString("INVOICE_NO"));


					if(modifiedLIUDetailsObj.getPaymentMode().equalsIgnoreCase("OTHERS") && modifiedResulSetArray.getString("DISPLAY")==null)
					{
						modifiedLIUDetailsObj.setPayment_currency("-");
					}
					else
					{
						modifiedLIUDetailsObj.setPayment_currency(modifiedResulSetArray.getString("DISPLAY"));
					}
					modifiedLIUDetailsObj.setExchange_rate(modifiedResulSetArray.getDouble("EXCHANGE_RATE"));
					modifiedLIUDetailsObj.setLiuReason(modifiedResulSetArray.getString("LIU_REASON"));

					/*if(action.equalsIgnoreCase("UPDATE")){
					   modifiedLIUDetailsObj.setRemarks("LIU CLEARED");
					   }
					   else{*/

					/* }*/
					modifiedLIUDetailsObj.setReferenceID(modifiedResulSetArray.getString("REF_NUMBER"));
					modifiedLIUDetailsObj.setRemarks(modifiedResulSetArray.getString("REMARKS"));
					modifiedLIUDetailsObj.setPaymentAmount(modifiedResulSetArray.getDouble("PAYMENT_AMOUNT"));
					modifiedLIUDetailsObj.setEffectivePaymentAmount(modifiedResulSetArray.getFloat("EFFECTIVE_PAYMENT_AMOUNT"));
					modifiedLIUDetailsObj.setFileID(modifiedResulSetArray.getString("FILE_ID"));
					modifiedLIUDetailsObj.setRecordId(modifiedResulSetArray.getLong("RECORD_ID"));
					modifiedLIUDetailsObj.setCustBankAccNo(modifiedResulSetArray.getString("CUSTOMER_BANK_ACCOUNT_NO"));

					modifiedLIUDetailsObj.setErrorMsg(errorMsg);
					modifiedLIUDetailsObj.setErrorCode(errorCode);

					liuRecordsListUpdated.add(modifiedLIUDetailsObj);

				}

			}
			LIUlogger.info("Size of liuRecordsListUpdated at modifiedLIUDetails method in LIURecordsDaoIMPL:"+liuRecordsListUpdated);


		} catch (SQLException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);
			return null;
		}
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);
			return null;
		}finally {

			if(modifiedResulSetArray!=null){
				try {
					modifiedResulSetArray.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(callableStatement!=null){
				try {
					callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(conn!=null){
				try {
					conn.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}

			}
		}
		LIUlogger.info("executed modifiedLIUDetails method in LIURecordsDaoIMPL");	

		return liuRecordsListUpdated;

	}



	public LIURecordDetails modifiedApsLIURecords(List<LIURecordDetails> modifiedAccountsRecords,String userId,String liuFlag) {

		final String procedureCall = "{call LIU_DETAILS_APS(?,?,?,?)}";
		CallableStatement callableStatement=null;
		ResultSet modifiedResulSetArray = null;
		LIURecordDetails modifiedLIUDetailsObj =null;

		List<LIURecordDetails> liuRecordsListUpdated=new ArrayList<LIURecordDetails>();

		try {

			// Get Connection instance from dataSource
			LIUlogger.info("Entered modifiedLIUDetails method in LIURecordsDaoIMPL");	

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			StructDescriptor structDescriptor = StructDescriptor.createDescriptor("LIU_CLEARING_OBJ", conn);

			STRUCT[] structs = new STRUCT[modifiedAccountsRecords.size()];
			for (int index = 0; index < modifiedAccountsRecords.size(); index++)
			{
				LIURecordDetails modifiedRecordsObj = modifiedAccountsRecords.get(index);
				Object[] params = new Object[20];


				params[0] = modifiedRecordsObj.getFileID();
				LIUlogger.info("FILE ID (1):"+modifiedRecordsObj.getFileID());
				params[1] = modifiedRecordsObj.getRecordId();
				LIUlogger.info("RECORD ID (2):"+modifiedRecordsObj.getRecordId());
				params[2] = modifiedRecordsObj.getPaymentMode();
				LIUlogger.info("PAYMENT MODE (3):"+modifiedRecordsObj.getPaymentMode());
				params[3] = modifiedRecordsObj.getAccountExtID();
				LIUlogger.info(" ACCOUNT EXT ID (4):"+modifiedRecordsObj.getAccountExtID());

				if(modifiedRecordsObj.getParentAcctNo()==null){
					params[4]=null; 
				}
				else{
					params[4] =modifiedRecordsObj.getParentAcctNo();//parent account no
				}
				LIUlogger.info("Parent account no is:"+modifiedRecordsObj.getParentAcctNo());

				if(modifiedRecordsObj.getB2b_b2c_Segment()==null)
				{
					params[5] ="";
					LIUlogger.info("B2B B2C 20: B2B B2C IS SET TO NULL 20:");

				} 
				else
				{
					params[5] = modifiedRecordsObj.getB2b_b2c_Segment();
					LIUlogger.info("B2B B2C :"+modifiedRecordsObj.getB2b_b2c_Segment());
				}

				params[6] = modifiedRecordsObj.getApsFlag();
				LIUlogger.info("aps flag is"+modifiedRecordsObj.getApsFlag());
				params[7] = modifiedRecordsObj.getLob();  
				LIUlogger.info("LOB :"+modifiedRecordsObj.getLob());

				if(modifiedRecordsObj.getFxLegalEntity()==null){
					params[8]=0;
				}
				else{
					params[8] = Integer.parseInt(modifiedRecordsObj.getFxLegalEntity()); 
				}
				LIUlogger.info("LEGAL ENTITY 15:"+modifiedRecordsObj.getFxLegalEntity());

				if(modifiedRecordsObj.getDelNumber()==null){
					params[9] = "null";
				}

				else{
					params[9]=modifiedRecordsObj.getDelNumber();
				}

				params[10]=modifiedRecordsObj.getInvoiceNumber();
				LIUlogger.info("INVOICE NUMBER 	:"+modifiedRecordsObj.getInvoiceNumber());

				/* if(modifiedRecordsObj.getFxCustomerType()==null){

 	        	  params[11] = 0;

 	           }
 	           else{*/

				//     params[11] = Integer.parseInt(modifiedRecordsObj.getFxCustomerType());
				params[11] = 1;

				LIUlogger.info("FX CUSTOMER TYPE :"+modifiedRecordsObj.getFxCustomerType());
				//}



				params[12] = 0;
				LIUlogger.info("CUSTOMER CLASS :"+modifiedRecordsObj.getFxCustomerClass());


				/* else{
 	            params[12] = Integer.parseInt(modifiedRecordsObj.getFxCustomerClass());
 	           LIUlogger.info("CUSTOMER CLASS :"+modifiedRecordsObj.getFxCustomerClass());
 	          }*/
				/*   if(modifiedRecordsObj.getFxVIPFlag()==null){*/

				params[13] = 0;
				LIUlogger.info("FX VIP FLAG 17:"+modifiedRecordsObj.getFxVIPFlag()); 
				/*   }
 	         else{
 	          params[13] = Integer.parseInt(modifiedRecordsObj.getFxVIPFlag());
 	           LIUlogger.info("FX VIP FLAG 17:"+modifiedRecordsObj.getFxVIPFlag());
 	         }*/
				params[14]=0; //account category

				params[15] = modifiedRecordsObj.getOrigBillRefResets();
				LIUlogger.info("OrigBillRefResets :"+modifiedRecordsObj.getOrigBillRefResets());

				params[16]=liuFlag;

				params[17]=userId;


				params[18]= modifiedRecordsObj.getRemarks();


				String anchorId=modifiedRecordsObj.getAnchorId();

				if(anchorId==null||anchorId.equalsIgnoreCase(""))
				{
					anchorId="NA";
					params[19]=anchorId;
				}
				else{
					params[19]= modifiedRecordsObj.getAnchorId();
				}
				LIUlogger.info("Remarks :"+modifiedRecordsObj.getRemarks());
				LIUlogger.info("user updating value"+userId);

				LIUlogger.info("Input values to Proc:");
				for(int i=0;i<params.length;i++)
				{

					LIUlogger.info(i+":"+params[i]+" ,");
				}

				STRUCT struct = new STRUCT(structDescriptor, conn, params);

				structs[index] = struct;
			}
			LIUlogger.info("Length of struct at modifiedLIUDetails method in LIURecordsDaoIMPL"+structs.length);

			ArrayDescriptor desc = ArrayDescriptor.createDescriptor("LIU_TAB_TYPE",conn);

			ARRAY oracleArray = new ARRAY(desc, conn, structs);


			callableStatement = conn.prepareCall(procedureCall);

			callableStatement.setArray(1, oracleArray);
			callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.registerOutParameter(4, Types.VARCHAR);

			callableStatement.executeUpdate(); 
			conn.commit();

			String errorMsg=callableStatement.getString(3);
			String errorCode=callableStatement.getString(4);

			LIUlogger.info("Error message at modifiedLIUDetails method in LIURecordsDaoIMPL:"+errorMsg );
			LIUlogger.info("Error code at modifiedLIUDetails method in LIURecordsDaoIMPL:"+errorCode );

			//   LIUlogger.info("Session ID at modifiedLIUDetails method in LIURecordsDaoIMPL:"+sessionId);

			modifiedResulSetArray=(ResultSet) callableStatement.getObject(2);

			if (modifiedResulSetArray == null) 
			{
				LIUlogger.info("DB returning NULL values at modifiedLIUDetails method in LIURecordsDaoIMPL");
			}

			else
			{
				LIUlogger.info("modifiedResulSetArray.getFetchSize()--->>"+modifiedResulSetArray.getFetchSize());
				while (modifiedResulSetArray.next())
				{
					modifiedLIUDetailsObj = new LIURecordDetails();

					modifiedLIUDetailsObj.setErrorMsg(errorMsg);
					/*modifiedLIUDetailsObj.setLiuTrackingID(modifiedResulSetArray.getInt("LIU_TRACKING_ID"));*/
					modifiedLIUDetailsObj.setPaymentMode(modifiedResulSetArray.getString("PAYMENT_MODE"));

					LIUlogger.info("modifiedLIUDetailsObj.setPaymentMode"+modifiedResulSetArray.getString("PAYMENT_MODE"));
					/* modifiedLIUDetailsObj.setRemitterIFSC(modifiedResulSetArray.getString("REMITTER_IFSC"));*/

					if ( (modifiedResulSetArray.getString("ACCT_EXT_ID")==null && modifiedLIUDetailsObj.getPaymentMode().equalsIgnoreCase("NEFT") ))
					{
						modifiedLIUDetailsObj.setAccountExtID("-");
					}
					else if(modifiedResulSetArray.getString("ACCT_EXT_ID")==null)
						modifiedLIUDetailsObj.setAccountExtID("-");
					else
						modifiedLIUDetailsObj.setAccountExtID(modifiedResulSetArray.getString("ACCT_EXT_ID"));

					LIUlogger.info("Account External id is:"+modifiedResulSetArray.getString("ACCT_EXT_ID"));

					if( (modifiedResulSetArray.getString("DERIVED_SEGMENT_B2B_B2C")==null && modifiedLIUDetailsObj.getPaymentMode().equalsIgnoreCase("NEFT") ))
					{
						modifiedLIUDetailsObj.setB2b_b2c_Segment("-");
					}
					else if(modifiedResulSetArray.getString("DERIVED_SEGMENT_B2B_B2C")==null)
						modifiedLIUDetailsObj.setB2b_b2c_Segment("-");
					else
						modifiedLIUDetailsObj.setB2b_b2c_Segment(modifiedResulSetArray.getString("DERIVED_SEGMENT_B2B_B2C"));
					LIUlogger.info("derived segment is:"+modifiedResulSetArray.getString("DERIVED_SEGMENT_B2B_B2C"));


					if( (modifiedResulSetArray.getString("INVOICE_NO")==null && modifiedLIUDetailsObj.getPaymentMode().equalsIgnoreCase("NEFT") ))
					{
						modifiedLIUDetailsObj.setInvoiceNumber("-");
					}
					else if(modifiedResulSetArray.getString("INVOICE_NO")==null)
						modifiedLIUDetailsObj.setInvoiceNumber("-");
					else
						modifiedLIUDetailsObj.setInvoiceNumber(modifiedResulSetArray.getString("INVOICE_NO"));

					LIUlogger.info("invoice no is"+modifiedResulSetArray.getString("INVOICE_NO"));
					if(modifiedLIUDetailsObj.getPaymentMode().equalsIgnoreCase("OTHERS") && modifiedResulSetArray.getString("DISPLAY")==null)
					{
						modifiedLIUDetailsObj.setPayment_currency("-");
					}
					else
					{
						modifiedLIUDetailsObj.setPayment_currency(modifiedResulSetArray.getString("DISPLAY"));
					}

					LIUlogger.info("payment currency is:"+modifiedResulSetArray.getString("DISPLAY"));
					modifiedLIUDetailsObj.setExchange_rate(modifiedResulSetArray.getDouble("EXCHANGE_RATE"));

					LIUlogger.info("exchange rate is"+modifiedResulSetArray.getDouble("EXCHANGE_RATE"));
					modifiedLIUDetailsObj.setLiuReason(modifiedResulSetArray.getString("LIU_REASON"));


					modifiedLIUDetailsObj.setRemarks(modifiedResulSetArray.getString("REMARKS"));//?

					modifiedLIUDetailsObj.setReferenceID(modifiedResulSetArray.getString("REF_NUMBER"));
					LIUlogger.info("reference number is:"+modifiedResulSetArray.getString("REF_NUMBER"));
					//  modifiedLIUDetailsObj.setRemarks(modifiedResulSetArray.getString("REMARKS"));
					modifiedLIUDetailsObj.setPaymentAmount(modifiedResulSetArray.getDouble("PAYMENT_AMOUNT"));
					modifiedLIUDetailsObj.setEffectivePaymentAmount(modifiedResulSetArray.getFloat("EFFECTIVE_PAYMENT_AMOUNT"));
					modifiedLIUDetailsObj.setFileID(modifiedResulSetArray.getString("FILE_ID"));
					modifiedLIUDetailsObj.setRecordId(modifiedResulSetArray.getLong("RECORD_ID"));
					modifiedLIUDetailsObj.setCustBankAccNo(modifiedResulSetArray.getString("CUSTOMER_BANK_ACCOUNT_NO"));
					modifiedLIUDetailsObj.setModifiedDelNo(modifiedResulSetArray.getString("DEL_NO"));
					// modifiedLIUDetailsObj.setAnchorId(modifiedResulSetArray.getInt("ANCHOR_ID"));
					System.out.println("Del no modified-------->>>>>>>>>>>"+modifiedLIUDetailsObj.getModifiedDelNo());

					// System.out.println("anchor id -------->>>>>>>>>>>"+modifiedLIUDetailsObj.getAnchorId());
					modifiedLIUDetailsObj.setErrorMsg(errorMsg);
					modifiedLIUDetailsObj.setErrorCode(errorCode);

					//liuRecordsListUpdated.add(modifiedLIUDetailsObj);

				}

			}
			LIUlogger.info("Size of liuRecordsListUpdated at modifiedLIUDetails method in LIURecordsDaoIMPL:"+liuRecordsListUpdated);


		} catch (SQLException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);
			return null;
		}
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);
			return null;
		}finally {

			if(modifiedResulSetArray!=null){
				try {
					modifiedResulSetArray.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(callableStatement!=null){
				try {
					callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(conn!=null){
				try {
					conn.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}

			}
		}
		LIUlogger.info("executed modifiedLIUDetails method in LIURecordsDaoIMPL");	

		return modifiedLIUDetailsObj;

	}




	public LIURecordDetails downloadedFileAps(LIURecordDetails liuDownloadObj,/*String downloadedFilesPath,*/String extension,String pageNumber) throws SQLException
	{

		ResultSet resultsetdetails = null;
		CallableStatement callableStatement=null;

		int i=1;

		try {

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();

			LIUlogger.info("Entered downloadedFile method in LIURecordsDaoIMPL");	

			final String procedureCall = "{call ACE_CAD_LIU_RECORDS_SEARCH_APS(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";

			callableStatement = conn.prepareCall(procedureCall);

			callableStatement.setString(1, liuDownloadObj.getPaymentMode());
			callableStatement.setString(2, liuDownloadObj.getReferenceID());
			callableStatement.setString(3, liuDownloadObj.getRemitterIFSC());
			callableStatement.setString(4, liuDownloadObj.getAccountExtID());	
			//		callableStatement.setString(5, liuDownloadObj.getFileID());
			callableStatement.setString(5, liuDownloadObj.getFileName());
			callableStatement.setString(6, liuDownloadObj.getLiuReason());
			callableStatement.setString(7, pageNumber);
			callableStatement.setString(8, liuDownloadObj.getFromDate());
			callableStatement.setString(9, liuDownloadObj.getToDate());
			callableStatement.setString(10,liuDownloadObj.getLiuStatus());
			callableStatement.setString(11, liuDownloadObj.getUserID());



			LIUlogger.info("FILE ID at downloadedFile method in LIURecordsDaoIMPL :"+liuDownloadObj.getFileName());
			LIUlogger.info("LIU STATUS at downloadedFile method in LIURecordsDaoIMPL:"+ liuDownloadObj.getLiuStatus());
			LIUlogger.info("Reference Id at downloadedFile method in LIURecordsDaoIMPL:"+ liuDownloadObj.getReferenceID());
			LIUlogger.info("Payment Mode at downloadedFile method in LIURecordsDaoIMPL:"+ liuDownloadObj.getPaymentMode());
			LIUlogger.info("Cheque MICR at downloadedFile method in LIURecordsDaoIMPL:"+ liuDownloadObj.getRemitterIFSC());

			LIUlogger.info("details entered into callable statement of downloadedFile @IMPL ");

			callableStatement.registerOutParameter(12, Types.INTEGER);
			callableStatement.registerOutParameter(13, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(14,OracleTypes.VARCHAR);
			callableStatement.registerOutParameter(15,OracleTypes.VARCHAR);


			callableStatement.executeUpdate();
			int totalPages=callableStatement.getInt(12);
			String errorMsg=callableStatement.getString(14);

			LIUlogger.info("Error message at downloadedFile method in LIURecordsDaoIMPL:"+errorMsg);
			LIUlogger.info("Total No.Of Pages  at downloadedFile method in LIURecordsDaoIMPL:"+totalPages);
			liuDownloadObj.setErrorMsg(errorMsg);

			resultsetdetails = (ResultSet) callableStatement.getObject(13);

			if (resultsetdetails == null) 
			{
				LIUlogger.info("DB returning NULL values at downloadedFile method in LIURecordsDaoIMPL");
			}

			FileOutputStream downloadFile = null;

			try 
			{
				downloadFile = new FileOutputStream(new File("APS_"+liuDownloadObj.getLiuStatus()+"_"+getDateTime()+"."+extension));

				LIUlogger.info("PAYMENT MODE:"+liuDownloadObj.getPaymentMode());
				LIUlogger.info("FILE NAME:"+liuDownloadObj.getFileName());
				LIUlogger.info("LIU STATUS:"+liuDownloadObj.getLiuStatus());


				XSSFWorkbook workbook = new XSSFWorkbook();
				XSSFSheet worksheet = workbook.createSheet("LIU REPORTS");
				XSSFRow row=null;
				row = worksheet.createRow(0);
				//		HSSFCellStyle cellStyle = workbook.createCellStyle();

				XSSFCellStyle my_style = workbook.createCellStyle();
				XSSFFont my_font=workbook.createFont();
				my_font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				my_style.setFont(my_font);

				XSSFCellStyle rightAligned = workbook.createCellStyle();
				rightAligned.setAlignment(XSSFCellStyle.ALIGN_RIGHT);



				Cell cellA1 = row.createCell((short) 0);
				cellA1.setCellValue("PAYMENT MODE");
				cellA1.setCellStyle(my_style);

				Cell cellB1 = row.createCell((short) 1);
				cellB1.setCellValue("REFERENCE ID/CHEQUE/UTR");
				cellB1.setCellStyle(my_style);

				Cell cellC1 = row.createCell((short) 2);
				cellC1.setCellValue("ACCOUNT EXTERNAL ID");
				//cellStyle = workbook.createCellStyle();
				cellC1.setCellStyle(my_style);


				Cell cellD1 = row.createCell((short) 3);
				cellD1.setCellValue("DEL NUMBER");
				cellD1.setCellStyle(my_style);

				Cell cellE1 = row.createCell((short) 4);
				cellE1.setCellValue("INVOICE NUMBER");
				cellE1.setCellStyle(my_style);

				Cell cellF1 = row.createCell((short) 5);
				cellF1.setCellValue("PAYMENT AMOUNT");
				cellF1.setCellStyle(my_style);

				Cell cellG1 = row.createCell((short) 6);
				cellG1.setCellValue("PAYMENT CURRENCY");
				cellG1.setCellStyle(my_style);

				Cell cellH1 = row.createCell((short) 7);
				cellH1.setCellValue("EXCHANGE RATE");
				cellH1.setCellStyle(my_style);

				Cell cellI1 = row.createCell((short) 8);
				cellI1.setCellValue("EFFECTIVE PAYMENT AMOUNT");
				cellI1.setCellStyle(my_style);

				Cell cellJ1 = row.createCell((short) 9);
				cellJ1.setCellValue("REMITTER IFSC");
				cellJ1.setCellStyle(my_style);

				Cell cellK1 = row.createCell((short) 10);
				cellK1.setCellValue("CUSTOMER BANK ACCOUNT NO.");
				cellK1.setCellStyle(my_style);

				Cell cellL1 = row.createCell((short) 11);
				cellL1.setCellValue("LIU REASON");
				cellL1.setCellStyle(my_style);

				Cell cellM1 = row.createCell((short) 12);
				cellM1.setCellValue("FILE ID");
				cellM1.setCellStyle(my_style);

				Cell cellN1 = row.createCell((short) 13);
				cellN1.setCellValue("FILE NAME");
				cellN1.setCellStyle(my_style);

				Cell cellO1 = row.createCell((short) 14);	           
				cellO1.setCellValue("VENDOR ID");
				cellO1.setCellStyle(my_style);

				Cell cellP1 = row.createCell((short) 15);	           
				cellP1.setCellValue("VENDOR NAME");
				cellP1.setCellStyle(my_style);

				Cell cellQ1 = row.createCell((short) 16);
				cellQ1.setCellValue("USER OLM-ID");
				cellQ1.setCellStyle(my_style);

				Cell cellR1 = row.createCell((short) 17);
				cellR1.setCellValue("UPLOADED DATE");
				cellR1.setCellStyle(my_style);

				if(liuDownloadObj.getLiuStatus().equalsIgnoreCase("LIU PENDING"))
				{
					Cell cellS1 = row.createCell((short) 18);
					cellS1.setCellValue("PENDING SINCE");
					cellS1.setCellStyle(my_style);

				}
				else
				{
					Cell cellS1 = row.createCell((short) 18);
					cellS1.setCellValue("ACTED IN (DAYS)");
					cellS1.setCellStyle(my_style);

				}


				//cellStyle = workbook.createCellStyle();




				if(resultsetdetails!=null){
					while (resultsetdetails.next()) {


						LIURecordDetails liuRecordDownloadObj=new LIURecordDetails();

						if(resultsetdetails.getString("PAYMENT_MODE").equalsIgnoreCase("OTHERS"))
						{
							liuRecordDownloadObj.setPaymentMode("MISCELLANEOUS");
						}
						else
						{
							liuRecordDownloadObj.setPaymentMode(resultsetdetails.getString("PAYMENT_MODE"));
						}
						liuRecordDownloadObj.setPaymentAmount(resultsetdetails.getDouble("PAYMENT_AMOUNT"));
						liuRecordDownloadObj.setFileID(resultsetdetails.getString("FILE_ID"));
						liuRecordDownloadObj.setLiuReason(resultsetdetails.getString("LIU_REASON"));
						liuRecordDownloadObj.setVendorID(resultsetdetails.getString("VENDOR_ID"));
						liuRecordDownloadObj.setUserID(resultsetdetails.getString("USER_ID"));
						liuRecordDownloadObj.setCircle(resultsetdetails.getString("CIRCLE"));
						liuRecordDownloadObj.setReferenceID(resultsetdetails.getString("REF_NUMBER"));
						liuRecordDownloadObj.setRemitterIFSC(resultsetdetails.getString("REMITTER_IFSC"));					
						liuRecordDownloadObj.setAccountExtID(resultsetdetails.getString("ACCT_EXT_ID"));
						liuRecordDownloadObj.setInvoiceNumber(resultsetdetails.getString("VC_INVOICE_NO"));
						liuRecordDownloadObj.setB2b_b2c_Segment(resultsetdetails.getString("B2B_B2C_SEGMENT"));
						liuRecordDownloadObj.setCust_currency(resultsetdetails.getString("FX_CUSTOMER_CURRENCY"));
						liuRecordDownloadObj.setPayment_currency("INR");
						liuRecordDownloadObj.setExchange_rate(resultsetdetails.getDouble("EXCHANGE_RATE"));
						liuRecordDownloadObj.setFileUploadDate(resultsetdetails.getString("FILE_UPLOAD_DATE"));
						if(resultsetdetails.getString("VENDOR_NAME")=="")
						{
							liuRecordDownloadObj.setVendorName("");
						}
						else					
							liuRecordDownloadObj.setVendorName(resultsetdetails.getString("VENDOR_NAME"));

						liuRecordDownloadObj.setPendingSince(resultsetdetails.getInt("PENDING_SINCE"));
						liuRecordDownloadObj.setCustBankAccNo(resultsetdetails.getString("CUSTOMER_BANK_ACCOUNT_NO"));
						liuRecordDownloadObj.setVendorID(resultsetdetails.getString("VENDOR_ID"));
						liuRecordDownloadObj.setActedIn(resultsetdetails.getInt("ACTED_IN"));
						liuRecordDownloadObj.setDelNumber(resultsetdetails.getString("DEL_NO"));
						liuRecordDownloadObj.setEffectivePaymentAmount(resultsetdetails.getDouble("EFFECTIVE_PAYMENT_AMOUNT"));
						liuRecordDownloadObj.setFileName(resultsetdetails.getString("FILE_NAME"));

						row = worksheet.createRow(i);


						//	 worksheet.autoSizeColumn(0); 
						XSSFCell cellA2 = row.createCell((short) 0);
						cellA2.setCellValue(liuRecordDownloadObj.getPaymentMode());

						//	 worksheet.autoSizeColumn(1); 
						XSSFCell cellB2 = row.createCell((short) 1);
						cellB2.setCellValue(liuRecordDownloadObj.getReferenceID());

						//	 worksheet.autoSizeColumn(2); 
						XSSFCell cellC2 = row.createCell((short) 2);
						cellC2.setCellValue(liuRecordDownloadObj.getAccountExtID());

						//	worksheet.autoSizeColumn(3); 
						XSSFCell cellD2 = row.createCell((short) 3);
						cellD2.setCellValue(liuRecordDownloadObj.getDelNumber());
						cellD2.setCellStyle(rightAligned);


						//	worksheet.autoSizeColumn(4);
						XSSFCell cellE2 = row.createCell((short) 4);
						cellE2.setCellValue(liuRecordDownloadObj.getInvoiceNumber());

						//	worksheet.autoSizeColumn(5);
						XSSFCell cellF2 = row.createCell((short) 5);
						cellF2.setCellValue(liuRecordDownloadObj.getPaymentAmount());

						//		worksheet.autoSizeColumn(6);
						XSSFCell cellG2 = row.createCell((short) 6);
						cellG2.setCellValue(liuRecordDownloadObj.getPayment_currency());

						if(liuRecordDownloadObj.getPaymentMode().equalsIgnoreCase("OTHERS"))
						{
							//  worksheet.autoSizeColumn(7);
							XSSFCell cellH2 = row.createCell((short) 7);
							cellH2.setCellValue("1.0");
						}
						else
						{
							//	    worksheet.autoSizeColumn(7);
							XSSFCell cellH2 = row.createCell((short) 7);
							cellH2.setCellValue(liuRecordDownloadObj.getExchange_rate());
						}

						if(liuRecordDownloadObj.getPaymentMode().equalsIgnoreCase("OTHERS"))
						{
							//	worksheet.autoSizeColumn(8);
							XSSFCell cellI2 = row.createCell((short) 8);
							cellI2.setCellValue(liuRecordDownloadObj.getPaymentAmount());
						}

						else
						{
							//	worksheet.autoSizeColumn(8);
							XSSFCell cellI2 = row.createCell((short) 8);
							cellI2.setCellValue(liuRecordDownloadObj.getEffectivePaymentAmount());
						}

						//	worksheet.autoSizeColumn(9);
						XSSFCell cellJ2 = row.createCell((short) 9);
						cellJ2.setCellValue(liuRecordDownloadObj.getRemitterIFSC());

						//	worksheet.autoSizeColumn(10);
						XSSFCell cellK2 = row.createCell((short) 10);
						cellK2.setCellValue(liuRecordDownloadObj.getCustBankAccNo());

						//	worksheet.autoSizeColumn(11);
						XSSFCell cellL2 = row.createCell((short) 11);
						cellL2.setCellValue(liuRecordDownloadObj.getLiuReason());

						//	worksheet.autoSizeColumn(12);
						XSSFCell cellM2 = row.createCell((short) 12);
						cellM2.setCellValue(liuRecordDownloadObj.getFileID());

						//	worksheet.autoSizeColumn(13);
						XSSFCell cellN2 = row.createCell((short) 13);
						cellN2.setCellValue(liuRecordDownloadObj.getFileName());

						//	worksheet.autoSizeColumn(14);
						XSSFCell cellO2 = row.createCell((short) 14);
						cellO2.setCellValue(liuRecordDownloadObj.getVendorID());

						//    worksheet.autoSizeColumn(15);
						XSSFCell cellP2 = row.createCell((short) 15);
						cellP2.setCellValue(liuRecordDownloadObj.getVendorName());

						//     worksheet.autoSizeColumn(16);
						XSSFCell cellQ2 = row.createCell((short) 16);
						cellQ2.setCellValue(liuRecordDownloadObj.getUserID());

						//	worksheet.autoSizeColumn(17);
						XSSFCell cellR2 = row.createCell((short) 17);
						cellR2.setCellValue(liuRecordDownloadObj.getFileUploadDate());

						//	worksheet.autoSizeColumn(18);

						if(liuDownloadObj.getLiuStatus().equalsIgnoreCase("LIU PENDING"))
						{
							XSSFCell cellS2 = row.createCell((short) 18);
							cellS2.setCellValue(liuRecordDownloadObj.getPendingSince());
						}
						else
						{   
							XSSFCell cellS2 = row.createCell((short) 18);
							cellS2.setCellValue(liuRecordDownloadObj.getActedIn());
						}  
						i++;

					} 

					for(int j=0;j<19;j++)
					{
						worksheet.autoSizeColumn(j);

					}


					try {
						workbook.write(downloadFile);
						downloadFile.flush();
						downloadFile.close();
					} catch (IOException e) {
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						LIUlogger.error(errors);
						return null;
					}
				}	

			}

			catch (FileNotFoundException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				LIUlogger.error(errors);
				return null;
			}
			catch (Exception e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				LIUlogger.error(errors);
				return null;

			}


		}

		finally{
			if(resultsetdetails!=null){
				try {
					resultsetdetails.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(callableStatement!=null){
				try {
					callableStatement.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);
				}
			}

			if(conn!=null){
				try {
					conn.close();
				} catch (Exception e) {
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					LIUlogger.error(errors);	
				}

			}
		}

		LIUlogger.info("executed downloadedFile method in LIURecordsDaoIMPL");	

		return liuDownloadObj;


	}

	@Override
	public String payCodeDetails(List<LIURecordDetails> modifiedAccountsRecords, String userId, String sessionId,
			String action, int pageNumber) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	public LIURecordDetails accountProfileCache(LIURecordDetails liuInputFxObj) throws SQLException {

		/*List<LIURecordDetails> cacheAccount = new ArrayList<LIURecordDetails>();*/
		LIURecordDetails liuOutputFxObj = new LIURecordDetails();

		try{

			System.out.println("in liu cache code................");
			LIUlogger.info("in liu cache code................");


			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			String accountNo=liuInputFxObj.getAccountExtID();

			String LiuCacheCount=" select count(*) from (select a.ACCOUNT_NO,a.B2B_B2C,a.APS_FLAG,a.LEGAL_ENTITY,a.CUSTOMER_TYPE from account_profile_aps a where a.APS_FLAG='APS' and account_no='"+accountNo+"' order by inthit_date ) where  rownum<2"; 
			PreparedStatement cacheCount = conn.prepareStatement(LiuCacheCount);
			ResultSet rsCountRecords = cacheCount.executeQuery();
			if(rsCountRecords.next()){

				liuOutputFxObj.setCount(rsCountRecords.getInt(1));

			}
			String liuCacheQuery=" select ACCOUNT_NO,B2B_B2C,APS_FLAG,LEGAL_ENTITY,CUSTOMER_TYPE from (select a.ACCOUNT_NO,a.B2B_B2C,a.APS_FLAG,a.LEGAL_ENTITY,a.CUSTOMER_TYPE from account_profile_aps a where a.APS_FLAG='APS' and account_no='"+accountNo+"' order by inthit_date ) where  rownum<2";
			PreparedStatement psTotalRecords = conn.prepareStatement(liuCacheQuery);
			ResultSet rsTotalRecords = psTotalRecords.executeQuery();
			if(rsTotalRecords.next()){

				liuOutputFxObj.setAccountExtID(rsTotalRecords.getString(1));
				liuOutputFxObj.setB2b_b2c_Segment(rsTotalRecords.getString(2));
				liuOutputFxObj.setApsFlag(rsTotalRecords.getString(3));
				liuOutputFxObj.setFxLegalEntity(rsTotalRecords.getString(4));
				liuOutputFxObj.setFxCustomerType(rsTotalRecords.getString(5));
				//cacheAccount.add(cache);

			}

			rsCountRecords.close();
			rsTotalRecords.close();
			conn.close();
			System.out.println("liu input cache fx object"+liuOutputFxObj);

		}

		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);	
		}

		return liuOutputFxObj;


	}

	public LIURecordDetails accountProfileCacheLegacy(LIURecordDetails liuInputFxObj) throws SQLException {

		/*List<LIURecordDetails> cacheAccount = new ArrayList<LIURecordDetails>();*/
		LIURecordDetails liuOutputFxObj = new LIURecordDetails();

		try{

			System.out.println("in liu cache code................");
			LIUlogger.info("in liu cache code................");


			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			conn = jdbcTemplate.getDataSource().getConnection();
			String accountNo=liuInputFxObj.getAccountExtID();

			String LiuCacheCount=" select count(*) from (select a.ACCOUNT_NO,a.B2B_B2C,a.APS_FLAG,a.LEGAL_ENTITY,a.CUSTOMER_TYPE from account_profile_CAD a where a.APS_FLAG='CAD' and account_no='"+accountNo+"' order by inthit_date ) where  rownum<2"; 
			PreparedStatement cacheCount = conn.prepareStatement(LiuCacheCount);
			ResultSet rsCountRecords = cacheCount.executeQuery();
			if(rsCountRecords.next()){

				liuOutputFxObj.setCount(rsCountRecords.getInt(1));

			}
			String liuCacheQuery=" select ACCOUNT_NO,B2B_B2C,APS_FLAG,LEGAL_ENTITY,CUSTOMER_TYPE from (select a.ACCOUNT_NO,a.B2B_B2C,a.APS_FLAG,a.LEGAL_ENTITY,a.CUSTOMER_TYPE from account_profile_CAD a where a.APS_FLAG='CAD' and account_no='"+accountNo+"' order by inthit_date ) where  rownum<2";
			PreparedStatement psTotalRecords = conn.prepareStatement(liuCacheQuery);
			ResultSet rsTotalRecords = psTotalRecords.executeQuery();
			if(rsTotalRecords.next()){

				liuOutputFxObj.setAccountExtID(rsTotalRecords.getString(1));
				liuOutputFxObj.setB2b_b2c_Segment(rsTotalRecords.getString(2));
				liuOutputFxObj.setApsFlag(rsTotalRecords.getString(3));
				liuOutputFxObj.setFxLegalEntity(rsTotalRecords.getString(4));
				liuOutputFxObj.setFxCustomerType(rsTotalRecords.getString(5));
				//cacheAccount.add(cache);

			}

			rsCountRecords.close();
			rsTotalRecords.close();
			conn.close();
			System.out.println("liu input cache fx object"+liuOutputFxObj);

		}

		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);	
		}

		return liuOutputFxObj;


	}

	/*public String payCodeDetails(List<LIURecordDetails> modifiedAccountsRecords,String userId,String sessionId,String action,int pageNumber) throws SQLException {

	final String procedureCall = "{call DERIVE_PAYMENT_CODE_APS(?,?,?,?,?,?,?)}";
	CallableStatement callableStatement=null;
	ResultSet modifiedResulSetArray = null;

	List<LIURecordDetails> liuRecordsListUpdated=new ArrayList<LIURecordDetails>();

	try {

		// Get Connection instance from dataSource
		LIUlogger.info("Entered modifiedLIUDetails method in LIURecordsDaoIMPL");	

		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		conn = jdbcTemplate.getDataSource().getConnection();

		String rfPayment="";String b2b ="";String accountType="";

	        for (int index = 0; index < modifiedAccountsRecords.size(); index++)
	        {
	        	LIURecordDetails modifiedRecordsObj = modifiedAccountsRecords.get(index);



                   String paymentMode= modifiedRecordsObj.getPaymentMode();
	 	           LIUlogger.info("PAYMENT MODE 8:"+modifiedRecordsObj.getPaymentMode());
	 	           String lob = modifiedRecordsObj.getLob();  
	 	           LIUlogger.info("LOB 14:"+modifiedRecordsObj.getLob());

	 	          if(modifiedRecordsObj.getB2b_b2c_Segment()==null)
		            {
		            	  b2b ="";
		            	  LIUlogger.info("B2B B2C 20: B2B B2C IS SET TO NULL 20:");

		            } 
		            else
		            {
		            	 b2b = modifiedRecordsObj.getB2b_b2c_Segment();
		      	        LIUlogger.info("B2B B2C 20:"+modifiedRecordsObj.getB2b_b2c_Segment());
		            }

	 	         if(modifiedRecordsObj.getAccountType()==null)
		            {
		            	   accountType ="";
				            LIUlogger.info("ACCOUNT TYPE 13: ACCOUNT TYPE IS SET TO NULL");
		            }
		            else
		            {
		            	 accountType = modifiedRecordsObj.getAccountType();
				            LIUlogger.info("ACCOUNT TYPE 13:"+modifiedRecordsObj.getAccountType());
		            }


	 	         String legalEntity = modifiedRecordsObj.getFxLegalEntity();  
	 	           LIUlogger.info("LEGAL ENTITY 15:"+modifiedRecordsObj.getFxLegalEntity());


	 	          String customerName = modifiedRecordsObj.getCustomerName();
	 	           LIUlogger.info("CUSTOMER NAME 9:"+modifiedRecordsObj.getCustomerName());

	 	           if(modifiedRecordsObj.getLob().equalsIgnoreCase("ISTM") && modifiedRecordsObj.getAccountType().equalsIgnoreCase("DUMMY") && modifiedRecordsObj.getCustomerName()!=null)
	 	           {
	 	        	  rfPayment="YES";
	 	           }
	 	           else{
	 	        	  rfPayment="NO";
	 	           }
	 	           IF (    V_DERIVED_LOB = 'ISTM'
			                   AND v_acct_type = 'DUMMY'
			                   AND V_ORDER_NUMBER IS NOT NULL
			                   AND V_CUSTOMER_NAME IS NOT NULL)
			               THEN
			                  V_IS_RF_PAYMENT := 'YES';
			               ELSE
			                  V_IS_RF_PAYMENT := 'NO';
			               END IF;
	    callableStatement = conn.prepareCall(procedureCall);

		callableStatement.setString(1,paymentMode);
		callableStatement.setString(2,lob);
		callableStatement.setString(3,b2b);
		callableStatement.setString(4,accountType);
		callableStatement.setString(5,legalEntity);
		callableStatement.setString(6,rfPayment);
		// callableStatement.setString(5, apsFlag);
        callableStatement.registerOutParameter(6, Types.NUMERIC);
		callableStatement.registerOutParameter(7, Types.VARCHAR);

		callableStatement.executeUpdate(); 


		 String errorMsg=callableStatement.getString(6);
		 String errorCode=callableStatement.getString(7);

        conn.close();
			}

		}

    finally{


		if(callableStatement!=null){
	     	   try {
	     		  callableStatement.close();
				} catch (Exception e) {
					  StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						LIUlogger.error(errors);
				}
	     	   }

	    	   if(conn!=null){
	         	   try {
	    				conn.close();
	    			} catch (Exception e) {
	    				  StringWriter errors= new StringWriter();
	    					e.printStackTrace(new PrintWriter(errors));
	    					LIUlogger.error(errors);	
	    				}

	         	   }
      }


	return null;
	}*/

	public BulkDetails updateNonMigratedAcctDetails(String accountNumber, String msisdn,String inputLob)
	{
		LIUlogger.info("Start of Method updateNonMigratedAcctDetails");


		String retValue = null;
		String ndsResponse=null;
		String isTimeout ="NO";
		String isMigrated="false";
		BulkDetails bulkdetails1 = null;

		String CONNECT_TEXT = "connect timed out";
		String READ_TEXT = "Read timed out";

		try {
			BulkDetails bulkDetails = new BulkDetails();
			//	accountNumber="1739810440";
			if(!CommonValidator.isNull(accountNumber) && !accountNumber.equals("0")){
				bulkDetails.setAcctEXTID(accountNumber);
			}
			else{
				bulkDetails.setDelNO(msisdn);
			}
			CustomerAccountSummaryClient custAccountSummaryClient = new CustomerAccountSummaryClient();
			LIUlogger.info("Before calling INT_632 and account no is --->>" + accountNumber
					+ " in AccountDetailsClientThread");
			bulkdetails1 = 
					custAccountSummaryClient.postCustomerAccountSummaryToFX(bulkDetails, isMigrated,inputLob);
			//.createRequestJSONForPostCustAccountSummaryToFX(bulkDetails);
			LIUlogger.info("After calling INT_632 fx_outstanding_amount is in Call method---->>>"
					+ bulkdetails1.getFxOutstandingAmount() + "and accountNo is-->>" + accountNumber
					+ " in AccountDetailsClientThread");

			LIUlogger.info("ERROR from 632Int in MULITHREADCALLL-->> "+bulkdetails1.getErrorMsg());

			if(bulkdetails1.getErrorMsg() != null){

				if(CONNECT_TEXT.equalsIgnoreCase(bulkdetails1.getErrorMsg()) || 
						READ_TEXT.equalsIgnoreCase(bulkdetails1.getErrorMsg())){

					updateINT632CADDetails(accountNumber,null,msisdn,bulkdetails1);
					bulkdetails1.setApsFlag("TIMEOUT");
					retValue="ERROR";//to be checked later
					isTimeout="YES";
				}
				else{

					LIUlogger.info("Eror MSG for INT 632-->> "+bulkdetails1.getErrorMsg());

					//errorCodeAndDescription="Error from INT 632-> "+bulkdetails1.getErrorMsg();
					bulkdetails1.setApsFlag("ERROR");
					retValue="ERROR";
					updateINT632CADDetails(accountNumber,"ERROR",msisdn,bulkdetails1);

					///TO BE UPDATED IN RESPECTIVE TABLE

				}

			}

			else{

				String b2b=bulkdetails1.getB2b2c();
				String mktCode=bulkdetails1.getMktCode();
				String legelEntity=bulkdetails1.getLegalEntity();
				LIUlogger.info("account_number--->>"+bulkdetails1.getAcctEXTID()+" legelEntity-->>"+legelEntity+ "b2b-->>"+b2b+" mktCode-->>"+mktCode);

				
				LIUlogger.info("bulkdetails1.getLob()->>"+bulkdetails1.getLob()+
						" bulkdetails1.getServerId()->>"+bulkdetails1.getServerId()+
						" accountNumber->>"+accountNumber);

				if(bulkdetails1.getLob()==null && bulkdetails1.getServerId()!=null){

					String lob=getLobFromServerId(bulkdetails1.getServerId());
					bulkdetails1.setLob(lob);
				}
				
				
				if(!CommonValidator.isNull(accountNumber)){
					//accountNumber=bulkdetails1.getAcctEXTID();

					bulkdetails1.setApsFlag("CAD");
					ndsResponse="CAD";
					retValue = ndsResponse;
					updateINT632CADDetails(accountNumber, "CAD",bulkdetails1.getDelNO(),bulkdetails1);


				}
				else{

					if(CommonValidator.isNull(accountNumber) && !CommonValidator.isNull(msisdn)){

						bulkdetails1.setApsFlag("CAD");
						ndsResponse="CAD";
						retValue = ndsResponse;
						updateINT632CADDetails(accountNumber, "CAD",msisdn,bulkdetails1);


					}
				}
				//CALL SUCCESS METHOD HERE
				LIUlogger.info("bulkdetails1.getAccountInactiveDate()---->>>"+bulkdetails1.getAccountInactiveDate());
				if(bulkdetails1.getAccountInactiveDate()!=null){
					//send to LIU to be mapped in proc
					//proc is ready aps3 folder on desktop
					bulkdetails1.setErrorMsg("Account is not active");
					bulkdetails1.setErrorReasonCode("LIU_ACCOUNT");
				}	

			}

		}  catch (Exception e) {
			// TODO Auto-generated catch block
			LIUlogger.info("Exception", e);
		}
		LIUlogger.info("END of Method updateNonMigratedAcctDetails");

		return bulkdetails1;

	}
	public String getLobFromServerId(String serverId) {

		LIUlogger.info(" Start:: getLobFromServerId server id "+serverId);
		Connection con = null;
		String lob=null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			con = jdbcTemplate.getDataSource().getConnection();

			String query = "SELECT LOB FROM SERV_ID_LOB_MSTR WHERE STATUS='A' AND SERV_ID="+ serverId;
			PreparedStatement ps = con.prepareStatement(query);
			LIUlogger.info("getLobFromServerId query-->>"+query);
			//ps.setString(1, accountNo);
			//ps.setString(2, errMsg);
			ResultSet rs=ps.executeQuery();

			if(rs!=null && rs.next()){
				lob=rs.getString(1);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			LIUlogger.info("Exception", e);
		} finally {
			try {
				if(con!=null){
					con.close();

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				LIUlogger.info("Exception", e);
			}

		}
		LIUlogger.info(" END:: getLobFromServerId lob id "+lob);
		return lob;
	}

	public void updateINT632APSDetails(String accountNo, String apsflagval,String msisdnVal,BulkDetails bulkdetails1) {

		LIUlogger.info(" Start:: Inserting account profile aps details");
		Connection con = null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			con = jdbcTemplate.getDataSource().getConnection();
			if(!CommonValidator.isNull(bulkdetails1.getErrorMsg())){
				LIUlogger.info("inside error descri");

				String query = "insert into ACCOUNT_PROFILE_APS(account_no,inthit_date,aps_flag,error_description,msisdn) values(?,systimestamp,?,?,?)";
				PreparedStatement ps = con.prepareStatement(query);

				ps.setString(1, accountNo);
				ps.setString(2, apsflagval);
				ps.setString(3, bulkdetails1.getErrorMsg());
				ps.setString(4, msisdnVal);

				ps.executeQuery();
			}

			else{

				String query = "insert into ACCOUNT_PROFILE_APS(account_no,aps_flag,b2b_b2c,"
						+ "legal_entity,mkt_code,msisdn,parent_account_no,"
						+ "PRIMARY_CONTACT_NUMBER,ALTERNATE_CONTACT,CUSTOMER_TYPE,CUSTOMER_CLASS,VIP_FLAG,"
						+ "ACCOUNT_CATEGORY,INDIVIDUAL_NAME,BILL_REF_NUMBER,BILL_REF_RESETS,inthit_date,lob,BILL_COMPANY,CUSTOMER_EMAIL_ID,AEND) "
						+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,systimestamp,?,?,?,?)";
				PreparedStatement ps = con.prepareStatement(query);

				ps.setString(1, accountNo);
				ps.setString(2, apsflagval);
				ps.setString(3, bulkdetails1.getB2b2c());
				ps.setString(4, bulkdetails1.getLegalEntity());
				ps.setInt(5, Integer.parseInt(bulkdetails1.getMktCode()));
				ps.setString(6, msisdnVal);
				ps.setString(7, bulkdetails1.getParentAccountNumber());
				ps.setString(8, bulkdetails1.getPrimaryContactNumber());
				ps.setString(9,bulkdetails1.getAlternateContactNumber());
				ps.setString(10, bulkdetails1.getCustomerType());
				ps.setString(11, bulkdetails1.getCustomerClass());
				ps.setString(12, bulkdetails1.getVipFlag());
				ps.setInt(13, Integer.parseInt(bulkdetails1.getAccountCategory()));
				ps.setString(14, bulkdetails1.getGivenName()+" "+bulkdetails1.getFamilyName());
				ps.setString(15, bulkdetails1.getOrigBillRefNo());
				ps.setString(16, bulkdetails1.getOrigBillRefResets());
				ps.setString(17, bulkdetails1.getLob());
				ps.setString(18, bulkdetails1.getBillCompany());
				ps.setString(19, bulkdetails1.getEmailId());
				//ading aend val
				if(accountNo !=null && accountNo!="" && accountNo.length()>2){

					ps.setString(20, accountNo.substring(accountNo.length()-2, accountNo.length()));
				}
				else if(msisdnVal !=null && msisdnVal!="" && msisdnVal.length()>2){
					ps.setString(20, msisdnVal.substring(msisdnVal.length()-2, msisdnVal.length()));
				}
				else
					ps.setString(20,null);
				ps.executeQuery();

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			LIUlogger.info("Exception", e);
		} finally {
			try {
				if(con!=null){
					con.close();

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				LIUlogger.info("Exception", e);
			}

		}
		LIUlogger.info(
				" END:: Inserting account profile aps details");

	}

	public void updateINT632CADDetails(String accountNo, String apsflagval,String msisdnVal,BulkDetails bulkdetails1) {

		LIUlogger.info(" Start:: Inserting account profile aps details");

		LIUlogger.info("accountNo-->"+accountNo+" apsflagval->"+apsflagval+" bulkdetails1.getB2b2c()->"+bulkdetails1.getB2b2c());
		LIUlogger.info("bulkdetails1.getLegalEntity()->"+bulkdetails1.getLegalEntity()+" bulkdetails1.getMktCode()->"+bulkdetails1.getMktCode()+" msisdnVal->"+msisdnVal);


		LIUlogger.info("bulkdetails1.getParentAccountNumber()->"+bulkdetails1.getParentAccountNumber()+" bulkdetails1.getPrimaryContactNumber()->"+bulkdetails1.getPrimaryContactNumber()+" bulkdetails1.getAlternateContactNumber()->"+bulkdetails1.getAlternateContactNumber());

		LIUlogger.info("bulkdetails1.getCustomerType()-->"+bulkdetails1.getCustomerType()+" and bulkdetails1.getCustomerClass()--->"+bulkdetails1.getCustomerClass()+" and bulkdetails1.getVipFlag()-->"+bulkdetails1.getVipFlag()+" and bulkdetails1.getAccountCategory()--->"+bulkdetails1.getAccountCategory()+" and bulkdetails1.getGivenName()-->>"+bulkdetails1.getGivenName()+" and bulkdetails1.getFamilyName()-->>"+bulkdetails1.getFamilyName()+" and bulkdetails1.getOrigBillRefNo()-->"+bulkdetails1.getOrigBillRefNo());

		LIUlogger.info("bulkdetails1.getOrigBillRefResets()-->"+bulkdetails1.getOrigBillRefResets());
		Connection con = null;

		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			con = jdbcTemplate.getDataSource().getConnection();

			if(!CommonValidator.isNull(bulkdetails1.getErrorMsg())){
				LIUlogger.info("inside error description");

				String query = "insert into ACCOUNT_PROFILE_CAD(account_no,inthit_date,aps_flag,error_description,msisdn) values(?,systimestamp,?,?,?)";
				PreparedStatement ps = con.prepareStatement(query);

				ps.setString(1, accountNo);
				ps.setString(2, apsflagval);
				ps.setString(3, bulkdetails1.getErrorMsg());
				ps.setString(4, msisdnVal);

				ps.executeQuery();
			}

			else{

				String query = "insert into ACCOUNT_PROFILE_CAD(account_no,aps_flag,b2b_b2c,"
						+ "legal_entity,mkt_code,msisdn,parent_account_no,"
						+ "PRIMARY_CONTACT_NUMBER,ALTERNATE_CONTACT,CUSTOMER_TYPE,CUSTOMER_CLASS,VIP_FLAG,"
						+ "ACCOUNT_CATEGORY,INDIVIDUAL_NAME,BILL_REF_NUMBER,BILL_REF_RESETS,inthit_date,lob,BILL_COMPANY,CUSTOMER_EMAIL_ID,AEND) "
						+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,systimestamp,?,?,?,?)";
				PreparedStatement ps = con.prepareStatement(query);

				ps.setString(1, accountNo);
				ps.setString(2, apsflagval);
				ps.setString(3, bulkdetails1.getB2b2c());
				ps.setString(4, bulkdetails1.getLegalEntity());
				ps.setInt(5, Integer.parseInt(bulkdetails1.getMktCode()));
				ps.setString(6, msisdnVal);
				ps.setString(7, bulkdetails1.getParentAccountNumber());
				ps.setString(8, bulkdetails1.getPrimaryContactNumber());
				ps.setString(9,bulkdetails1.getAlternateContactNumber());
				ps.setString(10, bulkdetails1.getCustomerType());
				ps.setString(11, bulkdetails1.getCustomerClass());
				ps.setString(12, bulkdetails1.getVipFlag());
				ps.setInt(13, Integer.parseInt(bulkdetails1.getAccountCategory()));
				ps.setString(14, bulkdetails1.getGivenName()+" "+bulkdetails1.getFamilyName());
				ps.setString(15, bulkdetails1.getOrigBillRefNo());
				ps.setString(16, bulkdetails1.getOrigBillRefResets());
				ps.setString(17, bulkdetails1.getLob());
				ps.setString(18, bulkdetails1.getBillCompany());
				ps.setString(19, bulkdetails1.getEmailId());

				//ading aend val
				if(accountNo !=null && accountNo!="" && accountNo.length()>2){

					ps.setString(20, accountNo.substring(accountNo.length()-2, accountNo.length()));
				}
				else if(msisdnVal !=null && msisdnVal!="" && msisdnVal.length()>2){
					ps.setString(20, msisdnVal.substring(msisdnVal.length()-2, msisdnVal.length()));
				}
				else
					ps.setString(20,null);

				ps.executeQuery();

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			LIUlogger.info("Exception", e);
		} finally {
			try {
				if(con!=null){
					con.close();

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				LIUlogger.info("Exception", e);
			}

		}
		LIUlogger.info(
				" END:: Inserting account profile aps details");

	}
	public BulkDetails updateMigratedAccountDetails(String accountNumber, String msisdn)
	{


		String CONNECT_TEXT = "connect timed out";
		String READ_TEXT = "Read timed out";
		String retValue = null;
		String ndsResponse=null;
		//boolean flag =true;
		String isTimeout ="NO";
		String isMigrated="true";
		BulkDetails bulkdetails1 =null;

		try {
			BulkDetails bulkDetails = new BulkDetails();
			//	accountNumber="1739810440";
			if(!CommonValidator.isNull(accountNumber) && !accountNumber.equals("0")){
				bulkDetails.setAcctEXTID(accountNumber);
			}
			else{
				bulkDetails.setDelNO(msisdn);
			}
			CustomerAccountSummaryClient custAccountSummaryClient = new CustomerAccountSummaryClient();
			LIUlogger.info("Before calling INT_632 and account no is --->>" + accountNumber
					+ " in AccountDetailsClientThread");
			bulkdetails1 = 
					custAccountSummaryClient.postCustomerAccountSummaryToFX(bulkDetails, isMigrated,"Mobility");
			//.createRequestJSONForPostCustAccountSummaryToFX(bulkDetails);
			LIUlogger.info("After calling INT_632 fx_outstanding_amount is in Call method---->>>"
					+ bulkdetails1.getFxOutstandingAmount() + "and accountNo is-->>" + accountNumber
					+ " in AccountDetailsClientThread");

			LIUlogger.info("ERROR from 632Int in MULITHREADCALLL-->> "+bulkdetails1.getErrorMsg());

			if(bulkdetails1.getErrorMsg() != null){

				if(READ_TEXT.equalsIgnoreCase(bulkdetails1.getErrorMsg()) || 
						CONNECT_TEXT.equalsIgnoreCase(bulkdetails1.getErrorMsg())){

					bulkdetails1.setApsFlag("TIMEOUT");

					updateINT632APSDetails(accountNumber,null,msisdn,bulkdetails1);
					retValue="TimeOut";
					isTimeout="YES";
				}
				else{

					LIUlogger.info("Eror MSG for INT 632-->> "+bulkdetails1.getErrorMsg());
					bulkdetails1.setApsFlag("ERROR");

					retValue="ERROR";
					updateINT632APSDetails(accountNumber,"ERROR",msisdn,bulkdetails1);

				}
				//UPDATING HIT TIME IN CASE OF FAILURE
				//update632FailureResponse(accountNumber, msisdn, multi_Service, isMigrated,isTimeout,lob,bulkdetails1.getErrorMsg());
			}

			else{

				String b2b=bulkdetails1.getB2b2c();
				String mktCode=bulkdetails1.getMktCode();
				String legelEntity=bulkdetails1.getLegalEntity();
				LIUlogger.info("account_number--->>"+bulkdetails1.getAcctEXTID()+" legelEntity-->>"+legelEntity+ "b2b-->>"+b2b+" mktCode-->>"+mktCode);

				if(!CommonValidator.isNull(accountNumber)){
					//accountNumber=bulkdetails1.getAcctEXTID();
					bulkdetails1.setApsFlag("APS");
					ndsResponse="APS";
					retValue = ndsResponse;
					updateINT632APSDetails(accountNumber, "APS",bulkdetails1.getDelNO(),bulkdetails1);


				}
				else{

					if(CommonValidator.isNull(accountNumber) && !CommonValidator.isNull(msisdn)){

						bulkdetails1.setApsFlag("APS");
						ndsResponse="APS";
						retValue = ndsResponse;
						updateINT632APSDetails(accountNumber, "APS",msisdn,bulkdetails1);


					}
				}

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			LIUlogger.info("Exception", e);
		}


		return bulkdetails1;

	}
	
	public BulkDetails updateMigratedAccountDetails(String accountNumber, String msisdn,String lob)
	{


		String CONNECT_TEXT = "connect timed out";
		String READ_TEXT = "Read timed out";
		String retValue = null;
		String ndsResponse=null;
		//boolean flag =true;
		String isTimeout ="NO";
		String isMigrated="true";
		BulkDetails bulkdetails1 =null;

		try {
			BulkDetails bulkDetails = new BulkDetails();
			//	accountNumber="1739810440";
			if(!CommonValidator.isNull(accountNumber) && !accountNumber.equals("0")){
				bulkDetails.setAcctEXTID(accountNumber);
			}
			else{
				bulkDetails.setDelNO(msisdn);
			}
			if(!CommonValidator.isNull(accountNumber) && (accountNumber.contains("21-") || accountNumber.startsWith("21-"))){
				bulkDetails.setLob(lob);
			}
			
			CustomerAccountSummaryClient custAccountSummaryClient = new CustomerAccountSummaryClient();
			LIUlogger.info("Before calling INT_632 and account no is --->>" + accountNumber
					+ " in AccountDetailsClientThread");
			bulkdetails1 = 
					custAccountSummaryClient.postCustomerAccountSummaryToFX(bulkDetails, isMigrated,lob);
			//.createRequestJSONForPostCustAccountSummaryToFX(bulkDetails);
			LIUlogger.info("After calling INT_632 fx_outstanding_amount is in Call method---->>>"
					+ bulkdetails1.getFxOutstandingAmount() + "and accountNo is-->>" + accountNumber
					+ " in AccountDetailsClientThread");

			LIUlogger.info("ERROR from 632Int in MULITHREADCALLL-->> "+bulkdetails1.getErrorMsg());

			if(bulkdetails1.getErrorMsg() != null){

				if(READ_TEXT.equalsIgnoreCase(bulkdetails1.getErrorMsg()) || 
						CONNECT_TEXT.equalsIgnoreCase(bulkdetails1.getErrorMsg())){

					bulkdetails1.setApsFlag("TIMEOUT");

					updateINT632APSDetails(accountNumber,null,msisdn,bulkdetails1);
					retValue="TimeOut";
					isTimeout="YES";
				}
				else{

					LIUlogger.info("Eror MSG for INT 632-->> "+bulkdetails1.getErrorMsg());
					bulkdetails1.setApsFlag("ERROR");

					retValue="ERROR";
					updateINT632APSDetails(accountNumber,"ERROR",msisdn,bulkdetails1);

				}
				//UPDATING HIT TIME IN CASE OF FAILURE
				//update632FailureResponse(accountNumber, msisdn, multi_Service, isMigrated,isTimeout,lob,bulkdetails1.getErrorMsg());
			}

			else{

				String b2b=bulkdetails1.getB2b2c();
				String mktCode=bulkdetails1.getMktCode();
				String legelEntity=bulkdetails1.getLegalEntity();
				LIUlogger.info("account_number--->>"+bulkdetails1.getAcctEXTID()+" legelEntity-->>"+legelEntity+ "b2b-->>"+b2b+" mktCode-->>"+mktCode);

				if(!CommonValidator.isNull(accountNumber)){
					//accountNumber=bulkdetails1.getAcctEXTID();
					bulkdetails1.setApsFlag("APS");
					ndsResponse="APS";
					retValue = ndsResponse;
					updateINT632APSDetails(accountNumber, "APS",bulkdetails1.getDelNO(),bulkdetails1);


				}
				else{

					if(CommonValidator.isNull(accountNumber) && !CommonValidator.isNull(msisdn)){

						bulkdetails1.setApsFlag("APS");
						ndsResponse="APS";
						retValue = ndsResponse;
						updateINT632APSDetails(accountNumber, "APS",msisdn,bulkdetails1);


					}
				}

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			LIUlogger.info("Exception", e);
		}


		return bulkdetails1;

	}
	

	public LIURecordDetails validationsFromFXAps(LIURecordDetails liuInputFxObj)
	{
		LIURecordDetails liuOutputFxObj = new LIURecordDetails();
		List<LIURecordDetails> cacheAccount = new ArrayList<LIURecordDetails>();
		List<com.acecad.airtel.eai.integration.model.Invoice> invoiceList = null;
		//Addition By APS Team Starts
		String apsFlag = "";
		//String firstVal="";
		String lob="";
		String accountNumber=liuInputFxObj.getAccountExtID();
		String msisdn=liuInputFxObj.getDelNumber();
		OptimusDetailsDto optimusDetails=null;
		String anchorId="";
		int productTypeStatus=0;
		//Addition by APS Team Ends Here
		try {

			if("0".equals(accountNumber))
			{
				accountNumber=null;
			}
			if(!liuInputFxObj.getAccountExtID().equals("0") || liuInputFxObj.getAccountExtID()!=""){
				//Getting lob from cache by using function get_lob_details
				try {
					lob=getlobByAccountNo(liuInputFxObj.getAccountExtID());
					LIUlogger.info("line number 5343 account_number--->>"+liuInputFxObj.getAccountExtID()+"LOB is===>"+lob);
				} catch (Exception e) {

					e.printStackTrace();
				}
			}

			if(accountNumber==null && liuInputFxObj.getDelNumber()!=""){
				//Getting lob from cache by using function get_lob_details
				try {
					lob=getlobByDelNo(liuInputFxObj.getDelNumber());
					LIUlogger.info("mobile number--->>"+liuInputFxObj.getDelNumber()+"LOB is===>"+lob);
				} catch (Exception e) {

					e.printStackTrace();
				}
			}
			LIUlogger.info("line number 5360 account_number--->>"+liuInputFxObj.getAccountExtID()+
					" accountNumber->"+accountNumber);
			
			if(accountNumber!=null && accountNumber.length()>14){

				LIUlogger.info("account_number length >14--->>"+liuInputFxObj.getAccountExtID()+"LOB is===>"+lob+"in account number length greater than 13");
				//Int 632 call with false
				
				
				BulkDetails bulkobjRes=updateNonMigratedAcctDetails(liuInputFxObj.getAccountExtID(), liuInputFxObj.getDelNumber(),"AES");

				LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"after response from updateNonmigrated method");

				if (!"LIU_ACCOUNT".equalsIgnoreCase(bulkobjRes.getErrorCodeDescription()) 
						&& "CAD".equalsIgnoreCase(bulkobjRes.getApsFlag())) {
					
					LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"in aps flag CAD");
					
					CustomerAccountSummaryClient custAccountSummaryClient = new CustomerAccountSummaryClient();
					BulkDetails fileRecords = new BulkDetails();
					//fileRecords.setAcctEXTID(liuInputFxObj.getAccountExtID());
					
					fileRecords.setAcctEXTID(liuInputFxObj.getFxInternalAcctNum());// this is for 220call
				
					//BulkDetails bulkobjRes = custAccountSummaryClient.postCustomerAccountSummaryToFX(fileRecords,"true");
					//.createRequestJSONForPostCustAccountSummaryToFX(fileRecords);
					if (bulkobjRes != null) {
						
						LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"bulkobjRes != null");

						if (CommonValidator.isNull(bulkobjRes.getErrorMsg())) {
							liuInputFxObj.setApsFlag(bulkobjRes.getApsFlag());
							liuInputFxObj.setLob(bulkobjRes.getLob());
							LIUlogger.info("LOB BEFORE SETTING VAL->"+bulkobjRes.getLob());
							if(bulkobjRes.getB2b2c()==null && 
									("AES".equalsIgnoreCase(bulkobjRes.getLob()) || "ISTM".equalsIgnoreCase(bulkobjRes.getLob()))){
								bulkobjRes.setB2b2c("B2B");
								
							}
							//liuInputFxObj.setRemarks("");
							liuInputFxObj.setFxLegalEntity(bulkobjRes.getLegalEntity());
							liuInputFxObj.setMarketCode(bulkobjRes.getMktCode());
							//liuInputFxObj.setAccountType("CUSTOMER");
							liuInputFxObj.setB2b_b2c_Segment(bulkobjRes.getB2b2c());
							LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"bulkobjRes.getB2b2c()->"+bulkobjRes.getB2b2c());
							if(bulkobjRes.getB2b2c()!=null){
								LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"bulkobjRes.getB2b2c()!=null ||!bulkobjRes.getB2b2c().isEmpty()->");
								
								if("B2B".equalsIgnoreCase(bulkobjRes.getB2b2c())){ //invoice list
									GetCustomerInvoiceSummaryV5 customerInvoiceDetailsClient = new GetCustomerInvoiceSummaryV5();
									try {
										fileRecords =customerInvoiceDetailsClient.postUpdateCustomerInvoiceToFX(fileRecords,"");
									} catch (Exception e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}	
							}
							String inr = "1";
							liuInputFxObj.setPayment_currency(bulkobjRes.getPaymentCurrency());
							if(!inr.equalsIgnoreCase(liuInputFxObj.getPayment_currency())){
								liuInputFxObj.setRemarks("Currency Discrepancy");
							}

						}else{
							liuInputFxObj.setRemarks(liuInputFxObj.getLiuReason());
						}

					}
					fileRecords.setAcctEXTID(liuInputFxObj.getAccountExtID());
				}
			}
			LIUlogger.info("line number 5414 account_number--->>"+liuInputFxObj.getAccountExtID()+
					" accountNumber->"+accountNumber);
			if(accountNumber!=null && accountNumber.length()<=14){


				LIUlogger.info("account_number length <=14 --->>"+liuInputFxObj.getAccountExtID()+"length less then 13");
				
				if(CommonValidator.isNull(lob) && !accountNumber.startsWith("21-")){

					LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"lob===>"+lob);

					lob="Mobility";
					LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"Hitting optimus with lob mobility");

					optimusDetails=new OptimusClient().postOptimusToFX(lob,accountNumber,"",productTypeStatus);

					LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"after Hitting optimus with lob mobility");

					if(!"Success".equalsIgnoreCase(optimusDetails.getResponseMsg())){


						lob="Telemedia";//FL
						LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"Hitting optimus with lob "+lob);
						optimusDetails=new OptimusClient().postOptimusToFX(lob,accountNumber,"",productTypeStatus);
						LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"after Hitting optimus with lob "+lob);
					}
				}else if(accountNumber.startsWith("21-")){
					LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID());
					lob="AES";
				}else
				{

					LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"in else block when lob is not null "+lob);
					if("mob".equalsIgnoreCase(lob)){
						lob="Mobility";
					}
					if("BTS".equalsIgnoreCase(lob) || "fl".equalsIgnoreCase(lob)){
						lob="Telemedia";
					}

					optimusDetails=new OptimusClient().postOptimusToFX(lob,accountNumber,"",productTypeStatus);
					LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"in else block when lob is not null and after hitting"+lob);
				}

				String homesIdDesc="";
				String inputLob="AES";
				String val=accountNumber.substring(0, 1);
				if(optimusDetails!=null){
				anchorId= optimusDetails.getAnchor();
				LIUlogger.info("anchorId----------------->>>>>>>>>"+anchorId);
				if(anchorId!=null){

					LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"anchor id is:---->>>>>>>>>"+anchorId);
					//	 System.out.println("anchor id is:---->>>>>>>>>"+anchorId);
				}
				
				
				apsFlag=optimusDetails.getApsFlag();
				
				LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"apsFlag is:---->>>>>>>>>"+apsFlag);
				LIUlogger.info("optimusDetails.getResponseMsg()------>>>>>"+optimusDetails.getResponseMsg());
				//String val=accountNumber.substring(0, 1);
				homesIdDesc=optimusDetails.getResponseMsg();
				if("Success".equalsIgnoreCase(homesIdDesc)){
					homesIdDesc=null;
					inputLob="Mobility";
				}
				}
				if(homesIdDesc!=null && !(accountNumber.length()==8 && "7".equalsIgnoreCase(val))){
					liuInputFxObj.setRemarks("Invalid Account/Mobile No");
				}
				

				
				 if(!"APS".equalsIgnoreCase(apsFlag) && !"HOLD".equalsIgnoreCase(apsFlag) && !accountNumber.startsWith("21-")){

					LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"apsFlag is:---->>>>>>>>>"+apsFlag+"LEGACY HIT");

					BulkDetails bulkobjRes=updateNonMigratedAcctDetails(liuInputFxObj.getAccountExtID(), liuInputFxObj.getDelNumber(),inputLob);

					CustomerAccountSummaryClient custAccountSummaryClient = new CustomerAccountSummaryClient();
					BulkDetails fileRecords = new BulkDetails();
					if("AES".equalsIgnoreCase(bulkobjRes.getLob()) || "ISTM".equalsIgnoreCase(bulkobjRes.getLob())){
						fileRecords.setAcctEXTID(liuInputFxObj.getFxInternalAcctNum());//FOR 220 CALL
					}
					else{
					fileRecords.setAcctEXTID(liuInputFxObj.getAccountExtID());
					}
					//BulkDetails bulkobjRes = custAccountSummaryClient.postCustomerAccountSummaryToFX(fileRecords,"true");
					//.createRequestJSONForPostCustAccountSummaryToFX(fileRecords);
					if (bulkobjRes != null) {

						if (CommonValidator.isNull(bulkobjRes.getErrorMsg())) {
							liuInputFxObj.setApsFlag(bulkobjRes.getApsFlag());
							liuInputFxObj.setLob(bulkobjRes.getLob());
							//liuInputFxObj.setRemarks("");
							LIUlogger.info("LOB BEFORE SETTING VAL->"+bulkobjRes.getLob());
							if(bulkobjRes.getB2b2c()==null && 
									("AES".equalsIgnoreCase(bulkobjRes.getLob()) || "ISTM".equalsIgnoreCase(bulkobjRes.getLob()))){
								bulkobjRes.setB2b2c("B2B");
								
							}
							liuInputFxObj.setFxLegalEntity(bulkobjRes.getLegalEntity());
							liuInputFxObj.setMarketCode(bulkobjRes.getMktCode());
							//liuInputFxObj.setAccountType("CUSTOMER");
							liuInputFxObj.setB2b_b2c_Segment(bulkobjRes.getB2b2c());
							if(bulkobjRes.getB2b2c()!=null){
								if("B2B".equalsIgnoreCase(bulkobjRes.getB2b2c())){ //invoice list
									GetCustomerInvoiceSummaryV5 customerInvoiceDetailsClient = new GetCustomerInvoiceSummaryV5();
									try {
										fileRecords =customerInvoiceDetailsClient.postUpdateCustomerInvoiceToFX(fileRecords,"");
									} catch (Exception e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}	
							}
							String inr = "1";
							liuInputFxObj.setPayment_currency(bulkobjRes.getPaymentCurrency());
							if(!inr.equalsIgnoreCase(liuInputFxObj.getPayment_currency())){
								liuInputFxObj.setRemarks("Currency Discrepancy");
							}

						}else{
							liuInputFxObj.setRemarks(liuInputFxObj.getLiuReason());
						}

					}
					fileRecords.setAcctEXTID(liuInputFxObj.getAccountExtID());
					if("ERROR".equalsIgnoreCase(bulkobjRes.getApsFlag())){
						liuInputFxObj.setRemarks("Invalid Account/Mobile No");
					}
					if("TIMEOUT".equalsIgnoreCase(bulkobjRes.getApsFlag())){
						liuInputFxObj.setRemarks("Getting TimeOut from INT_632");
					}

				}else if(!"APS".equalsIgnoreCase(apsFlag) && !"HOLD".equalsIgnoreCase(apsFlag) && accountNumber.startsWith("21-")){
					//AES 632 call for 21- account
					LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"----->>21- account 632 HIT");
					BulkDetails bulkobjRes=updateMigratedAccountDetails(accountNumber, msisdn,lob);
					LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"AFTER update migrated hit");
					
					BulkDetails fileRecords = new BulkDetails();
					fileRecords.setAcctEXTID(liuInputFxObj.getAccountExtID());
					if (bulkobjRes != null) {
						LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"setting values after 632");
						if (CommonValidator.isNull(bulkobjRes.getErrorMsg())) {
							liuInputFxObj.setApsFlag(bulkobjRes.getApsFlag());
							liuInputFxObj.setLob(bulkobjRes.getLob());
							//liuInputFxObj.setRemarks("SUCCESS");
							liuInputFxObj.setFxLegalEntity(bulkobjRes.getLegalEntity());
							liuInputFxObj.setMarketCode(bulkobjRes.getMktCode());
							liuInputFxObj.setAccountType(bulkobjRes.getAccountType());
							liuInputFxObj.setB2b_b2c_Segment(bulkobjRes.getB2b2c());
							if(bulkobjRes.getB2b2c()!=null ||  !bulkobjRes.getB2b2c().isEmpty()){
								if("B2B".equalsIgnoreCase(bulkobjRes.getB2b2c())){ //invoice list
									GetCustomerInvoiceSummaryV5 customerInvoiceDetailsClient = new GetCustomerInvoiceSummaryV5();
									try {
										fileRecords =customerInvoiceDetailsClient.postUpdateCustomerInvoiceToFX(fileRecords,"");
									} catch (Exception e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}	
							}
							String inr = "1";
							liuInputFxObj.setPayment_currency(bulkobjRes.getPaymentCurrency());

							if(!inr.equalsIgnoreCase(liuInputFxObj.getPayment_currency())){
								liuInputFxObj.setRemarks("Currency Discrepancy");
							}
							LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+" values set after 632"+"liu remarks----------->>>>>"+liuInputFxObj.getRemarks());
							}else{
								liuInputFxObj.setRemarks(liuInputFxObj.getLiuReason());
							}
							
							if("ERROR".equalsIgnoreCase(bulkobjRes.getApsFlag())){
								liuInputFxObj.setRemarks("Invalid Account/Mobile No");
								
								LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+" in error block of aps flag"+"liu remarks----------->>>>>"+liuInputFxObj.getRemarks());

							}
							if("TIMEOUT".equalsIgnoreCase(bulkobjRes.getApsFlag())){
								liuInputFxObj.setRemarks("Getting TimeOut from INT_632");
								
								LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+" in error block of Getting TimeOut from INT_632"+"liu remarks----------->>>>>"+liuInputFxObj.getRemarks());

							}
						
					}
				}

				if(("APS").equalsIgnoreCase(apsFlag)){
					LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"apsFlag is:---->>>>>>>>>"+apsFlag+"APS HIT");
					//cache function
					BulkDetails bulkobjRes=updateMigratedAccountDetails(accountNumber, msisdn);

					LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"AFTER update migrated hit");

					CustomerAccountSummaryClient custAccountSummaryClient = new CustomerAccountSummaryClient();
					BulkDetails fileRecords = new BulkDetails();
					fileRecords.setAcctEXTID(liuInputFxObj.getAccountExtID());
					//BulkDetails bulkobjRes = custAccountSummaryClient.postCustomerAccountSummaryToFX(fileRecords,"true");
					//.createRequestJSONForPostCustAccountSummaryToFX(fileRecords);
					if (bulkobjRes != null) {
						LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"setting values after 632");
						if (CommonValidator.isNull(bulkobjRes.getErrorMsg())) {
							liuInputFxObj.setApsFlag(bulkobjRes.getApsFlag());
							liuInputFxObj.setLob("MOB");
							//liuInputFxObj.setRemarks("SUCCESS");
							liuInputFxObj.setFxLegalEntity(bulkobjRes.getLegalEntity());
							liuInputFxObj.setMarketCode(bulkobjRes.getMktCode());
							liuInputFxObj.setAccountType("CUSTOMER");
							liuInputFxObj.setB2b_b2c_Segment(bulkobjRes.getB2b2c());
							if(bulkobjRes.getB2b2c()!=null ||  !bulkobjRes.getB2b2c().isEmpty()){
								if("B2B".equalsIgnoreCase(bulkobjRes.getB2b2c())){ //invoice list
									GetCustomerInvoiceSummaryV5 customerInvoiceDetailsClient = new GetCustomerInvoiceSummaryV5();
									try {
										fileRecords =customerInvoiceDetailsClient.postUpdateCustomerInvoiceToFX(fileRecords,"");
									} catch (Exception e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}	
							}
							String inr = "1";
							liuInputFxObj.setPayment_currency(bulkobjRes.getPaymentCurrency());

							if(!inr.equalsIgnoreCase(liuInputFxObj.getPayment_currency())){
								liuInputFxObj.setRemarks("Currency Discrepancy");
							}
							LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+" values set after 632"+"liu remarks----------->>>>>"+liuInputFxObj.getRemarks());
						}else{
							liuInputFxObj.setRemarks(liuInputFxObj.getLiuReason());
						}

					}
					if("ERROR".equalsIgnoreCase(bulkobjRes.getApsFlag())){
						liuInputFxObj.setRemarks("Invalid Account/Mobile No");
						
						LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+" in error block of aps flag"+"liu remarks----------->>>>>"+liuInputFxObj.getRemarks());

					}
					if("TIMEOUT".equalsIgnoreCase(bulkobjRes.getApsFlag())){
						liuInputFxObj.setRemarks("Getting TimeOut from INT_632");
						
						LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+" in error block of Getting TimeOut from INT_632"+"liu remarks----------->>>>>"+liuInputFxObj.getRemarks());

					}

				}

				if(("HOLD").equalsIgnoreCase(apsFlag)){
					LIUlogger.info("account_number--->>"+liuInputFxObj.getAccountExtID()+"apsFlag is hold"+apsFlag);
				}


			}
			//mobile no optimus
			if(accountNumber==null && !msisdn.equals("") ){
				LIUlogger.info("msisdn--->>"+msisdn);
				if(CommonValidator.isNull(lob)){

					lob="Mobility";
					optimusDetails=new OptimusClient().postOptimusToFX(lob,null,msisdn,productTypeStatus);
					LIUlogger.info("msisdn--->>"+msisdn+"after optimus hit with lob"+lob);
					if(!"Success".equalsIgnoreCase(optimusDetails.getResponseMsg()) || "No data found".equalsIgnoreCase(optimusDetails.getResponseMsg())){
						productTypeStatus=1;
						lob="Telemedia";//FL
						optimusDetails=new OptimusClient().postOptimusToFX(lob,null,msisdn,productTypeStatus);
						LIUlogger.info("msisdn--->>"+msisdn+"after optimus hit with lob"+lob);
					}
				}

				else
				{
					if("mob".equalsIgnoreCase(lob)){
						lob="Mobility";
					}
					if("BTS".equalsIgnoreCase(lob) || "fl".equalsIgnoreCase(lob)){
						lob="Telemedia";
					}
					optimusDetails=new OptimusClient().postOptimusToFX(lob,null,msisdn,productTypeStatus);
					LIUlogger.info("msisdn--->>"+msisdn+"after optimus hit with lob"+lob);
				}


				anchorId= optimusDetails.getAnchor();
				if(!("").equalsIgnoreCase (anchorId)){

					LIUlogger.info("msisdn--->>"+msisdn+"after optimus hit with lob"+lob+"anchor id is:---->>>>>>>>>"+anchorId);
					// System.out.println("anchor id is:---->>>>>>>>>"+anchorId);
				}
				apsFlag=optimusDetails.getApsFlag();
				
				String homesIdDesc=optimusDetails.getResponseMsg();
				String inputLob="AES";
				if("Success".equalsIgnoreCase(homesIdDesc)){
					homesIdDesc=null;
					inputLob="Mobility";
				}

				if(("CAD").equalsIgnoreCase(apsFlag) || homesIdDesc!=null ){
					LIUlogger.info("msisdn--->>"+msisdn+"after optimus hit with lob"+lob+"LEGACY HIT");
					BulkDetails bulkobjRes=updateNonMigratedAcctDetails(liuInputFxObj.getAccountExtID(), liuInputFxObj.getDelNumber(),inputLob);

					//			CustomerAccountSummaryClient custAccountSummaryClient = new CustomerAccountSummaryClient();
					BulkDetails fileRecords = new BulkDetails();
					fileRecords.setAcctEXTID(liuInputFxObj.getAccountExtID());
					//BulkDetails bulkobjRes = custAccountSummaryClient.postCustomerAccountSummaryToFX(fileRecords,"true");
					//.createRequestJSONForPostCustAccountSummaryToFX(fileRecords);
					if (bulkobjRes != null) {

						if (CommonValidator.isNull(bulkobjRes.getErrorMsg())) {
							liuInputFxObj.setApsFlag(bulkobjRes.getApsFlag());
							liuInputFxObj.setLob(bulkobjRes.getLob());
							//liuInputFxObj.setRemarks("");
							liuInputFxObj.setFxLegalEntity(bulkobjRes.getLegalEntity());
							liuInputFxObj.setMarketCode(bulkobjRes.getMktCode());
							//liuInputFxObj.setAccountType("CUSTOMER");
							liuInputFxObj.setParentAcctNo(bulkobjRes.getParentAccountNumber());
							liuInputFxObj.setAccountExtID(bulkobjRes.getAcctEXTID());
							liuInputFxObj.setB2b_b2c_Segment(bulkobjRes.getB2b2c());
							if(bulkobjRes.getB2b2c()!=null){
								if("B2B".equalsIgnoreCase(bulkobjRes.getB2b2c())){ //invoice list
									GetCustomerInvoiceSummaryV5 customerInvoiceDetailsClient = new GetCustomerInvoiceSummaryV5();
									try {
										fileRecords =customerInvoiceDetailsClient.postUpdateCustomerInvoiceToFX(fileRecords,"");
									} catch (Exception e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}	
							}
							String inr = "1";
							liuInputFxObj.setPayment_currency(bulkobjRes.getPaymentCurrency());
							if(!inr.equalsIgnoreCase(liuInputFxObj.getPayment_currency())){
								liuInputFxObj.setRemarks("Currency Discrepancy");
							}

						}else{
							liuInputFxObj.setRemarks(liuInputFxObj.getLiuReason());
						}

					}

					if("ERROR".equalsIgnoreCase(bulkobjRes.getApsFlag())){
						liuInputFxObj.setRemarks("Invalid Account/Mobile No");
					}
					if("TIMEOUT".equalsIgnoreCase(bulkobjRes.getApsFlag())){
						liuInputFxObj.setRemarks("Getting TimeOut from INT_632");
					}
				}

				if(("APS").equalsIgnoreCase(apsFlag)){
					LIUlogger.info("msisdn--->>"+msisdn+"after optimus hit with lob"+lob+"APS HIT");
					//cache function
					BulkDetails bulkobjRes=updateMigratedAccountDetails(accountNumber, msisdn);
					CustomerAccountSummaryClient custAccountSummaryClient = new CustomerAccountSummaryClient();
					BulkDetails fileRecords = new BulkDetails();
					fileRecords.setAcctEXTID(liuInputFxObj.getAccountExtID());
					//BulkDetails bulkobjRes = custAccountSummaryClient.postCustomerAccountSummaryToFX(fileRecords,"true");
					//.createRequestJSONForPostCustAccountSummaryToFX(fileRecords);
					if (bulkobjRes != null) {

						if (CommonValidator.isNull(bulkobjRes.getErrorMsg())) {
							liuInputFxObj.setApsFlag(bulkobjRes.getApsFlag());
							liuInputFxObj.setLob("MOB");
							//liuInputFxObj.setRemarks("SUCCESS");
							liuInputFxObj.setFxLegalEntity(bulkobjRes.getLegalEntity());
							liuInputFxObj.setMarketCode(bulkobjRes.getMktCode());
							liuInputFxObj.setAccountType("CUSTOMER");
							liuInputFxObj.setB2b_b2c_Segment(bulkobjRes.getB2b2c());
							liuInputFxObj.setParentAcctNo(bulkobjRes.getParentAccountNumber());
							liuInputFxObj.setAccountExtID(bulkobjRes.getAcctEXTID());
							if(bulkobjRes.getB2b2c()!=null){
								if("B2B".equalsIgnoreCase(bulkobjRes.getB2b2c())){ //invoice list
									GetCustomerInvoiceSummaryV5 customerInvoiceDetailsClient = new GetCustomerInvoiceSummaryV5();
									try {
										fileRecords =customerInvoiceDetailsClient.postUpdateCustomerInvoiceToFX(fileRecords,"");
									} catch (Exception e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}	
							}
							String inr = "1";
							liuInputFxObj.setPayment_currency(bulkobjRes.getPaymentCurrency());

							if(!inr.equalsIgnoreCase(liuInputFxObj.getPayment_currency())){
								liuInputFxObj.setRemarks("Currency Discrepancy");
							}

						}else{
							liuInputFxObj.setRemarks(liuInputFxObj.getLiuReason());
						}

					}
					if("ERROR".equalsIgnoreCase(bulkobjRes.getApsFlag())){
						liuInputFxObj.setRemarks("Invalid Account/Mobile No");
					}
					if("TIMEOUT".equalsIgnoreCase(bulkobjRes.getApsFlag())){
						liuInputFxObj.setRemarks("Getting TimeOut from INT_632");
					}

				}

				if(("hold").equalsIgnoreCase(apsFlag)){
					System.out.println("in hold block response from optimus");
				}

			}




		}

		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			LIUlogger.error(errors);
			liuInputFxObj.setRemarks("Failed: Connectivity Issue..RETRY..");
			LIUlogger.info(liuInputFxObj.getRemarks());
			LIUlogger.info("In catch block exception handling.. ");


		}

		return liuInputFxObj;

	}

	public String getlobByDelNo(String delno) throws Exception{
		String lob="";
		int msisdn=0;
		msisdn=Integer.parseInt(delno);
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			String qry = " select GET_LOB_DETAILS('', "+msisdn+") from dual";
			ps = con.prepareStatement(qry);
			rs = ps.executeQuery();
			while (rs.next()) {
				lob = rs.getString(1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (con != null) {
				ps.close();
				rs.close();
				con.close();
			}
		}
		return lob;

	}

	public String getlobByAccountNo(String accountNo) throws Exception{
		String lob="";


		Connection con = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		try {
			con = new JdbcTemplate(dataSource).getDataSource().getConnection();
			String qry = " select DERIVE_LOB('"+accountNo+"') from dual";
			ps = con.prepareStatement(qry);
			rs = ps.executeQuery();
			while (rs.next()) {
				lob = rs.getString(1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (con != null) {
				ps.close();
				rs.close();
				con.close();
			}
		}
		return lob;

	}


}


