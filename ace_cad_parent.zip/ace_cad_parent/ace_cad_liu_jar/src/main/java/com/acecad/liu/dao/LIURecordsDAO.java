package com.acecad.liu.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;









/*import com.acecad.liu.model.ActivityLogDetails;
import com.acecad.liu.model.LIUPaginationDetails;*/
import com.acecad.liu.model.LIURecordDetails;

public interface LIURecordsDAO 
     {

	
	public List<String> liuReasonDropdown();
	
	public List<String> liuPayModeDropdown();
	
	public List<String> liuStatusDropdown(); 
	
	public List<String> liuFilenameList();
	
	public List<LIURecordDetails> liuPaymentCurrency(); 
	
	public HashMap<Integer, List<LIURecordDetails>> liuRecordSearchFirstPage(int pageNumber,LIURecordDetails liuRecordDetailsObj ) throws SQLException;

	public LIURecordDetails downloadedFile(LIURecordDetails liuDownloadObj,/*String downloadedFilesPath,*/String extension,String pageNumber) throws SQLException;

	public List<LIURecordDetails> modifiedLIUDetails(List<LIURecordDetails> modifiedAccountsRecords,String userId,String sessionId,String action,int pageNumber);
	
	public List<LIURecordDetails> eCollectAccountMapNeftCheck(List<LIURecordDetails> eCollectAccountMapRecords,String action,int pageNumber); 
	
	public LIURecordDetails validationsFromFX(LIURecordDetails liuInputFxObj);
	
	public String getDateTime();
	
	public HashMap<Integer, List<LIURecordDetails>> liuApsRecordSearchFirstPage(int pageNumber,LIURecordDetails liuRecordDetailsObj) throws SQLException;
	
	public List<String> liuApsFilenameList();
	
	public List<LIURecordDetails> modifiedApsLIUDetails(List<LIURecordDetails> modifiedAccountsRecords,String userId,String sessionId,String action,int pageNumber);
	public LIURecordDetails downloadedFileAps(LIURecordDetails liuDownloadObj,/*String downloadedFilesPath,*/String extension,String pageNumber) throws SQLException;
	public String payCodeDetails(List<LIURecordDetails> modifiedAccountsRecords,String userId,String sessionId,String action,int pageNumber)throws SQLException; 
	public LIURecordDetails validationsFromFXAps(LIURecordDetails liuInputFxObj);
	//public List<LIURecordDetails> modifiedApsLIURecords(List<LIURecordDetails> modifiedAccountsRecords,String userId,String liuFlag);
	public LIURecordDetails modifiedApsLIURecords(List<LIURecordDetails> modifiedAccountsRecords,String userId,String liuFlag);
     }
