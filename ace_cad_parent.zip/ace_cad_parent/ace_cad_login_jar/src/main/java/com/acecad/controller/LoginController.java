package com.acecad.controller;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Cache;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.ldap.CommunicationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Caching;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.session.SessionInformation;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.security.web.authentication.session.SessionAuthenticationException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.airtel.acecad.UtilityJar.ActivityLog;
import com.airtel.login.dao.MenuDao;
import com.airtel.login.model.Menu;
import com.airtel.login.service.LoginService;
import com.airtel.login.service.LoginServiceImpl;
import com.airtel.login.util.ClearCache;
import com.airtel.login.util.CustomExceptionHandler;
import com.airtel.login.util.DatabaseExceptionHandler;
import com.airtel.login.util.LDAPAuthentication;
import com.airtel.login.util.RedirectionPage;
import com.airtel.login.util.SessionAttributes;
import com.airtel.login.util.UserMenu;
import com.airtel.login.util.UserMessages;
import com.airtel.login.model.User;
import com.airtel.login.model.LDAPAuthenticationResult;
import com.googlecode.ehcache.annotations.TriggersRemove;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.validation.Valid;
import org.springframework.cache.annotation.*;

@Controller
public class LoginController {
	public static String s_Admin= "CadAdmin";
	public static String s_User= "User";
	public static String s_vendorSpoc= "Vendor";
	public static String s_CadUser="CadUser";
	public static String s_RM= "RM";
	public static String s_login= "login";
	public static String s_logout= "logout";
	public static String s_alreadyactive= "alreadyactive";
	public static String s_homepage= "Home";
	public static String s_errorpage="Error";
	
	
	
	
	/*@Autowired
	SessionAttributes sessionattribute;*/
	
	private static Logger logger =LogManager.getLogger("loginLogger");
	
	@Value("${LDAP_DOMAIN}")
	private String LDAP_DOMAIN;
	
	@Value("${LDAP_URL}")
	private String LDAP_URL;
	
	@Autowired
	LoginService loginService;
	
	@Autowired
	MenuDao menuDao;
	
	@Autowired
	UserMenu userMenu;
	
	@Autowired
	SessionRegistryImpl sessionRegistry;
	/*@Autowired
	Menu menu;*/
	
	@Autowired
	ActivityLog activityLogDao;
	
	@Autowired
	LDAPAuthentication ldapauthenticate;
	
	/*@Autowired
	User user;*/
/*		@Autowired
		public void setUser(User user) {
		this.user = user;
	}*/

/*		@Autowired
		public void setLoginService(LoginService loginService) {
		this.loginService = loginService;
	}
		*/
		ModelAndView mav;
	//	int SNo=0;
		
	  @RequestMapping(value = "/")
		    public String LoginPage() {
		  logger.info("entered Login Controller");
		  	return "redirect:/authenticate";
		    } 
		@RequestMapping(value = "/authenticate", method = RequestMethod.GET)
		public ModelAndView signInPage(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response,
				@RequestParam(value = "logout", required = false) String logout,
				@RequestParam(value = "session", required = false) String sessionexpired,
				@RequestParam(value = "error", required = false) String error) {
			//User user=new User();
			//LoginService loginService=new LoginServiceImpl();			java.util.Properties props = System.getProperties() ;
			/*String myValue = props.getProperty( "ACE_CAD_HOME1" ) ;
			System.out.println("System Property is:"+System.getProperty("ACE_CAD_HOME"));
			System.out.println("Environment Property is:"+myValue);*/
			System.out.println("session value is:"+sessionexpired);
			System.out.println("Logout value is:"+logout);
			HttpSession ses=request.getSession(false);
			mav=new ModelAndView();
			Long SNo=0l;
			logger.info("session id during login is:"+ses);
			
			if((ses!=null && ses.getAttribute("userid")!=null) && logout==null)
			{
				   logger.info("User already logged in!!!");
					mav.addObject("message", "User could be already logged-in or previous session not closed properly.Either case user need to wait to login again");
					mav.setViewName(s_alreadyactive);
			}
		
		      //logout process
			else if(logout != null)
		      {	
				  
		    	  HttpSession session=request.getSession(true);
		    	  System.out.println("user is:"+session.getAttribute("user"));
		    	  User user=(User)session.getAttribute("user");
		    	  if(user!=null)
		    	  {
		    	  String userid=user.getS_UserID();
		    	  System.out.println("user id is:"+user.getS_UserID());
		    	  try{
		    	  SNo=activityLogDao.insertActivityLog(0l,userid,"User Logout",null,null,null,null,null);
		    	  }
					catch(SQLException e)
					{
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
						mav.addObject("message","DB Connectivity issues");
						mav.setViewName(s_errorpage);
						return mav;
					}
		    	  String status=loginService.userSessionUpdate(user.getS_UserSessionID());
		    	  logger.info("session end-date is updated for session"+user.getS_UserSessionID()+" and updated status is"+status);
		    	  Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		    	  logger.info("Logout process begin");
		    	  logger.info("Authentication Object is :"+auth);
		    	  
		    	  
		    	 
				     if (auth != null){    
				         new SecurityContextLogoutHandler().logout(request, response, auth);
				        logger.info("Authentication Object has been cleared");
				     }
				    
				    
				    
				   /* List<SessionInformation> userSessions = sessionRegistry.getAllSessions(user.getS_UserID(),false);
				    System.out.println("user session is:"+userSessions.size());
			        for (SessionInformation userSession : userSessions){
			            userSession.expireNow();
			            System.out.println("user session expired explicitly");
			        }*/
			        
			        logger.info("User details clear:"+user.isUserObjectClear(user));
			        try{
				    SNo=activityLogDao.insertActivityLog(SNo,userid,"User Logout","success","User logged out",null,null,null);
		    		}
					catch(SQLException e)
					{
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
						mav.addObject("message","DB Connectivity issues");
						mav.setViewName(s_errorpage);
						return mav;
					}
				    request.getSession().invalidate();
				    
				    model.put("userForm", user);
					mav.addObject("message", "Thank you for using Payment Application. You've been logged out successfully.");
					logger.info("User values reset done:"+user.isUserObjectClear(user));
					logger.info("User Logged out successfully!!!");
					mav.setViewName(s_logout);
					return mav;
		    	  }
		    	  else{
		    		  mav.addObject("message", "Please close the window. Thank you.");
		    		  mav.setViewName(s_logout);
		    	  }
		      } 
		      //end of logout process
		      
		      //Session expire/duplicate process
			else if (sessionexpired != null)
		      {	
		    	  
		    	  if(sessionexpired.equalsIgnoreCase("expired"))
		    	  {
		    	  Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		    	 // logger.info("Session expired");
		    	  logger.info("Authentication Object is :"+auth);
		    	 // logger.info("User details clear:"+user.isUserObjectClear(user));
		    	 
				     if (auth != null){    
				         new SecurityContextLogoutHandler().logout(request, response, auth);
				        // user=null;
				    	 //sessionattribute.unMount(request);
				     }
				    request.getSession().invalidate();
				    logger.info("User Logged out successfully!!!");
					mav.addObject("message", "Your Session expired. Request to login again. Thank You !!!!");
					//logger.info("User values reset done:"+user.isUserObjectClear(user));
					 mav.setViewName(s_logout);
					 System.out.println("redirection due to session expiry");
					 return mav;
		    	  }
		    	  else if(sessionexpired.equalsIgnoreCase("alreadyactive"))
		    	  {
		    	  
				    logger.info("User already logged in!!!");
					//mav.addObject("message", "User could be already logged in or previous session not closed properly.Either case user has to wait to login again");
					mav.setViewName(s_alreadyactive);
		    	  }
		    	
		      } 
		      //end of Session expire/duplicate process
			else
			{
		      User user = new User();
		      model.put("userForm", user);
		    // logger.info("User values entered in GET method:"+user.getS_UserID()+","+user.getS_Password());
		      SessionAttributes sessionattribute= new SessionAttributes();
		      mav = new ModelAndView();
		      logger.info("Entered signInPage method with GET request");
		      logger.info("logout value in singinPage:"+logout);
		      logger.info("session value in singinPage:"+sessionexpired);
		      logger.info("session value in singinPage:"+error);
		      mav.setViewName(s_login);
			}
		      return mav;
		}

		 @RequestMapping(value = "/authenticate", method = RequestMethod.POST)
		    public String doLogin(@Valid @ModelAttribute("userForm") User userForm,
		            BindingResult result,HttpServletRequest request,HttpServletResponse response) throws CustomExceptionHandler,SQLException,javax.naming.CommunicationException 
		 {
			// String return_page="";
			 Long SNo=0l;
			// HttpSession session=request.getSession();
			 User user=new User();
			 //LoginService loginService=new LoginServiceImpl();
			//String userid=userForm.getS_UserID();
			 
			try{
			 SNo=activityLogDao.insertActivityLog(0l,userForm.getS_UserID(),"User Login",null,null,null,null,null);
			}
			catch(SQLException e)
			{
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
				return s_errorpage;
			}
			 logger.info("Form values:"+userForm.getS_UserID()+":"+userForm.getS_Password());
			 System.out.println("error:"+result.hasErrors());
		        if (result.hasErrors()) {
		        	try{
		        	SNo=activityLogDao.insertActivityLog(SNo,userForm.getS_UserID(),"User Login","Failure","User Credential Validation failed",null,null,null);
		        }
				catch(SQLException e)
				{
					StringWriter errors= new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					logger.error(errors);
					return s_errorpage;
				}
		            	return s_login;
		        } 
		        else
		        {
		        	
		        	user=loginService.loginAuthentication(userForm, request);
		        	
		        	if(user.getS_UserStatus()==null)
		        	{
		        		try{
		        		SNo=activityLogDao.insertActivityLog(SNo,userForm.getS_UserID(),"User Login","Failure","Database exception",null,null,null);
		        		throw new DatabaseExceptionHandler();
		        	}
					catch(SQLException e)
					{
						StringWriter errors= new StringWriter();
						e.printStackTrace(new PrintWriter(errors));
						logger.error(errors);
						return s_errorpage;
					}
		        		
		        	}
		        	if(user.getS_UserStatus().equalsIgnoreCase("1") && user.getS_UserFlag().equalsIgnoreCase("0"))
		        	{
		        		LDAPAuthenticationResult ldapAuthenticationResultObj=null;
		        	
		        		//LDAP AUTHENTICATION
		        		//LDAPAuthentication ldapauthenticate=new LDAPAuthentication();
		        		logger.info("ldap server details are: "+LDAP_DOMAIN+":"+LDAP_URL);
		        		
		        	/*	try{
		        		ldapAuthenticationResultObj = ldapauthenticate.ldapAuthenticate(
		        				userForm.getS_UserID(), userForm.getS_Password(), LDAP_DOMAIN, LDAP_URL,request,response);
		        		}
		        		catch(SessionAuthenticationException e)
		        		{
		        			StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				logger.error(errors);
		        			logger.info("in SessionAuthenticationException method");
		        		
							return s_alreadyactive;
			        		
		        		}
		        		catch(java.lang.NullPointerException e)
		        		{
		        			StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				logger.error(errors);
		        			logger.info("User already logged in!!!");
		        			
		   				return s_alreadyactive;
		        		}
		        		catch(Exception e)
		        		{
		        			StringWriter errors= new StringWriter();
		    				e.printStackTrace(new PrintWriter(errors));
		    				logger.error(errors);
		        		result.rejectValue("s_Password", "NotEmpty.userForm.Password", "LDAP Connection timed out. Please try again later");
		        		logger.info("LDAP Connectivity issue observed");
		        		return s_login;
		        		
		        		}
		        		logger.info("LDAP Authentication Values are:"+ldapAuthenticationResultObj.toString());
		        		        		
		        
		    			
		        		logger.info("LDAP status is:"+ldapAuthenticationResultObj.getStatus());
		        		
		        		
		        		if(ldapAuthenticationResultObj.getStatus().equalsIgnoreCase("Success"))
		        		{
		        			
		        			//set Username in User object
		        			try{
		        			SNo=activityLogDao.insertActivityLog(SNo,userForm.getS_UserID(),"User Login","Success","User logged in",null,null,null);
		        		}
						catch(SQLException e)
						{
							StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							logger.error(errors);
							return s_errorpage;
						}
		        			user.setS_Uname(ldapAuthenticationResultObj.getUsername());
		        			
		        			//Insert User session details
		        			logger.info("Updating User Success session details as LDAP status is:"+ldapAuthenticationResultObj.getStatus());
		        			loginService.userSessionInsert(user, request, ldapAuthenticationResultObj);
		        			
		        			SessionAttributes sessionattribute=new SessionAttributes();
		        			sessionattribute.setSesssionAttributes(user,request);		        			
		        			logger.info("Session Attributes:"+sessionattribute.toString());
		        			
		        			//Spring Security Authentication/Authorization
		        			try{
		        			Authentication authentication = null;
			    			authentication = new UsernamePasswordAuthenticationToken(
			    					user.getS_UserID(), user.getS_Password(),
			    					AuthorityUtils.createAuthorityList(user.getS_UserRole()));
			    					
			    			SecurityContextHolder.getContext().setAuthentication(authentication);
		        			}
		        			catch(Exception e)
		        			{
		        				StringWriter errors= new StringWriter();
		        				e.printStackTrace(new PrintWriter(errors));
		        				logger.error(errors);
		        			}
		        			
			    			return "redirect:"+RedirectionPage.redirectionTo(user.getS_UserRole());
		        		}
		        		else
		        		{
		        			try{
		        			SNo=activityLogDao.insertActivityLog(SNo,userForm.getS_UserID(),"User Login","Failure","Invalid Credentials",null,null,null);
		        		}
						catch(SQLException e)
						{
							StringWriter errors= new StringWriter();
							e.printStackTrace(new PrintWriter(errors));
							logger.error(errors);
							return s_errorpage;
						}
		        			result.rejectValue("s_Password", "NotEmpty.userForm.Password",ldapAuthenticationResultObj.getFailureReason());
		        			//Insert Failure User session details
		        			logger.info("Updating Failure session details as LDAP status is:"+ldapAuthenticationResultObj.getStatus());
		        			loginService.userSessionInsert(user, request, ldapAuthenticationResultObj);
			        		return s_login;
		        		}
		        	
		        }*/
		        	/*else if(!(user.getS_UserFlag().equalsIgnoreCase("0"))) //'0' is flag return by PROC if success, else non zero value
		        	{
		        		result.rejectValue("s_Password", "NotEmpty.userForm.Password", UserMessages.errorMessage("6"));
		        		logger.info("Error thrown from PROC");
		        		return s_login;
		        	}
		        	
		        	else
		        	{
		        		result.rejectValue("s_Password", "NotEmpty.userForm.Password", UserMessages.errorMessage(user.getS_UserStatus()));
		        		logger.info("Invalid User ID");
		        		return s_login;
		        	}*/
		        	try{
		        		ldapAuthenticationResultObj=new LDAPAuthenticationResult();
		        		ldapAuthenticationResultObj.setUserID(userForm.getS_UserID());
		        		ldapAuthenticationResultObj.setUsername("Default User");
		        		ldapAuthenticationResultObj.setEnabled(true);
		        		ldapAuthenticationResultObj.setAuthenticated(true);
		        		ldapAuthenticationResultObj.setStatus("Success");
		    			ldapAuthenticationResultObj.setFailureReason("Success");
		        		//return s_login;
		    			user.setS_Uname(ldapAuthenticationResultObj.getUsername());
	        			
	        			//Insert User session details
	        			logger.info("Updating User Success session details as LDAP status is:"+ldapAuthenticationResultObj.getStatus());
	        			loginService.userSessionInsert(user, request, ldapAuthenticationResultObj);
	        			
	        			SessionAttributes sessionattribute=new SessionAttributes();
	        			sessionattribute.setSesssionAttributes(user,request);		        			
	        			logger.info("Session Attributes:"+sessionattribute.toString());
	        			
	        			//Spring Security Authentication/Authorization
	        			try{
	        			Authentication authentication = null;
		    			authentication = new UsernamePasswordAuthenticationToken(
		    					user.getS_UserID(), user.getS_Password(),
		    					AuthorityUtils.createAuthorityList(user.getS_UserRole()));
		    					
		    			SecurityContextHolder.getContext().setAuthentication(authentication);
	        			}
	        			catch(Exception e)
	        			{
	        				StringWriter errors= new StringWriter();
	        				e.printStackTrace(new PrintWriter(errors));
	        				logger.error(errors);
	        			}
	        			
		    			return "redirect:"+RedirectionPage.redirectionTo(user.getS_UserRole());
		    		}		        		
		        	catch(Exception e){
		        		e.printStackTrace();
		        		return s_errorpage;
		        	}
		         }
		       }
		        return s_login;
		    }
		 
		 @RequestMapping(value = "/cadadmin")
			public ModelAndView cadAdmin(HttpServletRequest request) {
			 HttpSession session=request.getSession(false);
				logger.info("Start of Cad Admin User");
				if (mav == null) {
					mav = new ModelAndView();
					
				}
				int roleId=Integer.parseInt(session.getAttribute("user_role_id").toString());
				logger.info("User Role ID is :"+roleId);
				/*UserMenu userMenu=new UserMenu();*/
				HashMap<String,List<Menu>> subMenu=userMenu.userMenu(roleId);
				mav.addObject("MenuList", subMenu);
				//modelAndViewObj.setViewName("menuList");
			
				mav.setViewName(s_homepage);
				mav.addObject("user",session.getAttribute("user"));
				//session.setAttribute("user", user);
				session.setAttribute("MenuList", subMenu);
				session.setAttribute("homeurl", "/cadadmin");
				return mav;
			}
		 
		 
		
		 @RequestMapping(value = "/caduser")
			public ModelAndView cadUser(HttpServletRequest request) {
				logger.info("Start of Cad User");
				HttpSession session=request.getSession(false);
				if (mav == null) {
					mav = new ModelAndView();
					
				}
				
				int roleId=Integer.parseInt(session.getAttribute("user_role_id").toString());
				logger.info("User Role ID is :"+roleId);
				/*UserMenu userMenu=new UserMenu();*/
				LinkedHashMap<String,List<Menu>> subMenu=userMenu.userMenu(roleId);
				mav.addObject("MenuList", subMenu);
				//modelAndViewObj.setViewName("menuList");
			
				mav.setViewName(s_homepage);
				mav.addObject("user",session.getAttribute("user"));
				
				//session.setAttribute("user", user);
				session.setAttribute("MenuList", subMenu);
				session.setAttribute("homeurl", "/caduser");
				return mav;
			}
		 
		 @RequestMapping(value = "/wacUser")
			public ModelAndView wacUser(HttpServletRequest request) {
				logger.info("Start of Wac User");
				HttpSession session=request.getSession(false);
				if (mav == null) {
					mav = new ModelAndView();
					
				}
				
				int roleId=Integer.parseInt(session.getAttribute("user_role_id").toString());
				logger.info("User Role ID is :"+roleId);
				/*UserMenu userMenu=new UserMenu();*/
				LinkedHashMap<String,List<Menu>> subMenu=userMenu.userMenu(roleId);
				mav.addObject("MenuList", subMenu);
				//modelAndViewObj.setViewName("menuList");
			
				mav.setViewName(s_homepage);
				mav.addObject("user",session.getAttribute("user"));
				
				//session.setAttribute("user", user);
				session.setAttribute("MenuList", subMenu);
				session.setAttribute("homeurl", "/wacUser");
				return mav;
			}
		 
		 @RequestMapping(value = "/cadspvuser")
			public ModelAndView cadSpvUser(HttpServletRequest request) {
				logger.info("Start of Cad SPV User");
				HttpSession session=request.getSession(false);
				if (mav == null) {
					mav = new ModelAndView();
					
				}
				
				int roleId=Integer.parseInt(session.getAttribute("user_role_id").toString());
				logger.info("User Role ID is :"+roleId);
				/*UserMenu userMenu=new UserMenu();*/
				logger.info("User Role ID is :"+roleId);
				/*UserMenu userMenu=new UserMenu();*/
				HashMap<String,List<Menu>> subMenu=userMenu.userMenu(roleId);
				mav.addObject("MenuList", subMenu);
				//modelAndViewObj.setViewName("menuList");
			
				mav.setViewName(s_homepage);
				mav.addObject("user",session.getAttribute("user"));
				//session.setAttribute("user", user);
				session.setAttribute("MenuList", subMenu);
				session.setAttribute("homeurl", "/cadspvuser");
				return mav;
			}
		 @RequestMapping(value = "/vendorSpv")
			public ModelAndView vendorSPOC(HttpServletRequest request) {
				logger.info("Start of VendorSpoc");
				HttpSession session=request.getSession(false);
				if (mav == null) {
					mav = new ModelAndView();
					
				}
				int roleId=Integer.parseInt(session.getAttribute("user_role_id").toString());
				logger.info("User Role ID is :"+roleId);
				/*UserMenu userMenu=new UserMenu();*/
				HashMap<String,List<Menu>> subMenu=userMenu.userMenu(roleId);
				mav.addObject("MenuList", subMenu);
				//modelAndViewObj.setViewName("menuList");
			
				mav.setViewName(s_homepage);
				mav.addObject("user",session.getAttribute("user"));
				//session.setAttribute("user", user);
				session.setAttribute("MenuList", subMenu);
				session.setAttribute("homeurl", "/vendor");
				return mav;
			}
		 @RequestMapping(value = "/vendoruser")
			public ModelAndView vendorUser(HttpServletRequest request) {
				logger.info("Start of internal");
				HttpSession session=request.getSession(false);
				if (mav == null) {
					mav = new ModelAndView();
					
				}


				int roleId=Integer.parseInt(session.getAttribute("user_role_id").toString());
				logger.info("User Role ID is :"+roleId);
				/*UserMenu userMenu=new UserMenu();*/
				HashMap<String,List<Menu>> subMenu=userMenu.userMenu(roleId);
				mav.addObject("MenuList", subMenu);
				//modelAndViewObj.setViewName("menuList");
			
				mav.setViewName(s_homepage);
				mav.addObject("user",session.getAttribute("user"));
				//session.setAttribute("user", user);
				session.setAttribute("MenuList", subMenu);
				session.setAttribute("homeurl", "/vendoruser");
				return mav;
			}
		 @RequestMapping(value = "/rmuser")
			public ModelAndView rmUser(HttpServletRequest request) {
				logger.info("Start of internal");
				HttpSession session=request.getSession(false);
				if (mav == null) {
					mav = new ModelAndView();
					
				}


				int roleId=Integer.parseInt(session.getAttribute("user_role_id").toString());
				logger.info("User Role ID is :"+roleId);
				/*UserMenu userMenu=new UserMenu();*/
				HashMap<String,List<Menu>> subMenu=userMenu.userMenu(roleId);
				mav.addObject("MenuList", subMenu);
				//modelAndViewObj.setViewName("menuList");
			
				mav.setViewName(s_homepage);
				mav.addObject("user",session.getAttribute("user"));
				//session.setAttribute("user", user);
				session.setAttribute("MenuList", subMenu);
				session.setAttribute("homeurl", "/rmuser");
				return mav;
			}
	 @RequestMapping(value="/session")
		 public ModelAndView sessionTimeOut(HttpServletRequest request, HttpServletResponse response) {
		 Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	     if (auth != null){    
	         new SecurityContextLogoutHandler().logout(request, response, auth);
	     }
	     request.getSession().invalidate();
		 
			 logger.info("Session invalidated");
		     mav.addObject("message", "Your Session has been expired. Please close the brower to access the application again. Thank you!!");
		     logger.info("User session Expired");
		     mav.setViewName("logout");
				//mav.setViewName("login");
		    
	
		 return mav;
		 } 
	 @RequestMapping(value="/ldaperror")
	 public ModelAndView ldapConnectionError(HttpServletRequest request, HttpServletResponse response) {
	 
	     mav.addObject("message", "Oops!! Seems problem connection LDAP. Please try sometime later");
	     logger.info("User session Expired");
	     mav.setViewName("Error");
			//mav.setViewName("login");
	    

	 return mav;
	 } 
	 

			@ExceptionHandler(DatabaseExceptionHandler.class)
			public ModelAndView handleCustomException(HttpServletRequest req,SQLException ex) {
				StringWriter errors = new StringWriter();
				ex.printStackTrace(new PrintWriter(errors));
				logger.info("DatabaseExceptionHandler method invoked:"+errors.toString());
				
				ModelAndView model = new ModelAndView("Error");
				model.addObject("exception", ex);
				 model.addObject("url", req.getRequestURL());
						    
				return model;

			} 
			@ExceptionHandler(javax.naming.CommunicationException.class)
			public ModelAndView handleLDAPConnectionError(HttpServletRequest req, Exception ex) {
				HttpSession session=req.getSession(false);
				User user=(User)session.getAttribute("user");
				String userid=user.getS_UserID();
				StringWriter errors = new StringWriter();
				ex.printStackTrace(new PrintWriter(errors));
				logger.info("LDAP exception handler method invoked:"+errors.toString());
				Long SNo=0l;
				ModelAndView model = new ModelAndView("Error");
				model.addObject("exception", ex);
				 model.addObject("url", req.getRequestURL());
				 try{
				 SNo=activityLogDao.insertActivityLog(SNo,userid,"User Login","Failure","LDAP Connectivity Issues",null,null,null);
			}
			catch(SQLException e)
			{
				StringWriter error= new StringWriter();
				e.printStackTrace(new PrintWriter(error));
				logger.error(error);
				return model;
			}
				return model;

			}
			 @RequestMapping(value="/clearcache")
			 //@TriggersRemove(cacheName = "getMenuDetails")
			 @Caching(evict = {
					 /*@CacheEvict(value="getMenuDetails", allEntries=true),*/
						@CacheEvict(value="getMenuDetails", allEntries=true)		    
					})
			 public ModelAndView clearCache(HttpServletRequest request, HttpServletResponse response) {
				 ModelAndView mav=new ModelAndView();
			/*	 //ClearCache cc=new ClearCache();
				// logger.info("CacheCleared:"+cc.clearCache());
				 CacheManager manager = CacheManager.getInstance();
				 String[] caches= manager.getCacheNames();
				
				 for (String s: caches) {           
				        //Do your stuff here
				        System.out.println("caches are:"+s); 
				        
				    }
				 
				 Ehcache cache = manager.getEhcache("getMenuDetails");
				 Map<Object, Element> mapElements = cache.getAll(cache.getKeys()); 
				 cache.flush();
				 cache.removeAll();
				 manager.clearAll();
				 
				 Iterator<Map.Entry<Object, Element>> entries = System.out.println(cache.getMemoryStoreSize());
				 System.out.println(cache.getSize());
				 System.out.println(cache.isKeyInCache("7"));
				 System.out.println(cache.isElementInMemory("7"));
				 
				 while (entries.hasNext()) {
				     Map.Entry<Object, Element> entry = entries.next();
				     System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
				 }
				 
				 List cachelist =cache.getKeys();
				 System.out.println("keys size is:"+cachelist.size());
				 for(int i=0;i<cachelist.size();i++)
					 System.out.println("cache keys are:"+cachelist.get(i));
				 for (String s: caches) {           
				        //Do your stuff here
				        System.out.println("caches post flush:"+s); 
				    }
				logger.info(CacheManager.getInstance().getCache("getMenuDetails"));*/
				 mav.addObject("message", "Cache has been cleared");
			     logger.info("Cache cleared");
			     mav.setViewName("logout");
					//mav.setViewName("login");
			    
		
			 return mav;
			 } 
			 
			 @ExceptionHandler(java.sql.SQLException.class)
				public ModelAndView handleSQLException(HttpServletRequest req,java.sql.SQLException exception) {
					
					exception.printStackTrace();
					HttpSession session=req.getSession(false);
					/*Had to comment as DB errors couldn't be handled as it fails with below code
					 * User user=(User)session.getAttribute("user");
					String userid=user.getS_UserID();
					SNo=activityLogDao.insertActivityLog(SNo,userid,"User Login","Failure","Seems Database/LDAP issue");*/
				//	ModelAndView model = new ModelAndView("Error");
					logger.info(exception.getCause());
					logger.info(exception.getLocalizedMessage());
					 ModelAndView mav = new ModelAndView();
					    mav.addObject("exception", exception);
					    mav.addObject("url", req.getRequestURL());
					    mav.setViewName("Error");
					return mav;

				} 
			@ExceptionHandler(Exception.class)
			public ModelAndView handleAllException(HttpServletRequest req,Exception exception) {
				
				exception.printStackTrace();
				HttpSession session=req.getSession(false);
				/*Had to comment as DB errors couldn't be handled as it fails with below code
				 * User user=(User)session.getAttribute("user");
				String userid=user.getS_UserID();
				SNo=activityLogDao.insertActivityLog(SNo,userid,"User Login","Failure","Seems Database/LDAP issue");*/
			//	ModelAndView model = new ModelAndView("Error");
				logger.info(exception.getCause());
				logger.info(exception.getLocalizedMessage());
				 ModelAndView mav = new ModelAndView();
				    mav.addObject("exception", exception);
				    mav.addObject("url", req.getRequestURL());
				    mav.setViewName("Error");
				return mav;

			} 
			
			
			 @RequestMapping(value = "/cadbulk")
				public ModelAndView cadBulk(HttpServletRequest request) {
					logger.info("Start of Cad User");
					HttpSession session=request.getSession(false);
					if (mav == null) {
						mav = new ModelAndView();
						
					}
					
					int roleId=Integer.parseInt(session.getAttribute("user_role_id").toString());
					logger.info("User Role ID is :"+roleId);
					/*UserMenu userMenu=new UserMenu();*/
					LinkedHashMap<String,List<Menu>> subMenu=userMenu.userMenu(roleId);
					mav.addObject("MenuList", subMenu);
					//modelAndViewObj.setViewName("menuList");
				
					mav.setViewName(s_homepage);
					mav.addObject("user",session.getAttribute("user"));
					
					//session.setAttribute("user", user);
					session.setAttribute("MenuList", subMenu);
					session.setAttribute("homeurl", "/cadbulk");
					return mav;
				}
	            //Added by APS//@RequestMapping(value = "/cadbin")
				public ModelAndView cadbinUser(HttpServletRequest request) {
					logger.info("Start of cadbin");
					HttpSession session = request.getSession(false);
					if (mav == null) {
						mav = new ModelAndView();

					}

					int roleId = Integer.parseInt(session.getAttribute("user_role_id").toString());
					logger.info("User Role ID is :" + roleId);
					/* UserMenu userMenu=new UserMenu(); */
					HashMap<String, List<Menu>> subMenu = userMenu.userMenu(roleId);
					mav.addObject("MenuList", subMenu);
					// modelAndViewObj.setViewName("menuList");

					mav.setViewName(s_homepage);
					mav.addObject("user", session.getAttribute("user"));
					// session.setAttribute("user", user);
					session.setAttribute("MenuList", subMenu);
					return mav;
				}

				@RequestMapping(value = "/ipbin")
				public ModelAndView ipbinUser(HttpServletRequest request) {
					logger.info("Start of ipbin");
					HttpSession session = request.getSession(false);
					if (mav == null) {
						mav = new ModelAndView();

					}

					int roleId = Integer.parseInt(session.getAttribute("user_role_id").toString());
					logger.info("User Role ID is :" + roleId);
					/* UserMenu userMenu=new UserMenu(); */
					HashMap<String, List<Menu>> subMenu = userMenu.userMenu(roleId);
					mav.addObject("MenuList", subMenu);
					// modelAndViewObj.setViewName("menuList");

					mav.setViewName(s_homepage);
					mav.addObject("user", session.getAttribute("user"));
					// session.setAttribute("user", user);
					session.setAttribute("MenuList", subMenu);
					return mav;
				}

				@RequestMapping(value = " /cashbin")
				public ModelAndView cashbinUser(HttpServletRequest request) {
					logger.info("Start of ipbin");
					HttpSession session = request.getSession(false);
					if (mav == null) {
						mav = new ModelAndView();

					}

					int roleId = Integer.parseInt(session.getAttribute("user_role_id").toString());
					logger.info("User Role ID is :" + roleId);
					/* UserMenu userMenu=new UserMenu(); */
					HashMap<String, List<Menu>> subMenu = userMenu.userMenu(roleId);
					mav.addObject("MenuList", subMenu);
					// modelAndViewObj.setViewName("menuList");

					mav.setViewName(s_homepage);
					mav.addObject("user", session.getAttribute("user"));
					// session.setAttribute("user", user);
					session.setAttribute("MenuList", subMenu);
					return mav;
				}

				@RequestMapping(value = " /dispatchbin")
				public ModelAndView dispatchbinUser(HttpServletRequest request) {
					logger.info("Start of ipbin");
					HttpSession session = request.getSession(false);
					if (mav == null) {
						mav = new ModelAndView();

					}

					int roleId = Integer.parseInt(session.getAttribute("user_role_id").toString());
					logger.info("User Role ID is :" + roleId);
					/* UserMenu userMenu=new UserMenu(); */
					HashMap<String, List<Menu>> subMenu = userMenu.userMenu(roleId);
					mav.addObject("MenuList", subMenu);
					// modelAndViewObj.setViewName("menuList");

					mav.setViewName(s_homepage);
					mav.addObject("user", session.getAttribute("user"));
					// session.setAttribute("user", user);
					session.setAttribute("MenuList", subMenu);
					return mav;
				}

				@RequestMapping(value = " /closebin")
				public ModelAndView closebinUser(HttpServletRequest request) {
					logger.info("Start of ipbin");
					HttpSession session = request.getSession(false);
					if (mav == null) {
						mav = new ModelAndView();

					}

					int roleId = Integer.parseInt(session.getAttribute("user_role_id").toString());
					logger.info("User Role ID is :" + roleId);
					/* UserMenu userMenu=new UserMenu(); */
					HashMap<String, List<Menu>> subMenu = userMenu.userMenu(roleId);
					mav.addObject("MenuList", subMenu);
					// modelAndViewObj.setViewName("menuList");

					mav.setViewName(s_homepage);
					mav.addObject("user", session.getAttribute("user"));
					// session.setAttribute("user", user);
					session.setAttribute("MenuList", subMenu);
					return mav;
				}

				@RequestMapping(value = " /cadleadbin")
				public ModelAndView cadleadBin(HttpServletRequest request) {
					logger.info("Start of ipbin");
					HttpSession session = request.getSession(false);
					if (mav == null) {
						mav = new ModelAndView();

					}

					int roleId = Integer.parseInt(session.getAttribute("user_role_id").toString());
					String subRoleId = (String) session.getAttribute("secondaryLogin");
					System.out.println("Secondary Login is............" + subRoleId);
					logger.info("User Role ID is :" + roleId);
					/* UserMenu userMenu=new UserMenu(); */
					HashMap<String, List<Menu>> subMenu = userMenu.userMenu(roleId);
					mav.addObject("MenuList", subMenu);
					// modelAndViewObj.setViewName("menuList");

					mav.setViewName(s_homepage);
					mav.addObject("user", session.getAttribute("user"));
					// session.setAttribute("user", user);
					session.setAttribute("MenuList", subMenu);
					return mav;
				}

				@RequestMapping(value = "/masterRefund")
				public ModelAndView masterRefundUser(HttpServletRequest request) {
					logger.info("Start of ipbin");
					HttpSession session = request.getSession(false);
					if (mav == null) {
						mav = new ModelAndView();

					}

					int roleId = Integer.parseInt(session.getAttribute("user_role_id").toString());
					logger.info("User Role ID is :" + roleId);
					/* UserMenu userMenu=new UserMenu(); */
					HashMap<String, List<Menu>> subMenu = userMenu.userMenu(roleId);
					mav.addObject("MenuList", subMenu);
					// modelAndViewObj.setViewName("menuList");

					mav.setViewName(s_homepage);
					mav.addObject("user", session.getAttribute("user"));
					// session.setAttribute("user", user);
					session.setAttribute("MenuList", subMenu);
					return mav;
				}
				/**************************Channel Island Users Start*************************/
				
				 @RequestMapping(value = "/ciCadduser")
					public ModelAndView cIcadUser(HttpServletRequest request) {
						logger.info("Start of channel Cad User");
						HttpSession session=request.getSession(false);
						if (mav == null) {
							mav = new ModelAndView();
							
						}
						
						int roleId=Integer.parseInt(session.getAttribute("user_role_id").toString());
						logger.info("User Role ID is :"+roleId);
						/*UserMenu userMenu=new UserMenu();*/
						LinkedHashMap<String,List<Menu>> subMenu=userMenu.userMenu(roleId);
						mav.addObject("MenuList", subMenu);
						//modelAndViewObj.setViewName("menuList");
					
						mav.setViewName(s_homepage);
						mav.addObject("user",session.getAttribute("user"));
						
						//session.setAttribute("user", user);
						session.setAttribute("MenuList", subMenu);
						session.setAttribute("homeurl", "/ciCadduser");
						return mav;
					}
				 @RequestMapping(value = "/cispvuser")
				 public ModelAndView cISpvUser(HttpServletRequest request) {
						logger.info("Start of Channel Cad SPV User");
						HttpSession session=request.getSession(false);
						if (mav == null) {
							mav = new ModelAndView();
							
						}
						
						int roleId=Integer.parseInt(session.getAttribute("user_role_id").toString());
						logger.info("User Role ID is :"+roleId);
						/*UserMenu userMenu=new UserMenu();*/
						logger.info("User Role ID is :"+roleId);
						/*UserMenu userMenu=new UserMenu();*/
						HashMap<String,List<Menu>> subMenu=userMenu.userMenu(roleId);
						mav.addObject("MenuList", subMenu);
						//modelAndViewObj.setViewName("menuList");
					
						mav.setViewName(s_homepage);
						mav.addObject("user",session.getAttribute("user"));
						//session.setAttribute("user", user);
						session.setAttribute("MenuList", subMenu);
						session.setAttribute("homeurl", "/cispvuser");
						return mav;
					}
				 
				 
				 @RequestMapping(value = "/viewUser")
					public ModelAndView viewUser(HttpServletRequest request) {
						logger.info("Start of Cad User");
						HttpSession session=request.getSession(false);
						if (mav == null) {
							mav = new ModelAndView();
							
						}
						
						int roleId=Integer.parseInt(session.getAttribute("user_role_id").toString());
						logger.info("User Role ID is :"+roleId);
						/*UserMenu userMenu=new UserMenu();*/
						LinkedHashMap<String,List<Menu>> subMenu=userMenu.userMenu(roleId);
						mav.addObject("MenuList", subMenu);
						//modelAndViewObj.setViewName("menuList");
					
						mav.setViewName(s_homepage);
						mav.addObject("user",session.getAttribute("user"));
						
						//session.setAttribute("user", user);
						session.setAttribute("MenuList", subMenu);
						session.setAttribute("homeurl", "/viewUser");
						return mav;
					}
				 
				 /**************************Channel Island Users END*************************/
				// **********************************************************Added by APS
				// TEAM
				// End**********************************************************************//
}