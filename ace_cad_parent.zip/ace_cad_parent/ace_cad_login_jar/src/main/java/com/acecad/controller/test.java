package com.acecad.controller;

public class test {

	
	public static void main(String[] args) {
		abc();
	}
	
	
	static String abc(){
		
		String a="xyz";
		String b="abc";
		String c="hello";
		System.out.println("sdfs"+a);
		a.equalsIgnoreCase(b);
				System.out.println("x"+a);
		return a;
		
	}
}

