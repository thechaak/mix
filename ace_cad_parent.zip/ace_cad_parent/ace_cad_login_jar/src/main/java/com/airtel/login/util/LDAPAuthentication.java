package com.airtel.login.util;

import java.io.PrintWriter;
import java.io.StringWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.AuthenticationException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.ldap.authentication.ad.ActiveDirectoryLdapAuthenticationProvider;
import org.springframework.security.web.authentication.session.SessionAuthenticationException;
import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;

import com.airtel.login.model.LDAPAuthenticationResult;

public class LDAPAuthentication {
	
	private static Logger logger = LogManager
			.getLogger("loginLogger");

	@Autowired
	SessionAuthenticationStrategy sessionAuthenticationStrategy;
	
	@Autowired
	SessionRegistryImpl sessionRegistry;
	
	public LDAPAuthenticationResult ldapAuthenticate(String id,String password, String LDAP_DOMAIN, String LDAP_URL, HttpServletRequest httpReq, HttpServletResponse httpResp) throws SessionAuthenticationException {
		logger.info("Start of ldapAuthenticate");
		Throwable cause=null;
		String ldap_ErrorCode="";
		String errorMessage = null;
		Authentication result;
		
		
		LDAPAuthenticationResult ldapAuthenticationResultObj = new LDAPAuthenticationResult();
		ldapAuthenticationResultObj.setUserID(id);
		try {
			errorMessage = "";
			ActiveDirectoryLdapAuthenticationProvider authProvider = new ActiveDirectoryLdapAuthenticationProvider(
					LDAP_DOMAIN, LDAP_URL);
			//authProvider.setSearchFilter("A1W9V4JY");
			
			UsernamePasswordAuthenticationToken request = new UsernamePasswordAuthenticationToken(id, password);
			//System.out.println("getCredentials are:"+request.getCredentials().toString());
			logger.info(" LDAP Authenitcation Request :"+request);
			result = authProvider.authenticate(request);
			//result=authProvider.
			SecurityContextHolder.getContext().setAuthentication(result);
			logger.info("result is:"+result.getPrincipal().toString());
			logger.info("request is:"+httpReq.toString());
			logger.info("response is:"+httpResp.toString());
	
			
			//if(cause)
			
			//to check concurrent user login
			sessionAuthenticationStrategy.onAuthentication(result, httpReq, httpResp);
			
		/*	
		 * To check the active users in SessionRegistry
		 * List<Object> usersLoggedIn=sessionRegistry.getAllPrincipals();
			
			for(Object userLogIn:usersLoggedIn)
			{
				//User user=(User)userLogIn;
			System.out.println("User details from session Registry are:"+userLogIn);
			//System.out.println("User from sessionregistry:"+sessionRegistry.);
			//System.out.println("Useres Logged in are"+user.getS_UserSessionID());
			}*/
			/*NamingException exception= new NamingException();
			 cause=new ActiveDirectoryAuthenticationException(Integer.toHexString(8754632),exception.getMessage(),exception);*/
			logger.info("getCredentials are:"+cause);
			logger.info(" LDAP Authenitcation Result :"+result);
			String res = result.toString();
			
			String[] requestObj = res.split(";");
			for (int i = 0; i < requestObj.length; i++) {
				
				if (requestObj[i] != null
						&& requestObj[i].toUpperCase().contains(
								"CN=".toUpperCase())) {
					String[] literals = requestObj[i].split(":");
					if (literals[4] != null
							&& literals[4].toUpperCase().contains("=")) {
						logger.info("UserName is:"+literals[4].substring(literals[4].indexOf("=")+1,literals[4].indexOf(",")));
						String username=literals[4].substring(literals[4].indexOf("=")+1,literals[4].indexOf(","));
						ldapAuthenticationResultObj.setUsername(username);
						//ldapAuthenticationResultObj.setEnabled(isEnabled);
					}
				}
				
				if (requestObj[i] != null
						&& requestObj[i].toUpperCase().contains(
								"Enabled".toUpperCase())) {
					String[] literals = requestObj[i].split(":");
					if (literals[1] != null
							&& literals[1].toUpperCase().contains("TRUE")) {
						boolean isEnabled = true;
						ldapAuthenticationResultObj.setEnabled(isEnabled);
					}
				}
				if (requestObj[i] != null
						&& requestObj[i].toUpperCase().contains(
								"AccountNonExpired".toUpperCase())) {
					String[] literals = requestObj[i].split(":");
					if (literals[1] != null
							&& literals[1].toUpperCase().contains("TRUE")) {
						boolean isEnabled = true;
						ldapAuthenticationResultObj
								.setAccountNonExpired(isEnabled);
					}
				}
				if (requestObj[i] != null
						&& requestObj[i].toUpperCase().contains(
								"CredentialsNonExpired".toUpperCase())) {
					String[] literals = requestObj[i].split(":");
					if (literals[1] != null
							&& literals[1].toUpperCase().contains("TRUE")) {
						boolean isEnabled = true;
						ldapAuthenticationResultObj
								.setCredentailsNonExpired(isEnabled);
					}
				}
				if (requestObj[i] != null
						&& requestObj[i].toUpperCase().contains(
								"AccountNonLocked".toUpperCase())) {
					String[] literals = requestObj[i].split(":");
					if (literals[1] != null
							&& literals[1].toUpperCase().contains("TRUE")) {
						boolean isEnabled = true;
						ldapAuthenticationResultObj
								.setAccountNonLocked(isEnabled);
					}
				}
				if (requestObj[i] != null
						&& requestObj[i].toUpperCase().contains(
								"Authenticated".toUpperCase())) {
					String[] literals = requestObj[i].split(":");
					if (literals[1] != null
							&& literals[1].toUpperCase().contains("TRUE")) {
						boolean isEnabled = true;
						ldapAuthenticationResultObj.setAuthenticated(isEnabled);
					}
				}
			}
			ldapAuthenticationResultObj.setStatus("Success");
			ldapAuthenticationResultObj.setFailureReason("Success");
			SecurityContextHolder.getContext().setAuthentication(result);
			
			
			
			
			
		}
		
/*		
		catch (UsernameNotFoundException e ) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
			 logger.info(e.getLocalizedMessage());
			errorMessage = e.getLocalizedMessage();
			
			
			ActiveDirectoryLdapAuthenticationProvider authProvider = new ActiveDirectoryLdapAuthenticationProvider(
					"airtelworld.com", LDAP_URL);
			//authProvider.setSearchFilter("A1W9V4JY");
			
			UsernamePasswordAuthenticationToken request = new UsernamePasswordAuthenticationToken(id, password);
			//System.out.println("getCredentials are:"+request.getCredentials().toString());
			logger.info(" LDAP Authenitcation Request :"+request);
			result = authProvider.authenticate(request);
			//result=authProvider.
			SecurityContextHolder.getContext().setAuthentication(result);
			logger.info("result is:"+result.getPrincipal().toString());
			logger.info("request is:"+httpReq.toString());
			logger.info("response is:"+httpResp.toString());
	
			
			
			
			cause=e.getCause();
			String error=cause.getLocalizedMessage();
			//System.out.println("error message is:"+error.substring(error.indexOf("data")+5, error.indexOf("data")+8));
			ldap_ErrorCode=error.substring(error.indexOf("data")+5, error.indexOf("data")+8);
			ldapAuthenticationResultObj.setStatus("Failure");
			ldapAuthenticationResultObj.setFailureReason(LDAPErrorMessages.ldapErrorMessage(ldap_ErrorCode));
			ldapAuthenticationResultObj.setFailureCode(ldap_ErrorCode);
		}*/
		
		
		
		catch (AuthenticationException e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
			errorMessage = e.getLocalizedMessage();
			logger.info("error message is:"+e.getRootCause());
			logger.info(e.getLocalizedMessage());
			ldapAuthenticationResultObj.setStatus("Failure");
			ldapAuthenticationResultObj.setFailureReason(errorMessage);
		}
		catch (Exception e) {
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
			 logger.info(e.getLocalizedMessage());
			errorMessage = e.getLocalizedMessage();
			
			cause=e.getCause();
			String error=cause.getLocalizedMessage();
			//System.out.println("error message is:"+error.substring(error.indexOf("data")+5, error.indexOf("data")+8));
			ldap_ErrorCode=error.substring(error.indexOf("data")+5, error.indexOf("data")+8);
			ldapAuthenticationResultObj.setStatus("Failure");
			ldapAuthenticationResultObj.setFailureReason(LDAPErrorMessages.ldapErrorMessage(ldap_ErrorCode));
			ldapAuthenticationResultObj.setFailureCode(ldap_ErrorCode);
		}
		logger.info("End of ldapAuthenticate");
		return ldapAuthenticationResultObj;
	}
	
}
