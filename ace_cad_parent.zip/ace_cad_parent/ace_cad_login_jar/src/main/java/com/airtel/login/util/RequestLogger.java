package com.airtel.login.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.omg.stub.java.rmi._Remote_Stub;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

@Component
public class RequestLogger extends HandlerInterceptorAdapter {
     
	private static Logger logger =LogManager.getLogger("loginLogger");
     
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
    	
    	String requestURI=request.getRequestURI();
    	StringBuffer requestUrl=request.getRequestURL();
    	String contextpath=request.getContextPath();
    	String apsUrl="https://sit.sso.airtel.com/aps";
    	logger.info("requestUrl is------>>>>>>>>>>>>>"+requestUrl+"contextpath is ---------------->>>>>>>>>>>"+contextpath);
    	
    /*	 if (requestUrl.equals(apsUrl)) {
          logger.info("request urllllllllllllll with /aps............");
             
         }
    	 else{
    		 //  String toReplace = requestURI.substring(requestURI.indexOf("/Dir_My_App"), requestURI.lastIndexOf("/") + 1);
    		 
    		 String newURI = requestUrl.insert(26, "aps").toString();
    		 logger.info("new url is ---------------........................"+newURI);
            //  request.getRequestDispatcher(newURI).forward(request, response);
    		 
    		 logger.info("request url with /............");
    		 
    	 }*/
            logger.info(request.getMethod() + " " + request.getServletPath() + " received");
         return true;
    }
    
    
    @Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
    	logger.info("request in post handle"+request.getContextPath());
		System.out.println("Post-handle");
	}
	
	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		
		
		System.out.println("After completion handle");
	}
    
}