package com.airtel.login.util;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

//Done by APS Team
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
//import org.apache.log4j.Logger;
//Addition by APS Team Ends here

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;

import com.acecad.controller.LoginController;
import com.airtel.login.model.User;

public class SessionAttributes {
	
	@Autowired
	User user;
	public HttpSession session=null;
	//Done by APS Team
//	private Logger logger = Logger.getLogger(SessionAttributes.class);
	private static Logger logger =LogManager.getLogger(SessionAttributes.class);

	public  void setSesssionAttributes(User user,HttpServletRequest request)
	{
		
		session=request.getSession(true);
		session.setAttribute("userid", user.getS_UserID());
		session.setAttribute("sessionid", user.getS_UserSessionID());
		session.setAttribute("last_successful_login", user.getS_LastSuccessLogin());
		session.setAttribute("last_unsuccessful_login", user.getS_LastUnSuccessLogin());
		session.setAttribute("uname", user.getS_Uname());
		session.setAttribute("user_role", user.getS_UserRole());
		session.setAttribute("user_role_id", user.getS_User_Role_Id());
		session.setAttribute("user", user);
		session.setAttribute("email", user.getS_EmailId());
		
		//System.out.println("useremailid:"+session.getAttribute("email"));
		
	} 
	
	public String  toString()

	{
		return 	"UserSessionID:"+session.getAttribute("sessionid")+"; UserID:"+session.getAttribute("userid")
				+";LastSuccessLogin:"+session.getAttribute("last_successful_login")+";LastUnsuccessLogin:"+session.getAttribute("last_unsuccessful_login")
				+";UserName:"+session.getAttribute("uname")+";UserRole:"+session.getAttribute("user_role")+";UserRoleID:"+session.getAttribute("user_role_id"); 
	
	}
	
	public void unMount(HttpServletRequest request) {
		logger.info("Session and Spring session are going to be unMounted");
		request.getSession().invalidate();
		Authentication authentication = null;
		AuthorityUtils.authorityListToSet(AuthorityUtils.NO_AUTHORITIES);
		SecurityContextHolder.getContext().setAuthentication(authentication);
		logger.info("Session and Spring session have been unMounted");
	}
}
