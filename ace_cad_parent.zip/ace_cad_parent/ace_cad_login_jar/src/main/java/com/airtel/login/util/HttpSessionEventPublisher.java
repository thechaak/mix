package com.airtel.login.util;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.security.web.context.support.SecurityWebApplicationContextUtils;
import org.springframework.security.web.session.HttpSessionCreatedEvent;

public class HttpSessionEventPublisher implements HttpSessionListener {
	private static Logger logger =LogManager.getLogger("loginLogger");
	
	ApplicationContext getContext(ServletContext servletContext) { 
	return SecurityWebApplicationContextUtils.findRequiredWebApplicationContext(servletContext); 
	} 

	
	@Override
	public void sessionCreated(HttpSessionEvent event) {
		HttpSessionCreatedEvent e = new HttpSessionCreatedEvent(event.getSession()); 
		logger.info("HttpSessionEventPublisher-sessino created"); 
		/*if (log.isDebugEnabled()) { 
		log.debug("Publishing event: " + e); 
		} */
		getContext(event.getSession().getServletContext()).publishEvent(e); 


	}

	@Override
	public void sessionDestroyed(HttpSessionEvent event) {
		HttpSessionCreatedEvent e = new HttpSessionCreatedEvent(event.getSession()); 
		logger.info("HttpSessionEventPublisher-session destroyed"); 
		/*if (log.isDebugEnabled()) { 
		log.debug("Publishing event: " + e); 
		} */
		getContext(event.getSession().getServletContext()).publishEvent(e); 


	}

}
