package com.airtel.login.model;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;

public class User {
	@NotEmpty(message="{NotEmpty.userForm.userID}")
	@Length(min=8,message="{Length.userForm.userID}")
	private String s_UserID;
	
	@NotEmpty(message="{NotEmpty.userForm.Password}")
	private String s_Password;
	private String s_IPAddress;
	private String s_UserSessionID;
	private String s_UserStatus;
	private String s_UserRole;
	private String s_Uname;
	private String s_LastSuccessLogin;
	private String s_LastUnSuccessLogin;
	private String s_UserFlag;
	private String s_User_Role_Id;
	private String s_EmailId;
	
	public String getS_EmailId() {
		return s_EmailId;
	}
	public void setS_EmailId(String s_EmailId) {
		this.s_EmailId = s_EmailId;
	}
	public String getS_User_Role_Id() {
		return s_User_Role_Id;
	}
	public void setS_User_Role_Id(String s_User_Role_Id) {
		this.s_User_Role_Id = s_User_Role_Id;
	}
	public String getS_Uname() {
		return s_Uname;
	}
	public void setS_Uname(String s_Uname) {
		this.s_Uname = s_Uname;
	}
	public String getS_LastSuccessLogin() {
		return s_LastSuccessLogin;
	}
	public void setS_LastSuccessLogin(String s_LastSuccessLogin) {
		this.s_LastSuccessLogin = s_LastSuccessLogin;
	}
	public String getS_LastUnSuccessLogin() {
		return s_LastUnSuccessLogin;
	}
	public void setS_LastUnSuccessLogin(String s_LastUnSuccessLogin) {
		this.s_LastUnSuccessLogin = s_LastUnSuccessLogin;
	}

	public String getS_UserFlag() {
		return s_UserFlag;
	}
	public void setS_UserFlag(String s_UserFlag) {
		this.s_UserFlag = s_UserFlag;
	}
	public String getS_UserStatus() {
		return s_UserStatus;
	}
	public void setS_UserStatus(String s_UserStatus) {
		this.s_UserStatus = s_UserStatus;
	}
	public String getS_UserRole() {
		return s_UserRole;
	}
	public void setS_UserRole(String s_UserRole) {
		this.s_UserRole = s_UserRole;
	}
	public String getS_UserSessionID() {
		return s_UserSessionID;
	}
	public void setS_UserSessionID(String s_UserSession) {
		this.s_UserSessionID = s_UserSession;
	}
	public String getS_IPAddress() {
		return s_IPAddress;
	}
	public void setS_IPAddress(String s_IPAddress) {
		this.s_IPAddress = s_IPAddress;
	}
	public String getS_MACID() {
		return s_MACID;
	}
	public void setS_MACID(String s_MACID) {
		this.s_MACID = s_MACID;
	}
	private String s_MACID;
	public String getS_UserID() {
		return s_UserID;
	}
	public void setS_UserID(String s_UserID) {
		this.s_UserID = s_UserID;
	}
	public String getS_Password() {
		return s_Password;
	}
	public void setS_Password(String s_Password) {
		this.s_Password = s_Password;
	}
	
	public String toString(){
	  
		return "Userid:"+getS_UserID()+";UserRole:"+getS_UserRole()+";UserStatus:"+getS_UserStatus()
				+";IP:"+getS_IPAddress()+";MAC:"+getS_MACID()+";UserSession:"+getS_UserSessionID()+";Flag:"+getS_UserFlag()
				+";Uname:"+getS_Uname()+";LastSuccessLogin:"+getS_LastSuccessLogin()+";LastUnsuccessLogin:"+getS_LastUnSuccessLogin();
	}
	public boolean isUserObjectClear(User user)
	{
		user.setS_Uname(null);
		user.setS_Password(null);
		user.setS_IPAddress(null);
		user.setS_LastSuccessLogin(null);
		user.setS_LastUnSuccessLogin(null);
		user.setS_MACID(null);
		user.setS_UserFlag(null);
		user.setS_UserID(null);
		user.setS_UserRole(null);
		user.setS_UserSessionID(null);
		user.setS_UserStatus(null);
		
		return true;
	}
	@Override
	public boolean equals(Object object) {
		boolean result = false;
		if (object == null || object.getClass() != getClass()) {
			result = false;
		} else {
			User user = (User) object;
			if (this.s_UserID == user.s_UserID && this.s_Password==user.s_Password) {
				result = true;
			}
		}
		return result;
	}

	// just omitted null checks
	@Override
	public int hashCode() {
		int hash = 3;
		hash = 7 * hash + this.s_UserID.hashCode();
		hash = 7 * hash + this.s_Password.hashCode();
		return hash;
	}
	
}
