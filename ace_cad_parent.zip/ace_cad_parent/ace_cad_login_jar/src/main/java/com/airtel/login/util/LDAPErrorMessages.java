package com.airtel.login.util;

import java.util.HashMap;

public class LDAPErrorMessages {

public static String ldapErrorMessage(String code){
		
		HashMap errorMsg= new HashMap();
		
		errorMsg.put("525", "User not found");
		errorMsg.put("52e", "Invalid credentials");
		errorMsg.put("530", "Not permitted to logon at this time");
		errorMsg.put("531", "Not permitted to logon at this workstation");
		errorMsg.put("532", "Password expired");
		errorMsg.put("533", "Account disabled");
		errorMsg.put("701", "Account expired");
		errorMsg.put("773", "User must reset password");
		errorMsg.put("775", "User account locked");
		
	
		return errorMsg.get(code).toString();
	}
}
