
package com.airtel.login.util;

public class CustomExceptionHandler extends RuntimeException {
	private static final long serialVersionUID = 1L;

	private String errCode;
	public String getErrCode() {
		return errCode;
	}

	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}

	private String errMsg;

	//getter and setter methods

	public CustomExceptionHandler(String errMsg) {
		this.errMsg = errMsg;
	}

}