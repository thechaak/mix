package com.airtel.login.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;
import org.apache.logging.log4j.LogManager;






import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.jdbc.core.JdbcTemplate;








import com.acecad.controller.LoginController;
import com.airtel.login.model.Menu;


public class MenuDao {
	private static Logger logger =LogManager.getLogger("loginLogger");
	
	@Autowired
	  DataSource dataSource;
		final long startTime = System.nanoTime();
		
		

		public MenuDao()
		{
			
		}
		public MenuDao(DataSource dataSource) {
			this.dataSource = dataSource;
		}
	
		
	public List<Menu> getMenuDetails(int roleId) {
		// TODO Auto-generated method stub
		final String procedureCall = "{call AIRTL_MENU_DETAILS.AIRTL_MENU_ROLEID(?,?)}";
		System.out.println("in MenuDao.java");
		Connection connection = null;
	  String headerStatus=null;
	  ResultSet menuDetails=null;
	  List<Menu> menuList=new ArrayList<Menu>();
		try {

			// Get Connection instance from dataSource
			System.out.println("connect"+ "ion:" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			
			
			
			CallableStatement callableStatement = connection
					.prepareCall(procedureCall);
			
			callableStatement.setInt(1,roleId);
			
			callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
			
			callableStatement.executeUpdate();
		
			menuDetails=(ResultSet) callableStatement.getObject(2);
			while (menuDetails.next()) {
				Menu menuDetails1=new Menu();
			
				menuDetails1.setMenuId(menuDetails.getInt(1));
				menuDetails1.setMenuName(menuDetails.getString(2));
				logger.info("Menu is:"+menuDetails1.getMenuName());
			
				menuList.add(menuDetails1);
				
			}
			
		} catch (SQLException e) {
			logger.info(e.getLocalizedMessage());
			e.printStackTrace();

		} finally {

			if (connection != null)
				try {
					connection.close();
				} catch (SQLException e) {
					logger.info(e.getLocalizedMessage());
					e.printStackTrace();
				}
		}
		return menuList;
	}
	public List<Menu> getSubMenuDetails(int roleId, int menuId,String menuName) {
		// TODO Auto-generated method stub
		final String procedureCall = "{call AIRTL_MENU_DETAILS.AIRTL_SUBMENU_ROLEID(?,?,?)}";
		Connection connection = null;
	 
	  ResultSet menuDetails=null;
	  List<Menu> menuList=new ArrayList<Menu>();
		try {

			// Get Connection instance from dataSource
			//System.out.println("connect"+ "ion:" + dataSource.getConnection());
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			connection = jdbcTemplate.getDataSource().getConnection();
			
			CallableStatement callableStatement = connection
					.prepareCall(procedureCall);
			
			callableStatement.setInt(1,roleId);
			callableStatement.setInt(2,menuId);
		
			
			callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
			
			callableStatement.executeUpdate();
		
			menuDetails=(ResultSet) callableStatement.getObject(3);
			while (menuDetails.next()) {
				Menu menuDetails1=new Menu();
				menuDetails1.setRoleId(roleId);
				menuDetails1.setMenuId(menuId);
				menuDetails1.setMenuName(menuName);
				menuDetails1.setSubMenuId(menuDetails.getInt(1));
				menuDetails1.setSubMenu(menuDetails.getString(2));
				menuDetails1.setUrl(menuDetails.getString(3));
				System.out.println("User Menu Details are:"+menuId+"--Submenu"+menuDetails1.getSubMenu());
				menuList.add(menuDetails1);
				
			}
			
		} catch (SQLException e) {
			logger.info(e.getLocalizedMessage());
			e.printStackTrace();

		} finally {

			if (connection != null)
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
					logger.info(e.getLocalizedMessage());
				}
		}
		return menuList;
		
	}
	

}
