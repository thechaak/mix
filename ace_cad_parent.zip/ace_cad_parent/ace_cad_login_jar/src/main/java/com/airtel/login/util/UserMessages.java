package com.airtel.login.util;

import java.util.HashMap;

public class UserMessages {
	
	public static String errorMessage(String code){
		
		HashMap errorMsg= new HashMap();
		
		errorMsg.put("1", "Success");
		errorMsg.put("2", "UserID either doesn't exist or inactive");
		errorMsg.put("3", "Account locked due to 3 consecutive failure attempts");
		errorMsg.put("4", "Account has been locked");
		//errorMsg.put("5", "UserID doesn't exist, Please enter a valid UserID");
		errorMsg.put("6", "Database interaction has gone wrong. Please try again later. Thank you!!");
		
	
		return errorMsg.get(code).toString();
	}

}
