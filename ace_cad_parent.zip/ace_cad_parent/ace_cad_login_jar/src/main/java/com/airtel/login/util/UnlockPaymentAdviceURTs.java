package com.airtel.login.util;


import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;
import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;


public class UnlockPaymentAdviceURTs 
{

   
	private static Logger logger =LogManager.getLogger("loginLogger");
	public static int deleteLockedUTRs(String user)
	{
		DataSource dataSource=null;

		JdbcTemplate jdbcTemplate=null;
		String query="update AIRTL_PAYMENT_ADVICE_LOCK set LOCK_STATUS='SESSION_EXPIRED',END_TIME=SYSDATE where LOCK_STATUS='ACQUIRED' and UPPER(LOCK_ACQUIRED_BY)=UPPER('"+user+"')";
		logger.info(query);
	
		try{
			ApplicationContext ctx=new ClassPathXmlApplicationContext("PaymentAdviceUTRsClearance.xml");  
		
			//dataSource=(DataSource)ctx.getBean("dataSource");
			jdbcTemplate=(JdbcTemplate)ctx.getBean("jdbcTemplate");
			return jdbcTemplate.update(query);
		}
			catch (Exception e)
		{
				logger.info(e.getLocalizedMessage());
			return -1;
		}
	}
	
	
	public static int deleteLockedUTRsTds(String user)
	{
		DataSource dataSource=null;

		JdbcTemplate jdbcTemplate=null;
		String query="update AIRTL_TDS_LOCK set LOCK_STATUS='SESSION_EXPIRED',END_TIME=SYSDATE where LOCK_STATUS='ACQUIRED' and UPPER(LOCK_ACQUIRED_BY)=UPPER('"+user+"')";
		logger.info(query);
	
		try{
			ApplicationContext ctx=new ClassPathXmlApplicationContext("PaymentAdviceUTRsClearance.xml");  
		
			//dataSource=(DataSource)ctx.getBean("dataSource");
			jdbcTemplate=(JdbcTemplate)ctx.getBean("jdbcTemplate");
			return jdbcTemplate.update(query);
		}
			catch (Exception e)
		{
				logger.info(e.getLocalizedMessage());
			return -1;
		}
	}
}
