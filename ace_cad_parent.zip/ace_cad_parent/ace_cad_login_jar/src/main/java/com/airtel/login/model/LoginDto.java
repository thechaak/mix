package com.airtel.login.model;

import java.util.ArrayList;
import java.util.List;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;
 
public class LoginDto implements GrantedAuthority{

	private String userName;
	private String userId;
	private String roleId;
	private String userStatus;
	private String roleDesc;
	private String successLogin;
	private String unsuccessLogin;
	private String emailId;
	private String macId;
	private String ipAddress;
	private String sessionId;
	private String endTime;
	
	
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getMacId() {
		return macId;
	}
	public void setMacId(String macId) {
		this.macId = macId;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	List<LoginDto> loginDetails=new ArrayList<LoginDto>();
	public List<LoginDto> getLoginDetails() {
		return loginDetails;
	}
	public void setLoginDetails(List<LoginDto> loginDetails) {
		this.loginDetails = loginDetails;
	}
	public String getSuccessLogin() {
		return successLogin;
	}
	public void setSuccessLogin(String successLogin) {
		this.successLogin = successLogin;
	}
	public String getUnsuccessLogin() {
		return unsuccessLogin;
	}
	public void setUnsuccessLogin(String unsuccessLogin) {
		this.unsuccessLogin = unsuccessLogin;
	}
	public String getRoleDesc() {
		return roleDesc;
	}
	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getRoleId() {
		return roleId;
	}
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
	public String getUserStatus() {
		return userStatus;
	}
	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}
	@Override
	public String toString() {
		return "LoginDto [userName=" + userName + ", userId=" + userId + ", roleId=" + roleId + ", userStatus="
				+ userStatus + ", roleDesc=" + roleDesc + ", successLogin=" + successLogin + ", unsuccessLogin="
				+ unsuccessLogin + ", emailId=" + emailId + "]";
	}
	@Override
	public String getAuthority() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	
	
	
}
