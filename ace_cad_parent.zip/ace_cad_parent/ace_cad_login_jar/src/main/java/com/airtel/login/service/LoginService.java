package com.airtel.login.service;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;

import com.airtel.login.util.IpMacAddress;
import com.airtel.login.model.LDAPAuthenticationResult;
import com.airtel.login.model.User;

	public interface LoginService{
		
	public User loginAuthentication(User userform, HttpServletRequest request);
	public User userSessionInsert(User user, HttpServletRequest request, LDAPAuthenticationResult ldapAuthenticationResultObj);
	public String userSessionUpdate(String session_id);
	   

	}



