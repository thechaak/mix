package com.airtel.login.util;

import java.sql.SQLException;

public class DatabaseExceptionHandler extends SQLException {
	private static final long serialVersionUID = 1L;

	private String errCode;
	public String getErrCode() {
		return errCode;
	}

	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}

	private String errMsg;
	public DatabaseExceptionHandler()
	{
		super();
	}

	//getter and setter methods

	public DatabaseExceptionHandler(String errCode, String errMsg) {
		this.errCode = errCode;
		this.errMsg = errMsg;
	}
	public DatabaseExceptionHandler(SQLException exception) {
		//this.errCode = errCode;
		this.errMsg = exception.getMessage();
	}

}