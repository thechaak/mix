package com.airtel.login.service;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;

import com.acecad.controller.LoginController;
import com.airtel.login.dao.UserDAO;
import com.airtel.login.dao.UserDAOImpl;
import com.airtel.login.util.IpMacAddress;
import com.airtel.login.model.LDAPAuthenticationResult;
import com.airtel.login.model.User;

public class LoginServiceImpl implements LoginService {

	private static Logger logger =LogManager.getLogger("loginLogger");	
	
/*	@Autowired
	User user;*/
	
	@Autowired
	UserDAO userdao;
	
/*	@Autowired
	LDAPAuthenticationResult ldapAuthenticationResultObj;*/
	public IpMacAddress ipmacaddres;
	public User loginAuthentication(User user, HttpServletRequest request) {
		/*
		 * This section is commmented post login flow change
		 * 
		HttpSession session=request.getSession();
		HashMap ipmac= new HashMap();
		ipmacaddres= new IpMacAddress();
		ipmac= ipmacaddres.getIPMAC();
		logger.info("user details entered:"+user.getS_UserID()+":Password:"+user.getS_Password());
		user.setS_IPAddress(ipmac.get("ip").toString());
		user.setS_MACID(ipmac.get("macaddress").toString());
		user.setS_UserSessionID(session.getId());
		logger.info("sessionid:"+session.getId());
		
		 */
		/*UserDAO userdao=new UserDAOImpl();*/
		logger.info("User Authentication in DB");
		logger.info("User values are:"+user.getS_UserID());
		user= userdao.userAuthentication(user);
		logger.info("user status is:"+ user.getS_UserStatus());
		return user;
	}
	public User userSessionInsert(User user, HttpServletRequest request, LDAPAuthenticationResult ldapAuthenticationResultObj) {

		HttpSession session=request.getSession(true);
		HashMap ipmac= new HashMap();
		ipmacaddres= new IpMacAddress();
		ipmac= ipmacaddres.getIPMAC();
		//logger.info("user details entered:"+user.getS_UserID()+":Password:"+user.getS_Password());
		user.setS_IPAddress(ipmac.get("ip").toString());
		user.setS_MACID(ipmac.get("macaddress").toString());
		user.setS_UserSessionID(session.getId());
		/*UserDAO userdao=new UserDAOImpl();*/
		user=userdao.userSessionInsert(user, ldapAuthenticationResultObj);
		logger.info("User object post SessionUpdate in DB:"+user.toString());
		return user;
	}
	public String userSessionUpdate(String session_id)
	{
		String status="";
		/*UserDAO userdao=new UserDAOImpl();*/
		int rows_update=userdao.userSessionUpdate(session_id);
		logger.info("rows updated for session end-date:"+rows_update);
		if(rows_update==1)
		status="success";
		else
		status="failure";
		return status;
	}

}
