package com.airtel.login.service;

public interface UserDetailsService {

}
