package com.airtel.login.dao;

import com.airtel.login.model.LDAPAuthenticationResult;
import com.airtel.login.model.User;
import com.airtel.login.util.DatabaseExceptionHandler;

public interface UserDAO {

	public User userAuthentication(User userform);
	public User userSessionInsert(User userform,LDAPAuthenticationResult ldapAuthenticationResultObj);
	public int userSessionUpdate(String sessionId);
}
