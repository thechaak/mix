package com.airtel.login.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.EnableCaching;

import com.acecad.controller.LoginController;
import com.airtel.login.dao.MenuDao;
import com.airtel.login.model.Menu;
//import org.springframework.cache.interceptor.KeyGenerator;


public class UserMenu {

	@Autowired
	MenuDao menuDao;
	private static Logger logger =LogManager.getLogger("loginLogger");;
	
	/*@Cacheable(cacheNames="getMenuDetails")*/

@Cacheable(value="getMenuDetails"/*, key="#root.method.name"*/) 
		public LinkedHashMap<String,List<Menu>> userMenu(int userRole)
	{
		
		//HashMap<String,List<Menu>> subMenu=new HashMap<String,List<Menu>>();
		LinkedHashMap<String,List<Menu>> subMenu = new LinkedHashMap();
		List<Menu> menuList=new ArrayList<Menu>();
		List<Menu> subMenuList=new ArrayList<Menu>();
		logger.info("userrole in usermenu.java is:"+userRole);
		
		logger.info("menuDaoobject created:"+menuDao);
		menuList=menuDao.getMenuDetails(userRole);

		for(Menu me:menuList){
			subMenuList=menuDao.getSubMenuDetails(userRole,me.getMenuId(),me.getMenuName());
			subMenu.put(me.getMenuName(), subMenuList);
		}

		return subMenu;
	}
	
}
