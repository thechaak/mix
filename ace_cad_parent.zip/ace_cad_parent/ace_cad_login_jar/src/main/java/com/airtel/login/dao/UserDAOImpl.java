package com.airtel.login.dao;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import javax.sql.DataSource;

//import org.apache.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.airtel.login.model.LDAPAuthenticationResult;
import com.airtel.login.model.User;

public class UserDAOImpl implements UserDAO {
	@Autowired
	@Qualifier("dataSource")
	private DataSource dataSource;
	
	@Autowired
	@Qualifier("jdbcTemplate")
	private JdbcTemplate jdbcTemplate;  
	
	/*@Autowired
	User user;*/
	
/*	@Autowired
	LDAPAuthenticationResult ldapAuthenticationResultObj;*/
	private static Logger logger =LogManager.getLogger("loginLogger");
	public User userAuthentication(User user){
		Connection connection = null;
		
		try {
			jdbcTemplate = new JdbcTemplate(dataSource);
			
			connection = jdbcTemplate.getDataSource().getConnection();
			/*  Commented due to Change in Login Flow
			
			String insertStoreProc = "{call ACE_CAD_USER_SECURITY.ACE_CAD_USER_LOGIN(?,?,?,?,?,?,?,?,?,?,?,?)}";
			CallableStatement callableStatement = connection.prepareCall(insertStoreProc);
			
			callableStatement.setString(1, user.getS_UserID());
			callableStatement.setString(2, user.getS_Password());
			callableStatement.setString(3, user.getS_IPAddress());
			callableStatement.setString(4, user.getS_MACID());
			callableStatement.setString(5, user.getS_UserSessionID());
	
			callableStatement.registerOutParameter(6, Types.VARCHAR);
			callableStatement.registerOutParameter(7, Types.VARCHAR);
			callableStatement.registerOutParameter(8, Types.VARCHAR);
			callableStatement.registerOutParameter(9, Types.VARCHAR);
			callableStatement.registerOutParameter(10, Types.VARCHAR);
			callableStatement.registerOutParameter(11, Types.VARCHAR);
			//callableStatement.registerOutParameter(12, Types.REF_CURSOR);
			callableStatement.registerOutParameter(12,OracleTypes.CURSOR);
			System.out.println("input for user login proc:"+user.toString());
			logger.info("User Login Values"+user.toString());
			callableStatement.executeUpdate();
			String userRole=callableStatement.getString(6);
			String userStatus=callableStatement.getString(7);
			String procFlag=callableStatement.getString(11);
			String uname=callableStatement.getString(8);
			String last_success_login=callableStatement.getString(9);
			String last_unsuccess_login=callableStatement.getString(10);
			ResultSet rs=(ResultSet)callableStatement.getObject(12);
			//System.out.println(" User Role : "+userRole);
			//System.out.println(" Logged In Status : "+loggedInStatus);
			while(rs.next())
			{
			System.out.println("cirles are:"+rs.getString(1));
	
			}
			user.setS_UserRole(userRole);
			user.setS_UserStatus(userStatus);
			user.setS_UserFlag(procFlag);
			user.setS_Uname(uname);
			user.setS_LastSuccessLogin(last_success_login);
			user.setS_LastUnSuccessLogin(last_unsuccess_login);
			logger.info("User Login Values"+user.toString()); 
			
			 Commented due to Change in Login Flow*/ 
			
			String insertStoreProc = "{call ACE_CAD_USER_SECURITY.ace_cad_login_id_check(?,?,?)}";
			CallableStatement callableStatement = connection.prepareCall(insertStoreProc);
			logger.info("User values for validation in DB is"+user.getS_UserID());
			callableStatement.setString(1, user.getS_UserID());
			callableStatement.registerOutParameter(2, Types.VARCHAR);
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			
			callableStatement.executeUpdate();
			
			String userStatus=callableStatement.getString(2);
			String procFlag=callableStatement.getString(3);
			logger.info("User values after validation in DB, status:"+userStatus);
			logger.info("User values after validation in DB, procFlag:"+procFlag);
			//logger.info("Proc status and flag are :"+callableStatement.getString(2)+","+callableStatement.getString(3));
			
			user.setS_UserStatus(userStatus);
			user.setS_UserFlag(procFlag);
		}
		catch(SQLException e)
		{
			StringWriter errors=new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.info(errors.toString());
			e.printStackTrace();
		}
		catch(Exception e)
		{
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		 finally
		{
			try {
				connection.close();
				logger.info("connection Close:");
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		} 
		
		return user;
	}
	public User userSessionInsert(User user,LDAPAuthenticationResult ldapAuthenticationResultObj) {
		Connection connection = null;
		try
		{
		jdbcTemplate = new JdbcTemplate(dataSource);
		
		connection = jdbcTemplate.getDataSource().getConnection();
		String insertStoreProc = "{call ACE_CAD_USER_SECURITY.ace_cad_session_insert(?,?,?,?,?,?,?,?,?,?,?,?)}";
		CallableStatement callableStatement = connection.prepareCall(insertStoreProc);
		logger.info("User object before session update:"+user.toString());
		System.out.println("Is authenticated:"+ldapAuthenticationResultObj.isAuthenticated());
		//Set IN Parameters
		callableStatement.setString(1, user.getS_UserID());
		callableStatement.setString(2, Boolean.toString(ldapAuthenticationResultObj.isAuthenticated()));
		callableStatement.setString(3, ldapAuthenticationResultObj.getFailureReason());
		callableStatement.setString(4, user.getS_IPAddress());
		//callableStatement.setString(4,"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
		callableStatement.setString(5, user.getS_MACID());
		callableStatement.setString(6, user.getS_UserSessionID());
		
		//Register OUT Parameters
		callableStatement.registerOutParameter(7, Types.VARCHAR);
		callableStatement.registerOutParameter(8, Types.VARCHAR);
		callableStatement.registerOutParameter(9, Types.VARCHAR);
		callableStatement.registerOutParameter(10, Types.VARCHAR);
		callableStatement.registerOutParameter(11, Types.VARCHAR);
		callableStatement.registerOutParameter(12, Types.VARCHAR);
		//Execute Query
		callableStatement.executeUpdate();
		
		//Fetch OUT Parameters
		String userRole=callableStatement.getString(7);
		String last_success_login=callableStatement.getString(8);
		String last_unsuccess_login=callableStatement.getString(9);
		String procFlag=callableStatement.getString(10);
		String user_role_id=callableStatement.getString(11);
		String user_email=callableStatement.getString(12);
		
		//logger.info("Last Success login:"+callableStatement.getString(8));
		//logger.info("Last UnSuccess login:"+callableStatement.getString(9));
		user.setS_UserRole(userRole);
		user.setS_UserFlag(procFlag);
		user.setS_LastSuccessLogin(last_success_login);
		user.setS_LastUnSuccessLogin(last_unsuccess_login);
		user.setS_User_Role_Id(user_role_id);
		user.setS_EmailId(user_email);
		
		logger.info("User object post session update:"+user.toString());
		
		}
		catch(SQLException e)
		{
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		catch(Exception e)
		{
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally
		{
			try {
				connection.close();
				logger.info("connection Close:");
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}
		return user;
		
	}

	public int userSessionUpdate(String sessionId)
	{
		int rows_updated=0;
		Connection connection = null;
		try
		{
		jdbcTemplate = new JdbcTemplate(dataSource);
		
		connection = jdbcTemplate.getDataSource().getConnection();
		String insertStoreProc = "{call ACE_CAD_USER_SECURITY.ace_cad_session_update(?,?)}";
		CallableStatement callableStatement = connection.prepareCall(insertStoreProc);
		//Set IN Parameters
		callableStatement.setString(1,sessionId);
	
		
		//Register OUT Parameters
		callableStatement.registerOutParameter(2, Types.INTEGER);
	
		//Execute Query
		callableStatement.executeUpdate();
		
		//Fetch OUT Parameters
		rows_updated=callableStatement.getInt(2);
		
		logger.info("Session updated for:"+sessionId);
		
		}
		catch(SQLException e)
		{
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		catch(Exception e)
		{
			StringWriter errors= new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.error(errors);
		}
		finally
		{
			try {
				connection.close();
				logger.info("connection Close:");
			} catch (SQLException e) {
				StringWriter errors= new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				logger.error(errors);
			}
		}
		return rows_updated;
	}
	
	public int updateSessionDetails(String sessionId)
	{
		DataSource dataSource=null;
     
		JdbcTemplate jdbcTemplate=null;
		String query="UPDATE airtl_user_session_details aus SET aus.session_endtime = SYSDATE WHERE aus.session_id = '"+sessionId+"'";
		logger.info(query);
	
		try{
			ApplicationContext ctx=new ClassPathXmlApplicationContext("PaymentAdviceUTRsClearance.xml");  
		
			//dataSource=(DataSource)ctx.getBean("dataSource");
			jdbcTemplate=(JdbcTemplate)ctx.getBean("jdbcTemplate");
			return jdbcTemplate.update(query);
		}
			catch (Exception e)
		{
				logger.info(e.getLocalizedMessage());
			return -1;
		}
	}
	
}
