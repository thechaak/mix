package com.airtel.login.util;

import java.util.HashMap;

public class RedirectionPage {


	public static String redirectionTo(String code){
		
		HashMap redirect= new HashMap();
		
		redirect.put("ROLE_VENDOR_USER", "/vendoruser");
		redirect.put("ROLE_VENDOR_SPV", "/vendorSpv");
		redirect.put("ROLE_CAD_ADMIN", "/cadadmin");
		redirect.put("ROLE_CAD_USER", "/caduser");
		redirect.put("ROLE_CAD_SPV", "/cadspvuser");
		redirect.put("ROLE_RM", "/rmuser");
		redirect.put("login", "/login");
		redirect.put("authenticate","/authenticate");
		redirect.put("ROLE_CAD_BULK","/cadbulk");
		
	/****************Added by APS Team Start*************/
		redirect.put("ROLE_CAD_BIN","/cadbin");
		redirect.put("ROLE_IP_BIN","/ipbin");
		redirect.put("ROLE_CASH_BIN","/cashbin");
		redirect.put("ROLE_DISPATCH","/dispatchbin");
		redirect.put("ROLE_CLOSE_BIN","/closebin");
		redirect.put("ROLE_CAD_LEAD","/cadleadbin");
		redirect.put("ROLE_MASTER_CAD","/masterRefund");
		redirect.put("ROLE_CI_USER","/ciCadduser");
		redirect.put("ROLE_CI_SPV_USER","/cispvuser");
		redirect.put("ROLE_WAC","/wacUser");
	
		return redirect.get(code).toString();
	}
}
