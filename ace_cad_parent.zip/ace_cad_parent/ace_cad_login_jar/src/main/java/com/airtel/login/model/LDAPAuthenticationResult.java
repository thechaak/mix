package com.airtel.login.model;


public class LDAPAuthenticationResult {
	private String userID;
	private String password;
	private String username;
	private boolean isAccountNonExpired=false;
	private boolean isAccountNonLocked=false;
	private boolean isCredentailsNonExpired=false;
	private boolean isAuthenticated=false;
	private boolean isEnabled=false;
	private String status;
	private String failureReason;
	private String failureCode;
	public String getFailureCode() {
		return failureCode;
	}
	public void setFailureCode(String failureCode) {
		this.failureCode = failureCode;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public boolean isAccountNonExpired() {
		return isAccountNonExpired;
	}
	public void setAccountNonExpired(boolean isAccountNonExpired) {
		this.isAccountNonExpired = isAccountNonExpired;
	}
	public boolean isAccountNonLocked() {
		return isAccountNonLocked;
	}
	public void setAccountNonLocked(boolean isAccountNonLocked) {
		this.isAccountNonLocked = isAccountNonLocked;
	}
	public boolean isCredentailsNonExpired() {
		return isCredentailsNonExpired;
	}
	public void setCredentailsNonExpired(boolean isCredentailsNonExpired) {
		this.isCredentailsNonExpired = isCredentailsNonExpired;
	}
	public boolean isAuthenticated() {
		return isAuthenticated;
	}
	public void setAuthenticated(boolean isAuthenticated) {
		this.isAuthenticated = isAuthenticated;
	}
	public boolean isEnabled() {
		return isEnabled;
	}
	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getFailureReason() {
		return failureReason;
	}
	public void setFailureReason(String failureReason) {
		this.failureReason = failureReason;
	}
	
	public String toString()
	{
		return "UserID:"+getUserID()+"-isAccountNonExpired:"+isAccountNonExpired()+"-isAccountNonLocked:"+isAccountNonLocked()
				+"-isCredentailsNonExpired:"+isCredentailsNonExpired()+"-isAuthenticated:"+isAuthenticated()+"-isEnabled:"+isEnabled()
				+"-getStatus:"+getStatus()+"-getFailureReason:"+getFailureReason();
	}
		
}

