package com.airtel.login.util;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Ehcache;

public class ClearCache {
	
	public boolean clearCache()
	{
		CacheManager manager = CacheManager.getInstance();
		Ehcache cache = manager.getCache("getMenuDetails");
		cache.removeAll();
		return true;
	}

}
