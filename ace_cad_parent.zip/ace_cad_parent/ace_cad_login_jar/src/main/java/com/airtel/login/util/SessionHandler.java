package com.airtel.login.util;


import javax.annotation.PreDestroy;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSessionEvent;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.security.web.context.support.SecurityWebApplicationContextUtils;
import org.springframework.security.web.session.HttpSessionCreatedEvent;
import org.springframework.security.web.session.HttpSessionDestroyedEvent;

import com.airtel.login.dao.UserDAOImpl;

public class SessionHandler	extends HttpSessionEventPublisher {
	
	
private static Logger logger =LogManager.getLogger("loginLogger");
	
	ApplicationContext getContext(ServletContext servletContext) { 
	return SecurityWebApplicationContextUtils.findRequiredWebApplicationContext(servletContext); 
	} 

	
	@Override
	public void sessionCreated(HttpSessionEvent event) {
		HttpSessionCreatedEvent e = new HttpSessionCreatedEvent(event.getSession()); 
		logger.info("sessino created"); 
		/*if (log.isDebugEnabled()) { 
		log.debug("Publishing event: " + e); 
		} */
		getContext(event.getSession().getServletContext()).publishEvent(e); 


	}

	@Override
	public void sessionDestroyed(HttpSessionEvent event) {
		
		HttpSessionDestroyedEvent e = new HttpSessionDestroyedEvent(event.getSession()); 
		 UserDAOImpl u=new UserDAOImpl();
		//Clear PaymentAdvice UTRs locked by user if any
		if(e.getSession().getAttribute("userid")!=null)
		{
			u.updateSessionDetails(e.getSession().getId());
			
			logger.info("Cleared locks from AIRTL_PAYMENT_ADVICE_LOCK Table:"+UnlockPaymentAdviceURTs.deleteLockedUTRs(e.getSession().getAttribute("userid").toString()));
			logger.info("Cleared locks from AIRTL_TDS_LOCK Table:"+UnlockPaymentAdviceURTs.deleteLockedUTRsTds(e.getSession().getAttribute("userid").toString()));
		}
		logger.info("session destroyed"); 
		logger.info("session ID in Destroy method:"+e.getSession().getAttribute("userid"));
		
		
		/*if (log.isDebugEnabled()) { 
		log.debug("Publishing event: " + e); 
		} */
		getContext(event.getSession().getServletContext()).publishEvent(e); 
/*		try {
			
			response.sendRedirect("logout.jsp");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/

	}

	



	@PreDestroy
	public void cleanUp() throws Exception {
	  System.out.println("Spring Container is destroy! Objects clean up");
	}
	
	
	
 /*
    private final Counter counterOfActiveSessions;
 
    public SessionListenerWithMetrics() {
        super();
        counterOfActiveSessions = MetricRegistrySingleton.metrics.counter("web.sessions.active.count");
    }
 
    public void sessionCreated(final HttpSessionEvent event) {
    	System.out.println("session created");
    	System.out.println(event.getSession().getId());
       // counterOfActiveSessions.inc();
    }
    public void sessionDestroyed(final HttpSessionEvent event) {
       // counterOfActiveSessions.dec();
    	System.out.println("session expired");
    	System.out.println(event.getSession().getId());
    }
	
implements ApplicationListener<ApplicationEvent> {
    
  // private static final Logger LOG = Logger.getLogger(WebSessionListener.class);
	
   @Override
   public void onApplicationEvent(ApplicationEvent applicationEvent) {
       System.out.println("entered onApplicationEvent");
       System.out.println(applicationEvent instanceof HttpSessionCreatedEvent);
       System.out.println(applicationEvent.getClass());
       HttpServletRequest request=null;
       if(applicationEvent instanceof HttpSessionCreatedEvent){ //If event is a session created event
    	 
    	  HttpSessionCreatedEvent httpSessionCreatedEvent=new HttpSessionCreatedEvent(request.getSession());
          HttpSession httpSession =httpSessionCreatedEvent.getSession();
          String sessionId = httpSession.getId(); //get session id
          System.out.println("session id in SessionHandler on session creation is:"+sessionId);
          //persistSessionData(sessionId); //save session data to DB
          //LOG.debug(" Session is invalidated |SESSION_ID :" + sessionId ); //log data
        
       }else if(applicationEvent instanceof HttpSessionDestroyedEvent){ //If event is a session destroy event
          ...
       }else{
          ...
       }
   }*/
}