package com.airtel.acecad.reports.dto;

public class MasterRefundReport {
	private String SR_NUMBER;
	public String getSR_NUMBER() {
		return SR_NUMBER;
	}
	public void setSR_NUMBER(String sR_NUMBER) {
		SR_NUMBER = sR_NUMBER;
	}
	private String srNumber;
	private String srType;
	private String subType;
	private String refundAmount;
	private String modeOfRefund;
	private String rejectionReason;
	private String status;
	private String circle;
	private String accountNumber;
	private String delNo;
	private String name;
	private String address;
	private String email;
	private String alternateContact;
	private String reroutedStatus;
	private String reroutedNo;
	private String cadTaskOpen;
	private String cadTaskClosed;
	private String cadApprovedBy;
	private String cadTaskStatus;
	private String ipTaskOpen;
	private String ipTaskClosed;
	private String ipApprovedBy;
	private String ipTaskStatus;
	private String cnbTaskOpen;
	private String cnbTaskClosed;
	private String cnbApprovedBy;
	private String cnbTaskStatus;
	private String dpatchTaskOpen;
	private String dpatchClosed;
	private String dpatchApprovedBy;
	private String dpatchTaskStatus;
	private String fxPostedDate;
	private String fxStatus;
	private String prevChequeNo;
	private String parentSr;
	private String reasonToStop;
	private String reSrMode;
	private String pymntStatusCad;
	private String cadUploadIfsc;
	private String cadBankAccount;
	private String cadAddress;
	private String cnbUtrCheque;
	private String utrDate;
    private String cafNumber;
    private String depositDescription;
    private String siebelStatus;
    private String srReceivedDate;
    private String srCreateDate;
    private String bankAccount;
    private String ifsc;
    private String cadSla;
    private String cadSlaBreach;
    private String ipSla;
    private String ipSlaBreach;
    private String cnbSla;
    private String cnbSlaBreach;
    private String dpatchSla;
    private String dpatcSlaBreach;
    private String cnbReissueStartTime ;
    private String cnbReissueEndTime;
    private String cnbReissueStatus;
    private String cnbReissueActedBy;
    private String marketCode;
    private String cadLeadStartTime;
    private String cadLeadEndTime;
    private String cadLeadStatus;
    private String cadLeadActedBy;
    private String cadLeadSlaBreach;
	private String pymntStausCnb;
	private String awbNo;
	private String awbDate;
	private String awbStatus;
	
    
    public String getCadLeadStartTime() {
		return cadLeadStartTime;
	}
	public void setCadLeadStartTime(String cadLeadStartTime) {
		this.cadLeadStartTime = cadLeadStartTime;
	}
	public String getCadLeadEndTime() {
		return cadLeadEndTime;
	}
	public void setCadLeadEndTime(String cadLeadEndTime) {
		this.cadLeadEndTime = cadLeadEndTime;
	}
	public String getCadLeadStatus() {
		return cadLeadStatus;
	}
	public void setCadLeadStatus(String cadLeadStatus) {
		this.cadLeadStatus = cadLeadStatus;
	}
	public String getCadLeadActedBy() {
		return cadLeadActedBy;
	}
	public void setCadLeadActedBy(String cadLeadActedBy) {
		this.cadLeadActedBy = cadLeadActedBy;
	}
	public String getCadLeadSlaBreach() {
		return cadLeadSlaBreach;
	}
	public void setCadLeadSlaBreach(String cadLeadSlaBreach) {
		this.cadLeadSlaBreach = cadLeadSlaBreach;
	}
	public String getDepositDescription() {
		return depositDescription;
	}
	public void setDepositDescription(String depositDescription) {
		this.depositDescription = depositDescription;
	}
	public String getSiebelStatus() {
		return siebelStatus;
	}
	public void setSiebelStatus(String siebelStatus) {
		this.siebelStatus = siebelStatus;
	}
	public String getSrReceivedDate() {
		return srReceivedDate;
	}
	public void setSrReceivedDate(String srReceivedDate) {
		this.srReceivedDate = srReceivedDate;
	}
	public String getSrCreateDate() {
		return srCreateDate;
	}
	public void setSrCreateDate(String srCreateDate) {
		this.srCreateDate = srCreateDate;
	}
	public String getBankAccount() {
		return bankAccount;
	}
	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public String getCadSla() {
		return cadSla;
	}
	public void setCadSla(String cadSla) {
		this.cadSla = cadSla;
	}
	public String getCadSlaBreach() {
		return cadSlaBreach;
	}
	public void setCadSlaBreach(String cadSlaBreach) {
		this.cadSlaBreach = cadSlaBreach;
	}
	public String getIpSla() {
		return ipSla;
	}
	public void setIpSla(String ipSla) {
		this.ipSla = ipSla;
	}
	public String getIpSlaBreach() {
		return ipSlaBreach;
	}
	public void setIpSlaBreach(String ipSlaBreach) {
		this.ipSlaBreach = ipSlaBreach;
	}
	public String getCnbSla() {
		return cnbSla;
	}
	public void setCnbSla(String cnbSla) {
		this.cnbSla = cnbSla;
	}
	public String getCnbSlaBreach() {
		return cnbSlaBreach;
	}
	public void setCnbSlaBreach(String cnbSlaBreach) {
		this.cnbSlaBreach = cnbSlaBreach;
	}
	public String getDpatchSla() {
		return dpatchSla;
	}
	public void setDpatchSla(String dpatchSla) {
		this.dpatchSla = dpatchSla;
	}
	public String getDpatcSlaBreach() {
		return dpatcSlaBreach;
	}
	public void setDpatcSlaBreach(String dpatcSlaBreach) {
		this.dpatcSlaBreach = dpatcSlaBreach;
	}

    
	public String getMarketCode() {
		return marketCode;
	}
	public void setMarketCode(String marketCode) {
		this.marketCode = marketCode;
	}
	public String getCnbReissueStartTime() {
		return cnbReissueStartTime;
	}
	public void setCnbReissueStartTime(String cnbReissueStartTime) {
		this.cnbReissueStartTime = cnbReissueStartTime;
	}
	public String getCnbReissueEndTime() {
		return cnbReissueEndTime;
	}
	public void setCnbReissueEndTime(String cnbReissueEndTime) {
		this.cnbReissueEndTime = cnbReissueEndTime;
	}
	public String getCnbReissueStatus() {
		return cnbReissueStatus;
	}
	public void setCnbReissueStatus(String cnbReissueStatus) {
		this.cnbReissueStatus = cnbReissueStatus;
	}
	public String getCnbReissueActedBy() {
		return cnbReissueActedBy;
	}
	public void setCnbReissueActedBy(String cnbReissueActedBy) {
		this.cnbReissueActedBy = cnbReissueActedBy;
	}
	public String getCafNumber() {
		return cafNumber;
	}
	public void setCafNumber(String cafNumber) {
		this.cafNumber = cafNumber;
	}
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getSrType() {
		return srType;
	}
	public void setSrType(String srType) {
		this.srType = srType;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getRefundAmount() {
		return refundAmount;
	}
	public void setRefundAmount(String refundAmount) {
		this.refundAmount = refundAmount;
	}
	public String getModeOfRefund() {
		return modeOfRefund;
	}
	public void setModeOfRefund(String modeOfRefund) {
		this.modeOfRefund = modeOfRefund;
	}
	public String getRejectionReason() {
		return rejectionReason;
	}
	public void setRejectionReason(String rejectionReason) {
		this.rejectionReason = rejectionReason;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getDelNo() {
		return delNo;
	}
	public void setDelNo(String delNo) {
		this.delNo = delNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAlternateContact() {
		return alternateContact;
	}
	public void setAlternateContact(String alternateContact) {
		this.alternateContact = alternateContact;
	}
	public String getReroutedStatus() {
		return reroutedStatus;
	}
	public void setReroutedStatus(String reroutedStatus) {
		this.reroutedStatus = reroutedStatus;
	}
	public String getReroutedNo() {
		return reroutedNo;
	}
	public void setReroutedNo(String reroutedNo) {
		this.reroutedNo = reroutedNo;
	}
	public String getCadTaskOpen() {
		return cadTaskOpen;
	}
	public void setCadTaskOpen(String cadTaskOpen) {
		this.cadTaskOpen = cadTaskOpen;
	}
	public String getCadTaskClosed() {
		return cadTaskClosed;
	}
	public void setCadTaskClosed(String cadTaskClosed) {
		this.cadTaskClosed = cadTaskClosed;
	}
	public String getCadApprovedBy() {
		return cadApprovedBy;
	}
	public void setCadApprovedBy(String cadApprovedBy) {
		this.cadApprovedBy = cadApprovedBy;
	}
	public String getCadTaskStatus() {
		return cadTaskStatus;
	}
	public void setCadTaskStatus(String cadTaskStatus) {
		this.cadTaskStatus = cadTaskStatus;
	}
	public String getIpTaskOpen() {
		return ipTaskOpen;
	}
	public void setIpTaskOpen(String ipTaskOpen) {
		this.ipTaskOpen = ipTaskOpen;
	}
	public String getIpTaskClosed() {
		return ipTaskClosed;
	}
	public void setIpTaskClosed(String ipTaskClosed) {
		this.ipTaskClosed = ipTaskClosed;
	}
	public String getIpApprovedBy() {
		return ipApprovedBy;
	}
	public void setIpApprovedBy(String ipApprovedBy) {
		this.ipApprovedBy = ipApprovedBy;
	}
	public String getIpTaskStatus() {
		return ipTaskStatus;
	}
	public void setIpTaskStatus(String ipTaskStatus) {
		this.ipTaskStatus = ipTaskStatus;
	}
	public String getCnbTaskOpen() {
		return cnbTaskOpen;
	}
	public void setCnbTaskOpen(String cnbTaskOpen) {
		this.cnbTaskOpen = cnbTaskOpen;
	}
	public String getCnbTaskClosed() {
		return cnbTaskClosed;
	}
	public void setCnbTaskClosed(String cnbTaskClosed) {
		this.cnbTaskClosed = cnbTaskClosed;
	}
	public String getCnbApprovedBy() {
		return cnbApprovedBy;
	}
	public void setCnbApprovedBy(String cnbApprovedBy) {
		this.cnbApprovedBy = cnbApprovedBy;
	}
	public String getCnbTaskStatus() {
		return cnbTaskStatus;
	}
	public void setCnbTaskStatus(String cnbTaskStatus) {
		this.cnbTaskStatus = cnbTaskStatus;
	}
	public String getDpatchTaskOpen() {
		return dpatchTaskOpen;
	}
	public void setDpatchTaskOpen(String dpatchTaskOpen) {
		this.dpatchTaskOpen = dpatchTaskOpen;
	}
	public String getDpatchClosed() {
		return dpatchClosed;
	}
	public void setDpatchClosed(String dpatchClosed) {
		this.dpatchClosed = dpatchClosed;
	}
	public String getDpatchApprovedBy() {
		return dpatchApprovedBy;
	}
	public void setDpatchApprovedBy(String dpatchApprovedBy) {
		this.dpatchApprovedBy = dpatchApprovedBy;
	}
	public String getDpatchTaskStatus() {
		return dpatchTaskStatus;
	}
	public void setDpatchTaskStatus(String dpatchTaskStatus) {
		this.dpatchTaskStatus = dpatchTaskStatus;
	}
	public String getFxPostedDate() {
		return fxPostedDate;
	}
	public void setFxPostedDate(String fxPostedDate) {
		this.fxPostedDate = fxPostedDate;
	}
	public String getFxStatus() {
		return fxStatus;
	}
	public void setFxStatus(String fxStatus) {
		this.fxStatus = fxStatus;
	}
	public String getPrevChequeNo() {
		return prevChequeNo;
	}
	public void setPrevChequeNo(String prevChequeNo) {
		this.prevChequeNo = prevChequeNo;
	}
	public String getParentSr() {
		return parentSr;
	}
	public void setParentSr(String parentSr) {
		this.parentSr = parentSr;
	}
	public String getReasonToStop() {
		return reasonToStop;
	}
	public void setReasonToStop(String reasonToStop) {
		this.reasonToStop = reasonToStop;
	}
	public String getReSrMode() {
		return reSrMode;
	}
	public void setReSrMode(String reSrMode) {
		this.reSrMode = reSrMode;
	}
	public String getPymntStatusCad() {
		return pymntStatusCad;
	}
	public void setPymntStatusCad(String pymntStatusCad) {
		this.pymntStatusCad = pymntStatusCad;
	}
	public String getCadUploadIfsc() {
		return cadUploadIfsc;
	}
	public void setCadUploadIfsc(String cadUploadIfsc) {
		this.cadUploadIfsc = cadUploadIfsc;
	}
	public String getCadBankAccount() {
		return cadBankAccount;
	}
	public void setCadBankAccount(String cadBankAccount) {
		this.cadBankAccount = cadBankAccount;
	}
	public String getCadAddress() {
		return cadAddress;
	}
	public void setCadAddress(String cadAddress) {
		this.cadAddress = cadAddress;
	}
	public String getCnbUtrCheque() {
		return cnbUtrCheque;
	}
	public void setCnbUtrCheque(String cnbUtrCheque) {
		this.cnbUtrCheque = cnbUtrCheque;
	}
	public String getUtrDate() {
		return utrDate;
	}
	public void setUtrDate(String utrDate) {
		this.utrDate = utrDate;
	}
	public String getPymntStausCnb() {
		return pymntStausCnb;
	}
	public void setPymntStausCnb(String pymntStausCnb) {
		this.pymntStausCnb = pymntStausCnb;
	}
	public String getAwbNo() {
		return awbNo;
	}
	public void setAwbNo(String awbNo) {
		this.awbNo = awbNo;
	}
	public String getAwbDate() {
		return awbDate;
	}
	public void setAwbDate(String awbDate) {
		this.awbDate = awbDate;
	}
	public String getAwbStatus() {
		return awbStatus;
	}
	public void setAwbStatus(String awbStatus) {
		this.awbStatus = awbStatus;
	}

	

}
