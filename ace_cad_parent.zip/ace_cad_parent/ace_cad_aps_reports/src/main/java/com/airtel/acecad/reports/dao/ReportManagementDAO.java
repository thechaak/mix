package com.airtel.acecad.reports.dao;

import java.sql.SQLException;
import java.util.HashMap;

public interface ReportManagementDAO {
	
	public Object[] generateAllReport(String reportId,String reportName,String startDate,String endDate,String fileId);

	public HashMap<Integer,String> getReportListAPS(String paymentType, String user) throws SQLException;
}
