package com.airtel.acecad.reports.dto;

public class NrcPostingDTO {
	
	private String serialNo;
	private String marketCode;
	private String accountNo;
	private String serviceExternalId; 
	private String typeIdNrc;
	private String annotation;
	private String effectiveDate;
	private String nrcAmount;
	private String fileName;
	private String fileId;
	private String fileSource;
	private String uploadedBy;
	private String uploadedDate;
	private String approvedBy;
	private String approvedDate;
	private String fxPostedDate;
	private String status;
	private String failureReason;
	private String nrcTrackingId;

	private String viewId;
	public String getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	public String getMarketCode() {
		return marketCode;
	}
	public void setMarketCode(String marketCode) {
		this.marketCode = marketCode;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getServiceExternalId() {
		return serviceExternalId;
	}
	public void setServiceExternalId(String serviceExternalId) {
		this.serviceExternalId = serviceExternalId;
	}
	public String getTypeIdNrc() {
		return typeIdNrc;
	}
	public void setTypeIdNrc(String typeIdNrc) {
		this.typeIdNrc = typeIdNrc;
	}
	public String getAnnotation() {
		return annotation;
	}
	public void setAnnotation(String annotation) {
		this.annotation = annotation;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getNrcAmount() {
		return nrcAmount;
	}
	public void setNrcAmount(String nrcAmount) {
		this.nrcAmount = nrcAmount;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getFileSource() {
		return fileSource;
	}
	public void setFileSource(String fileSource) {
		this.fileSource = fileSource;
	}
	public String getUploadedBy() {
		return uploadedBy;
	}
	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}
	public String getUploadedDate() {
		return uploadedDate;
	}
	public void setUploadedDate(String uploadedDate) {
		this.uploadedDate = uploadedDate;
	}
	public String getApprovedBy() {
		return approvedBy;
	}
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}
	public String getApprovedDate() {
		return approvedDate;
	}
	public void setApprovedDate(String approvedDate) {
		this.approvedDate = approvedDate;
	}
	public String getFxPostedDate() {
		return fxPostedDate;
	}
	public void setFxPostedDate(String fxPostedDate) {
		this.fxPostedDate = fxPostedDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getFailureReason() {
		return failureReason;
	}
	public void setFailureReason(String failureReason) {
		this.failureReason = failureReason;
	}
	public String getNrcTrackingId() {
		return nrcTrackingId;
	}
	public void setNrcTrackingId(String nrcTrackingId) {
		this.nrcTrackingId = nrcTrackingId;
	}

	public String getViewId() {
		return viewId;
	}
	public void setViewId(String viewId) {
		this.viewId = viewId;
	}

	

}
