package com.airtel.acecad.reports.dto;

public class EcsChargingReportDto {
	
	private String serviceExternalId;
	private String msisdn;
	private String accountStatus;
	private String accountNo;
	private String statementDate;
	private String paymentDueDate;
	private String balanceDue;
	private String billRefNo;
	private String billRefReset;
	private String fromDate;
	private String toDate;
	private String bankCode;
	private String accountHolderName;
	private String bankAgencyName;
	private String nachLimit;
	private String accountExternalId;
	private String trackingId;
	private String trackingIdServ;
	private String amount;
	private String fileId;
	private String userId;
	private String source;
	private String createdDate;
	private String modifiedDate;
	private String fileIdentifier;
	private String statusDescription;
	private String amountToPost;
	private String paymentDescription;
	private String paymentPostedDate;
	private String reversalDescription;
	private String debitDate;
	private String bankRejectionReason;
	private String bankDescription;
	private String nrcStatusDescription;
	private String nrcStatusDescriptionss;
	private String billCycle;
	private String circle;
	private String mtStatus;
	private String mtTriggerDate;
	private String bankTransactionNo;
	private String linkedTransactionNo;
	private String serviceStatus;
	private String ecsTriggerDate;
	private String ecsStatus;
	private String transactionNo;
	private String transactionNos;
	private String trackingIds;
	private String trackingIdServs;
	private String amountToPosts;
	private String paymentDescriptions;
	private String reversalDescriptions;
	private String debitDates;
	private String bankRejectionReasons;
	private String bankTransactionNos;
	private String bankDescriptions;
	public String getNrcStatusDescriptionss() {
		return nrcStatusDescriptionss;
	}
	public void setNrcStatusDescriptionss(String nrcStatusDescriptionss) {
		this.nrcStatusDescriptionss = nrcStatusDescriptionss;
	}
	public String getServiceExternalId() {
		return serviceExternalId;
	}
	public void setServiceExternalId(String serviceExternalId) {
		this.serviceExternalId = serviceExternalId;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getStatementDate() {
		return statementDate;
	}
	public void setStatementDate(String statementDate) {
		this.statementDate = statementDate;
	}
	public String getPaymentDueDate() {
		return paymentDueDate;
	}
	public void setPaymentDueDate(String paymentDueDate) {
		this.paymentDueDate = paymentDueDate;
	}
	public String getBalanceDue() {
		return balanceDue;
	}
	public void setBalanceDue(String balanceDue) {
		this.balanceDue = balanceDue;
	}
	public String getBillRefNo() {
		return billRefNo;
	}
	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}
	public String getBillRefReset() {
		return billRefReset;
	}
	public void setBillRefReset(String billRefReset) {
		this.billRefReset = billRefReset;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public String getBankAgencyName() {
		return bankAgencyName;
	}
	public void setBankAgencyName(String bankAgencyName) {
		this.bankAgencyName = bankAgencyName;
	}
	public String getNachLimit() {
		return nachLimit;
	}
	public void setNachLimit(String nachLimit) {
		this.nachLimit = nachLimit;
	}
	public String getAccountExternalId() {
		return accountExternalId;
	}
	public void setAccountExternalId(String accountExternalId) {
		this.accountExternalId = accountExternalId;
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	public String getTrackingIdServ() {
		return trackingIdServ;
	}
	public void setTrackingIdServ(String trackingIdServ) {
		this.trackingIdServ = trackingIdServ;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getFileIdentifier() {
		return fileIdentifier;
	}
	public void setFileIdentifier(String fileIdentifier) {
		this.fileIdentifier = fileIdentifier;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	public String getAmountToPost() {
		return amountToPost;
	}
	public void setAmountToPost(String amountToPost) {
		this.amountToPost = amountToPost;
	}
	public String getPaymentDescription() {
		return paymentDescription;
	}
	public void setPaymentDescription(String paymentDescription) {
		this.paymentDescription = paymentDescription;
	}
	public String getPaymentPostedDate() {
		return paymentPostedDate;
	}
	public void setPaymentPostedDate(String paymentPostedDate) {
		this.paymentPostedDate = paymentPostedDate;
	}
	public String getReversalDescription() {
		return reversalDescription;
	}
	public void setReversalDescription(String reversalDescription) {
		this.reversalDescription = reversalDescription;
	}
	public String getDebitDate() {
		return debitDate;
	}
	public void setDebitDate(String debitDate) {
		this.debitDate = debitDate;
	}
	public String getBankRejectionReason() {
		return bankRejectionReason;
	}
	public void setBankRejectionReason(String bankRejectionReason) {
		this.bankRejectionReason = bankRejectionReason;
	}
	public String getBankDescription() {
		return bankDescription;
	}
	public void setBankDescription(String bankDescription) {
		this.bankDescription = bankDescription;
	}
	public String getNrcStatusDescription() {
		return nrcStatusDescription;
	}
	public void setNrcStatusDescription(String nrcStatusDescription) {
		this.nrcStatusDescription = nrcStatusDescription;
	}
	public String getBillCycle() {
		return billCycle;
	}
	public void setBillCycle(String billCycle) {
		this.billCycle = billCycle;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getMtStatus() {
		return mtStatus;
	}
	public void setMtStatus(String mtStatus) {
		this.mtStatus = mtStatus;
	}
	public String getMtTriggerDate() {
		return mtTriggerDate;
	}
	public void setMtTriggerDate(String mtTriggerDate) {
		this.mtTriggerDate = mtTriggerDate;
	}
	public String getBankTransactionNo() {
		return bankTransactionNo;
	}
	public void setBankTransactionNo(String bankTransactionNo) {
		this.bankTransactionNo = bankTransactionNo;
	}
	public String getLinkedTransactionNo() {
		return linkedTransactionNo;
	}
	public void setLinkedTransactionNo(String linkedTransactionNo) {
		this.linkedTransactionNo = linkedTransactionNo;
	}
	public String getServiceStatus() {
		return serviceStatus;
	}
	public void setServiceStatus(String serviceStatus) {
		this.serviceStatus = serviceStatus;
	}
	public String getEcsTriggerDate() {
		return ecsTriggerDate;
	}
	public void setEcsTriggerDate(String ecsTriggerDate) {
		this.ecsTriggerDate = ecsTriggerDate;
	}
	public String getEcsStatus() {
		return ecsStatus;
	}
	public void setEcsStatus(String ecsStatus) {
		this.ecsStatus = ecsStatus;
	}
	public String getTransactionNo() {
		return transactionNo;
	}
	public void setTransactionNo(String transactionNo) {
		this.transactionNo = transactionNo;
	}
	public String getTransactionNos() {
		return transactionNos;
	}
	public void setTransactionNos(String transactionNos) {
		this.transactionNos = transactionNos;
	}
	public String getTrackingIds() {
		return trackingIds;
	}
	public void setTrackingIds(String trackingIds) {
		this.trackingIds = trackingIds;
	}
	public String getTrackingIdServs() {
		return trackingIdServs;
	}
	public void setTrackingIdServs(String trackingIdServs) {
		this.trackingIdServs = trackingIdServs;
	}
	public String getAmountToPosts() {
		return amountToPosts;
	}
	public void setAmountToPosts(String amountToPosts) {
		this.amountToPosts = amountToPosts;
	}
	public String getPaymentDescriptions() {
		return paymentDescriptions;
	}
	public void setPaymentDescriptions(String paymentDescriptions) {
		this.paymentDescriptions = paymentDescriptions;
	}
	public String getReversalDescriptions() {
		return reversalDescriptions;
	}
	public void setReversalDescriptions(String reversalDescriptions) {
		this.reversalDescriptions = reversalDescriptions;
	}
	public String getDebitDates() {
		return debitDates;
	}
	public void setDebitDates(String debitDates) {
		this.debitDates = debitDates;
	}
	public String getBankRejectionReasons() {
		return bankRejectionReasons;
	}
	public void setBankRejectionReasons(String bankRejectionReasons) {
		this.bankRejectionReasons = bankRejectionReasons;
	}
	public String getBankTransactionNos() {
		return bankTransactionNos;
	}
	public void setBankTransactionNos(String bankTransactionNos) {
		this.bankTransactionNos = bankTransactionNos;
	}
	public String getBankDescriptions() {
		return bankDescriptions;
	}
	public void setBankDescriptions(String bankDescriptions) {
		this.bankDescriptions = bankDescriptions;
	}
	public String getNrcStatusDescriptions() {
		return nrcStatusDescriptions;
	}
	public void setNrcStatusDescriptions(String nrcStatusDescriptions) {
		this.nrcStatusDescriptions = nrcStatusDescriptions;
	}
	private String nrcStatusDescriptions;
	
}
