package com.airtel.acecad.reports.dto;

public class AdjustmentReversalDTO {
	
	private String serialNo;
	private String marketCode;
	private String accountExternalId;
	private String adjustmentReasonCode;
	private String geocode;
	private String origBillRefNo;
	private String origBillRefResets;
	private String origTransCode;
	private String trackingId;
	private String trackingIdServ;
	private String fileName;
	private String fileId;
	private String fileSource;
	private String uploadedBy;
	private String uploadedDate;
	private String approvedBy;
	private String approvedDate;
	private String fxReversedDate;
	private String status;
	private String failureReason;
	public String getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	public String getMarketCode() {
		return marketCode;
	}
	public void setMarketCode(String marketCode) {
		this.marketCode = marketCode;
	}
	public String getAccountExternalId() {
		return accountExternalId;
	}
	public void setAccountExternalId(String accountExternalId) {
		this.accountExternalId = accountExternalId;
	}
	public String getAdjustmentReasonCode() {
		return adjustmentReasonCode;
	}
	public void setAdjustmentReasonCode(String adjustmentReasonCode) {
		this.adjustmentReasonCode = adjustmentReasonCode;
	}
	public String getGeocode() {
		return geocode;
	}
	public void setGeocode(String geocode) {
		this.geocode = geocode;
	}
	public String getOrigBillRefNo() {
		return origBillRefNo;
	}
	public void setOrigBillRefNo(String origBillRefNo) {
		this.origBillRefNo = origBillRefNo;
	}
	public String getOrigBillRefResets() {
		return origBillRefResets;
	}
	public void setOrigBillRefResets(String origBillRefResets) {
		this.origBillRefResets = origBillRefResets;
	}
	public String getOrigTransCode() {
		return origTransCode;
	}
	public void setOrigTransCode(String origTransCode) {
		this.origTransCode = origTransCode;
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	public String getTrackingIdServ() {
		return trackingIdServ;
	}
	public void setTrackingIdServ(String trackingIdServ) {
		this.trackingIdServ = trackingIdServ;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getFileSource() {
		return fileSource;
	}
	public void setFileSource(String fileSource) {
		this.fileSource = fileSource;
	}
	public String getUploadedBy() {
		return uploadedBy;
	}
	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}
	public String getUploadedDate() {
		return uploadedDate;
	}
	public void setUploadedDate(String uploadedDate) {
		this.uploadedDate = uploadedDate;
	}
	public String getApprovedBy() {
		return approvedBy;
	}
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}
	public String getApprovedDate() {
		return approvedDate;
	}
	public void setApprovedDate(String approvedDate) {
		this.approvedDate = approvedDate;
	}
	public String getFxReversedDate() {
		return fxReversedDate;
	}
	public void setFxReversedDate(String fxReversedDate) {
		this.fxReversedDate = fxReversedDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getFailureReason() {
		return failureReason;
	}
	public void setFailureReason(String failureReason) {
		this.failureReason = failureReason;
	}
	

}
