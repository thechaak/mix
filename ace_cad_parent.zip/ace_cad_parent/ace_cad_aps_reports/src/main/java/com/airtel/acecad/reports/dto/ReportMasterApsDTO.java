package com.airtel.acecad.reports.dto;

public class ReportMasterApsDTO {

	
	private String activeUserId = null;
	private String roleId = null;
	private String reportId = null;
	private String reportName = null;
	private String reportTemplate = null;
	private String reportStartDateString;
	private String reportEndDateString;
	private String circleId;
	private String reportOutputFileName = null;
	private String isValid = null;
	private String comments = null;
	
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getIsValid() {
		return isValid;
	}
	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}
	public String getActiveUserId() {
		return activeUserId;
	}
	public void setActiveUserId(String activeUserId) {
		this.activeUserId = activeUserId;
	}
	public String getRoleId() {
		return roleId;
	}
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
	public String getReportId() {
		return reportId;
	}
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}
	public String getReportName() {
		return reportName;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	public String getReportTemplate() {
		return reportTemplate;
	}
	public void setReportTemplate(String reportTemplate) {
		this.reportTemplate = reportTemplate;
	}
	public String getReportStartDateString() {
		return reportStartDateString;
	}
	public void setReportStartDateString(String reportStartDateString) {
		this.reportStartDateString = reportStartDateString;
	}
	public String getReportEndDateString() {
		return reportEndDateString;
	}
	public void setReportEndDateString(String reportEndDateString) {
		this.reportEndDateString = reportEndDateString;
	}
	public String getCircleId() {
		return circleId;
	}
	public void setCircleId(String circleId) {
		this.circleId = circleId;
	}
	public String getReportOutputFileName() {
		return reportOutputFileName;
	}
	public void setReportOutputFileName(String reportOutputFileName) {
		this.reportOutputFileName = reportOutputFileName;
	}
	
	
}
