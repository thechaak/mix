package com.airtel.acecad.reports.controller;


import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.HashMap;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.servlet.ModelAndView;

import com.airtel.acecad.reports.dao.ReportManagementDAO;

import aps.reports.org.apache.poi.util.IOUtils;

//import aps.reports.org.apache.poi.util.IOUtils;


@Controller
public class ReportController {
	@Autowired
	ReportManagementDAO reportManagementDAO;
	HttpServletRequest request;
	HttpSession session;

	private String REPORT_TEMPLATE_PATH = System.getenv("ACE_CAD_HOME")+File.separator+"ReportTemplates"+File.separator+"{0}";
	private String REPORT_OUTPUT_FILE_PATH = System.getenv("ACE_CAD_HOME")+File.separator+"ReportOutFiles"+File.separator+"{0}";
	private static Logger logger = LogManager.getLogger("workflowControlLogger");


	///adding for Reports
	@RequestMapping(value ="/getReportsAPS", method = RequestMethod.GET)
	public ModelAndView getReportsAPS(HttpServletRequest request,HttpServletResponse response){
		logger.info(" inside ace_cad aps reports Reaching getReportsAPS of workflow Controller method");
		session = request.getSession(true);
		String user= session.getAttribute("user_role").toString();
		String reportId="",fromDate="",endDate="",fileId="";
		Object[] obj=new Object[4];
		String filePath=null;
		String fileName=null;
		int dataListSize=0;
		String message=null;
		String paymentType="";
		try{
			reportId = request.getParameter("reportId");
			fromDate = request.getParameter("fromDate");
			endDate = request.getParameter("endDate");
			paymentType=request.getParameter("paymentType");
			fileId=request.getParameter("fileId");
			if(paymentType!=null){
				
			}
			else{
				paymentType="PAYMENT";
			}
			
			
			logger.info("reportId-->>"+reportId);
			logger.info("fromDate-->>"+fromDate);
			logger.info("endDate-->>"+endDate);
			logger.info("reportId-->>"+fileId);
		}catch(Exception e){
			reportId = "";
			fromDate = "";
			endDate =  "";
			fileId = "";
		}
		HashMap<Integer, String> reportList = null;
		try {
			logger.info("start Inside workflow controller");
			reportList = reportManagementDAO.getReportListAPS(paymentType,user);
			if(reportId!=null && !reportId.isEmpty()){


				obj=reportManagementDAO.generateAllReport(reportId,null,fromDate,endDate,fileId);
				
				dataListSize= (int) obj[0];
				
				System.out.println("OBJECT 1 Size-->> "+dataListSize);
				if(dataListSize==0){
					dataListSize=1;
				}
				
				System.out.println("OBJECT 1 Size-->> "+dataListSize);
				filePath=(String) obj[2];
				fileName=(String) obj[3];
				logger.info("FilePath in Controller -->> "+filePath);
				String updatedFilePath=filePath+".xls";
				System.out.println("updated FilePath in Controller -->> "+updatedFilePath);
				//Adding new code

			
				if (dataListSize>0) {
					File file = new File(updatedFilePath);
					InputStream in = new BufferedInputStream(new FileInputStream(file));
					response.setContentType("application/xls");
					response.setHeader("Content-Disposition", "attachment; filename=" + fileName + ".xls");
					ServletOutputStream out = response.getOutputStream();
					byte[] bytes = IOUtils.toByteArray(in);
					out.write(bytes);
					out.close();
					out.flush();
				}
				else
				{
					
					message="No Records Found";
					
				}

			}
			logger.info("end Inside workflow controller");
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		/*if(message!=null){
			return new ModelAndView("redirect:/apsReports?message="+message);
		}*/
		ModelAndView modelAndViewObj = new ModelAndView();
		try {
			modelAndViewObj.addObject("reportsList", reportList);
			modelAndViewObj.addObject("searchedReportId", reportId);
			modelAndViewObj.addObject("filtersearch", "true");
			modelAndViewObj.addObject("fromdate", fromDate);
			modelAndViewObj.addObject("enddate", endDate);
			modelAndViewObj.addObject("fileId", fileId);
			modelAndViewObj.addObject("paymentType", paymentType);
			modelAndViewObj.addObject("userRole",user);
			modelAndViewObj.setViewName("apsReports");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return modelAndViewObj;
	}
	@RequestMapping(value ="/getCIReportsAPS", method = RequestMethod.GET)
	public ModelAndView getCIReportsAPS(HttpServletRequest request,HttpServletResponse response){
		logger.info(" inside ace_cad aps reports Reaching getReportsAPS of workflow Controller method");
		session = request.getSession(true);
		String user= session.getAttribute("user_role").toString();
		String reportId="",fromDate="",endDate="",fileId="";
		Object[] obj=new Object[4];
		String filePath=null;
		String fileName=null;
		int dataListSize=0;
		String message=null;
		String paymentType="";
		try{
			reportId = request.getParameter("reportId");
			fromDate = request.getParameter("fromDate");
			endDate = request.getParameter("endDate");
			paymentType=request.getParameter("paymentType");
			fileId=request.getParameter("fileId");
			if(paymentType!=null){
				
			}
			else{
				paymentType="CIPAYMENT";
			}
			
			
			logger.info("reportId-->>"+reportId);
			logger.info("fromDate-->>"+fromDate);
			logger.info("endDate-->>"+endDate);
			logger.info("reportId-->>"+fileId);
		}catch(Exception e){
			reportId = "";
			fromDate = "";
			endDate =  "";
			fileId = "";
		}
		HashMap<Integer, String> reportList = null;
		try {
			logger.info("start Inside workflow controller");
			reportList = reportManagementDAO.getReportListAPS(paymentType,user);
			if(reportId!=null && !reportId.isEmpty()){


				obj=reportManagementDAO.generateAllReport(reportId,null,fromDate,endDate,fileId);
				
				dataListSize= (int) obj[0];
				
				System.out.println("OBJECT 1 Size-->> "+dataListSize);
				if(dataListSize==0){
					dataListSize=1;
				}
				
				System.out.println("OBJECT 1 Size-->> "+dataListSize);
				filePath=(String) obj[2];
				fileName=(String) obj[3];
				logger.info("FilePath in Controller -->> "+filePath);
				String updatedFilePath=filePath+".xls";
				System.out.println("updated FilePath in Controller -->> "+updatedFilePath);
				//Adding new code

			
				if (dataListSize>0) {
					File file = new File(updatedFilePath);
					InputStream in = new BufferedInputStream(new FileInputStream(file));
					response.setContentType("application/xls");
					response.setHeader("Content-Disposition", "attachment; filename=" + fileName + ".xls");
					ServletOutputStream out = response.getOutputStream();
					byte[] bytes = IOUtils.toByteArray(in);
					out.write(bytes);
					out.close();
					out.flush();
				}
				else
				{
					
					message="No Records Found";
					
				}

			}
			logger.info("end Inside workflow controller");
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		/*if(message!=null){
			return new ModelAndView("redirect:/apsReports?message="+message);
		}*/
		ModelAndView modelAndViewObj = new ModelAndView();
		try {
			modelAndViewObj.addObject("reportsList", reportList);
			modelAndViewObj.addObject("searchedReportId", reportId);
			modelAndViewObj.addObject("filtersearch", "true");
			modelAndViewObj.addObject("fromdate", fromDate);
			modelAndViewObj.addObject("enddate", endDate);
			modelAndViewObj.addObject("fileId", fileId);
			modelAndViewObj.addObject("paymentType", paymentType);
			modelAndViewObj.setViewName("CIapsReports");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return modelAndViewObj;
	}
	

	

}



