package com.airtel.acecad.reports.dao;

import java.io.File;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.airtel.acecad.reports.controller.ReportController;
import com.airtel.acecad.reports.dto.AdjustmentPostingDTO;
import com.airtel.acecad.reports.dto.AdjustmentReversalDTO;
import com.airtel.acecad.reports.dto.BulkUploadReportDTO;
import com.airtel.acecad.reports.dto.DepositPostingReportDTO;
import com.airtel.acecad.reports.dto.DepositReversalDTO;
import com.airtel.acecad.reports.dto.EcsChargingReportDto;
import com.airtel.acecad.reports.dto.JasperReportGenerator;
import com.airtel.acecad.reports.dto.MasterRefundReport;
import com.airtel.acecad.reports.dto.NrcPostingDTO;
import com.airtel.acecad.reports.dto.NrcReversalDTO;
import com.airtel.acecad.reports.dto.RefundReissueRecourierDTO;
import com.airtel.acecad.reports.dto.RefundSrCurrentStatusDTO;
import com.airtel.acecad.reports.dto.RefundWaterFallReportDTO;
import com.airtel.acecad.reports.dto.ReportMasterApsDTO;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;



public class ReportManagementDAOImpl implements ReportManagementDAO{

	@Autowired
	DataSource dataSource;
	@Autowired
	private PlatformTransactionManager transactionManager;
	@Autowired
	JasperReportGenerator jasperReportGenerator;



	public ReportManagementDAOImpl(DataSource dataSource) {
		this.dataSource = dataSource;
		setTransactionManager(transactionManager);
	}
	public ReportManagementDAOImpl() {
		// TODO Auto-generated constructor stub
	}
	public void setTransactionManager(
			PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}


	private String REPORT_TEMPLATE_PATH = System.getenv("ACE_CAD_HOME")+File.separator+"ReportTemplates"+File.separator+"{0}";
	private String REPORT_OUTPUT_FILE_PATH = System.getenv("ACE_CAD_HOME")+File.separator+"ReportOutFiles"+File.separator+"{0}";

	private static Logger logger = LogManager.getLogger(ReportManagementDAOImpl.class);
	public HashMap<Integer,String> getReportListAPS(String paymentType, String user) throws SQLException{
		Connection con = null;
		ResultSet rs=null;
		String query="";
		con = new JdbcTemplate(dataSource).getDataSource().getConnection();
		HashMap<Integer,String> reportList = new HashMap<Integer,String>();
		if(user.equalsIgnoreCase("ROLE_RM")){
			query = "select report_id,report_name,report_template,is_valid,created_date,modified_date,report_output_file_name from master_reports_Aps where report_type='"+paymentType+"' and status='AM'";
		}
		
		else if(user.equalsIgnoreCase("ROLE_CI_USER")||user.equalsIgnoreCase("ROLE_CI_SPV_USER")){
			query = "select report_id,report_name,report_template,is_valid,created_date,modified_date,report_output_file_name from master_reports_Aps where report_type='"+paymentType+"' and status ='AC'";
		}else if(user.equalsIgnoreCase("ROLE_WAC")){
			query = "select report_id,report_name,report_template,is_valid,created_date,modified_date,report_output_file_name from master_reports_Aps where report_type='"+paymentType+"' and status='AW'";
		}
		
		else{
			query = "select report_id,report_name,report_template,is_valid,created_date,modified_date,report_output_file_name from master_reports_Aps where report_type='"+paymentType+"' and status IN ('A')";
		}
		PreparedStatement ps = con.prepareStatement(query);
		rs = ps.executeQuery();
		while(rs.next()){
			reportList.put(rs.getInt("report_id"), rs.getString("report_name"));	
		}
		if(con!=null){
			ps.close();
			rs.close();
			con.close();
		}
		return reportList;	
	}
	public Object[] generateAllReport(String reportId,String reportName,String startDate,String endDate,String fileId) {
		System.out.println(" Start generateAllReport");
		Object[] obj=new Object[4];
		List<Object> reportDataList;
		ReportMasterApsDTO reportMasterApsDTO=null;
System.out.println("reportName---->>>>>>"+reportName);
		try {

			System.out.println("generateRepor111t");
			reportMasterApsDTO=new ReportMasterApsDTO();
			//get all details from master_reports_aps
			reportMasterApsDTO=getdataMasterReportsAps(reportId, null);
			//getting all the data from DB by firing different report queries
			reportDataList=new ArrayList<Object>();
		
			reportDataList = generateReport(reportId,startDate,endDate);
			
			
			obj[0]=reportDataList.size();
			
			
			if(obj[0]==null){
				obj[0]=1;
			}
			logger.info("dataBeanList size --   "+reportDataList.size());

/*
			if (reportDataList != null && !reportDataList.isEmpty()) {*/
			logger.info("dataBeanList===>" + reportDataList);
				// Generating Report

				if (reportId.equals(reportMasterApsDTO.getReportId())) {

					logger.info("Report Template =====> " + reportMasterApsDTO.getReportTemplate());
					logger.info("Report Output FileName =====> " + reportMasterApsDTO.getReportOutputFileName());
					String reportTemplate = MessageFormat.format(REPORT_TEMPLATE_PATH, reportMasterApsDTO.getReportTemplate());

					//String reportTemplate = MessageFormat.format(REPORT_TEMPLATE_PATH, "lead_generation.jrxml");
					logger.info("Complete Report jrxml path ===> " + reportTemplate);

					String outputFileName=reportMasterApsDTO.getReportOutputFileName() + new SimpleDateFormat("ddMMyyhhmmss").format(new Date());
					String reportOutputFile = MessageFormat.format(REPORT_OUTPUT_FILE_PATH, outputFileName);

					obj[1]=reportTemplate;
					obj[2]=reportOutputFile;
					obj[3]=outputFileName;


					jasperReportGenerator.generateExcelReport(reportTemplate, reportOutputFile, reportDataList, null,startDate,endDate,fileId);

				}
			/*}*/ /*else {
				System.out.println("No Records Found");

				//return "error";
			}*/

		} catch (Exception e) {

			return obj;
		}
		return obj;

	}

	public ReportMasterApsDTO getdataMasterReportsAps(String reportId,String reportName){

		ReportMasterApsDTO reportMasterApsDTO=new ReportMasterApsDTO();

		String query="select REPORT_ID,REPORT_NAME,REPORT_TEMPLATE,IS_VALID,CREATED_DATE,"
				+ "MODIFIED_DATE,REPORT_OUTPUT_FILE_NAME"
				+ " from MASTER_REPORTS_APS where report_id=? ";
		Connection con=null;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);



		try {
			con = jdbcTemplate.getDataSource().getConnection();
			System.out.println("connection made...");

			System.out.println("in getdataMasterReportsAps and con is not null");
			System.out.println("Report ID-->>"+reportId);
			PreparedStatement preparedStatement = con.prepareStatement(query);
			preparedStatement.setString(1, reportId);
			//preparedStatement.setString(2, reportName);

			ResultSet rs = preparedStatement.executeQuery();


			// ResultSetMetaData columns = resultSet.getMetaData();
			List<String> list = new ArrayList();
			try {
				while (rs.next()) {

					reportMasterApsDTO.setReportId(rs.getString(1));
					reportMasterApsDTO.setReportName(rs.getString(2));
					reportMasterApsDTO.setReportTemplate(rs.getString(3));
					reportMasterApsDTO.setIsValid(rs.getString(4));
					reportMasterApsDTO.setReportStartDateString(rs.getString(5));
					reportMasterApsDTO.setReportEndDateString(rs.getString(6));
					reportMasterApsDTO.setReportOutputFileName(rs.getString(7));
				}
			} catch (Exception e) {
				//log.info(e);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return reportMasterApsDTO;
	}


	public List<List<String>> reportProcCall(String reportId,String startTimeStamp,String endTimeStamp) {

		Connection con = null;
		//List<List> list = null;
		List<String> val=null;
		List<List<String>> finalList = new ArrayList();
		// final String procedureCall = "{call FX_POSTING_APS1(?,?,?,?,?)}";
		// PROC RENAMED ON 23 JAN
		
		logger.info("Inside PROC reportProcCall-->> "+startTimeStamp+" End Time-->> "+endTimeStamp);
		final String procedureCall = "{call REPORTS_APS(?,?,?,?)}";
		try {
			try {
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				con = jdbcTemplate.getDataSource().getConnection();
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println( e);
			}

			// conn = jdbcTemplate.getDataSource().getConnection();

			if (con != null) {
				try {
					CallableStatement callableStatement = con.prepareCall(procedureCall);
					callableStatement.setInt(1, Integer.valueOf(reportId));
					callableStatement.setString(2, startTimeStamp);
					callableStatement.setString(3, endTimeStamp);
					callableStatement.registerOutParameter(4, OracleTypes.CURSOR);


					callableStatement.executeUpdate();
					ResultSet resultSet = ((OracleCallableStatement)callableStatement).getCursor(4);
					// callableStatement.executeQuery();
					val=new ArrayList();
					while (resultSet.next()) {
						int i = 1;
						ResultSetMetaData columns = resultSet.getMetaData();
						List<String> list = new ArrayList();
						while(i <= columns.getColumnCount()) {

							String resVal=resultSet.getString(i++);
							if(resVal==null)
							{

								list.add("");
							}
							else
							{
								list.add(resVal);
							}
							//list.add(resultSet.getString(i++));
						}
						finalList.add(list);

					}
					logger.info("finalList-->>"+finalList);

					callableStatement.close();


				} catch (Exception e) {
					// TODO: handle exception
					logger.info("callFXPostingAPS1--" + e);
					e.printStackTrace();
				}

			}

			// return list;
		} catch (Exception e) {
			logger.info("callFXPostingAPS1--" + e);
		} finally {
			try {
				con.commit();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.info("callFXPostingAPS1--" + e);
			}

		}
		return finalList;

	}


	public List<Object> generateReport(String reportId,String startDate,String endDate) throws Exception{
		//	List<Object> dataBeanList = null;
		List<Object> reportDetailList = new ArrayList<Object>();
		List<List<String>> finalList = null;
		try {
			logger.info(":::::::::::::::Entered generateReport() method of ReportManagementDAOImpl::::::::::::");

			///reportmanagementDTO 
			ReportMasterApsDTO reportMasterApsDTO=new ReportMasterApsDTO();
			reportMasterApsDTO=getdataMasterReportsAps(reportId, null);

			logger.info("reportName-->> "+reportMasterApsDTO.getReportName());
			/*if(reportId.equalsIgnoreCase("113")||reportId.equalsIgnoreCase("114")||reportId.equalsIgnoreCase("115")||reportId.equalsIgnoreCase("116")||reportId.equalsIgnoreCase("117")
			||reportId.equalsIgnoreCase("118")||reportId.equalsIgnoreCase("119")||reportId.equalsIgnoreCase("120")||reportId.equalsIgnoreCase("121")||reportId.equalsIgnoreCase("122")
			||reportId.equalsIgnoreCase("123")||reportId.equalsIgnoreCase("124")||reportId.equalsIgnoreCase("125")||reportId.equalsIgnoreCase("126")||reportId.equalsIgnoreCase("127")
			||reportId.equalsIgnoreCase("128")||reportId.equalsIgnoreCase("129")||reportId.equalsIgnoreCase("130")||reportId.equalsIgnoreCase("131")||reportId.equalsIgnoreCase("132")
			||reportId.equalsIgnoreCase("133")||reportId.equalsIgnoreCase("134")||reportId.equalsIgnoreCase("135")||reportId.equalsIgnoreCase("136")||reportId.equalsIgnoreCase("137")
			||reportId.equalsIgnoreCase("138")||reportId.equalsIgnoreCase("139")||reportId.equalsIgnoreCase("140")||reportId.equalsIgnoreCase("141")||reportId.equalsIgnoreCase("142")

			||reportId.equalsIgnoreCase("143")||reportId.equalsIgnoreCase("144")||reportId.equalsIgnoreCase("145")||reportId.equalsIgnoreCase("146")||reportId.equalsIgnoreCase("147")
			||reportId.equalsIgnoreCase("148") || reportId.equalsIgnoreCase("149")||reportId.equalsIgnoreCase("150")||reportId.equalsIgnoreCase("151")||reportId.equalsIgnoreCase("152")||reportId.equalsIgnoreCase("153")
			||reportId.equalsIgnoreCase("154")||reportId.equalsIgnoreCase("155")||reportId.equalsIgnoreCase("156"))*/
			
			if(reportMasterApsDTO.getReportName()!=null && reportId!=null){

				finalList = null;
				
			}
			else{
				logger.info("in report proc call method");
				 finalList=reportProcCall(reportId, startDate, endDate);
			}
			logger.info("finalList List here --->>> "+finalList);


			/*if(reportMasterApsDTO.getReportName().equalsIgnoreCase("RefundWaterFallReport") && finalList!=null){
				
				System.out.println("start -RefundWaterFallReport-->>> ");
				RefundWaterFallReportDTO refundWaterFallReportDTO=null;
				for(int i=0;i<finalList.size();i++){
					List<String> list=new ArrayList();
					list=finalList.get(i);
					
					refundWaterFallReportDTO=new RefundWaterFallReportDTO();
					
					refundWaterFallReportDTO.setSrNumber(list.get(0));
					refundWaterFallReportDTO.setSrType(list.get(1));
					refundWaterFallReportDTO.setSrCreationDate(list.get(2));
					//refundWaterFallReportDTO.setSrStatus(list.get(3));
					refundWaterFallReportDTO.setRefundType(list.get(3));
					refundWaterFallReportDTO.setRefundAmount(list.get(4));
					refundWaterFallReportDTO.setTaskName(list.get(5));
					refundWaterFallReportDTO.setGroupName(list.get(6));
					refundWaterFallReportDTO.setTaskStatus(list.get(7));
					refundWaterFallReportDTO.setActedBy(list.get(8));
					//refundWaterFallReportDTO.setActionTaken(list.get(10));
					refundWaterFallReportDTO.setTaskStartTime(list.get(9));
					refundWaterFallReportDTO.setTaskEndTime(list.get(10));
					refundWaterFallReportDTO.setNotes(list.get(11));
					refundWaterFallReportDTO.setSlaBreached(list.get(12));
					refundWaterFallReportDTO.setCircle(list.get(13));
				

					reportDetailList.add(refundWaterFallReportDTO);
				}

				System.out.println("end -RefundWaterFallReport-->>> ");				

			}
			if(reportMasterApsDTO.getReportName().equalsIgnoreCase("RefundReissueRecourierReport") && finalList!=null){
				
				System.out.println("start -RefundReissueRecourierReport-->>> ");
				RefundReissueRecourierDTO refundReissueRecourierDTO=null;
				
				for(int i=0;i<finalList.size();i++){
					List<String> list=new ArrayList();
					list=finalList.get(i);
					
					refundReissueRecourierDTO=new RefundReissueRecourierDTO();
					
					
					refundReissueRecourierDTO.setProcessId(list.get(0));
					refundReissueRecourierDTO.setAccountNumber(list.get(1));
					refundReissueRecourierDTO.setNewSrNumber(list.get(2));
					refundReissueRecourierDTO.setPaymentStatusCnb(list.get(3));
					refundReissueRecourierDTO.setChequeNumber(list.get(4));
					refundReissueRecourierDTO.setRefundAmount(list.get(5));
					refundReissueRecourierDTO.setReasonStopPayment(list.get(6));
					refundReissueRecourierDTO.setChequeDate(list.get(7));
					refundReissueRecourierDTO.setNewSrCreationDate(list.get(8));
					refundReissueRecourierDTO.setNewSrStatus(list.get(9));
					refundReissueRecourierDTO.setParentSr(list.get(10));
					refundReissueRecourierDTO.setServiceInstance(list.get(11));
					refundReissueRecourierDTO.setCafNumber(list.get(12));
					refundReissueRecourierDTO.setSrSubType(list.get(13));
					refundReissueRecourierDTO.setReSrMode(list.get(14));				
					refundReissueRecourierDTO.setRefundMode(list.get(15));
					refundReissueRecourierDTO.setBeneficiaryName(list.get(16));
					refundReissueRecourierDTO.setBenAddress1(list.get(17));
					refundReissueRecourierDTO.setBenAddress2(list.get(18));
					refundReissueRecourierDTO.setBenAddress3(list.get(19));
					refundReissueRecourierDTO.setBenAddress4(list.get(20));					
					//refundReissueRecourierDTO.setPinId(list.get(22));
					refundReissueRecourierDTO.setBenAccountNumber(list.get(21));
					refundReissueRecourierDTO.setIfscCode(list.get(22));					
					refundReissueRecourierDTO.setBenBankName(list.get(23));
					refundReissueRecourierDTO.setBenEmailId(list.get(24));
					refundReissueRecourierDTO.setComments(list.get(25));

					reportDetailList.add(refundReissueRecourierDTO);
				}

				System.out.println("end -RefundReissueRecourierReport-->>> ");	
				
				
			}
			if(reportMasterApsDTO.getReportName().equalsIgnoreCase("DepositPostingReport") && finalList!=null){

				System.out.println("start -DepositPostingReport-->>> ");
				//PROC CALL
				DepositPostingReportDTO depositPostingReportDTO=null;
				for(int i=0;i<finalList.size();i++){
					List<String> list=new ArrayList();
					list=finalList.get(i);
					//for(int j=0;j<list.size();j++)
					//{
					depositPostingReportDTO=new DepositPostingReportDTO();
					depositPostingReportDTO.setSerialNo(list.get(0));
					depositPostingReportDTO.setMarketCode(list.get(1));
					depositPostingReportDTO.setMobileNo(list.get(2));
					depositPostingReportDTO.setAccountExternalId(list.get(3));
					depositPostingReportDTO.setDepositType(list.get(4));
					depositPostingReportDTO.setDateReceived(list.get(5));
					depositPostingReportDTO.setAmount(list.get(6));
					depositPostingReportDTO.setFileName(list.get(7));
					depositPostingReportDTO.setFileId(list.get(8));
					depositPostingReportDTO.setFileSource(list.get(9));
					depositPostingReportDTO.setUploadedBy(list.get(10));
					depositPostingReportDTO.setUploadedDate(list.get(11));
					depositPostingReportDTO.setApprovedBy(list.get(12));
					depositPostingReportDTO.setApprovedDate(list.get(13));
					depositPostingReportDTO.setFxPostedDate(list.get(14));
					depositPostingReportDTO.setStatus(list.get(15));
					depositPostingReportDTO.setFailureReason(list.get(16));
					depositPostingReportDTO.setMicrBankId(list.get(17));
					depositPostingReportDTO.setChequeNo(list.get(18));
					depositPostingReportDTO.setChequeDate(list.get(19));
					depositPostingReportDTO.setBankName(list.get(20));
					depositPostingReportDTO.setCsrNotes(list.get(21));
					depositPostingReportDTO.setLob(list.get(22));
					depositPostingReportDTO.setSrNumber(list.get(23));
					depositPostingReportDTO.setTrackingId(list.get(24));
					depositPostingReportDTO.setTrackingIdServ(list.get(25));
					depositPostingReportDTO.setActivationDate(list.get(26));

					reportDetailList.add(depositPostingReportDTO);
				}

				System.out.println("end -DepositPostingReport-->>> ");				
			}
			if(reportMasterApsDTO.getReportName().equalsIgnoreCase("DepositReversalReports") && finalList!=null){
				System.out.println("start -DepositReversalReports-->>> ");	
				DepositReversalDTO depositReversalDTO=null;
				for(int i=0;i<finalList.size();i++){
					List<String> list=new ArrayList();
					list=finalList.get(i);

					depositReversalDTO=new DepositReversalDTO();
					depositReversalDTO.setSerialNo(list.get(0));
					depositReversalDTO.setMarketCode(list.get(1));
					depositReversalDTO.setAccountExternalId(list.get(2));
					depositReversalDTO.setMobileNo(list.get(3));
					depositReversalDTO.setRefundReasonCode(list.get(4));
					depositReversalDTO.setOrigTrackingId(list.get(5));
					depositReversalDTO.setOrigTrackingIdServ(list.get(6));
					depositReversalDTO.setDepositTypeCode(list.get(7));
					depositReversalDTO.setCrsId(list.get(8));
					depositReversalDTO.setCsrRemark(list.get(9));
					depositReversalDTO.setBusinessUnit(list.get(10));
					depositReversalDTO.setRefundType(list.get(11));
					depositReversalDTO.setFileName(list.get(12));
					depositReversalDTO.setFileId(list.get(13));
					depositReversalDTO.setFileSource(list.get(14));
					depositReversalDTO.setUploadedBy(list.get(15));
					depositReversalDTO.setUploadedDate(list.get(16));
					depositReversalDTO.setApprovedBy(list.get(17));
					depositReversalDTO.setFxReversedDate(list.get(18));
					depositReversalDTO.setStatus(list.get(19));
					depositReversalDTO.setFailureReason(list.get(20));

					reportDetailList.add(depositReversalDTO);
				}
				System.out.println("end -DepositReversalReports-->>> ");

			}

		
			if(reportMasterApsDTO.getReportName().equalsIgnoreCase("AdjustmentPostingReports") && finalList!=null){

				System.out.println("start -AdjustmentPostingReports-->>> ");	
				AdjustmentPostingDTO adjustmentPostingDTO=null;
				for(int i=0;i<finalList.size();i++){
					List<String> list=new ArrayList();
					list=finalList.get(i);

					adjustmentPostingDTO=new AdjustmentPostingDTO();
					adjustmentPostingDTO.setSerialNo(list.get(0));
					adjustmentPostingDTO.setMarketCode(list.get(1));
					adjustmentPostingDTO.setAccountExternalId(list.get(2));
					adjustmentPostingDTO.setAdjustmentReasonCode(list.get(3));
					adjustmentPostingDTO.setAnnotation(list.get(4));
					adjustmentPostingDTO.setAmount(list.get(5));
					adjustmentPostingDTO.setBillRefNo(list.get(6));
					adjustmentPostingDTO.setBillRefResets(list.get(7));
					adjustmentPostingDTO.setEffectiveDate(list.get(8));
					adjustmentPostingDTO.setTransCode(list.get(9));
					adjustmentPostingDTO.setTypeOfAdjustment(list.get(10));
					adjustmentPostingDTO.setFileName(list.get(11));
					adjustmentPostingDTO.setFileId(list.get(12));
					adjustmentPostingDTO.setFileSource(list.get(13));
					adjustmentPostingDTO.setUploadedBy(list.get(14));
					adjustmentPostingDTO.setUploadedDate(list.get(15));
					adjustmentPostingDTO.setApprovedBy(list.get(16));
					adjustmentPostingDTO.setApprovedDate(list.get(17));
					adjustmentPostingDTO.setFxPostedDate(list.get(18));
					adjustmentPostingDTO.setStatus(list.get(19));
					adjustmentPostingDTO.setFailureReason(list.get(20));
					adjustmentPostingDTO.setTrackingId(list.get(21));
					adjustmentPostingDTO.setTrackingIdServ(list.get(22));

					reportDetailList.add(adjustmentPostingDTO);
				}
				System.out.println("end -AdjustmentPostingReports-->>> ");


			}
			
			if(reportMasterApsDTO.getReportName().equalsIgnoreCase("NRCPostingReports")&& finalList!=null){
				
				 NrcPostingDTO nrcpost=null;
					for(int i=0;i<finalList.size();i++){
						List<String> list=new ArrayList();
						list=finalList.get(i);
						nrcpost=new NrcPostingDTO(); 
						nrcpost.setSerialNo(list.get(0));
						nrcpost.setMarketCode(list.get(1));
						nrcpost.setAccountNo(list.get(2));
						nrcpost.setServiceExternalId(list.get(3));
						nrcpost.setTypeIdNrc(list.get(4));
						nrcpost.setAnnotation(list.get(5));
						nrcpost.setEffectiveDate(list.get(6));
						nrcpost.setNrcAmount(list.get(7));
						nrcpost.setFileName(list.get(8));
						nrcpost.setFileId(list.get(9));
						nrcpost.setFileSource(list.get(10));
						nrcpost.setUploadedBy(list.get(11));
						nrcpost.setUploadedDate(list.get(12));
						nrcpost.setApprovedBy(list.get(13));
						nrcpost.setApprovedDate(list.get(14));
						nrcpost.setFxPostedDate(list.get(15));
						nrcpost.setStatus(list.get(16));
						nrcpost.setFailureReason(list.get(17));
						nrcpost.setNrcTrackingId(list.get(18));
						nrcpost.setViewId(list.get(19));
						
					   reportDetailList.add(nrcpost);
					}

			}
			if(reportMasterApsDTO.getReportName().equalsIgnoreCase("NRCReversalReports")&& finalList!=null){
				
				    NrcReversalDTO nrc=null;
				for(int i=0;i<finalList.size();i++){
					List<String> list=new ArrayList();
					list=finalList.get(i);
					nrc=new NrcReversalDTO(); 
					nrc.setSerialNo(list.get(0));
					nrc.setMarketCode(list.get(1));
					nrc.setAccountNo(list.get(2));
					nrc.setFileName(list.get(3));
					nrc.setFileId(list.get(4));
					nrc.setFileSource(list.get(5));
					nrc.setUploadedBy(list.get(6));
					nrc.setUploadedDate(list.get(7));
					nrc.setApprovedBy(list.get(8));
					nrc.setApprovedDate(list.get(9));
					nrc.setFxReversalDate(list.get(10));
					nrc.setStatus(list.get(11));
					nrc.setFailureReason(list.get(12));
					nrc.setNrcTrackingId(list.get(13));
					nrc.setViewId(list.get(14));
				   reportDetailList.add(nrc);
				}

			}
			if(reportMasterApsDTO.getReportName().equalsIgnoreCase("AdjustmentPostingReports")){

			}
			if(reportMasterApsDTO.getReportName().equalsIgnoreCase("AdjustmentReversalReports")&& finalList!=null){
				
				AdjustmentReversalDTO adj=null; 
				for(int i=0;i<finalList.size();i++){
					List<String> list=new ArrayList();
					list=finalList.get(i);
					
					adj=new AdjustmentReversalDTO(); 
				    adj.setSerialNo(list.get(0));
					adj.setMarketCode(list.get(1));
					adj.setAccountExternalId(list.get(2));
					adj.setAdjustmentReasonCode(list.get(3));
					adj.setGeocode(list.get(4));
					adj.setOrigBillRefNo(list.get(5));
					adj.setOrigBillRefResets(list.get(6));
					adj.setOrigTransCode(list.get(7));
					adj.setTrackingId(list.get(8));
					adj.setTrackingIdServ(list.get(9));
					adj.setFileName(list.get(10));
					adj.setFileId(list.get(11));
					adj.setFileSource(list.get(12));
					adj.setUploadedBy(list.get(13));
					adj.setUploadedDate(list.get(14));
					adj.setApprovedBy(list.get(15));
					adj.setApprovedDate(list.get(16));
					adj.setFxReversedDate(list.get(17));
					adj.setStatus(list.get(18));
					adj.setFailureReason(list.get(19));
				    reportDetailList.add(adj);
				}

			}	if(reportMasterApsDTO.getReportName().equalsIgnoreCase("BulkUploadReports") && finalList!=null){

				System.out.println("start -BulkUploadReports-->>> ");
				//PROC CALL
				BulkUploadReportDTO bulk=null;
				
				for(int i=0;i<finalList.size();i++){
					List<String> list=new ArrayList();
					list=finalList.get(i);
					//for(int j=0;j<list.size();j++)
					//{
					bulk=new BulkUploadReportDTO();
					bulk.setSerialNo(list.get(0));
					bulk.setCircle(list.get(1));
					bulk.setFileId(list.get(2));
					bulk.setFileName(list.get(3));
					bulk.setFileSource(list.get(4));
					bulk.setType(list.get(5));
					bulk.setUploadedBy(list.get(6));
					bulk.setUploadedDate(list.get(7));
					bulk.setApprovedBy(list.get(8));
					bulk.setApprovedDate(list.get(9));
					bulk.setTotalRecords(list.get(10));
					bulk.setTotalValue(list.get(11));
					bulk.setInProgressRecords(list.get(12));
					bulk.setInProgressValue(list.get(13));
					bulk.setStatus(list.get(14));
					bulk.setRecordsPostedToFx(list.get(15));
					bulk.setValuesPostedToFx(list.get(16));
					bulk.setFailedRecords(list.get(17));
					bulk.setFailedRecordsValue(list.get(18));
					reportDetailList.add(bulk);
				}
			}
			
			if(reportMasterApsDTO.getReportName().equalsIgnoreCase("RefundSrCurrentStatus") && finalList!=null){

				System.out.println("start -RefundSrCurrentStatus-->>> ");
				//PROC CALL
				RefundSrCurrentStatusDTO refundSrStatus=null;
				for(int i=0;i<finalList.size();i++){
					List<String> list=new ArrayList();
					list=finalList.get(i);
					
					refundSrStatus=new RefundSrCurrentStatusDTO();
					refundSrStatus.setSrNumber(list.get(0));
					refundSrStatus.setDateSr(list.get(1));
					refundSrStatus.setSrName(list.get(2));
					refundSrStatus.setSrSubType(list.get(3));
					refundSrStatus.setAccountNo(list.get(4));
					refundSrStatus.setCafNumber(list.get(5));
					refundSrStatus.setMobDelNo(list.get(6));
					refundSrStatus.setCustomerName(list.get(7));
					refundSrStatus.setAddress(list.get(8));
					refundSrStatus.setEmail(list.get(9));
					refundSrStatus.setAlternateContactNo(list.get(10));
					refundSrStatus.setModeOfRefund(list.get(11));
					refundSrStatus.setTaskName(list.get(12));
					refundSrStatus.setTaskOwner(list.get(13));
					refundSrStatus.setApprovedBy(list.get(14));
					refundSrStatus.setTaskStartDate(list.get(15));
					refundSrStatus.setTaskEndDate(list.get(16));
					refundSrStatus.setTaskStatus(list.get(17));
					refundSrStatus.setRemarks(list.get(18));
					refundSrStatus.setUtrChequeDate(list.get(19));
					refundSrStatus.setCircle(list.get(20));
					refundSrStatus.setMarketCode(list.get(21));
					refundSrStatus.setRefundAmount(list.get(22));
					refundSrStatus.setPaymentStatus(list.get(23));
					refundSrStatus.setParentSrNumber(list.get(24));
					refundSrStatus.setComments(list.get(25));
					reportDetailList.add(refundSrStatus);
				}
			}
			
             if(reportMasterApsDTO.getReportName().equalsIgnoreCase("EcsChargingReport") && finalList!=null){
				
				System.out.println("start -EcsChargingReport-->>> ");
				EcsChargingReportDto ecsReportDto=null;
				for(int i=0;i<finalList.size();i++){
					List<String> list=new ArrayList<String>();
					list=finalList.get(i);
					
					ecsReportDto=new EcsChargingReportDto();
					ecsReportDto.setServiceExternalId(list.get(0));
					ecsReportDto.setMsisdn(list.get(1));
					ecsReportDto.setAccountStatus(list.get(2));
					ecsReportDto.setAccountNo(list.get(3));
					ecsReportDto.setStatementDate(list.get(4));
					ecsReportDto.setPaymentDueDate(list.get(5));
				    ecsReportDto.setBalanceDue(list.get(6));
				    ecsReportDto.setBillRefNo(list.get(7));
				    ecsReportDto.setBillRefReset(list.get(8));
				    ecsReportDto.setFromDate(list.get(9));
				    ecsReportDto.setToDate(list.get(10));
				    ecsReportDto.setBankCode(list.get(11));
				    ecsReportDto.setAccountHolderName(list.get(12));
				    ecsReportDto.setBankAgencyName(list.get(13));
				    ecsReportDto.setNachLimit(list.get(14));
				    ecsReportDto.setAccountExternalId(list.get(15));
				    ecsReportDto.setTrackingId(list.get(16));
				    ecsReportDto.setTrackingIdServ(list.get(17));
				    ecsReportDto.setAmount(list.get(18));
				    ecsReportDto.setFileId(list.get(19));
				    ecsReportDto.setUserId(list.get(20));
				    ecsReportDto.setSource(list.get(21));
				    ecsReportDto.setCreatedDate(list.get(22));
				    ecsReportDto.setModifiedDate(list.get(23));
				    ecsReportDto.setFileIdentifier(list.get(24));
				    ecsReportDto.setStatusDescription(list.get(25));
				    ecsReportDto.setAmountToPost(list.get(26));
				    ecsReportDto.setPaymentDescription(list.get(27));
				    ecsReportDto.setPaymentPostedDate(list.get(28));
				    ecsReportDto.setReversalDescription(list.get(29));
				    ecsReportDto.setDebitDate(list.get(30));
				    ecsReportDto.setBankRejectionReason(list.get(31));
				    ecsReportDto.setBankDescription(list.get(32));
				    ecsReportDto.setNrcStatusDescription(list.get(33));
				    ecsReportDto.setBillCycle(list.get(34));
				    ecsReportDto.setCircle(list.get(35));  
				    ecsReportDto.setMtStatus(list.get(36));
				    ecsReportDto.setMtTriggerDate(list.get(37));
				    ecsReportDto.setBankTransactionNo(list.get(38));
				    ecsReportDto.setLinkedTransactionNo(list.get(39));
				    ecsReportDto.setServiceStatus(list.get(40));
				    ecsReportDto.setEcsTriggerDate(list.get(41));
				    ecsReportDto.setEcsStatus(list.get(42));
				    ecsReportDto.setBankTransactionNo(list.get(43));
				    ecsReportDto.setTrackingIds(list.get(44));
				    ecsReportDto.setTrackingIdServs(list.get(45));
				    ecsReportDto.setAmountToPosts(list.get(46));
				    ecsReportDto.setPaymentDescriptions(list.get(47));  
				    ecsReportDto.setReversalDescriptions(list.get(48));
				    ecsReportDto.setDebitDates(list.get(49));
				    ecsReportDto.setBankRejectionReasons(list.get(50));
				    ecsReportDto.setBankTransactionNos(list.get(51));
				    ecsReportDto.setBankDescriptions(list.get(52));
                    ecsReportDto.setNrcStatusDescriptions(list.get(53));
					reportDetailList.add(ecsReportDto);
				}

				System.out.println("end -EcsChargingReport-->>> ");				

			}
             
			if(reportMasterApsDTO.getReportName().equalsIgnoreCase("MasterRefundReport") && finalList!=null){
				
				System.out.println("start -MasterRefundReport-->>> ");
				MasterRefundReport masterRefundReport= null;
				
				for(int i=0;i<finalList.size();i++){
					List<String> list=new ArrayList<String>();
					list=finalList.get(i);
					
					masterRefundReport=new MasterRefundReport();
					masterRefundReport.setSR_NUMBER(list.get(1));
					/*masterRefundReport.setSrType(list.get(2));
					masterRefundReport.setSubType(list.get(3));
					masterRefundReport.setRefundAmount(list.get(4));
					masterRefundReport.setModeOfRefund(list.get(5));
					masterRefundReport.setRejectionReason(list.get(6));
					masterRefundReport.setStatus(list.get(7));
					masterRefundReport.setCircle(list.get(8));
					masterRefundReport.setAccountNumber(list.get(9));
					masterRefundReport.setDelNo(list.get(10));
					masterRefundReport.setName(list.get(11));
					masterRefundReport.setAddress(list.get(12));
					masterRefundReport.setEmail(list.get(13));
					masterRefundReport.setAlternateContact(list.get(14));
					masterRefundReport.setReroutedStatus(list.get(15));
					masterRefundReport.setReroutedNo(list.get(16));
					masterRefundReport.setCadTaskOpen(list.get(17));
					masterRefundReport.setCadTaskClosed(list.get(18));
					masterRefundReport.setCadApprovedBy(list.get(19));
					masterRefundReport.setCadTaskStatus(list.get(20));
					masterRefundReport.setIpTaskOpen(list.get(21));
					masterRefundReport.setIpTaskClosed(list.get(22));
					masterRefundReport.setIpApprovedBy(list.get(23));
					masterRefundReport.setIpTaskStatus(list.get(24));
					masterRefundReport.setCnbTaskOpen(list.get(25));
					masterRefundReport.setCnbTaskClosed(list.get(26));
					masterRefundReport.setCnbApprovedBy(list.get(27));
					masterRefundReport.setCnbTaskStatus(list.get(28));
					masterRefundReport.setDpatchTaskOpen(list.get(29));
					masterRefundReport.setDpatchClosed(list.get(30));
					masterRefundReport.setDpatchApprovedBy(list.get(31));
					masterRefundReport.setDpatchTaskStatus(list.get(32));
					masterRefundReport.setFxPostedDate(list.get(33));
					masterRefundReport.setFxStatus(list.get(34));
					masterRefundReport.setPrevChequeNo(list.get(35));
					masterRefundReport.setParentSr(list.get(36));
					masterRefundReport.setReasonToStop(list.get(37));
					masterRefundReport.setReSrMode(list.get(38));
					masterRefundReport.setPymntStatusCad(list.get(39));
					masterRefundReport.setCadUploadIfsc(list.get(40));
					masterRefundReport.setCadBankAccount(list.get(41));
					masterRefundReport.setCadAddress(list.get(42));
					masterRefundReport.setCnbUtrCheque(list.get(43));
					masterRefundReport.setUtrDate(list.get(44));
					masterRefundReport.setPymntStausCnb(list.get(45));
					masterRefundReport.setAwbNo(list.get(46));
					masterRefundReport.setAwbDate(list.get(47));
					masterRefundReport.setAwbStatus(list.get(48));
					masterRefundReport.setCafNumber(list.get(49));
					masterRefundReport.setDepositDescription(list.get(50));
					masterRefundReport.setSiebelStatus(list.get(51));
					masterRefundReport.setSrReceivedDate(list.get(52));
					masterRefundReport.setSrCreateDate(list.get(53));
					masterRefundReport.setBankAccount(list.get(54));
					masterRefundReport.setIfsc(list.get(55));
					masterRefundReport.setCadSla(list.get(56));
					masterRefundReport.setCadSlaBreach(list.get(57));
					masterRefundReport.setIpSla(list.get(58));
					masterRefundReport.setIpSlaBreach(list.get(59));
					masterRefundReport.setCnbSla(list.get(60));
					masterRefundReport.setCnbSlaBreach(list.get(61));
					masterRefundReport.setDpatchSla(list.get(62));
					masterRefundReport.setDpatcSlaBreach(list.get(63));
					masterRefundReport.setMarketCode(list.get(64));
					masterRefundReport.setCnbReissueStartTime(list.get(65));
					masterRefundReport.setCnbReissueEndTime(list.get(66));
					masterRefundReport.setCnbReissueStatus(list.get(67));
					masterRefundReport.setCnbReissueActedBy(list.get(68));
					masterRefundReport.setCadLeadStartTime(list.get(69));
					masterRefundReport.setCadLeadEndTime(list.get(70));
					masterRefundReport.setCadLeadStatus(list.get(71));
					masterRefundReport.setCadLeadActedBy(list.get(72));
					masterRefundReport.setCadLeadSlaBreach(list.get(73));*/
				//reportDetailList.add(masterRefundReport);
				//}

			logger.info("end -MasterRefundReport-->>> ");				

			//}
			
		}catch(Exception e){

		}
		return reportDetailList;
	}


}
