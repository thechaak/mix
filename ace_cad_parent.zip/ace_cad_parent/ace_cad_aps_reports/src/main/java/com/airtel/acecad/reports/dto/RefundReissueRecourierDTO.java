package com.airtel.acecad.reports.dto;

public class RefundReissueRecourierDTO {
	
	
	private String processId;
	private String accountNumber;
	private String newSrNumber;
	private String paymentStatusCnb;
	private String chequeNumber;
	private String refundAmount;
	private String reasonStopPayment;
	private String chequeDate;
	private String newSrCreationDate;
	private String newSrStatus;
	private String parentSr;
	private String serviceInstance;
	private String cafNumber;
	private String srSubType;
	private String reSrMode;
	private String refundMode;
	private String beneficiaryName;
	private String benAddress1;
	private String benAddress2;
	private String benAddress3;
	private String benAddress4;
	private String pinId;
	private String benAccountNumber;
	private String ifscCode;
	private String benBankName;
	private String benEmailId;
	private String airtelAccountNo;
	private String comments;
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getProcessId() {
		return processId;
	}
	public void setProcessId(String processId) {
		this.processId = processId;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getNewSrNumber() {
		return newSrNumber;
	}
	public void setNewSrNumber(String newSrNumber) {
		this.newSrNumber = newSrNumber;
	}
	public String getPaymentStatusCnb() {
		return paymentStatusCnb;
	}
	public void setPaymentStatusCnb(String paymentStatusCnb) {
		this.paymentStatusCnb = paymentStatusCnb;
	}
	public String getChequeNumber() {
		return chequeNumber;
	}
	public void setChequeNumber(String chequeNumber) {
		this.chequeNumber = chequeNumber;
	}
	public String getRefundAmount() {
		return refundAmount;
	}
	public void setRefundAmount(String refundAmount) {
		this.refundAmount = refundAmount;
	}
	public String getReasonStopPayment() {
		return reasonStopPayment;
	}
	public void setReasonStopPayment(String reasonStopPayment) {
		this.reasonStopPayment = reasonStopPayment;
	}
	public String getChequeDate() {
		return chequeDate;
	}
	public void setChequeDate(String chequeDate) {
		this.chequeDate = chequeDate;
	}
	public String getNewSrCreationDate() {
		return newSrCreationDate;
	}
	public void setNewSrCreationDate(String newSrCreationDate) {
		this.newSrCreationDate = newSrCreationDate;
	}
	public String getNewSrStatus() {
		return newSrStatus;
	}
	public void setNewSrStatus(String newSrStatus) {
		this.newSrStatus = newSrStatus;
	}
	public String getParentSr() {
		return parentSr;
	}
	public void setParentSr(String parentSr) {
		this.parentSr = parentSr;
	}
	public String getServiceInstance() {
		return serviceInstance;
	}
	public void setServiceInstance(String serviceInstance) {
		this.serviceInstance = serviceInstance;
	}
	public String getCafNumber() {
		return cafNumber;
	}
	public void setCafNumber(String cafNumber) {
		this.cafNumber = cafNumber;
	}
	public String getSrSubType() {
		return srSubType;
	}
	public void setSrSubType(String srSubType) {
		this.srSubType = srSubType;
	}
	public String getReSrMode() {
		return reSrMode;
	}
	public void setReSrMode(String reSrMode) {
		this.reSrMode = reSrMode;
	}
	public String getRefundMode() {
		return refundMode;
	}
	public void setRefundMode(String refundMode) {
		this.refundMode = refundMode;
	}
	public String getBeneficiaryName() {
		return beneficiaryName;
	}
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}
	public String getBenAddress1() {
		return benAddress1;
	}
	public void setBenAddress1(String benAddress1) {
		this.benAddress1 = benAddress1;
	}
	public String getBenAddress2() {
		return benAddress2;
	}
	public void setBenAddress2(String benAddress2) {
		this.benAddress2 = benAddress2;
	}
	public String getBenAddress3() {
		return benAddress3;
	}
	public void setBenAddress3(String benAddress3) {
		this.benAddress3 = benAddress3;
	}
	public String getBenAddress4() {
		return benAddress4;
	}
	public void setBenAddress4(String benAddress4) {
		this.benAddress4 = benAddress4;
	}
	public String getPinId() {
		return pinId;
	}
	public void setPinId(String pinId) {
		this.pinId = pinId;
	}
	public String getBenAccountNumber() {
		return benAccountNumber;
	}
	public void setBenAccountNumber(String benAccountNumber) {
		this.benAccountNumber = benAccountNumber;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getBenBankName() {
		return benBankName;
	}
	public void setBenBankName(String benBankName) {
		this.benBankName = benBankName;
	}
	public String getBenEmailId() {
		return benEmailId;
	}
	public void setBenEmailId(String benEmailId) {
		this.benEmailId = benEmailId;
	}
	public String getAirtelAccountNo() {
		return airtelAccountNo;
	}
	public void setAirtelAccountNo(String airtelAccountNo) {
		this.airtelAccountNo = airtelAccountNo;
	}

	

}
