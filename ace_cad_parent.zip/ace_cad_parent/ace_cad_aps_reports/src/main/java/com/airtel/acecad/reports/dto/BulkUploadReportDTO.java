package com.airtel.acecad.reports.dto;

public class BulkUploadReportDTO {
	private String serialNo;
	private String circle;
	private String fileId;
	private String fileName;
	private String fileSource;
	private String type;
	private String uploadedBy;
	private String uploadedDate;
	private String approvedBy;
	private String approvedDate;
	private String totalRecords;
	private String totalValue;
	private String inProgressRecords;
	private String inProgressValue;
	private String status;
	private String recordsPostedToFx;
	private String valuesPostedToFx;
	private String failedRecords;
	private String failedRecordsValue;
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileSource() {
		return fileSource;
	}
	public void setFileSource(String fileSource) {
		this.fileSource = fileSource;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getUploadedBy() {
		return uploadedBy;
	}
	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}
	public String getUploadedDate() {
		return uploadedDate;
	}
	public void setUploadedDate(String uploadedDate) {
		this.uploadedDate = uploadedDate;
	}
	public String getApprovedBy() {
		return approvedBy;
	}
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}
	public String getApprovedDate() {
		return approvedDate;
	}
	public void setApprovedDate(String approvedDate) {
		this.approvedDate = approvedDate;
	}
	public String getTotalRecords() {
		return totalRecords;
	}
	public void setTotalRecords(String totalRecords) {
		this.totalRecords = totalRecords;
	}
	public String getTotalValue() {
		return totalValue;
	}
	public void setTotalValue(String totalValue) {
		this.totalValue = totalValue;
	}
	public String getInProgressRecords() {
		return inProgressRecords;
	}
	public void setInProgressRecords(String inProgressRecords) {
		this.inProgressRecords = inProgressRecords;
	}
	public String getInProgressValue() {
		return inProgressValue;
	}
	public void setInProgressValue(String inProgressValue) {
		this.inProgressValue = inProgressValue;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRecordsPostedToFx() {
		return recordsPostedToFx;
	}
	public void setRecordsPostedToFx(String recordsPostedToFx) {
		this.recordsPostedToFx = recordsPostedToFx;
	}
	public String getValuesPostedToFx() {
		return valuesPostedToFx;
	}
	public void setValuesPostedToFx(String valuesPostedToFx) {
		this.valuesPostedToFx = valuesPostedToFx;
	}
	public String getFailedRecords() {
		return failedRecords;
	}
	public void setFailedRecords(String failedRecords) {
		this.failedRecords = failedRecords;
	}
	public String getFailedRecordsValue() {
		return failedRecordsValue;
	}
	public void setFailedRecordsValue(String failedRecordsValue) {
		this.failedRecordsValue = failedRecordsValue;
	}

}
