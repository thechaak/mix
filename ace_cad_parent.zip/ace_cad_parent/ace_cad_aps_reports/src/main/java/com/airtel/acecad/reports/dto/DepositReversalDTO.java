package com.airtel.acecad.reports.dto;

public class DepositReversalDTO {
	
	
	private String serialNo;
	private String marketCode;
	private String accountExternalId;
	private String mobileNo; 
	private String refundReasonCode;
	private String origTrackingId;
	private String origTrackingIdServ;
	private String depositTypeCode;
	private String crsId;
	private String csrRemark;
	private String businessUnit;
	private String refundType;
	private String fileName;
	private String fileId;
	private String fileSource;
	private String uploadedBy;
	private String uploadedDate;
	private String approvedBy;
	private String approvedDate;
	private String fxReversedDate;
	private String status;
	private String failureReason;
	public String getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	public String getMarketCode() {
		return marketCode;
	}
	public void setMarketCode(String marketCode) {
		this.marketCode = marketCode;
	}
	public String getAccountExternalId() {
		return accountExternalId;
	}
	public void setAccountExternalId(String accountExternalId) {
		this.accountExternalId = accountExternalId;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getRefundReasonCode() {
		return refundReasonCode;
	}
	public void setRefundReasonCode(String refundReasonCode) {
		this.refundReasonCode = refundReasonCode;
	}
	public String getOrigTrackingId() {
		return origTrackingId;
	}
	public void setOrigTrackingId(String origTrackingId) {
		this.origTrackingId = origTrackingId;
	}
	public String getOrigTrackingIdServ() {
		return origTrackingIdServ;
	}
	public void setOrigTrackingIdServ(String origTrackingIdServ) {
		this.origTrackingIdServ = origTrackingIdServ;
	}
	public String getDepositTypeCode() {
		return depositTypeCode;
	}
	public void setDepositTypeCode(String depositTypeCode) {
		this.depositTypeCode = depositTypeCode;
	}
	public String getCrsId() {
		return crsId;
	}
	public void setCrsId(String crsId) {
		this.crsId = crsId;
	}
	public String getCsrRemark() {
		return csrRemark;
	}
	public void setCsrRemark(String csrRemark) {
		this.csrRemark = csrRemark;
	}
	public String getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}
	public String getRefundType() {
		return refundType;
	}
	public void setRefundType(String refundType) {
		this.refundType = refundType;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getFileSource() {
		return fileSource;
	}
	public void setFileSource(String fileSource) {
		this.fileSource = fileSource;
	}
	public String getUploadedBy() {
		return uploadedBy;
	}
	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}
	public String getUploadedDate() {
		return uploadedDate;
	}
	public void setUploadedDate(String uploadedDate) {
		this.uploadedDate = uploadedDate;
	}
	public String getApprovedBy() {
		return approvedBy;
	}
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}
	public String getApprovedDate() {
		return approvedDate;
	}
	public void setApprovedDate(String approvedDate) {
		this.approvedDate = approvedDate;
	}
	public String getFxReversedDate() {
		return fxReversedDate;
	}
	public void setFxReversedDate(String fxReversedDate) {
		this.fxReversedDate = fxReversedDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getFailureReason() {
		return failureReason;
	}
	public void setFailureReason(String failureReason) {
		this.failureReason = failureReason;
	}

}
