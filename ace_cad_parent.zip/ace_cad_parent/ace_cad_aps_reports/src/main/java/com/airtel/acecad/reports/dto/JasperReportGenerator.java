package com.airtel.acecad.reports.dto;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleXlsReportConfiguration;

/**
 * 
 */

public class JasperReportGenerator {
	
	@Autowired
	
	//static
	DataSource dataSource;
	@Autowired
	private PlatformTransactionManager transactionManager;
	/**
	 * 
	 */
	public JasperReportGenerator() {
	}
	public JasperReportGenerator(DataSource dataSource) {
		this.dataSource = dataSource;
		setTransactionManager(transactionManager);
	}
	public void setTransactionManager(
			PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}
	private static Logger logger = LogManager.getLogger("workflowControlLogger");
	/**
	 * @description This method will generate a PDF report.
	 * @param reportTemplate
	 * @param outputFileName
	 * @param dataBeanList
	 * @param parameters
	 * @return boolean
	 * @throws JRException
	 * @throws FileNotFoundException
	 */
	public static boolean generatePdfReport(String reportTemplate, String outputFileName, List<Object> dataBeanList, Map<String, Object> parameters) {
		boolean success = true;
		
		logger.info("START - generatePdfReport of JasperReportGenerator for template :: " + reportTemplate);
		try{
			InputStream inputStream = new FileInputStream (reportTemplate);

			JasperDesign jasperDesign = JRXmlLoader.load(inputStream);
			JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
			
			JasperPrint jasperPrint = null;
			if(dataBeanList == null || dataBeanList.isEmpty()){
				jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, new JREmptyDataSource());
			}else{
				jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, new JRBeanCollectionDataSource(dataBeanList));
			}
			
			JasperExportManager.exportReportToPdfFile(jasperPrint, outputFileName+".pdf"); 
		}catch(Exception e){
			logger.info(e);
			success = false;
		}
		logger.info("END - generatePdfReport of JasperReportGenerator for template :: " + reportTemplate + " :: Success :: " + success);
		return success;
	}

	/**

	 * @description This method will generate a EXCEL report.
	 * @param reportTemplate
	 * @param outputFileName
	 * @param dataBeanList
	 * @param parameters
	 * @return boolean
	 * @throws JRException
	 * @throws FileNotFoundException
	 */
	public boolean generateExcelReport(String reportTemplate, String outputFileName, Collection<Object> dataBeanList, Map<String, Object> parameters,String startDate, String endDate,String fileId) throws JRException, FileNotFoundException {
		boolean success = true;
		logger.info("outputFileName---->>>>>>>>>>"+outputFileName);
		logger.info("START - generateExcelReport of JasperReportGenerator for template :: " + reportTemplate);
		Connection connection=null;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

		try{
			InputStream inputStream = new FileInputStream (reportTemplate);

			JasperDesign jasperDesign = JRXmlLoader.load(inputStream);
			System.out.println("hello####111");
			JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
			System.out.println("hello####");
			JasperPrint jasperPrint = null;
			//parameters.put(JRParameter.IS_IGNORE_PAGINATION, Boolean.TRUE);
		//	System.out.println("before making connection------------>>>>>>>>>>");
			//Connection connection = null;
	        try {
	       // Class.forName("oracle.jdbc.driver.OracleDriver");
	        connection = jdbcTemplate.getDataSource().getConnection();
	        } catch (SQLException ex) {
	        } 
	        logger.info("connection------------>>>>>>>>>>"+connection);
			
			
		
			Map<String, Object> parameters1 = new HashMap<String ,Object>();
			
			parameters1.put("endDate", endDate);
			parameters1.put("startDate", startDate);
			parameters1.put("fileId", fileId);
			
            
			logger.info("parameters------------>>>>>>>>>>"+parameters1);
			
			
			try { 
				/*if(reportTemplate.contains("MasterRefundReport")||outputFileName.contains("LBX_CHQ_Report")||outputFileName.contains("Cheque_Homes_Record")||outputFileName.contains("Misc_Report")||outputFileName.contains("Misc_Homes")||outputFileName.contains("Neft_Report")||
				  reportTemplate.contains("cadCreeperDownload")||reportTemplate.contains("cadCreeperDownloadPD")||reportTemplate.contains("cadCreeperDownloadNCA")||reportTemplate.contains("ReissueRecourierDownload")
				 || reportTemplate.contains("IP_BIN_DOWNLOAD")||reportTemplate.contains("docketDownload")||reportTemplate.contains("CB_DECISION_DOWNLOAD")||reportTemplate.contains("RefundBulk")||outputFileName.contains("BlackListed_Accounts")
				 ||reportTemplate.contains("UntracedAccount")||reportTemplate.contains("DashBoardQuery")||outputFileName.contains("Unaccounted_EFT_Report")||outputFileName.contains("Suspense_View")||reportTemplate.contains("DepositTransfer")||reportTemplate.contains("PaymentTransfer")||
				 outputFileName.contains("Pending_Neft_Records")||outputFileName.contains("Misc_Pending_Records")||outputFileName.contains("Pending_Cheque_Records")||outputFileName.contains("Untraced_Cheque_Records")||outputFileName.contains("PendingPaymentAdvice")
				 ||reportTemplate.contains("CPMiscRecord")||reportTemplate.contains("NRCRecords")||reportTemplate.contains("AdjustmentRecords")||reportTemplate.contains("AdjustmentReversal")||reportTemplate.contains("DepositRecords")||reportTemplate.contains("ReversalRecords")||

				 outputFileName.contains("Payment_Transfer_Records")||outputFileName.contains("Payment_Transfer_SR_Records")||outputFileName.contains("Refund_Current_Status")||outputFileName.contains("Refund_Record_Closed")||outputFileName.contains("Cheque_Bounce_Records") 
				 || outputFileName.contains("Payment_Posting_Records") || outputFileName.contains("Direct_Reversel_Report")|| outputFileName.contains("DUP_CAD_REFUND")|| outputFileName.contains("DUP_CAD_REFUNDNCA")
				 || outputFileName.contains("DUP_CAD_REFUNDPD")|| outputFileName.contains("DUP_CAD_REISSUE"))*/
				
				if(reportTemplate!=null && outputFileName!=null){
					
					logger.info("in direct db connection loop of jasper report---------------------------------");
					System.out.println("in direct db connection loop of jasper report---------------------------------");                  
					jasperPrint = JasperFillManager.fillReport(jasperReport, parameters1, connection);
					//jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, new JRBeanCollectionDataSource(dataBeanList));
				
				}
				else{
					
					if(dataBeanList == null || dataBeanList.isEmpty()){
						jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, new JREmptyDataSource());
					}else{
						jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, new JRBeanCollectionDataSource(dataBeanList));
						//jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, new JRBeanCollectionDataSource(dataBeanList));
					}
					
				}
			} catch (JRException e) {
				System.out.println("in jr exception block"+e);
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			

			//Commented To include Custom JRXlsExporter to implement
			//aps.reports.org.apache.poi to remove poi 3.10FINAL and poi 3.15 conflict
			CustomJRXlsExporter exporter = new CustomJRXlsExporter();
			//JRXlsExporter exporter = new JRXlsExporter();
			exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
			exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(outputFileName+".xls"));

			SimpleXlsReportConfiguration configuration = new SimpleXlsReportConfiguration();
			//configuration.setOnePagePerSheet(true);
			configuration.setDetectCellType(true);
			configuration.setCollapseRowSpan(true);
			configuration.setAutoFitPageHeight(true);
			configuration.setWhitePageBackground(false);
			
			//configuration.setPageScale(150);
			
			//configuration.setMaxRowsPerSheet(100);
			//configuration.

			exporter.setConfiguration(configuration);

			exporter.exportReport();

		}catch(Exception e){
			System.out.println( e);
			e.printStackTrace();
			success = false;
		}
		System.out.println("END - generateExcelReport of JasperReportGenerator for template :: " + reportTemplate + " :: Success :: " + success);
		return success;
	}
	
	
	
}
