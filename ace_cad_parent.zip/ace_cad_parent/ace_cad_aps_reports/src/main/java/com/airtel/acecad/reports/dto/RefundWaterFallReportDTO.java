package com.airtel.acecad.reports.dto;

public class RefundWaterFallReportDTO {
	
	private String srNumber;
	private String srType;
	private String srCreationDate;
	private String srStatus;
	private String refundType;
	private String refundAmount;
	private String taskName;
	private String groupName;
	private String taskStatus;
	private String actedBy;
	private String actionTaken;
	private String taskStartTime;
	private String taskEndTime;
	private String notes;
	private String slaBreached;
	private String circle;
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getSrType() {
		return srType;
	}
	public void setSrType(String srType) {
		this.srType = srType;
	}
	public String getSrCreationDate() {
		return srCreationDate;
	}
	public void setSrCreationDate(String srCreationDate) {
		this.srCreationDate = srCreationDate;
	}
	public String getSrStatus() {
		return srStatus;
	}
	public void setSrStatus(String srStatus) {
		this.srStatus = srStatus;
	}
	public String getRefundType() {
		return refundType;
	}
	public void setRefundType(String refundType) {
		this.refundType = refundType;
	}
	public String getRefundAmount() {
		return refundAmount;
	}
	public void setRefundAmount(String refundAmount) {
		this.refundAmount = refundAmount;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getTaskStatus() {
		return taskStatus;
	}
	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}
	public String getActedBy() {
		return actedBy;
	}
	public void setActedBy(String actedBy) {
		this.actedBy = actedBy;
	}
	public String getActionTaken() {
		return actionTaken;
	}
	public void setActionTaken(String actionTaken) {
		this.actionTaken = actionTaken;
	}
	public String getTaskStartTime() {
		return taskStartTime;
	}
	public void setTaskStartTime(String taskStartTime) {
		this.taskStartTime = taskStartTime;
	}
	public String getTaskEndTime() {
		return taskEndTime;
	}
	public void setTaskEndTime(String taskEndTime) {
		this.taskEndTime = taskEndTime;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getSlaBreached() {
		return slaBreached;
	}
	public void setSlaBreached(String slaBreached) {
		this.slaBreached = slaBreached;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}

}
