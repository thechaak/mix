package com.airtel.acecad.reports.dto;

public class RefundSrCurrentStatusDTO {
	
	
	private String srNumber;
	private String dateSr;
	private String srName;
	private String srSubType;
	private String accountNo;
	private String cafNumber;
    private String mobDelNo;
    private String customerName;
    private String address;
    private String email;
    private String alternateContactNo;
    private String modeOfRefund;
    private String taskName;
    private String taskOwner;
    private String approvedBy;
    private String taskStartDate;
    private String taskEndDate;
    private String taskStatus;
    private String remarks;
    private String bankRefNumber;
    private String utrChequeDate;
    private String awbNumber;
    private String deliveryStatus;
    private String circle;
    public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	private String marketCode;
    private String refundAmount;
    private String srMode;
    private String paymentStatus;
    private String parentSrNumber;
    private String comments;
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getDateSr() {
		return dateSr;
	}
	public void setDateSr(String dateSr) {
		this.dateSr = dateSr;
	}
	public String getSrName() {
		return srName;
	}
	public void setSrName(String srName) {
		this.srName = srName;
	}
	public String getSrSubType() {
		return srSubType;
	}
	public void setSrSubType(String srSubType) {
		this.srSubType = srSubType;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getCafNumber() {
		return cafNumber;
	}
	public void setCafNumber(String cafNumber) {
		this.cafNumber = cafNumber;
	}
	public String getMobDelNo() {
		return mobDelNo;
	}
	public void setMobDelNo(String mobDelNo) {
		this.mobDelNo = mobDelNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAlternateContactNo() {
		return alternateContactNo;
	}
	public void setAlternateContactNo(String alternateContactNo) {
		this.alternateContactNo = alternateContactNo;
	}
	public String getModeOfRefund() {
		return modeOfRefund;
	}
	public void setModeOfRefund(String modeOfRefund) {
		this.modeOfRefund = modeOfRefund;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getTaskOwner() {
		return taskOwner;
	}
	public void setTaskOwner(String taskOwner) {
		this.taskOwner = taskOwner;
	}
	public String getApprovedBy() {
		return approvedBy;
	}
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}
	public String getTaskStartDate() {
		return taskStartDate;
	}
	public void setTaskStartDate(String taskStartDate) {
		this.taskStartDate = taskStartDate;
	}
	public String getTaskEndDate() {
		return taskEndDate;
	}
	public void setTaskEndDate(String taskEndDate) {
		this.taskEndDate = taskEndDate;
	}
	public String getTaskStatus() {
		return taskStatus;
	}
	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getBankRefNumber() {
		return bankRefNumber;
	}
	public void setBankRefNumber(String bankRefNumber) {
		this.bankRefNumber = bankRefNumber;
	}
	public String getUtrChequeDate() {
		return utrChequeDate;
	}
	public void setUtrChequeDate(String utrChequeDate) {
		this.utrChequeDate = utrChequeDate;
	}
	public String getAwbNumber() {
		return awbNumber;
	}
	public void setAwbNumber(String awbNumber) {
		this.awbNumber = awbNumber;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getMarketCode() {
		return marketCode;
	}
	public void setMarketCode(String marketCode) {
		this.marketCode = marketCode;
	}
	public String getRefundAmount() {
		return refundAmount;
	}
	public void setRefundAmount(String refundAmount) {
		this.refundAmount = refundAmount;
	}
	public String getSrMode() {
		return srMode;
	}
	public void setSrMode(String srMode) {
		this.srMode = srMode;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public String getParentSrNumber() {
		return parentSrNumber;
	}
	public void setParentSrNumber(String parentSrNumber) {
		this.parentSrNumber = parentSrNumber;
	}

}
